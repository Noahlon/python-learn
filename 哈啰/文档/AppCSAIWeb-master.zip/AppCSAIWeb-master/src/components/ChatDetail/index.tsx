import { Button, Popover, Table, Modal } from 'antd';
import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import { toPng } from 'html-to-image';
import AudioPlayer from 'react-h5-audio-player';
import 'react-h5-audio-player/lib/styles.css';
import { isEmpty } from 'lodash';
import { ICallDetail, ICallMsg, IIntentDetectionInfoList } from '@/api/call';
import { releaseInitiatorOption } from '@/pages/calllist';
import { useModel } from '@umijs/max';
import { httpReplace } from '@/utils';
import { VerticalAlignBottomOutlined } from '@ant-design/icons';
import { v1 as uuidv1 } from 'uuid';
import PopoverComponent from './popoverComponent';
import { formList, hitIntentColumns } from './config';
import hitIntent from '@/assets/img/hitIntent.png';
import styles from './index.less';

interface Prop {
  callType?: number;
  callLineName?: string;
  isTurnBottom?: boolean;
  info?: ICallDetail;
  translateChecked?: boolean;
  isCalllist?: boolean;
  isErrorCorrection?: boolean;
  update?: any;
  isUpdateScroll?: boolean; //是否需要更新scroll滚动条
}

const callTestType = {
  0: '本地测试',
  1: '呼叫测试',
};
// 意图类型
export const intentionTypeOption = [
  { label: '短语', value: 1 },
  { label: '算法', value: 2 },
  { label: '核心句', value: 3 },
  { label: '短语+算法', value: 4 },
  { label: '算法+短语', value: 5 },
];

interface ICorrectionInfo {
  asrIssues?: string; //ASR识别不准具体问题描述
  missingCorpus?: string; //缺少语料具体问题描述
  intentIssues?: string; //意图识别问题
  intentIssuesList?: number[]; //意图识别问题id IntentIssuesEnum枚举key
  otherDescription?: string; //其他问题描述
}

interface CurrentData {
  key?: number;
  type?: string;
  formData?: any;
  speakId?: string;
  correctionInfo: ICorrectionInfo;
}
const ChatDetail: React.FC<Prop> = ({
  info,
  isTurnBottom = false,
  callType,
  callLineName,
  translateChecked = false,
  isCalllist = false,
  isErrorCorrection = false,
  update,
  isUpdateScroll = true,
}) => {
  const [currentData, setCurrentData] = useState<any>({});
  const chatRef = useRef(null);
  const { breakOptions, getBreakList } = useModel('speech');
  // const [curCallnfo, setCallInfo] = useState<ICallMsg>(undefined);
  const audioRef = useRef(null);

  // 意图识别弹窗
  const [hitIntentOpen, setHitIntentOpen] = useState<boolean>(false);
  const [hitIntentList, setHitIntentList] = useState<
    IIntentDetectionInfoList[]
  >([]);

  useEffect(() => {
    //通话记录+单据纠错引用时，不改变scroll位置
    if (isUpdateScroll) {
      if (isTurnBottom) {
        document
          .getElementById('chatRoom')
          ?.scrollTo(0, chatRef.current?.clientHeight + 300);
      } else {
        document.getElementById('chatRoom').scrollTo(0, 0);
      }
    }

    if (!breakOptions?.length) {
      getBreakList();
    }
    setCurrentData({});
  }, [info]);

  // 聊天文本转图片
  const onButtonClick = useCallback(() => {
    if (chatRef.current === null) {
      return;
    }
    toPng(chatRef.current, { cacheBust: true })
      .then((dataUrl) => {
        const link = document.createElement('a');
        link.download = 'my-image-name.png';
        link.href = dataUrl;
        link.click();
      })
      .catch((err) => {
        console.log(err);
      });
  }, [chatRef]);

  // 播放
  const handlePlay = useCallback((info: ICallMsg) => {
    if (!info?.splitAudioUrl) return;
    // setCallInfo(info);
    if (audioRef.current?.audio?.current) {
      audioRef.current.audio.current.src = httpReplace(info?.splitAudioUrl);
      audioRef.current.audio.current.currentTime = 0;
    }
  }, []);

  // 播放结束
  const handleAudioEnd = useCallback(() => {
    // setCallInfo(undefined);
    audioRef.current.audio.current.currentTime = 0;
    audioRef.current.audio.current.src = '';
  }, []);
  // 选中当前语句赋值及提交纠错表单
  const updateCurrentData = (
    data: CurrentData,
    value?: ICorrectionInfo,
    speakId?: string,
  ) => {
    if (speakId && update) {
      update(value, speakId);
    }
    setCurrentData(data);
  };

  // 处理Popover的placement方向
  const handleString = (speakContents = [], item: any, index: number) => {
    const verticalString =
      speakContents?.length - 1 === index && speakContents?.length > 1
        ? 'Bottom'
        : 'Top';
    const levelString = item.speaker === 1 ? `right` : `left`;

    return `${levelString}${verticalString}`;
  };
  return (
    <>
      <Button onClick={onButtonClick} style={{ display: 'none' }}>
        下载
      </Button>
      <div className={styles.chatDetail} id="chatRoom">
        <div className={styles.chatContent} ref={chatRef}>
          {(!!callType || callType === 0) && (
            <div className={styles.createTime}>
              测试类型：{callTestType[`${callType}`]}
            </div>
          )}
          {!!callType && info?.callDialogueResDTO?.calledNumber && (
            <div className={styles.createTime}>
              被叫号：{info?.callDialogueResDTO?.calledNumber}
            </div>
          )}
          {!!callType && callLineName && (
            <div className={styles.createTime}>外呼线路：{callLineName}</div>
          )}
          {info?.callDialogueResDTO?.dialTime && (
            <div className={styles.createTime}>
              {info?.callDialogueResDTO?.dialTime} 开始呼叫
            </div>
          )}
          {info?.callDialogueResDTO?.answerTime && (
            <div className={styles.createTime}>
              {info?.callDialogueResDTO?.answerTime} 建立通话
            </div>
          )}
          {info?.speakContents?.map((item, index) => (
            <div key={`${item.speakTime}_${index}`}>
              <div
                className={`${styles.chatItem} ${
                  item.speaker === 2 ? styles.right : ''
                } ${
                  !isEmpty(item?.correctionInfo) ? styles.hasCorrection : ''
                }`}
              >
                <div className={styles.wrap}>
                  <div className={styles.time}>{item.speakTime}</div>
                  {item.speaker === 1 && (
                    <div className={styles.process}>
                      {index && (item.corpusSourceDesc || item.corpusName)
                        ? '触发 -> '
                        : null}
                      {item.corpusSourceDesc || item.corpusName
                        ? `${item.corpusSourceDesc || '-'}/${
                            item.corpusName || '-'
                          }`
                        : null}
                    </div>
                  )}
                  {/* 操作位置 */}
                  <PopoverComponent
                    item={item}
                    index={index}
                    currentData={currentData}
                    updateCurrentData={updateCurrentData}
                    chatRef={chatRef}
                    isErrorCorrection={isErrorCorrection}
                    formList={formList}
                    popoverPlacement={handleString(
                      info?.speakContents,
                      item,
                      index,
                    )}
                  >
                    <div
                      className={
                        item.speaker === 2 && !!item.splitAudioUrl
                          ? `${styles.text} ${styles.showAudio}`
                          : styles.text
                      }
                    >
                      {/* 点击icon打开命中意图弹窗 */}
                      {item.speaker === 2 &&
                        item?.intentDetectionInfoList?.length > 0 && (
                          <img
                            src={hitIntent}
                            className={styles.hitIntentIcon}
                            onClick={() => {
                              setHitIntentOpen(true);
                              setHitIntentList(
                                item?.intentDetectionInfoList || [],
                              );
                            }}
                          ></img>
                        )}
                      {item.splitAudioUrl && (
                        <a
                          href={httpReplace(item.splitAudioUrl)}
                          style={{
                            left:
                              item?.sentRecogResultList?.length > 0
                                ? '-50px'
                                : '-30px',
                          }}
                          className={styles.upload}
                        >
                          <VerticalAlignBottomOutlined />
                        </a>
                      )}
                      {translateChecked
                        ? item.translateSpeakContent
                        : item.speakContent}
                      {/* 播放按钮 */}
                      {item.speaker === 2 && !!item.splitAudioUrl && (
                        <span className={styles.audio}>
                          {item?.playTime === 0 ? 0 : item?.playTime || '无'}
                          &Prime;
                          <svg
                            aria-hidden="true"
                            fill="currentColor"
                            className={styles.play}
                            onClick={() => handlePlay(item)}
                          >
                            <use xlinkHref="#icon-yuyinbofang-left"></use>
                          </svg>
                        </span>
                      )}
                    </div>
                  </PopoverComponent>

                  {item.speaker === 2 ? (
                    <svg
                      className={styles.icon}
                      aria-hidden="true"
                      fill="currentColor"
                    >
                      <use xlinkHref="#icon-yonghu"></use>
                    </svg>
                  ) : (
                    <svg
                      className={styles.icon}
                      aria-hidden="true"
                      fill="currentColor"
                    >
                      <use xlinkHref="#icon-007jiqiren"></use>
                    </svg>
                  )}
                  {/* 通话记录翻译 */}
                  {isCalllist && item.translateSpeakContent && (
                    <div className={styles.translateText}>
                      {item.translateSpeakContent}
                    </div>
                  )}
                  {item.speaker === 1 && item.isUnifiedAnswer && (
                    <div className={styles.reply}>开启统一回复</div>
                  )}
                  {item.speaker === 1 && item.breakType && (
                    <div className={styles.reply}>
                      {
                        breakOptions?.find((i) => i.type === item.breakType)
                          ?.desc
                      }
                    </div>
                  )}
                  {item.speaker === 1 && item.jumpType && item.jumpTypeDesc && (
                    <div className={styles.reply}>
                      跳转：{item.jumpTypeDesc}
                    </div>
                  )}
                  {item.speaker === 2 &&
                    !!(translateChecked
                      ? item.translateSegments?.length
                      : item.segments?.length) && (
                      <div className={styles.participle}>
                        {(translateChecked
                          ? item.translateSegments
                          : item.segments
                        )?.map((item, index) => (
                          <span key={`${item}_${index}`}>{item}</span>
                        ))}
                      </div>
                    )}
                  {/* 2025-06-19新增sentRecogResultList（显示单语句命中列表集合）和intentDetectionInfoList（显示单语句命中过的列表）*/}
                  {/* 命中核心句 */}
                  {item.speaker === 2 &&
                    item?.sentRecogResultList?.length > 0 &&
                    item.sentRecogResultList.map((items, index) => {
                      return (
                        <div className={styles.intentionWrap} key={index}>
                          <span className={styles.label}>
                            {items?.intentDetectionTypeName} :
                          </span>
                          <div className={styles.intentionContent}>
                            <div className={styles.sentRecogResultItem}>
                              {(items?.hitIntentSetName ||
                                items?.hitIntent) && (
                                <div className={styles.intention}>
                                  <Popover
                                    getPopupContainer={(node) =>
                                      chatRef?.current || node
                                    }
                                    content={`${items?.hitIntentSetName || ''}${
                                      (items?.hitIntentSetName &&
                                        items?.hitIntent &&
                                        '/') ||
                                      ''
                                    }${items?.hitIntent || ''}`}
                                  >
                                    {`${items?.hitIntentSetName || ''}${
                                      (items?.hitIntentSetName &&
                                        items?.hitIntent &&
                                        '/') ||
                                      ''
                                    }${items?.hitIntent || ''}`}
                                  </Popover>
                                </div>
                              )}

                              {items?.hitInfo && (
                                <div
                                  className={
                                    styles.hitInfoText +
                                    ' ' +
                                    `${
                                      !items?.hitIntentSetName &&
                                      !items?.hitIntent
                                        ? styles.hitInfoTextWidth
                                        : ''
                                    }`
                                  }
                                >
                                  <Popover
                                    getPopupContainer={(node) =>
                                      chatRef?.current || node
                                    }
                                    content={items?.hitInfo}
                                  >
                                    {items?.hitInfo}
                                  </Popover>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  {/* 核心句 */}
                  {item.speaker === 2 &&
                    !item?.sentRecogResultList?.length &&
                    !item?.intentDetectionInfoList?.length &&
                    item.userIntentions?.filter((i) =>
                      [3].includes(i.intentionObtainType),
                    )?.length > 0 && (
                      <div className={styles.intentionWrap}>
                        <span className={styles.label}>核心句意图:</span>
                        <div className={styles.intentionContent}>
                          {item.userIntentions
                            .filter((i) => [3].includes(i.intentionObtainType))
                            .map((i, index) => (
                              <div
                                key={`${i.intention}_${index}`}
                                className={styles.intentionItem}
                              >
                                <div
                                  className={
                                    i.isHit
                                      ? `${styles.intention} ${styles.selectIntention}`
                                      : styles.intention
                                  }
                                >
                                  <Popover
                                    content={`${
                                      i.intentionColleciton
                                        ? i.intentionColleciton
                                        : ''
                                    }${
                                      i.intentionColleciton && i.intention
                                        ? '/'
                                        : ''
                                    }${i.intention}`}
                                  >
                                    {i.intentionColleciton
                                      ? i.intentionColleciton
                                      : ''}
                                    {i.intentionColleciton && i.intention
                                      ? '/'
                                      : ''}
                                    {i.intention}
                                  </Popover>
                                </div>
                              </div>
                            ))}
                        </div>
                      </div>
                    )}
                  {/* 算法意图 */}
                  {item.speaker === 2 &&
                    !item?.sentRecogResultList?.length &&
                    !item?.intentDetectionInfoList?.length &&
                    item.userIntentions?.filter(
                      (i) => ![1, 3].includes(i.intentionObtainType),
                    )?.length > 0 && (
                      <div className={styles.intentionWrap}>
                        <div
                          className={`${styles.intentionContent} ${styles.wP100}`}
                        >
                          {item.userIntentions
                            .filter(
                              (i) => ![1, 3].includes(i.intentionObtainType),
                            )
                            .map((i, index) => (
                              <div
                                className={`${styles.typeFlex} ${styles.flexEnd}`}
                                key={`type${index}`}
                              >
                                {i.intentionObtainType && (
                                  <span className={styles.label}>
                                    {
                                      intentionTypeOption.find(
                                        (item) =>
                                          item.value === i.intentionObtainType,
                                      )?.label
                                    }
                                    :
                                  </span>
                                )}

                                <div
                                  key={`${i.intention}_${index}`}
                                  className={styles.intentionItem}
                                >
                                  <div
                                    className={
                                      i.isHit
                                        ? `${styles.intention} ${styles.selectIntention}`
                                        : styles.intention
                                    }
                                  >
                                    <Popover
                                      content={`${
                                        i.intentionColleciton
                                          ? i.intentionColleciton
                                          : ''
                                      }${
                                        i.intentionColleciton && i.intention
                                          ? '/'
                                          : ''
                                      }${i.intention}`}
                                    >
                                      {i.intentionColleciton
                                        ? i.intentionColleciton
                                        : ''}
                                      {i.intentionColleciton && i.intention
                                        ? '/'
                                        : ''}
                                      {i.intention}
                                    </Popover>
                                  </div>
                                  {i?.score && (
                                    <div className={styles.purpos}>
                                      {i?.score}
                                    </div>
                                  )}
                                  {(translateChecked
                                    ? i.translateHitPhrases
                                    : i.hitPhrases
                                  )?.map((j) => (
                                    <div key={j} className={styles.purpos}>
                                      {j}
                                    </div>
                                  ))}
                                </div>
                              </div>
                            ))}
                        </div>
                      </div>
                    )}
                  {item.speaker === 2 &&
                    !item?.sentRecogResultList?.length &&
                    !item?.intentDetectionInfoList?.length &&
                    item.hitCoreNodeName &&
                    !!item.hitCorePhrases?.length && (
                      <div className={styles.phraseWrap}>
                        <span className={styles.label}>命中短语:</span>
                        <div className={styles.phraseContent}>
                          <div className={styles.phraseItem}>
                            {item.hitCoreNodeName}
                          </div>
                          {item.hitCorePhrases.map((j) => (
                            <div key={uuidv1()} className={styles.phraseItem}>
                              {j}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  {item.speaker === 2 &&
                    !item?.sentRecogResultList?.length &&
                    !item?.intentDetectionInfoList?.length &&
                    item.userIntentions?.filter(
                      (i) => i.intentionObtainType === 1,
                    )?.length > 0 && (
                      <div className={styles.intentionWrap}>
                        <span className={styles.label}>
                          短语意图
                          {
                            item.userIntentions?.filter(
                              (i) => i.intentionObtainType === 1,
                            )?.[0]?.version
                          }
                          :
                        </span>
                        <div className={styles.intentionContent}>
                          {item.userIntentions
                            ?.filter((i) => i.intentionObtainType === 1)
                            ?.map((i, index) => (
                              <div
                                key={`${i.intention}_${index}`}
                                className={styles.intentionItem}
                              >
                                {(i.intentionColleciton || i.intention) && (
                                  <div
                                    className={
                                      i.isHit
                                        ? `${styles.intention} ${styles.selectIntention}`
                                        : styles.intention
                                    }
                                  >
                                    <Popover
                                      content={`${i.intentionColleciton}/${i.intention}`}
                                    >
                                      {i.intentionColleciton}/{i.intention}
                                    </Popover>
                                  </div>
                                )}
                                {(translateChecked
                                  ? i.translateHitPhrases
                                  : i.hitPhrases
                                )?.map((j) => (
                                  <div key={j} className={styles.purpos}>
                                    {j}
                                  </div>
                                ))}
                              </div>
                            ))}
                        </div>
                      </div>
                    )}
                </div>
              </div>
              {item?.isTriggerTransfer && (
                <div className={styles.createTime}>
                  {item?.speakTime} 触发转接
                </div>
              )}
            </div>
          ))}

          {/* 识别挂断后ASR */}
          {info?.rearAsrInfoList?.map((item, index) => (
            <div
              className={`${styles.rearAsrBox} ${styles.chatItem} ${styles.right}`}
              key={`${item?.asrRearTime}_${index}`}
            >
              <div className={styles.wrap}>
                <div className={styles.time}>{item?.asrRearTime}</div>
                <div className={styles.textBox}>
                  {item?.intentDetectionInfoList?.length > 0 && (
                    <img
                      src={hitIntent}
                      className={styles.rearAsrHitIntentIcon}
                      onClick={() => {
                        setHitIntentOpen(true);
                        setHitIntentList(item?.intentDetectionInfoList || []);
                      }}
                    ></img>
                  )}
                  <div className={styles.text}>{item?.asrInput}</div>
                </div>
                <svg
                  className={styles.icon}
                  aria-hidden="true"
                  fill="currentColor"
                >
                  <use xlinkHref="#icon-yonghu"></use>
                </svg>
                {/* 命中核心句 */}
                {item?.sentRecogResultList?.length > 0 &&
                  item.sentRecogResultList.map((items, index) => {
                    return (
                      <div className={styles.intentionWrap} key={index}>
                        <span className={styles.label}>
                          {items?.intentDetectionTypeName} :
                        </span>
                        <div className={styles.intentionContent}>
                          <div className={styles.sentRecogResultItem}>
                            {(items?.hitIntentSetName || items?.hitIntent) && (
                              <div className={styles.intention}>
                                <Popover
                                  getPopupContainer={(node) =>
                                    chatRef?.current || node
                                  }
                                  content={`${items?.hitIntentSetName || ''}${
                                    (items?.hitIntentSetName &&
                                      items?.hitIntent &&
                                      '/') ||
                                    ''
                                  }${items?.hitIntent || ''}`}
                                >
                                  {`${items?.hitIntentSetName || ''}${
                                    (items?.hitIntentSetName &&
                                      items?.hitIntent &&
                                      '/') ||
                                    ''
                                  }${items?.hitIntent || ''}`}
                                </Popover>
                              </div>
                            )}

                            {items?.hitInfo && (
                              <div
                                className={
                                  styles.hitInfoText +
                                  ' ' +
                                  `${
                                    !items?.hitIntentSetName &&
                                    !items?.hitIntent
                                      ? styles.hitInfoTextWidth
                                      : ''
                                  }`
                                }
                              >
                                <Popover
                                  getPopupContainer={(node) =>
                                    chatRef?.current || node
                                  }
                                  content={items?.hitInfo}
                                >
                                  {items?.hitInfo}
                                </Popover>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                <div className={styles.intentionAsrDesc}>
                  <div>
                    {item?.asrTypeDesc}识别{'   '}命中意向：
                    {item?.intentionClassification || '空'}
                  </div>
                  <div>
                    分类名称：{item?.intentionClassificationDesc || '空'}
                  </div>
                </div>
              </div>
            </div>
          ))}
          {info?.callDialogueResDTO?.transferTime && (
            <div className={styles.createTime}>
              {info?.callDialogueResDTO?.transferTime} 转接成功
            </div>
          )}
          {info?.callDialogueResDTO?.hangupTime && (
            <div className={styles.createTime}>
              {info?.callDialogueResDTO?.hangupTime} &nbsp; &nbsp;
              {releaseInitiatorOption.find(
                (item) =>
                  item.value === info?.callDialogueResDTO?.releaseInitiator,
              )?.label || ''}
              挂断
            </div>
          )}
        </div>
      </div>
      <AudioPlayer
        ref={audioRef}
        style={{ display: 'none' }}
        // src={httpReplace(curCallnfo?.splitAudioUrl)}
        autoPlay={true}
        autoPlayAfterSrcChange={false}
        progressJumpStep={12 * 1000}
        customAdditionalControls={[]}
        onEnded={handleAudioEnd}
      />
      <Modal
        open={hitIntentOpen}
        footer={null}
        title={'查看'}
        onCancel={() => setHitIntentOpen(false)}
        width={'960px'}
      >
        <Table
          pagination={false}
          columns={hitIntentColumns}
          dataSource={hitIntentList}
          scroll={{ x: 2200, y: 450 }}
          rowKey={() => uuidv1()}
        ></Table>
      </Modal>
    </>
  );
};

export default memo(ChatDetail);
