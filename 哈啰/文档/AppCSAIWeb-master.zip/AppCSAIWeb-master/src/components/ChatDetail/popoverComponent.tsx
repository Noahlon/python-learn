import { Tooltip, Form, Row, Col, Input, Modal, Checkbox } from 'antd';
import React from 'react';
import { throttle, cloneDeep, isEmpty } from 'lodash';
import { EditOutlined } from '@ant-design/icons';
import styles from './index.less';
import './index.less';

interface ICorrectionInfo {
  asrIssues?: string; //ASR识别不准具体问题描述
  missingCorpus?: string; //缺少语料具体问题描述
  intentIssues?: string; //意图识别问题
  intentIssuesList?: number[]; //意图识别问题id IntentIssuesEnum枚举key
  otherDescription?: string; //其他问题描述
}

interface IFormListChild {
  itemCode: number;
  itemName: string;
}
interface IFormList {
  typeName?: string;
  childList?: IFormListChild[];
  value?: string;
}
interface Prop {
  item?: any;
  index?: number;
  currentData?: any;
  updateCurrentData?: (
    data: any,
    correctionInfo?: ICorrectionInfo,
    speakId?: string,
  ) => void;
  children?: JSX.Element;
  chatRef?: any;
  isErrorCorrection?: boolean;
  popoverPlacement?: any;
  formList: IFormList[];
}
const PopoverComponent: React.FC<Prop> = ({
  item, //数据
  index, //数组下标
  currentData, //当前选中的对象
  updateCurrentData, //修改当前对象方法
  children, //包裹的子组件
  chatRef, // 滚动容器的ref
  isErrorCorrection, //是否显示纠错
  formList = [],
}) => {
  const [form] = Form.useForm();
  //点击纠错按钮
  const clickTooltip = () => {
    form.resetFields();
    let formData = {};
    const checkedData = {};
    if (!isEmpty(item?.correctionInfo)) {
      for (const key in item?.correctionInfo) {
        if (item?.correctionInfo.hasOwnProperty(key)) {
          formData[key] = item?.correctionInfo[key];
          //只要key存在就认为已勾选
          checkedData[key] = true;
        }
      }
      delete checkedData.intentIssuesList;
      delete checkedData.otherDescription;
    }
    updateCurrentData({
      key: index,
      type: item.speaker,
      formData,
      speakId: item.speakId,
      correctionInfo: item?.correctionInfo || [],
      checkedData,
    });
  };

  //判断是否已纠错
  const hasCorrection = (correctionInfo = {}) => {
    if (isEmpty(correctionInfo)) {
      return false;
    }
    return true;
  };

  const handleLabelChecked = (e, code) => {
    const formData = cloneDeep(currentData?.formData);
    const checkedData = cloneDeep(currentData?.checkedData);
    //选中
    if (e.target.checked) {
      checkedData[code] = true;
    } else {
      //取消选中，清除对应的值
      delete checkedData[code];

      //如果是意图识别，需要清除意图和intentIssuesList
      if (code === 'intentIssues') {
        form.setFieldsValue({
          [code]: '',
          intentIssuesList: [],
        });
        formData[code] = '';
        formData.intentIssuesList = [];
      } else {
        form.setFieldsValue({
          [code]: '',
        });
        formData[code] = '';
      }
    }
    updateCurrentData({ ...currentData, formData, checkedData });
  };

  // 提交数据
  const onFinish = throttle((values) => {
    const data = {};
    Object.keys(values).forEach((key) => {
      //如果已勾选，或者是其他输入框有值，则更新入参
      if (currentData?.checkedData?.[key] || !!values[key]) {
        data[key] = values[key] || '';
      }
    });

    updateCurrentData?.({}, data, item.speakId);
  }, 2000);
  function cancel() {
    form.resetFields();
    updateCurrentData({});
  }
  return (
    <>
      {isErrorCorrection ? (
        <Tooltip
          getPopupContainer={(node) => chatRef?.current || node}
          zIndex={8}
          destroyTooltipOnHide={true}
          autoAdjustOverflow={false}
          placement={item.speaker === 1 ? 'topRight' : 'topLeft'}
          overlayClassName={styles['tooltipBox']}
          color={'#ffffff'}
          title={
            <div
              className={
                !isEmpty(item?.correctionInfo)
                  ? `${styles.butColor} ${styles.butActiveColor}`
                  : styles.butColor
              }
              onClick={() => {
                clickTooltip();
              }}
            >
              <EditOutlined className={styles.butIcon} />
              {hasCorrection(item?.correctionInfo) ? '已纠错' : '纠错'}
            </div>
          }
        >
          {children}
        </Tooltip>
      ) : (
        <>{children}</>
      )}
      {currentData?.key === index && (
        <Modal
          title="对话纠错"
          open={currentData?.key === index ? true : false}
          onOk={form.submit}
          onCancel={cancel}
          okText={'提交'}
        >
          <Form
            className={styles.formBox}
            form={form}
            layout="vertical"
            onFinish={onFinish}
          >
            {formList?.length > 0 &&
              formList.map((item) => {
                //意图识别问题
                if (['intentIssues'].includes(item.value)) {
                  return (
                    <Form.Item
                      label={
                        <Checkbox
                          checked={currentData?.checkedData?.[item.value]}
                          onChange={(e) => handleLabelChecked(e, item.value)}
                        >
                          {item.typeName}
                        </Checkbox>
                      }
                      className={
                        currentData?.checkedData?.[item.value]
                          ? 'show'
                          : 'hidden'
                      }
                    >
                      {!!currentData?.checkedData?.[item.value] && (
                        <>
                          <Form.Item
                            name="intentIssues"
                            initialValue={
                              currentData?.formData?.[item.value] || undefined
                            }
                          >
                            <Input
                              maxLength={50}
                              showCount
                              placeholder="请输入具体问题描述（最多50字）"
                              allowClear
                            />
                          </Form.Item>
                          <Form.Item
                            name="intentIssuesList"
                            initialValue={
                              currentData?.formData?.intentIssuesList || []
                            }
                          >
                            <Checkbox.Group>
                              <Row>
                                {item.childList?.map((item) => {
                                  return (
                                    <Col span={8} key={item.itemCode}>
                                      <Checkbox
                                        key={item.itemCode}
                                        value={item.itemCode}
                                      >
                                        {item.itemName}
                                      </Checkbox>
                                    </Col>
                                  );
                                })}
                              </Row>
                            </Checkbox.Group>
                          </Form.Item>
                        </>
                      )}
                    </Form.Item>
                  );
                }
                return (
                  <Form.Item
                    key={item.value}
                    label={
                      <Checkbox
                        checked={currentData?.checkedData?.[item.value]}
                        onChange={(e) => handleLabelChecked(e, item.value)}
                      >
                        {item.typeName}
                      </Checkbox>
                    }
                    name={item.value}
                    className={
                      currentData?.checkedData?.[item.value] ? 'show' : 'hidden'
                    }
                    initialValue={
                      currentData?.formData?.[item.value] || undefined
                    }
                    rules={[
                      () => ({
                        validator(_, value) {
                          const trimmedValue = (value && value.trim()) || '';
                          return trimmedValue && trimmedValue.length > 50
                            ? Promise.reject(new Error('最多输入50字'))
                            : Promise.resolve();
                        },
                      }),
                    ]}
                  >
                    {!!currentData?.checkedData?.[item.value] && (
                      <Input
                        maxLength={50}
                        showCount
                        placeholder="请输入具体问题描述（最多50字）"
                        allowClear
                      />
                    )}
                  </Form.Item>
                );
              })}
            <Form.Item
              name="otherDescription"
              initialValue={currentData?.formData?.otherDescription}
            >
              <Input.TextArea
                placeholder="请输入其他描述，最多50字"
                allowClear
                maxLength={50}
                showCount
              />
            </Form.Item>
          </Form>
        </Modal>
      )}
    </>
  );
};
export default React.memo(PopoverComponent);
