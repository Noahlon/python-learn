import type { ColumnsType } from 'antd/es/table';
import { IIntentDetectionInfoList } from '@/api/call';

export const formList = [
  {
    typeName: 'ASR识别不准',
    value: 'asrIssues',
  },
  {
    typeName: '缺少语料',
    value: 'missingCorpus',
  },
  {
    typeName: '意图识别问题',
    value: 'intentIssues',
    childList: [
      {
        itemCode: '1', //IntentIssuesEnum枚举key
        itemName: '缺少短语',
      },
      {
        itemCode: '2', //IntentIssuesEnum枚举key
        itemName: '短语添加有误',
      },
      {
        itemCode: '3', //IntentIssuesEnum枚举key
        itemName: '分词问题',
      },
      {
        itemCode: '4', //IntentIssuesEnum枚举key
        itemName: '多意图识别',
      },
      {
        itemCode: '5', //IntentIssuesEnum枚举key
        itemName: '缺少意图',
      },
    ],
  },
  // {
  //   typeName: '其他问题',
  //   value: 'otherDescription',
  // },
];

export const hitIntentColumns: ColumnsType<IIntentDetectionInfoList> = [
  {
    title: '序号',
    dataIndex: 'keySort',
    key: 'keySort',
    width: 80,
    fixed: 'left',
    render: (text, record, index) => {
      return index + 1;
    },
  },
  {
    title: '意图判断类型',
    dataIndex: 'intentDetectionTypeName',
    key: 'intentDetectionTypeName',
    width: 180,
    fixed: 'left',
  },
  {
    title: '命中意图集合',
    dataIndex: 'hitIntentSetName',
    key: 'hitIntentSetName',
  },
  {
    title: '命中意图',
    dataIndex: 'hitIntent',
    key: 'hitIntent',
  },
  {
    title: '意图属性',
    dataIndex: 'intentAttributesDesc',
    key: 'intentAttributesDesc',
  },
  {
    title: '命中信息',
    dataIndex: 'hitInfo',
    key: 'hitInfo',
  },
  {
    title: '是否命中语料',
    dataIndex: 'isMatchedCorpus',
    key: 'isMatchedCorpus',
    width: 140,
    render: (text) => {
      return text ? '是' : '否';
    },
  },
  {
    title: '语料名称',
    dataIndex: 'corpusName',
    key: 'corpusName',
  },
  {
    title: '语料配置优先级',
    dataIndex: 'corpusPriority',
    key: 'corpusPriority',
  },
  {
    title: '语料ID',
    dataIndex: 'corpusId',
    key: 'corpusId',
  },
  {
    title: '语料归属模块',
    dataIndex: 'corpusSourceName',
    key: 'corpusSourceName',
  },
  {
    title: '是否在可回复范围内配置',
    dataIndex: 'isInReplyScope',
    key: 'isInReplyScope',
    width: 190,
    render: (text) => {
      return text ? '是' : '否';
    },
  },
  {
    title: '是否有剩余播放次数',
    dataIndex: 'hasRemainingPlayCount',
    key: 'hasRemainingPlayCount',
    width: 160,
    render: (text) => {
      return text ? '是' : '否';
    },
  },
  {
    title: '是否回复语料',
    dataIndex: 'isReplyCorpus',
    key: 'isReplyCorpus',
    width: 140,
    render: (text) => {
      return text ? '是' : '否';
    },
  },
];
