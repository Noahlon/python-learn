import React, {
  useRef,
  useState,
  memo,
  forwardRef,
  useImperativeHandle,
} from 'react';
import { Form, Modal, Radio } from 'antd';
import AudioPlayer from 'react-h5-audio-player';
import 'react-h5-audio-player/lib/styles.css';
import { downloadCustomNameFile, httpReplace } from '@/utils';
import styles from './index.less';
import { useAccess } from '@umijs/max';

interface IProps {
  url?: string;
  visible: boolean;
  onOk?: () => void;
  cancel?: () => void;
  showDownLoad?: boolean;
  downloadPermission?: string;
}

const PlayAudio: React.FC<IProps> = forwardRef(
  (
    {
      visible,
      cancel,
      url,
      showDownLoad = true,
      downloadPermission = 'Call-Voice-Download',
    },
    ref,
  ) => {
    const access = useAccess();
    const audioRef = useRef<any>(null);
    const refWrap = useRef<any>(null);
    const [rate, setRate] = useState(1);
    const closeAudio = () => {
      audioRef.current.audio?.current?.pause();
    };
    const handlePlay = (e) => {
      e.target.playbackRate = rate;
    };

    useImperativeHandle(ref, () => ({
      reset: () => {
        if (audioRef?.current?.audio?.current)
          audioRef.current.audio.current.currentTime = 0;
      },
    }));

    const audioDownLoad = (url) => {
      try {
        const name = new Date().getTime().toString();
        let filename = url.split('?')[0];
        let parts = filename.split('.').pop();
        const filenames = name + '.' + parts;
        downloadCustomNameFile(url, filenames);
      } catch (error) {
        console.log(error);
      }
    };

    return (
      <>
        <Modal
          title={null}
          open={visible}
          width={'540px'}
          onCancel={() => cancel?.()}
          footer={null}
          style={{ top: 0 }}
          wrapClassName={styles.audioModal}
          mask={false}
          maskClosable={false}
          zIndex={1001}
          // getContainer={false}
          afterClose={() => {
            closeAudio();
          }}
        >
          <div ref={refWrap}>
            <AudioPlayer
              ref={audioRef}
              src={httpReplace(url)}
              autoPlay={true}
              autoPlayAfterSrcChange={false}
              onPlay={(e) => handlePlay(e)}
              progressJumpStep={12 * 1000}
              customAdditionalControls={[]}
            />
          </div>
          <Form.Item label="倍速" style={{ margin: '5px 0 0' }}>
            <Radio.Group
              value={rate}
              onChange={(e) => {
                setRate(e.target.value);
                const _audio = refWrap.current.querySelectorAll('audio');
                _audio[0].playbackRate = e.target.value;
              }}
            >
              <Radio value={0.5}>0.5</Radio>
              <Radio value={1}>1</Radio>
              <Radio value={1.5}>1.5</Radio>
              <Radio value={2}>2</Radio>
              <Radio value={2.5}>2.5</Radio>
            </Radio.Group>
            {access?.authCodeList?.includes(downloadPermission) &&
              showDownLoad && (
                <a href="#" onClick={() => audioDownLoad(url)}>
                  下载
                </a>
              )}
          </Form.Item>
        </Modal>
      </>
    );
  },
);

export default memo(PlayAudio);
