import React, { FC, useEffect, useState } from 'react';
import { useModel } from '@umijs/max';
import { EditOutlined } from '@ant-design/icons';
import type { DefaultOptionType } from 'antd/es/cascader';
import { Tag, Modal, Form, Cascader, message, Space, Button } from 'antd';
import {
  getIntentionOptsByIDs,
  IntentionOpt,
  updateCorpusBatch,
  getIntentionTextByIDs,
} from '@/api/intention';
import { parse } from 'query-string';

/* 
 新增 删除 标签控件
*/
interface NewTagsProps {
  currentKey?: string;
  tags?: any[];
  tagsIds?: any[];
  initData?: () => void;
}

const NewTags: FC<NewTagsProps> = ({ currentKey, tags, tagsIds, initData }) => {
  const [tagsText, setTagsText] = useState<object[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [intentionOpts, setIntentionOpts] = useState<IntentionOpt[]>([]);
  const [confirmLoading, setConfirmLoading] = useState<boolean>(false);
  const { setInIds } = useModel('global');
  const { speechInfo } = useModel('speech');
  const { SHOW_CHILD } = Cascader;
  const [form] = Form.useForm();
  const query: any = parse(location.search);

  const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };

  // 批量修改意图
  const batchChangeInent = async (ids: string[]) => {
    try {
      const res = await updateCorpusBatch({
        speechGuid: query?.speechGuid,
        corpusSource: Number(currentKey),
        intentionIds: ids,
        pageNum: 1,
        pageSize: 10,
      });
      if (res.success) {
        message.success('修改成功');
        initData();
      }
    } catch (error) {
      message.error(error);
    }
  };
  // 　通过id获取意图文字数组
  const getIntentionTextByIds = async (ids) => {
    if (ids?.length) {
      const res = await getIntentionTextByIDs({
        faqIds: ids,
      });
      if (res.success && res?.data?.length) {
        setTagsText(res.data);
      }
    } else {
      setTagsText([]);
    }
  };

  // 确认
  const handleOk = async () => {
    setConfirmLoading(true);
    let param = await form.validateFields();
    const ids = [];
    if (param.intentionIds?.length) {
      param.intentionIds.forEach((item) => {
        if (item?.length) ids.push(item[item.length - 1]);
      });
    }
    setInIds(param.intentionIds);
    batchChangeInent(ids);
    getIntentionTextByIds(ids);
    setConfirmLoading(false);
    setModalVisible(false);
  };

  // 获取意图级联
  const hangleIntentionOpt = async () => {
    const res = await getIntentionOptsByIDs({
      kcIds: speechInfo?.intentionCollections?.map(
        (item) => item.intentionCollectionId,
      ),
      bizId: speechInfo?.bizId,
    });
    if (res?.success && res?.data?.length)
      setIntentionOpts(res?.data?.filter((item) => !!item.list?.length));
  };

  // 级联搜索
  const filterCascader = (inputValue: string, path: DefaultOptionType[]) =>
    path.some(
      (option) =>
        (option.name as string)
          ?.toLowerCase()
          .indexOf(inputValue.toLowerCase()) > -1,
    );

  // 编辑
  const onEdit = async () => {
    const arr = [];
    if (!!tagsIds) {
      // 循环比较
      tagsIds.forEach((res) => {
        for (let i = 0; i < intentionOpts.length; i++) {
          intentionOpts[i].list.forEach((item: any) => {
            if (item.id === res) {
              arr.push([intentionOpts[i].id, item.id]);
            }
          });
        }
      });
    }
    // 表单赋值
    form.setFieldsValue({
      intentionIds: arr,
    });
    setModalVisible(true);
  };

  // 删除标签
  const handleClose = (id: string) => {
    if (speechInfo?.status === 1 || speechInfo?.status === 2) return;
    const newTags = tagsText.filter((item: any) => item.id !== id);
    let arr = newTags.map((res: any) => {
      return res.id;
    });
    batchChangeInent(arr);
  };

  useEffect(() => {
    hangleIntentionOpt();
  }, []);

  useEffect(() => {
    setTagsText(tags);
  }, [tags]);

  const viewFooter = () => {
    return (
      <Space>
        <Button
          onClick={() => {
            form.resetFields();
            setModalVisible(false);
          }}
        >
          取消
        </Button>
        <Button
          onClick={handleOk}
          disabled={speechInfo?.status === 1 || speechInfo?.status === 2}
        >
          确定
        </Button>
      </Space>
    );
  };

  return (
    <>
      {tagsText &&
        tagsText.map((tag: any) => {
          const tagElem = (
            <Tag
              className="edit-tag"
              key={tag.id}
              closable={!(speechInfo?.status === 1 || speechInfo?.status === 2)}
              onClose={() => handleClose(tag.id)}
            >
              <span>{tag.name}</span>
            </Tag>
          );
          return tagElem;
        })}
      <Tag className="site-tag-plus" onClick={onEdit}>
        <EditOutlined />
      </Tag>

      <Modal
        open={modalVisible}
        title={'请选择'}
        forceRender={true}
        footer={viewFooter()}
        maskClosable={false}
        width={'400px'}
        // onOk={handleOk}
        onCancel={() => {
          form.resetFields();
          setModalVisible(false);
        }}
        confirmLoading={confirmLoading}
        getContainer={false}
      >
        <Form form={form} {...layout}>
          <Form.Item label="触发意图" name="intentionIds">
            <Cascader
              options={intentionOpts}
              fieldNames={{ label: 'name', value: 'id', children: 'list' }}
              showCheckedStrategy={SHOW_CHILD}
              showSearch={{ filterCascader }}
              multiple
              allowClear
            />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};

export default NewTags;
