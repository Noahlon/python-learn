/* eslint-disable */
// @ts-nocheck
import React, { useContext, useEffect, useCallback } from 'react';
import { UNSAFE_NavigationContext as NavigationContext } from 'react-router-dom';

export function useBlocker(blocker, when = true) {
  const { navigator } = useContext(NavigationContext);

  useEffect(() => {
    if (!when) return;
    const unblock = navigator.block((tx) => {
      const autoUnblockingTx = {
        ...tx,
        retry() {
          unblock();
          tx.retry();
        },
      };
      blocker(autoUnblockingTx);
    });

    return unblock;
  }, [navigator, blocker, when]);
}

export const usePrompt = (message, when = true) => {
  const { navigator } = useContext(NavigationContext);

  const blocker = useCallback(
    (tx) => {
      if (typeof message === 'function') {
        let targetLocation = tx?.location?.pathname;
        if (targetLocation.startsWith(navigator.basename)) {
          targetLocation = targetLocation.substring(navigator.basename.length);
        }
        message(targetLocation).then(() => tx.retry());
      } else if (typeof message === 'string') {
        // // eslint-disable-next-line no-alert
        if (window.confirm(message)) {
          tx.retry();
        }
      }
    },
    [message, navigator.basename],
  );

  return useBlocker(blocker, when);
};
