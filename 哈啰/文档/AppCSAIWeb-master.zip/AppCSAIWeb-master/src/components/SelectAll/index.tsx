import React, { FC, useEffect, useState } from 'react';
import { Select } from 'antd';

const SelectAll: FC<any> = ({
  options,
  value,
  onChange,
  changeEvent,
  ...props
}) => {
  const [selected, setSelected] = useState<Array<string | number>>([]);
  const [allOpts, setAllOpts] = useState([]);

  const compareOpts = (val, opts) => {
    let _allOpts = [...opts];
    if (!val?.length) {
      _allOpts = opts.map((item) => {
        item.disabled = false;
        return item;
      });
    } else {
      const zIndex = val.findIndex((item) => item === 'all');
      _allOpts = opts.map((item) => {
        const _item = { ...item };
        if (
          (zIndex > -1 && _item.value !== 'all') ||
          (zIndex === -1 && _item.value === 'all')
        )
          _item.disabled = true;
        return _item;
      });
    }
    setAllOpts(_allOpts);
  };
  // 值改变
  const handleChange = (val) => {
    onChange?.(val);
    changeEvent?.();
    // const zIndex = val.findIndex((item) => item === 'all');
    // if (val?.[0] === 'all' && val.length > 1) {
    //   onChange?.(val.filter((item) => item !== 'all'));
    // } else if (
    //   (val[0] !== 'all' && zIndex > -1) ||
    //   (val[0] === 'all' && val.length === 1)
    // ) {
    //   onChange?.(['all']);
    // } else {
    //   onChange?.(val);
    // }
    // // if (zIndex > -1 && val.length > 1) {
    // //   onChange?.(val.filter(item => item === 'all'))
    // // } else {
    // //   onChange?.(val);
    // // }
  };

  useEffect(() => {
    setSelected(value);
    compareOpts(value, [{ label: '全部', value: 'all' }, ...options]);
  }, [value, options]);

  return (
    <>
      <Select
        value={selected}
        options={allOpts}
        onChange={handleChange}
        {...props}
      />
    </>
  );
};

export default SelectAll;
