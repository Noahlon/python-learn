// import { useDispatch, useStore } from 'umi';
import { uploadMusic } from '@/api/language';
import { message, Upload } from 'antd';
import { UploadChangeParam, UploadFile } from 'antd/es/upload';
import React, {
  FC,
  forwardRef,
  ReactNode,
  useImperativeHandle,
  useState,
} from 'react';
import { v1 as uuidv1 } from 'uuid';
import styles from './index.less';
const { Dragger } = Upload;

export interface Prop {
  uploadType?: string;
  sizeLimit?: number;
  showUploadList?: boolean;
  onChange?: (list?: UploadFile[]) => void;
  onBeforeUpload?: () => void;
  onFail?: (error?: any) => void;
  children?: ReactNode | string;
  maxCount?: number;
  fileNameFC?: (name: string) => void; // 获取文件名函数
  ref?: any;
}

const FileUploadShowList: FC<Prop> = forwardRef(
  (
    {
      uploadType = '',
      sizeLimit,
      onBeforeUpload,
      onChange,
      children = null,
      showUploadList = false,
      maxCount = 1,
      fileNameFC,
      ...props
    },
    ref,
  ) => {
    const [fileList, setFileList] = useState<UploadFile[]>([]);

    const beforeUpload = (file: {
      type: string;
      size: number;
      name: string;
    }) => {
      if (
        maxCount &&
        fileList.filter((item) => item.status === 'done').length === maxCount
      ) {
        message.error(`最大上传 ${maxCount} 个文件!`);
        return false;
      }
      if (sizeLimit) {
        const limit = file.size / 1024 / 1024 < sizeLimit;
        if (!limit) {
          message.error(`文件大小需小于 ${sizeLimit} MB!`);
          return !limit;
        }
      }
      // let suffix = ''
      // try {
      //   const fileArr = file?.name?.split('.');
      //   suffix = fileArr[fileArr.length - 1] || '';
      // } catch (error) {
      // }
      // if (uploadType && suffix && !uploadType.includes(suffix)) {
      //   message.error(`文件格式不符合`);
      //   return false;
      // }
      return true;
    };

    const handleUpload = async (Info) => {
      console.log('Info', Info);
      onBeforeUpload?.();
      const formData = new FormData();
      const file = Info.file;
      formData.append('file', file);
      // console.log(formData.get("file"));
      fileNameFC?.(file.name);
      let list: UploadFile[] = [];
      const uid: string = uuidv1();
      if (maxCount === 1) {
        list = [
          {
            uid,
            name: `${file.name}`,
            status: 'uploading',
            percent: 50,
          },
        ];
      } else {
        list = [
          ...fileList,
          {
            uid,
            name: `${file.name}`,
            status: 'uploading',
            percent: 50,
          },
        ];
      }
      setFileList(list);
      try {
        // const { success } = await uploadTaskDataFile(formData);
        // Info.onProgress({ percent: 50 })
        const res = (await uploadMusic(formData)) as any;
        const _list = JSON.parse(JSON.stringify(list));
        console.log(_list);
        const fileItem = _list.find((item) => item.uid === uid);
        if (fileItem) {
          fileItem.url = res?.url;
          fileItem.status = res?.url ? 'done' : 'error';
        }
        setFileList(_list);
        onChange?.(_list);
      } catch (e) {}
    };

    const handleChange = (info: UploadChangeParam<UploadFile>) => {
      if (info.file.status === 'uploading') {
        return;
      }
      if (info.file.status === 'error') {
        // message.error('上传失败');
      }
    };

    // 删除
    const handleDelete = (file) => {
      const list = JSON.parse(JSON.stringify(fileList));
      const zIndex = list.findIndex((item) => item.uid === file.uid);
      if (zIndex > -1) {
        list.splice(zIndex, 1);
        setFileList(list);
        onChange?.(list);
      }
    };

    // 清空
    const clearData = () => {
      setFileList([]);
      onChange?.([]);
    };

    useImperativeHandle(ref, () => ({
      clearData: clearData,
    }));

    return (
      <Dragger
        accept={uploadType}
        maxCount={maxCount}
        fileList={fileList}
        showUploadList={showUploadList}
        beforeUpload={beforeUpload}
        onChange={handleChange}
        customRequest={(info) => handleUpload(info)}
        className={styles.uploadFile}
        onRemove={handleDelete}
        progress={{
          strokeColor: {
            '0%': '#108ee9',
            '100%': '#87d068',
          },
          strokeWidth: 3,
          // format: percent => percent && `${parseFloat(percent.toFixed(2))}%`,
        }}
        {...props}
      >
        {children ? children : '上传文件'}
      </Dragger>
    );
  },
);

export default FileUploadShowList;
