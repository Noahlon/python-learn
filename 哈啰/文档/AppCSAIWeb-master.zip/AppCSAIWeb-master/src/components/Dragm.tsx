import React, { useEffect, useState } from 'react';
import DragM from 'dragm';

export const ModalDrag = ({ children }) => {
  const [modalDom, setModalDom] = useState(null);

  const updateTransform = (transformStr) => {
    modalDom.style.transform = transformStr;
  };

  useEffect(() => {
    const ele = document.querySelector('.custom-draggable-modal');
    setModalDom(ele);
    // console.log('modalDom.current', modalDom.current)
  }, []);

  return (
    <DragM updateTransform={updateTransform}>
      <div>{children}</div>
    </DragM>
  );
};
