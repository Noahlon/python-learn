import React, { useEffect } from 'react';
import { Chart } from '@antv/g2';
import { accMul } from '@/utils';

let chart: any;
interface PropsType {
  data: {
    item: string;
    count: number;
    percent: number;
  }[];
}

const BarChart: React.FC<PropsType> = ({ data }) => {
  useEffect(() => {
    chart = new Chart({
      container: 'container',
      autoFit: true,
      height: 380,
    });
  }, []);

  useEffect(() => {
    chart.clear(); // 清除画布
    // 最大值*1.23，设置最大长度
    let max = data[0].count;
    data.forEach((it) => {
      max = it.count > max ? it.count : max;
    });
    max *= 1.3;
    const newData = data.reverse();
    chart.axis('count', false);
    chart.data(newData);
    chart.scale({ count: { min: 0, max } }, { nice: true });
    chart.coordinate().transpose();
    chart.tooltip({
      showMarkers: false,
      showTitle: false,
      // 修改tooltip的key值
      customItems: (item) => {
        // console.log('tooltip', item)
        const arr = {
          ...item[0],
          name: item[0].title,
          value: Number(item[0].value).toLocaleString(),
        };
        return [arr];
      },
    });
    chart.interaction('active-region');
    chart
      .interval()
      .position('item*count')
      // 设置文字
      .label('count', (count) => {
        const content = () => {
          const item = newData.find((it) => it.count === count);

          return `${accMul(
            item?.percent || 0,
            100,
          )}%\xa0\xa0\xa0 ${count.toLocaleString()}`;
        };

        return {
          content,
          offset: 10,
          style: {
            fill: '#999',
          },
        };
      })
      .size(30)
      .animate(false);
    chart.render();
  }, [data]);
  return (
    <>
      <div
        id="container"
        style={{ width: '600px', height: '350px', marginTop: '30px' }}
      ></div>
    </>
  );
};
export default BarChart;
