import React from 'react';
import styles from './index.less';

interface Prop {
  curSms: {
    signature?: string;
    content?: string;
  };
}

const SmsSimplePreview: React.FC<Prop> = ({ curSms }) => {
  return (
    <div className={styles.smsCotent}>
      <div className={styles.smsKey}>签名</div>
      <div className={styles.smsValue}>{curSms?.signature}</div>

      <div className={styles.smsKey}>短信内容</div>
      <div className={styles.smsValue}>{curSms?.content}</div>
    </div>
  );
};

export default SmsSimplePreview;
