import { AllSkillGroupObj } from '@/api/accountPermission/skillGroup';
import {
  Button,
  InputNumber,
  Popconfirm,
  Select,
  Table,
  Typography,
  Tooltip,
  Switch,
} from 'antd';
import { ColumnsType } from 'antd/es/table';
import React, { useEffect, useMemo, useState } from 'react';
import { v1 as uuidv1 } from 'uuid';
import styles from './index.less';

type TableData = AllSkillGroupObj & { rosterCount: number };

interface Prop {
  curTaskType?: number;
  skillGroupOpts: AllSkillGroupObj[];
  defaultList?: TableData[];
  showRoster?: boolean;
  waitRosterWithOutTaskCount?: number;
  onChange?: (res: TableData[]) => void;
}

const SkillGroupForm: React.FC<Prop> = ({
  curTaskType,
  skillGroupOpts,
  defaultList,
  showRoster,
  waitRosterWithOutTaskCount,
  onChange,
}) => {
  const [tableData, setTableData] = useState<TableData[]>([]);

  // 可添加的列表
  const showSeatList = useMemo(() => {
    const arr = skillGroupOpts?.filter((item) => {
      const isContain = tableData.some(
        (it) => it.skillGroupGuid === item.skillGroupGuid,
      );
      return !isContain && item.seatCount !== 0;
    });

    return arr;
  }, [skillGroupOpts, tableData]);

  // 分发名单
  const distributionRoster = (tableArr) => {
    const arr = JSON.parse(JSON.stringify(tableArr));
    if (showRoster && arr?.length > 0) {
      // 座席数量
      const totalSeatCount = arr?.reduce((total, cur) => {
        return total + cur?.seatCount;
      }, 0);
      // (技能组下座席数量/全部已选技能组座席数量和）* 可下发名单数
      arr.forEach((item) => {
        item.rosterCount = Math.floor(
          (item?.seatCount / totalSeatCount) * waitRosterWithOutTaskCount || 0,
        );
      });
      const _totalCount = arr?.reduce((total, cur) => {
        return total + cur?.rosterCount;
      }, 0);

      // 余数名单添加到第一个技能组里面
      if (_totalCount < waitRosterWithOutTaskCount) {
        arr[0].rosterCount += waitRosterWithOutTaskCount - _totalCount;
      }
      setTableData(arr);
      onChange?.(arr);
    } else {
      setTableData([]);
      onChange?.([]);
    }
  };

  // 添加
  const handleAdd = (guidArr: string[]) => {
    const curSkillGroup = skillGroupOpts?.find(
      (item) => item.skillGroupGuid === guidArr[0],
    );
    const arr = [curSkillGroup, ...tableData];

    if (showRoster) {
      distributionRoster(arr);
    } else {
      setTableData(arr as TableData[]);
      onChange?.(arr as TableData[]);
    }
  };

  // 删除
  const handleDelete = async (record: TableData) => {
    const tableArr = tableData.filter(
      (item) => item?.skillGroupGuid !== record?.skillGroupGuid,
    );

    if (showRoster) {
      distributionRoster(tableArr);
    } else {
      setTableData(tableArr);
      onChange?.(tableArr);
    }
  };
  // 选择呼损名单分配人
  const handleAllocationStatusChange = (guid: string) => {
    const arr = JSON.parse(JSON.stringify(tableData));
    arr.forEach((item) => {
      if (item?.skillGroupGuid === guid) {
        item.callLossDistribute = !item.callLossDistribute;
      } else {
        item.callLossDistribute = false;
      }
    });
    setTableData(arr);
    onChange?.(arr);
  };

  const columns: ColumnsType<TableData> = [
    {
      title: '技能组',
      dataIndex: 'skillGroupName',
    },
    {
      title: '组长',
      dataIndex: 'groupLeaderName',
    },
    {
      title: '座席数',
      dataIndex: 'seatCount',
      width: 80,
    },
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 80,
      render: (_, record) => (
        <Popconfirm
          title="确认要删除吗？"
          onConfirm={() => handleDelete(record)}
          placement="topRight"
        >
          <Button type="link">删除</Button>
        </Popconfirm>
      ),
    },
  ];

  const handleInputChange = (e: number, guid: string) => {
    const arr = JSON.parse(JSON.stringify(tableData));
    arr.forEach((item) => {
      if (item?.skillGroupGuid === guid) {
        item.rosterCount = e;
      }
    });
    onChange?.(arr);
    setTableData(arr);
  };

  const tableColumns: ColumnsType<TableData> = useMemo(() => {
    if (showRoster) {
      columns.splice(3, 0, {
        title: '名单数',
        dataIndex: 'rosterCount',
        width: 130,
        render: (text, record) => {
          return (
            <InputNumber
              min={0}
              precision={0}
              value={text}
              controls={false}
              onChange={(e) => handleInputChange(e, record.skillGroupGuid)}
            />
          );
        },
      });
    }
    if (curTaskType === 3) {
      columns.splice(3, 0, {
        title: (
          <div className={styles.td}>
            呼损名单分配人
            <Tooltip
              placement="top"
              title={'开启后呼损名单将自动下发给对应组长'}
            >
              <span className={styles.tips}>?</span>
            </Tooltip>
          </div>
        ),
        dataIndex: 'callLossDistribute',
        width: 140,
        render: (_, record) => (
          <Switch
            onChange={() => handleAllocationStatusChange(record.skillGroupGuid)}
            checked={record.callLossDistribute}
          />
        ),
      });
    }
    return columns;
  }, [showRoster, tableData]);

  const rosterTotal = useMemo(() => {
    const _total = tableData?.reduce((total, item) => {
      return total + (item?.rosterCount || 0);
    }, 0);
    return _total;
  }, [tableData]);

  useEffect(() => {
    if (defaultList) {
      const needRosterCount = defaultList?.every((item) => !item.rosterCount);
      if (showRoster && needRosterCount) {
        return distributionRoster(defaultList);
      }
      setTableData(defaultList);
    } else {
      setTableData([]);
    }
  }, [defaultList]);

  return (
    <>
      <Select
        placeholder="添加技能组到下面表格"
        showSearch
        allowClear
        mode="multiple"
        value={[]}
        optionFilterProp="skillGroupName"
        fieldNames={{ label: 'skillGroupName', value: 'skillGroupGuid' }}
        options={showSeatList}
        onChange={handleAdd}
        style={{ width: '100%', marginBottom: 24 }}
        notFoundContent={<div style={{ textAlign: 'center' }}>暂无数据</div>}
      />
      {tableData?.length > 0 && (
        <Table
          columns={tableColumns}
          dataSource={tableData}
          scroll={{ x: 'max-content', y: 300 }}
          rowKey="skillGroupGuid"
          size="small"
          pagination={{
            pageSize: 50,
            showQuickJumper: false,
            showSizeChanger: false,
            showTotal: (total: number) => `总共 ${total} 组`,
          }}
          summary={(res) =>
            showRoster ? (
              <Table.Summary fixed>
                <Table.Summary.Row>
                  <Table.Summary.Cell key={uuidv1()} index={0}>
                    总计：
                  </Table.Summary.Cell>
                  <Table.Summary.Cell key={uuidv1()} index={1} />
                  <Table.Summary.Cell key={uuidv1()} index={2}>
                    {res?.reduce((total, cur) => {
                      return total + cur?.seatCount;
                    }, 0)}
                  </Table.Summary.Cell>
                  <Table.Summary.Cell key={uuidv1()} index={3}>
                    {rosterTotal > waitRosterWithOutTaskCount ? (
                      <Typography.Text type="danger">
                        {rosterTotal}
                      </Typography.Text>
                    ) : (
                      rosterTotal
                    )}
                  </Table.Summary.Cell>
                  <Table.Summary.Cell key={uuidv1()} index={4} />
                </Table.Summary.Row>
              </Table.Summary>
            ) : null
          }
        />
      )}
      {showRoster && rosterTotal > waitRosterWithOutTaskCount && (
        <Typography.Text type="danger" style={{ float: 'right' }}>
          下发名单总数不允许大于可下发名单数
        </Typography.Text>
      )}
    </>
  );
};

export default SkillGroupForm;
