import React, { FC, useEffect, useState } from 'react';
import '@wangeditor/editor/dist/css/style.css';
import { Editor, Toolbar } from '@wangeditor/editor-for-react';
import { IDomEditor, IEditorConfig, IToolbarConfig } from '@wangeditor/editor';
import { uploadFile } from '@/api/language';
import { Button } from 'antd';
import { debounce } from 'lodash';
import styles from './index.less';

type InsertFnType = (url: string, alt: string, href: string) => void;

interface IProps {
  value: string;
  save?: (html: string) => void;
  showBtn?: boolean;
}

/**
 * 富文本网址
 * https://www.wangeditor.com/
 */

const RichText: FC<IProps> = (props) => {
  const { value, showBtn = false, save } = props;
  // eslint-disable-next-line
  const [editor, setEditor] = useState<IDomEditor | null>(null);
  // 编辑器内容
  const [html, setHtml] = useState('');

  const toolbarConfig: Partial<IToolbarConfig> = {};

  const editorConfig: Partial<IEditorConfig> = {
    placeholder: '请输入内容...',
    MENU_CONF: {},
  };

  editorConfig.MENU_CONF['uploadImage'] = {
    // 自定义上传
    async customUpload(file: File, insertFn: InsertFnType) {
      // file 即选中的文件
      // 自己实现上传，并得到图片 url
      // 最后插入图片
      const formData = new FormData();
      formData.append('file', file);
      const res: any = await uploadFile(formData);
      const { url } = res;
      if (url) {
        insertFn(url, file.name, '');
      }
    },
  };

  toolbarConfig.excludeKeys = [
    'headerSelect',
    'italic',
    'group-more-style', // 排除菜单组，写菜单组 key 的值即可
    'group-video',
  ];

  const saveHandle = debounce(async () => {
    save?.(html);
  }, 50);

  const cancelHandle = () => {
    setHtml(value);
  };

  useEffect(() => {
    setHtml(value);
  }, [value]);

  // 及时销毁 editor ，重要！
  useEffect(() => {
    return () => {
      if (editor === null) return;
      editor.destroy();
      setEditor(null);
    };
  }, [editor]);

  return (
    <>
      <div className={styles.richText}>
        <Toolbar
          editor={editor}
          defaultConfig={toolbarConfig}
          mode="default"
          className={styles.toolbar}
        />
        <Editor
          defaultConfig={editorConfig}
          value={html}
          onCreated={setEditor}
          onChange={(editor) => setHtml(editor.getHtml())}
          mode="default"
          className={styles.editor}
        />
      </div>
      {showBtn && (
        <div className={styles.btn}>
          <Button
            onClick={saveHandle}
            className={styles.btnSave}
            type="primary"
          >
            保存
          </Button>
          <Button onClick={cancelHandle} className={styles.btnCancel}>
            取消
          </Button>
        </div>
      )}
    </>
  );
};

export default RichText;
