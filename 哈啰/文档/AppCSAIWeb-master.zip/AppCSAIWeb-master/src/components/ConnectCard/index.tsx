import React from 'react';
import styles from './index.less';
import { Tooltip } from 'antd';
import { InfoCircleOutlined } from '@ant-design/icons';

interface PropsType {
  title: string;
  percentage: string | number;
  txt1: string;
  txt2: string;
  num1: number | string;
  num2: number | string;
  tooltip: string;
}

const ConnectCard: React.FC<PropsType> = ({
  title,
  percentage = '0',
  txt1,
  txt2,
  num1 = '-',
  num2 = '-',
  tooltip,
}) => {
  return (
    <div className={styles.connectcard}>
      <div className={styles.top}>
        <h4>
          {title}
          <Tooltip title={tooltip}>
            <span>
              <InfoCircleOutlined />
            </span>
          </Tooltip>
        </h4>
        <h2>{percentage}%</h2>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <p>{txt1}</p>
        <p>{num1?.toLocaleString()}</p>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <p>{txt2}</p>
        <p>{num2?.toLocaleString()}</p>
      </div>
    </div>
  );
};

export default ConnectCard;
