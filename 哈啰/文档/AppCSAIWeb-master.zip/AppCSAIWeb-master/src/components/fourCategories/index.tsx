/* eslint-disable no-shadow */
/* eslint-disable react/display-name */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useState,
  useMemo,
} from 'react';
import { Cascader } from 'antd';
import { getClassifyTree } from '@/api/business';

// 将递归的树结构展开为数组

// 给每个children 加个层数
const calculateLevel = (arr: any, initLevel: any) => {
  arr.forEach((element: { level: any; children: any }) => {
    element.level = initLevel;
    if (element.children) {
      calculateLevel(element.children, initLevel + 1);
    }
  });
  return arr;
};

// 限制展示3层
const limitLevel = (tree: any, level: number) => {
  if (!tree) return;
  for (const node of tree) {
    if (level === 1) {
      delete node.children;
    } else {
      limitLevel(node.children, level - 1);
    }
  }
  return tree;
};
interface IProps {
  onChange: any;
  [propsName: string]: any;
}
const FourCategories: React.FC<IProps> = forwardRef((props, ref) => {
  const { businessType, value, onChange, modalType } = props as any;
  const [options, setOptions] = useState<any[]>([]);

  function onValueChange(value: any, data: any) {
    const level3ParentGuid = data && data!.length === 3 ? data[2]!.guid : '';
    console.log(level3ParentGuid.length);
    if (onChange) onChange(value, level3ParentGuid);
  }
  const getOptions = async () => {
    const res = (await getClassifyTree()) as any;
    const type = Number(businessType);
    const filteredRes = !Number.isNaN(type)
      ? res?.data?.filter(
          (item: { businessType: number }) => item.businessType === type,
        )
      : undefined;
    const result = filteredRes || res?.data;
    const list = calculateLevel(result, 1);
    const level3List = limitLevel(list, 3);
    setOptions(level3List);
  };

  useEffect(() => {
    getOptions();
  }, []);

  return (
    <div>
      <Cascader
        value={value}
        options={options}
        disabled={modalType === 1 ? true : false}
        onChange={onValueChange}
        changeOnSelect
        fieldNames={{ label: 'classifyName', value: 'classifyId' }}
        getPopupContainer={(triggerNode) =>
          triggerNode.parentElement || document.body
        }
      />
    </div>
  );
});

export default FourCategories;
// const [fourValue, setFourValue] = useState<string[]>([]);
// 父组件引用  <FourCategories changeFourValue={setFourValue}/>
