import React, { useEffect } from 'react';
import { Chart } from '@antv/g2';
import { accMul } from '@/utils';
interface PropsType {
  container: string;
  data: {
    item: string;
    count: number;
    percent: number;
  }[];
  title: string;
  total: number;
  height: number;
  ringStyle?: {
    radius: number;
    innerRadius: number;
  };
}
let chart: any;

const RingChart: React.FC<PropsType> = ({
  container,
  data,
  title,
  total,
  height,
  ringStyle,
}) => {
  useEffect(() => {
    chart = new Chart({
      container,
      autoFit: true,
      height,
    });
  }, []);

  useEffect(() => {
    chart.clear(); // 清除画布
    chart.data(data);
    // %
    // chart.scale('percent', {
    //   formatter: (val) => val
    // });
    // 内外径
    chart.coordinate('theta', {
      radius: ringStyle?.radius || 0.65,
      innerRadius: ringStyle?.innerRadius || 0.62,
    });
    // 辅助文本
    chart
      .annotation()
      .text({
        position: ['50%', '50%'],
        content: title,
        style: {
          fontSize: 16,
          fill: '#8c8c8c',
          textAlign: 'center',
        },
        offsetY: -20,
      })
      .text({
        position: ['50%', '50%'],
        content: total?.toLocaleString(),
        style: {
          fontSize: 22,
          fill: '#000',
          textAlign: 'center',
        },
        offsetY: 20,
      })
      .text({
        position: ['50%', '50%'],
        style: {
          fontSize: 14,
          fill: '#8c8c8c',
          textAlign: 'center',
        },
        offsetY: 20,
        offsetX: 20,
      });
    // 右侧图例
    chart.legend({
      position: 'right',
      // layout: 'vertical',
      // maxRow: 2,//当图例项过多分页时，可以设置最大行数（仅适用于 layout: 'horizontal'），默认为：1。
      // // itemSpacing:10,//控制图例项水平方向的间距。
      // marker:{//图例项的 marker 图标配置
      //     symbol:'square'
      // },
      slidable: true,
      flipPage: true,
      // itemWidth: 260,
      maxItemWidth: '40%',
      maxWidthRatio: 1,
      // offsetX: -20,
      itemName: {
        formatter: (text, _, index) => {
          let precent = '0';
          if (data[index].percent) {
            precent = accMul(data[index].percent, 100).toFixed(2);
          }
          return `${text}\xa0\xa0 ${precent}%\xa0\xa0 ${data[
            index
          ].count.toLocaleString()}`;
        },
      },
    });
    // 关闭tooltip的title
    chart.tooltip({ showTitle: false });
    chart
      .interval()
      .animate(false)
      .adjust('stack')
      .position('percent')
      .color('item')
      .tooltip('item*percent', (item, percent) => {
        // percent = percent * 100 + '%';
        return {
          name: item,
          value: (percent * 100).toFixed(2) + '%',
        };
      });

    chart.interaction('element-active');

    chart.render();
  }, [data, total, container, title]);

  return (
    <>
      <div id={container}></div>
    </>
  );
};
export default RingChart;
