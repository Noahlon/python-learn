import React, { useCallback, useRef, useState } from 'react';
import {
  LogoutOutlined,
  SyncOutlined,
  UploadOutlined,
  UserOutlined,
} from '@ant-design/icons';
import {
  Button,
  Col,
  Dropdown,
  Form,
  message,
  Modal,
  Radio,
  Row,
  Upload,
} from 'antd';
import { ProBreadcrumb } from '@ant-design/pro-components';
import { useModel } from '@umijs/max';
import styles from './style.less';
import { LAYOUTWRAPFIVE } from '@/constants/processconfig';
import { uploadMusic } from '@/api/language';
import {
  onlineTranslation,
  translationLanguage,
  uploadTranslation,
} from '@/api/speech';
import { httpReplace } from '@/utils';
import { debounce } from 'lodash';

const HeaderRight: React.FC = () => {
  const checkTimerRef = useRef(null);
  const { userInfo, signOut } = useModel('global');
  const [uploadLoading, setUploadLoading] = useState(false);
  const [downLoadLoading, setDownLoadLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [fileList, setFileList] = useState([]);
  const [process, setProcess] = useState(0); // 0: 未上传 1:创建 2: 执行 3:完成 4: 失败
  const [url, setUrl] = useState('');
  const [type, setType] = useState(null);
  const [languageOpts, setLanguageOpts] = useState([]);

  const onMenuClick = useCallback(
    (event: {
      key: string;
      keyPath: string[];
      item: React.ReactInstance;
      domEvent:
        | React.MouseEvent<HTMLElement>
        | React.KeyboardEvent<HTMLElement>;
    }) => {
      const { key } = event;

      if (key === 'logout') {
        signOut();
      }
    },
    [],
  );

  // 销毁定时任务
  const finishTimeTask = () => {
    if (checkTimerRef?.current) clearInterval(checkTimerRef.current);
    checkTimerRef.current = null;
  };

  // 取消弹框
  const handleCancel = useCallback(() => {
    setUploadLoading(false);
    setDownLoadLoading(false);
    setProcess(0);
    setFileList([]);
    setUrl('');
    finishTimeTask();
    setType(languageOpts?.[0]?.translateLanguageType);
    setOpen(false);
  }, [languageOpts]);

  // 获取语言类型
  const handleTranslationLanguage = useCallback(async () => {
    const res = await translationLanguage();
    setLanguageOpts(res.data || []);
    setType(res.data?.[0].translateLanguageType);
  }, []);

  // 打开弹框
  const handleTranslate = useCallback(() => {
    handleTranslationLanguage();
    setOpen(true);
  }, []);

  // 获取转译状态
  const handleTranslation = useCallback(async (guid) => {
    setProcess(2);
    const res = (await uploadTranslation({ guid })) as any;
    if (!res.success) finishTimeTask();
    if (res.success && !!res?.data?.fileUrl && res?.data?.status === 3) {
      finishTimeTask();
      setUrl(res?.data?.fileUrl);
    }
    setProcess(res?.data?.status);
  }, []);

  // 上传文件
  const customRequest = async ({ file }: any) => {
    if (!type) return message.warning('请先选择语言');
    setProcess(0);
    setUrl('');
    finishTimeTask();
    setUploadLoading(true);
    const formData = new FormData();
    formData.append('file', file);
    const dest = message.loading('正在上传文件');
    setFileList([
      {
        uid: '-1',
        name: file.name,
        status: 'uploading',
      },
    ]);
    try {
      const res = (await uploadMusic(formData)) as any;
      const resp = (await onlineTranslation({
        fileName: file.name,
        fileUrl: res?.url,
        translateLanguageType: type,
      })) as any;
      if (!!resp?.data?.guid) {
        setFileList([
          {
            uid: '-1',
            name: file.name,
            status: 'done',
            url: res?.url,
          },
        ]);
        handleTranslation(resp.data.guid);
        checkTimerRef.current = setInterval(async () => {
          handleTranslation(resp.data.guid);
        }, 1000);
      } else {
        setFileList([
          {
            uid: '-5',
            name: file.name,
            status: 'error',
          },
        ]);
      }
    } catch (e) {
      // 上传失败
      setFileList([
        {
          uid: '-5',
          name: file.name,
          status: 'error',
        },
      ]);
    }
    setUploadLoading(false);
    dest?.();
  };

  // 下载文件
  const handleDownLoad = debounce(async () => {
    if (!url) return;
    let elink = document.createElement('a');
    elink.style.display = 'none';
    let newUrl = httpReplace(url);
    elink.href = newUrl;
    // elink.download = '';
    document.body.appendChild(elink);
    elink.click();
    setTimeout(() => {
      document.body.removeChild(elink);
    }, 300);
  }, 300);

  return (
    <div className={styles.header}>
      <ProBreadcrumb />
      <div className={styles.right}>
        <div className={styles.translateWrap} onClick={handleTranslate}>
          <svg className={styles.translateIcon} aria-hidden="true">
            <use xlinkHref="#icon-translate"></use>
          </svg>
          翻译工具
        </div>
        <Dropdown
          // overlay={menuHeaderDropdown}
          menu={{
            items: [
              {
                label: '登出',
                key: 'logout',
                icon: <LogoutOutlined />,
              },
            ],
            onClick: onMenuClick,
          }}
        >
          <span className={`${styles.action} ${styles.account}`}>
            <UserOutlined style={{ marginRight: 6 }} />
            <span className={`${styles.name} anticon`}>
              {userInfo?.realName}
            </span>
          </span>
        </Dropdown>
      </div>

      <Modal
        open={open}
        title="转译工具"
        forceRender
        width="540px"
        onCancel={handleCancel}
        footer={null}
        confirmLoading={uploadLoading}
        getContainer={false}
      >
        <Form {...LAYOUTWRAPFIVE}>
          <Form.Item
            label="语言选择"
            labelCol={{ offset: 3, span: 4 }}
            wrapperCol={{ offset: 0 }}
          >
            <Radio.Group
              options={languageOpts?.map((item) => ({
                label: item.translateLanguageName,
                value: item.translateLanguageType,
              }))}
              optionType="button"
              onChange={({ target: { value } }) => setType(value)}
              value={type}
            />
          </Form.Item>
          <Form.Item
            label="文件"
            labelCol={{ offset: 3, span: 4 }}
            wrapperCol={{ offset: 0 }}
          >
            <Row>
              <Col>
                <Upload
                  maxCount={1}
                  fileList={fileList}
                  accept=".xls,.xlsx"
                  customRequest={(item) => customRequest(item)}
                  disabled={uploadLoading}
                  onRemove={() => setFileList([])}
                >
                  <Button
                    disabled={uploadLoading}
                    icon={<UploadOutlined style={{ color: '#c0c0c0' }} />}
                  >
                    上传文件
                  </Button>
                </Upload>
              </Col>
            </Row>
            <Button
              type="link"
              style={{ position: 'absolute', left: '120px', top: 0 }}
              href="https://m.hellobike.com/resource/helloyun/wb15144/%E7%BF%BB%E8%AF%91%E5%B0%8F%E5%B7%A5%E5%85%B7%E6%A8%A1%E7%89%88.xlsx"
            >
              下载模版
            </Button>
          </Form.Item>
          {!!process && (
            <Form.Item
              label=""
              labelCol={{ span: 0 }}
              wrapperCol={{ span: 17, offset: 7 }}
            >
              {process === 2 ? (
                <>
                  <SyncOutlined
                    spin
                    style={{ marginRight: '5px', color: '#f2820a' }}
                  />
                  转译中...
                </>
              ) : process === 3 ? (
                '转译成功'
              ) : process === 4 ? (
                '转译失败'
              ) : null}
            </Form.Item>
          )}
          {!!url && (
            <Form.Item
              label=""
              labelCol={{ span: 0 }}
              wrapperCol={{ span: 17, offset: 7 }}
            >
              <Button
                disabled={downLoadLoading}
                icon={
                  <UploadOutlined
                    style={{ transform: 'rotate(180deg)', color: '#c0c0c0' }}
                  />
                }
                onClick={handleDownLoad}
              >
                下载结果
              </Button>
            </Form.Item>
          )}
        </Form>
      </Modal>
    </div>
  );
};

export default HeaderRight;
