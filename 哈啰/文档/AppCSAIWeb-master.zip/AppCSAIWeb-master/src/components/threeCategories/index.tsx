/* eslint-disable no-shadow */
/* eslint-disable react/display-name */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useState,
  useMemo,
} from 'react';
import { parse } from 'query-string';
import { Cascader } from 'antd';
import { getClassifyTree } from '@/api/business';

// 将递归的树结构展开为数组

// 给每个children 加个层数
const calculateLevel = (arr: any, initLevel: any) => {
  arr.forEach((element: { level: any; children: any }) => {
    element.level = initLevel;
    if (element.children) {
      calculateLevel(element.children, initLevel + 1);
    }
  });
  return arr;
};

// 限制展示3层
const limitLevel = (tree: any, level: number) => {
  if (!tree) return;
  for (const node of tree) {
    if (level === 1) {
      delete node.children;
    } else {
      limitLevel(node.children, level - 1);
    }
  }
  return tree;
};
interface IProps {
  speechName: string;
  classifyId: string;
  modalType: string;
  [propsName: string]: any;
}
let ccc = [] as string[];
// 根据子id找父id,返回值不包含查找的id
const findParentsId = (treeData: string | any[], id: string) => {
  if (treeData.length === 0) return;
  for (let i = 0; i < treeData.length; i++) {
    if (treeData[i].classifyId === id) {
      console.log(treeData[i].guid);
      ccc = [treeData[i].guid];
      return [];
    } else {
      if (treeData[i].children) {
        let res = findParentsId(treeData[i].children, id) as any;
        if (res !== undefined) {
          return res.concat(treeData[i].guid);
        }
      }
    }
  }
};
const orgChildIdFindParent = (childId: string, orgList: any) => {
  const result = findParentsId(orgList, childId);
  return result || [];
};
const ThreeCategories: React.FC<IProps> = forwardRef((props, ref) => {
  const { businessType, value, onChange, modalType, speechName, classifyId } =
    props as any;
  const [options, setOptions] = useState<any[]>([]);

  function onValueChange(value: any) {
    if (onChange) onChange(value);
  }
  const getOptions = async () => {
    const query = parse(location.search) as any;
    const res = (await getClassifyTree()) as any;
    const type = Number(classifyId);
    const filteredRes = !Number.isNaN(type)
      ? res?.data?.filter(
          (item: { classifyId: number }) => +item.classifyId === type,
        )
      : undefined;
    const result = filteredRes || res?.data;
    const list = calculateLevel(result, 1);
    const level3List = limitLevel(list, 3);
    let _arryDt = orgChildIdFindParent(query.lastGuId, level3List);
    onValueChange(_arryDt.reverse().concat(ccc));
    setOptions(level3List);
  };

  const displayRender = (labels: any, selectedOptions: any[]) =>
    labels.map((label: any, i: number) => {
      const option = selectedOptions[i];
      if (i === labels.length - 1) {
        return (
          <span key={i}>
            {label} / <span>{speechName}</span>
          </span>
        );
      }
      return <span key={i}>{label} / </span>;
    });

  useEffect(() => {
    getOptions();
  }, []);

  return (
    <div>
      <Cascader
        value={value}
        options={options}
        disabled={true}
        onChange={onValueChange}
        displayRender={displayRender as any}
        changeOnSelect
        fieldNames={{ label: 'classifyName', value: 'guid' }}
        getPopupContainer={(triggerNode) =>
          triggerNode.parentElement || document.body
        }
      />
    </div>
  );
});

export default ThreeCategories;
// const [fourValue, setFourValue] = useState<string[]>([]);
// 父组件引用  <FourCategories changeFourValue={setFourValue}/>
