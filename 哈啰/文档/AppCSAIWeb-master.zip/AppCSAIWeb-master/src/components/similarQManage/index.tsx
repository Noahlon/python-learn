import React, { useState, useEffect } from 'react';
import {
  Modal,
  Button,
  Input,
  Table,
  Popconfirm,
  Tooltip,
  message,
} from 'antd';
import {
  getExtendFaqList,
  IExtendFaq,
  createExtendFaq,
  similarExtendFaqResDTO,
  deleteExtendFaq,
} from '@/api/extendFaq';
import style from './style.less';
import { ModalDrag } from '../Dragm';
// import DraggableModal from '../Draggable';

interface IProps {
  standardFaqGuid: string;
  similarVisible: boolean;
  onChange: any;
  [propsName: string]: any;
}
const SimilarQManage: React.FC<IProps> = ({
  standardFaqGuid,
  similarVisible,
  onChange,
}) => {
  const [visible, setVisible] = useState(false);
  const [confirmVisible, setConfirmVisible] = useState(false);
  const [questionText, setQuestionText] = useState('');
  const [total, setTotal] = useState(0);

  const [similarCheckList, setSimilarCheckList] =
    useState<similarExtendFaqResDTO[]>();
  const [similarQData, setSimilarQData] = useState<IExtendFaq[]>();
  // const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>([]);
  // const [loading, setLoading] = useState(false);

  const fetchExtendFaqList = async () => {
    const res = await getExtendFaqList({ standardFaqGuid });
    setSimilarQData(res);
    setTotal(res.length || 0);
  };

  useEffect(() => {
    if (similarVisible) {
      fetchExtendFaqList();
    }
    setVisible(similarVisible);
  }, [similarVisible]);

  const createSimilarQ = async (ignoreSimilarCheck: boolean) => {
    if (!questionText) {
      return message.warning('请填写内容');
    }

    if (questionText.length > 2501) {
      return message.warning('字数超过2500');
    }
    const res = await createExtendFaq({
      standardFaqGuid,
      extendFaqName: questionText,
      ignoreSimilarCheck,
    });
    if (res?.status === 0) {
      message.error(res?.info);
      return;
    }
    if (
      res.data?.checkSimilarSuccess === false &&
      res.data?.similarExtendFaqResDTOList
    ) {
      if (res.data?.similarExtendFaqResDTOList?.length === 0) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        handleConfirmOk();
        return;
      }
      setConfirmVisible(true);
      setSimilarCheckList(res.data?.similarExtendFaqResDTOList);
      return;
    }
    fetchExtendFaqList();
  };

  const deleteSimilarQ = async (record: IExtendFaq) => {
    const { guid } = record;
    const res = await deleteExtendFaq({
      extendFaqGuid: guid,
    });
    if (res.success) {
      message.success('删除成功');
      fetchExtendFaqList();
    }
  };

  const handleCancel = () => {
    setVisible(false);
    onChange();
  };

  const handleConfirmCancel = () => {
    setConfirmVisible(false);
  };

  const handleConfirmOk = () => {
    createSimilarQ(true);
    setConfirmVisible(false);
  };

  const handleQuestionText = (e: {
    target: { value: React.SetStateAction<string> };
  }) => {
    setQuestionText(e.target.value);
  };

  const columns = [
    {
      title: '相似问法',
      dataIndex: 'extendFaqName',
      ellipsis: {
        showTitle: false,
      },
      render(extendFaqName: any) {
        return (
          <Tooltip placement="topLeft" title={extendFaqName}>
            {extendFaqName}
          </Tooltip>
        );
      },
    },
    {
      title: '操作',
      key: 'action',
      width: 60,
      render: function Action(text: any, record: IExtendFaq) {
        return (
          <Popconfirm
            title="你确定要删除吗?"
            onConfirm={() => deleteSimilarQ(record)}
            okText="确定"
            cancelText="取消"
          >
            <span style={{ color: '#FF4D4F', cursor: 'pointer' }}>删除</span>
          </Popconfirm>
        );
      },
    },
  ];

  const similarCheckColumns = [
    {
      title: '相似问法',
      dataIndex: 'faqName',
      ellipsis: true,
    },
    {
      title: '所属标准问法',
      dataIndex: 'extendFaqName',
      ellipsis: {
        showTitle: false,
      },
      render(extendFaqName: string) {
        return (
          <Tooltip placement="topLeft" title={extendFaqName}>
            {extendFaqName}
          </Tooltip>
        );
      },
    },
    {
      title: '相似度',
      dataIndex: 'similarRate',
      ellipsis: true,
    },
  ];

  // const start = () => {
  //   setLoading(true);
  //   // ajax request after empty completing
  //   setTimeout(() => {
  //     setSelectedRowKeys([]);
  //     setLoading(false);
  //   }, 1000);
  // };

  // const onSelectChange = (newSelectedRowKeys: React.Key[]) => {
  //   console.log('selectedRowKeys changed: ', newSelectedRowKeys);
  //   setSelectedRowKeys(newSelectedRowKeys);
  // };

  // const rowSelection = {
  //   selectedRowKeys,
  //   onChange: onSelectChange,
  //   selections: [
  //     {
  //       key: 'delete',
  //       text: '批量删除',
  //       onSelect: changableRowKeys => {
  //         console.log('删除', changableRowKeys)
  //         // setSelectedRowKeys(changableRowKeys);
  //       },
  //     },
  //   ]
  // };

  // const hasSelected = selectedRowKeys.length > 0;

  return (
    <>
      <Modal
        title={<ModalDrag>相似问法管理</ModalDrag>}
        className="custom-draggable-modal"
        open={visible}
        onCancel={handleCancel}
        footer={false}
        destroyOnClose={true}
        width={600}
      >
        <div className={style.input}>
          <div style={{ minWidth: 'fit-content' }}>相似问法:</div>
          <Input
            style={{ margin: '0 5px' }}
            placeholder="请输入"
            value={questionText}
            onChange={handleQuestionText}
            showCount
          />
          <Button onClick={() => createSimilarQ(false)}>添加</Button>
        </div>
        {/* <Button type="primary" onClick={start} disabled={!hasSelected} loading={loading}>
          Reload
        </Button> */}
        <ModalDrag>
          <Table
            rowKey={(record) => record.guid}
            columns={columns}
            dataSource={similarQData}
            // rowSelection={rowSelection}
            pagination={{
              pageSize: 100,
              // simple: true,
              total: total,
              showSizeChanger: false,
              showTotal: (total) => `${total} 条数据`,
            }}
          />
        </ModalDrag>
      </Modal>
      <Modal
        title="该知识标准分类下已经相似的相似问法, 请确认是否继续创建:"
        open={confirmVisible}
        onCancel={handleConfirmCancel}
        onOk={handleConfirmOk}
      >
        <Table
          rowKey={(record) => `row_${record.faqName}`}
          columns={similarCheckColumns}
          dataSource={similarCheckList}
          pagination={{
            pageSize: 5,
            simple: true,
          }}
        />
      </Modal>
    </>
  );
};

export default SimilarQManage;
