import React from 'react';
import styles from './index.less';
import { Dropdown, Popconfirm } from 'antd';
import { MoreOutlined } from '@ant-design/icons';
import type { MenuProps } from 'antd';

interface PropsType {
  title: string;
  goodsCode: number | string;
  id: string | number;
  heightLight: any;
  flag: string;
  tag?: boolean;
  codeType?: number;
  isShow?: any;
  delTenantToProps?: any;
  editAuth?: boolean;
}

const AddCard: React.FC<PropsType> = (props) => {
  const {
    tag,
    title,
    goodsCode,
    id,
    heightLight,
    flag,
    isShow,
    delTenantToProps,
    editAuth,
  } = props;

  // 点击高亮
  const handleClick = () => {
    heightLight(id);
  };

  // 卡片编辑
  const editCard = () => {
    // 租户
    if (typeof isShow === 'function') {
      isShow();
    }
  };

  // 删除
  const delCard = () => {
    return new Promise((resolve) => {
      // 租户
      if (typeof isShow === 'function') {
        delTenantToProps()?.then(() => {
          resolve(1);
        });
      }
    });
  };

  let items: MenuProps['items'] = [
    editAuth
      ? {
          label: (
            <a href="#" onClick={editCard}>
              编辑
            </a>
          ),
          key: '0',
        }
      : null,
    !tag && editAuth
      ? {
          label: (
            <Popconfirm
              title="确认要删除吗？"
              onConfirm={delCard}
              placement="topRight"
            >
              <a href="#">删除</a>
            </Popconfirm>
          ),
          key: '1',
        }
      : null,
  ];

  return (
    <>
      <div
        className={`${styles.addCard} ${flag === id ? styles.active : ''}`}
        onClick={handleClick}
      >
        <div className={styles.title}>
          <h3>{title}</h3>
          {editAuth ? (
            <Dropdown menu={{ items }} trigger={['click']}>
              <MoreOutlined style={{ fontSize: '20px' }} />
            </Dropdown>
          ) : (
            <></>
          )}
        </div>
        <h4>
          租户编号：
          {goodsCode}
        </h4>
      </div>
    </>
  );
};

export default AddCard;
