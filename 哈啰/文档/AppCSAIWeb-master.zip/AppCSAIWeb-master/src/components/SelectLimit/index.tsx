import React, { FC, useEffect, useState } from 'react';
import { Select } from 'antd';
export interface Options {
  label: string;
  value: string | number;
  disabled?: boolean;
  id?: string;
}

// interface Props {
//   options: Options[];
//   text?: string;
//   max?: number;
//   value?: Array<string | number>;
//   onChange?: (value: Array<string | number>) => void;
// }

const SelectLimit: FC<any> = ({
  text = '请选择',
  options,
  value,
  onChange,
  max,
  ...props
}) => {
  const [selected, setSelected] = useState<Array<string | number>>([]);
  const [opt, setOpt] = useState(options);
  // 值改变
  const handleChange = (val) => {
    if (max && val.length === max) {
      opt.forEach((item) => {
        if (!val.includes(item.value)) item.disabled = true;
      });
    } else {
      opt.forEach((item) => (item.disabled = false));
    }
    setSelected(val);
    setOpt([...opt]);
    onChange?.(val);
  };

  useEffect(() => {
    setSelected(value);
  }, [value]);

  useEffect(() => {
    const selectOpt = [...options];
    if (max && selected?.length === max) {
      selectOpt.forEach((item) => {
        if (!selected?.includes(item.value)) item.disabled = true;
      });
    } else {
      selectOpt.forEach((item) => (item.disabled = false));
    }
    setOpt([...selectOpt]);
  }, [options]);
  return (
    <>
      <Select
        placeholder={text}
        value={selected}
        mode="multiple"
        showSearch
        allowClear
        getPopupContainer={(triggerNode) =>
          triggerNode.parentElement || document.body
        }
        filterOption={(input, option: any) =>
          (option?.label ?? '').includes(input)
        }
        options={opt}
        onChange={handleChange}
        {...props}
      />
    </>
  );
};

export default SelectLimit;
