import React from 'react';
import { SmsTemplateObj } from '@/api/smsTemplate';
import { getVariableContent } from '@/components/SmsVarChoose/util';
import { supportCarrierOpts } from '@/pages/lineSupplier/config';
import styles from './index.less';

interface Prop {
  curSms: SmsTemplateObj & { classification?: string };
}

const SmsPreView: React.FC<Prop> = ({ curSms }) => {
  return (
    <div className={styles.smsCotent}>
      {curSms?.classification && (
        <>
          <div className={styles.smsKey}>意向结果</div>
          <div className={styles.smsValue}>{curSms.classification}</div>
        </>
      )}
      <div className={styles.smsKey}>服务商</div>
      <div className={styles.smsValue}>
        {curSms?.supplierNameList?.map((item, idx) => (
          <span key={idx}>
            {idx !== 0 ? '、' : ''}
            {item}
          </span>
        ))}
      </div>
      <div className={styles.smsKey}>模版名称</div>
      <div className={styles.smsValue}>{curSms?.templateName}</div>
      <div className={styles.smsKey}>短信内容</div>
      <div className={styles.smsValue}>
        {curSms?.signature}
        {getVariableContent(curSms?.templateContentDetails)}
      </div>
      <div className={styles.smsKey}>链接</div>
      <div className={styles.smsValue}>
        {curSms?.linkType === 0 ? curSms?.link ?? '-' : curSms?.chain ?? '-'}
      </div>
      <div className={styles.smsKey}>支持运营商</div>
      <div className={styles.smsValue}>
        {curSms?.carrierType?.length > 0 ? (
          <>
            {curSms.carrierType.map((val, index) => {
              const text = supportCarrierOpts.find(
                (it) => it.value === val,
              )?.label;
              return (
                <span key={index}>
                  {index !== 0 ? '、' : ''}
                  {text}
                </span>
              );
            })}
          </>
        ) : (
          '-'
        )}
      </div>
      <div className={styles.smsKey}>发送盲区</div>
      <div className={styles.smsValue}>
        {curSms?.areaLimitDisplay?.length ? (
          <div className={styles.selectTagWrap}>
            {curSms.areaLimitDisplay.map((item, idx) => (
              <div className={styles.tagItem} key={idx}>
                <div className={styles.tagLeft}>
                  <div className={styles.proTag}>
                    <div className={styles.tagName}>{item.province}</div>
                    <div className={styles.tagCount}>
                      ({!item?.cities?.length ? '全部' : item?.cities?.length})
                    </div>
                  </div>
                </div>
                <div className={styles.tagRight}>
                  {!item?.cities?.length ? (
                    <div>全部</div>
                  ) : (
                    item?.cities?.map((i, idx) => (
                      <div key={idx} className={styles.cityTag}>
                        {idx !== 0 ? '、' : ''}
                        {i}
                      </div>
                    ))
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          '-'
        )}
      </div>
    </div>
  );
};

export default SmsPreView;
