import React, { useEffect, useRef, useState } from 'react';
import DebounceSelect from '../DebounceSelect';
import { findPage, getLineSupplier } from '@/api/lineSupplier';

interface IProps {
  value?: [string, string];
  onChange?: (value: [string, string] | [string]) => void;
  disabled?: boolean;
}

const SupplierLineSelect: React.FC<IProps> = ({
  value,
  onChange,
  disabled,
}) => {
  // 供应商
  const supplierRef = useRef(null);
  const [supplierValue, setSupplierValue] = useState(undefined);
  // 线路
  const lineRef = useRef(null);
  const [lineValue, setLineValue] = useState(undefined);

  // 外部fetch供应商列表数据
  const fetchSupplierOptions = async (value?: string) => {
    const params = { guid: value };
    const res = await getLineSupplier(params);
    supplierRef?.current?.setOptions(res?.data || []);
  };

  // search供应商列表数据
  const searchSupplierOptions = async (value?: string) => {
    const params = { supplierName: value };
    const res = await getLineSupplier(params);
    return res?.data || [];
  };

  // 外部fetch线路列表数据
  const fetchLineOptions = async (value?: string) => {
    const params = { pageNum: 1, pageSize: 50, status: 1, supplierGuid: value };
    const res = await findPage(params);
    lineRef?.current?.setOptions(res?.data?.list || []);
  };

  // search线路列表数据
  const searchLineOptions = async (value?: string) => {
    const params = {
      pageNum: 1,
      pageSize: 50,
      status: 1,
      supporterLineName: value,
    };
    const res = await findPage(params);
    return res?.data?.list || [];
  };

  // 供应商change
  const handleSupplierChange = (e: string) => {
    // 设置「供应商」和「线路」value
    setSupplierValue(e);
    setLineValue(undefined);
    // fetch「供应商」和「线路」数据
    fetchLineOptions(e);
    if (!e) {
      fetchSupplierOptions();
    }
    onChange([e]);
  };

  // 线路change
  const handleLineChange = async (e: string) => {
    setLineValue(e);

    const obj = lineRef?.current?.options?.find((item) => item?.guid === e);
    // 清空线路
    if (!e) {
      onChange([obj?.supplierGuid || supplierValue]);
      // 如果有供应商数据，刷新线路列表
      if (obj?.supplierGuid || supplierValue) {
        fetchLineOptions(obj?.supplierGuid || supplierValue);
      }
      return;
    }
    // 切换线路
    const isFlag = supplierRef?.current?.options?.some(
      (item) => item?.guid === obj?.supplierGuid,
    );
    // 如果供应商列表没有，就重新fetch
    if (!isFlag) {
      await fetchSupplierOptions(obj?.supplierGuid);
    }
    onChange([obj?.supplierGuid, e]);
  };

  useEffect(() => {
    // 供应商和线路数据初始化
    if (supplierRef.current && lineRef.current) {
      fetchSupplierOptions();
      fetchLineOptions();
    }
  }, []);

  useEffect(() => {
    if (value?.length === 2) {
      setSupplierValue(value[0]);
      setLineValue(value[1]);
      // 回显获取线路数据
      fetchLineOptions(value[0])
    }
    if (!value) {
      setSupplierValue(undefined);
      setLineValue(undefined);
    }
  }, [value]);

  return (
    <div>
      <DebounceSelect
        ref={supplierRef}
        value={supplierValue}
        fetchOptions={searchSupplierOptions}
        fieldNames={{ label: 'supplierName', value: 'guid' }}
        onChange={handleSupplierChange}
        disabled={disabled}
        placeholder="请输入供应商"
        style={{ width: '100%', marginBottom: 10 }}
      />
      <DebounceSelect
        ref={lineRef}
        value={lineValue}
        fetchOptions={searchLineOptions}
        fieldNames={{ label: 'supporterLineName', value: 'guid' }}
        disabled={disabled}
        onChange={handleLineChange}
        placeholder="请输入线路"
        style={{ width: '100%' }}
      />
    </div>
  );
};

export default SupplierLineSelect;
