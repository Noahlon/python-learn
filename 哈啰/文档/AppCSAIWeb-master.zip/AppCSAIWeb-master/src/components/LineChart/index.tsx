import React, { memo, useEffect, useRef } from 'react';
import { Chart } from '@antv/g2';

type LineDataType = {
  xAxis: string;
  yAxis: number;
  item: string;
}[];
interface PropsType {
  // width: string;
  data: LineDataType;
  container: string;
  height?: number;
  showPercent?: boolean;
  padding?: number[];
}

const LineChart: React.FC<PropsType> = ({
  // width,
  height,
  data,
  container,
  showPercent = false,
}) => {
  console.log('折线图重绘');
  const chartRef = useRef(null);
  useEffect(() => {
    chartRef.current = new Chart({
      container,
      autoFit: true,
      height,
    });
  }, []);

  useEffect(() => {
    chartRef.current.clear(); // 清除画布
    chartRef.current.data(data);

    chartRef.current.scale({
      xAxis: {
        range: [0, 1],
      },
      yAxis: {
        nice: true,
      },
    });

    chartRef.current.tooltip({
      showCrosshairs: true,
      shared: true,
      // showTitle: false,

      customItems: showPercent
        ? (items) => {
            const newItems = [{ ...items[0], value: items[0].value + ' %' }];
            return newItems;
          }
        : (items) => {
            console.log(items);
            const newItems = [
              { ...items[0], value: Number(items[0].value) + ' 通' },
            ];
            return newItems;
          },
    });

    chartRef.current.line().position('xAxis*yAxis').color('item');
    // .label('value')
    chartRef.current
      .point()
      .position('xAxis*yAxis')
      .color('item')
      .shape('circle');

    chartRef.current.render();
  }, [data]);

  return <div id={container} style={{ height }}></div>;
};

export default memo(LineChart);
