/* eslint-disable */
import React from 'react';
import Draggable from 'draggable';
import { Modal } from 'antd';
import { ModalProps } from 'antd/lib/modal/Modal';

interface IState {
  open: boolean;
  draggableInited: boolean; // draggable初始化标识
}

export default class DraggableModal extends React.Component<
  ModalProps,
  IState
> {
  constructor(props: ModalProps | Readonly<ModalProps>) {
    super(props);

    this.state = {
      open: false,
      draggableInited: false,
    };
  }

  componentWillReceiveProps(newProps: any) {
    const { open } = this.props;
    if (newProps.open && !open) {
      setTimeout(() => {
        this.initDrag();
      }, 0);
    }
  }

  initDrag() {
    if (!this.state.draggableInited) {
      // 目标为：Modal组件
      const ele = document.querySelector('.custom-draggable-modal');
      if (ele) {
        new Draggable(ele, {
          // 拖拽handle设置为Modal头部，不设置此参数表示整个Modal都可拖拽
          // handle: ele.querySelector(".ant-modal-header")
        });
      }
      this.setState({ draggableInited: true });
    }
  }
  render() {
    return (
      <Modal className="custom-draggable-modal" {...this.props}>
        {this.props.children}
      </Modal>
    );
  }
}
