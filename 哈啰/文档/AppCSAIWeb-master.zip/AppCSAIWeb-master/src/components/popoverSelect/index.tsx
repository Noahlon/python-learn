import {
  CheckOutlined,
  CloseOutlined,
  SearchOutlined,
} from '@ant-design/icons';
import { Input, Popover } from 'antd';
import React, {
  ReactNode,
  useEffect,
  useState,
  forwardRef,
  useImperativeHandle,
} from 'react';
import styles from './index.less';

interface Prop {
  children: ReactNode;
  options: any[];
  onChange: (res: any[]) => void;
  showSearch?: boolean;
  showClear?: boolean;
  isSingleSelect?: boolean;
  fieldNames?: { label?: string; value?: string; desc?: string };
  ref?: React.ForwardedRef<unknown>;
  defaultValue?: any;
}

const PopoverSelect: React.FC<Prop> = forwardRef(
  (
    {
      children,
      options,
      onChange,
      showSearch,
      showClear = true,
      isSingleSelect,
      fieldNames,
      defaultValue,
    },
    ref,
  ) => {
    const [open, setOpen] = useState(false);
    const [showOptions, setShowOptions] = useState([]);
    const [allOptions, setAllOptions] = useState([]);
    const [selectOptions, setSelectOptions] = useState([]);
    const [searchValue, setSearchValue] = useState(undefined);

    const handleOpenChange = (newOpen: boolean) => {
      setOpen(newOpen);
      // 关闭popover清除搜索
      if (!newOpen && searchValue) {
        setSearchValue(undefined);
        setShowOptions(allOptions);
      }
    };

    // 搜索change
    const handleSearchChange = (value: string) => {
      const _filterOptions = allOptions?.filter((item) =>
        item.label?.includes(value),
      );
      setShowOptions(_filterOptions);
      setSearchValue(value);
    };

    // 选中和反选
    const handleSelect = (value: string) => {
      const isContain = selectOptions?.includes(value); // 是否已选中状态
      let _selectArr = selectOptions?.length ? [...selectOptions] : [];
      // 单选
      if (isSingleSelect) {
        if (isContain) {
          return setOpen(false);
        } else {
          _selectArr = [value];
        }
        setOpen(false);
      }
      // 多选
      else {
        if (isContain) {
          _selectArr = selectOptions.filter((item) => item !== value);
        } else {
          _selectArr.push(value);
        }
      }
      setSelectOptions(_selectArr);
      onChange(_selectArr);
    };

    // 清空
    const clearAll = () => {
      setSelectOptions([]);
      handleSearchChange('');
      onChange([]);
      setOpen(false);
    };

    useImperativeHandle(ref, () => ({
      handleSelect,
      clearAll,
    }));

    useEffect(() => {
      if (options) {
        let _options = [];
        if (fieldNames) {
          _options = options?.map((item) => {
            return {
              label: item[fieldNames?.label || 'label'],
              value: item[fieldNames?.value || 'value'],
              desc: item[fieldNames?.desc || 'desc'],
              ...item,
            };
          });
        } else {
          _options = options;
        }
        setAllOptions(_options);
        setShowOptions(_options);
      }
    }, [options]);

    useEffect(() => {
      if (defaultValue !== undefined) {
        if (Array.isArray(defaultValue)) {
          setSelectOptions(defaultValue);
        } else {
          setSelectOptions([defaultValue]);
        }
      } else {
        setSelectOptions(defaultValue);
      }
    }, [defaultValue]);

    const popoverContent = (
      <div className={styles.filterBox}>
        {/* search */}
        {showSearch && (
          <div className={styles.filter}>
            <Input
              placeholder="搜索"
              value={searchValue}
              onChange={(e) => handleSearchChange(e.target.value)}
              allowClear
              suffix={<SearchOutlined />}
            />
          </div>
        )}
        {/* clear */}
        {showClear && (
          <div
            className={styles.selectOption}
            style={{ color: '#aaa' }}
            onClick={clearAll}
          >
            <div>清空</div>
            <div className={styles.checkIcon}>
              <CloseOutlined />
            </div>
          </div>
        )}
        {/* options */}
        <div className={styles.optionContainer}>
          {showOptions?.map((item) => (
            <div
              className={`${styles.selectOption} ${
                selectOptions?.includes(item.value) ? styles.active : ''
              }`}
              key={item.value}
              onClick={() => handleSelect(item.value)}
            >
              <div className={styles.selectValue}>{item.label}</div>
              {item.desc && <div className={styles.vyBZn}>{item.desc}</div>}
              <div className={styles.checkIcon}>
                {selectOptions?.includes(item.value) && <CheckOutlined />}
              </div>
            </div>
          ))}
        </div>
      </div>
    );

    return (
      <Popover
        open={open}
        onOpenChange={handleOpenChange}
        content={popoverContent}
        trigger={'click'}
        placement="bottom"
        overlayClassName={styles.filterOverlayWrap}
      >
        {children}
      </Popover>
    );
  },
);

export default PopoverSelect;
