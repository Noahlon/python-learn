export const getFilterValueText = (
  selectValue,
  opts: any[],
  fieldNames?: { label?: string; value?: string },
) => {
  if (selectValue === undefined || selectValue?.length === 0) {
    return '全部';
  }

  let text = '';
  if (Array.isArray(selectValue)) {
    // 多选
    selectValue.forEach((val, index) => {
      opts?.forEach((item) => {
        if (item[fieldNames?.value || 'value'] === val) {
          text +=
            item[fieldNames?.label || 'label'] +
            (index !== selectValue.length - 1 ? '、' : '');
        }
      });
    });
  }
  // 单选
  else {
    const cur = opts?.find(
      (item) => item[fieldNames?.value || 'value'] === selectValue,
    );
    text = cur?.[fieldNames?.label || 'label'];
  }

  return text;
};
