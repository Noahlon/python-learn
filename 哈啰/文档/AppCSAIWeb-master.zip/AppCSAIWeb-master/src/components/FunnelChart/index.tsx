import React, { memo, useEffect, useRef } from 'react';
import { Funnel } from '@antv/g2plot';

type FunnelDataType = {
  name: string;
  value: number;
  rateText?: string;
  rateTextTip?: string;
}[];

interface PropsType {
  data: FunnelDataType;
  container: string;
  height: number;
  padding?: number[];
  color?: string[];
  otherProps?: object;
}

const FunnelChart: React.FC<PropsType> = ({
  height,
  data,
  container,
  padding = [20, 60, 15, 0],
  color = ['#1790FF', '#8181FF', '#70B605', '#BFBF00', '#D98201', '#63DAAB'],
  otherProps = {},
}) => {
  const chartRef = useRef(null);

  useEffect(() => {
    chartRef.current = new Funnel(document.getElementById(container), {
      locale: 'zh-CN',
      height,
      padding,
      color,
      data: [],
      xField: 'name',
      yField: 'value',
      label: {
        style: {
          fill: '#333',
        },
      },
      ...otherProps,
      conversionTag: {
        formatter: (datum) => {
          if (datum?.hideText) {
            return '';
          }
          const showRateText = datum.rateText
            ? datum.rateText
            : `转化率 ${(
                (datum[Funnel.CONVERSATION_FIELD][1] /
                  datum[Funnel.CONVERSATION_FIELD][0]) *
                100
              ).toFixed(2)}%`;

          return `${showRateText} ${
            datum.rateTextTip ? '\n' + datum.rateTextTip : ''
          }`;
        },
      },
    });
    chartRef.current.render();
  }, []);

  useEffect(() => {
    chartRef.current.changeData(data);
  }, [data]);

  return <div id={container} style={{ height }}></div>;
};

export default memo(FunnelChart);
