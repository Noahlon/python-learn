import { Cascader, Form, Input, Modal, message } from 'antd';
import React, {
  useEffect,
  useState,
  forwardRef,
  useImperativeHandle,
} from 'react';
import {
  // getNewIntentionListById,
  intentionLearning,
  IntentionLearningType,
  getIntentionTree,
  intentionLearningExe,
  IntentionLearningExeType,
  getGroupWithKc, // 获取所有意图
} from '@/api/intention';
import { getIdList } from '@/utils';
import type { DefaultOptionType } from 'antd/es/cascader';
const { SHOW_CHILD } = Cascader;
interface PropTypes {
  ref: any;
  type: 'ITENTIONTEST' | 'ITENTIONLAERNING';
  getTableData?: any;
  modalArr?: string[];
  page?: number;
  formObj?: any;
}

const ItentionLearningModal: React.FC<PropTypes> = forwardRef(
  ({ type, getTableData, modalArr, page, formObj }, ref) => {
    const [formLearn] = Form.useForm();
    const [, setSelectData] = useState([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [treeData, setTreeData] = useState([]);
    const [treeListData, setTreeListData] = useState([]);
    const [searchValue, setSearchValue] = useState('');

    // 弹窗意图
    // const getNewIntentionListByIds = async (kcGuid) => {
    //   const { data } = await getNewIntentionListById({ kcGuid });
    //   if (data) {
    //     setSelectData(data);
    //   } else setSelectData([]);
    // };
    // 意图测试tree
    const getIntentionTrees = async () => {
      const { data } = await getIntentionTree();
      if (data) {
        setTreeData(data);
      } else setTreeData([]);
    };

    // 意图测试-学习
    const intentionLearnings = async (obj: IntentionLearningType) => {
      await intentionLearning(obj);
    };
    // 意图学习-学习
    const intentionLearningExes = async (obj: IntentionLearningExeType) => {
      await intentionLearningExe(obj);
    };

    const clearForm = () => {
      setIsModalOpen(false);
      formLearn.resetFields();
    };

    const handleOk = async () => {
      const res = await formLearn.validateFields();
      let obj: IntentionLearningType = {};
      let kcFaqInfoList = [];
      if (res?.kcFaqInfoList) {
        for (let i = 0, len = res?.kcFaqInfoList.length; i < len; i++) {
          kcFaqInfoList.push(
            JSON.parse(res?.kcFaqInfoList[i][res?.kcFaqInfoList[i].length - 1]),
          );
        }
      }
      obj.kcFaqInfoList = kcFaqInfoList;
      if (res?.phrases) {
        obj = {
          ...obj,
          phrases: res?.phrases,
        };
      }
      if (res?.nearQuestions) {
        obj = {
          ...obj,
          nearQuestions: res?.nearQuestions,
        };
      }
      if (res?.kernelSentenceInfo) {
        obj = {
          ...obj,
          kernelSentenceInfo: res?.kernelSentenceInfo,
        };
      }
      if (!(res?.phrases || res?.nearQuestions || res?.kernelSentenceInfo)) {
        message.error('至少补充一项学习内容');
      } else {
        if (type === 'ITENTIONTEST') {
          await intentionLearnings(obj);
          getTableData(page, 100);
        } else if (type === 'ITENTIONLAERNING') {
          await intentionLearningExes({ ...obj, recordIds: modalArr });
          setTimeout(() => {
            getTableData(page, 100, formObj);
            setSearchValue('');
          }, 500);
        }
        clearForm();
      }
    };
    // 获取所有意图
    const getGroupWithKcData = async () => {
      const { data } = await getGroupWithKc();
      if (data) {
        for (let i = 0, len = data.length; i < len; i++) {
          let kcList = data[i].kcList;
          data[i].value = data[i].guid;
          for (let j = 0, jleng = kcList.length; j < jleng; j++) {
            data[i].kcList[j].value = JSON.stringify({
              kcGuid: kcList[j].kcGuid,
              faqId: kcList[j].faqId,
            });
          }
        }
        setTreeListData(data);
      } else setTreeListData([]);
    };

    useEffect(() => {
      getIntentionTrees();
      getGroupWithKcData();
    }, []);

    useImperativeHandle(ref, () => ({
      openModal: (kcGuid = undefined) => {
        setIsModalOpen(true);
        if (type === 'ITENTIONTEST') {
          // getNewIntentionListByIds(kcGuid);
          formLearn.setFieldValue(
            'kcGuidArr',
            getIdList(treeData, 'id', kcGuid),
          );
        } else if (type === 'ITENTIONLAERNING') {
          setSelectData([]);
        }
      },
    }));
    const filter = (inputValue: string, path: DefaultOptionType[]) =>
      path.some(
        (option) =>
          (option.name as string)
            .toLowerCase()
            .indexOf(inputValue.toLowerCase()) > -1,
      );
    const onSearch = (value) => {
      setSearchValue(value);
    };

    return (
      <Modal
        title="学习"
        open={isModalOpen}
        onOk={handleOk}
        onCancel={clearForm}
      >
        <Form form={formLearn} labelCol={{ span: 6 }} wrapperCol={{ span: 14 }}>
          {/* <Form.Item name="faqId" label="意图" rules={[{ required: true }]}>
            <Select
              placeholder="请选择"
              allowClear
              options={selectData}
              fieldNames={{
                label: 'name',
                value: 'faqId',
              }}
            />
          </Form.Item> */}
          <Form.Item
            name="kcFaqInfoList"
            label="意图"
            rules={[
              { required: true, message: '' },
              {
                validator: (_, value) => {
                  if (!value?.length) {
                    return Promise.reject('请输入意图集合');
                  } else return Promise.resolve();
                },
              },
            ]}
          >
            <Cascader
              placeholder="请选择"
              options={treeListData}
              allowClear
              multiple
              showCheckedStrategy={SHOW_CHILD}
              showSearch={{ filter, limit: 500 }}
              fieldNames={{ label: 'name', children: 'kcList' }}
              onSearch={onSearch}
              searchValue={searchValue}
              // onChange={(_, opt) => {
              //   if (opt?.length === 3) getNewIntentionListByIds(opt[2]?.id);
              //   else {
              //     setSelectData([]);
              //     formLearn.setFieldValue('faqId', '');
              //   }
              // }}
            />
          </Form.Item>
          <Form.Item name="kernelSentenceInfo" label="核心句">
            <Input.TextArea
              autoSize={{ minRows: 4 }}
              maxLength={120}
              placeholder="句子之间用分号/回车相隔"
            />
          </Form.Item>
          {/* <Form.Item name="nearQuestions" label="相似句">
            <Input.TextArea
              autoSize={{ minRows: 4 }}
              maxLength={120}
              placeholder="句子之间用分号/回车相隔"
            />
          </Form.Item> */}
          <Form.Item name="phrases" label="核心短语">
            <Input.TextArea
              autoSize={{ minRows: 4 }}
              maxLength={120}
              placeholder="短语之间用逗号相隔"
            />
          </Form.Item>
        </Form>
      </Modal>
    );
  },
);
export default ItentionLearningModal;
