import React, { useEffect, useState } from 'react';
import { Select, Form } from 'antd';
import { getAutoCommitTimeList } from '@/api/projectv2/task';

const AutoCommitTimeItem: React.FC = () => {
  const [timeList, setTimeList] = useState([]);

  useEffect(() => {
    //请求自动提交时间枚举
    getAutoCommitTimeList().then((res) => {
      if (res?.code === 0) {
        const arr = res?.data?.map((item) => {
          return {
            label: item.desc,
            value: item.time,
          };
        });
        setTimeList(arr);
      }
    });
  }, []);

  return (
    <Form.Item
      label="自动提交时间"
      name="followupRecordAutoCommitTime"
      rules={[{ required: true }]}
    >
      <Select
        showSearch
        placeholder="请选择自动提交时间"
        getPopupContainer={(triggerNode) =>
          triggerNode.parentElement || document.body
        }
        options={timeList}
      />
    </Form.Item>
  );
};

export default AutoCommitTimeItem;
