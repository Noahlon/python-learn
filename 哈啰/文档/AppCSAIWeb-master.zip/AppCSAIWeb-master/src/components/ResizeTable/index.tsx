import React from 'react';
import { Table } from 'antd';
import { TableProps } from 'antd/lib/table';
import { useGetTableResizeHeight } from '@/utils/hooks';
import styles from './index.less';
import { VList } from 'virtuallist-antd';

/**
 * 自适应高度表格
 * @功能
 * 1、自动占满页面剩余高度
 * 2、改变浏览器窗口时自动适应剩余高度不出现外部滚动条
 * @前提 页面自身设置的有高度，而非根据子元素撑开高度
 * @使用方法
 * 1、安装lodash--yarn add lodash，仅使用里面的防抖方法
 * 2、在需要使用的地方导入--import ResizeTable from '@/components/ResizeTable/ResizeTable'
 * 3、使用--<ResizeTable api和antd的Table一样/>
 * @demo
 * import ResizeTable from '@/components/ResizeTable/ResizeTable';
 * const Demo = () => {
 *     return (
 *         <div style={{height: '900px', display: 'flex', flexDirection: 'column' }}>
 *             查询条件
 *             <Form .../>
 *             自适应表格
 *             <ResizeTable
 *                  rowKey="id"
 *                  columns={columns}
 *                  dataSource={data}
 *                  pagination={{
 *                      total: total,
 *                      current: condition.pageIndex,
 *                      pageSize: condition.pageSize,
 *                 }}
 *         </div>
 *     )
 * }
 *
 */
const ResizeTable = <RecordType extends object = any>(
  props: TableProps<RecordType> & {
    otherReduceHeight?: number;
    containerId?: string;
    virtual?: boolean;
  },
) => {
  const [tableHeight] = useGetTableResizeHeight(
    props?.containerId || 'resize-table',
    props.otherReduceHeight,
  );

  let tableProps: TableProps<RecordType> = {
    ...props,
    scroll: {
      y: tableHeight,
    },
  };
  if (props?.scroll?.x) {
    tableProps.scroll!.x = props.scroll.x;
  }

  if (props?.pagination) {
    tableProps.pagination = Object.assign(
      {
        showSizeChanger: true,
        pageSizeOptions: [100, 200, 500],
        showTotal: (total: number) => `总共 ${total} 条`,
      },
      props.pagination,
    );
  }

  // 是否开启虚拟列表
  if (props?.virtual) {
    tableProps.components = VList({
      height: tableHeight,
    });
  }

  return (
    <div className={styles.tableWrap}>
      <div id={props?.containerId || 'resize-table'} className={styles.table}>
        <Table<RecordType> {...tableProps} />
      </div>
    </div>
  );
};

export default ResizeTable;
