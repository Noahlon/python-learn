import React, { useEffect, useMemo, useRef } from 'react';
import { useState } from 'react';
import { Button, Dropdown, message } from 'antd';
import styles from './index.less';
import { PlusCircleOutlined } from '@ant-design/icons';
import { useModel } from '@umijs/max';
import { ICorpusContent } from '@/api/speech';

const InputOfChoose: React.FC = ({ value, onChange }) => {
  // const [selects, setSelects] = useState([]);
  const [focusNode, setFocusNode] = useState();
  const { variableList } = useModel('speech');
  const [focusOffset, setFocusOffset] = useState(0);
  const inputRef = useRef(null);
  const isFirst = useRef(true);

  const getAllEle = (parentNode: any) => {
    let node = [];
    if (parentNode?.childNodes?.length) {
      parentNode?.childNodes?.forEach((item) => {
        if (item?.childNodes?.length) {
          const _node = getAllEle(item);
          node = [...node, ..._node];
        } else if (
          item?.nodeName === '#text' &&
          item?.nodeValue !== '\n' &&
          !!item?.nodeValue?.trim()
        ) {
          node.push(item);
        }
      });
    }
    return node;
  };
  const handleOnChange = () => {
    const lastNode = inputRef.current?.lastChild;
    if (lastNode?.nodeName === '#text' && !lastNode?.data)
      inputRef.current.removeChild(lastNode);
    let _childNodes = getAllEle(inputRef.current);

    // 过滤文本补充词的数据
    _childNodes = _childNodes?.filter(
      (item) => item?.parentNode?.className !== 'complementVar',
    );

    const content = [];
    let _index = 0;
    for (let index = 0; index < _childNodes.length; index++) {
      if (_childNodes?.[index]?.parentNode?.className === 'addEle') {
        const _type = _childNodes?.[index]?.parentNode.getAttribute('type');
        _index += 1;

        // variableInfo添加补充词数据
        const _variableInfo: ICorpusContent['variableInfo'] = {
          variableCode: _type,
          variableName: variableList?.find((i) => i.variableCode === _type)
            ?.variableName,
        };
        const _variableValueCompletion = variableList?.find(
          (i) => i.variableCode === _type,
        )?.variableValueCompletion;

        if (_variableValueCompletion) {
          _variableInfo.variableValueCompletion = _variableValueCompletion;
        }

        const _preVariableValueCompletion = variableList?.find(
          (i) => i.variableCode === _type,
        )?.preVariableValueCompletion;

        if (_preVariableValueCompletion) {
          _variableInfo.preVariableValueCompletion =
            _preVariableValueCompletion;
        }

        content.push({
          order: _index,
          type: 2,
          variableInfo: _variableInfo,
        });
      } else {
        const preNode = _childNodes?.[index - 1];
        if (preNode && preNode?.parentNode?.className !== 'addEle') {
          content[content.length - 1].contentText =
            content[content.length - 1]?.contentText +
            _childNodes?.[index]?.nodeValue;
        } else {
          _index += 1;
          content.push({
            order: _index,
            type: 1,
            contentText: _childNodes?.[index].nodeValue,
          });
        }
      }
    }
    onChange(content);
  };

  const onSelectSubmit = (val) => {
    isFirst.current = false;
    // setSelects([...selects, val]);
    const selection = window.getSelection();
    const range = window.getSelection().getRangeAt(0);
    if (focusNode?.parentElement?.className?.indexOf('addEle') > -1)
      return message.error('不能在变量上添加变量');
    range.setStart(focusNode, focusOffset);
    range.setEnd(focusNode, focusOffset);
    // 删除输入的{}符号
    range.deleteContents();
    const spanNode1 = document.createElement('span');
    // const spanNode2 = document.createElement('span');
    // 判断变量是否有补充词
    if (val.variableValueCompletion || val.preVariableValueCompletion) {
      spanNode1.className = 'complementVar';
      spanNode1.innerHTML = `${
        val.preVariableValueCompletion ? val.preVariableValueCompletion : ''
      }<span class="addEle" type=${val.value}>{${val.text}}</span>${
        val.variableValueCompletion ? val.variableValueCompletion : ''
      }`;
    } else {
      spanNode1.className = 'addEle';
      spanNode1.innerHTML = `{${val.text}}`;
    }
    spanNode1.contentEditable = 'false'; //设置为不可编辑，是为了整个{xxx}一起删掉
    spanNode1.setAttribute('type', val.value);
    // spanNode2.innerHTML = '&nbsp;';
    const frag = document.createDocumentFragment();
    // node,
    // lastNode;
    frag.appendChild(spanNode1); //在 Range 的起点处插入一个节点。
    range.insertNode(frag);
    selection.collapseToEnd(); // 将当前的选区折叠到最末尾的一个点。
   
    handleOnChange();
  };

  const items = useMemo(() => {
    return variableList?.map((item) => ({
      key: item.variableCode,
      label: (
        <div
          onClick={() =>
            onSelectSubmit({
              text: item.variableName,
              value: item.variableCode,
              variableValueCompletion: item.variableValueCompletion || '',
              preVariableValueCompletion: item.preVariableValueCompletion || '',
            })
          }
        >
          {item.variableName}
        </div>
      ),
    }));
  }, [variableList, focusOffset, focusNode]);

  useEffect(() => {
    if (isFirst.current && inputRef?.current) {
      let _html = '';
      if (typeof value === 'string') {
        _html = value;
      } else if (Array.isArray(value)) {
        value.forEach((item) => {
          if (item.type === 1) {
            _html += item.contentText;
          } else if (item.type === 2) {
            const _opt = variableList.find(
              (i) => i.variableCode === item?.variableInfo?.variableCode,
            );
            if (_opt) {
              let _str = '';
              // 判断是否有「补充词」
              if (
                _opt.variableValueCompletion ||
                _opt.preVariableValueCompletion
              ) {
                _str = `<span class="complementVar" contenteditable="false" type="${
                  _opt.variableCode
                }">${
                  _opt.preVariableValueCompletion
                    ? _opt.preVariableValueCompletion
                    : ''
                }<span class="addEle" type="${_opt.variableCode}">{${
                  _opt.variableName
                }}</span>${
                  _opt.variableValueCompletion
                    ? _opt.variableValueCompletion
                    : ''
                }</span>`;
              } else {
                _str = `<span class="addEle" contenteditable="false" type="${_opt.variableCode}">{${_opt.variableName}}</span>`;
              }

              _html += _str;
            }
          }
        });
      }
      inputRef.current.innerHTML = _html || '';
      setTimeout(() => {
        try {
          inputRef.current?.focus();
          const selection = window.getSelection();
          selection?.selectAllChildren(inputRef.current);
          selection?.collapseToEnd(); //光标移至最后
          inputRef.current?.blur();
        } catch (e) {}
      }, 100);
    }
  }, [value, variableList]);

  return (
    <div className={styles.chooseWrap}>
      <div className={styles.chooseInputWrap}>
        <div
          ref={inputRef}
          contentEditable
          // onKeyDown={onTalkKeyDown}
          className={styles.chooseInput}
          onInput={(e) => {
            isFirst.current = false;
            // console.log(e.target.innerText);
            handleOnChange();
            if (e.nativeEvent.data === '@') {
              // 监听输入@
              console.log(e.nativeEvent.data);
            }
          }}
          onBlur={() => {
            let selection = window.getSelection();
            setFocusNode(selection.focusNode); // 缓存光标所在节点
            setFocusOffset(selection.focusOffset); // 缓存光标所在节点位置
          }}
          onPaste={(e) => {
            if (!!variableList?.length) message.warning('复制后需重新选择变量');
            const bufferText = (
              (e.originalEvent || e).clipboardData || window.clipboardData
            ).getData('Text');
            e.preventDefault();
            document.execCommand('insertText', false, bufferText);
          }}
        ></div>
      </div>

      <Dropdown menu={{ items }} trigger={['click']}>
        <Button
          type="link"
          icon={<PlusCircleOutlined />}
          className={styles.add}
        >
          添加变量
        </Button>
      </Dropdown>
    </div>
  );
};

export default InputOfChoose;
