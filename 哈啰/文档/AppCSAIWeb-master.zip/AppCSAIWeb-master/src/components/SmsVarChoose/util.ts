import React from 'react';
// 获取短信内容的length
export const getSmsTextLength = (content) => {
  let _length = 0;
  content?.forEach((item) => {
    if (item.type === 1) {
      _length += item.contentText.length;
    }
    if (item.type === 2) {
      if (+item.variableInfo.variableType === 1) {
        _length += 4;
      } else {
        _length += item.variableInfo.variableName.length;
      }
    }
    if (item.type === 3 && item.contentText) {
      _length += item.contentText?.length;
    }
  });
  return _length;
};

// 获取短信内容中的变量列表
export const getSmsVariableList = (content) => {
  const contentVariableCodes = content?.reduce((total, cur) => {
    if (cur?.type === 2) {
      return [...total, cur?.variableInfo?.variableCode];
    }
    return total;
  }, []);
  return contentVariableCodes || [];
};

// 获取通道短信内容中的变量名称列表
export const getChannelVariableNameList = (content) => {
  const contentVariableNames = content?.reduce((total, cur) => {
    if (cur?.type === 2) {
      return [...total, cur?.variableInfo?.variableName];
    }
    return total;
  }, []);
  return contentVariableNames || [];
};

// 获取短信内容中的url列表
export const getUrlList = (content) => {
  return content?.filter((item) => item.type === 3);
};

// 获取短信内容的content
export const getVariableContent = (contentDetails) => {
  let _content = [];
  contentDetails?.forEach((item, idx) => {
    if (item.type === 1) {
      _content.push(item.contentText);
    } else if (item.type === 2) {
      _content.push(
        React.createElement(
          'span',
          { key: idx, className: 'globalVariableName' },
          `{${item?.variableInfo?.variableName}}`,
        ),
      );
    } else if (item.type === 3) {
      _content.push(item.contentText);
    }
  });
  return _content;
};
