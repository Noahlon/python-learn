import React, { useEffect, useRef } from 'react';
import { useState } from 'react';
import {
  Button,
  Popover,
  Select,
  message,
  Input,
  Row,
  Col,
  Avatar,
  Empty,
  Form,
  InputNumber,
} from 'antd';
import { EnterOutlined, DeleteOutlined } from '@ant-design/icons';
import { variableOpts, operationOpts } from '@/pages/speech/config';
import {
  getSmsTextLength,
  getChannelVariableNameList,
  getUrlList,
} from './util';
import { useModel } from '@umijs/max';
import { IVariableInfo } from '@/api/smsTemplate';
import styles from './index.less';

const SmsVarChannel: React.FC = ({ value, onChange, linkType }) => {
  const {
    channelVariableList,
    setChannelVariableList,
    channelUrlContent,
    setChannelUrlContent,
    channelVariableUrlList,
    setChannelVariableUrlList,
  } = useModel('smsMange');
  const [variableNameInput, setVariableNameInput] = useState<string>(); // 变量输入
  const [variableTypeSelect, setVariableTypeSelect] = useState(); // 变量类型
  const [hadVariableNames, setHadVariableNames] = useState([]); // 短信内容中变量name列表
  const [urlList, setUrlList] = useState([]); // url列表
  const [smsPopoverOpen, setSmsPopoverOpen] = useState(false);
  const [fieldLength, setFieldLength] = useState(0); // 短信内容的长度
  const addLoadingRef = useRef(false); // 是否添加loading

  const [focusNode, setFocusNode] = useState();
  const [focusOffset, setFocusOffset] = useState(0);
  const [operator, setOperator] = useState('+');
  const [operand, setOperand] = useState(0);
  const inputRef = useRef(null);
  const isFirst = useRef(true);

  // 添加通道变量列表到model
  const cacheVariableList = async (variableInfo: IVariableInfo) => {
    // 防止快速添加多个
    if (addLoadingRef.current) {
      return;
    }
    addLoadingRef.current = true;
    setChannelVariableList([...channelVariableList, variableInfo]);
    //如果是文本类型，需要同步更新外部变量链接下拉列表
    if (variableInfo.variableType === 4) {
      if (channelVariableUrlList?.length > 0) {
        setChannelVariableUrlList([...channelVariableUrlList, variableInfo]);
      } else {
        setChannelVariableUrlList([variableInfo]);
      }
    }
    setTimeout(() => {
      addLoadingRef.current = false;
    }, 0);
  };

  // 变量列表中添加单个变量
  const handleAddVariable = () => {
    const variableNameTrim = variableNameInput?.trim();
    // 判断是否重名
    const isNameRepeat = channelVariableList?.some(
      (item) => item.variableName === variableNameTrim,
    );
    if (isNameRepeat) {
      message.error('变量名称已存在');
      return;
    }
    //如果是日期类型，需要校验
    if ([10, 11].includes(variableTypeSelect)) {
      if (!operand && operand !== 0) {
        message.warning('请填写日期天数');
        return;
      }
      const variableName =
        (variableTypeSelect === 10 ? '短信发送日期' : '名单导入日期') +
        operator +
        operand +
        '天';
      if (
        channelVariableList?.some((item) => item.variableName === variableName)
      ) {
        message.error('变量名称已存在');
        return;
      }
    }
    if (channelVariableList?.length >= 10) {
      message.error('变量不能超过10个');
      return;
    }
    if (!variableTypeSelect) {
      message.warning('请先选择变量类型');
      return;
    }
    if (!variableNameTrim && ![10, 11].includes(variableTypeSelect)) {
      message.warning('请填写变量名称');
      return;
    }
    // 姓名和尾号不置空
    if (![1, 2, 8, 9].includes(variableTypeSelect)) {
      setVariableNameInput('');
      setOperator('+');
      setOperand(0);
    }

    let addParams = {};

    //日期类型
    if ([10, 11].includes(variableTypeSelect)) {
      addParams = {
        operator,
        operand,
        variableName:
          (variableTypeSelect === 10 ? '短信发送日期' : '名单导入日期') +
          operator +
          operand +
          '天',
        variableType: variableTypeSelect,
      };
    } else {
      addParams = {
        variableName: variableNameTrim,
        variableType: variableTypeSelect,
      };
    }
    cacheVariableList(addParams);
  };

  // 删除变量
  const deleteVariable = async (name: string) => {
    //如果删除的是文本类型变量，需要刷新外部变量链接的数据源
    const deleteVariableType = channelVariableList.find(
      (i) => i.variableName === name,
    )?.variableType;
    if (deleteVariableType === 4) {
      const _urlList = channelVariableUrlList?.filter(
        (item) => item.variableName !== name,
      );
      setChannelVariableUrlList(_urlList);
    }

    const _list = channelVariableList?.filter(
      (item) => item.variableName !== name,
    );
    setChannelVariableList(_list);
  };

  const getAllEle = (parentNode: any) => {
    let node = [];
    if (parentNode?.childNodes?.length) {
      parentNode?.childNodes?.forEach((item, idx) => {
        if (item?.childNodes?.length) {
          const _node = getAllEle(item);
          node = [...node, ..._node];
        } else if (item?.nodeName === '#text' && item?.nodeValue !== '\n') {
          // 如果是两个变量和url之间允许有空格
          const preItem = parentNode?.childNodes?.[idx - 1];
          const nextItem = parentNode?.childNodes?.[idx + 1];
          const isFlag =
            preItem &&
            preItem?.nodeName !== '#text' &&
            nextItem &&
            nextItem?.nodeName !== '#text';
          if (!!item?.nodeValue?.trim() || isFlag) {
            node.push(item);
          }
        }
      });
    }
    return node;
  };

  const handleOnChange = () => {
    const lastNode = inputRef.current?.lastChild;
    if (lastNode?.nodeName === '#text' && !lastNode?.data)
      inputRef.current.removeChild(lastNode);
    const _childNodes = getAllEle(inputRef.current);
    const content = [];
    let _index = 0;
    for (let index = 0; index < _childNodes.length; index++) {
      if (_childNodes?.[index]?.parentNode?.className === 'addEle') {
        const _varname =
          _childNodes?.[index]?.parentNode.getAttribute('varname');
        const _vartype =
          _childNodes?.[index]?.parentNode.getAttribute('vartype');
        _index += 1;
        content.push({
          order: _index,
          type: 2,
          variableInfo: {
            variableType: _vartype,
            variableName: _varname,
          },
        });
      } else if (_childNodes?.[index]?.parentNode?.className === 'urlEle') {
        _index += 1;
        content.push({
          order: _index,
          type: 3,
          contentText: channelUrlContent,
        });
      } else {
        const preNode = _childNodes?.[index - 1];
        if (
          preNode &&
          preNode?.parentNode?.className !== 'addEle' &&
          preNode?.parentNode?.className !== 'urlEle'
        ) {
          content[content.length - 1].contentText =
            content[content.length - 1]?.contentText +
            _childNodes?.[index]?.nodeValue;
        } else {
          _index += 1;
          content.push({
            order: _index,
            type: 1,
            contentText: _childNodes?.[index].nodeValue,
          });
        }
      }
    }
    // 文本长度
    const _length = getSmsTextLength(content);
    setFieldLength(_length);

    // 短信内容中变量列表
    const _contentVariableNames = getChannelVariableNameList(content);
    setHadVariableNames(_contentVariableNames);

    // url列表
    const _contentUrlList = getUrlList(content);
    setUrlList(_contentUrlList);
    onChange(content);
  };

  // 短信内容中添加变量
  const onSelectSubmit = (val, url: boolean = false) => {
    if (!url && hadVariableNames?.length >= 8)
      return message.error('变量数量不能大于8个');
    if (url) {
      if (!channelUrlContent) {
        return message.error('链接为空，请先补充');
      }
      if (urlList?.length >= 1) {
        return message.error('链接数量不能大于1个');
      }
    }
    isFirst.current = false;
    // setSelects([...selects, val]);
    const selection = window.getSelection();
    const range = window.getSelection().getRangeAt(0);
    if (focusNode?.parentElement?.className?.indexOf('addEle') > -1)
      return message.error('不能在变量上添加变量');
    range.setStart(focusNode, focusOffset);
    range.setEnd(focusNode, focusOffset);
    // 删除输入的{}符号
    range.deleteContents();
    const spanNode1 = document.createElement('span');
    spanNode1.className = url ? 'urlEle' : 'addEle';
    spanNode1.innerHTML = url ? `'${val.text}'` : `{${val.text}}`;
    spanNode1.contentEditable = 'false'; //设置为不可编辑，是为了整个{xxx}一起删掉
    spanNode1.setAttribute('varname', val.text);
    spanNode1.setAttribute('vartype', val.type);
    const frag = document.createDocumentFragment();
    // node,
    // lastNode;
    frag.appendChild(spanNode1); // 在 Range 的起点处插入一个节点。
    range.insertNode(frag);
    selection.collapseToEnd(); // 将当前的选区折叠到最末尾的一个点。
    handleOnChange();
  };

  // 通道内容中删除变量
  const deleteHidden = (data) => {
    //作为变量引用
    if (hadVariableNames?.includes(data.variableName)) {
      return true;
    }
    //变量链接引入
    if (linkType === 2) {
      return (
        urlList?.find((item) => item.type === 3)?.contentText ===
        data.variableName
      );
    }
    return false;
  };

  useEffect(() => {
    if (isFirst.current && inputRef?.current) {
      let _html = '';
      if (typeof value === 'string') {
        _html = value;
      } else if (Array.isArray(value)) {
        value.forEach((item) => {
          if (item.type === 1) {
            _html += item.contentText;
          } else if (item.type === 2) {
            const _opt = channelVariableList?.find(
              (i) => i.variableName === item?.variableInfo?.variableName,
            );
            if (_opt)
              _html += `<span class="addEle" contenteditable="false" varname="${_opt.variableName}" vartype="${_opt.variableType}">{${_opt.variableName}}</span>`;
          } else if (item.type === 3) {
            _html += `<span class="urlEle" contenteditable="false">'url'</span>`;
          }
        });
      }
      inputRef.current.innerHTML = _html || '';

      const _length = getSmsTextLength(value);
      setFieldLength(_length);

      // 短信内容中变量列表
      const _contentVariableNames = getChannelVariableNameList(value);
      setHadVariableNames(_contentVariableNames);

      // url 列表
      const _contentUrlList = getUrlList(value);
      setUrlList(_contentUrlList);

      setTimeout(() => {
        try {
          inputRef.current?.focus();
          const selection = window.getSelection();
          selection?.selectAllChildren(inputRef.current);
          selection?.collapseToEnd(); // 光标移至最后
          inputRef.current?.blur();
        } catch (e) {}
      }, 100);
    }
  }, [value, channelVariableList]);

  useEffect(() => {
    if (!value?.length) {
      return;
    }
    const arr = [...value];
    arr.forEach((item) => {
      if (item.type === 3) {
        item.contentText = channelUrlContent;
      }
    });
    const _length = getSmsTextLength(value);
    setFieldLength(_length);
    onChange(arr);
  }, [channelUrlContent]);

  useEffect(() => {
    // 短信重置变量列表和url链接
    return () => {
      setChannelUrlContent('');
      setChannelVariableList([]);
    };
  }, []);

  return (
    <div className={styles.chooseWrap}>
      {/* 短信内容框 */}
      <div className={styles.chooseInputWrap}>
        <div
          ref={inputRef}
          contentEditable
          className={styles.chooseInput}
          onInput={() => {
            isFirst.current = false;
            handleOnChange();
          }}
          onBlur={() => {
            let selection = window.getSelection();
            setFocusNode(selection.focusNode); // 缓存光标所在节点
            setFocusOffset(selection.focusOffset); // 缓存光标所在节点位置
          }}
          onPaste={(e) => {
            if (!!channelVariableList?.length)
              message.warning('复制后需重新选择变量');
            const bufferText = (
              (e.originalEvent || e).clipboardData || window.clipboardData
            ).getData('Text');
            e.preventDefault();
            document.execCommand('insertText', false, bufferText);
          }}
        ></div>
      </div>
      {/* 添加变量util */}
      <div className={styles.outVariableUtil}>
        <Button
          type="primary"
          onClick={() =>
            onSelectSubmit(
              {
                text: 'url',
              },
              true,
            )
          }
        >
          链接
        </Button>
        <div className={styles.variableUtil}>
          <Popover
            placement="leftTop"
            open={smsPopoverOpen}
            overlayClassName={styles.smsVarPopover}
            getPopupContainer={(triggerNode) =>
              triggerNode.parentElement || document.body
            }
            content={
              <div className="smsVarCotent">
                <Form>
                  <Row>
                    <Col span={7}>
                      <Form.Item required={false} style={{ marginBottom: 0 }}>
                        <Select
                          value={variableTypeSelect}
                          onChange={(e) => {
                            setVariableTypeSelect(e);
                            let str = '';
                            if ([1, 2, 8, 9].includes(e)) {
                              str = variableOpts.find(
                                (item) => item.value === e,
                              )?.label;
                            }
                            setVariableNameInput(str);
                          }}
                          options={variableOpts}
                        />
                      </Form.Item>
                    </Col>
                    <Col span={17}>
                      <Form.Item required={false} style={{ marginBottom: 0 }}>
                        <Input.Group compact>
                          {[10, 11].includes(variableTypeSelect) ? (
                            <Row
                              style={{
                                width: 'calc(100% - 50px)',
                                display: 'inline-flex',
                                alignItems: 'center',
                                margin: '0',
                              }}
                              gutter={8}
                            >
                              <span
                                style={{
                                  marginLeft: '6px',
                                  marginRight: '6px',
                                }}
                              >
                                {variableTypeSelect === 10
                                  ? '短信发送日期'
                                  : '名单导入日期'}
                              </span>

                              <Select
                                value={operator}
                                onChange={(e) => {
                                  setOperator(e);
                                  if (e === '-' && operand === 0) {
                                    setOperand(1);
                                  }
                                }}
                                options={operationOpts}
                              />
                              <InputNumber
                                value={operand}
                                style={{ width: '55px' }}
                                max={99}
                                precision={0}
                                maxLength={2}
                                min={operator === '+' ? 0 : 1}
                                onChange={(e) => {
                                  setOperand(e);
                                }}
                              />
                              <span
                                style={{
                                  marginLeft: '4px',
                                }}
                              >
                                天
                              </span>
                            </Row>
                          ) : (
                            <Input
                              value={variableNameInput}
                              disabled={[1, 2, 8, 9].includes(
                                variableTypeSelect,
                              )}
                              onChange={(e) =>
                                setVariableNameInput(e.target.value)
                              }
                              onPressEnter={handleAddVariable}
                              placeholder="限制30字"
                              maxLength={30}
                              style={{ width: 'calc(100% - 50px)' }}
                            />
                          )}
                          <Button
                            type="primary"
                            onClick={handleAddVariable}
                            icon={<EnterOutlined />}
                          />
                        </Input.Group>
                      </Form.Item>
                    </Col>
                  </Row>
                </Form>
                <div>
                  <div className="variableHint">请选择：</div>
                  {channelVariableList?.length > 0 ? (
                    <div>
                      {channelVariableList.map((item, idx) => (
                        <div className="variableItem" key={String(idx)}>
                          <div
                            className="variableItemLeft"
                            onClick={() => {
                              onSelectSubmit({
                                text: item.variableName,
                                type: item.variableType,
                              });
                              setSmsPopoverOpen(false);
                            }}
                          >
                            <Avatar
                              size={26}
                              style={{ backgroundColor: '#f56a00' }}
                            >
                              {variableOpts
                                ?.find((it) => it.value === item.variableType)
                                ?.label?.slice(0, 1)}
                            </Avatar>
                            <div className="variableValue">
                              {item.variableName}
                            </div>
                          </div>
                          {!deleteHidden(item) && (
                            <div
                              className="variableItemRight"
                              onClick={() => deleteVariable(item.variableName)}
                            >
                              <DeleteOutlined />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                  )}
                </div>
              </div>
            }
          >
            <Button
              type="primary"
              ghost={!smsPopoverOpen}
              onClick={() => setSmsPopoverOpen(!smsPopoverOpen)}
            >
              添加变量
            </Button>
          </Popover>
          <div style={{ paddingLeft: '10px' }}>{fieldLength}/500</div>
        </div>
      </div>
    </div>
  );
};

export default SmsVarChannel;
