import React, { useEffect, useState } from 'react';
import { Checkbox, Col, Divider, message, Row, Space, Button } from 'antd';
import type { CheckboxChangeEvent } from 'antd/es/checkbox';
import { cloneDeep } from 'lodash';
import { useModel } from '@umijs/max';
import {
  CopyOutlined,
  SnippetsOutlined,
  DeleteOutlined,
} from '@ant-design/icons';
import {
  IDCheckedData,
  IDRootData,
  IDTabInfo,
  IDTreeItem,
  IDTypeItem,
} from './types';
import TreeComponent from './treeComponent';
import styles from './index.less';

interface Prop {
  typeIndex: number; //当前枚举下标
  treeList: IDTreeItem[]; //当前分类下省市树列表
  typeItem: IDTypeItem; //当前类型枚举对象
  tabInfo: IDTabInfo; //当前需要提交的数据列表
  updateTree?: (data: any, index: number, key: number, info: any) => void; //修改外层数的回调方法
  rootData: IDRootData; //初始化数据
}

const Container: React.FC<Prop> = ({
  treeList,
  typeIndex,
  typeItem,
  updateTree,
  tabInfo,
  rootData,
}) => {
  const [convertToList, setConvertToList] = useState<any>([]);
  const { setCurrentCopyData, currentCopyData } = useModel('task');
  // 当前运营商全选/半选配置
  const [indeterminate, setIndeterminate] = useState(false);
  const [checkAll, setCheckAll] = useState(false);
  const [currentData, setCurrentData] = useState<any>({});

  const cityClick = ({
    cityKey, //当前点击市按钮key
    anchorIndex, //锚点列表下标
    provinceIndex, //省列表下标
    cityIndex, //市列表下标
  }: IDCheckedData) => {
    let { provinceNum = 0, checkList = [] } = tabInfo;
    //treeList树形数据
    const _treeList = cloneDeep(treeList);
    const provinceData =
      (_treeList?.length > 0 &&
        _treeList[anchorIndex].children[provinceIndex]) ||
      []; //获取当前点击的省数据
    const selectNum = provinceData.selectNum || 0; //获取当前省下选中市数量
    const check = provinceData.children[cityIndex]?.check ? false : true; //判断是否需要选中
    // 弹窗中选中市数量
    provinceData.selectNum = check ? selectNum + 1 : selectNum - 1;
    provinceData.children[cityIndex].check = check;
    // //收集省市数量
    if (selectNum === 0) {
      provinceNum = provinceNum + 1;
    } else if (provinceData.selectNum === 0) {
      provinceNum = provinceNum - 1;
    }
    // 设置弹窗内checkbox 全选/半选
    let checkAll =
      provinceData.selectNum === provinceData.children.length ? true : false;
    // //设置类型下选中的市数量
    const checkIndex = checkList.findIndex(
      (item) => item.value === provinceData.value,
    );
    if (check) {
      //如果当前城市所在的省份已经有被选中的
      if (checkIndex > -1) {
        checkList[checkIndex].children.push(provinceData.children[cityIndex]);
        checkList[checkIndex].allCity = checkAll ? 1 : 0;
      } else {
        checkList.push({
          value: provinceData.value,
          label: provinceData.label,
          allCity: checkAll ? 1 : 0,
          children: [provinceData.children[cityIndex]],
        });
      }
    } else {
      //取消选中
      checkList[checkIndex].children = checkList[checkIndex].children.filter(
        (item) => item.value !== cityKey,
      );
      checkList[checkIndex].allCity = checkAll ? 1 : 0;
      //如果当前省份下的所有市都没有被选中,则删除该省份
      if (checkList[checkIndex].children?.length === 0) {
        checkList.splice(checkIndex, 1);
      }
    }
    updateTree?.(_treeList, typeIndex, Number(typeItem.value) as number, {
      provinceNum,
      checkList,
    });
    setCurrentData({
      indeterminate: checkAll || provinceNum === 0 ? false : true,
      checkAll,
    });
  };

  // 用于数据修改是否全选添加check属性
  const updateCheck = (nodes: any, check: boolean) => {
    try {
      return nodes.map((anchorItem: any) => {
        return {
          ...anchorItem,
          children: anchorItem?.children?.map((provinceItem: any) => {
            return {
              ...provinceItem,
              selectNum: check ? provinceItem?.children?.length : 0,
              children: provinceItem?.children?.map((cityItem: any) => {
                return {
                  ...cityItem,
                  check,
                };
              }),
            };
          }),
        };
      });
    } catch (error) {
      return nodes;
    }
  };

  // 全选半选
  const onCheckAllChange = (check: boolean) => {
    setIndeterminate(false);
    const provinceNum = check ? rootData.rootProvinceNum : 0;
    let checkList = [];
    if (check) {
      checkList = rootData.rootCityList.map((item: any) => {
        return {
          ...item,
          allCity: 1,
        };
      });
    }
    setCheckAll(check);
    updateTree?.(
      updateCheck(treeList, check),
      typeIndex,
      Number(typeItem.value) as number,
      {
        provinceNum,
        checkList,
      },
    );
  };

  // 气泡打开后赋值
  const onOpenChange = (open: boolean, selectNum: number, cityNum: number) => {
    if (open) {
      // 全选/半选
      let checkAll = selectNum === cityNum ? true : false;
      setCurrentData({
        indeterminate: checkAll || selectNum === 0 ? false : true,
        checkAll,
      });
    }
  };

  // 气泡内checkout
  const onCheckItemAllChange = (
    check: boolean,
    anchorIndex: number, //锚点列表下标
    provinceIndex: number, //省列表下标
  ) => {
    let { provinceNum = 0, checkList = [] } = tabInfo;
    const provinceData = treeList[anchorIndex]?.children[provinceIndex]; //获取当前点击的省数据
    const selectNum = provinceData?.selectNum || 0; //获取当前省下选中市数量
    const cityNum = provinceData?.children?.length; //获取当前省下市数量
    provinceData.selectNum = check ? cityNum : 0;
    provinceData.children = provinceData?.children?.map((item: any) => {
      return {
        ...item,
        check,
      };
    });
    // 收集省市数量
    if (selectNum === 0) {
      provinceNum = provinceNum + 1;
    } else if (selectNum === cityNum) {
      provinceNum = provinceNum - 1;
    }
    if (check) {
      checkList = checkList.filter((item) => item.value !== provinceData.value);
      checkList.push({
        label: provinceData.label,
        value: provinceData.value,
        allCity: 1,
        children: provinceData.children,
      });
    } else {
      //取消选中
      checkList = checkList.filter((item) => item.value !== provinceData.value);
    }
    updateTree?.(treeList, typeIndex, Number(typeItem.value) as number, {
      provinceNum,
      checkList,
    });
    setCurrentData({ indeterminate: false, checkAll: check });
  };

  // 复制
  const copyFunc = () => {
    message.success('复制成功！');
    setCurrentCopyData(() => {
      return { tabInfo, treeList, indeterminate, checkAll };
    });
  };

  // 粘贴
  const pasteFunc = () => {
    message.success('粘贴成功！');
    if (currentCopyData?.treeList) {
      updateTree?.(
        cloneDeep(currentCopyData?.treeList),
        typeIndex,
        Number(typeItem.value) as number,
        {
          provinceNum: currentCopyData?.tabInfo?.provinceNum || 0,
          checkList: cloneDeep(currentCopyData?.tabInfo?.checkList) || [],
        },
      );
      return;
    }
    onCheckAllChange(false);
  };

  // 清空
  const delFunc = () => {
    message.success('清空成功！');
    setCurrentCopyData({});
    onCheckAllChange(false);
  };

  // 将数组列表多条数据转成长度为2的二维数组
  const convertTo2DArray = (arr: any) => {
    if (!arr || !Array.isArray(arr)) return [];
    const mindleNum = Math.floor(arr?.length / 2);
    const result = [arr.slice(0, mindleNum), arr.slice(mindleNum, arr.length)];
    return result;
  };

  useEffect(() => {
    if (treeList.length > 0) {
      setConvertToList(convertTo2DArray(treeList));

      //设置外层checked是否选中
      const { provinceNum = 0, checkList = [] } = tabInfo;
      const { rootProvinceNum = 0, rootCityList = [] } = rootData;
      let checkCityList = [];
      let rootCitys = [];
      checkList?.forEach((item) => {
        checkCityList = checkCityList.concat(...(item?.children || []));
      });
      rootCityList?.forEach((item) => {
        rootCitys = rootCitys.concat(...(item?.children || []));
      });
      const checkLengthFlag =
        rootProvinceNum > 0 && checkCityList.length === rootCitys.length
          ? true
          : false;
      setCheckAll(checkLengthFlag);
      setIndeterminate(checkLengthFlag || provinceNum === 0 ? false : true);
    }
  }, [JSON.stringify(treeList)]);

  return (
    <div className={styles.containerBox}>
      <div className={styles.headerBox}>
        <Checkbox
          indeterminate={indeterminate}
          onChange={(e: CheckboxChangeEvent) => {
            onCheckAllChange(e?.target?.checked);
          }}
          checked={checkAll}
        >
          全选
        </Checkbox>
        <Space>
          <Button
            className={styles.headerText}
            type="link"
            icon={<CopyOutlined />}
            onClick={() => {
              copyFunc();
            }}
          >
            复制
          </Button>
          <Button
            className={styles.headerText}
            type="link"
            icon={<SnippetsOutlined />}
            onClick={() => {
              pasteFunc();
            }}
          >
            粘贴
          </Button>
          <Button
            className={styles.headerText}
            type="link"
            icon={<DeleteOutlined />}
            onClick={() => {
              delFunc();
            }}
          >
            清空
          </Button>
        </Space>
      </div>
      <Divider></Divider>
      <Row>
        {convertToList.map((item: any, index: number) => {
          return (
            <Col
              span={12}
              key={`convertToList${index}`}
              className={styles.colBox}
            >
              <TreeComponent
                treeList={item}
                onOpenChange={onOpenChange}
                onCheckItemAllChange={onCheckItemAllChange}
                cityClick={cityClick}
                setCurrentData={setCurrentData}
                currentData={currentData}
              ></TreeComponent>
            </Col>
          );
        })}
      </Row>
    </div>
  );
};

export default Container;
