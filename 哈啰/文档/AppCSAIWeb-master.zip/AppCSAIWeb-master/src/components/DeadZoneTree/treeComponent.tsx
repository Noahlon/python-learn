import React from 'react';
import { Button, Checkbox, Divider, Popover, Space } from 'antd';
import { DownOutlined } from '@ant-design/icons';
import { IDAnchorItem } from './types';

import styles from './index.less';
interface Prop {
  currentData: any; //当前选中的数据
  setCurrentData: any; //设置当前选中数据
  cityClick: any; //单点市按钮
  onCheckItemAllChange?: any; //弹窗内checked回调
  onOpenChange: any; //打开弹窗方法
  treeList: any; //渲染树
}

const TreeComponent: React.FC<Prop> = ({
  treeList,
  currentData,
  cityClick,
  onCheckItemAllChange,
  onOpenChange,
}) => {
  return (
    <div className={styles.contentBox}>
      {treeList?.length > 0 &&
        treeList.map((anchorItem: IDAnchorItem, anchorIndex: any) => {
          return (
            <div
              className={styles.anchorBox}
              key={`anchorIndex-${anchorIndex}`}
            >
              <div className={styles.anchorText}>{anchorItem.value}</div>
              <Space size={[8, 8]} wrap className={styles.provinceFlex}>
                {anchorItem?.children?.length > 0 &&
                  anchorItem?.children.map(
                    (provinceItem: any, provinceIndex: number) => {
                      // 设置省份下已选市数量
                      const selectNum = provinceItem?.selectNum || 0;
                      return (
                        <Popover
                          key={`provinceIndex-${provinceIndex}`}
                          placement="bottomLeft"
                          onOpenChange={(open) => {
                            onOpenChange(
                              open,
                              selectNum,
                              provinceItem?.children?.length || 0,
                            );
                          }}
                          content={
                            <div style={{ width: '400px' }}>
                              <Checkbox
                                indeterminate={
                                  currentData?.indeterminate || false
                                }
                                onChange={(e) => {
                                  onCheckItemAllChange(
                                    e.target.checked,
                                    anchorItem.anchorIndex, //锚点列表下标
                                    provinceIndex,
                                  );
                                }}
                                checked={currentData?.checkAll || false}
                              >
                                全选
                              </Checkbox>
                              <Divider className={styles.dividerBox}></Divider>
                              <Space
                                size={[8, 8]}
                                wrap
                                className={styles.cityBox}
                              >
                                {provinceItem?.children?.length > 0 &&
                                  provinceItem?.children.map(
                                    (cityItem: any, cityIndex: number) => {
                                      return (
                                        <Button
                                          size={'middle'}
                                          key={`cityIndex-${cityIndex}`}
                                          type={
                                            cityItem.check
                                              ? 'primary'
                                              : 'default'
                                          }
                                          onClick={() => {
                                            cityClick({
                                              cityKey: cityItem.value, //当前点击市按钮key
                                              anchorIndex:
                                                anchorItem.anchorIndex, //锚点列表下标
                                              provinceIndex, //省列表下标
                                              cityIndex, //市列表下标
                                            });
                                          }}
                                        >
                                          {cityItem.label}
                                        </Button>
                                      );
                                    },
                                  )}
                              </Space>
                            </div>
                          }
                          trigger="click"
                          getPopupContainer={(triggerNode) => {
                            return triggerNode.parentElement;
                          }}
                        >
                          <div
                            className={
                              selectNum > 0
                                ? styles.provinceBox +
                                  ' ' +
                                  styles.provinceBoxActive
                                : styles.provinceBox
                            }
                          >
                            <div className={styles.provinceText}>
                              {provinceItem.label}
                              {selectNum > 0 ? (
                                <div className={styles.provinceNum}>
                                  (
                                  {selectNum === provinceItem?.children?.length
                                    ? '全'
                                    : provinceItem?.selectNum}
                                  )
                                </div>
                              ) : null}
                            </div>

                            <DownOutlined />
                          </div>
                        </Popover>
                      );
                    },
                  )}
              </Space>
            </div>
          );
        })}
    </div>
  );
};

export default React.memo(TreeComponent);
