import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Dropdown, Tabs, Modal } from 'antd';
import type { MenuProps } from 'antd';
import { cloneDeep, isEmpty } from 'lodash';
import { PlusOutlined } from '@ant-design/icons';
import { useModel } from '@umijs/max';
import { getRootTree, tabOptions, carrierOther } from './config';
import { IDTypeItem, IrootCityData } from './types';
import Container from './container';
import styles from './index.less';

const DeadZoneTree = ({ visible, onOk, onCancel, data }) => {
  const { provinceCityList } = useModel('task');
  // 类型和锚点省市树合并后的树形列表,渲染所有tab
  const [tabList, setTabList] = useState<any[]>([]);
  //当前选中tab
  const [activeKey, setActiveKey] = useState<any>(undefined);
  // 是否支持新增tab
  const [hideAdd, setHideAdd] = useState(false);
  // 每个类型下数据汇总
  const [tabInfo, setTabInfo] = useState<any>({});
  // 初始化获取所有市的key和省数量,用于判断当前tab下所有的城市是否全选
  const rootData = useRef({});

  const treeList = cloneDeep(getRootTree(provinceCityList));

  //处理数据
  const handleList = (checkList: any, key: any, data: any) => {
    let provinceNum = 0;
    let rootProvinceNum = 0;

    //用于收集所有省份城市citycode信息
    let cityList: IrootCityData[] = [];
    cityList = cityList.concat(...treeList.map((item) => item.children));

    const list = treeList.map(
      (
        anchorItem, // 锚点循环
        anchorIndex,
      ) => ({
        ...anchorItem,
        anchorIndex,
        children: anchorItem.children.map((provinceItem: any) => {
          // 省列表循环
          rootProvinceNum++;
          const findItem = checkList?.find(
            (item) => item.value === provinceItem?.value,
          );
          // 获取当前省下选中的值
          if (!isEmpty(findItem)) {
            const selectedCitys = findItem?.children?.map(
              (cityItem) => cityItem.value,
            );
            // 判断是否在当前锚点下
            provinceNum++; //给类型添加省数量
            return {
              ...provinceItem,
              selectNum: selectedCitys?.length, //设置当前省下选中市数量
              children: provinceItem?.children?.map((cityItem: any) => {
                return {
                  ...cityItem,
                  check: !!selectedCitys?.includes(cityItem.value),
                };
              }),
            };
          }
          return {
            ...provinceItem,
            selectNum: 0, //设置当前省下选中市数量
          };
        }),
      }),
    );
    data[key] = {
      provinceNum, // 收集类型下省数量
      checkList, // 当前类型下选中的数据
    };
    rootData.current = { rootCityList: cityList, rootProvinceNum };
    return list;
  };

  // tab切换
  const onTabClick = (key: string) => {
    setActiveKey(key);
  };

  // 删除tab
  const tabAddDel = (targetKey: any, action: string) => {
    if (action !== 'add') {
      setHideAdd(tabList.length - 1 === tabOptions.length ? true : false);
      setTabInfo((pre: any) => {
        delete pre[targetKey];
        return { ...pre };
      });
      const list = tabList.filter((item) => item.value !== targetKey);
      setActiveKey(list[list.length - 1].value);
      setTabList(list);
    }
  };

  //新增tab
  const tabAdd = ({ value, label }: any) => {
    const children = treeList.map((item, anchorIndex) => {
      return { ...item, anchorIndex };
    });
    const add = {
      label,
      value,
      children: cloneDeep(children),
    };
    setActiveKey(value);
    setHideAdd(tabList.length + 1 === tabOptions.length ? true : false);
    setTabList((pre) => {
      return [...pre, add];
    });
    setTabInfo((pre: any) => {
      return { ...pre, [value]: { provinceNum: 0, checkList: [] } };
    });
  };

  // 修改当前类型下树形列表
  const updateTree = (data: any, index: number, key: number, info: any) => {
    setTabList((pre) => {
      pre[index].children = data;
      return [...pre];
    });
    setTabInfo((pre: any) => {
      pre[key] = info;
      return { ...pre };
    });
  };

  const items: MenuProps['items'] = useMemo(() => {
    if (tabList?.length > 0) {
      let tabKeyList = tabList.map((item) => item.value);
      const list = tabOptions
        .filter((item) => !tabKeyList.includes(item.value))
        .map((items) => {
          return {
            label: (
              <div
                key={`MenuProps${items.value}`}
                onClick={() => {
                  tabAdd(items);
                }}
              >
                {items.label}
              </div>
            ),
            key: items.value,
          };
        });
      return list || [];
    }
    return (
      tabOptions.map((items) => {
        return {
          label: (
            <div
              key={`MenuProps${items.value}`}
              onClick={() => {
                tabAdd(items);
              }}
            >
              {items.label}
            </div>
          ),
          key: items.value,
        };
      }) || []
    );
  }, [tabList]);

  // tab数据items列表
  const itemList = useMemo(() => {
    if (tabList.length === 0) return [];
    return tabList.map((item: IDTypeItem, index) => {
      // 当前选中的数量和选中值
      const info = tabInfo?.[Number(item.value)] || {};
      //省个数
      let provinceNum = info?.provinceNum || 0;
      //市个数
      let cityNum = 0;
      info?.checkList?.forEach((check) => {
        cityNum += check?.children?.length || 0;
      });
      //其他tab下，不展示
      if (Number(item.value) === carrierOther) {
        return {
          label: (
            <>
              <div className={styles.tabText}>{item.label}</div>
              <div>无法设置区域</div>
            </>
          ),
          closable: tabList.length === 1 ? false : true,
          children: <div className={styles['empty']}>其他无法设置区域</div>,
          key: item.value,
        };
      }
      return {
        label: (
          <div className={styles['tabHeader']}>
            <div className={styles.tabText}>{item.label}</div>
            <div>
              ({provinceNum}省{cityNum}市)
            </div>
          </div>
        ),
        closable: tabList.length === 1 ? false : true,
        children: (
          <Container
            treeList={cloneDeep(item.children)}
            tabInfo={info}
            typeIndex={index}
            typeItem={item}
            updateTree={updateTree}
            rootData={cloneDeep(rootData.current)}
          ></Container>
        ),
        key: item.value,
      };
    });
  }, [tabList]);

  //提交盲区配置
  const handleSubmit = () => {
    let limitData: any[] = [];
    //根据tab顺序，组装数据
    tabList.forEach((item) => {
      limitData.push({
        carrier: item.value,
        carrierDesc: tabOptions?.find((option) => option.value === item.value)
          ?.label,
        limitInfo: tabInfo[Number(item.value)]?.checkList,
      });
    });
    onOk(limitData);
  };

  const handleCancel = () => {
    onCancel();
  };

  useEffect(() => {
    if (!visible) {
      return;
    }
    //初始化生成树形结构树
    let list = [];
    //初始化接收类型下有多少选中，选中的省数据
    let info = {};
    // 后端返回数据为空时，需要默认枚举第一个数据
    if (data?.length === 0 && tabOptions.length > 0) {
      list = [
        {
          ...tabOptions[0],
          children: handleList([], tabOptions[0].value, info),
        },
      ];
    }
    if (data?.length > 0) {
      list =
        data.map((item) => {
          const obj = {
            ...item,
            value: item.carrier,
            label: item.carrierDesc,
            children: handleList(item.limitInfo, item.carrier, info),
          };
          delete obj.carrier;
          delete obj.limitInfo;
          return obj;
        }) || [];
    }
    setActiveKey(list?.[0]?.value);
    setTabInfo(info);
    setTabList(list);
  }, [visible]);

  return (
    <Modal
      title="盲区配置"
      open={visible}
      width={900}
      onOk={handleSubmit}
      onCancel={handleCancel}
      className={styles['deadZoneTree']}
    >
      <Tabs
        type="editable-card"
        items={itemList}
        className={styles['deadZoneTabs']}
        addIcon={
          <Dropdown trigger={['click']} menu={{ items }} placement="bottomLeft">
            <div className={styles['addIcon']}>
              <PlusOutlined />
            </div>
          </Dropdown>
        }
        onEdit={tabAddDel}
        hideAdd={hideAdd}
        activeKey={activeKey}
        onTabClick={onTabClick}
      ></Tabs>
    </Modal>
  );
};

export default DeadZoneTree;
