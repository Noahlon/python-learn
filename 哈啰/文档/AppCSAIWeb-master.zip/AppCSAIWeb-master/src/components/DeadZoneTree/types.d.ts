export interface IrootCityData {
  label: string;
  value: string;
  children?: {
    label: string;
    value: string;
  }[];
}

export interface IDRootData {
  rootCityList?: IrootCityData[];
  rootProvinceNum?: number;
}

export interface IDTabInfo {
  checkList?: any[];
  provinceNum?: number;
}

export interface IDTypeItem {
  label: string;
  value?: string;
  children?: any[];
}

export interface IDTreeItem {
  anchorIndex?: number;
  value: string;
  label: string;
  children: any[];
}

export interface IDCheckedData {
  cityKey?: number;
  anchorIndex: number;
  provinceIndex: number;
  cityIndex: number;
}

export interface IDAnchorItem {
  value?: string;
  anchorIndex?: number;
  children: any[];
}
