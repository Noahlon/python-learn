export const getRootTree = (dist) => {
  if (!dist || !Array.isArray(dist)) return [];
  let list = dist.sort(
    (e, t) => e.firstChar.charCodeAt(0) - t.firstChar.charCodeAt(0),
  );
  list = list.reduce((province: any, parent) => {
    let index = province.findIndex((e: any) => e.value === parent.firstChar),
      citys = {
        label: parent.label,
        value: parent.value,
      };
    if (parent?.children?.length) {
      Object.assign(citys, {
        children: parent.children,
      });
    }
    if (index !== -1) {
      province[index].children.push(citys);
    } else {
      province.push({
        value: parent.firstChar,
        children: [citys],
      });
    }
    return province;
  }, []);
  return list;
};

export const tabOptions = [
  {
    value: 1,
    label: '移动',
  },
  {
    value: 2,
    label: '联通',
  },
  {
    value: 3,
    label: '电信',
  },
  {
    value: 5,
    label: '未知',
  },
  {
    value: 6,
    label: '其他',
  },
];

export const carrierOther = 6;
