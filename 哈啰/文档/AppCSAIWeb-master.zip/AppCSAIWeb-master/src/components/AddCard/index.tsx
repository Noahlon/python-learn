import React from 'react';
import styles from './index.less';
import { Tag, Dropdown, Popconfirm } from 'antd';
import { MoreOutlined } from '@ant-design/icons';
import type { MenuProps } from 'antd';

interface PropsType {
  title: string;
  goodsCode: string;
  contacts: string;
  time: string;
  id: string | number;
  heightLight: any;
  flag: string;
  tag?: boolean;
  status?: number;
  codeType?: number;
  isShow2?: any;
  isShow?: any;
  delTenantToProps?: any;
  isBlack?: number;
  delBalck?: any;
  editAuth?: boolean;
}

const AddCard: React.FC<PropsType> = (props) => {
  const {
    tag,
    title,
    goodsCode,
    contacts,
    time,
    status,
    id,
    heightLight,
    flag,
    codeType,
    isShow2,
    isShow,
    delTenantToProps,
    isBlack,
    delBalck,
    editAuth,
  } = props;

  // 点击高亮
  const handleClick = () => {
    heightLight(id);
  };

  // 卡片编辑
  const editCard = () => {
    // 租户
    if (typeof isShow2 === 'function') {
      isShow2();
    }
    // 线路
    else if (typeof isShow === 'function') {
      isShow();
    }
  };

  // 删除
  const delCard = () => {
    return new Promise((resolve) => {
      // 租户
      if (typeof isShow2 === 'function') {
        delTenantToProps()?.then(() => {
          resolve(1);
        });
      }
      // 线路
      else if (typeof isShow === 'function') {
        // console.log('线路删除');
        delBalck()?.then(() => {
          resolve(1);
        });
      }
    });
  };

  let items: MenuProps['items'] = [
    editAuth
      ? {
          label: (
            <a href="#" onClick={editCard}>
              编辑
            </a>
          ),
          key: '0',
        }
      : null,
    !tag && editAuth
      ? {
          label: (
            <Popconfirm
              title="确认要删除吗？"
              onConfirm={delCard}
              placement="topRight"
            >
              <a href="#">删除</a>
            </Popconfirm>
          ),
          key: '1',
        }
      : null,
  ];

  return (
    <>
      <div
        className={`${styles.addCard} ${flag === id ? styles.active : ''}`}
        onClick={handleClick}
      >
        <div className={styles.title}>
          <h3>{title}</h3>
          {editAuth ? (
            <Dropdown menu={{ items }} trigger={['click']}>
              <MoreOutlined style={{ fontSize: '20px' }} />
            </Dropdown>
          ) : (
            <></>
          )}
        </div>
        <h4>
          {(() => {
            switch (codeType) {
              case 1:
                return '租户编号：';
              case 2:
                return '商户编号：';
              case 3:
                return '适用行业：';
              default:
                return '';
            }
          })()}
          {goodsCode}
        </h4>
        <h5>
          {isBlack === 1 ? '黑名单量：' : '联系人：'}
          {contacts}
        </h5>

        <div className={styles.createTime}>
          <p>创建时间：{time}</p>
          {tag ? (
            <Tag color={status === 1 ? 'green' : 'red'}>
              {status === 1 ? '合作中' : '已停止'}
            </Tag>
          ) : (
            <></>
          )}
        </div>
      </div>
    </>
  );
};

export default AddCard;
