import React, { useState, useEffect } from 'react';
import style from './style.less';

const timeList = [
  { index: 0, checked: false, time: '00:00 - 00:30', hour: '0' },
  { index: 1, checked: false, time: '00:30 - 01:00', hour: '1' },
  { index: 2, checked: false, time: '01:00 - 01:30', hour: '' },
  { index: 3, checked: false, time: '01:30 - 02:00', hour: '2' },
  { index: 4, checked: false, time: '02:00 - 02:30', hour: '' },
  { index: 5, checked: false, time: '02:30 - 03:00', hour: '3' },
  { index: 6, checked: false, time: '03:00 - 03:30', hour: '' },
  { index: 7, checked: false, time: '03:30 - 04:00', hour: '4' },
  { index: 8, checked: false, time: '04:00 - 04:30', hour: '' },
  { index: 9, checked: false, time: '04:30 - 05:00', hour: '5' },
  { index: 10, checked: false, time: '05:00 - 05:30', hour: '' },
  { index: 11, checked: false, time: '05:30 - 06:00', hour: '6' },
  { index: 12, checked: false, time: '06:00 - 06:30', hour: '' },
  { index: 13, checked: false, time: '06:30 - 07:00', hour: '7' },
  { index: 14, checked: false, time: '07:00 - 07:30', hour: '' },
  { index: 15, checked: false, time: '07:30 - 08:00', hour: '8' },
  { index: 16, checked: false, time: '08:00 - 08:30', hour: '' },
  { index: 17, checked: false, time: '08:30 - 09:00', hour: '9' },
  { index: 18, checked: false, time: '09:00 - 09:30', hour: '' },
  { index: 19, checked: false, time: '09:30 - 10:00', hour: '10' },
  { index: 20, checked: false, time: '10:00 - 10:30', hour: '' },
  { index: 21, checked: false, time: '10:30 - 11:00', hour: '11' },
  { index: 22, checked: false, time: '11:00 - 11:30', hour: '' },
  { index: 23, checked: false, time: '11:30 - 12:00', hour: '12' },
  { index: 24, checked: false, time: '12:00 - 12:30', hour: '' },
  { index: 25, checked: false, time: '12:30 - 13:00', hour: '13' },
  { index: 26, checked: false, time: '13:00 - 13:30', hour: '' },
  { index: 27, checked: false, time: '13:30 - 14:00', hour: '14' },
  { index: 28, checked: false, time: '14:00 - 14:30', hour: '' },
  { index: 29, checked: false, time: '14:30 - 15:00', hour: '15' },
  { index: 30, checked: false, time: '15:00 - 15:30', hour: '' },
  { index: 31, checked: false, time: '15:30 - 16:00', hour: '16' },
  { index: 32, checked: false, time: '16:00 - 16:30', hour: '' },
  { index: 33, checked: false, time: '16:30 - 17:00', hour: '17' },
  { index: 34, checked: false, time: '17:00 - 17:30', hour: '' },
  { index: 35, checked: false, time: '17:30 - 18:00', hour: '18' },
  { index: 36, checked: false, time: '18:00 - 18:30', hour: '' },
  { index: 37, checked: false, time: '18:30 - 19:00', hour: '19' },
  { index: 38, checked: false, time: '19:00 - 19:30', hour: '' },
  { index: 39, checked: false, time: '19:30 - 20:00', hour: '20' },
  { index: 40, checked: false, time: '20:00 - 20:30', hour: '' },
  { index: 41, checked: false, time: '20:30 - 21:00', hour: '21' },
  { index: 42, checked: false, time: '21:00 - 21:30', hour: '' },
  { index: 43, checked: false, time: '21:30 - 22:00', hour: '22' },
  { index: 44, checked: false, time: '22:00 - 22:30', hour: '' },
  { index: 45, checked: false, time: '22:30 - 23:00', hour: '23' },
  { index: 46, checked: false, time: '23:00 - 23:30', hour: '' },
  { index: 47, checked: false, time: '23:30 - 23:59', hour: '24' },
];
// const timeSlot = (step: number) => {
//   let timeArr = [] as any;
//   const date = new Date();
//   date.setHours(9); // 时分秒设置从零点开始
//   date.setSeconds(0);
//   date.setUTCMinutes(0);

//   const slotNum = (11 * 60) / step; // 算出多少个间隔
//   for (let f = 0; f <= slotNum; f++) {
//     let time = new Date(Number(date.getTime()) + Number(step * 60 * 1000 * f)); // 获取：零点的时间 + 每次递增的时间
//     let hour = '' as any,
//       sec = '' as any;
//     // eslint-disable-next-line @typescript-eslint/no-unused-expressions
//     time.getHours() < 10
//       ? (hour = '0' + time.getHours())
//       : (hour = time.getHours()); // 获取小时
//     // eslint-disable-next-line @typescript-eslint/no-unused-expressions
//     time.getMinutes() < 10
//       ? (sec = '0' + time.getMinutes())
//       : (sec = time.getMinutes()); // 获取分钟
//     timeArr.push({
//       index: f,
//       checked: true,
//       time: hour + ':' + sec,
//       hourTime: hour,
//     });
//   }
//   return timeArr;
// };

// const timeSlotOne = (hours: number, min: number, num: number, step: 30) => {
//   let timeArr = [] as string[];
//   const date = new Date();
//   date.setHours(hours); // 时分秒设置从零点开始
//   date.setSeconds(0);
//   date.setUTCMinutes(min);

//   const slotNum = (num * 60) / step; // 算出多少个间隔
//   for (let f = 0; f <= slotNum; f++) {
//     let time = new Date(Number(date.getTime()) + Number(step * 60 * 1000 * f)); // 获取：零点的时间 + 每次递增的时间
//     let hour = '' as any,
//       sec = '' as any;
//     // eslint-disable-next-line @typescript-eslint/no-unused-expressions
//     time.getHours() < 10
//       ? (hour = '0' + time.getHours())
//       : (hour = time.getHours()); // 获取小时
//     // eslint-disable-next-line @typescript-eslint/no-unused-expressions
//     time.getMinutes() < 10
//       ? (sec = '0' + time.getMinutes())
//       : (sec = time.getMinutes()); // 获取分钟
//     timeArr.push(hour + ':' + sec);
//   }
//   return timeArr;
// };

interface selectTimeRange {
  startTime?: string;
  endTime?: string;
}

const PhoneTime: React.FC<any> = (props) => {
  // let checkedRange = useRef([]);
  const { value, onChange } = props;
  const [data, setData] = useState(timeList);
  const [callDuration, setCallDuration] = useState([]);

  // 获取标签数据
  const getTagList = (list) => {
    const timeArray: selectTimeRange[] = [];
    let time: selectTimeRange = {};
    const checkedList = list.filter((e) => e.checked);
    for (let i = 0; i < checkedList.length; i++) {
      if (!time.startTime) {
        time.startTime = checkedList[i].time?.slice(0, 5);
      }
      if (
        (checkedList[i + 1] &&
          checkedList[i + 1]?.index - checkedList[i]?.index !== 1) ||
        i === checkedList.length - 1
      ) {
        time.endTime = checkedList[i].time?.slice(8, 13);
        timeArray.push({ ...time });
        time = {};
      }
    }
    return timeArray;
  };

  // 点击
  const handleClick = (e: { index: number; checked: boolean }) => {
    const { index, checked } = e;
    const list = data.map((e) => {
      return {
        ...e,
        checked: e.index === index ? !checked : e.checked,
      };
    });
    setData(list);
    const tags = getTagList(list);
    setCallDuration(tags);
    const checkedList = [...list].filter((e) => e.checked);
    if (checkedList.length) {
      const startTime = checkedList[0] ? checkedList[0]?.time?.slice(0, 5) : '';
      const endTime = checkedList[checkedList.length - 1]
        ? checkedList[checkedList.length - 1]?.time?.slice(8, 13)
        : '';
      onChange({ timeRange: [startTime, endTime], callDuration: tags });
    } else {
      onChange(undefined);
    }
  };

  const getValue = () => {
    if (Array.isArray(value?.callDuration)) {
      const callDurationTemp = JSON.parse(JSON.stringify(value?.callDuration));
      callDurationTemp.forEach((item) => {
        item.startTime = item.startTime.slice(0, 5);
        item.endTime = item.endTime.slice(0, 5);
      });
      setCallDuration(callDurationTemp);
      const timeData = JSON.parse(JSON.stringify(timeList));
      callDurationTemp.forEach((item) => {
        const firstItem = timeData.find(
          (i) => i.time?.slice(0, 5) === item.startTime,
        );
        if (firstItem) {
          const endItem =
            firstItem.time.slice(8, 13) === item.endTime
              ? firstItem
              : timeData.find((i) => i.time?.slice(8, 13) === item.endTime);
          timeData.forEach((i) => {
            if (
              (firstItem?.index < i.index || firstItem?.index === i.index) &&
              (i.index < endItem?.index || i.index === endItem?.index)
            ) {
              i.checked = true;
            }
          });
        }
      });
      setData(timeData);
    }
  };

  useEffect(() => {
    getValue();
  }, [value]);

  return (
    <>
      <div className={style.timeSlider}>
        <div className={style.timeWrap}>
          {data.map((e) => {
            return (
              <i
                className={e.checked ? style.active : ''}
                style={{ fontSize: 8 }}
                key={e.index}
                onClick={() => handleClick(e)}
              >
                {/* {e.index} */}
                <span
                  className={`${style.timeName}`}
                  style={{
                    transform: e.index === 0 ? 'translateX(-50%)' : '',
                  }}
                >
                  {/* {e.time === '09:00' || e.time === '20:00' ? e.time : e.hour} */}
                  {e.hour}
                </span>
              </i>
            );
          })}
        </div>
        <div className={style.info}>
          {callDuration.map((item) => (
            <div className={style.infoTag} key={item.startTime}>
              <span className={style.tagText}>
                {`${item.startTime} - ${item.endTime}`}
              </span>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default PhoneTime;
