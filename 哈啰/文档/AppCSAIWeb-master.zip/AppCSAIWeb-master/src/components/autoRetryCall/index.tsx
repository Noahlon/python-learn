import React, { useState, useEffect } from 'react';
import { Checkbox, InputNumber } from 'antd';
import style from './style.less';

const listArr = [
  {
    label: '第一次',
    value: 'first',
    checked: false,
    num: 0,
  },
  {
    label: '第二次',
    value: 'second',
    checked: false,
    num: 0,
  },
  {
    label: '第三次',
    value: 'third',
    checked: false,
    num: 0,
  },
];
const AutoRetryCall: React.FC<any> = (props) => {
  const [data, setData] = useState(listArr);
  const { value, onChange } = props;
  const handleChange = (e: any, value: string, type: string) => {
    let list: React.SetStateAction<
      { label: string; value: string; checked: boolean; num: number }[]
    > = [];
    if (type === 'checkbox') {
      list = data.map((item) => {
        return {
          ...item,
          checked: item?.value === value ? e.target.checked : item.checked,
        };
      });
    }
    if (type === 'input') {
      list = data.map((item) => {
        return {
          ...item,
          num: item?.value === value ? e : item.num,
        };
      });
    }
    onChange(list);
    setData(list);
  };
  const getValue = () => {
    if (value) {
      let valueList = [];
      if (Array.isArray(value)) {
        valueList = data.map((e) => {
          const firstObj = value.find((k) => k.value === 'first');
          const secondObj = value.find((k) => k.value === 'second');
          const thirdObj = value.find((k) => k.value === 'third');
          return {
            ...e,
            checked:
              e.value === 'first'
                ? firstObj.checked
                : e.value === 'second'
                ? secondObj.checked
                : e.value === 'third'
                ? thirdObj.checked
                : false,
            num:
              e.value === 'first'
                ? firstObj.num
                : e.value === 'second'
                ? secondObj.num
                : e.value === 'third'
                ? thirdObj.num
                : 0,
          };
        });
      } else {
        valueList = data.map((e) => {
          return {
            ...e,
            checked:
              e.value === 'first'
                ? !!value?.first
                : e.value === 'second'
                ? !!value?.second
                : e.value === 'third'
                ? !!value?.third
                : false,
            num:
              e.value === 'first'
                ? value?.first
                : e.value === 'second'
                ? value?.second
                : e.value === 'third'
                ? value?.third
                : false,
          };
        });
      }
      setData(valueList);
    } else {
      setData(listArr);
    }
  };
  useEffect(() => {
    getValue();
  }, [value]);
  return (
    <>
      <div className={style.autoCall}>
        {data.map((e) => {
          return (
            <div
              key={e.value}
              className={style.autoLine}
              style={{ marginBottom: '10px' }}
            >
              <Checkbox
                checked={e.checked}
                onChange={(i) => handleChange(i, e.value, 'checkbox')}
              >
                {e.label}
              </Checkbox>
              <div className={style.autoLine}>
                <div>间隔</div>
                <InputNumber
                  placeholder="1-600"
                  value={e.num}
                  onChange={(i) => handleChange(i, e.value, 'input')}
                  min={0}
                  style={{
                    width: '85px',
                    marginLeft: '10px',
                    marginRight: '8px',
                  }}
                />
                <div>min</div>
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
};

export default AutoRetryCall;
