import React, { useState, useEffect, useRef } from 'react';
import {
  Modal,
  Form,
  Input,
  Select,
  message,
  InputNumber,
  Tooltip,
  Collapse,
  Radio,
  Button,
  Row,
  Col,
  Popover,
  Checkbox,
  Tabs,
  Tag,
  Avatar,
  Table,
} from 'antd';
import moment from 'moment';
import { isEqual, cloneDeep } from 'lodash';
import { getList, getIntentionList } from '@/api/language';
import {
  createTask,
  updateTask,
  getTenantConcurrencytask,
  getTaskStrategyList,
  queryTaskLimitExt,
  queryTemplateLimitExt,
  ICarrierAreaLimit,
  ICarrierAreaLimitResponse,
  checkTaskVariable,
} from '@/api/taskCenter';
import {
  LinegroupObj,
  TenantLinegroupRes,
  queryTenantLinegroupPage,
  tenantList,
} from '@/api/tenantManage';
import { SmsTemplateObj, querySmsTemplate } from '@/api/smsTemplate';
import {
  CloseCircleOutlined,
  DownOutlined,
  InfoCircleOutlined,
  PlusOutlined,
  UpOutlined,
} from '@ant-design/icons';
import {
  taskTransferOpts,
  taskTypeOpts,
  listDataOpts,
  callbackOpts,
  callbackSelectList,
} from '@/pages/taskCenter/config';
import { accAdd, isIntegerBarringZero } from '@/utils';
import SmsPreView from '../smsPreview';
import AutoRetryCall from '@/pages/taskTemplate/components/autoRetryCall';
import PolicyTimeline from '@/pages/taskTemplate/components/policyTimeline';
import CallPeriods from '@/pages/taskTemplate/components/callPeriods';
import { useModel } from '@umijs/max';
import DeadZoneTree from '@/components/DeadZoneTree';
import { carrierOther } from '@/components/DeadZoneTree/config';
import { variableOpts } from '@/pages/speech/config';
import styles from './index.less';

const { Option } = Select;
const timeRangeDefault = {
  callDuration: [{ startTime: '09:00', endTime: '20:00' }],
  timeRange: ['09:00', '20:00'],
};

const callOrderOptions = [
  {
    label: '添加时间顺序呼叫',
    value: 1,
  },
  {
    label: '添加时间倒序呼叫',
    value: 2,
  },
];
const TaskModal: React.FC<any> = ({
  visible,
  cancel,
  record,
  onOKClick,
  modalType, // 1: 新增 2: 编辑
}) => {
  const [form] = Form.useForm();
  const layout = {
    labelCol: { span: 7 },
    wrapperCol: { span: 17 },
  };
  const [params] = useState({
    pageNum: 1,
    pageSize: 999,
  });
  const [tenant, setTenant] = useState([]);
  const [callLineList, setCallLineList] = useState([]);
  // 意向列表
  const [intentionClassifysList, setIntentionClassifysList] = useState([]);
  // 短信列表
  const [smsList, setSmsList] = useState([]);
  const [concurrency, setConcurrencty] = useState<number>(null);
  const [activeKey, setActiveKey] = useState<string[]>(['1']);
  const [activeKey2, setActiveKey2] = useState<string[]>(['2']);
  const [activeKey3, setActiveKey3] = useState<string[]>(['3']);
  const [editLoading, setEditLoading] = useState(false);
  const [smsPopoverOpen, setSmsPopoverOpen] = useState(false); // 短信气泡框显示
  const isHoverPopover = useRef(false); // 是否hover在短信气泡框上
  const [multipleSmsLink, setMultipleSmsLink] = useState<number>(0); // 千人千链checkbox
  // 短信气泡框内容
  const [currentSmsPopover, setCurrentSmsPopover] =
    useState<SmsTemplateObj>(undefined);

  //监听名单数据类型表单
  const showPhoneType = Form.useWatch('phoneType', form);
  const callbackSwitchType = Form.useWatch('callbackSwitch', form);

  //监听话术表单变化
  const faqGuidValue = Form.useWatch('groupIds', form);
  const [faqGroupValueIds, setFaqGroupIds] = useState([]);

  const [taskType, setTaskType] = useState<number>(0); //任务类型 1-长期 0-短期
  const [taskTab, setTaskTab] = useState<string>('1'); //1-基础信息 2-执行策略
  const timeLineRef = useRef<any>(null);

  const [limitZoneVisible, setLimitZoneVisible] = useState<boolean>(false);
  const [limitInfo, setLimitInfo] = useState<ICarrierAreaLimit[]>([]);
  const [errorIds, setErrorIds] = useState([]);

  const {
    cacheData,
    setCacheData,
    faqGuidList,
    setFaqGuidList,
    selectedFaqs,
    setSelectedFaqs,
    setUpdateIntention,
  } = useModel('task');
  const { fetchProvinceCityList } = useModel('common');
  const [formData, updateFormData] = useState<any>({});
  // 执行开始时间 和结束时间
  const [callDuration, setCallDuration] = useState([]);
  //判断是否初次载入
  const [isFirst, setFirst] = useState(true);

  // 呼叫次数据
  const [isCallbackSelectList, setIsCallbackSelectList] = useState<number>(0);

  // 预计可用30秒下发数
  const getConcurrencys = async (id: string) => {
    const { data } = await getTenantConcurrencytask({
      code: Number(form.getFieldValue('tenant') || record?.tenant),
      tenantLineGroupId: id,
    });
    setConcurrencty(data || 0);
  };

  // 验证话术是否存在
  const handleValidatorFaqGuid = async (rule, value) => {
    if (!value?.length) return Promise.reject('请选择话术');
    let res = Promise.resolve();
    value?.forEach((item) => {
      if (item?.groupId) {
        const zIndex = faqGuidList.findIndex(
          (i) => i.groupId === item?.groupId,
        );
        if (zIndex === -1)
          res = Promise.reject('存在执行话术找不到，请重新选择');
      }
    });
    return res;
  };

  // 验证话术分流
  const handleValidatorCount = async (rule, value) => {
    if (!value) return Promise.reject('请输入');
    if (!isIntegerBarringZero(value)) return Promise.reject('正整数');
    let res = Promise.resolve(); // Promise.reject('话术分流比之和不等于100');
    let isExistEmpty = false;
    let allCount = 0;
    const _list = form.getFieldValue('groupIds');
    if (_list?.length) {
      _list?.forEach((item) => {
        if (item?.count) {
          allCount = accAdd(allCount, item.count);
        } else {
          isExistEmpty = true;
        }
      });
    }
    if (!isExistEmpty && allCount !== 100)
      res = Promise.reject('话术分流比之和不等于100');
    return res;
  };

  // 意向分类验证
  const handleValidatorClassification = async (rule, value, index) => {
    const _list = form.getFieldValue('smsConfigs');
    if (_list?.length) {
      const flatList = _list.map((it) => it?.classification).filter(Boolean);
      const val = flatList[index];
      const isRepeat = flatList.indexOf(val) !== flatList.lastIndexOf(val);
      if (isRepeat) return Promise.reject('意向分类不能重复');
    }
    if (!value) return Promise.reject('请选择意向分类');
    return Promise.resolve();
  };

  // 意向分类change
  const handleClassificationChange = () => {
    const _smsConfigs = form.getFieldValue('smsConfigs');
    const value = _smsConfigs?.map((_, index) => [
      'smsConfigs',
      index,
      'classification',
    ]);
    if (!!value?.length) form.validateFields(value);
  };

  // 处理添加数据
  // 将时间字符串转换为分钟数以便比较
  const timeToMinutes = (timeStr) => {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours * 60 + minutes;
  };

  const minutesToTime = (minutes) => {
    const hours = Math.floor(minutes / 60);
    const minutesRemainder = minutes % 60;
    return `${hours.toString().padStart(2, '0')}:${minutesRemainder
      .toString()
      .padStart(2, '0')}`;
  };

  const getLastAndFirstTime = (timePeriods) => {
    let exeStartTime = null;
    let exeEndTime = null;
    timePeriods.forEach((period) => {
      const startMinutes = timeToMinutes(period.startTime);
      const endMinutes = timeToMinutes(period.endTime);

      // 如果earliestStartTime为空，或者当前startTime更早
      if (exeStartTime === null || startMinutes < exeStartTime) {
        exeStartTime = startMinutes;
      }

      // 如果latestEndTime为空，或者当前endTime更晚
      if (exeEndTime === null || endMinutes > exeEndTime) {
        exeEndTime = endMinutes;
      }
    });
    return {
      exeStartTime: minutesToTime(exeStartTime),
      exeEndTime: minutesToTime(exeEndTime),
    };
  };

  const renderVariableType = (type) => {
    const variable = variableOpts.find((item) => item.value === type);
    return variable?.label;
  };

  // 验证
  const handleValidatorRetry = async (rule, value) => {
    if (!value) return Promise.resolve();
    if (Array.isArray(value) && value.length) {
      for (let index = 0; index < value.length; index++) {
        if (value[index].checked) {
          if (
            !value[index].num ||
            Number(value[index].num) < 1 ||
            Number(value[index].num) > 600
          )
            return Promise.reject('时间间隔不能为空且在1-600分钟之间');
        }
      }
    } else {
      const nums = Object.values(value);
      for (let index = 0; index < nums.length; index++) {
        if (
          !nums[index] ||
          Number(nums[index]) < 1 ||
          Number(nums[index]) > 600
        )
          return Promise.reject('时间间隔不能为空且在1-600分钟之间');
      }
    }
    return Promise.resolve();
  };
  const updataForm = (val: any) => {
    let autoRetryJson = {} as any;
    let autoRetryLength = 0;
    let param, json;

    if (Array.isArray(val?.autoRetry)) {
      const autoRetry = val?.autoRetry!.filter((e) => e.checked);
      autoRetryLength = autoRetry.length;
      autoRetry.forEach((e) => {
        if (e.value === 'first') {
          autoRetryJson['first'] = e.num;
        }
        if (e.value === 'second') {
          autoRetryJson['second'] = e.num;
        }
        if (e.value === 'third') {
          autoRetryJson['third'] = e.num;
        }
      });
    } else {
      autoRetryJson = val?.autoRetry;
      if (autoRetryJson && Object.keys(autoRetryJson)?.length) {
        autoRetryLength = 1;
      }
    }

    let smsConfigsList = [];
    if (val?.smsConfigs?.length) {
      smsConfigsList = val.smsConfigs.map((item) => ({
        classification: item.classification,
        smsTemplateId: item.smsTemplateId,
      }));
    }

    //盲区配置
    let carrierAreaLimit = [];
    let _limitInfo = cloneDeep(limitInfo);
    if (_limitInfo?.length) {
      _limitInfo?.forEach((item) => {
        //其他运营商
        if (item.carrier === carrierOther) {
          carrierAreaLimit.push({
            carrier: item.carrier,
            limitInfo: [],
          });
        }
        if (item.carrier !== carrierOther && item?.limitInfo?.length > 0) {
          item?.limitInfo?.forEach((limit) => {
            //全选时，不需要传children
            if (limit.allCity === 1) {
              delete limit.children;
              delete limit.allCity;
            } else {
              delete limit.allCity;
            }
          });
          carrierAreaLimit.push({
            carrier: item.carrier,
            limitInfo: item?.limitInfo,
          });
        }
      });
    }

    //短期任务逻辑
    if (val.taskType === 0) {
      const { exeStartTime, exeEndTime } = getLastAndFirstTime(callDuration);

      json = { autoRetry: autoRetryJson, callDuration };
      if (smsConfigsList.length > 0) {
        json.smsConfigs = smsConfigsList;
      }

      const faqName = faqGuidList.find(
        (e: any) => e.groupId === val.groupIds?.[0]?.groupId,
      ) as any;
      const speechList = [];
      val.groupIds?.forEach((item) => {
        let _name = item.groupId;
        if (item.count && val.groupIds?.length > 1) _name += `:${item.count}`;
        speechList.push(_name);
      });
      param = {
        name: val?.name,
        exeStartTime: exeStartTime,
        exeEndTime: exeEndTime,
        expectLoadCount: val?.expectLoadCount,
        tenant: val?.tenant,
        faqGuid: speechList.join(','),
        autoRetry: autoRetryLength ? '1' : '0',
        ext: JSON.stringify(json),
        groupId: speechList.join(','),
        taskType: val.taskType,
        transfer: val.transfer,
        phoneType: val.phoneType,
        callbackSwitch: val.callbackSwitch,
        callbackCallTimes: val.callbackCallTimes,
        loadFlag: val.loadFlag,
        tenantLineGroupId: val.callLine,
        thirdBlacklistIntercept: val.thirdBlacklistIntercept,
        featureIntercept: val.featureIntercept,
        carrierAreaLimit,
      };
      if (record?.templateGuid) {
        param.templateGuid = record?.templateGuid;
        param.templateName = record?.templateName;
      }
      if (modalType === 2) {
        param.guid = record?.guid;
      }
      if (modalType === 1) {
        param.faqName = faqName?.speechName;
      }
    } else if (val.taskType === 1) {
      const strategyList =
        (timeLineRef.current && timeLineRef.current.getValue()) || cacheData;
      const _strategyList = cloneDeep(strategyList);
      //长期任务必须添加一条执行策略,编辑时不校验
      if (
        _strategyList?.length === 0 &&
        val.taskType === 1 &&
        modalType === 1
      ) {
        return message.error('请至少添加一条执行策略');
      }
      json = { autoRetry: autoRetryJson };
      if (smsConfigsList.length > 0) {
        json.smsConfigs = smsConfigsList;
      }
      _strategyList?.forEach((item) => {
        delete item.guid;
        delete item.groupIds;
        delete item.faqNames;
      });
      //长期任务
      param = {
        name: val?.name,
        expectLoadCount: val?.expectLoadCount,
        tenant: val?.tenant,
        ext: JSON.stringify(json),
        autoRetry: autoRetryLength ? '1' : '0',
        remark: val?.remark,
        taskName: val?.taskName,
        taskType: val.taskType,
        transfer: val.transfer,
        phoneType: val.phoneType,
        callbackSwitch: val.callbackSwitch,
        callbackCallTimes: val.callbackCallTimes,
        loadFlag: val.loadFlag,
        thirdBlacklistIntercept: val.thirdBlacklistIntercept,
        featureIntercept: val.featureIntercept,
        tenantLineGroupId: val.callLine,
        taskStrategyList: _strategyList,
        carrierAreaLimit,
      };
      if (modalType === 2) {
        param.guid = record?.guid;
        delete param.taskStrategyList;
      }
    }
    setEditLoading(true);
    setTimeout(() => {
      if (editLoading) setEditLoading(false);
    }, 5000);
    const action = modalType === 1 ? createTask : updateTask;
    action({ ...param, multipleSmsLink })
      .then((data: any) => {
        if (data?.success) {
          message.success('操作成功');
          form.setFieldsValue({
            name: '',
            groupIds: undefined,
            smsConfigs: undefined,
            autoRetry: undefined,
            callDuration: [],
            autoStartup: undefined,
          });
          setLimitInfo([]);
          onOKClick();
        } else {
          // message.error(data?.info ? data?.info : '操作失败');
        }
        setEditLoading(false);
      })
      .catch((e: any) => e)
      .finally(() => setEditLoading(false));
  };

  const handleClickUpdate = () => {
    let checkChain = false;
    if (form.getFieldValue('smsConfigs')) {
      const smsconfigs = form
        .getFieldValue('smsConfigs')
        ?.map((item) => item['smsTemplateId']);
      checkChain = smsList.some(
        (item) => smsconfigs.includes(item.id) && item.chainId,
      );
    }
    form.validateFields().then((val: any) => {
      if (taskTab === '2' && val.taskType === 1) {
        const name = form.getFieldValue('name');
        Object.assign(val, formData, { name });
      }
      if (checkChain && multipleSmsLink) {
        Modal.confirm({
          title: '关联的短信模版中插入的链接为短链，建议使用原始链接',
          content: '还要继续提交吗？',
          okText: '继续',
          cancelText: '取消',
          onOk() {
            updataForm(val);
          },
        });
      } else {
        updataForm(val);
      }
    });
  };
  // 获取外呼线路下拉列表
  const getCallLineList = (tenantCode: number) => {
    return new Promise<TenantLinegroupRes>((resolve, reject) => {
      queryTenantLinegroupPage({ tenantCode })
        .then((res) => {
          if (res.success) {
            setCallLineList(res.data);
            resolve(res);
          }
        })
        .catch((err) => {
          reject(err);
        });
    });
  };
  // 获取短信
  const getAllSmsTemplateData = async (val) => {
    if (!visible) return;
    const res = await querySmsTemplate({
      pageNum: 1,
      pageSize: 999,
      tenantList: [val],
    });
    if (res?.data) {
      setSmsList(res.data?.list);
    }
  };

  // 租户下拉关联话术和短信模版
  const handleChange = async (val) => {
    if (val) {
      // 切换租户清除关联的数据
      setConcurrencty(null);
      form.setFieldsValue({
        callLine: undefined,
        expectLoadCount: undefined,
        groupIds: undefined,
        smsConfigs: undefined,
      });

      //清空策略
      timeLineRef?.current?.clearList();
      setCacheData([]);
      if (taskType === 1) {
        setSelectedFaqs([]);
      }
      //将是否第一次进入置为false，切换到策略列表时，不再请求模板对应的策略列表
      //因为只有创建任务时才支持切换租户，因此不用考虑编辑场景，只针对通过模板创建长期任务的场景
      setFirst(false);

      getCallLineList(Number(val));
      getAllSmsTemplateData(val);
      const data = (await getList({
        pageSize: 999,
        pageNum: 1,
        tenant: val,
        status: 1,
        needSpeechVariable: 1,
      })) as any;
      if (data?.list && data?.list?.length) {
        setFaqGuidList(data?.list);
      } else {
        setFaqGuidList([]);
      }
    }
  };

  // 获取租户下拉列表
  const getTenantList = async () => {
    if (!visible) return;
    const { data } = await tenantList(params);
    setTenant(data);
  };

  // 获取意向分类下拉
  const getIntentionOpt = async (faqGroupGuids: string[] | null) => {
    if (!visible) return;
    if (!faqGroupGuids?.length) {
      setIntentionClassifysList([]);
      return;
    }

    const res = await getIntentionList({
      pageSize: 200,
      pageNum: 1,
      orderByName: true,
      speechGroupIdList: faqGroupGuids,
    });
    if (res) {
      setIntentionClassifysList(res);
    }
  };

  const labelView = () => {
    return (
      <Tooltip
        placement="topLeft"
        title="配置值为期望值，实际并发是根据租户线路情况进行锁定"
      >
        <InfoCircleOutlined style={{ marginRight: '10px' }} />
        <span>期望并发</span>
      </Tooltip>
    );
  };

  //任务类型切换
  const taskTypeChange = (e) => {
    setTaskType(e.target.value);
    setTaskTab('1');
    //切换长期任务
    if (e.target.value === 1) {
      setUpdateIntention(true);
      const strategyList = timeLineRef?.current?.getValue() || cacheData;
      const strategyListNewList = strategyList.filter(
        (item) => item?.status !== 30,
      );
      const faqGroupIds = strategyListNewList
        ?.map((item) => item?.faqGroupIds)
        ?.filter((item) => item);
      let ids = [];
      faqGroupIds.forEach((item) => {
        const groupIds = item?.split(',') || [];
        groupIds?.map((i) => ids.push(i?.split(':')[0]));
      });
      setSelectedFaqs([...new Set(ids.flat())]);
    } else {
      setSelectedFaqs(null);
    }
  };

  const onTabsChange = (e: string) => {
    //切换到执行策略时，对基础信息表单做必填校验，如果不通过不允许切换
    if (Number(e) === 2) {
      form.validateFields().then((data) => {
        updateFormData(data);
        setTaskTab(e);
      });
    } else if (Number(e) === 1) {
      //切换到基础信息时，存储当前执行策略列表
      setTaskTab(e);
      setActiveKey(['1']);
      setActiveKey2(['2']);
      setActiveKey3(['3']);
    }
  };
  const handleCountChange = () => {
    const _groupId = form.getFieldValue('groupIds');
    const value = _groupId?.map((item, index) => ['groupIds', index, 'count']);
    if (!!value?.length) form.validateFields(value);
  };

  // 添加时间段
  const handleAdd = (data: any) => {
    setCallDuration(data);
    form.setFieldsValue({ callDuration: data });
  };

  // 移除时间段
  const handleClose = (removedTag: { startTime }) => {
    const callDurationData = JSON.parse(JSON.stringify(callDuration));
    const newTags = callDurationData.filter(
      (tag) => tag.startTime !== removedTag.startTime,
    );
    setCallDuration(newTags);
    form.setFieldsValue({ callDuration: newTags });
  };

  // 鼠标移到挂机短信的某一行
  const handleSmsMouseEnter = (e, index: number) => {
    // 如果气泡框挡住了元素，就不显示气泡框
    if (isHoverPopover.current) {
      isHoverPopover.current = false;
      return;
    }

    // 判断鼠标是否在下拉框上（是就隐藏短信气泡框）
    const target = e.target?.getBoundingClientRect();
    const currentTarget = e.currentTarget?.getBoundingClientRect();
    if (Math.abs(target?.top - currentTarget?.top) > currentTarget?.height) {
      setSmsPopoverOpen(false);
      return;
    }

    const curSmsConfig = form.getFieldValue('smsConfigs')[index];
    const { classification, smsTemplateId } = curSmsConfig || {};
    const curSmsTemplate =
      smsList.find((item) => item.id === smsTemplateId) || {};

    curSmsTemplate.classification = classification;

    setCurrentSmsPopover(curSmsTemplate);
    setSmsPopoverOpen(true);
  };

  const setFormData = (key: string, data: any) => {
    Object.assign(formData, {
      key: data,
    });
  };

  const handleAutoCallChange = (data: []) => {
    setFormData('autoRetry', data);
  };

  const onChangeCheckbox = (e) => {
    setMultipleSmsLink(e.target.checked ? 1 : 0);
  };

  const closeLimit = (record: ICarrierAreaLimit) => {
    const info = limitInfo.filter((info) => info.carrier !== record.carrier);
    setLimitInfo(info);
  };

  const handleLimitOk = (info: ICarrierAreaLimit[]) => {
    setLimitZoneVisible(false);
    setLimitInfo(info);
  };

  const handleLimitCancel = () => {
    setLimitZoneVisible(false);
  };

  const handleLimitOpen = () => {
    setLimitZoneVisible(true);
  };

  //校验变量是否冲突
  const checkVariable = async (current, history) => {
    const res = await checkTaskVariable({
      speechList: current,
      historySpeechList: history,
    });
    return res;
  };

  const validateVariable = () => {
    const groupIds = form.getFieldValue('groupIds');
    const value = groupIds?.map((_, index) => ['groupIds', index, 'groupId']);
    if (!!value?.length) form.validateFields(value);
  };

  //渲染盲区信息
  const renderLimitInfo = (info: ICarrierAreaLimit) => {
    const { carrier, carrierDesc, limitInfo } = info;
    let cityNum = 0;
    limitInfo?.forEach((item) => {
      cityNum += item?.children?.length || 0;
    });
    if (Number(carrier) === carrierOther) {
      return carrierDesc + '： -';
    }
    return (
      carrierDesc + '：(' + limitInfo?.length + ') 省 (' + cityNum + ') 市'
    );
  };

  const renderVariable = (item) => {
    const columns = [
      {
        title: '变量名称',
        dataIndex: 'variableName',
        key: 'variableName',
        width: 120,
        render: (text) => {
          return <span className={styles['titleBox']}>{text}</span>;
        },
      },
      {
        title: '变量code',
        dataIndex: 'variableCode',
        key: 'variableCode',
        width: 150,
        render: (text, record) => {
          return (
            <span className={styles['titleBox']}>
              {[1, 8, 9, 10, 11].includes(record.variableType) ? '-' : text}
            </span>
          );
        },
      },
      {
        title: '变量类型',
        dataIndex: 'variableType',
        key: 'variableType',
        width: 100,
        render: (text) => {
          return (
            <span className={styles['titleBox']}>
              {renderVariableType(text)}
            </span>
          );
        },
      },
    ];
    return (
      <div onClick={(event) => event.preventDefault()}>
        <Table
          className={styles['tooltipTable']}
          columns={columns}
          dataSource={item?.speechVariableDTOList}
          pagination={false}
          showHeader={false}
          bordered
          scroll={{ y: 400 }}
        />
      </div>
    );
  };

  //监听选中话术变化
  useEffect(() => {
    if (!!visible) {
      getIntentionOpt(selectedFaqs);
    }
  }, [selectedFaqs]);

  //切换话术时，更新意向分类,针对短期任务
  useEffect(() => {
    if (!visible) return;
    const faqGroupGuids = faqGuidValue
      ?.map((item) => item.groupId)
      ?.filter((item) => item);

    //存在选中话术，且值发生了变化
    //如果话术发生了变化，需要校验是否存在变量冲突
    if (!isEqual(faqGroupGuids, faqGroupValueIds)) {
      if (!!faqGroupGuids?.length) {
        checkVariable(faqGroupGuids, []).then((res) => {
          if (res?.code === '0' && !!res?.data?.length) {
            setErrorIds(res?.data);
            validateVariable();
            message.error(
              '当前话术变量code对应名称或者类型和已选择的变量话术不一致，请重新选择',
            );
          } else if (res?.code === '0' && res?.data?.length === 0) {
            //校验通过
            setErrorIds([]);
            validateVariable();
          }
        });
      }
      setFaqGroupIds(faqGroupGuids);
      if (faqGroupGuids?.length) {
        getIntentionOpt(faqGroupGuids);
      } else if (faqGroupGuids?.length === 0) {
        getIntentionOpt([]);
      }
    }
  }, [faqGuidValue]);

  useEffect(() => {
    getTenantList();
    // getIntentionOpt();
    setCacheData([]);
    if (visible) {
      fetchProvinceCityList();
    }
    if (record?.tenant && visible) {
      handleChange(record?.tenant);
    } else {
      setFaqGuidList([]);
    }
    if (Object.keys(record).length && visible) {
      let ext: any = {};
      let _smsConfigs = [];
      try {
        ext = JSON.parse(record?.ext);
      } catch (error) {}
      if (ext) {
        //短期任务时，初始化拨打时段
        if (record.taskType === 0) {
          setCallDuration(ext?.callDuration);
        }
        if (ext?.smsConfigs?.length) {
          _smsConfigs = ext.smsConfigs.map((item) => {
            return {
              classification: item.classification,
              smsTemplateId: item.smsTemplateId,
            };
          });
        }
      }
      const name =
        modalType === 2
          ? record?.name
          : `${record?.taskName}${moment().format('YYYYMMDDHHmm')}`;
      const _groupIds = [];
      if (record?.groupId && record.taskType === 0) {
        const _speechList = record?.groupId?.split(',');
        _speechList?.forEach((item) => {
          const val = item?.split(':');
          _groupIds.push({ groupId: val?.[0], count: val?.[1] });
        });
      }
      setTaskType(record.taskType);
      setTaskTab('1');
      //判读如果是通过模板新增的话，需要请求模板策略列表
      if (record.templateGuid && !record.guid) {
        getTaskStrategyList({
          bizGuid: record.templateGuid,
          bizType: 2,
          queryScene: 1,
        }).then((res) => {
          if (res.success) {
            setCacheData(res?.data || []);
            if (record.taskType === 1) {
              const activeValidData = res?.data?.filter(
                (item) => item?.status !== 30,
              );
              const faqGroupIds = activeValidData.map(
                (item) => item?.faqGroupIds,
              );
              let ids = [];
              faqGroupIds.forEach((item) => {
                const groupIds = item?.split(',') || [];
                groupIds?.map((i) => ids.push(i?.split(':')[0]));
              });
              setUpdateIntention(false);
              setSelectedFaqs([...new Set(ids.flat())]);
            }
          }
        });
      } else if (record.guid && record.taskType === 1) {
        //长期任务编辑
        getTaskStrategyList({
          bizGuid: record.guid,
          bizType: 1,
        }).then((res) => {
          if (res.success) {
            setCacheData(res?.data || []);
            const activeValidData = res?.data?.filter(
              (item) => item?.status !== 30,
            );
            const faqGroupIds = activeValidData.map(
              (item) => item?.faqGroupIds,
            );
            let ids = [];
            faqGroupIds.forEach((item) => {
              const groupIds = item?.split(',') || [];
              groupIds?.map((i) => ids.push(i?.split(':')[0]));
            });
            setUpdateIntention(false);
            setSelectedFaqs([...new Set(ids.flat())]);
          }
        });
      }
      //如果是通过模版新增任务，需要根据模版id请求
      if (record.templateGuid && !record.guid) {
        queryTemplateLimitExt({ templateGuid: record.templateGuid }).then(
          (res: ICarrierAreaLimitResponse) => {
            if (res.code === '0') {
              setLimitInfo(res?.data?.carrierAreaLimit || []);
            }
          },
        );
      } else {
        //根据任务id请求盲区配置信息
        queryTaskLimitExt({ taskGuid: record.guid }).then(
          (res: ICarrierAreaLimitResponse) => {
            if (res.code === '0') {
              setLimitInfo(res?.data?.carrierAreaLimit || []);
            }
          },
        );
      }

      form.setFieldsValue({
        name: name,
        groupIds: _groupIds,
        smsConfigs: _smsConfigs,
        tenant: Number(record?.tenant) || undefined,
        autoStartup: record?.autoStartup!.toString(),
        autoRetry: ext?.autoRetry || {},
        callDuration: record.taskType === 0 ? ext?.callDuration : [],
        expectLoadCount: record.expectLoadCount,
        taskType: record.taskType,
        transfer: record.transfer,
        phoneType: record.phoneType,
        callbackSwitch: record.callbackSwitch,
        callbackCallTimes: record.callbackCallTimes,
        loadFlag: record.loadFlag,
        callLine: record.tenantLineGroupId,
        thirdBlacklistIntercept: record.thirdBlacklistIntercept,
        featureIntercept: record.featureIntercept,
      });
      // 是否展示呼叫次数
      if (record.callbackSwitch === 1) {
        setIsCallbackSelectList(1);
      } else {
        setIsCallbackSelectList(0);
      }

      if ([0, 1].includes(record?.multipleSmsLink)) {
        setMultipleSmsLink(record.multipleSmsLink);
      }

      if (record?.tenantLineGroupId) {
        getConcurrencys(record?.tenantLineGroupId);
      }
      // 高级配置设置了就展开
      if (record.transfer !== 0 || record.phoneType || record.loadFlag) {
        setActiveKey(['1']);
      } else {
        setActiveKey(undefined);
      }

      // 拦截配置设置了就展开
      if (
        record.thirdBlacklistIntercept !== 0 ||
        record.featureIntercept !== 0
      ) {
        setActiveKey3(['3']);
      } else {
        setActiveKey3(undefined);
      }
    } else {
      form.resetFields();
      setTaskType(0);
      setTaskTab('1');
      setCallDuration([]);
      setCacheData([]);
      setSelectedFaqs(null);
      setLimitInfo([]);
      setErrorIds([]);
      form.setFieldsValue({
        exeStartTime: timeRangeDefault,
        taskType: 0,
        transfer: 0,
        phoneType: 1,
        callbackSwitch: 0, // 未接通话单推送配置
        loadFlag: 1,
        groupIds: undefined,
        smsConfigs: undefined,
        thirdBlacklistIntercept: 0,
        featureIntercept: 0,
      });
      setMultipleSmsLink(0);
    }
  }, [visible]);

  return (
    <>
      <Modal
        title={
          modalType === 1
            ? '新增任务'
            : modalType === 2
            ? '编辑任务'
            : '查看任务'
        }
        open={visible}
        width={650}
        onOk={handleClickUpdate}
        onCancel={() => {
          cancel();
          form.resetFields();
          setActiveKey(['1']);
          setActiveKey2(['2']);
          setActiveKey3(['3']);
          setConcurrencty(0);
          setEditLoading(false);
          setCacheData([]);
          setSelectedFaqs([]);
          setIntentionClassifysList([]);
          setSmsList([]);
          setErrorIds([]);
          setFaqGroupIds([]);
          setLimitInfo([]);
          // 呼叫次数页面闭合时，不显示
          setIsCallbackSelectList(0);
        }}
        forceRender
        getContainer={false}
        confirmLoading={editLoading}
        // className={styles['taskEditModal']}
      >
        <Form form={form} {...layout}>
          <Form.Item
            label="选择租户"
            name="tenant"
            rules={[{ required: true }]}
          >
            <Select
              disabled={modalType !== 1}
              placeholder="请选择租户"
              onChange={handleChange}
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
              showSearch
              optionFilterProp="name"
              options={tenant}
              fieldNames={{ label: 'name', value: 'code' }}
            />
          </Form.Item>
          <Form.Item label="任务名称" name="name" rules={[{ required: true }]}>
            <Input maxLength={60} placeholder="请输入任务名称，限制60字" />
          </Form.Item>
          <Form.Item label="任务类型" name="taskType">
            <Radio.Group
              options={taskTypeOpts}
              optionType="button"
              disabled={modalType === 2}
              onChange={taskTypeChange}
            />
          </Form.Item>
          {taskType === 1 && (
            <Tabs
              activeKey={taskTab}
              onChange={onTabsChange}
              style={{ marginLeft: '58px' }}
              items={[
                {
                  label: '基础信息',
                  key: '1',
                },
                {
                  label: '执行策略',
                  key: '2',
                },
              ]}
            />
          )}
          {taskType === 0 && (
            <>
              <Form.Item
                label={<span className="notice">执行话术</span>}
                style={{ marginTop: '15px' }}
              >
                <Form.List
                  name="groupIds"
                  rules={[{ validator: handleValidatorFaqGuid }]}
                  initialValue={[]}
                >
                  {(fields, { add, remove }, { errors }) => (
                    <>
                      <Form.Item
                        noStyle
                        shouldUpdate={(prev, cur) =>
                          prev.groupIds !== cur.groupIds
                        }
                      >
                        <Button
                          onClick={() =>
                            add({
                              groupId: undefined,
                              count: undefined,
                            })
                          }
                          disabled={fields?.length > 4}
                          icon={<PlusOutlined />}
                          type="primary"
                          style={{ margin: '5px 0 20px 0' }}
                          size="small"
                        >
                          添加
                        </Button>
                      </Form.Item>

                      {fields.map(({ key, name }) => (
                        <Row key={name}>
                          {/**
                          * COl span 只有一条数据为 24 多条时为 24
                          */}
                          <Col span={fields?.length !== 1 ? 15 : 24}>
                            <Form.Item
                              noStyle
                              shouldUpdate={(prev, cur) =>
                                prev.groupIds !== cur.groupIds
                              }
                            >
                              {({ getFieldValue }) => {
                                const speechList = getFieldValue('groupIds');
                                const speechOpts = faqGuidList?.map((item) => {
                                  const _item = { ...item };
                                  const _index = speechList?.findIndex(
                                    (i) => i.groupId === item.groupId,
                                  );
                                  if (_index > -1 && _index !== key)
                                    _item.disabled = true;
                                  return _item;
                                });
                                return (
                                  <Form.Item
                                    style={{
                                      marginRight: '10px',
                                      marginBottom: 0,
                                    }}
                                    name={[name, 'groupId']}
                                    rules={[
                                      { required: true, message: '请选择' },
                                      {
                                        validator: (_, value) => {
                                          if (errorIds.includes(value)) {
                                            return Promise.reject(
                                              new Error(''),
                                            );
                                          }
                                          return Promise.resolve();
                                        },
                                      },
                                    ]}
                                  >
                                    <Select
                                      showSearch
                                      placeholder="请选择执行话术"
                                      getPopupContainer={(triggerNode) =>
                                        triggerNode.parentElement ||
                                        document.body
                                      }
                                      className={styles['speech-select']}
                                      filterOption={(input, option) =>
                                        (option?.label ?? '')
                                          .toLowerCase()
                                          .includes(input.toLowerCase())
                                      }
                                    >
                                      {speechOpts?.map((item) => (
                                        <Select.Option
                                          value={item.groupId}
                                          key={item.groupId}
                                          disabled={item.disabled}
                                          label={item.speechName}
                                        >
                                          {item?.isSpeechVariable === 1 ? (
                                            <Tooltip
                                              title={renderVariable(item)}
                                              color="white"
                                              placement="left"
                                              overlayInnerStyle={{
                                                width: 400,
                                                position: 'relative',
                                                right: 164,
                                              }}
                                              getPopupContainer={() =>
                                                document.getElementsByClassName(
                                                  'speech-select',
                                                )[0]?.parentElement ||
                                                document.body
                                              }
                                            >
                                              <Avatar
                                                size={22}
                                                style={{
                                                  backgroundColor: '#722ed1',
                                                  fontSize: 14,
                                                  marginRight: 5,
                                                }}
                                              >
                                                变
                                              </Avatar>
                                            </Tooltip>
                                          ) : null}
                                          {item.speechName}
                                        </Select.Option>
                                      ))}
                                    </Select>
                                  </Form.Item>
                                );
                              }}
                            </Form.Item>
                          </Col>
                          {fields?.length !== 1 && (
                            <>
                              <Col
                                span={2}
                                style={{
                                  margin: '5px 5px 0px 0px',
                                  textAlign: 'right',
                                }}
                              >
                                分流
                              </Col>
                              <Col span={4}>
                                <Form.Item
                                  style={{ marginRight: '5px' }}
                                  name={[name, 'count']}
                                  rules={[{ validator: handleValidatorCount }]}
                                >
                                  <Input
                                    allowClear
                                    onChange={handleCountChange}
                                  />
                                </Form.Item>
                              </Col>
                              <Col
                                span={1}
                                style={{ margin: '5px 5px 0px 0px' }}
                              >
                                %
                              </Col>
                            </>
                          )}
                          {!!key && (
                            <Col
                              span={1}
                              style={{
                                marginTop: '4px',
                                fontSize: '18px',
                                color: '#2d8cf0',
                              }}
                              onClick={() => {
                                remove(name);
                                // 删除之后重新计算百分比
                                setTimeout(() => {
                                  handleCountChange();
                                }, 50);
                              }}
                            >
                              <CloseCircleOutlined />
                            </Col>
                          )}
                        </Row>
                      ))}
                      <Form.ErrorList errors={errors} />
                    </>
                  )}
                </Form.List>
              </Form.Item>
              <Form.Item
                label="拨打时段"
                name="callDuration"
                rules={[{ required: true }]}
              >
                <CallPeriods
                  callDuration={callDuration || []}
                  handleClose={handleClose}
                  handleAdd={handleAdd}
                  taskType={taskType}
                />
              </Form.Item>
            </>
          )}
          {taskTab !== '2' && (
            <>
              <Form.Item
                label="自动补呼"
                name="autoRetry"
                style={{ marginBottom: '30px' }}
                rules={[{ validator: handleValidatorRetry }]}
              >
                <AutoRetryCall onChange={handleAutoCallChange} />
              </Form.Item>
              <Form.Item label="挂机短信" style={{ marginBottom: 0 }}>
                <Form.List name="smsConfigs" initialValue={[]}>
                  {(fields, { add, remove }) => (
                    <>
                      <Form.Item noStyle>
                        <Row justify="space-between">
                          <Col>
                            <Button
                              onClick={() =>
                                add({
                                  classification: undefined,
                                  smsTemplateId: undefined,
                                })
                              }
                              icon={<PlusOutlined />}
                              type="primary"
                              style={{ margin: '5px 0 20px 0' }}
                              size="small"
                            >
                              添加
                            </Button>
                          </Col>
                          <Row justify="end">
                            <Col>
                              <Checkbox
                                checked={!!multipleSmsLink}
                                onChange={onChangeCheckbox}
                              >
                                千人千链
                              </Checkbox>
                            </Col>
                            <Col
                              onMouseEnter={() => {
                                isHoverPopover.current = true;
                              }}
                            >
                              <Popover
                                overlayClassName="smsConfigsPopover"
                                open={smsPopoverOpen}
                                content={
                                  <SmsPreView curSms={currentSmsPopover} />
                                }
                                getPopupContainer={(triggerNode) =>
                                  triggerNode.parentElement || document.body
                                }
                                placement="rightTop"
                              >
                                <div style={{ height: '22px' }} />
                              </Popover>
                            </Col>
                          </Row>
                        </Row>
                      </Form.Item>
                      {fields.map(({ key, name }) => (
                        <Row
                          key={key}
                          style={{
                            marginBottom: '24px',
                          }}
                        >
                          <Col
                            span={22}
                            onMouseEnter={(e) => handleSmsMouseEnter(e, name)}
                            onMouseLeave={() => setSmsPopoverOpen(false)}
                          >
                            <Row>
                              <Col span={10}>
                                <Form.Item
                                  noStyle
                                  shouldUpdate={(prevValues, curValues) => {
                                    return (
                                      prevValues.smsConfigs !==
                                      curValues.smsConfigs
                                    );
                                  }}
                                >
                                  {() => (
                                    <Form.Item
                                      label="意向分类"
                                      colon={false}
                                      style={{
                                        marginRight: '10px',
                                        marginBottom: 0,
                                      }}
                                      name={[name, 'classification']}
                                      rules={[
                                        {
                                          validator: (rule, value) =>
                                            handleValidatorClassification(
                                              rule,
                                              value,
                                              name,
                                            ),
                                        },
                                      ]}
                                    >
                                      <Select
                                        showSearch
                                        placeholder="请选择"
                                        getPopupContainer={(triggerNode) =>
                                          triggerNode.parentElement ||
                                          document.body
                                        }
                                        fieldNames={{
                                          label: 'classification',
                                          value: 'classification',
                                        }}
                                        options={intentionClassifysList}
                                        onChange={handleClassificationChange}
                                        onDropdownVisibleChange={() =>
                                          setSmsPopoverOpen(false)
                                        }
                                      />
                                    </Form.Item>
                                  )}
                                </Form.Item>
                              </Col>
                              <Col span={14}>
                                <Form.Item
                                  name={[name, 'smsTemplateId']}
                                  rules={[
                                    {
                                      required: true,
                                      message: '请选择短信模版',
                                    },
                                  ]}
                                  style={{
                                    marginBottom: 0,
                                  }}
                                >
                                  <Select
                                   showSearch
                                   filterOption={(input, option) =>
                                     option.templateName
                                       .toLowerCase()
                                       .includes(input.toLowerCase())
                                   }
                                    options={smsList}
                                    fieldNames={{
                                      label: 'templateName',
                                      value: 'id',
                                    }}
                                    getPopupContainer={(triggerNode) =>
                                      triggerNode.parentElement || document.body
                                    }
                                    placeholder={'请选择短信模版'}
                                    onDropdownVisibleChange={() =>
                                      setSmsPopoverOpen(false)
                                    }
                                  />
                                </Form.Item>
                              </Col>
                            </Row>
                          </Col>
                          <Col
                            span={1}
                            style={{
                              margin: '4px 0 0 5px',
                              fontSize: '18px',
                              color: '#2d8cf0',
                              cursor: 'pointer',
                            }}
                            onClick={() => {
                              remove(name);
                              handleClassificationChange();
                            }}
                          >
                            <CloseCircleOutlined />
                          </Col>
                        </Row>
                      ))}
                    </>
                  )}
                </Form.List>
              </Form.Item>
              {/* 线路配置 */}
              <Collapse
                ghost
                activeKey={activeKey2}
                expandIconPosition="end"
                expandIcon={(panelProps) =>
                  panelProps?.isActive ? <DownOutlined /> : <UpOutlined />
                }
                onChange={(val: string[]) => setActiveKey2(val)}
              >
                <Collapse.Panel
                  header="线路配置"
                  key="2"
                  className={styles.collapse}
                >
                  <Form.Item
                    label="外呼线路"
                    name="callLine"
                    rules={[{ required: true }]}
                  >
                    <Select
                      showSearch
                      placeholder="请选择外呼线路"
                      onChange={getConcurrencys}
                      getPopupContainer={(triggerNode) =>
                        triggerNode.parentElement || document.body
                      }
                    >
                      {callLineList?.map((data: LinegroupObj) => (
                        <Option
                          value={data.tenantLineGroupId}
                          key={data.tenantLineGroupCode}
                        >
                          {data.tenantLineGroupName}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                  <Form.Item noStyle>
                    <Form.Item
                      label={labelView()}
                      name="expectLoadCount"
                      style={{ margin: '0' }}
                      rules={[{ required: true, message: '请输入' }]}
                    >
                      <InputNumber
                        min={1}
                        max={100000}
                        style={{
                          width: '196px',
                        }}
                      />
                    </Form.Item>
                    <div
                      style={{
                        margin: '5px 0 15px 140px',
                        color: '#999',
                        height: '22px',
                      }}
                    >
                      {concurrency
                        ? `预计可用并发${concurrency}`
                        : '无可用并发'}
                    </div>
                  </Form.Item>
                </Collapse.Panel>
              </Collapse>
              {/* 高级配置 */}
              <Collapse
                ghost
                activeKey={activeKey}
                expandIconPosition="end"
                expandIcon={(panelProps) =>
                  panelProps?.isActive ? <DownOutlined /> : <UpOutlined />
                }
                onChange={(val: string[]) => setActiveKey(val)}
              >
                <Collapse.Panel
                  header="高级配置"
                  key="1"
                  className={styles.collapse}
                >
                  <Form.Item
                    label="名单数据类型"
                    name="phoneType"
                    help={
                      showPhoneType === 2 ? (
                        <div style={{ color: '#ff4d4f' }}>
                          密文手机号场景下，短信配置不生效，请知晓
                        </div>
                      ) : null
                    }
                  >
                    <Radio.Group
                      disabled={modalType === 2}
                      options={listDataOpts}
                      optionType="button"
                    />
                  </Form.Item>
                  <Form.Item label="接通后转接" name="transfer">
                    <Radio.Group
                      options={taskTransferOpts}
                      optionType="button"
                    />
                  </Form.Item>
                  <Form.Item label="呼叫顺序" name="loadFlag">
                    <Select
                      showSearch
                      placeholder="请选择呼叫顺序"
                      getPopupContainer={(triggerNode) =>
                        triggerNode.parentElement || document.body
                      }
                      filterOption={(input, option) =>
                        (option?.label ?? '')
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                      options={callOrderOptions}
                    />
                  </Form.Item>
                  <Form.Item
                    label="未接通话单推送配置"
                    name="callbackSwitch"
                    help={
                      callbackSwitchType === 1 ? (
                        <div style={{ color: '#ff4d4f' }}>
                          租户首次使用请联系余绵辉或陈康康针对租户进行配置
                        </div>
                      ) : null
                    }
                  >
                    <Radio.Group
                      onChange={(val) =>
                        setIsCallbackSelectList(val.target.value)
                      }
                      options={callbackOpts}
                      optionType="button"
                    />
                  </Form.Item>
                  {isCallbackSelectList === 1 && (
                    <Form.Item
                      label={
                        <>
                          <Tooltip
                            placement="top"
                            title="满足配置的呼叫次数且外呼结果为非接通的话单会进行推送"
                          >
                            <InfoCircleOutlined />
                          </Tooltip>
                          呼叫次数
                        </>
                      }
                      rules={[
                        {
                          required: true,
                          message: '请选择呼叫次数',
                        },
                      ]}
                      name="callbackCallTimes"
                    >
                      <Select
                        mode="multiple"
                        placeholder="请选择"
                        allowClear
                        options={callbackSelectList}
                      />
                    </Form.Item>
                  )}
                  {/* 盲区设置 */}
                  <Form.Item label="呼叫盲区" name="carrierAreaLimit">
                    <Button type="primary" onClick={handleLimitOpen}>
                      编辑
                    </Button>
                    <div className={styles['limitList']}>
                      {limitInfo?.map((item: ICarrierAreaLimit) => {
                        return (
                          <div key={item.carrier} className={styles['tagItem']}>
                            <Tag closable onClose={() => closeLimit(item)}>
                              {renderLimitInfo(item)}
                            </Tag>
                          </div>
                        );
                      })}
                    </div>
                  </Form.Item>
                </Collapse.Panel>
              </Collapse>
              {/* 拦截配置 */}
              <Collapse
                ghost
                activeKey={activeKey3}
                expandIconPosition="end"
                expandIcon={(panelProps) =>
                  panelProps?.isActive ? <DownOutlined /> : <UpOutlined />
                }
                onChange={(val: string[]) => setActiveKey3(val)}
              >
                <Collapse.Panel
                  header="拦截配置"
                  key="3"
                  className={styles.collapse}
                >
                  <Form.Item label="外部黑名单" name="thirdBlacklistIntercept">
                    <Radio.Group
                      options={taskTransferOpts}
                      optionType="button"
                    />
                  </Form.Item>
                  <Form.Item label="规则拦截" name="featureIntercept">
                    <Radio.Group
                      options={taskTransferOpts}
                      optionType="button"
                    />
                  </Form.Item>
                </Collapse.Panel>
              </Collapse>
            </>
          )}
          {taskTab === '2' && taskType === 1 && (
            <PolicyTimeline
              guid={record.guid}
              bizType={1}
              ref={timeLineRef}
              modalType={modalType}
              templateGuid={record?.templateGuid}
              isFirst={isFirst}
              setFirst={setFirst}
            />
          )}
        </Form>
        {limitZoneVisible && (
          <DeadZoneTree
            visible={limitZoneVisible}
            onCancel={handleLimitCancel}
            onOk={handleLimitOk}
            data={cloneDeep(limitInfo)}
          />
        )}
      </Modal>
    </>
  );
};

export default TaskModal;
