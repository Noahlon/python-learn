import { Button, Input, Popover, Space } from 'antd';
import React, { ReactNode, useEffect, useState } from 'react';
import styles from './index.less';

interface Prop {
  children: ReactNode;
  value: string;
  onOk: (value: string) => void;
}

const PopoverInput: React.FC<Prop> = ({ children, value, onOk }) => {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState('');

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen);
  };

  const handleTextChange = (val: string) => {
    setText(val);
  };

  useEffect(() => {
    if (open) {
      setText(value);
    }
  }, [open, value]);

  const popoverContent = (
    <div className={styles.filterBox}>
      <Input
        placeholder="请输入"
        allowClear
        value={text}
        onChange={(e) => handleTextChange(e.target.value)}
      />
      <div className={styles.bottom}>
        <Space>
          <Button onClick={() => setOpen(false)}>取消</Button>
          <Button
            type="primary"
            onClick={() => {
              onOk(text);
              setOpen(false);
            }}
          >
            确定
          </Button>
        </Space>
      </div>
    </div>
  );

  return (
    <Popover
      open={open}
      onOpenChange={handleOpenChange}
      content={popoverContent}
      trigger={'click'}
      placement="bottom"
      overlayClassName={styles.filterOverlayWrap}
    >
      {children}
    </Popover>
  );
};

export default PopoverInput;
