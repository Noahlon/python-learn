import { Button, InputNumber, Popover, Space, message } from 'antd';
import React, { ReactNode, useEffect, useState } from 'react';
import styles from './index.less';

interface Prop {
  children: ReactNode;
  startValue: number;
  endValue: number;
  onOk: (start: number, end: number) => void;
}

const PopoverInputNumber2: React.FC<Prop> = ({
  children,
  onOk,
  startValue,
  endValue,
}) => {
  const [open, setOpen] = useState(false);
  const [num1, setNum1] = useState<number>();
  const [num2, setNum2] = useState<number>();

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen);
  };

  const handleSubmit = () => {
    if (typeof num1 === 'number' && typeof num2 === 'number' && num1 > num2) {
      message.error('起始数字不能大于结束数字');
      return;
    }
    setOpen(false);
    onOk(num1, num2);
  };

  useEffect(() => {
    if (open) {
      setNum1(startValue);
      setNum2(endValue);
    }
  }, [open, startValue, endValue]);

  const popoverContent = (
    <div className={styles.filterBox}>
      <Space size="middle">
        <InputNumber
          placeholder="请输入"
          min={0}
          value={num1}
          className={styles.input}
          onChange={(num) => setNum1(num)}
        />
        -
        <InputNumber
          placeholder="请输入"
          min={0}
          value={num2}
          className={styles.input}
          onChange={(num) => setNum2(num)}
        />
      </Space>
      <div className={styles.bottom}>
        <Space>
          <Button onClick={() => setOpen(false)}>取消</Button>
          <Button type="primary" onClick={handleSubmit}>
            确定
          </Button>
        </Space>
      </div>
    </div>
  );

  return (
    <Popover
      open={open}
      onOpenChange={handleOpenChange}
      content={popoverContent}
      trigger={'click'}
      placement="bottom"
      overlayClassName={styles.filterOverlayWrap}
    >
      {children}
    </Popover>
  );
};

export default PopoverInputNumber2;
