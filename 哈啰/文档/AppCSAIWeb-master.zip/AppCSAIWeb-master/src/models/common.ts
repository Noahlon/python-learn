import { useState } from 'react';
import { getTenantList, getTenantVersionList } from '@/api/tenant';
import { getBizTreeList } from '@/api/biz';
import { getProvinceCityList } from '@/api/common';

const Common = () => {
  const [tenantOpts, setTenantOpts] = useState([]); // 租户opts
  const [bizTree, setBizTree] = useState([]); // 行业多级opts
  const [DISTRICTS, setDISTRICTS] = useState([]);

  // fetch租户数据
  const fetchTenantOpts = async (bpoVersion?: number) => {
    const params = { pageNum: 1, pageSize: 999 };
    let res;
    if (bpoVersion) {
      Object.assign(params, { transferVersion: bpoVersion });
      res = await getTenantVersionList(params);
    } else {
      res = await getTenantList(params);
    }
    if (res?.data?.length) {
      const opts = res.data.map((item) => ({
        label: item.name,
        value: item.code,
      }));
      setTenantOpts(opts);
    }
  };

  // fetch行业数据
  const fetchBizTreeOpts = async (bpoVersion?: number) => {
    const params = { includeScene: true };
    if (bpoVersion) {
      Object.assign(params, { bpoVersion: bpoVersion });
    }
    const res = await getBizTreeList(params);
    setBizTree(res?.data || []);
  };

  // 获取省市区域
  const fetchProvinceCityList = async () => {
    const res = await getProvinceCityList();
    setDISTRICTS(res);
  };

  return {
    tenantOpts,
    setTenantOpts,
    fetchTenantOpts,
    bizTree,
    fetchBizTreeOpts,
    fetchProvinceCityList,
    DISTRICTS,
  };
};

export default Common;
