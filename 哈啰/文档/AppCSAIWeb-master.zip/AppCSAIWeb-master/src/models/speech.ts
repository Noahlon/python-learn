// 流程图数据

import { getBizTreeList } from '@/api/biz';
import { getCallResultList, ICallResult } from '@/api/call';
import {
  getIntentionLabelList,
  getIntentionList,
  IBreak,
  Intention,
  IntentionLabel,
  queryBreakList,
} from '@/api/language';
import {
  getSpeechVariable,
  ISpeechInfo,
  IVariable,
  ISpeechVersionTabData,
} from '@/api/speech';
import { useCallback, useState } from 'react';
import moment, { Moment } from 'moment';

export interface Option {
  value: string;
  label: string;
  children?: Option[];
  disabled?: true;
}

const Speech = () => {
  // 标签数据
  const [labelList, setLabelList] = useState<IntentionLabel[]>(null);
  const [variableList, setVariableList] = useState<IVariable[]>([]);
  const [bizList, setBizList] = useState<Option[]>([]);
  const [intentionClassifysList, setIntentionClassifysList] = useState<
    Intention[]
  >([]);
  const [breakOptions, setBreakOptions] = useState<IBreak[]>([]);
  const [parentTab, setParentTab] = useState('1');
  const [statusLabel, setStatusLabel] = useState(null);
  const [isVisiable, setIsVisiable] = useState(null);
  const [btnHeight, setBtnHeight] = useState(250);
  const [isDraft, setIsDraft] = useState(null);
  const [speechInfo, setSpeechInfo] = useState<ISpeechInfo>();
  const [callResultList, setCallResultList] = useState<ICallResult[]>([]);
  const [statisticQueryTime, setStatisticQueryTime] = useState<
    [Moment, Moment]
  >([
    moment('00:00:00', 'HH:mm:ss').subtract(6, 'days'),
    moment('23:59:59', 'HH:mm:ss'),
  ]);
  const [statisticQueryVersion, setStatisticQueryVersion] = useState(undefined);
  // 话术列表queryParams
  const [speechQueryParams, setSpeechQueryParams] = useState({});
  //当前选中的tab详情数据
  const [currentTabData, setCurrentTabData] = useState<ISpeechVersionTabData>(
    {},
  );
  // 是否需要监听页面
  const [isListeningPage, setIsListeningPage] = useState(true);
  // 获取标签列表
  const handleGetLabelList = async (speechGuid: string) => {
    const res = await getIntentionLabelList({
      pageSize: 200,
      pageNum: 1,
      speechGuid,
    });
    if (res) {
      const _list = res?.map((item) => ({
        desc: item.labelName,
        code: item.code,
      }));
      setLabelList(_list);
      return _list;
    }
    return [];
  };

  // 获取变量列表
  const handleGetVariableList = async (speechGuid: string) => {
    const res = await getSpeechVariable({
      speechGuid,
    });
    if (res?.data) {
      setVariableList(res.data);
      return res.data;
    } else {
      setVariableList([]);
    }
    return [];
  };

  // 转换行业
  const getBizOpts = (list) => {
    const opts = list?.map((item) => {
      return {
        value: item.id,
        label: item.name,
        children: item.children?.length ? getBizOpts(item.children) : undefined,
      };
    });
    return opts;
  };

  // 获取行业列表
  const handleGetBizList = useCallback(async () => {
    const res = await getBizTreeList({ includeScene: true });
    const opts = getBizOpts(res?.data);
    if (opts?.length) setBizList(opts);
    return [];
  }, []);

  // 获取话术意向分类下拉
  const getClassifysList = async (speechGuid: string) => {
    const res = await getIntentionList({
      pageSize: 200,
      pageNum: 1,
      speechGuid,
      orderByName: true,
    });
    if (res) {
      setIntentionClassifysList(res);
    }
  };

  // 获取打断数据
  const getBreakList = useCallback(async () => {
    const res = await queryBreakList();
    if (res.data) {
      // const opts = res.data.map((item) => ({
      //   label: item.desc,
      //   value: item.type,
      // }));
      setBreakOptions(res.data);
    }
  }, []);

  // 获取通话结果
  const handleCallResultList = useCallback(async () => {
    const res = await getCallResultList();
    if (res?.data) {
      const opts = res?.data.map((item) => ({
        label: item.desc,
        value: item.status,
      }));
      setCallResultList(opts);
    }
  }, []);

  return {
    labelList,
    handleGetLabelList,
    setLabelList,
    variableList,
    setVariableList,
    handleGetVariableList,
    bizList,
    isVisiable,
    isDraft,
    setIsDraft,
    setIsVisiable,
    handleGetBizList,
    parentTab,
    statusLabel,
    setStatusLabel,
    setParentTab,
    intentionClassifysList,
    setIntentionClassifysList,
    getClassifysList,
    breakOptions,
    getBreakList,
    speechInfo,
    setSpeechInfo,
    callResultList,
    btnHeight,
    setBtnHeight,
    handleCallResultList,
    statisticQueryTime,
    setStatisticQueryTime,
    statisticQueryVersion,
    setStatisticQueryVersion,
    speechQueryParams,
    setSpeechQueryParams,
    currentTabData,
    setCurrentTabData,
    isListeningPage,
    setIsListeningPage,
  };
};

export default Speech;
