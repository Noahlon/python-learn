// 租户相关数据

import { useState } from 'react';

const Tenant = () => {
  const [callbackRuleList, setCallbackRuleList] = useState([]);

  return {
    callbackRuleList,
    setCallbackRuleList,
  };
};

export default Tenant;
