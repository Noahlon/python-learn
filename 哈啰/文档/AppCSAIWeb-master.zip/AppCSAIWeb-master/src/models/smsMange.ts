import { useState } from 'react';
import { queryTemplateVariable } from '@/api/smsTemplate';

const SmsManage = () => {
  // 短信模版---当前templateId
  const [templateId, setTemplateId] = useState<string>();
  // 短信模版---变量列表
  const [tempVariableList, setTempVariableList] = useState([]);
  const [urlContent, setUrlContent] = useState('');
  // 通道--变量列表
  const [channelVariableList, setChannelVariableList] = useState([]);
  // 通道--链接内容
  const [channelUrlContent, setChannelUrlContent] = useState('');
  //短信模板下的通道列表支持复制，存储当前模板id
  const [currentCopyTemplateId, setCurrentCopyTemplateId] = useState('');
  // 短信模版---变量链接列表
  const [tempVariableUrlList, setTempVariableUrlList] = useState([]);
  // 通道---变量链接列表
  const [channelVariableUrlList, setChannelVariableUrlList] = useState([]);

  // 获取模版变量列表
  const getTempVariableList = async (templateId: string) => {
    const res = await queryTemplateVariable({
      templateId,
    });
    if (res?.data) {
      setTempVariableList(res.data);
      return res.data;
    }
  };

  // 获取模版变量链接列表(查询文本类型4的数据)
  const getTempVariableUrlList = async (templateId: string) => {
    const res = await queryTemplateVariable({
      templateId,
      variableType: 4,
    });
    if (res?.code === '0') {
      setTempVariableUrlList(res.data);
      return res.data;
    }
  };

  return {
    templateId,
    setTemplateId,
    tempVariableList,
    setTempVariableList,
    getTempVariableList,
    urlContent,
    setUrlContent,
    channelVariableList,
    setChannelVariableList,
    channelUrlContent,
    setChannelUrlContent,
    currentCopyTemplateId,
    setCurrentCopyTemplateId,
    tempVariableUrlList,
    getTempVariableUrlList,
    channelVariableUrlList,
    setChannelVariableUrlList,
    setTempVariableUrlList,
  };
};

export default SmsManage;
