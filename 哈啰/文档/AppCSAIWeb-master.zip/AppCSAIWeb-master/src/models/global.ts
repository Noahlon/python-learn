// 全局共享数据示例
import { DEFAULT_NAME } from '@/constants';
import ssoAuth from '@hb/sso-auth2';

import { useState } from 'react';

interface setInIdsType {
  id: string;
  name: string;
}

const useUser = () => {
  const [name, setName] = useState<string>(DEFAULT_NAME);
  const [inIds, setInIds] = useState<setInIdsType[]>([]);
  const [batchEditNumberOpen, setBatchEditNumberOpen] = useState(false);
  const [importModalOpen, setImportModalOpen] = useState(false);
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [numberModalType, setNumberModalType] = useState('add');
  const [tenantManageId, setTenantManageId] = useState(null);
  const [callLineId, setCallLineId] = useState(null);
  const [addFlag, setAddFlag] = useState(false);
  const [loadDataListTab, setLoadDataListTab] = useState(false);
  const [callingNumber, setCallingNumber] = useState(undefined);
  const [lineSupplierRowHandleId, setLineSupplierRowHandleId] = useState<
    string | null
  >(null);
  const [taskCenterStopFlag, setTaskCenterStopFlag] = useState<'启动' | '停止'>(
    null,
  );
  // 线路供应商号码启用
  const [lineSupplierPhoneStart, setLineSupplierPhoneStart] = useState([]);
  // 线路供应商号码停用
  const [lineSupplierPhoneStop, setLineSupplierPhoneStop] = useState([]);
  // 意向分类全量数据-下拉
  const [intentClassificationAll, setIntentClassificationAll] = useState([]);

  return {
    name,
    loadDataListTab,
    callingNumber,
    setCallingNumber,
    setLoadDataListTab,
    addFlag,
    setAddFlag,
    callLineId,
    setCallLineId,
    tenantManageId,
    numberModalType,
    setNumberModalType,
    setTenantManageId,
    setName,
    batchEditNumberOpen,
    importModalOpen,
    addModalOpen,
    setAddModalOpen,
    setBatchEditNumberOpen,
    setImportModalOpen,
    inIds,
    setInIds,
    lineSupplierRowHandleId,
    setLineSupplierRowHandleId,
    userInfo: ssoAuth.userInfo,
    token: ssoAuth.token,
    signOut: ssoAuth.signOut.bind(ssoAuth),
    taskCenterStopFlag,
    setTaskCenterStopFlag,
    lineSupplierPhoneStart,
    setLineSupplierPhoneStart,
    lineSupplierPhoneStop,
    setLineSupplierPhoneStop,
    intentClassificationAll,
    setIntentClassificationAll,
  };
};

export default useUser;
