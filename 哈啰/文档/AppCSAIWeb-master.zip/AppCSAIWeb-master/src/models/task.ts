// 流程图数据

import { ITaskInfo, IBatchExecReq, IProvinceCity } from '@/api/taskCenter';
import { useState } from 'react';
// 流程图数据
import { Intention } from '@/api/language';

const Task = () => {
  const [params, setParams] = useState({
    startDate: undefined,
    endDate: undefined,
    tenantCode: undefined,
    taskName: undefined,
    faqName: undefined,
    taskStatus: undefined,
  });
  // 并发调整选中的任务
  const [superveneTaskList, setSuperveneTaskList] = useState<ITaskInfo[]>([]);
  // 并发调整选中的租户
  const [curTenantId, setCurTenantId] = useState('');
  //批量添加呼叫表单的params
  const [batchExcelParams, setBatchExcelParams] = useState<IBatchExecReq>({
    taskGuidList: undefined,
  });
  // 设置线路组id
  const [curTenantLineGroupId, setCurTenantLineGroupId] = useState('');
  //缓存策略数据，供复制粘贴功能使用
  const [policyData, setPolicyData] = useState();
  const [faqGuidList, setFaqGuidList] = useState([]);
  //任务不可外呼时间段
  const [forbinCallDuration, setForbinCallDuration] = useState('');
  //查询外呼策略名单条件
  const [strategyConditionList, setStrategyConditionList] = useState([]);
  const [intentionOpt, setIntentionOpt] = useState<Intention[]>([]);
  const [cacheData, setCacheData] = useState<any>([]);
  //已选中话术组id(用于请求话术对应的意向分类) -- 只针对长期任务类型,短期任务通过onchange触发
  const [selectedFaqs, setSelectedFaqs] = useState(null);
  const [updateIntention, setUpdateIntention] = useState(false); //初次渲染，不清空意向分类
  //复制粘贴任务中的盲区信息
  const [currentCopyData, setCurrentCopyData] = useState<any>({});
  //省市信息
  const [provinceCityList, setProvinceCityList] = useState<IProvinceCity[]>([]);

  return {
    params,
    setParams,
    superveneTaskList,
    setSuperveneTaskList,
    curTenantId,
    setCurTenantId,
    batchExcelParams,
    setBatchExcelParams,
    curTenantLineGroupId,
    setCurTenantLineGroupId,
    policyData,
    setPolicyData,
    faqGuidList,
    setFaqGuidList,
    forbinCallDuration,
    setForbinCallDuration,
    strategyConditionList,
    setStrategyConditionList,
    intentionOpt,
    setIntentionOpt,
    cacheData,
    setCacheData,
    selectedFaqs,
    setSelectedFaqs,
    updateIntention,
    setUpdateIntention,
    currentCopyData,
    setCurrentCopyData,
    provinceCityList,
    setProvinceCityList,
  };
};

export default Task;
