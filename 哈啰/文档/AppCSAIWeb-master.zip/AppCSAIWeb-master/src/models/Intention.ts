import { useState } from 'react';

const Intention = () => {
  // 意图学习选中的意图id
  const [selectedFaqId, setSelectedFaqId] = useState<string>(undefined);

  return {
    selectedFaqId,
    setSelectedFaqId,
  };
};

export default Intention;
