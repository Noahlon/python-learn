// 流程图数据

import { useCallback, useState } from 'react';
import { IMold, ISubNodeAdd } from '../api/speechFlow';

const Prcess = () => {
  // 路由下拉数据
  const [moldData, setMoldData] = useState<IMold[]>([]);
  // 模版数据
  const [currentSubProcessData, setCurrentSubProcessData] = useState(undefined);
  // 添加自节点数据
  const [addSubNodeData, setAddSubNodeData] = useState<ISubNodeAdd[]>([]);

  // 修改路由模版数据
  const handleChangeMoldData = useCallback((value: IMold[]) => {
    setMoldData(value);
  }, []);

  // 修改当前子流程数据
  const handleChangeCurrentSubProcessData = useCallback((value) => {
    setCurrentSubProcessData(value);
  }, []);

  // 修改当前子流程数据
  const handleChangeAddSubNodeData = useCallback((value) => {
    setAddSubNodeData(value);
  }, []);

  return {
    moldData,
    handleChangeMoldData,
    currentSubProcessData,
    handleChangeCurrentSubProcessData,
    addSubNodeData,
    handleChangeAddSubNodeData,
  };
};

export default Prcess;
