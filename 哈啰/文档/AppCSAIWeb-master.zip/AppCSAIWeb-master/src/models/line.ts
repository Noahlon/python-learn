// 流程图数据

import { useState } from 'react';

const Line = () => {
  // 租户线路类型
  const [type, setType] = useState(0); // 0-关闭 1-新增 2-编辑
  // 线路列表是否刷新
  const [lineCount, setLineCount] = useState(0);
  // 号码列表是否刷新
  const [numCount, setNumCount] = useState(0);
  // 租户选中线路信息
  const [info, setInfo] = useState(undefined);

  return {
    type,
    setType,
    lineCount,
    setLineCount,
    numCount,
    setNumCount,
    info,
    setInfo,
  };
};

export default Line;
