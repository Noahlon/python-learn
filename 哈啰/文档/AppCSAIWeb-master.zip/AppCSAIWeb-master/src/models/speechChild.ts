import { useState } from 'react';
import { getChildSpeechList, ChildSpeechObj } from '@/api/speechChild';

const SpeechChild = () => {
  const [selectedChildGuid, setSelectedChildGuid] = useState<string>(undefined);
  const [childProcessList, setChildProcessList] = useState<ChildSpeechObj[]>(
    [],
  );
  const [childListLoading, setChildListLoading] = useState(false);
  // 当前的子流程详情数据
  const [currentInfo, setCurrentInfo] = useState(undefined);
  // 判断是否自动弹框（起始语料）
  const [isCreateModal, setIsCreateModal] = useState(false);
  // 原始模式（判断是否修改）
  const [defaultSpeechNodeDatas, setDefaultSpeechNodeDatas] = useState([]);

  // 子流程列表
  const getChildProcessList = async (speechGuid: string) => {
    setChildListLoading(true);

    const res = await getChildSpeechList({
      speechGuid,
    });
    setChildProcessList(res?.data || []);
    setChildListLoading(false);
    return res?.data || [];
  };

  const clearSubProcessData = () => {
    setSelectedChildGuid(undefined);
    setChildProcessList([]);
    setCurrentInfo(undefined);
    setIsCreateModal(false);
    setDefaultSpeechNodeDatas([]);
  };

  return {
    selectedChildGuid,
    setSelectedChildGuid,
    childProcessList,
    getChildProcessList,
    childListLoading,
    setChildProcessList,
    isCreateModal,
    setIsCreateModal,
    currentInfo,
    setCurrentInfo,
    clearSubProcessData,
    defaultSpeechNodeDatas,
    setDefaultSpeechNodeDatas,
  };
};

export default SpeechChild;
