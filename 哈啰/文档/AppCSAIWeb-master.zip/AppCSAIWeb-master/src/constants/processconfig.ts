export const LAYOUT = {
  labelCol: { span: 8 },
  wrapperCol: { span: 16 },
};

export const LAYOUTLABELSMALL = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 },
};

export const LAYOUTLABEL = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
};

export const LAYOUTWRAP = {
  wrapperCol: { offset: 6, span: 18 },
};

export const LAYOUTLABELFIVE = {
  labelCol: { span: 5 },
  wrapperCol: { span: 19 },
};

export const LAYOUTWRAPFIVE = {
  wrapperCol: { offset: 5, span: 19 },
};

export const LAYOUTWRAPLARGE = {
  wrapperCol: { offset: 8, span: 16 },
};

export const LAYOUTWRAPALL = {
  wrapperCol: { span: 24 },
};

export const LAYOUTHOR = {
  labelCol: { span: 24 },
  wrapperCol: { span: 24 },
};

export const LAYOUTLABELEIGHT = {
  labelCol: { span: 6 },
};

export const SEARCHLAYOUT = { xl: 8, sm: 12, xs: 24 };
