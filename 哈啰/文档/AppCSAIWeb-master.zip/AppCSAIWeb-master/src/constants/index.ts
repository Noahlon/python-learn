export const DEFAULT_NAME = 'Umi Max';

// 呼叫中心数据枚举
export const ccServerOptions = [
  // { label: '中弘CC', value: 'zhongHongCC' },
  // { label: '自研CC', value: 'independentCC' },
  { label: '中弘CC2.0', value: 'selfInnovateCCV2' },
];
