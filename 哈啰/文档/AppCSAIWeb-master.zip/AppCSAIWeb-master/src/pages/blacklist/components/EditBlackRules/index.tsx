import { addBlackRule, editBlackRule, IBlackRule } from '@/api/blacklist';
import { getIntentionOptsByIDs } from '@/api/intention';
import { getIntentionListAll } from '@/api/language';
import {
  getCorpusListByIds,
  getSpeechListByTrade,
  ITradeSpeechList,
} from '@/api/speech';
import { Options } from '@/components/SelectLimit';
import { ICorpusClass } from '@/pages/speech/config';
import { getZeroOrPositiveInt } from '@/utils';
import { useModel } from '@umijs/max';
import { Cascader, Form, Input, Modal, Select } from 'antd';
import { DefaultOptionType } from 'antd/es/cascader';
import { debounce, intersection } from 'lodash';
import React, { useCallback, useEffect, useRef, useState } from 'react';
const { SHOW_CHILD } = Cascader;

export interface Prop {
  type?: number;
  info?: IBlackRule;
  groupId?: string;
  onOk?: () => void;
  onCancel?: () => void;
}

const layout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
};

const asteriskCss = {
  marginRight: '4px',
  color: '#ff4d4f',
  fontSize: '14px',
};

const noticeCss = {
  color: '#999',
  fontSize: '14px',
};

const errorCss = {
  color: 'red',
  fontSize: '14px',
};

const selectCss = {
  display: 'inline-block',
  width: '54%',
};

const inputCss = {
  display: 'inline-block',
  width: '36%',
  paddingLeft: '15px',
};

const unitCss = {
  display: 'inline-block',
  width: '10%',
  paddingLeft: '18px',
};

const smallInputCss = {
  display: 'inline-block',
  width: '20%',
};

const separatorCss = { margin: '0 10px', display: 'inline-block' };

const hitCount = (
  <label style={{ display: 'flex' }}>
    命中数量 <span style={{ margin: '-1px 0 0 5px' }}>&ge;</span>
  </label>
);

const EditBlackRules: React.FC<Prop> = ({
  type,
  onOk,
  onCancel,
  info,
  groupId,
}) => {
  const [form] = Form.useForm();
  const selectSpeechIds = Form.useWatch('speechIds', form);
  const selectBizIds = Form.useWatch('bizIds', form);
  const { bizList, handleGetBizList } = useModel('speech');
  const [algorithmIntentionOptions, setAlgorithmIntentionOptions] = useState(
    [],
  );
  const [QADatabaseOptions, setQADatabaseOptions] = useState<Options[]>([]);
  const [intentionClassifysList, setIntentionClassifysList] = useState([]);
  const [rulesError, setRulesError] = useState(false);
  const [loading, setLoading] = useState(false);
  const radioGroupRef = useRef(null);
  const [speechOpt, setSpeechOpt] = useState<ITradeSpeechList[]>([]);
  const [labelOpts] = useState<Options[]>([]);
  // 第一次加载
  const firstRef = useRef(true);

  // 话术范围前端搜索
  const [searchSpeechValue, setSearchSpeechValue] = useState('');
  // 行业范围前端搜索
  const [searchBizValue, setSearchBizValue] = useState('');

  // form重置
  const reSetForm = () => {
    form.resetFields();
    setRulesError(false);
    setAlgorithmIntentionOptions([]);
    setQADatabaseOptions([]);
  };
  const getBizName = (ids: any) => {
    const names = [];
    bizList?.forEach((item) => {
      item?.children?.forEach((i) => {
        i?.children?.forEach((j) => {
          ids?.forEach((h) => {
            if (h?.[2] === j.value)
              names.push(`${item.label}/${i.label}/${j.label}`);
          });
        });
      });
    });
    return names;
  };

  // 提交
  const handleOk = async () => {
    let param = await form.validateFields();
    if (
      !param?.hitCorpusIds?.length &&
      !param?.hitPhraseIntentions?.length &&
      !param?.hitLabelIds?.length &&
      !param.startDurationCall &&
      !param.endDurationCall &&
      !param.startUserSpeakCount &&
      !param.endUserSpeakCount &&
      !param.startSpeechCount &&
      !param.endSpeechCount &&
      !param.intentClassify
    ) {
      setRulesError(true);
      return;
    } else {
      setRulesError(false);
    }
    if (param.bizIds?.length) {
      const bizSceneIds = param.bizIds?.map((item) => item?.[2]);
      param.bizSceneIds = bizSceneIds;
      const sceneNames = getBizName(param.bizIds);
      param.sceneNames = sceneNames;
    }
    delete param.bizIds;
    setLoading(true);
    const _speechGroupIds = param?.speechIds?.map((item) => item[2]);
    param.speechGuids = _speechGroupIds;
    let _speechGroupGuids = [];
    speechOpt?.forEach((item) => {
      item?.children?.forEach((i) => {
        const _speechs = i?.children?.filter((h) =>
          _speechGroupIds?.includes(h.guid),
        );
        if (_speechs?.length)
          _speechGroupGuids = [
            ..._speechGroupGuids,
            ..._speechs.map((item) => item.speechGroupId),
          ];
      });
    });
    param.speechGroupGuids = _speechGroupGuids;
    const ruleSettings = [];
    // 答疑库
    if (param?.hitCorpusIds?.length) {
      const _rules = param?.hitCorpusIds.map((item) => ({
        guid: QADatabaseOptions?.find((i) => i.label === item)?.id || '',
        name: item,
      }));
      ruleSettings.push({
        count: param?.hitCorpusIdsNum,
        rules: _rules,
        type: 1,
      });
    }
    // 命中意图
    if (param?.hitPhraseIntentions?.length) {
      let _IntentionRules = [];
      const _ids = param?.hitPhraseIntentions.map((item) => item[1]);
      algorithmIntentionOptions?.forEach((item) => {
        const intentionList = item.list?.filter((i) => _ids.includes(i.id));
        if (intentionList?.length)
          intentionList.forEach((i) =>
            _IntentionRules.push({
              guid: i.id,
              name: i.name,
            }),
          );
      });
      ruleSettings.push({
        count: param?.hitPhraseIntentionsNum,
        rules: _IntentionRules,
        type: 2,
      });
    }
    // 标签
    if (param?.hitLabelIds?.length) {
      const _rules = param?.hitLabelIds?.map((item) => ({ name: item }));
      ruleSettings.push({
        count: param?.hitLabelIdsNum,
        rules: _rules,
        type: 3,
      });
    }
    param.ruleSettings = ruleSettings;
    param.groupId = groupId;
    delete param?.speechIds;
    delete param?.hitCorpusIds;
    delete param?.hitCorpusIdsNum;
    delete param?.hitPhraseIntentions;
    delete param?.hitPhraseIntentionsNum;
    delete param?.hitLabelIds;
    delete param?.hitLabelIdsNum;

    if (type === 2 && info?.id) {
      param.id = info?.id;
    }
    const api = type === 2 ? editBlackRule : addBlackRule;
    const res = await api(param);
    if (res.success) {
      reSetForm();
      onOk?.();
    }
    setLoading(false);
  };

  // 意图查询
  const handleGetIntentionOpt = async (params) => {
    const res = await getIntentionOptsByIDs(params);
    if (res?.success && res.data?.length) {
      setAlgorithmIntentionOptions(res.data);
    } else {
      setAlgorithmIntentionOptions([]);
    }
  };

  // 答疑库查询
  const handleGetCorpusOpt = async ({
    name,
    faqIds,
  }: {
    name?: string;
    faqIds?: string[];
  }) => {
    if (selectSpeechIds?.length !== 1 || selectSpeechIds?.[0]?.length !== 3) {
      setQADatabaseOptions([]);
      form.setFieldValue('hitCorpusIds', undefined);
      return;
    }
    let res = await getCorpusListByIds({
      ids: faqIds,
      corpusName: name,
      speechGuid: selectSpeechIds?.[0][2],
      corpusSource: ICorpusClass.QA,
    });
    if (res?.length) {
      let opts: Options[] = res?.map((item) => ({
        label: item.corpusName,
        value: item.corpusName,
        id: item.id,
      }));
      const selectIds = form.getFieldValue('hitCorpusIds');
      if (selectIds?.length) {
        const filterOpt = QADatabaseOptions.filter(
          (item) =>
            selectIds.includes(item.label) &&
            opts.findIndex((i) => i.label === item.label) === -1,
        );
        if (filterOpt?.length) opts = [...filterOpt, ...opts];
      }
      setQADatabaseOptions(opts);
    }
  };

  // 答疑库搜索
  const handleCorpusSearch = useCallback(
    debounce((name: string) => {
      handleGetCorpusOpt({ name });
    }, 500),
    [QADatabaseOptions, selectSpeechIds],
  );

  // 字符替换数字
  const handleInputNumber = (type, value) => {
    getZeroOrPositiveInt(value).then((val) => form.setFieldValue(type, val));
  };

  // 验证
  const handleValidatorRetry = useCallback(async (rule, value, pNaame) => {
    const pNaameVal = form.getFieldValue(pNaame);
    if (!pNaameVal || !pNaameVal.length) return Promise.resolve();
    // if (value === '0') return Promise.reject('不能为0');
    if (!value) return Promise.reject('请输入');
    if (!/^([1-9]\d{0,4}|99999)$/.test(value))
      return Promise.reject('请输入1-99999的正整数');
    return Promise.resolve();
  }, []);

  // 验证
  const handleValidatorBiz = async (rule, value) => {
    let res = Promise.resolve();
    if (value?.length) {
      value?.forEach((item) => {
        if (item?.length !== 3) res = Promise.reject('请选择正确场景');
      });
    }
    return res;
  };

  // 验证输入范围及右边大于左边
  const handleValidatorCompare = useCallback(
    async (rule, value, formItemIds) => {
      if (!value) return Promise.resolve();
      if (!/^([1-9]\d{0,4}|99999)$/.test(value))
        return Promise.reject('请输入1-99999的正整数');
      const startNum = form.getFieldValue(formItemIds[0]);
      const endNum = form.getFieldValue(formItemIds[1]);
      if (!startNum || !endNum) {
        return Promise.resolve();
      } else if (Number(endNum) < Number(startNum)) {
        return Promise.reject('右边应大于左边值');
      }
      return Promise.resolve();
    },
    [],
  );

  // 验证标签大于50
  const handleValidatorLabel = useCallback(async (rule, value) => {
    if (!value?.length) return Promise.resolve();
    if (value?.length > 50) return Promise.reject('标签数量不能大于50');
    return Promise.resolve();
  }, []);

  // 验证话术
  const validSpeech = (_, val) => {
    let res = Promise.resolve();
    val?.forEach((item) => {
      if (item?.length !== 3) res = Promise.reject('存在选项不是话术');
    });
    const bizIds = form.getFieldValue('bizIds');
    if (!val?.length && !bizIds?.length)
      res = Promise.reject('话术范围和行业范围至少选择一项');
    return res;
  };

  // 验证命中意图
  const handleValidatorIntention = (_, val) => {
    if (!val?.length) return Promise.resolve();
    let res = Promise.resolve();
    if (val?.length > 50) return Promise.reject('意图数量不能大于50');
    val?.forEach((item) => {
      if (item?.length !== 2) res = Promise.reject('存在选项不是意图');
    });
    return res;
  };

  // 改变意向值
  const handleIntentionClassificationChange = (code: string) => {
    const intentClassify = form.getFieldValue('intentClassify');
    if (intentClassify && intentClassify === code)
      form.setFieldValue('intentClassify', undefined);
  };

  // 话术级联搜索
  const filterCascader = (inputValue: string, path: DefaultOptionType[]) =>
    path.some(
      (option) =>
        (option.name as string)
          ?.toLowerCase()
          .indexOf(inputValue.toLowerCase()) > -1,
    );

  // 行业级联搜索
  const filterBizCascader = (inputValue: string, path: DefaultOptionType[]) =>
    path.some(
      (option) =>
        (option.label as string)
          ?.toLowerCase()
          .indexOf(inputValue.toLowerCase()) > -1,
    );

  // 获取意向分类
  const getIntentionOpt = useCallback(async () => {
    const res = await getIntentionListAll({
      pageSize: 200,
      pageNum: 1,
    });
    if (res) {
      setIntentionClassifysList(res);
    }
  }, []);

  // 获取话术列表
  const getSpeechOpt = useCallback(async () => {
    const res = await getSpeechListByTrade({ status: 1 });
    if (res) setSpeechOpt(res.data);
  }, []);

  useEffect(() => {
    getIntentionOpt();
    getSpeechOpt();
  }, []);

  // 给命中意图初始化
  useEffect(() => {
    const intentionInfo = info?.ruleSettings?.find((item) => item.type === 2);
    if (
      firstRef.current &&
      algorithmIntentionOptions?.length &&
      intentionInfo
    ) {
      const _ids = intentionInfo?.rules?.map((item) => item.guid);
      let intentionInit = [];
      algorithmIntentionOptions?.forEach((item) => {
        const intentionList = item.list?.filter((i) => _ids.includes(i.id));
        if (intentionList?.length)
          intentionList.forEach((i) => {
            intentionInit.push([item.id, i.id]);
          });
      });
      form.setFieldValue('hitPhraseIntentions', intentionInit);
    }
  }, [algorithmIntentionOptions]);

  // 话术值变化查询答疑库
  useEffect(() => {
    handleGetCorpusOpt({});
  }, [selectSpeechIds]);

  useEffect(() => {
    if (!type) {
      return;
    }
    // 先清空原有意图的数据
    setAlgorithmIntentionOptions([]);
    form.setFieldValue('hitPhraseIntentions', undefined);

    // 话术范围的二级行业
    const _speechLevelTwoIds =
      selectSpeechIds?.reduce((total, cur) => {
        if (total?.includes(cur?.[1])) {
          return total;
        }
        return [...total, cur?.[1]];
      }, []) || [];

    // 行业范围的二级行业
    const _bizLevelTwoIds =
      selectBizIds?.reduce((total, cur) => {
        if (total?.includes(cur?.[1])) {
          return total;
        }
        return [...total, cur?.[1]];
      }, []) || [];

    // 如果话术范围和行业范围都为[]就return
    if (_speechLevelTwoIds?.length === 0 && _bizLevelTwoIds?.length === 0) {
      return;
    }

    let mixLevelIds = [];
    // 如果只选了话术范围，那么就传话术范围所在的二级行业id
    if (_speechLevelTwoIds?.length === 0) {
      mixLevelIds = _bizLevelTwoIds;
    }
    // 如果只选了行业范围，那么就传行业范围所在的二级行业id
    if (_bizLevelTwoIds?.length === 0) {
      mixLevelIds = _speechLevelTwoIds;
    }
    // 话术范围的二级和话术范围的二级的交集
    if (_speechLevelTwoIds?.length && _bizLevelTwoIds?.length) {
      mixLevelIds = intersection(_speechLevelTwoIds, _bizLevelTwoIds);
    }

    // 再请求意图数据
    const params = {
      bizIdList: mixLevelIds,
    };
    handleGetIntentionOpt(params);
  }, [type, selectSpeechIds, selectBizIds]);

  // 表单初始值
  useEffect(() => {
    if (info && type) {
      const formData = JSON.parse(JSON.stringify(info));
      if (speechOpt?.length && formData?.speechGuids) {
        const _ids = [];
        speechOpt?.forEach((item) => {
          item?.children?.forEach((i) => {
            i?.children?.forEach((j) => {
              if (formData?.speechGuids.includes(j.guid))
                _ids.push([item.guid, i.guid, j.guid]);
            });
          });
        });
        formData.speechIds = _ids;
      }
      if (formData?.ruleSettings?.length) {
        formData?.ruleSettings?.forEach((item) => {
          if (item.type === 1) {
            formData.hitCorpusIds = item?.rules?.map((i) => i.name);
            formData.hitCorpusIdsNum = item.count;
          } else if (item.type === 2) {
            // formData.hitPhraseIntentions = _ids;
            formData.hitPhraseIntentionsNum = item.count;
          } else if (item.type === 3) {
            formData.hitLabelIds = item?.rules?.map((i) => i.name);
            formData.hitLabelIdsNum = item.count;
          }
        });
      }
      delete formData?.speechGuids;
      delete formData?.ruleSettings;
      form.setFieldsValue(formData);
    } else {
      form.resetFields();
      setSearchSpeechValue('');
      setSearchBizValue('');
      firstRef.current = true;
    }
    if (type && !bizList?.length) handleGetBizList();
    setLoading(false);
  }, [type]);

  // 表单初始值
  useEffect(() => {
    if (!!type && !!info && !!bizList?.length) {
      const ids = [];
      bizList?.forEach((item) => {
        item?.children?.forEach((i) => {
          i?.children?.forEach((j) => {
            if (info?.bizSceneIds?.includes(j.value))
              ids.push([item.value, i.value, j.value]);
          });
        });
      });
      form.setFieldValue('bizIds', ids);
    }
  }, [type, bizList, info]);

  // 意向分类取消选中
  useEffect(() => {
    let radioEle = null;
    if (radioGroupRef?.current && type && intentionClassifysList?.length) {
      setTimeout(() => {
        radioEle = radioGroupRef?.current;
        if (radioEle) {
          radioEle.addEventListener('click', function (e) {
            if (e.target.tagName === 'INPUT') {
              handleIntentionClassificationChange(e.target.value);
            }
          });
        }
      }, 100);
    }
    return () =>
      radioEle?.removeEventListener(
        'click',
        handleIntentionClassificationChange,
      );
  }, [radioGroupRef, intentionClassifysList, type]);

  return (
    <Modal
      open={!!type}
      title={
        type === 2
          ? '编辑规则'
          : type === 1
          ? '新增规则'
          : type === 3
          ? '复制规则'
          : '查看规则'
      }
      forceRender={true}
      width={'700px'}
      onOk={handleOk}
      onCancel={() => {
        reSetForm();
        onCancel?.();
      }}
      confirmLoading={loading}
      getContainer={false}
    >
      <Form form={form} {...layout}>
        <Form.Item
          label="规则名称"
          name="ruleName"
          rules={[{ required: true }]}
        >
          <Input placeholder="请输入名称" maxLength={30} />
        </Form.Item>
        <Form.Item
          label={
            <>
              <label style={asteriskCss}>*</label>禁呼时长
            </>
          }
          style={{ marginBottom: 0 }}
        >
          <Form.Item
            name="dayLimit"
            style={selectCss}
            rules={[
              { required: true, message: '请输入禁呼时长' },
              {
                pattern: /^([1-9]\d{0,4}|99999)$/,
                message: '请输入1-99999的正整数',
              },
            ]}
          >
            <Input placeholder="请输入禁呼时长" />
          </Form.Item>
          <Form.Item style={unitCss}>天</Form.Item>
        </Form.Item>
        <Form.Item
          label="话术范围"
          name="speechIds"
          rules={[{ validator: validSpeech }]}
        >
          <Cascader
            placeholder="请选择话术"
            fieldNames={{
              label: 'name',
              value: 'guid',
              children: 'children',
            }}
            getPopupContainer={(triggerNode) =>
              triggerNode.parentElement || document.body
            }
            multiple
            options={speechOpt}
            allowClear
            showCheckedStrategy={SHOW_CHILD}
            showSearch={{ filter: filterCascader }}
            // onSearch={(value) => console.log(value)}
            // onChange={(v, a) => {console.log(v); console.log(a)}}
            onSearch={setSearchSpeechValue}
            searchValue={searchSpeechValue}
          />
        </Form.Item>
        <Form.Item
          label="行业范围"
          name="bizIds"
          rules={[{ validator: handleValidatorBiz }]}
        >
          <Cascader
            placeholder="请选择行业范围"
            options={bizList}
            changeOnSelect
            showSearch={{ filter: filterBizCascader }}
            multiple
            showCheckedStrategy={SHOW_CHILD}
            onSearch={setSearchBizValue}
            searchValue={searchBizValue}
          />
        </Form.Item>
        <Form.Item
          label={
            <>
              <label style={asteriskCss}>*</label>配置规则
            </>
          }
        >
          <div style={rulesError ? errorCss : noticeCss}>至少配置一项规则</div>
        </Form.Item>
        {!selectSpeechIds || selectSpeechIds?.length < 2 ? (
          <Form.Item label="命中答疑库" style={{ marginBottom: 0 }}>
            <Form.Item name="hitCorpusIds" style={selectCss}>
              <Select
                placeholder="请选择"
                allowClear
                mode="multiple"
                maxTagCount="responsive"
                filterOption={false}
                onSearch={(name) => handleCorpusSearch(name)}
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                options={QADatabaseOptions}
              />
            </Form.Item>
            <Form.Item
              label={hitCount}
              colon={false}
              style={inputCss}
              name="hitCorpusIdsNum"
              rules={[
                {
                  validator: (rule, value) =>
                    handleValidatorRetry(rule, value, 'hitCorpusIds'),
                },
              ]}
            >
              <Input
                placeholder="请输入"
                onChange={(e) =>
                  handleInputNumber('hitCorpusIdsNum', e.target.value)
                }
              />
            </Form.Item>
            <Form.Item style={unitCss}>个</Form.Item>
          </Form.Item>
        ) : null}
        <Form.Item label="命中意图" style={{ marginBottom: 0 }}>
          <Form.Item
            name="hitPhraseIntentions"
            style={selectCss}
            rules={[
              {
                validator: (rule, value) =>
                  handleValidatorIntention(rule, value),
              },
            ]}
          >
            <Cascader
              placeholder="请选择命中意图"
              fieldNames={{ label: 'name', value: 'id', children: 'list' }}
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
              multiple
              options={algorithmIntentionOptions}
              allowClear
              maxTagCount="responsive"
              showCheckedStrategy={SHOW_CHILD}
              showSearch={{ filter: filterCascader }}
              // onSearch={(value) => console.log(value)}
              // onChange={(v) => console.log(v)}
            />
          </Form.Item>
          <Form.Item
            label={hitCount}
            colon={false}
            name="hitPhraseIntentionsNum"
            style={inputCss}
            rules={[
              {
                validator: (rule, value) =>
                  handleValidatorRetry(rule, value, 'hitPhraseIntentions'),
              },
            ]}
          >
            <Input
              placeholder="请输入"
              onChange={(e) =>
                handleInputNumber('hitPhraseIntentionsNum', e.target.value)
              }
            />
          </Form.Item>
          <Form.Item style={unitCss}>个</Form.Item>
        </Form.Item>

        <Form.Item label="命中标签" style={{ marginBottom: 0 }}>
          <Form.Item
            name="hitLabelIds"
            style={selectCss}
            rules={[
              {
                validator: (rule, value) => handleValidatorLabel(rule, value),
              },
            ]}
          >
            {/* <SelectLimit options={labelOptions} max={50} text="请选择标签" /> */}
            <Select
              mode="tags"
              allowClear
              placeholder="请输入标签"
              // onChange={handleLabelChange}
              tokenSeparators={[',', '，']}
              options={labelOpts}
            />
          </Form.Item>
          <Form.Item
            label={hitCount}
            colon={false}
            name="hitLabelIdsNum"
            style={inputCss}
            rules={[
              {
                validator: (rule, value) =>
                  handleValidatorRetry(rule, value, 'hitLabelIds'),
              },
            ]}
          >
            <Input
              placeholder="请输入"
              onChange={(e) =>
                handleInputNumber('hitLabelIdsNum', e.target.value)
              }
            />
          </Form.Item>
          <Form.Item style={unitCss}>个</Form.Item>
        </Form.Item>

        <Form.Item label="通话时长（秒）" style={{ marginBottom: 0 }}>
          <Form.Item
            name="startDurationCall"
            rules={[
              {
                validator: (rule, value) =>
                  handleValidatorCompare(rule, value, [
                    'startDurationCall',
                    'endDurationCall',
                  ]),
              },
            ]}
            style={smallInputCss}
          >
            <Input
              placeholder="请输入"
              allowClear
              // onChange={(e) =>
              //   handleInputNumber(
              //     ['purposeRule', 'callDuration', 'min'],
              //     e.target.value,
              //   )
              // }
            />
          </Form.Item>
          <Form.Item style={separatorCss}>-</Form.Item>
          <Form.Item
            name="endDurationCall"
            rules={[
              {
                validator: (rule, value) =>
                  handleValidatorCompare(rule, value, [
                    'startDurationCall',
                    'endDurationCall',
                  ]),
              },
            ]}
            style={smallInputCss}
          >
            <Input
              placeholder="请输入"
              allowClear
              // onChange={(e) =>
              //   handleInputNumber(
              //     ['purposeRule', 'callDuration', 'max'],
              //     e.target.value,
              //   )
              // }
            />
          </Form.Item>
        </Form.Item>

        <Form.Item label="对话次数" style={{ marginBottom: 0 }}>
          <Form.Item
            name="startUserSpeakCount"
            rules={[
              {
                validator: (rule, value) =>
                  handleValidatorCompare(rule, value, [
                    'startUserSpeakCount',
                    'endUserSpeakCount',
                  ]),
              },
            ]}
            style={smallInputCss}
          >
            <Input
              placeholder="请输入"
              allowClear
              // onChange={(e) =>
              //   handleInputNumber(
              //     ['purposeRule', 'dialogueRounds', 'min'],
              //     e.target.value,
              //   )
              // }
            />
          </Form.Item>
          <Form.Item style={separatorCss}>-</Form.Item>
          <Form.Item
            name="endUserSpeakCount"
            rules={[
              {
                validator: (rule, value) =>
                  handleValidatorCompare(rule, value, [
                    'startUserSpeakCount',
                    'endUserSpeakCount',
                  ]),
              },
            ]}
            style={smallInputCss}
          >
            <Input
              placeholder="请输入"
              allowClear
              // onChange={(e) =>
              //   handleInputNumber(
              //     ['purposeRule', 'dialogueRounds', 'max'],
              //     e.target.value,
              //   )
              // }
            />
          </Form.Item>
        </Form.Item>
        <Form.Item label="说话次数" style={{ marginBottom: 0 }}>
          <Form.Item
            name="startSpeechCount"
            rules={[
              {
                validator: (rule, value) =>
                  handleValidatorCompare(rule, value, [
                    'startSpeechCount',
                    'endSpeechCount',
                  ]),
              },
            ]}
            style={smallInputCss}
          >
            <Input
              placeholder="请输入"
              allowClear
              // onChange={(e) =>
              //   handleInputNumber(
              //     ['purposeRule', 'userSayTimes', 'min'],
              //     e.target.value,
              //   )
              // }
            />
          </Form.Item>
          <Form.Item style={separatorCss}>-</Form.Item>
          <Form.Item
            name="endSpeechCount"
            rules={[
              {
                validator: (rule, value) =>
                  handleValidatorCompare(rule, value, [
                    'startSpeechCount',
                    'endSpeechCount',
                  ]),
              },
            ]}
            style={smallInputCss}
          >
            <Input
              placeholder="请输入"
              allowClear
              // onChange={(e) =>
              //   handleInputNumber(
              //     ['purposeRule', 'userSayTimes', 'max'],
              //     e.target.value,
              //   )
              // }
            />
          </Form.Item>
        </Form.Item>
        <Form.Item label="意向分类" name="intentClassify">
          {/* <Radio.Group
            ref={radioGroupRef}
            options={intentionClassifysList?.map((i) => ({
              label: i.classification,
              value: i.classification,
            }))}
            optionType="button"
          /> */}
          <Select
            placeholder="请选择"
            // onChange={(val) => handleRouteTypeChange(val)}
            getPopupContainer={(triggerNode) =>
              triggerNode.parentElement || document.body
            }
            allowClear
            showSearch
            options={intentionClassifysList?.map((i) => ({
              label: i.classification,
              value: i.classification,
            }))}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default EditBlackRules;
