import React, { useState, memo } from 'react';
import { Form, Modal, Input, DatePicker, message } from 'antd';
import moment from 'moment';
import { addBlackQuickly, IAddQuicklyParams } from '@/api/blacklist';
import { validatePhoneNumberV2 } from '@/utils/validate';

const { TextArea } = Input;
const layout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 19 },
};

interface Prop {
  showAddBlackModal?: boolean;
  groupId: string;
  onOk?: () => void;
  onCancel?: () => void;
}

const AddBlack: React.FC<Prop> = memo(
  ({ showAddBlackModal, onCancel, onOk, groupId }) => {
    const [form] = Form.useForm();
    const [confirmLoading, setConfirmLoading] = useState(false);

    // 取消
    const handleCancel = () => {
      form.resetFields();
      setConfirmLoading(false);
      onCancel?.();
    };

    // fetch添加
    const fetchAddBlackQuickly = async (param: IAddQuicklyParams) => {
      setConfirmLoading(true);
      const res = await addBlackQuickly(param);
      if (res.success) {
        message.success('添加成功');
        onOk?.();
        handleCancel();
      }
      setConfirmLoading(false);
    };

    // 提交
    const handleOk = async () => {
      let param = await form.validateFields();

      param.expireTime = moment(param.expireTime)
        .startOf('day')
        .format('YYYY-MM-DD HH:mm:ss');
      const mList = param.mobileList
        ?.trim()
        ?.split(/[\s\n]/)
        ?.filter(Boolean);
      param.mobileList = [...new Set(mList)];
      param.groupId = groupId;

      fetchAddBlackQuickly(param);
    };

    // 验证多手机号格式
    const handleValidatorPhone = (_, value: string) => {
      if (!value) return Promise.reject('请输入手机号');
      const textList = value.trim().split(/[\s\n]/);
      if (textList?.length) {
        const isRealPhone = textList
          .filter(Boolean)
          ?.every((mobile: string) => {
            return validatePhoneNumberV2(mobile);
          });
        if (!isRealPhone) {
          return Promise.reject('请输入正确的格式和手机号');
        }
      }
      return Promise.resolve();
    };

    return (
      <>
        <Modal
          open={showAddBlackModal}
          title="添加"
          forceRender
          width="540px"
          onOk={handleOk}
          onCancel={handleCancel}
          confirmLoading={confirmLoading}
          getContainer={false}
        >
          <Form form={form} {...layout}>
            <Form.Item
              label="说明"
              name="instructions"
              rules={[{ required: true }]}
            >
              <Input maxLength={30} placeholder="请输入说明，限制30字" />
            </Form.Item>
            <Form.Item
              label="过期日期"
              name="expireTime"
              rules={[{ required: true, message: '请选择过期日期' }]}
            >
              <DatePicker
                style={{ width: '100%' }}
                showToday={false}
                disabledDate={(current) => {
                  return current && current < moment().endOf('day');
                }}
              />
            </Form.Item>
            <Form.Item
              label="手机号"
              name="mobileList"
              rules={[
                {
                  required: true,
                  validator: handleValidatorPhone,
                },
              ]}
            >
              <TextArea rows={6} placeholder="多手机号换行输入" />
            </Form.Item>
          </Form>
        </Modal>
      </>
    );
  },
);
export default AddBlack;
