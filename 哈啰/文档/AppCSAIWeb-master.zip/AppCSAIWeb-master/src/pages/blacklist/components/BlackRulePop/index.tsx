import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Pagination,
  Drawer,
  Button,
  Dropdown,
  Empty,
  Popconfirm,
  Spin,
  message,
} from 'antd';
import { v1 as uuidv1 } from 'uuid';
import styles from './index.less';
import { useAccess } from '@umijs/max';
import { MoreOutlined } from '@ant-design/icons';
import EditBlackRules from '../EditBlackRules';
import { deleteBlackRule, getBlackRuleList, IBlackRule } from '@/api/blacklist';

const BlackRuleDrawer: React.FC<{
  open: boolean;
  groupId: string;
  onCancel: () => void;
}> = ({ open, groupId, onCancel }) => {
  const queryParams = useRef({
    pageNum: 1,
    pageSize: 100,
  });
  const access = useAccess();
  const [isLoading, setLoading] = useState(false);
  const [rulesList, setRulesList] = useState<IBlackRule[]>([]);
  const [curInfo, setCurInfo] = useState<IBlackRule>(undefined);
  const [total, setTotal] = useState(0);
  const [pageIndex, setPageIndex] = useState(1);
  const [pageSize, setPageSize] = useState(100);
  // 0--关闭 1--新建 2--编辑
  const [type, setType] = useState(0);

  // 获取列表
  const handlerGetLists = async () => {
    if (!groupId) return;
    setLoading(true);
    console.log(queryParams.current);
    const res = await getBlackRuleList({
      groupId,
      ...queryParams.current,
    });
    if (res.success) {
      setRulesList(res.data?.list);
      setTotal(res.data?.totalRecord);
    }
    setLoading(false);
  };

  // 分页
  const onChange = (page: number | undefined, size: number | undefined) => {
    if (size !== pageSize) {
      queryParams.current.pageNum = 1;
      queryParams.current.pageSize = size;
      setPageIndex(1);
      setPageSize(size);
    } else {
      setPageIndex(page);
      queryParams.current.pageNum = page;
    }
    handlerGetLists();
  };

  // 删除
  const handleDeleteRules = async (ruleItem: IBlackRule) => {
    const res = await deleteBlackRule({ id: ruleItem.id });
    if (res.success) {
      message.success('删除成功');
      handlerGetLists();
    }
  };

  // 编辑规则提交
  const handleRuleFormOk = () => {
    setCurInfo(undefined);
    setType(0);
    queryParams.current.pageNum = 1;
    setPageIndex(1);
    handlerGetLists();
  };

  // 获取下拉数据
  const getDropdownList = (info: IBlackRule) => {
    return [
      {
        key: `${info.id}Add`,
        label: (
          <div
            onClick={() => {
              setType(2);
              setCurInfo(info);
            }}
          >
            编辑
          </div>
        ),
      },
      {
        key: `${info.id}Delete`,
        label: (
          <Popconfirm
            title="你确定要删除吗?"
            onConfirm={() => handleDeleteRules(info)}
            okText="确定"
            cancelText="取消"
          >
            删除
          </Popconfirm>
        ),
      },
    ];
  };

  // 获取数字大小
  const getCount = (start: number | undefined, end: number | undefined) => {
    if ((start || start === 0) && (end || end === 0)) {
      return (
        <>
          {start}-{end}
        </>
      );
    } else if (start || start === 0) {
      return <>&nbsp;&ge;&nbsp;{start}</>;
    } else if (end || end === 0) {
      return <>&nbsp;&le;&nbsp;{end}</>;
    }
    return '';
  };

  // 获取规则内容
  const getRuleContent = useCallback(
    (info: IBlackRule) => {
      let _length = 0;
      const _showMap = [];
      if (info?.ruleSettings?.length) {
        info?.ruleSettings.forEach((item) => {
          _length += 1;
          _showMap.push(
            <p key={uuidv1()} className={styles.ruleConLabel}>
              {item.type === 1
                ? '命中答疑库:'
                : item.type === 2
                ? '命中意图:'
                : '命中标签:'}
              &nbsp;
              {item?.rules?.map((i) => `‘${i.name}’`)?.join('、')}
              ；&ge;&nbsp;{item?.count}
            </p>,
          );
        });
      }
      if ((info?.startDurationCall || info?.endDurationCall) && _length < 3) {
        _length += 1;
        _showMap.push(
          <p key={uuidv1()} className={styles.ruleConLabel}>
            通话时长: {getCount(info?.startDurationCall, info?.endDurationCall)}
          </p>,
        );
      }
      if (
        (info?.startUserSpeakCount || info?.endUserSpeakCount) &&
        _length < 3
      ) {
        _length += 1;
        _showMap.push(
          <p key={uuidv1()} className={styles.ruleConLabel}>
            对话次数:{' '}
            {getCount(info?.startUserSpeakCount, info?.endUserSpeakCount)}
          </p>,
        );
      }
      if ((info?.startSpeechCount || info?.endSpeechCount) && _length < 3) {
        _length += 1;
        _showMap.push(
          <p key={uuidv1()} className={styles.ruleConLabel}>
            说话次数: {getCount(info?.startSpeechCount, info?.endSpeechCount)}
          </p>,
        );
      }
      return (
        <div className={styles.roleContent}>{_showMap.map((item) => item)}</div>
      );
    },
    [rulesList],
  );

  useEffect(() => {
    if (groupId && open) handlerGetLists();
  }, [groupId, open]);
  return (
    <Drawer
      title="规则配置"
      width={640}
      open={open}
      destroyOnClose
      bodyStyle={{ padding: '0 14px' }}
      onClose={() => onCancel?.()}
      extra={
        <Button type="primary" block onClick={() => setType(1)}>
          新增
        </Button>
      }
      footer={
        <Pagination
          current={pageIndex}
          showSizeChanger={true}
          pageSize={pageSize}
          total={total}
          showTotal={(total) => `总共 ${total} 条`}
          onChange={onChange}
        />
      }
      footerStyle={{ textAlign: 'right' }}
    >
      <Spin spinning={isLoading}>
        <div className={styles.rulesWrap}>
          {rulesList.map((item) => (
            <div key={item.id} className={styles.rulesItem}>
              {access?.authCodeList?.includes('Call-Limit-Blacklist-Edit') && (
                <Dropdown
                  menu={{ items: getDropdownList(item) }}
                  placement="bottomRight"
                  trigger={['click']}
                >
                  <MoreOutlined className={styles.edit} />
                </Dropdown>
              )}
              <p className={styles.label}>规则名称: {item.ruleName} </p>
              <p className={styles.label}>禁呼时长: {item.dayLimit}天 </p>
              <p className={styles.label}>
                话术范围: {item.speeches?.map((i) => `${i.name}；`)}
              </p>
              <p className={styles.label}>
                行业范围: {item?.sceneNames?.map((i) => `${i}；`)}
              </p>
              <p className={styles.label}>规则配置: </p>
              {getRuleContent(item)}
              {item?.intentClassify && (
                <p className={styles.label}>
                  意向分类: {item?.intentClassify}{' '}
                </p>
              )}
            </div>
          ))}
          {!!rulesList?.length &&
            [1, 2].map((item) => (
              <div key={item} className={styles.fill}></div>
            ))}
          {!rulesList?.length && (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} style={{ flex: 1 }} />
          )}
        </div>
      </Spin>
      <EditBlackRules
        type={type}
        info={curInfo}
        onOk={handleRuleFormOk}
        groupId={groupId}
        onCancel={() => {
          setCurInfo(undefined);
          setType(0);
        }}
      />
    </Drawer>
  );
};

export default BlackRuleDrawer;
