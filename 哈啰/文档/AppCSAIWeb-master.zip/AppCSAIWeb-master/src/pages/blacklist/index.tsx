import React, { useEffect, useState, useRef, useCallback } from 'react';
import styles from './index.less';
import {
  Button,
  Spin,
  Modal,
  Form,
  Input,
  message,
  Table,
  Popconfirm,
  Cascader,
  Empty,
  Pagination,
  Space,
  Typography,
  Select,
} from 'antd';
import {
  SearchOutlined,
  InboxOutlined,
  VerticalAlignBottomOutlined,
  SettingOutlined,
} from '@ant-design/icons';
import AddCard from '@/components/AddCard';
import {
  getBlackCard,
  getDropList,
  addBlackGroup,
  delBlackGroup,
  uploadBlack,
  editBlackGroup,
  blackListLog,
  delDlackListLog,
  findBlackList,
  // findCard,
  AddblackGroupType,
  EditBlackGroupType,
  exportBlackListLog,
} from '@/api/blacklist';
import FileUploadShowList from '@/components/FileUploadShowList';
import { useAccess, useModel } from '@umijs/max';
import BlackRuleDrawer from './components/BlackRulePop';
import AddBlack from './components/AddBlack';
import { httpReplace } from '@/utils';
import { validatePhoneNumberV2 } from '@/utils/validate';
import { DefaultOptionType } from 'antd/lib/cascader';

const { TextArea } = Input;
const { SHOW_CHILD } = Cascader;
type IptStatusType = '' | 'warning' | 'error';
type ITenantRange = 'tenantList' | 'excludeTenantList' | undefined;

const BlackList: React.FC = () => {
  const { tenantOpts, fetchTenantOpts } = useModel('common');
  const queryParams = useRef({
    pageNum: 1,
    pageSize: 100,
  });
  const [form] = Form.useForm();
  const access = useAccess();
  const ref = useRef();
  const tableRef = useRef();
  // 第一个card阴影 guid
  const [flag, setFlag] = useState('');
  // cardData
  const [cardData, setCardData] = useState([]);
  // 商户弹窗
  const [isModalOpen, SetIsModalOpen] = useState(false);
  // 商户编辑/新增
  const [isAdd, setIsAdd] = useState(false);
  const [isLoadingCard, setIsLoadingCard] = useState(true);
  const [addCardOpt, setAddCardOption] = useState([]);
  const [showImportModal, setShowImportModal] = useState(false);
  const [showAddBlackModal, setShowAddBlackModal] = useState(false);
  const [fileUploadFailUrl, setFileUploadFailUrl] = useState('');
  const [tableData, setTableData] = useState([]);
  const [iptValue, setIptValue] = useState('');
  const [fileList, setFileList] = useState([]);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [searchData, setSearchData] = useState([]);
  const [iptStatus, setIptStatus] = useState<IptStatusType>('');
  const [fileName, setFileName] = useState('');
  const [searchStatus, setSearchStatus] = useState(false);
  const [tableHeight, setTableHeight] = useState(null);
  const [pageIndex, setPageIndex] = useState(1);
  const [pageSize, setPageSize] = useState(100);
  const [total, setTotal] = useState<number>(0);
  // 规则弹窗
  const [showRuleModal, setShowRuleModal] = useState(false);

  // 适用场景搜索
  const [searchSceneValue, setSearchSceneValue] = useState('');

  // 租户范围
  const [tenantRange, setTenantRange] = useState<ITenantRange>();

  // 验证
  const handleValidatorBiz = async (rule, value) => {
    let res = Promise.resolve();
    if (value?.length) {
      value?.forEach((item) => {
        if (item?.length === 1 || item?.length === 2)
          res = Promise.reject('存在行业不是三级');
      });
    } else {
      // 没有选「租户范围」和「适用场景」
      if (!tenantRange) {
        res = Promise.reject(
          new Error('「租户范围」和「适用场景」至少选择一个'),
        );
      }
    }
    return res;
  };

  // api
  const getBlackCards = async () => {
    setIsLoadingCard(true);
    const { data } = await getBlackCard();
    if (data.length > 0) {
      data.forEach((it) => {
        it.sceneNames = it.sceneNames.join(';');
        it.createTime = it.createTime.replace('T', ' ');
      });
      setCardData(data);
      const zIndex = data.findIndex((item) => item?.id === flag);
      if (zIndex > -1) {
        setFlag(data[zIndex]?.id);
      } else {
        setFlag(data[0]?.id);
      }
      setIsLoadingCard(false);
    } else setIsLoadingCard(false);
  };
  const getDropLists = async () => {
    const { data } = await getDropList({ includeScene: true });
    const newData = JSON.parse(
      JSON.stringify(data).replace(/name/g, 'label').replace(/id/g, 'value'),
    );
    setAddCardOption(newData);
  };
  const addBlackGroups = async (obj: AddblackGroupType) => {
    await addBlackGroup(obj);
  };
  const editBlackGroups = async (obj: EditBlackGroupType) => {
    const res = await editBlackGroup(obj);
    console.log(res);
  };
  const delBlackGroups = async (id: string) => {
    await delBlackGroup({ id });
  };
  const blackListLogs = async (groupId: string) => {
    const data = await blackListLog({ ...queryParams.current, groupId });
    data?.list?.forEach((it) => {
      it.createTime = it.createTime.replace('T', ' ');
    });
    setTableData(data?.list);
    setTotal(data?.totalRecord);
    setSearchStatus(false);
    setIptValue('');
    setIptStatus('');
  };
  const delDlackListLogs = async (id: string) => {
    await delDlackListLog({ id });
    blackListLogs(flag);
  };
  const findBlackLists = async (mobile: string, groupId: string) => {
    const { data } = await findBlackList({ mobile, groupId });
    setSearchData(data);
  };
  // const findCards = async (id: string) => {
  //   const res = await findCard({ id });
  //   console.log('findCards', res);
  // };
  // 高亮
  const heightLight = (id) => {
    setFlag(id);
  };

  // 显示左侧弹窗
  const isShow = () => {
    SetIsModalOpen(!isModalOpen);
    setIsAdd(false);
  };

  // 新增黑名单组
  const addBlack = () => {
    // form.resetFields()
    isShow();
    setIsAdd(!isAdd);
  };

  const handleCancel = () => {
    getBlackCards();
    isShow();
  };
  const handleOk = () => {
    form.validateFields().then(async (res) => {
      if (res.groupName) {
        const { groupName, groupDesc, sceneIds } = res || {};
        // 「适用场景」「适用租户」「不适用租户」：前端没有选择时传空数组[]
        const _params: AddblackGroupType | EditBlackGroupType = {
          groupName,
          groupDesc,
          sceneIds: sceneIds?.map((item) => item[2]) || [],
          tenantList: [],
          excludeTenantList: [],
        };

        // 租户范围
        if (tenantRange) {
          _params[tenantRange] = res?.showTenantList;
        }

        if (isAdd) {
          await addBlackGroups(_params);
        } else {
          (_params as EditBlackGroupType).id = flag;
          await editBlackGroups(_params as EditBlackGroupType);
        }
        handleCancel();
      }
    });
  };

  const delClick = async (id) => {
    await delDlackListLogs(id);
    getBlackCards();
  };

  const handleExport = async (info) => {
    const dest = message.loading('正在下载');
    const res = await exportBlackListLog({ id: info?.id });
    if (res.success) {
      let elink = document.createElement('a');
      elink.style.display = 'none';
      let newUrl = httpReplace(res?.data?.ossUrl);
      elink.href = newUrl;
      // elink.download = '名单模版';
      document.body.appendChild(elink);
      elink.click();
      setTimeout(() => {
        document.body.removeChild(elink);
      }, 300);
    }
    dest?.();
  };

  const columns = [
    {
      title: '文件名',
      dataIndex: 'recordName',
      key: 'recordName',
    },
    {
      title: '名单数',
      dataIndex: 'listNumber',
      key: 'listNumber',
    },
    {
      title: '上传状态',
      dataIndex: 'recordStatus',
      key: 'recordStatus',
      render: (text) => {
        switch (text) {
          case 0:
            return '上传中';
          case 1:
            return '上传成功';
          case 2:
            return '上传失败';
          default:
            return '';
        }
      },
    },
    {
      title: '有效名单数',
      dataIndex: 'validListNumber',
      key: 'validListNumber',
    },
    {
      title: '添加人',
      dataIndex: 'author',
      key: 'author',
    },
    {
      title: '添加时间',
      dataIndex: 'createTime',
      key: 'createTime',
    },
    {
      title: '操作',
      dataIndex: 'op',
      key: 'op',
      render: (op, record) => {
        return access?.authCodeList?.includes('Call-Limit-Blacklist-Edit') ? (
          <Space direction="horizontal">
            <Popconfirm
              title=""
              okText="确定"
              cancelText="取消"
              onConfirm={() => delClick(record.id)}
              // onCancel={delCard}
              icon={<></>}
            >
              <a href="#">删除</a>
            </Popconfirm>
            <Typography.Link onClick={() => handleExport(record)}>
              下载
            </Typography.Link>
          </Space>
        ) : (
          ''
        );
      },
    },
  ];
  const delBlack = async (id) => {
    await delBlackGroups(id);
    getBlackCards();
  };

  useEffect(() => {
    getDropLists();
    getBlackCards();
    fetchTenantOpts();
  }, []);

  useEffect(() => {
    if (flag) {
      blackListLogs(flag);
    }
    if (tableRef.current) {
      // @ts-ignore
      setTableHeight(tableRef.current.clientHeight);
    }
  }, [flag]);

  // 回显
  useEffect(() => {
    if (isModalOpen && !isAdd) {
      const obj: any = cardData.filter((it) => it.id === flag);
      // console.log('objjj', obj);
      const arr: any = [];

      obj[0].sceneIds.forEach((it) => {
        const id = it;
        addCardOpt.forEach((item) => {
          item.children.forEach((i) => {
            const x = i.children.filter((j) => j.value === id);
            if (x.length) {
              x.forEach((h) => {
                arr.push([item.value, i.value, h.value]);
              });
            }
          });
        });
      });

      // 回显租户范围
      let _showTenantList = [];
      const { tenantList: _tenantList, excludeTenantList: _excludeTenantList } =
        obj?.[0] || {};

      if (_tenantList?.length) {
        setTenantRange('tenantList');
        _showTenantList = _tenantList;
      }

      if (_excludeTenantList?.length) {
        setTenantRange('excludeTenantList');
        _showTenantList = _excludeTenantList;
      }

      form.setFieldsValue({
        ...obj[0],
        sceneIds: arr,
        showTenantList: _showTenantList,
      });
    }
    if (!isModalOpen) {
      form.resetFields();
      setSearchSceneValue('');
      setTenantRange(undefined);
    }
  }, [isModalOpen]);

  // 导入
  const handleImport = () => {
    setShowImportModal(true);
  };

  // 导入取消
  const handleImportCancel = () => {
    setShowImportModal(false);
    // @ts-ignore
    if (ref.current) ref.current?.clearData();
    setFileUploadFailUrl('');
    setFileList([]);
  };

  // 导入提交
  const handleImportOk = async () => {
    const list = fileList?.filter((item) => item.status === 'done');
    if (!list?.length) return message.error('请先上传文件');
    setConfirmLoading(true);
    const dest = message.loading('正在导入');
    const res = await uploadBlack({
      groupId: flag,
      aliOssUrl: list[0].url,
      fileName,
    });
    // console.log('resssssss', res);

    if (res.success && res.data) {
      handleImportCancel();
      setShowImportModal(false);
      blackListLogs(flag);
    } else if (!res.success) {
      message.error('导入失败');
      // setFileUploadFailUrl(res?.data?.aliOssUrl);
    }
    dest?.();
    getBlackCards();
    setConfirmLoading(false);
  };

  const iptChange = (e) => {
    const a = e.target.value.replace(/[^\d]/g, '');
    if (!validatePhoneNumberV2(a)) {
      setIptStatus('error');
    } else {
      setIptStatus('');
    }
    setIptValue(a);
    // console.log(a);
  };

  const onBlur = () => {
    if (iptValue.length === 0) {
      setIptStatus('');
    }
  };

  const search = () => {
    if (validatePhoneNumberV2(iptValue)) {
      findBlackLists(iptValue, flag);
      setSearchStatus(true);
    }
  };

  const fileNameFC = (name: string) => {
    setFileName(name);
  };
  const validGroupName = (_, value) => {
    if (value?.length > 30) return Promise.reject('黑名单组名应小于等于30字');
    return Promise.resolve();
  };
  const validGroupDesc = (_, value) => {
    if (value?.length > 120) return Promise.reject('备注应小于等于120字');
    return Promise.resolve();
  };

  // 分页
  const onChange = (page: number | undefined, size: number | undefined) => {
    if (size !== pageSize) {
      queryParams.current.pageNum = 1;
      queryParams.current.pageSize = size;
      setPageIndex(1);
      setPageSize(size);
    } else {
      setPageIndex(page);
      queryParams.current.pageNum = page;
    }
    blackListLogs(flag);
  };

  const handleAddModalOk = useCallback(() => {
    blackListLogs(flag);
  }, [flag]);

  // 搜索过滤
  const bizfilter = (inputValue: string, path: DefaultOptionType[]) =>
    path.some(
      (option) =>
        (option.label as string)
          ?.toLowerCase()
          ?.indexOf(inputValue.toLowerCase()) > -1,
    );

  // 租户范围change
  const handleTenantRangeChange = (value: ITenantRange) => {
    setTenantRange(value);

    // 没有租户范围时清空租户
    if (!value) {
      form.setFieldValue('showTenantList', undefined);
    }

    // 判断如果「适用场景」有提示error就validateFields
    const sceneIdsErrorLen = form.getFieldError('sceneIds');
    if (sceneIdsErrorLen?.length > 0) {
      form.validateFields(['sceneIds']);
    }
  };

  return (
    <>
      <div className={styles.linesupplier}>
        <div className={styles.left}>
          {access?.authCodeList?.includes('Call-Limit-Blacklist-GroupAdd') && (
            <div className={styles.btn}>
              <Button type="primary" size="large" block onClick={addBlack}>
                新增黑名单组
              </Button>
            </div>
          )}
          <div className={styles.cardlist}>
            <Spin spinning={isLoadingCard} className={styles.spin}>
              <div style={{ height: '100%' }}>
                {cardData.length > 0 ? (
                  cardData.map((it) => (
                    <AddCard
                      key={it.id}
                      title={it.groupName}
                      goodsCode={it.sceneNames}
                      contacts={(+it.validListNumber).toLocaleString()}
                      time={it.createTime}
                      id={it.id}
                      heightLight={heightLight}
                      flag={flag}
                      status={it.supplierStatus}
                      isShow={isShow}
                      codeType={3}
                      isBlack={1}
                      delBalck={() => delBlack(it.id)}
                      editAuth={access?.authCodeList?.includes(
                        'Call-Limit-Blacklist-GroupEdit',
                      )}
                    />
                  ))
                ) : (
                  <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                )}
              </div>
            </Spin>
          </div>
        </div>
        <div className={styles.right}>
          <div className={styles.header}>
            <Input
              // type="number"
              placeholder="手机号"
              suffix={<SearchOutlined onClick={search} />}
              style={{ width: '300px' }}
              maxLength={15}
              value={iptValue}
              onChange={iptChange}
              onPressEnter={search}
              status={iptStatus}
              onBlur={onBlur}
            />
            {access?.authCodeList?.includes('Call-Limit-Blacklist-Add') && (
              <Space>
                <Button
                  type="primary"
                  icon={<SettingOutlined />}
                  onClick={() => {
                    setShowRuleModal(true);
                  }}
                >
                  黑名单规则配置
                </Button>
                <Button type="primary" onClick={handleImport}>
                  上传
                </Button>
                <Button
                  type="primary"
                  ghost
                  onClick={() => setShowAddBlackModal(true)}
                >
                  添加
                </Button>
              </Space>
            )}
          </div>
          <div className={styles.uploadLog}>
            {searchStatus ? (
              searchData.length ? (
                searchData.map((it, index) => (
                  <p key={index}>
                    <span>文件名：{it.recordName}</span>
                    <span style={{ marginLeft: '100px' }}>
                      过期日：
                      {it.blacklistType === 1
                        ? '永久过期'
                        : it.expireTime.replace('T00:00:00', '')}
                    </span>
                  </p>
                ))
              ) : (
                <p>暂无数据</p>
              )
            ) : (
              <></>
            )}
          </div>
          <p>上传记录</p>
          <div className={styles.table} ref={tableRef}>
            <Table
              columns={columns}
              dataSource={tableData}
              scroll={{ y: tableHeight - 55 }}
              rowKey={(record) => record.id}
              pagination={false}
            />
          </div>
          <div className={styles.subPagination}>
            <Pagination
              current={pageIndex}
              showSizeChanger={true}
              pageSize={pageSize}
              total={total}
              showTotal={(total) => `总共 ${total} 条`}
              onChange={onChange}
            />
          </div>
        </div>
      </div>

      {/* 左侧黑名单组 */}
      <Modal
        title="编辑"
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        getContainer={false}
        okText="提交"
        forceRender
      >
        <Form form={form} labelCol={{ span: 5 }} wrapperCol={{ span: 15 }}>
          <Form.Item
            label="黑名单组名"
            name="groupName"
            rules={[
              { required: true, message: '请输入' },
              { validator: validGroupName },
            ]}
          >
            <Input placeholder="请输入" />
          </Form.Item>
          <Form.Item label="租户范围">
            <Form.Item noStyle>
              <Select
                placeholder="请选择"
                allowClear
                value={tenantRange}
                onChange={handleTenantRangeChange}
              >
                <Select.Option value="tenantList">适用租户</Select.Option>
                <Select.Option value="excludeTenantList">
                  不适用租户
                </Select.Option>
              </Select>
            </Form.Item>
            {tenantRange && (
              <Form.Item
                style={{ margin: '10px 0 0' }}
                name="showTenantList"
                rules={[
                  { required: true, message: '请选择租户' },
                  {
                    validator: (_, value) => {
                      if (value?.length > 6) {
                        return Promise.reject(new Error('最多选6个租户'));
                      }
                      return Promise.resolve();
                    },
                  },
                ]}
              >
                <Select
                  placeholder="请选择租户"
                  allowClear
                  showSearch
                  mode="multiple"
                  optionFilterProp="label"
                  options={tenantOpts}
                />
              </Form.Item>
            )}
          </Form.Item>
          <Form.Item
            label="适用场景"
            name="sceneIds"
            rules={[
              {
                required: tenantRange === 'excludeTenantList',
                message: '请选择行业',
              },
              { validator: handleValidatorBiz },
            ]}
          >
            <Cascader
              options={addCardOpt}
              changeOnSelect
              multiple
              showCheckedStrategy={SHOW_CHILD}
              displayRender={(label) => label.join('/')}
              placeholder="请选择适用场景"
              showSearch={{ filter: bizfilter, limit: 500 }}
              onSearch={setSearchSceneValue}
              searchValue={searchSceneValue}
            />
          </Form.Item>

          <Form.Item
            label="备注"
            name="groupDesc"
            rules={[
              { required: true, message: '请输入' },
              { validator: validGroupDesc },
            ]}
          >
            <TextArea rows={3} />
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        open={showImportModal}
        title="批量导入"
        forceRender={true}
        width={'540px'}
        onOk={handleImportOk}
        onCancel={handleImportCancel}
        confirmLoading={confirmLoading}
        getContainer={false}
        destroyOnClose={true}
      >
        <FileUploadShowList
          // @ts-ignore
          ref={ref}
          showUploadList={true}
          uploadType=".xlsx,.xls"
          onChange={(list) => setFileList(list)}
          fileNameFC={fileNameFC}
        >
          <div className={styles.uploadIcon}>
            <InboxOutlined />
          </div>
          <div className={styles.notice}>点击或将文件拖拽到这里上传</div>
          <div className={styles.uploadType}>支持扩展名：&nbsp;.xlsx</div>
        </FileUploadShowList>
        <div style={{ textAlign: 'right' }}>
          <Button
            type="link"
            size="small"
            href="https://m.hellobike.com/resource/helloyun/wb23958/%E9%BB%91%E5%90%8D%E5%8D%95%E5%AF%BC%E5%85%A5%E6%A8%A1%E7%89%88.xlsx"
          >
            下载模版
          </Button>
        </div>
        {fileUploadFailUrl && !!fileList?.length && (
          <div className={styles.errorUploadWrap}>
            <VerticalAlignBottomOutlined className={styles.errorUploadIcon} />
            <a
              rel="noreferrer"
              target="_blank"
              href={fileUploadFailUrl}
              className={styles.errorUploadText}
            >
              下载导入失败数据
            </a>
          </div>
        )}
      </Modal>

      {/* 添加黑名单Modal */}
      <AddBlack
        showAddBlackModal={showAddBlackModal}
        onOk={handleAddModalOk}
        groupId={flag}
        onCancel={useCallback(() => setShowAddBlackModal(false), [])}
      />

      <BlackRuleDrawer
        open={showRuleModal}
        groupId={flag}
        onCancel={() => setShowRuleModal(false)}
      />
    </>
  );
};

export default BlackList;
