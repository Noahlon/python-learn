import React from 'react';
import { Form, Select, Button, Row, Col, Space, DatePicker } from 'antd';
import { SmsTemplateParams } from '@/api/smsTemplate';
import { distributaryStatusOpts, distributaryOpts } from '../../config';
import { SEARCHLAYOUT } from '@/constants/processconfig';
import moment from 'moment';
import { formatType, timeRanges } from '@/config';

interface IProps {
  onSearch: (data: SmsTemplateParams) => void;
  onReset: () => void;
  type?: string; //类型为outbound是外呼， distributary为分流平台
}

const { RangePicker } = DatePicker;

const SearchForm: React.FC<IProps> = ({ onSearch, onReset }) => {
  const [form] = Form.useForm();

  // 重置
  const handleReset = () => {
    form.resetFields();
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    if (res?.operatorTime?.length > 1) {
      res.createTimeStart = moment(res.operatorTime[0]).format(formatType);
      res.createTimeEnd = moment(res.operatorTime[1]).format(formatType);
    }
    delete res?.operatorTime;
    onSearch?.(res);
  };

  return (
    <Form form={form} style={{ padding: '20px 20px 0' }}>
      <Row wrap={false}>
        <Col flex="auto">
          <Row gutter={16}>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="bizType" label="文件类型">
                <Select
                  allowClear
                  showSearch
                  optionFilterProp="label"
                  placeholder="请选择文件类型"
                  options={distributaryOpts}
                />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="status" label="状态">
                <Select
                  allowClear
                  showSearch
                  optionFilterProp="label"
                  placeholder="请选择状态"
                  options={distributaryStatusOpts}
                />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="operatorTime" label="操作时间">
                <RangePicker
                  allowClear
                  showTime
                  placeholder={['开始时间', '结束时间']}
                  ranges={timeRanges}
                  style={{ width: '100%' }}
                />
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none" style={{ marginLeft: '15px' }}>
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default SearchForm;
