import React, { useEffect, useRef, useState } from 'react';
import type { ColumnsType } from 'antd/es/table';
import { Button } from 'antd';
import { DEFAULT_QUERY_PARAMS } from '@/config';
import SearchForm from './SearchForm';
import ResizeTable from '@/components/ResizeTable';
import {
  IDgetFileExportRecordObj,
  IDExportListParams,
  getFileExportRecordList,
} from '@/api/exportManage';
import { handleDownload } from '@/utils';
import { fileExportColumns } from '../../config';
import styles from '../../index.less';

const TableList: React.FC = () => {
  // table data
  const [tableData, setTableData] = useState<IDgetFileExportRecordObj[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  // pagination
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [tableTotal, setTableTotal] = useState<number>();
  // 搜索params
  const queryParams = useRef<IDExportListParams>(DEFAULT_QUERY_PARAMS);

  // fetch下载列表
  const fetchFileExportList = async () => {
    setTableLoading(true);
    const params = { ...queryParams.current };

    const res = await getFileExportRecordList(params);
    if (res?.data) {
      setTableData(res.data?.list || []);
      setTableTotal(res.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // 下载列表columns
  const tableColumns: ColumnsType<IDgetFileExportRecordObj> = [
    ...fileExportColumns,
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 100,
      render: (_, record) => (
        <Button
          disabled={!record.fileUrl}
          onClick={() => handleDownload(record.fileUrl)}
          type="link"
        >
          下载
        </Button>
      ),
    },
  ];

  // 分页change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchFileExportList();
  };

  // 搜索
  const handleSearch = (res: ExportListParams) => {
    const params = { ...queryParams.current };
    queryParams.current = { ...params, ...res };
    handlePageChange(1);
  };

  // 重置
  const handleReset = () => {
    queryParams.current = DEFAULT_QUERY_PARAMS;
    setPagination(DEFAULT_QUERY_PARAMS);
    fetchFileExportList();
  };

  useEffect(() => {
    fetchFileExportList();
  }, []);

  return (
    <div className={styles.exportManageWrap}>
      {/* 搜索 */}
      <SearchForm onSearch={handleSearch} onReset={handleReset} />
      {/* 表格 */}
      <ResizeTable
        columns={tableColumns}
        dataSource={tableData}
        rowKey="guid"
        containerId="distributaryId"
        loading={tableLoading}
        pagination={{
          onChange: handlePageChange,
          current: pagination.pageNum,
          pageSize: pagination.pageSize,
          pageSizeOptions: [100, 200, 300],
          total: tableTotal,
        }}
      />
    </div>
  );
};

export default TableList;
