import { ExportListObj, IDgetFileExportRecordObj } from '@/api/exportManage';
import { text1Tooltip } from '@/utils/format';
import { Badge } from 'antd';
import { PresetStatusColorType } from 'antd/es/_util/colors';
import { ColumnsType } from 'antd/es/table';
import { toThousands } from '@/utils';
import React from 'react';

// 枚举
export const exportStatusOpts = [
  { label: '执行中', value: 'IN_PROGRESS', badgeStatus: 'processing' },
  { label: '执行成功', value: 'SUCCESS', badgeStatus: 'success' },
  { label: '执行失败', value: 'FAIL', badgeStatus: 'error' },
];

export const exportTypeOpts = [
  { label: '通话记录', value: 'CALL_DIALOGUE' },
  { label: '短信上行记录', value: 'SMS_REPLY_RECORD' },
  { label: '短信下行记录', value: 'SMS_RECORD' },
  { label: '任务名单', value: 'TELEPHONE_RECORD' },
];

// 外呼列表columns
export const exportColumns: ColumnsType<ExportListObj> = [
  {
    title: 'ID',
    dataIndex: 'guid',
    width: 200,
  },
  {
    title: '文件类型',
    dataIndex: 'bizTypeDesc',
    width: 120,
  },
  {
    title: '状态',
    dataIndex: 'statusCode',
    width: 120,
    render: (text: string) => {
      const curObj = exportStatusOpts.find((item) => item.value === text);
      return React.createElement(Badge, {
        status: curObj?.badgeStatus as PresetStatusColorType,
        text: curObj?.label,
      });
    },
  },
  {
    title: '操作时间',
    dataIndex: 'operatorTime',
    render: (text) => {
      return text ?? '-';
    },
    width: 180,
  },
  {
    title: '操作人',
    dataIndex: 'operatorName',
    width: 120,
  },
  {
    title: '失败原因',
    dataIndex: 'failReason',
    width: 180,
    render: (text: string) => text1Tooltip(text),
  },
  {
    title: '数据量',
    dataIndex: 'count',
    width: 160,
    align: 'right',
    render: (text: number) => {
      return toThousands(text, true);
    },
  },
];

// 分流类型下拉
export const distributaryOpts = [
  { label: '渠道通话记录', value: 1 },
  { label: '渠道短信记录', value: 2 },
];
export const distributaryStatusOpts = [
  { label: '执行中', value: 1, badgeStatus: 'processing' },
  { label: '执行成功', value: 2, badgeStatus: 'success' },
  { label: '执行失败', value: 3, badgeStatus: 'error' },
];
// 分流渠道列表columns
export const fileExportColumns: ColumnsType<IDgetFileExportRecordObj> = [
  {
    title: 'ID',
    dataIndex: 'id',
    width: 200,
  },
  {
    title: '文件类型',
    dataIndex: 'bizType',
    width: 120,
    render: (text: number) => {
      return text === 1 ? '渠道通话记录' : '渠道短信记录';
    },
  },
  {
    title: '状态',
    dataIndex: 'status',
    width: 120,
    render: (text: number) => {
      const curObj = distributaryStatusOpts.find((item) => item.value === text);
      return React.createElement(Badge, {
        status: curObj?.badgeStatus as PresetStatusColorType,
        text: curObj?.label,
      });
    },
  },
  {
    title: '操作时间',
    dataIndex: 'createTime',
    render: (text) => {
      return text ?? '-';
    },
    width: 180,
  },
  {
    title: '操作人',
    dataIndex: 'operator',
    width: 120,
  },
  {
    title: '失败原因',
    dataIndex: 'failReason',
    width: 180,
    render: (text: string) => text1Tooltip(text),
  },
  {
    title: '数据量',
    dataIndex: 'exportCount',
    width: 180,
    render: (text: string) => text1Tooltip(text),
  },
];
