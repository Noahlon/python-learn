import React, { useEffect, useMemo, useState } from 'react';
import { Tabs } from 'antd';
import OutBoundList from './components/outbound';
import DistributaryList from './components/distributary';
import styles from './index.less';

const ExportManage: React.FC = () => {
  const [activeKey, setActiveKey] = useState('outbound');
  useEffect(() => {}, []);
  const items = useMemo(() => {
    return [
      {
        label: '外呼',
        key: 'outbound',
        children: <OutBoundList></OutBoundList>,
      },
      {
        label: '分流平台',
        key: 'distributary',
        children: <DistributaryList></DistributaryList>,
      },
    ];
  }, [activeKey]);
  return (
    <div className={styles.exportManageBox}>
      <Tabs
        items={items}
        onChange={(key) => setActiveKey(key)}
        activeKey={activeKey}
      ></Tabs>
    </div>
  );
};

export default ExportManage;
