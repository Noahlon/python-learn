import React, { useEffect, useRef, useState } from 'react';
import {
  DownOutlined,
  UnorderedListOutlined,
  EditOutlined,
  ExclamationCircleOutlined,
  CheckOutlined,
  CloseOutlined,
} from '@ant-design/icons';
import { Tree, Dropdown, Space, Input, Spin, Modal } from 'antd';
import type { MenuProps } from 'antd';
import styles from './index.less';
import {
  getBizTreeList,
  updateField,
  updateBizScene,
  addField,
  createBizScene,
  delField,
  delBizScene,
} from '@/api/biz';
import { v1 as uuidv1 } from 'uuid';
import { debounce } from 'lodash';
import { useModel } from '@umijs/max';

// 新增 index，用于scrollTo
const getTreeIndex = (data) => {
  let count = 0;
  let count2 = 0;
  for (let i = 0; i < data.length; i++) {
    count++;
    if (data[i].name !== '') {
      if (data[i].children) {
        for (let j = 0; j < data[i].children.length; j++) {
          count++;
          if (data[i].children[j].name !== '') {
            if (data[i].children[j].children) {
              for (let k = 0; k < data[i].children[j].children.length; k++) {
                count++;
                if (data[i].children[j].children[k].name === '') {
                  count2 = count;
                }
              }
            }
          } else {
            count2 = count;
          }
        }
      }
    } else {
      count2 = count;
    }
  }
  return count2;
};

interface SelectObjType {
  bizType: number;
  name: string;
  id: string;
  level: number;
}

type EditStatusType = 'edit' | 'del' | 'addNextLevel' | 'addSameLevel' | '';

const FieldsManage: React.FC = () => {
  const ref = useRef(null);
  const ref2 = useRef(null);
  const ref3 = useRef(null);
  const { handleGetBizList } = useModel('speech');
  const [editStatus, setEditStatus] = useState<EditStatusType>('');
  const [treeList, setTreeList] = useState([]);
  const [inputEdit, setInputEdit] = useState('');
  const [loading, setLoading] = useState(false);
  const [addInput, setAddInput] = useState('');
  const [selectObj, setSelectObj] = useState<SelectObjType>({
    bizType: null,
    name: '',
    id: '',
    level: null,
  });
  const [editInputStatus, setEditInputStatus] = useState<'error' | ''>('');
  const [parentId, setParentId] = useState<null | string>();
  const [height, setHeight] = useState(300);
  const [addFlag, setAddFlag] = useState(false);

  // api
  const getBizTreeLists = async () => {
    setLoading(true);
    const { data } = await getBizTreeList({ includeScene: true });
    if (data) {
      const data2: any = data;
      const newData = data2.map((it) => {
        it.level = 1;
        it.disabled = false;
        it.children.forEach((item) => {
          item.level = 2;
          item.disabled = false;
          item.children.forEach((item3) => {
            item3.level = 3;
            item3.disabled = false;
          });
        });
        return it;
      });
      setTreeList(newData);
      setLoading(false);
    }
  };
  const updateFields = async (id, bizName) => {
    setLoading(true);
    await updateField({ id, bizName });
    handleGetBizList();
    setLoading(false);
  };
  const updateBizScenes = async (id, sceneName) => {
    setLoading(true);
    await updateBizScene({ id, sceneName });
    handleGetBizList();
    setLoading(false);
  };
  const addFields = async (parentId, bizName) => {
    setLoading(true);
    await addField({ parentId, bizName });
    handleGetBizList();
    setLoading(false);
  };
  const createBizScenes = async (bizId, sceneName) => {
    setLoading(true);
    await createBizScene({ bizId, sceneName });
    handleGetBizList();
    setLoading(false);
  };
  const delFields = async (id) => {
    setLoading(true);
    await delField({ id });
    handleGetBizList();
    setLoading(false);
  };
  const delBizScenes = async (id) => {
    setLoading(true);
    await delBizScene({ id });
    handleGetBizList();
    setLoading(false);
  };

  // 获取tree高度
  const handleHeightEvent = debounce(async () => {
    const tree = document.getElementById('tree');
    const _height = tree?.clientHeight || 300;
    setHeight(_height);
  }, 200);

  // 禁用树
  const disabledTreeList = () => {
    const data = JSON.parse(JSON.stringify(treeList).replace(/false/g, 'true'));
    setTreeList(data);
  };

  // 激活树
  const activeTreeList = () => {
    const data = JSON.parse(JSON.stringify(treeList).replace(/true/g, 'false'));
    setTreeList(data);
  };

  useEffect(() => {
    handleHeightEvent();
    window.addEventListener('resize', handleHeightEvent);
    getBizTreeLists();
  }, []);

  useEffect(() => {
    if (editStatus === 'edit' && selectObj.id) {
      disabledTreeList();
    }
  }, [editStatus, selectObj.id]);

  // 选中当前树
  const onSelect = (_, info) => {
    console.log('info', info.node);
    const obj = {
      bizType: info.node.bizType,
      name: info.node.name,
      id: info.node.id,
      level: info.node.level,
    };
    setSelectObj(obj);
  };

  const titleRender = (item: any) => {
    // 新增下级
    const addNextLevel = () => {
      if (!addFlag) {
        console.log('addNextLevel');
        setAddFlag(true);
        setEditStatus('addNextLevel');
        const data = JSON.parse(
          JSON.stringify(treeList).replace(/false/g, 'true'),
        );
        setTreeList([]);
        switch (selectObj.level) {
          case 1:
            data.forEach((it) => {
              if (it.id === selectObj.id) {
                it.children.push({
                  id: uuidv1(),
                  name: '',
                  level: 2,
                  bizType: 0,
                  active: true,
                  disabled: true,
                  children: [],
                });
                setParentId(it.id);
              }
            });

            break;
          case 2:
            data.forEach((it) => {
              it.children.forEach((item) => {
                if (item.id === selectObj.id) {
                  item.children.push({
                    id: uuidv1(),
                    name: '',
                    level: 3,
                    bizType: 0,
                    active: true,
                    disabled: true,
                  });
                  setParentId(item.id);
                }
              });
            });
            break;
          default:
            setParentId(null);
            break;
        }
        setTimeout(() => {
          setTreeList(data);
          const treeIndex = getTreeIndex(data) - 1;
          const tree = document.getElementById('tree');
          if (height < treeIndex * 28) {
            tree.scrollTo(0, treeIndex * 28);
          }
        }, 0);
      }
    };

    // 新增同级节点
    const addSameLevel = () => {
      if (!addFlag) {
        setAddFlag(true);
        setEditStatus('addSameLevel');
        const data = JSON.parse(
          JSON.stringify(treeList).replace(/false/g, 'true'),
        );
        switch (selectObj.level) {
          case 1:
            data.push({
              id: uuidv1(),
              name: '',
              level: 1,
              bizType: 0,
              active: true,
              disabled: true,
              children: [],
            });
            setParentId(null);
            break;

          case 2:
            data.forEach((it) => {
              it.children.forEach((item) => {
                if (item.id === selectObj.id) {
                  it.children.push({
                    id: uuidv1(),
                    name: '',
                    level: 2,
                    bizType: 0,
                    active: true,
                    disabled: true,
                    children: [],
                  });
                  setParentId(it.id);
                }
              });
            });
            break;

          case 3:
            data.forEach((it) => {
              it.children.forEach((item) => {
                item.children.forEach((item3) => {
                  if (item3.id === selectObj.id) {
                    item.children.push({
                      id: uuidv1(),
                      name: '',
                      level: 3,
                      bizType: 1,
                      active: true,
                      disabled: true,
                    });
                    setParentId(item.id);
                  }
                });
              });
            });
            break;

          default:
            setParentId(null);
            break;
        }
        setTreeList(data);
        // 滚动
        const treeIndex = getTreeIndex(data) - 1;
        const tree = document.getElementById('tree');
        if (height < treeIndex * 28) {
          tree.scrollTo(0, treeIndex * 28);
        }
      }
    };

    // 删除
    const del = async () => {
      if (selectObj.bizType === 0) {
        await delFields(selectObj.id);
      } else if (selectObj.bizType === 1) {
        await delBizScenes(selectObj.id);
      }
      getBizTreeLists();
    };

    // dropdown item
    const items: MenuProps['items'] = [
      {
        key: '1',
        label:
          selectObj.level !== 3 ? (
            <a onClick={addNextLevel}>新增子节点</a>
          ) : (
            <></>
          ),
      },
      {
        key: '2',
        label: <a onClick={addSameLevel}>下方添加节点</a>,
      },
      {
        key: '3',
        label: (
          <a
            onClick={() => {
              Modal.confirm({
                title: '确定删除吗？',
                icon: <ExclamationCircleOutlined />,
                content: '',
                okText: '确认',
                cancelText: '取消',
                onOk: del,
              });
            }}
          >
            删除
          </a>
        ),
      },
    ];

    // 保存
    const save = async () => {
      // 编辑
      if (selectObj.name !== inputEdit && inputEdit !== '') {
        if (selectObj.bizType === 0) {
          await updateFields(selectObj.id, inputEdit);
          getBizTreeLists();
        } else if (selectObj.bizType === 1) {
          await updateBizScenes(selectObj.id, inputEdit);
          getBizTreeLists();
        }
        setInputEdit('');
      }
      // 新增同级  level === 1 || 2
      if (addInput !== '' && editStatus === 'addSameLevel') {
        if (selectObj.bizType === 0) {
          await addFields(parentId, addInput);
          getBizTreeLists();
          setAddInput('');
        } else if (selectObj.bizType === 1) {
          await createBizScenes(parentId, addInput);
          getBizTreeLists();
          setAddInput('');
        }
      }
      // 新增子节点
      else if (addInput !== '' && editStatus === 'addNextLevel') {
        if (selectObj.level === 1) {
          await addFields(parentId, addInput);
          getBizTreeLists();
          setAddInput('');
        } else if (selectObj.level === 2) {
          await createBizScenes(parentId, addInput);
          getBizTreeLists();
          setAddInput('');
        }
      }
      setEditStatus('');
      setAddFlag(false);
      activeTreeList();
    };

    // 编辑
    const edit = () => {
      if (editStatus !== 'addNextLevel' && editStatus !== 'addSameLevel') {
        setEditStatus('edit');
        setInputEdit(item.name);
      }
    };

    // 新增时取消编辑
    const cancelEdit = () => {
      const data = JSON.parse(
        JSON.stringify(treeList).replace(/true/g, 'false'),
      );
      if (editStatus === 'addSameLevel') {
        data.forEach((it) => {
          if (it.id === selectObj.id) {
            data.pop();
          } else {
            if (it.children) {
              it.children.forEach((item) => {
                if (item.id === selectObj.id) {
                  it.children.pop();
                } else {
                  if (item.children) {
                    item.children.forEach((item3) => {
                      if (item3.id === selectObj.id) {
                        item.children.pop();
                      }
                    });
                  }
                }
              });
            }
          }
        });
      } else if (editStatus === 'addNextLevel') {
        data.forEach((it) => {
          if (it.id === selectObj.id) {
            it.children.pop();
          } else {
            it.children.forEach((item) => {
              if (item.id === selectObj.id) {
                item.children.pop();
              }
            });
          }
        });
      }
      setTreeList(data);
      setAddFlag(false);
      setAddInput('');
      setEditStatus('');
    };

    // 编辑input
    const editInputChange = (e) => {
      if (e.target.value === '') {
        setEditInputStatus('error');
      } else {
        setEditInputStatus('');
      }
      setInputEdit(e.target.value);
    };
    // 新增input
    const addInputChange = (e) => {
      setAddInput(e.target.value);
    };

    return (
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <div
          style={{
            width:
              item.level === 1
                ? `${300 + 48}px`
                : item.level === 2
                ? `${300 + 24}px`
                : '300px',
          }}
        >
          {(() => {
            if (item.name === selectObj.name && editStatus === 'edit') {
              return (
                <Input
                  value={inputEdit}
                  onChange={editInputChange}
                  status={editInputStatus}
                  maxLength={20}
                  ref={ref}
                />
              );
            } else if (item.name === '' && editStatus === 'addSameLevel') {
              // 新增同级
              return (
                <Input
                  value={addInput}
                  onChange={addInputChange}
                  maxLength={20}
                  ref={ref2}
                  status={item.active ? 'error' : ''}
                />
              );
            } else if (item.name === '' && editStatus === 'addNextLevel') {
              // 新增下级
              return (
                <Input
                  value={addInput}
                  onChange={addInputChange}
                  maxLength={20}
                  ref={ref3}
                  status={item.active ? 'error' : ''}
                />
              );
            } else {
              return item.name;
            }
          })()}
        </div>
        <div>
          {(() => {
            if (item.id === selectObj.id && editStatus === 'edit') {
              return (
                <>
                  <CheckOutlined
                    style={{
                      marginRight: '15px',
                      marginLeft: '5px',
                      color: '#000',
                    }}
                    onClick={save}
                  />
                </>
              );
            } else if (
              (item.name === '' && editStatus === 'addSameLevel') ||
              (item.name === '' && editStatus === 'addNextLevel')
            ) {
              return (
                <>
                  <CheckOutlined
                    style={{
                      marginRight: '15px',
                      marginLeft: '5px',
                      color: '#000',
                      cursor: 'pointer',
                    }}
                    onClick={addInput !== '' ? save : null}
                  />
                  <CloseOutlined
                    style={{ color: '#000' }}
                    onClick={cancelEdit}
                  />
                </>
              );
            } else {
              return (
                <>
                  <EditOutlined
                    style={{ marginRight: '15px', marginLeft: '5px' }}
                    onClick={item.disabled ? null : edit}
                  />
                  <Dropdown
                    menu={{ items }}
                    trigger={['click']}
                    destroyPopupOnHide
                    disabled={item.disabled}
                  >
                    <Space>
                      <UnorderedListOutlined />
                    </Space>
                  </Dropdown>
                </>
              );
            }
          })()}
        </div>
      </div>
    );
  };

  // input 光标
  useEffect(() => {
    setTimeout(() => {
      if (editStatus === 'edit' && ref.current) {
        ref.current.focus({ cursor: 'end' });
      } else if (editStatus === 'addSameLevel' && ref2.current) {
        ref2.current.focus({ cursor: 'end' });
      }
    }, 200);
  }, [editStatus]);

  return (
    <div className={styles.sectormanage}>
      <h2>行业列表</h2>
      <div id="tree" className={styles.tree}>
        {treeList.length > 0 ? (
          <Spin spinning={loading}>
            <Tree
              showLine
              autoExpandParent
              switcherIcon={<DownOutlined />}
              defaultExpandAll={true}
              defaultExpandParent
              onSelect={onSelect}
              treeData={treeList}
              titleRender={titleRender}
              fieldNames={{ title: 'name', key: 'id' }}
            />
          </Spin>
        ) : (
          <></>
        )}
      </div>
    </div>
  );
};

export default FieldsManage;
