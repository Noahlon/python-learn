import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import Summary from './components/Summary';
import FilterForm from './components/FilterForm';
import ResizeTable from '@/components/ResizeTable';
import { ColumnsType } from 'antd/es/table';
import {
  rosterListColumns,
  DEFAULT_QUERY_PARAMS,
  supportCarrierOpts,
} from './config';
import {
  FilterCriteria,
  RosterListObj,
  RosterListParams,
  RosterWanderRes,
  activeRoster,
  queryRosterList,
  queryRosterWander,
  recoveryRoster,
} from '@/api/project/nameInfo';
import { Modal, Popover, Space, Typography, message } from 'antd';
import { IdcardOutlined } from '@ant-design/icons';
import { useLocation, useModel } from '@umijs/max';
import { parse } from 'query-string';
import DistributeModal from './components/DistributeModal';
import NameDetailDrawer from './components/NameDetail';
import { toThousands } from '@/utils';
import { showEmptyLine } from '@/utils/format';
import styles from './index.less';

const { Paragraph } = Typography;

const NameList: React.FC = () => {
  const location = useLocation();
  const query = parse(location.search) as { guid: string };
  const {
    fetchRosterEnum,
    fetchAllSkillGroup,
    fetchRosterSummary,
    projectDetail,
  } = useModel('project.model');
  const [tableData, setTableData] = useState<RosterListObj[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  // pagination
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [tableTotal, setTableTotal] = useState<number>();

  // 搜索params
  const pageParams = useRef({ ...DEFAULT_QUERY_PARAMS });
  const queryParams = useRef<FilterCriteria>();

  // 获取待操作的名单info
  const [wanderInfo, setWanderInfo] = useState<RosterWanderRes['data']>();

  // 名单详情
  const [detailGuid, setDetailGuid] = useState<string>();

  // 下发
  const [distributeOpen, setDistributeOpen] = useState(false);
  // 激活
  const [activeOpen, setActiveOpen] = useState(false);
  const [activeLoading, setActiveLoading] = useState(false);
  // 回收
  const [recoveryOpen, setRecoveryOpen] = useState(false);
  const [recoveryLoading, setRecoveryLoading] = useState(false);

  // columns
  const columns: ColumnsType<RosterListObj> = [
    {
      title: '手机号',
      dataIndex: 'action',
      fixed: 'left',
      width: 260,
      render: (_, record) => {
        const {
          phoneNum,
          phoneNumMd5,
          customerName,
          companyName,
          uploadNewid,
          uploadGuid,
        } = record || {};
        const carrierIcon = supportCarrierOpts?.find(
          (item) => item.value === record.carrierType,
        )?.icon;
        return (
          <Space size="middle" align="center">
            <a onClick={() => setDetailGuid(record?.guid)}>{phoneNum}</a>
            <Paragraph
              copyable={{
                text: phoneNumMd5,
                tooltips: ['复制md5', '复制成功'],
              }}
            />
            <Popover
              placement="rightTop"
              content={
                <>
                  <div>姓名：{showEmptyLine(customerName)}</div>
                  <div>公司名称 ：{showEmptyLine(companyName)}</div>
                  <div>newid：{showEmptyLine(uploadNewid)}</div>
                  <div>guid：{showEmptyLine(uploadGuid)}</div>
                </>
              }
            >
              <a className={styles.idCardIcon}>
                <IdcardOutlined />
              </a>
            </Popover>
            {carrierIcon && (
              <img className={styles.mobileIcon} src={carrierIcon} />
            )}
          </Space>
        );
      },
    },
    ...rosterListColumns,
  ];

  // fetch名单列表
  const fetchRosterList = async () => {
    const params = {
      ...pageParams.current,
      ...queryParams.current,
      projectGuid: query?.guid,
    };

    setTableLoading(true);
    const res = await queryRosterList(params);
    if (res?.data) {
      setTableData(res.data?.list);
      setTableTotal(res.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // fetch待操作的名单数量
  const fetchRosterWander = async () => {
    const params = {
      ...queryParams.current,
      projectGuid: query?.guid,
    };
    const res = await queryRosterWander({
      ...params,
      projectGuid: query?.guid,
    });
    if (res?.data) {
      setWanderInfo(res.data);
    }
  };

  const updateApi = () => {
    setTimeout(() => {
      fetchRosterList(); // 更新列表
      fetchRosterWander(); // 更新wander
      fetchRosterSummary(query?.guid); // 更新summary
    }, 500);
  };

  // 激活名单
  const handleActiveRoster = async () => {
    setActiveLoading(true);
    const params = {
      ...queryParams.current,
      waitRosterCount: wanderInfo?.waitRosterCount,
      projectGuid: query?.guid,
    };
    const res = await activeRoster(params);
    if (res?.success) {
      setActiveOpen(false);
      message.success('激活成功，请在待下发列表查看');
    }
    setActiveLoading(false);
    updateApi();
  };

  // 回收名单
  const handleRecoveryRoster = async () => {
    setRecoveryLoading(true);
    const params = {
      ...queryParams.current,
      waitRosterCount: wanderInfo?.waitRosterCount,
      projectGuid: query?.guid,
    };
    const res = await recoveryRoster(params);
    if (res?.success) {
      setRecoveryOpen(false);
      message.success('回收成功，请在已回收列表查看');
    }
    setRecoveryLoading(false);
    updateApi();
  };

  // 下发名单回调
  const handleDistributeOk = async () => {
    updateApi();
  };

  // 页面页数change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? pageParams.current.pageSize,
    };
    pageParams.current = { ...pageParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchRosterList();
  };

  // 搜索
  const handleSearch = (res: RosterListParams) => {
    queryParams.current = { ...res };
    handlePageChange(1);
    fetchRosterWander();
  };

  useEffect(() => {
    fetchRosterEnum();
  }, []);

  useEffect(() => {
    if (projectDetail?.tenantCode) {
      fetchAllSkillGroup([projectDetail?.tenantCode]);
    }
  }, [projectDetail?.tenantCode]);

  // 虚拟列表（防止多次render，防止render时scrollTop变化为0）
  const virtualTable = useMemo(() => {
    return (
      <ResizeTable
        virtual
        columns={columns}
        dataSource={tableData}
        scroll={{ x: 5000 }}
        rowKey="guid"
        loading={tableLoading}
        containerId="rosterListId"
        pagination={{
          onChange: handlePageChange,
          current: pagination.pageNum,
          pageSize: pagination.pageSize,
          pageSizeOptions: [100, 300, 500],
          total: tableTotal,
        }}
      />
    );
  }, [tableData, tableLoading]);

  return (
    <>
      <div className={styles.nameListWrap}>
        {/* 统计 */}
        <Summary />
        {/* 筛选 */}
        <FilterForm
          onSearch={useCallback(handleSearch, [])}
          setDistributeOpen={useCallback(setDistributeOpen, [])}
          setActiveOpen={useCallback(setActiveOpen, [])}
          setRecoveryOpen={useCallback(setRecoveryOpen, [])}
        />

        {/* 名单列表 */}
        {virtualTable}
      </div>

      {/* 名单详情Drawer */}
      <NameDetailDrawer
        guid={detailGuid}
        projectGuid={query?.guid}
        onCancel={useCallback(() => setDetailGuid(undefined), [])}
      />

      {/* 下发Modal */}
      <DistributeModal
        open={distributeOpen}
        wanderInfo={wanderInfo}
        queryParams={queryParams.current}
        onCancel={useCallback(() => setDistributeOpen(false), [])}
        onOk={useCallback(handleDistributeOk, [])}
      />

      {/* 激活modal */}
      <Modal
        open={activeOpen}
        title="激活名单"
        confirmLoading={activeLoading}
        onOk={handleActiveRoster}
        onCancel={() => setActiveOpen(false)}
      >
        <span>已选中名单数：{toThousands(wanderInfo?.waitRosterCount)}</span>
      </Modal>

      {/* 回收modal */}
      <Modal
        open={recoveryOpen}
        title="回收名单"
        confirmLoading={recoveryLoading}
        onOk={handleRecoveryRoster}
        onCancel={() => setRecoveryOpen(false)}
      >
        <span>已选中名单数：{toThousands(wanderInfo?.waitRosterCount)}</span>
      </Modal>
    </>
  );
};

export default NameList;
