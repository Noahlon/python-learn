import type { ColumnsType } from 'antd/es/table';
import { text1Tooltip } from '@/utils/format';

import { HaTaskPageParams, ISkillGroupList } from '@/api/project/task';

// 任务列表columns
export const taskColumns: ColumnsType<HaTaskPageParams> = [
  {
    title: '任务名称',
    dataIndex: 'name',
    fixed: 'left',
    width: 200,
    render: (text: string) => text1Tooltip(text),
  },
  {
    title: '任务类型',
    dataIndex: 'taskTypeDesc',
    width: 120,
  },
  {
    title: '名单数',
    dataIndex: 'telephoneCount',
    width: 130,
  },
  {
    title: '任务状态',
    dataIndex: 'statusDesc',
    render: (text: string) => {
      return text ? text : '-';
    },
    width: 120,
  },
  {
    title: '实际并发',
    dataIndex: 'loadCount',
    width: 80,
    render: (text: number) => text ?? '-',
  },
  {
    title: '触达率',
    dataIndex: 'totalCallRate',
    width: 100,
    render: (values: string) => {
      if (values) {
        return `${values}%`;
      }
      return '-';
    },
  },

  {
    title: '完成率',
    dataIndex: 'completableRate',
    render: (values: string) => {
      if (values) {
        return `${values}%`;
      }
      return '-';
    },
    width: 100,
  },
  {
    title: '成功转接率',
    dataIndex: 'transferRate',
    render: (values: string) => {
      if (values) {
        return `${values}%`;
      }
      return '-';
    },
    width: 120,
  },
  {
    title: '待呼名单数',
    dataIndex: 'totalUnCall',
    width: 120,
  },
  {
    title: '创建人',
    dataIndex: 'createdByName',
    width: 120,
  },
  {
    title: '创建时间',
    dataIndex: 'createTime',
    width: 200,
  },
];

// 手动下发详情列表
export const manualColumns: ColumnsType<ISkillGroupList> = [
  {
    title: '技能组',
    fixed: 'left',
    dataIndex: 'skillGroupName',
    key: 'skillGroupName',
    ellipsis: true,
  },
  {
    title: '组长',
    dataIndex: 'groupLeaderName',
    key: 'groupLeaderName',
    ellipsis: true,
  },
  {
    title: '座席数',
    dataIndex: 'seatCount',
    key: 'seatCount',
    ellipsis: true,
    render: (text: number) => text ?? '-',
  },
  {
    title: '名单数',
    dataIndex: 'rosterCount',
    key: 'rosterCount',
    ellipsis: true,
    render: (text: number) => text ?? '-',
  },
];

// 任务列表默认params
export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 100,
};

// 任务类型
export const TaskType = [
  {
    label: '手动下发',
    value: 0,
  },
  {
    label: 'AI外呼',
    value: 1,
  },
  {
    label: '预测外呼',
    value: 2,
  },
  {
    label: '人机协作',
    value: 3,
  },
];
// 任务状态
export const TaskStatus = [
  {
    label: '草稿',
    value: 0,
    tagColor: 'green',
  },
  {
    label: '待执行',
    value: 1,
    tagColor: 'red',
  },
  {
    label: '执行中',
    value: 2,
    tagColor: 'orange',
  },
  {
    label: '已结束',
    value: 3,
    tagColor: 'default',
  },
  {
    label: '已暂停',
    value: 4,
    tagColor: 'purple',
  },
];
