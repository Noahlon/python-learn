import { RosterDetail } from '@/api/project/nameInfo';
import { Empty, Space } from 'antd';
import React from 'react';
import styles from './index.less';

interface Prop {
  data: RosterDetail['rosterImportRecordDTOList'];
}

const ImportRrcord: React.FC<Prop> = ({ data }) => {
  return (
    <div>
      {data?.length > 0 ? (
        <>
          {data.map((item) => (
            <div key={item.batchGuid} className={styles.importBox}>
              <div>
                <div>批次名称：{item.batchName}</div>
                <div>批次ID：{item.batchGuid}</div>
              </div>
              <Space className={styles.createTime}>
                <span>{item.createdByName}</span>
                <span>{item.createTime}</span>
              </Space>
            </div>
          ))}
        </>
      ) : (
        <Empty />
      )}
    </div>
  );
};

export default ImportRrcord;
