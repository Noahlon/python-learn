import { Button, Drawer, Modal, Space, Spin, message } from 'antd';
import React, { useEffect, useState } from 'react';
import TaskCreateEdit from '../TaskCreateEdit';
import Manual from './components/Manual';
import AIcall from './components/AIcall';
import ForecastCall from './components/ForecastCall';
import Manmachine from './components/Manmachine';
import {
  haTaskStart,
  haTaskDelete,
  haTaskStop,
  haTaskFinish,
  TaskDetailObj,
  haTaskDetail,
} from '@/api/project/task';
import { useModel } from '@umijs/max';
import styles from './index.less';

interface IPops {
  onOk?: () => void;
  onCancel?: () => void;
  taskGuid: string;
}

const TaskDrawer: React.FC<IPops> = (props) => {
  const { onOk, onCancel, taskGuid } = props;
  const { fetchProjectDetail, projectDetail } = useModel('project.model');
  const [detailLoading, setdetailLoading] = useState(false);
  const [currentTask, setCurrentTask] = useState<TaskDetailObj>();
  const [modalType, setModalType] = useState<number>(undefined);

  // 获取详情信息
  const fetchTaskDtail = async () => {
    setdetailLoading(true);
    const res = await haTaskDetail({ taskGuid });
    setCurrentTask(res?.data);
    setdetailLoading(false);
  };

  // 编辑更新
  const handleEditOk = () => {
    fetchTaskDtail(); // 更新任务详情
    onOk?.(); // 更新任务列表
  };

  useEffect(() => {
    if (!!taskGuid) {
      fetchTaskDtail();
    }
    return () => {
      setCurrentTask(null);
    };
  }, [taskGuid]);

  const handleAction = async (type: string) => {
    let title = '';
    let content = '';
    let action;

    switch (type) {
      case 'finish':
        title = '确定结束该任务？';
        content = '任务结束后无法再次启动';
        action = haTaskFinish;
        break;
      case 'delete':
        title = '确定删除该任务？';
        content = '删除后数据无法恢复';
        action = haTaskDelete;
        break;
      case 'running':
        title = '确定启动该任务？';
        content = '启动后，到达执行时间系统会自动下发名单';
        action = haTaskStart;
        break;
      case 'pasued':
        title = '确定暂停该任务？';
        action = haTaskStop;
        break;
    }
    Modal.confirm({
      title,
      content,
      okText: '确定',
      cancelText: '取消',
      onOk: async () => {
        const res = await action({ taskGuid });
        if (res?.success) {
          message.success({
            content: '操作成功',
            className: 'customMessageTop',
          });
          fetchTaskDtail();
          onOk?.();
          fetchProjectDetail(projectDetail?.guid);
          if (type === 'delete') {
            onCancel?.();
          }
        }
      },
    });
  };

  return (
    <Drawer
      open={!!taskGuid}
      title="详情"
      footer={false}
      width={800}
      onClose={onCancel}
      destroyOnClose
    >
      <Spin spinning={detailLoading}>
        <div className={styles.contentWrap}>
          {/* 操作按钮列表 */}
          <div className={styles.topBox}>
            <div className={styles.title}>{currentTask?.taskName}</div>
            <Space size="middle">
              {[0, 4].includes(currentTask?.status) && (
                <>
                  <Button type="primary" ghost onClick={() => setModalType(1)}>
                    编辑
                  </Button>
                  <Button
                    type="primary"
                    ghost
                    onClick={() => handleAction('running')}
                  >
                    启动
                  </Button>
                </>
              )}
              {[4].includes(currentTask?.status) && (
                <Button
                  type="primary"
                  ghost
                  onClick={() => handleAction('finish')}
                >
                  结束
                </Button>
              )}
              {[0].includes(currentTask?.status) && (
                <Button
                  type="primary"
                  ghost
                  onClick={() => handleAction('delete')}
                >
                  删除
                </Button>
              )}
              {([1].includes(currentTask?.status) ||
                ([2].includes(currentTask?.status) &&
                  currentTask?.taskType !== 0)) && (
                <Button
                  type="primary"
                  ghost
                  onClick={() => handleAction('pasued')}
                >
                  暂停
                </Button>
              )}
            </Space>
          </div>

          {/* 手动下发详情 */}
          {currentTask?.taskType === 0 && <Manual currentTask={currentTask} />}
          {/* Ai外呼详情 */}
          {currentTask?.taskType === 1 && <AIcall currentTask={currentTask} />}
          {/* 预测外呼详情 */}
          {currentTask?.taskType === 2 && (
            <ForecastCall currentTask={currentTask} handleOk={fetchTaskDtail} />
          )}
          {/* 人机协作详情 */}
          {currentTask?.taskType === 3 && (
            <Manmachine currentTask={currentTask} handleOk={fetchTaskDtail} />
          )}

          {/* 编辑modal */}
          <TaskCreateEdit
            modalType={modalType}
            closeModal={() => setModalType(undefined)}
            taskRecord={currentTask}
            onOk={handleEditOk}
          />
        </div>
      </Spin>
    </Drawer>
  );
};

export default TaskDrawer;
