import { RosterDetail } from '@/api/project/nameInfo';
import { Empty, Space, Steps } from 'antd';
import React from 'react';

interface Prop {
  data: RosterDetail['rosterWanderInfoList'];
}

const WanderRrcord: React.FC<Prop> = ({ data }) => {
  return (
    <div>
      {data?.length > 0 ? (
        <Steps
          progressDot
          direction="vertical"
          items={data.map((item) => ({
            status: 'finish',
            title: <span style={{ marginRight: 30 }}>{item.operation}</span>,
            subTitle: (
              <Space size={10}>
                <span>{item.createdByName}</span>
                <span>{item.createTime}</span>
              </Space>
            ),
          }))}
        />
      ) : (
        <Empty />
      )}
    </div>
  );
};

export default WanderRrcord;
