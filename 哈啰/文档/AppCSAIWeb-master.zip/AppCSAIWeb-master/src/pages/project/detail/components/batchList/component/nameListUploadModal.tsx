import React, { memo, useEffect, useState } from 'react';
import { Button, Modal, Form, Radio, Upload, message, Typography } from 'antd';
import { CloudUploadOutlined } from '@ant-design/icons';
import { UploadChangeParam, UploadFile } from 'antd/es/upload';
import {
  rosterDownloadTemplate,
  rosterBatchImportAdd,
  RosterBatchImportAddParams,
} from '@/api/project/batch';
import { httpReplace } from '@/utils';
import { uploadFile } from '@/api/language';
import { useModel } from '@umijs/max';

interface UploadPropsType {
  open?: boolean;
  projectGuid?: any;
  onOk: () => void;
  onCancel: () => void;
}
const NameListUploadModal: React.FC<UploadPropsType> = memo(
  ({ open, onOk, projectGuid, onCancel }) => {
    const { fetchProjectDetail, projectDetail } = useModel('project.model');
    const [confirmLoading, setConfirmLoading] = useState(false);
    const [fileList, setFileList] = useState<any[]>([]);
    const [type, setType] = useState('0');
    const layout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 18 },
    };
    const nameUploadTypeOpts = [
      { label: '明文', value: '0' },
      { label: 'newId', value: '1' },
      { label: 'guid', value: '2' },
    ];

    const beforeUpload = (file:any) => {
      const isLt2M = file.size / 1024 / 1024 < 10;
      if (!isLt2M) {
        message.error('文件不能超过10M!');
        return false;
      }
      setFileList([]);
      return true;
    };

    // const handleUpload = async (Info) => {
    //     const file = Info.file;
    //     const list = [
    //     {
    //         status: 'done',
    //         file: file,
    //         name: file?.name,
    //     },
    //     ];
    //     setFileList(list);
    // };
    const handleUpload = async ({ file }) => {
      const formData = new FormData();
      formData.append('file', file);

      try {
        const res = (await uploadFile(formData)) as any;
        if (res) {
          const list = [
            {
              status: 'done',
              file: res?.url,
              name: file?.name,
            },
          ];
          setFileList(list);
        }
      } catch (e) {
        // 上传失败
      }
    };

    const handleChange = (info: UploadChangeParam<UploadFile>) => {
      if (info.file.status === 'uploading') {
        return;
      }
      if (info.file.status === 'error') {
        // message.error('上传失败');
      }
    };

    // 上传类型变化
    const handleTypeChange = (val) => {
      setType(val.target.value);
      setFileList([]);
    };

    // 提交上传
    const handleOk = async () => {
      if (!fileList?.length) return message.error('请先上传文件');
      setConfirmLoading(true);
      const args: RosterBatchImportAddParams = {
        file: fileList?.[0]?.file,
        projectGuid,
        fileName: fileList?.[0]?.name,
        uploadType: type,
      };
      const { success } = await rosterBatchImportAdd(args);
      if (success) {
        message.success('上传成功');
        onOk?.();
        fetchProjectDetail(projectDetail?.guid);
      }
      setConfirmLoading(false);
    };

    // 下载模版
    const handleDownload = async (fileType: number) => {
      const res = await rosterDownloadTemplate({
        projectGuid,
        uploadType: type,
        fileType,
      });
      if (res.success) {
        let elink = document.createElement('a');
        elink.style.display = 'none';
        let newUrl = httpReplace(res?.data?.ossUrl);
        elink.href = newUrl;
        // elink.download = '名单模版';
        document.body.appendChild(elink);
        elink.click();
        setTimeout(() => {
          document.body.removeChild(elink);
        }, 300);
      }
    };

    useEffect(() => {
      setFileList([]);
      setConfirmLoading(false);
      setType('0');
    }, [open]);
    return (
      <Modal
        open={open}
        title="上传名单"
        // forceRender={true}
        width={'540px'}
        onOk={handleOk}
        onCancel={onCancel}
        confirmLoading={confirmLoading}
        getContainer={false}
        destroyOnClose={true}
      >
        <Form {...layout}>
          <Form.Item label="上传类型">
            <Radio.Group
              value={type}
              options={nameUploadTypeOpts}
              optionType="button"
              onChange={handleTypeChange}
            />
          </Form.Item>
          <Form.Item
            label="文件"
            extra={
              <div>
                <div style={{ margin: '10px 5px 5px 0', fontSize: '14px' }}>
                  请上传CSV、XLS、XLSX文件
                </div>
                <Typography.Link
                  onClick={() => handleDownload(0)}
                  style={{ marginRight: '10px' }}
                >
                  下载CSV模版
                </Typography.Link>
                <Typography.Link
                  onClick={() => handleDownload(1)}
                  style={{ marginRight: '10px' }}
                >
                  下载XLS模版
                </Typography.Link>
                <Typography.Link onClick={() => handleDownload(2)}>
                  下载XLSX模版
                </Typography.Link>
                {/* <Button
                        style={{ marginLeft: '-15px' }}
                        type="link"
                        onClick={handleDownload}
                    >
                        下载CSV模版
                    </Button> */}
              </div>
            }
          >
            <Upload
              maxCount={1}
              accept=".csv, .xlsx, .xls"
              beforeUpload={beforeUpload}
              onChange={handleChange}
              customRequest={(info) => handleUpload(info)}
              fileList={fileList}
              showUploadList={true}
              onRemove={() => setFileList([])}
            >
              <Button icon={<CloudUploadOutlined />}>上传文件</Button>
            </Upload>
          </Form.Item>
        </Form>
      </Modal>
    );
  },
);
export default NameListUploadModal;
