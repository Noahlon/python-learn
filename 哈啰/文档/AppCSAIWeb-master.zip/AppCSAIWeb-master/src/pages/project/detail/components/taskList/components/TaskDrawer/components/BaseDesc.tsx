import { TaskDetailObj } from '@/api/project/task';
import { toThousands } from '@/utils';
import { Descriptions, Popover, Tag } from 'antd';
import React, { useEffect, useState } from 'react';
import { TaskStatus } from '../../../config';
import SmsPreView from '@/components/smsPreview';
import { SmsTemplateObj, querySmsTemplate } from '@/api/smsTemplate';
import { formatSeconds } from '@/utils/format';

interface Prop {
  currentTask: TaskDetailObj;
  taskType: number;
}

const BaseDesc: React.FC<Prop> = ({ currentTask, taskType }) => {
  //短信opts
  const [smsOpts, setSmsOpts] = useState<SmsTemplateObj[]>([]);

  // 获取短信opts
  const fetchSmsTemplate = async () => {
    const res = await querySmsTemplate({
      pageNum: 1,
      pageSize: 999,
      tenantList: [currentTask?.tenantCode],
    });
    if (res?.data) {
      setSmsOpts(res.data?.list);
    }
  };

  useEffect(() => {
    if (currentTask?.tenantCode) {
      fetchSmsTemplate();
    }
  }, [currentTask?.tenantCode]);

  return (
    <Descriptions column={2}>
      <Descriptions.Item label="任务类型">
        {currentTask?.taskTypeDesc}
      </Descriptions.Item>
      {[1, 3].includes(taskType) && (
        <Descriptions.Item label="千人千链">
          {currentTask?.multipleSmsLink ? '开启' : '关闭'}
        </Descriptions.Item>
      )}
      <Descriptions.Item label="任务状态">
        <Tag
          color={
            TaskStatus?.find((item) => item.value === currentTask?.status)
              ?.tagColor
          }
        >
          {currentTask?.statusDesc}
        </Tag>
      </Descriptions.Item>
      <Descriptions.Item label="外呼线路">
        {currentTask.tenantLineGroupName}
      </Descriptions.Item>
      {[1, 3].includes(taskType) && (
        <Descriptions.Item label="执行话术">
          {currentTask.faqName}
        </Descriptions.Item>
      )}
      <Descriptions.Item label="期望并发(运营设置/经理设置)">
        {toThousands(currentTask.expectLoadCount)}/
        {toThousands(currentTask.expectHumanLoadCount)}
      </Descriptions.Item>
      <Descriptions.Item label="拨打时段">
        {JSON.parse(currentTask.ext)?.callDuration?.map((item) => (
          <span key={item.startTime}>
            {item.startTime} - {item.endTime};
          </span>
        ))}
      </Descriptions.Item>
      <Descriptions.Item label="实际并发">
        {toThousands(currentTask.loadCount)}
      </Descriptions.Item>
      <Descriptions.Item label="自动补呼">
        <div>
          {JSON.parse(currentTask.ext)?.autoRetry?.first && (
            <div>
              第一次 间隔{JSON.parse(currentTask.ext)?.autoRetry?.first}min
            </div>
          )}
          {JSON.parse(currentTask.ext)?.autoRetry?.second && (
            <div>
              第二次 间隔:{JSON.parse(currentTask.ext)?.autoRetry?.second}min
            </div>
          )}
          {JSON.parse(currentTask.ext)?.autoRetry?.third && (
            <div>
              第三次 间隔:{JSON.parse(currentTask.ext)?.autoRetry?.third}min
            </div>
          )}
        </div>
      </Descriptions.Item>
      <Descriptions.Item label="外部黑名单">
        {currentTask?.thirdBlacklistIntercept ? '开启' : '关闭'}
      </Descriptions.Item>
      {[1, 3].includes(taskType) && (
        <Descriptions.Item label="挂机短信">
          {currentTask?.smsTemplateResponseList?.length > 0 ? (
            <div>
              {currentTask.smsTemplateResponseList.map((item, index) => (
                <div key={item.templateGuid + index}>
                  <Popover
                    content={
                      <SmsPreView
                        curSms={smsOpts?.find(
                          (it) => it?.id === item.templateGuid,
                        )}
                      />
                    }
                    placement="rightTop"
                    overlayClassName="smsConfigsPopover"
                  >
                    <a>{item.templateName}</a>
                  </Popover>
                </div>
              ))}
            </div>
          ) : (
            '-'
          )}
        </Descriptions.Item>
      )}
      {[2].includes(taskType) && (
        <Descriptions.Item label="名单数">
          {toThousands(currentTask?.telephoneCount)}
        </Descriptions.Item>
      )}
      <Descriptions.Item label="规则拦截">
        {currentTask?.featureIntercept ? '开启' : '关闭'}
      </Descriptions.Item>
      {[1, 3].includes(taskType) && (
        <Descriptions.Item label="名单数">
          {toThousands(currentTask?.telephoneCount)}
        </Descriptions.Item>
      )}
      {[2, 3].includes(taskType) && (
        <Descriptions.Item label="技能组">
          <Popover
            content={
              <div>
                {currentTask?.skillGroupList?.map((item) => (
                  <div key={item.skillGroupGuid}>{item.skillGroupName}</div>
                ))}
              </div>
            }
            placement="rightTop"
          >
            <a>{currentTask?.skillGroupList?.length}</a>
          </Popover>
        </Descriptions.Item>
      )}
      {[2, 3].includes(taskType) && (
        <Descriptions.Item label="自动提交时间">
          {formatSeconds(Number(currentTask.followupRecordAutoCommitTime))}
        </Descriptions.Item>
      )}
    </Descriptions>
  );
};

export default BaseDesc;
