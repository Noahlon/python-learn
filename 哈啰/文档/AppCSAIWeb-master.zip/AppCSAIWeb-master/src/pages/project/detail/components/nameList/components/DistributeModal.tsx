import React, { useState, useEffect, useRef, memo, useMemo } from 'react';
import {
  Modal,
  Form,
  Select,
  message,
  InputNumber,
  Tooltip,
  Collapse,
  Radio,
  Button,
  Row,
  Col,
  Popover,
  Checkbox,
  DatePicker,
  Cascader,
} from 'antd';
import moment from 'moment';
import { getIntentionListAll } from '@/api/language';
import { getTenantConcurrencytask } from '@/api/taskCenter';
import {
  getRosterTaskList,
  distributeRoster,
  RosterWanderRes,
  FilterCriteria,
  RosterDistributeParams,
} from '@/api/project/nameInfo';
import {
  TenantLinegroupRes,
  queryTenantLinegroupPage,
} from '@/api/tenantManage';
import { querySmsTemplate } from '@/api/smsTemplate';
import PhoneTime from '@/components/phoneTime';
import AutoRetryCall from '@/components/autoRetryCall';
import SkillGroupForm from '@/components/skillGroupForm';
import {
  CloseCircleOutlined,
  DownOutlined,
  InfoCircleOutlined,
  PlusOutlined,
  UpOutlined,
} from '@ant-design/icons';
import { taskTransferOpts } from '@/pages/taskCenter/config';
import SmsPreView from '@/components/smsPreview';
import AutoCommitTimeItem from '@/components/AutoCommitTimeItem';
import { toThousands } from '@/utils';
import { useModel } from '@umijs/max';
import { LAYOUTLABELFIVE } from '@/constants/processconfig';
import { getSpeechOpts } from '@/api/speech';
import { disabledTime } from '@/utils/date';
import styles from '../index.less';

const timeRangeDefault = {
  callDuration: [{ startTime: '09:00', endTime: '20:00' }],
  timeRange: ['09:00', '20:00'],
};

interface Prop {
  open: boolean;
  wanderInfo: RosterWanderRes['data'];
  queryParams: FilterCriteria;
  onCancel: () => void;
  onOk: () => void;
}

const DistributeModal: React.FC<Prop> = memo(
  ({ open, wanderInfo, queryParams, onCancel, onOk }) => {
    const { projectDetail, allSkillGroup } = useModel('project.model');
    // 当前的任务类型
    const [curTaskType, setCurTaskType] = useState<number>(undefined);
    const [curTaskInfo, setCurTaskInfo] = useState<any>();
    const [form] = Form.useForm();
    const [faqGuidList, setFaqGuidList] = useState([]);
    const [callLineList, setCallLineList] = useState([]);
    // 名单下发查询任务列表
    const [rosterTaskOpts, setRosterTaskOpts] = useState([]);
    // 意向列表
    const [intentionClassifysList, setIntentionClassifysList] = useState([]);
    // 短信列表
    const [smsList, setSmsList] = useState([]);

    const [concurrency, setConcurrencty] = useState<number>(null);
    const [activeKey2, setActiveKey2] = useState<string[]>(['2']);
    const [activeKey3, setActiveKey3] = useState<string[]>(['3']);
    const [editLoading, setEditLoading] = useState(false);
    const [smsPopoverOpen, setSmsPopoverOpen] = useState(false); // 短信气泡框显示
    const isHoverPopoverRef = useRef(false); // 是否hover在短信气泡框上
    const [multipleSmsLink, setMultipleSmsLink] = useState<number>(0); // 千人千链checkbox
    // 短信气泡框内容
    const [currentSmsPopover, setCurrentSmsPopover] = useState(undefined);

    // 预计可用30秒下发数
    const getConcurrencys = async (id: string) => {
      const { data } = await getTenantConcurrencytask({
        code: curTaskInfo?.tenantCode,
        tenantLineGroupId: id,
      });
      setConcurrencty(data || 0);
    };

    // 意向分类验证
    const handleValidatorClassification = async (rule, value, index) => {
      const _list = form.getFieldValue('smsConfigs');
      if (_list?.length) {
        const flatList = _list.map((it) => it?.classification).filter(Boolean);
        const val = flatList[index];
        const isRepeat = flatList.indexOf(val) !== flatList.lastIndexOf(val);
        if (isRepeat) return Promise.reject('意向分类不能重复');
      }
      if (!value) return Promise.reject('请选择意向分类');
      return Promise.resolve();
    };

    // 意向分类change
    const handleClassificationChange = () => {
      const _smsConfigs = form.getFieldValue('smsConfigs');
      const value = _smsConfigs?.map((_, index) => [
        'smsConfigs',
        index,
        'classification',
      ]);
      if (!!value?.length) form.validateFields(value);
    };

    // 验证技能组
    const handleValidatorSkillGroup = async (_, value) => {
      if (!value || value?.length === 0) {
        return Promise.reject(new Error('至少选择一个技能组'));
      }
      if (curTaskType === 0) {
        if (
          value?.some(
            (item) =>
              item?.rosterCount === undefined || item?.rosterCount === null,
          )
        ) {
          return Promise.reject(new Error('名单数不能为空'));
        }
      }
      return Promise.resolve();
    };

    // 验证自动补呼
    const handleValidatorRetry = async (rule, value) => {
      if (!value) return Promise.resolve();
      if (Array.isArray(value) && value.length) {
        for (let index = 0; index < value.length; index++) {
          if (value[index].checked) {
            if (
              !value[index].num ||
              Number(value[index].num) < 1 ||
              Number(value[index].num) > 600
            )
              return Promise.reject('时间间隔不能为空且在1-600分钟之间');
          }
        }
      } else {
        const nums = Object.values(value);
        for (let index = 0; index < nums.length; index++) {
          if (
            !nums[index] ||
            Number(nums[index]) < 1 ||
            Number(nums[index]) > 600
          )
            return Promise.reject('时间间隔不能为空且在1-600分钟之间');
        }
      }
      return Promise.resolve();
    };

    // reset表单
    const resetModal = () => {
      onCancel();
      form.resetFields();
      setCurTaskType(undefined);
      setConcurrencty(0);
      setEditLoading(false);
    };

    const updataForm = async (params: any) => {
      setEditLoading(true);

      const updateTaskInfo = params?.updateTaskInfo;
      const formTaskType = curTaskInfo?.taskType;

      // 设置任务入参updateTaskInfo
      updateTaskInfo.taskName = curTaskInfo?.taskName;
      updateTaskInfo.tenant = curTaskInfo?.tenantCode;
      updateTaskInfo.taskType = curTaskInfo?.taskType;
      updateTaskInfo.taskGuid = curTaskInfo?.taskGuid;

      // AI外呼，人机协作【1,3】
      if ([1, 3].includes(formTaskType)) {
        // 千人千链
        updateTaskInfo.multipleSmsLink = multipleSmsLink;
        // 话术
        const curFaq = faqGuidList?.find(
          (item) => item?.guid === updateTaskInfo.faqGuid,
        );
        updateTaskInfo.faqName = curFaq?.speechName;
        updateTaskInfo.faqGuid = curFaq?.guid;
      }

      // AI外呼，预测外呼，人机协作【1,2,3】
      if ([1, 2, 3].includes(formTaskType)) {
        const callTimeRange = updateTaskInfo?.exeCallTime?.timeRange;
        const callDuration = updateTaskInfo?.exeCallTime?.callDuration;
        let autoRetryJson = {} as any;
        if (Array.isArray(updateTaskInfo?.autoRetry)) {
          const autoRetry = updateTaskInfo?.autoRetry!.filter((e) => e.checked);
          autoRetry.forEach((e) => {
            if (e.value === 'first') {
              autoRetryJson['first'] = e.num;
            }
            if (e.value === 'second') {
              autoRetryJson['second'] = e.num;
            }
            if (e.value === 'third') {
              autoRetryJson['third'] = e.num;
            }
          });
        } else {
          autoRetryJson = updateTaskInfo?.autoRetry;
          if (autoRetryJson && Object.keys(autoRetryJson)?.length) {
          }
        }

        let smsConfigsList = [];
        if (updateTaskInfo?.smsConfigs?.length) {
          smsConfigsList = updateTaskInfo.smsConfigs.map((item) => ({
            classification: item.classification,
            smsTemplateId: item.smsTemplateId,
          }));
        }
        const json: any = { autoRetry: autoRetryJson, callDuration };
        if (smsConfigsList.length > 0) {
          json.smsConfigs = smsConfigsList;
        }
        let startTime = '';
        let endTime = '';
        if (callTimeRange?.length) {
          startTime = callTimeRange[0] || '';
          endTime = callTimeRange[1] || '';
        }

        delete updateTaskInfo.autoRetry;
        delete updateTaskInfo.smsConfigs;
        delete updateTaskInfo.exeCallTime;
        updateTaskInfo.exeStartTime = startTime;
        updateTaskInfo.exeEndTime = endTime;
        updateTaskInfo.ext = JSON.stringify(json);
      }

      // 手动下发，预测外呼，人机协作【0,2,3】
      if ([0, 2, 3].includes(curTaskType)) {
        let _ext = JSON.parse(updateTaskInfo.ext || '{}');
        _ext.followupRecordAutoCommitTime =
          updateTaskInfo.followupRecordAutoCommitTime;
        updateTaskInfo.ext = JSON.stringify(_ext);
        delete updateTaskInfo.followupRecordAutoCommitTime;
      }

      if (curTaskInfo?.templateGuid) {
        updateTaskInfo.templateGuid = curTaskInfo?.templateGuid;
        updateTaskInfo.templateName = curTaskInfo?.templateName;
      }

      const distributeRes = await distributeRoster({ ...params });

      if (distributeRes?.data) {
        message.success('操作成功');
        onOk();
        resetModal();
      }
      setEditLoading(false);
    };

    const handleOk = async () => {
      const res = await form.validateFields();

      // 删除多余的rosterTask
      delete res?.rosterTask;

      if (!projectDetail?.guid) {
        message.error('项目异常，请刷新重试');
        return;
      }

      if (!curTaskInfo?.taskGuid) {
        message.error('任务异常，请刷新重试');
        return;
      }

      const params: RosterDistributeParams = {
        ...queryParams,
        waitRosterWithOutTaskCount: wanderInfo?.waitRosterWithOutTaskCount,
        projectGuid: projectDetail.guid,
        updateTaskInfo: res,
      };

      const formTaskType = curTaskInfo?.taskType;
      // [手动下发]校验
      if ([0].includes(formTaskType)) {
        const totalRosterCount = res?.skillGroupList?.reduce((total, item) => {
          return total + (item?.rosterCount || 0);
        }, 0);
        if (totalRosterCount > wanderInfo?.waitRosterWithOutTaskCount) {
          return;
        }
      }

      // 手动下发，预测外呼，人机协作 [0, 2, 3]
      if ([0, 2, 3].includes(formTaskType) && res?.skillGroupList?.length > 0) {
        params.skillGroupList = res?.skillGroupList.map((item) => {
          const obj: any = {
            skillGroupGuid: item.skillGroupGuid,
            skillGroupName: item.skillGroupName,
          };
          // 手动下发有名单数
          if (formTaskType === 0) {
            obj.rosterCount = item.rosterCount;
          }
          return obj;
        });

        delete params?.updateTaskInfo?.skillGroupList;
      }

      // 校验短链 Ai外呼，人机协作 [1, 3]
      if ([1, 3].includes(formTaskType)) {
        let checkChain = false;
        if (form.getFieldValue('smsConfigs')) {
          const smsconfigs = form
            .getFieldValue('smsConfigs')
            ?.map((item) => item['smsTemplateId']);
          checkChain = smsList.some(
            (item) => smsconfigs.includes(item.id) && item.chainId,
          );
        }

        if (checkChain && multipleSmsLink) {
          Modal.confirm({
            title: '关联的短信模版中插入的链接为短链，建议使用原始链接',
            content: '还要继续提交吗？',
            okText: '继续',
            cancelText: '取消',
            onOk() {
              updataForm(params);
            },
          });
          return;
        }
      }

      updataForm(params);
    };
    // 获取外呼线路下拉列表
    const getCallLineList = () => {
      return new Promise<TenantLinegroupRes>((resolve, reject) => {
        queryTenantLinegroupPage({ tenantCode: projectDetail?.tenantCode })
          .then((res) => {
            if (res.success) {
              setCallLineList(res.data);
              resolve(res);
            }
          })
          .catch((err) => {
            reject(err);
          });
      });
    };
    // 获取短信
    const getAllSmsTemplateData = async () => {
      const res = await querySmsTemplate({
        pageNum: 1,
        pageSize: 999,
        tenantList: [projectDetail?.tenantCode],
      });
      if (res?.data) {
        setSmsList(res.data?.list);
      }
    };

    // 获取意向分类
    const getIntentionOpt = async () => {
      const res = await getIntentionListAll({
        pageSize: 200,
        pageNum: 1,
      });
      if (res) {
        setIntentionClassifysList(res);
      }
    };

    // 鼠标移到挂机短信的某一行
    const handleSmsMouseEnter = (e, index: number) => {
      // 如果气泡框挡住了元素，就不显示气泡框
      if (isHoverPopoverRef.current) {
        isHoverPopoverRef.current = false;
        return;
      }

      // 判断鼠标是否在下拉框上（是就隐藏短信气泡框）
      const target = e.target?.getBoundingClientRect();
      const currentTarget = e.currentTarget?.getBoundingClientRect();
      if (Math.abs(target?.top - currentTarget?.top) > currentTarget?.height) {
        setSmsPopoverOpen(false);
        return;
      }

      const curSmsConfig = form.getFieldValue('smsConfigs')[index];
      const { classification, smsTemplateId } = curSmsConfig || {};
      const curSmsTemplate =
        smsList.find((item) => item.id === smsTemplateId) || {};

      curSmsTemplate.classification = classification;

      setCurrentSmsPopover(curSmsTemplate);
      setSmsPopoverOpen(true);
    };

    const onChangeCheckbox = (e) => {
      setMultipleSmsLink(e.target.checked ? 1 : 0);
    };

    // fetch任务下发列表opts
    const fetchRosterTaskList = async () => {
      const params = { projectGuid: projectDetail?.guid };
      const res = await getRosterTaskList(params);
      if (res?.data) {
        const arr = res?.data?.map((item: any) => {
          item.label = item.taskTypeName;
          item.value = item.taskType;
          item.children = item.manualDeliveryTaskList;
          delete item.taskTypeName;
          delete item.taskType;
          delete item.manualDeliveryTaskList;
          item?.children?.forEach((it) => {
            it.label = it.taskName;
            it.value = it.taskGuid;
          });
          return item;
        });
        setRosterTaskOpts(arr);
      }
    };

    // fetch话术opts
    const fetchFaqOpts = async (transfer: boolean) => {
      const params = {
        tenantCode: projectDetail?.tenantCode,
        transfer,
      };
      const res = await getSpeechOpts(params);
      setFaqGuidList(res?.data || []);
    };

    // 加载所有的opts
    const fetchCurAllOpts = () => {
      if ([1, 3].includes(curTaskType)) {
        setFaqGuidList([]); // 先把话术列表置为空
        fetchFaqOpts(curTaskType === 1 ? false : true); // 话术
        getAllSmsTemplateData(); // 短信模版
        getIntentionOpt(); // 意向分类
      }
      if ([1, 2, 3].includes(curTaskType)) {
        getCallLineList(); // 外呼线路
      }
    };

    const setTaskForm = (data) => {
      // 先reset表单
      const allField = Object.keys(form.getFieldsValue())?.filter(
        (key) => key !== 'rosterTask',
      );
      form.resetFields(allField);

      let timeData = { ...timeRangeDefault };
      let ext: any = {};
      let _smsConfigs = [];
      try {
        ext = JSON.parse(data?.ext);
      } catch (error) {}
      if (ext) {
        if (ext?.callDuration) {
          const len = data?.exeStartTime?.length;
          const startTime = data?.exeStartTime?.slice(0, len - 3);
          const endTime = data?.exeEndTime?.slice(0, len - 3);
          timeData['callDuration'] = ext?.callDuration;
          timeData['timeRange'] = [startTime, endTime];
        }

        if (ext?.smsConfigs?.length) {
          _smsConfigs = ext.smsConfigs.map((item) => {
            return {
              classification: item.classification,
              smsTemplateId: item.smsTemplateId,
            };
          });
        }
      }

      if ([0, 1].includes(data?.multipleSmsLink)) {
        setMultipleSmsLink(data.multipleSmsLink);
      }

      if (data?.tenantLineGroupId) {
        getConcurrencys(data?.tenantLineGroupId);
      }

      // 拦截配置设置了就展开
      if (data.thirdBlacklistIntercept !== 0 || data.featureIntercept !== 0) {
        setActiveKey3(['3']);
      } else {
        setActiveKey3(undefined);
      }

      if ([1, 2, 3].includes(data?.taskType)) {
        data.exeCallTime = timeData;
        data.autoRetry = ext?.autoRetry || {};
        data.thirdBlacklistIntercept = data.thirdBlacklistIntercept ?? 0;
        data.featureIntercept = data.featureIntercept ?? 0;
      }

      // 手动下发，预测外呼，人机协作【0,2,3】
      if ([0, 2, 3].includes(data?.taskType)) {
        data.followupRecordAutoCommitTime = ext?.followupRecordAutoCommitTime;
      }

      if ([1, 3].includes(data?.taskType)) {
        data.smsConfigs = _smsConfigs;
      }

      form.setFieldsValue(data);
    };

    // 名单下发的任务change
    const handleChangeRosterTask = (e: [number, string]) => {
      if (!e || e?.length < 2) {
        return;
      }
      const taskType = e[0];
      setCurTaskType(taskType);
      let obj;
      rosterTaskOpts?.forEach((item) => {
        if (item.value === taskType) {
          item?.children?.forEach((it) => {
            if (it.value === e[1]) {
              obj = it;
            }
          });
        }
      });
      setCurTaskInfo(obj);
      setTaskForm(obj);
    };

    useEffect(() => {
      if (open) {
        fetchRosterTaskList();
      }
    }, [open]);

    useEffect(() => {
      fetchCurAllOpts();
    }, [curTaskType]);

    const labelView = () => {
      return (
        <Tooltip
          placement="topLeft"
          title="配置值为期望值，实际并发是根据租户线路情况进行锁定"
        >
          <InfoCircleOutlined style={{ marginRight: '10px' }} />
          <span>期望并发</span>
        </Tooltip>
      );
    };
    // render线路配置
    const LineFormItem = (
      <>
        <Form.Item
          label="外呼线路"
          name="tenantLineGroupId"
          rules={[{ required: true }]}
        >
          <Select
            showSearch
            placeholder="请选择外呼线路"
            onChange={getConcurrencys}
            getPopupContainer={(triggerNode) =>
              triggerNode.parentElement || document.body
            }
            optionFilterProp="tenantLineGroupName"
            fieldNames={{
              label: 'tenantLineGroupName',
              value: 'tenantLineGroupId',
            }}
            options={callLineList}
          />
        </Form.Item>
        <Form.Item noStyle>
          <Form.Item
            label={labelView()}
            name="expectLoadCount"
            style={{ margin: '0' }}
            rules={[{ required: true, message: '请输入' }]}
          >
            <InputNumber
              min={1}
              max={100000}
              style={{
                width: '100%',
              }}
            />
          </Form.Item>
          <div
            style={{
              margin: '5px 0 15px 140px',
              color: '#999',
              height: '22px',
            }}
          >
            {concurrency ? `预计可用并发${concurrency}` : '无可用并发'}
          </div>
        </Form.Item>
      </>
    );

    // render自动提交时间
    const AutoSubmitTimeItem = useMemo(() => <AutoCommitTimeItem />, []);

    // 任务状态为待执行、执行中 ，则不支持编辑任务配置
    const isDisabledForm = useMemo(() => {
      return ![0, 4].includes(curTaskInfo?.status);
    }, [curTaskInfo?.status]);

    return (
      <Modal
        title="下发名单"
        open={open}
        width={700}
        onOk={handleOk}
        onCancel={resetModal}
        forceRender
        getContainer={false}
        confirmLoading={editLoading}
      >
        <Form
          form={form}
          {...LAYOUTLABELFIVE}
          className={styles.distributeWrap}
          disabled={isDisabledForm}
        >
          <div className={styles.rosterCount}>
            <h3>已选择名单数：{toThousands(wanderInfo?.waitRosterCount)}</h3>
            <h3>
              可下发名单数：
              {toThousands(wanderInfo?.waitRosterWithOutTaskCount)}
            </h3>
          </div>
          <Form.Item
            label="名单下发的任务"
            name="rosterTask"
            rules={[{ required: true }]}
          >
            <Cascader
              disabled={false}
              showSearch
              placeholder="请选择名单下发的任务"
              options={rosterTaskOpts}
              onChange={handleChangeRosterTask}
            />
          </Form.Item>
          <Form.Item>
            <h3 className={styles.taskTitle}>任务配置</h3>
          </Form.Item>

          {[0].includes(curTaskType) && (
            <>
              <Form.Item
                label="执行时间"
                rules={[{ required: true }]}
                name="exeTime"
                getValueFromEvent={(...[, dateString]) => dateString}
                getValueProps={(value) => ({
                  value: value ? moment(value) : undefined,
                })}
              >
                <DatePicker
                  showTime
                  style={{ width: '100%' }}
                  disabledDate={(current) => {
                    return current && current < moment().subtract(1, 'days');
                  }}
                  disabledTime={disabledTime}
                />
              </Form.Item>

              <Form.Item
                label="技能组"
                required
                rules={[{ validator: handleValidatorSkillGroup }]}
                name="skillGroupList"
                style={{ marginBottom: 0 }}
              >
                <SkillGroupForm
                  showRoster={true}
                  defaultList={curTaskInfo?.skillGroupList}
                  skillGroupOpts={allSkillGroup}
                  waitRosterWithOutTaskCount={
                    wanderInfo?.waitRosterWithOutTaskCount
                  }
                />
              </Form.Item>
              {/* 自动提交时间 */}
              {AutoSubmitTimeItem}
            </>
          )}

          {[1, 3].includes(curTaskType) && (
            <Form.Item
              label="执行话术"
              name="faqGuid"
              rules={[{ required: true }]}
            >
              <Select
                showSearch
                placeholder="请选择执行话术"
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                fieldNames={{
                  label: 'speechName',
                  value: 'guid',
                }}
                options={faqGuidList}
              />
            </Form.Item>
          )}

          {[1, 2, 3].includes(curTaskType) && (
            <>
              <Form.Item
                label="拨打时段"
                name="exeCallTime"
                rules={[{ required: true }]}
                className={isDisabledForm ? styles.pointerNone : ''}
              >
                <PhoneTime />
              </Form.Item>

              {/* 自动提交时间 */}
              {curTaskType !== 1 && AutoSubmitTimeItem}

              <Form.Item
                label="自动补呼"
                name="autoRetry"
                style={{ marginBottom: '30px' }}
                rules={[{ validator: handleValidatorRetry }]}
              >
                <AutoRetryCall />
              </Form.Item>
            </>
          )}

          {[1, 3].includes(curTaskType) && (
            <Form.Item
              label="挂机短信"
              style={{ marginBottom: 0 }}
              className={isDisabledForm ? styles.pointerNone : ''}
            >
              <Form.List name="smsConfigs" initialValue={[]}>
                {(fields, { add, remove }) => (
                  <>
                    <Form.Item noStyle>
                      <Row justify="space-between">
                        <Col>
                          <Button
                            onClick={() =>
                              add({
                                classification: undefined,
                                smsTemplateId: undefined,
                              })
                            }
                            icon={<PlusOutlined />}
                            type="primary"
                            style={{ margin: '5px 0 20px 0' }}
                            size="small"
                          >
                            添加
                          </Button>
                        </Col>
                        <Row justify="end">
                          <Col>
                            <Checkbox
                              checked={!!multipleSmsLink}
                              onChange={onChangeCheckbox}
                            >
                              千人千链
                            </Checkbox>
                          </Col>
                          <Col
                            onMouseEnter={() => {
                              isHoverPopoverRef.current = true;
                            }}
                          >
                            <Popover
                              overlayClassName="smsConfigsPopover"
                              open={smsPopoverOpen}
                              content={
                                <SmsPreView curSms={currentSmsPopover} />
                              }
                              getPopupContainer={(triggerNode) =>
                                triggerNode.parentElement || document.body
                              }
                              placement="rightTop"
                            >
                              <div style={{ height: '22px' }} />
                            </Popover>
                          </Col>
                        </Row>
                      </Row>
                    </Form.Item>
                    {fields.map(({ key, name }) => (
                      <Row
                        key={key}
                        style={{
                          marginBottom: '24px',
                        }}
                      >
                        <Col
                          span={22}
                          onMouseEnter={(e) => handleSmsMouseEnter(e, name)}
                          onMouseLeave={() => setSmsPopoverOpen(false)}
                        >
                          <Row>
                            <Col span={10}>
                              <Form.Item
                                noStyle
                                shouldUpdate={(prevValues, curValues) => {
                                  return (
                                    prevValues.smsConfigs !==
                                    curValues.smsConfigs
                                  );
                                }}
                              >
                                {() => (
                                  <Form.Item
                                    label="意向分类"
                                    colon={false}
                                    style={{
                                      marginRight: '10px',
                                      marginBottom: 0,
                                    }}
                                    name={[name, 'classification']}
                                    rules={[
                                      {
                                        validator: (rule, value) =>
                                          handleValidatorClassification(
                                            rule,
                                            value,
                                            name,
                                          ),
                                      },
                                    ]}
                                  >
                                    <Select
                                      showSearch
                                      placeholder="请选择"
                                      getPopupContainer={(triggerNode) =>
                                        triggerNode.parentElement ||
                                        document.body
                                      }
                                      fieldNames={{
                                        label: 'classification',
                                        value: 'classification',
                                      }}
                                      options={intentionClassifysList}
                                      onChange={handleClassificationChange}
                                      onDropdownVisibleChange={() =>
                                        setSmsPopoverOpen(false)
                                      }
                                    />
                                  </Form.Item>
                                )}
                              </Form.Item>
                            </Col>
                            <Col span={14}>
                              <Form.Item
                                name={[name, 'smsTemplateId']}
                                rules={[
                                  {
                                    required: true,
                                    message: '请选择短信模版',
                                  },
                                ]}
                                style={{
                                  marginBottom: 0,
                                }}
                              >
                                <Select
                                  showSearch
                                  options={smsList}
                                  fieldNames={{
                                    label: 'templateName',
                                    value: 'id',
                                  }}
                                  optionFilterProp="templateName"
                                  getPopupContainer={(triggerNode) =>
                                    triggerNode.parentElement || document.body
                                  }
                                  placeholder={'请选择短信模版'}
                                  onDropdownVisibleChange={() =>
                                    setSmsPopoverOpen(false)
                                  }
                                />
                              </Form.Item>
                            </Col>
                          </Row>
                        </Col>
                        <Col
                          span={1}
                          style={{
                            margin: '4px 0 0 5px',
                            fontSize: '18px',
                            color: '#2d8cf0',
                            cursor: 'pointer',
                          }}
                          onClick={() => {
                            remove(name);
                            handleClassificationChange();
                          }}
                        >
                          <CloseCircleOutlined />
                        </Col>
                      </Row>
                    ))}
                  </>
                )}
              </Form.List>
            </Form.Item>
          )}

          {/* 线路配置 */}
          {[1].includes(curTaskType) && (
            <>
              <Collapse
                ghost
                activeKey={activeKey2}
                expandIconPosition="end"
                expandIcon={(panelProps) =>
                  panelProps?.isActive ? <DownOutlined /> : <UpOutlined />
                }
                onChange={(val: string[]) => setActiveKey2(val)}
              >
                <Collapse.Panel
                  header="线路配置"
                  key="2"
                  className="customCollapse"
                >
                  {LineFormItem}
                </Collapse.Panel>
              </Collapse>
            </>
          )}

          {[2, 3].includes(curTaskType) && (
            <>
              {/* 线路组 */}
              {LineFormItem}
              <Form.Item
                label="技能组"
                required
                name="skillGroupList"
                rules={[{ validator: handleValidatorSkillGroup }]}
                style={{ marginBottom: 0 }}
              >
                <SkillGroupForm
                  skillGroupOpts={allSkillGroup}
                  defaultList={curTaskInfo?.skillGroupList}
                />
              </Form.Item>
            </>
          )}

          {[1, 2, 3].includes(curTaskType) && (
            <>
              {/* 拦截配置 */}
              <Collapse
                ghost
                activeKey={activeKey3}
                expandIconPosition="end"
                expandIcon={(panelProps) =>
                  panelProps?.isActive ? <DownOutlined /> : <UpOutlined />
                }
                onChange={(val: string[]) => setActiveKey3(val)}
              >
                <Collapse.Panel
                  header="拦截配置"
                  key="3"
                  className="customCollapse"
                >
                  <Form.Item label="外部黑名单" name="thirdBlacklistIntercept">
                    <Radio.Group
                      options={taskTransferOpts}
                      optionType="button"
                    />
                  </Form.Item>
                  <Form.Item label="规则拦截" name="featureIntercept">
                    <Radio.Group
                      options={taskTransferOpts}
                      optionType="button"
                    />
                  </Form.Item>
                </Collapse.Panel>
              </Collapse>
            </>
          )}
        </Form>
      </Modal>
    );
  },
);

export default DistributeModal;
