import React, { useEffect } from 'react';
import { Tabs } from 'antd';
import ProjectInfo from './components/projectInfo';
import BatchList from './components/batchList';
import NameList from './components/nameList';
import TaskList from './components/taskList';
import { useLocation, useModel } from '@umijs/max';
import { parse } from 'query-string';
import styles from './index.less';
import { TypeTab } from './components/nameList/config';

const ProjectDetail: React.FC = () => {
  const location = useLocation();
  const query = parse(location.search) as { guid: string };

  const { fetchProjectDetail, setCurrentTab } = useModel('project.model');

  useEffect(() => {
    if (query.guid) {
      fetchProjectDetail(query.guid);
    }
    return () => {
      // 详情组件卸载时，tab重置为nameList
      setCurrentTab('nameList');
    };
  }, []);

  return (
    <div className={styles.projectDetail}>
      {/* 左侧info */}
      <ProjectInfo />
      {/* 右侧三个列表tab */}
      <div className={styles.rightContent}>
        <Tabs
          defaultActiveKey="nameList"
          onChange={(e: TypeTab) => setCurrentTab(e)}
          items={[
            {
              label: `名单列表`,
              key: 'nameList',
              children: <NameList />,
            },
            {
              label: `任务列表`,
              key: 'taskList',
              children: <TaskList />,
            },
            {
              label: `批次列表`,
              key: 'batchList',
              children: <BatchList />,
            },
          ]}
        />
      </div>
    </div>
  );
};

export default ProjectDetail;
