import {
  SeatStatisticsRes,
  TaskDetailObj,
  saveTaskMultiple,
  querySeatStatisticsInfo,
  queryAverageWaitSeconds,
  TaskSeatWaitRes,
  queryTaskSeatWaitInfo,
  saveAutoadvice,
} from '@/api/project/task';
import React, { useEffect, useRef, useState } from 'react';
import BaseRecord from './BaseRecord';
import {
  Button,
  Empty,
  Form,
  InputNumber,
  Modal,
  Pagination,
  Popover,
  Space,
  Spin,
  Switch,
  Tabs,
  message,
} from 'antd';
import { EditOutlined, EyeOutlined, MessageFilled } from '@ant-design/icons';
import { text1Tooltip } from '@/utils/format';
// import { debounce } from 'lodash';
import styles from '../index.less';

interface Prop {
  currentTask: TaskDetailObj;
  taskType: number;
  handleOk: () => void;
}

const BaseSeatRecord: React.FC<Prop> = ({
  currentTask,
  taskType,
  handleOk,
}) => {
  // 备注编辑
  const [multipleOpen, setMultipleOpen] = useState(false);
  const [form] = Form.useForm();

  const [accessKey, setAccessKey] = useState('1');
  const [seatListLoading, setSeatListLoading] = useState(false);
  // 座席统计数据
  const [seatStatisticsList, setSeatStatisticsList] = useState<
    SeatStatisticsRes['data']
  >([]);
  // 分页展示座席统计数据
  const [showSeatList, setShowSeatList] = useState<SeatStatisticsRes['data']>(
    [],
  );
  // 15分钟内平均等待时长
  const [averageWaitSeconds, setAverageWaitSeconds] = useState<string>();

  // 当前排队座席信息
  const [taskSeatWaitloading, setTaskSeatWaitloading] = useState(false);
  const [taskSeatWaitInfo, setTaskSeatWaitInfo] =
    useState<TaskSeatWaitRes['data']>();
  const [seatWaitOpen, setSeatWaitOpen] = useState(false);
  const seatWaitRef = useRef(null);
  const [autoadviceLoading, setAutoadviceLoading] = useState(false);

  // （先不做分页）
  // const handleSeatScroll = debounce((target: HTMLDivElement) => {
  //   const { scrollHeight, scrollTop, clientHeight } = target || {};
  //   if (scrollHeight - scrollTop - clientHeight < 1) {
  //     console.log('e');
  //   }
  // }, 500);

  // fetch任务下座席统计数据
  const fetchSeatStatisticsInfo = async () => {
    setSeatListLoading(true);
    const res = await querySeatStatisticsInfo({
      taskGuid: currentTask?.taskGuid,
    });
    setSeatStatisticsList(res?.data);
    setShowSeatList([...(res?.data || [])].slice(0, 20));
    setSeatListLoading(false);
  };

  // fetch任务下座席统计数据
  const fetchAverageWaitSeconds = async () => {
    const res = await queryAverageWaitSeconds({
      taskGuid: currentTask?.taskGuid,
    });
    setAverageWaitSeconds(res?.data);
  };

  // fetch当前排队座席信息
  const fetchTaskSeatWaitInfo = async () => {
    setTaskSeatWaitloading(true);
    const res = await queryTaskSeatWaitInfo({
      taskGuid: currentTask?.taskGuid,
    });
    setTaskSeatWaitInfo(res?.data);
    setTaskSeatWaitloading(false);
  };

  // fetch页面上显示数据的接口
  const fetchPageAllApi = () => {
    fetchSeatStatisticsInfo();
    fetchAverageWaitSeconds();
    fetchTaskSeatWaitInfo();
  };

  // tabs change
  const handleChangeAccessKey = (e: string) => {
    if (e === '2' && currentTask?.taskGuid) {
      fetchPageAllApi();
    }
    setAccessKey(e);
  };

  // 关闭编辑倍数modal
  const handleEditClose = () => {
    setMultipleOpen(false);
    form.resetFields();
  };

  // 停止轮询
  const stopSeatWaitLoop = () => {
    if (seatWaitRef.current) {
      clearInterval(seatWaitRef.current);
      seatWaitRef.current = null;
    }
  };

  // 轮询查座席等待信息
  const startSeatWaitLoop = () => {
    stopSeatWaitLoop();
    seatWaitRef.current = setInterval(() => {
      fetchPageAllApi(); // 座席情况接口轮询
    }, 2000);
  };

  // change排队信息open
  const handleChangeSeatOpen = (open: boolean) => {
    setSeatWaitOpen(open);
    if (open) {
      startSeatWaitLoop();
    } else {
      stopSeatWaitLoop();
    }
  };

  // 打开编辑并发倍数
  const handleMultipleOpen = () => {
    setMultipleOpen(true);
    // 打开编辑弹框需要刷新详情，因为弹框注解字段在详情中
    handleOk?.();
    form.setFieldsValue({
      multiple: Number(currentTask?.multiple) || undefined,
    });
  };

  // 提交倍数
  const handleOkMultiple = async () => {
    if (!currentTask?.taskGuid) {
      message.error('任务异常，请刷新重试');
    }
    const res = await form.validateFields();
    const params = {
      taskGuid: currentTask?.taskGuid,
      ...res,
    };
    const apiRes = await saveTaskMultiple(params);
    if (apiRes?.success) {
      handleOk?.();
      setMultipleOpen(false);
      message.success('调整完成');
    }
  };

  // 自动调整并发switch change
  const handleChangeAutoAdvice = async (isAuto: boolean) => {
    const params = {
      taskGuid: currentTask?.taskGuid,
      autoAdviceLoadCount: isAuto,
    };
    setAutoadviceLoading(true);
    const res = await saveAutoadvice(params);
    if (res?.success) {
      handleOk?.();
    }
    setAutoadviceLoading(false);
  };

  useEffect(() => {
    return stopSeatWaitLoop;
  }, []);

  return (
    <div className={styles.baseSeatRecord}>
      <div className={styles.seatConfig}>
        <div className={styles.seatConfigTop}>
          <Space>
            <div className={styles.numDesc}>
              ={' '}
              {currentTask?.autoAdviceLoadCount
                ? `1/转接率（${currentTask?.callCompletingRate || 0}%）`
                : currentTask?.multiple || 0}{' '}
              *空闲座席数（
              {currentTask?.waitSeatCount || 0}）
            </div>
            {!currentTask?.autoAdviceLoadCount && (
              <Button
                type="link"
                icon={<EditOutlined />}
                onClick={handleMultipleOpen}
              >
                编辑
              </Button>
            )}
          </Space>
          <div>
            <span>自动调整并发：</span>
            <Switch
              checked={currentTask?.autoAdviceLoadCount}
              loading={autoadviceLoading}
              onChange={handleChangeAutoAdvice}
            />
          </div>
        </div>
        <div>
          当前并发：
          <span className={styles.concurrentNum}>
            {currentTask?.actualLoadCount || 0}
          </span>
        </div>
      </div>
      <Tabs
        accessKey={accessKey}
        destroyInactiveTabPane
        onChange={handleChangeAccessKey}
        items={[
          {
            label: `统计数据`,
            key: '1',
            children: (
              <BaseRecord taskType={taskType} currentTask={currentTask} />
            ),
          },
          {
            label: `座席情况`,
            key: '2',
            children: (
              <>
                <Space size="middle">
                  <div>近15分钟平均等待时长：{averageWaitSeconds}</div>
                  <div>当前排队：{taskSeatWaitInfo?.length || 0}</div>
                  <Popover
                    open={seatWaitOpen}
                    onOpenChange={handleChangeSeatOpen}
                    placement="bottomLeft"
                    title="排队列表"
                    overlayClassName={styles.standWrap}
                    content={
                      <div
                        className={styles.standList}
                        // onScroll={(e: any) => handleSeatScroll(e.target)}
                      >
                        <Spin spinning={taskSeatWaitloading}>
                          {taskSeatWaitInfo?.length > 0 ? (
                            <>
                              {taskSeatWaitInfo.map((item) => (
                                <div
                                  className={styles.standItem}
                                  key={item.seatGuid}
                                >
                                  <div className={styles.standSeat}>
                                    <div>{item.seatName}</div>
                                    <div>{item.time}</div>
                                  </div>
                                  <div className={styles.skillGroup}>
                                    {item.skillGroupName}
                                  </div>
                                </div>
                              ))}
                            </>
                          ) : (
                            <Empty />
                          )}
                        </Spin>
                      </div>
                    }
                    trigger="click"
                  >
                    <Button type="link" icon={<EyeOutlined />}>
                      查看
                    </Button>
                  </Popover>
                </Space>
                <Spin spinning={seatListLoading}>
                  {seatStatisticsList?.length ? (
                    <div className={styles.cardWrap}>
                      {showSeatList?.map((item, index) => (
                        <div className={styles.card} key={String(index)}>
                          <div className={styles.topSkillBox}>
                            <MessageFilled className={styles.cardIcon} />
                            {text1Tooltip(item.skillGroupName)}
                          </div>
                          <Space size={12}>
                            <div className={styles.sign}>
                              <div className={styles.cardLabel}>当前签到</div>
                              <div className={styles.cardValue}>
                                {text1Tooltip(item.signInSeatCount)}
                              </div>
                            </div>
                            <div className={styles.distribute}>
                              <div className={styles.cardLabel}>已下发</div>
                              <div className={styles.cardValue}>
                                {text1Tooltip(item.issuedPersonListCount)}
                              </div>
                            </div>
                          </Space>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <Empty
                      style={{ marginTop: 30 }}
                      description="暂无座席统计数据"
                    />
                  )}
                </Spin>
                {seatStatisticsList?.length > 0 && (
                  <Pagination
                    className={styles.paginationBox}
                    size="small"
                    defaultCurrent={1}
                    pageSize={20}
                    total={seatStatisticsList.length}
                    onChange={(e) => {
                      setShowSeatList(
                        seatStatisticsList.slice((e - 1) * 20, e * 20),
                      );
                    }}
                    showTotal={(total) => `总共 ${total} 组`}
                  />
                )}
              </>
            ),
          },
        ]}
      />
      {/* 编辑并发倍数 */}
      <Modal
        title="编辑"
        open={multipleOpen}
        forceRender
        onCancel={handleEditClose}
        onOk={handleOkMultiple}
      >
        <Form form={form}>
          <Form.Item label="外呼并发">
            <Space align="center">
              <Form.Item
                name="multiple"
                rules={[{ required: true, message: '请输入' }]}
                noStyle
              >
                <InputNumber
                  min={1}
                  max={[2].includes(taskType) ? 300 : 800}
                  placeholder={`1-${[2].includes(taskType) ? '300' : '800'}`}
                />
              </Form.Item>

              <span>倍超并发外呼</span>
            </Space>
          </Form.Item>
          {currentTask?.callCompletingRate && (
            <div style={{ color: '#777' }}>
              注：当前外呼接通率{currentTask?.callCompletingRate}%，建议
              {currentTask?.adviceMultiple}倍超并发外呼
            </div>
          )}
        </Form>
      </Modal>
    </div>
  );
};

export default BaseSeatRecord;
