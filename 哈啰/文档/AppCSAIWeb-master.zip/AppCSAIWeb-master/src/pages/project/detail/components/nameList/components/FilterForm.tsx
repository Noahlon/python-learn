import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import {
  Button,
  Cascader,
  Checkbox,
  Col,
  Input,
  Row,
  Select,
  Space,
  DatePicker,
} from 'antd';
import {
  CaretDownOutlined,
  FilterOutlined,
  PlusOutlined,
} from '@ant-design/icons';
import {
  wanderStatusOpts,
  firstSearchTypes,
  FieldObj,
  allFixedFilterList,
  defaultAllDynamicFieldList,
} from '../config';
import PopoverSelect from '@/components/popoverSelect';
import { getFilterValueText } from '@/components/popoverSelect/util';
import { getProvinceCityList } from '@/api/common';
import PopoverInput from '@/components/popoverInput';
import PopoverInputNumber2 from '@/components/popoverInputNumber2';
import moment from 'moment';
import { formatType } from '@/config';
import { RosterListParams } from '@/api/project/nameInfo';
import { debounce } from 'lodash';
import { useModel } from '@umijs/max';
import styles from '../index.less';

interface Prop {
  onSearch: (res: RosterListParams) => void;
  setActiveOpen: (val: boolean) => void;
  setRecoveryOpen: (val: boolean) => void;
  setDistributeOpen: (val: boolean) => void;
}

const FilterForm: React.FC<Prop> = memo(
  ({ onSearch, setActiveOpen, setRecoveryOpen, setDistributeOpen }) => {
    const { rosterEunmList, allSkillGroup, currentTab, setRosterWanderStatus } =
      useModel('project.model');
    const filterRef = useRef(null);
    const [cityOpt, setCityOpt] = useState([]); // 城市opts
    // filter
    const [firstSearchType, setFirstSearchType] = useState('phoneNum');
    const [firstSearch, setFirstSearch] = useState<string>();
    const [allSearch, setAllSearch] = useState<RosterListParams | object>({
      wanderStatus: null,
    });

    const [fixFieldList, setFixFieldList] =
      useState<FieldObj[]>(allFixedFilterList);
    const [allDynamicFieldList, setAllDynamicFieldList] = useState<FieldObj[]>(
      defaultAllDynamicFieldList,
    );
    const [dynamicFieldList, setDynamicFieldList] = useState<FieldObj[]>([]);

    // 获取省市数据
    const getCityOpt = useCallback(async () => {
      const opt = [];
      // todo  异步获取省市数据
      const DISTRICTS: any = await getProvinceCityList();
      DISTRICTS.forEach((item) => {
        if (item['level'] === 1) {
          const citys = [];
          DISTRICTS.forEach((i) => {
            if (item.area_code === i.parent_code)
              citys.push({ value: i.area_name, label: i.area_name });
          });
          opt.push({
            value: item.area_code,
            label: item.area_name,
            children: citys,
          });
        }
      });
      setCityOpt(opt || []);
    }, []);

    // render表单的节点
    const renderFormItemNode = (item: FieldObj) => {
      const {
        fieldKey,
        startField,
        endField,
        fieldOptions,
        showSearch,
        fieldNames,
        fieldType,
      } = item || {};
      const searchKey = allSearch?.[fieldKey];
      const startSearchKey = allSearch?.[startField];
      const endSearchKey = allSearch?.[endField];

      switch (fieldType) {
        case 'select':
        case 'multipleSelect':
          return (
            <PopoverSelect
              options={fieldOptions}
              defaultValue={searchKey}
              onChange={(res) => {
                setAllSearch({
                  ...allSearch,
                  [fieldKey]: fieldType === 'select' ? res[0] : res,
                });
              }}
              isSingleSelect={fieldType === 'select'}
              showSearch={showSearch}
              fieldNames={fieldNames}
            >
              <div className={styles.customSelect}>
                <span
                  className={styles.customValue}
                  title={getFilterValueText(
                    searchKey,
                    fieldOptions,
                    fieldNames,
                  )}
                >
                  {getFilterValueText(searchKey, fieldOptions, fieldNames)}
                </span>
                <span className={styles.iconDown}>
                  <CaretDownOutlined />
                </span>
              </div>
            </PopoverSelect>
          );
        case 'selectTags':
          return (
            <Select
              className={styles.selectTags}
              placeholder="请输入"
              mode="tags"
              maxTagCount="responsive"
              onChange={(e) => {
                setAllSearch({
                  ...allSearch,
                  [fieldKey]: e,
                });
              }}
            />
          );
        case 'numberInterval':
          return (
            <PopoverInputNumber2
              startValue={startSearchKey}
              endValue={endSearchKey}
              onOk={(start, end) =>
                setAllSearch({
                  ...allSearch,
                  [startField]: start,
                  [endField]: end,
                })
              }
            >
              <div className={styles.customSelect}>
                <span className={styles.customValue}>
                  {startSearchKey ||
                  startSearchKey === 0 ||
                  endSearchKey ||
                  endSearchKey === 0 ? (
                    <>{`${startSearchKey ?? ''} ~ ${endSearchKey ?? ''}`}</>
                  ) : (
                    <span className={styles.grayColor}>请输入</span>
                  )}
                </span>
                <span className={styles.iconDown}>
                  <CaretDownOutlined />
                </span>
              </div>
            </PopoverInputNumber2>
          );
        case 'input':
          return (
            <PopoverInput
              value={searchKey}
              onOk={(value) =>
                setAllSearch({ ...allSearch, [fieldKey]: value })
              }
            >
              <div className={styles.customSelect}>
                <span className={styles.customValue} title={searchKey}>
                  {searchKey ? (
                    searchKey
                  ) : (
                    <span className={styles.grayColor}>请输入</span>
                  )}
                </span>
                <span className={styles.iconDown}>
                  <CaretDownOutlined />
                </span>
              </div>
            </PopoverInput>
          );
        case 'dateTimeRange':
          return (
            <DatePicker.RangePicker
              showTime
              bordered={false}
              onChange={(timeList) => {
                if (timeList?.length === 2) {
                  const startTime = moment(timeList[0]).format(formatType);
                  const endTime = moment(timeList[1]).format(formatType);
                  setAllSearch({
                    ...allSearch,
                    [startField]: startTime,
                    [endField]: endTime,
                  });
                } else {
                  setAllSearch({
                    ...allSearch,
                    [startField]: undefined,
                    [endField]: undefined,
                  });
                }
              }}
            />
          );
      }
    };

    // 删除后获取搜索params
    const setSearchParamsAfterDel = (
      fieldKey: string,
      startKey: string,
      endKey: string,
    ) => {
      const obj = { ...allSearch };
      if (startKey || endKey) {
        obj[startKey] = undefined;
        obj[endKey] = undefined;
      } else {
        if (fieldKey) {
          obj[fieldKey] = undefined;
        }
      }
      setAllSearch(obj);
    };

    // 清除所有后获取搜索params
    const setSearchParamsAfterClear = () => {
      const obj = { ...allSearch };
      dynamicFieldList?.forEach((item) => {
        if (item?.startField || item?.endField) {
          obj[item?.startField] = undefined;
          obj[item?.endField] = undefined;
        } else {
          if (item.fieldKey) {
            obj[item.fieldKey] = undefined;
          }
        }
      });
      setAllSearch(obj);
    };

    // 外部点击单个删除
    const handleDeleteField = (
      fieldKey: string,
      startKey: string,
      endKey: string,
    ) => {
      filterRef?.current?.handleSelect(fieldKey); // 外部删除筛选的key
      // 删除后的dynamicFieldList
      const _list = dynamicFieldList.filter(
        (item) => item.fieldKey !== fieldKey,
      );
      setDynamicFieldList(_list);
      // 更新search的params
      setSearchParamsAfterDel(fieldKey, startKey, endKey);
    };

    // 动态表单filter change
    const handleFilterChange = (arr: string[]) => {
      // 清除动态表单
      if (arr?.length === 0 || !arr) {
        setSearchParamsAfterClear();
      }
      // 删除单个
      else {
        dynamicFieldList?.forEach((item) => {
          const isDelete = !arr.some((key) => item.fieldKey === key);
          if (isDelete) {
            setSearchParamsAfterDel(
              item.fieldKey,
              item.startField,
              item.endField,
            );
          }
        });
      }

      // 添加动态表单
      const _list = [];
      arr?.forEach((key) => {
        const cur = allDynamicFieldList?.find((item) => item.fieldKey === key);
        if (cur) {
          _list.push(cur);
        }
      });
      setDynamicFieldList(_list);
    };

    // 手机号/md5/newGuid/guid change
    const handleChangeFirstInputDebounce = useCallback(
      debounce((value: string) => {
        setAllSearch({
          ...allSearch,
          phoneNum: undefined,
          phoneNumMd5: undefined,
          uploadNewid: undefined,
          uploadGuid: undefined,
          [firstSearchType]: value,
        });
      }, 300),
      [allSearch, firstSearchType],
    );

    const handleChangeFirstInput = (e: { target: { value: string } }) => {
      setFirstSearch(e.target.value);
      handleChangeFirstInputDebounce(e.target.value);
    };

    const handleChangeFirstType = (e: string) => {
      setFirstSearch(undefined);
      handleChangeFirstInputDebounce(undefined);
      setFirstSearchType(e);
    };

    // 可操作名单change
    const handleChangeOperation = (e: { target: { checked: boolean } }) => {
      setAllSearch({ ...allSearch, operationRosterBox: e.target.checked });
    };

    // 省市change
    const handleChangeCitys = (e: string[][]) => {
      const _citys = [];
      if (e?.length > 0) {
        e?.forEach((item) => {
          if (item?.length === 2) {
            _citys.push(item[1]);
          }
        });
      }
      setAllSearch({ ...allSearch, citys: _citys });
    };

    // 重置
    const handleResetSearch = () => {
      filterRef?.current?.clearAll();
      setAllSearch({ wanderStatus: null });
      setFirstSearchType('phoneNum');
      setFirstSearch(undefined);
    };

    // 延时500ms搜索
    const debounceUpdateApi = useCallback(
      debounce((res) => {
        // 更新搜索
        onSearch(res as RosterListParams);
      }, 500),
      [],
    );

    useEffect(() => {
      getCityOpt();
    }, []);

    useEffect(() => {
      // 从human.common.enum.list接口加载筛选数据
      if (rosterEunmList?.length > 0) {
        rosterEunmList.forEach((item) => {
          // 固定的表单
          const _fixList = allFixedFilterList?.map((it) => {
            // 跟进状态
            if (
              item.enumStr === 'RosterFollowStatusEnum' &&
              it.fieldKey === 'followStatuList'
            ) {
              it.fieldOptions = item.valueLableDTOList;
            }
            return it;
          });
          setFixFieldList(_fixList);

          // 动态的表单
          const _dynamicList = allDynamicFieldList?.map((it) => {
            // 任务类型
            if (item.enumStr === 'TaskTypeEnum' && it.fieldKey === 'taskType') {
              it.fieldOptions = item.valueLableDTOList;
            }
            // 任务状态
            if (
              item.enumStr === 'TaskStatusEnum' &&
              it.fieldKey === 'taskStatuList'
            ) {
              it.fieldOptions = item.valueLableDTOList;
            }
            // 执行结果
            if (
              item.enumStr === 'RosterExecuteStatusEnum' &&
              it.fieldKey === 'executeStatuList'
            ) {
              it.fieldOptions = item.valueLableDTOList;
            }
            // AI意向分类
            if (
              item.enumStr === 'IntentClassifyEnum' &&
              it.fieldKey === 'intentClassifyList'
            ) {
              it.fieldOptions = item.valueLableDTOList;
            }
            // 最近一次外呼结果
            if (
              item.enumStr === 'CallDetailResEnum' &&
              it.fieldKey === 'calloutResultList'
            ) {
              it.fieldOptions = item.valueLableDTOList;
            }
            return it;
          });
          setAllDynamicFieldList(_dynamicList);
        });
      }
    }, [rosterEunmList]);

    useEffect(() => {
      // 加载技能组筛选数据
      if (allSkillGroup?.length > 0) {
        const _dynamicList = allDynamicFieldList?.map((it) => {
          if (it.fieldKey === 'skillGroupGuid') {
            it.fieldOptions = allSkillGroup;
          }
          return it;
        });
        setAllDynamicFieldList(_dynamicList);
      }
    }, [allSkillGroup]);

    useEffect(() => {
      // tab切换为名单 || 搜索条件change时查询
      if (currentTab === 'nameList') {
        debounceUpdateApi(allSearch);
      }
    }, [allSearch, currentTab]);

    return (
      <div className={styles.filterWrap}>
        <Row justify="space-between" align="middle">
          <Col>
            <Space size="middle" className={styles.wanderWrap}>
              {/* 流转状态select */}
              <PopoverSelect
                options={wanderStatusOpts}
                isSingleSelect
                showClear={false}
                onChange={(res) => {
                  setRosterWanderStatus(res[0]);
                  setAllSearch({ ...allSearch, wanderStatus: res[0] });
                }}
                defaultValue={allSearch?.['wanderStatus']}
              >
                <a onClick={(e) => e.preventDefault()}>
                  <Space size={4}>
                    <FilterOutlined />
                    <div className={styles.circulationText}>
                      {getFilterValueText(
                        allSearch?.['wanderStatus'],
                        wanderStatusOpts,
                      )}
                    </div>
                    <CaretDownOutlined />
                  </Space>
                </a>
              </PopoverSelect>
              <Button onClick={handleResetSearch}>重置</Button>
              {[0].includes(allSearch?.['wanderStatus']) && (
                <Button type="primary" onClick={() => setDistributeOpen(true)}>
                  下发名单
                </Button>
              )}

              {[0, 1, 2].includes(allSearch?.['wanderStatus']) && (
                <Button type="primary" onClick={() => setRecoveryOpen(true)}>
                  回收名单
                </Button>
              )}

              {[3].includes(allSearch?.['wanderStatus']) && (
                <Button type="primary" onClick={() => setActiveOpen(true)}>
                  激活名单
                </Button>
              )}

              {[0].includes(allSearch?.['wanderStatus']) && (
                <Checkbox onChange={handleChangeOperation}>可操作名单</Checkbox>
              )}
            </Space>
          </Col>
          <Col>
            {/* 动态表单select */}
            <PopoverSelect
              ref={filterRef}
              showSearch
              fieldNames={{
                label: 'fieldName',
                value: 'fieldKey',
                desc: 'fieldTypeDesc',
              }}
              options={allDynamicFieldList}
              onChange={(arr) => handleFilterChange(arr)}
            >
              <a onClick={(e) => e.preventDefault()}>
                <Space size={4}>
                  <PlusOutlined />
                  筛选
                  <CaretDownOutlined />
                </Space>
              </a>
            </PopoverSelect>
          </Col>
        </Row>
        <div
          className={styles.filterFormWrap}
          onClick={(e) => e.preventDefault()}
        >
          {/* 手机号/md5/newGuid/guid 筛选 */}
          <div className={styles.filterPhoneBox}>
            <Input.Search
              allowClear
              value={firstSearch}
              onChange={handleChangeFirstInput}
              onSearch={() => debounceUpdateApi(allSearch)}
              addonBefore={
                <Select
                  style={{ width: 95 }}
                  options={firstSearchTypes}
                  value={firstSearchType}
                  onChange={handleChangeFirstType}
                />
              }
            />
          </div>
          {/* 固定 筛选项 */}
          {fixFieldList.map((item: FieldObj) => (
            <div className={styles.filterChild} key={item.fieldKey}>
              <label className={styles.filterLabel}>{item.fieldName}</label>
              {renderFormItemNode(item)}
            </div>
          ))}
          {/* 动态 筛选项 */}
          {dynamicFieldList.map((item: FieldObj) => (
            <div className={styles.filterChild} key={item.fieldKey}>
              <label className={styles.filterLabel}>{item.fieldName}</label>
              {item.fieldKey === 'citys' ? (
                <Cascader
                  options={cityOpt}
                  placeholder="请选择省市"
                  bordered={false}
                  multiple
                  maxTagCount="responsive"
                  showCheckedStrategy={Cascader.SHOW_CHILD}
                  onChange={handleChangeCitys}
                />
              ) : (
                renderFormItemNode(item)
              )}
              {/* 删除按钮 */}
              <span
                className={styles.deleteIcon}
                onClick={() =>
                  handleDeleteField(
                    item.fieldKey,
                    item.startField,
                    item.endField,
                  )
                }
              />
            </div>
          ))}
        </div>
      </div>
    );
  },
);

export default FilterForm;
