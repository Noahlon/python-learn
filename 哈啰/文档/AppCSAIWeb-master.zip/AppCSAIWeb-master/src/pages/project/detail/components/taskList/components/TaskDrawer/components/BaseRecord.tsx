import {
  TaskDetailObj,
  taskCallRound,
  taskCallStatus,
  taskFunnel,
  taskIntent,
  taskPersonList,
  taskStatisticAll,
  taskTag,
  taskThroughRateRound,
  taskThroughRound,
} from '@/api/project/task';
import ConnectCard from '@/components/ConnectCard';
import { Divider, Empty, Radio, Space, Spin } from 'antd';
import React, { useEffect, useState } from 'react';
import styles from '../index.less';
import RingChart from '@/components/RingChart';
import FunnelChart from '@/components/FunnelChart';
import BarChart from '@/components/BarChart';
import { accDiv } from '@/utils';

interface Prop {
  currentTask: TaskDetailObj;
  taskType: number;
}

const chartList1 = [
  { label: '名单状态', value: 'roster' },
  { label: '转化漏斗', value: 'funnel' },
  { label: '意向分类', value: 'intention' },
  { label: '命中标签', value: 'tag' },
  { label: '呼叫状态', value: 'callStatus' },
];

const chartList2 = [
  { label: '名单状态', value: 'roster' },
  { label: '外呼', value: 'call' },
  { label: '接通', value: 'connect' },
  { label: '接通率', value: 'connectRate' },
  { label: '呼叫状态', value: 'callStatus' },
];

const BaseRecord: React.FC<Prop> = ({ currentTask, taskType }) => {
  const [chartOpts, setChartOpts] = useState([]);
  const [chartType, setChartType] = useState('roster');
  const [chartLoading, setChartLoading] = useState(false);

  // 任务整体执行情况
  const [overall, setOverall] = useState(undefined);

  // 名单统计信息
  const [personList, setPersonList] = useState([]);
  // 转化漏斗
  const [funnel, setFunnel] = useState([]);
  // 意向分类
  const [intentionCat, setIntentionCat] = useState([]);
  // 命中标签
  const [tags, setTags] = useState([]);
  // 呼叫状态
  const [callResult, setCallResult] = useState([]);
  // 呼叫轮次统计
  const [callRound, setCallRound] = useState([]);
  // 接通轮次统计
  const [throughRound, setThroughRound] = useState([]);
  // 接通率轮次统计
  const [throughRateRound, setThroughRateRound] = useState([]);

  // total
  const [total, setTotal] = useState<number>();

  // 获取card数据
  const getOveralls = async () => {
    const res = await taskStatisticAll({ taskGuid: currentTask?.taskGuid });
    if (res?.success) {
      setOverall(res?.data || {});
    }
  };

  const formatData = (data, type = 0) => {
    const mapArr = [
      ['key', 'totalKey', 'percentageKey'],
      ['typeDesc', 'count', 'percentageKey'],
      ['callTimes', 'totalKey', 'percentageKey'],
    ];

    const arr = JSON.parse(
      JSON.stringify(data)
        .replaceAll(mapArr[type][0], 'item')
        .replaceAll(mapArr[type][1], 'count')
        .replaceAll(mapArr[type][2], 'percent'),
    );
    arr.forEach((it) => (it.percent = accDiv(+it.percent, 100)));
    return arr;
  };

  // 名单状态统计
  const getTaskPersonList = async () => {
    setChartLoading(true);
    const res = await taskPersonList({ taskGuid: currentTask?.taskGuid });
    if (res?.data) {
      setPersonList(formatData(res?.data?.details || [], 1));
      setTotal(res?.data?.totalCount);
    }
    setChartLoading(false);
  };

  // 转化漏斗明细情况
  const getProcessFunnelInfo = async () => {
    setChartLoading(true);
    const res = await taskFunnel({ taskGuid: currentTask?.taskGuid });
    if (res?.data) {
      const {
        total,
        totalPut,
        totalCall,
        percentageCall,
        percentageDialoguePut,
        totalSms,
        successSms,
        percentageSms,
        percentageSmsSuccess,
      } = res.data || {};
      const funnelArr = [];
      if (total || totalCall || totalPut || totalSms || successSms) {
        funnelArr.push({ name: '名单总数', value: total });
      }
      if (totalCall || totalPut || totalSms || successSms) {
        funnelArr.push({
          name: '已呼名单',
          value: totalCall,
          rateText: `触达率 ${percentageCall}`,
          rateTextTip: '(已呼名单/名单总数)',
        });
      }
      if (totalPut || totalSms || successSms) {
        funnelArr.push({
          name: '接通名单',
          value: totalPut,
          rateText: `接通率 ${percentageDialoguePut}`,
          rateTextTip: '(接通名单/已呼名单)',
        });
      }
      if (totalSms || successSms) {
        funnelArr.push({
          name: '触发短信',
          value: totalSms,
          rateText: `短信触发率 ${percentageSms}`,
          rateTextTip: '(触发短信名单数/接通名单数)',
        });
      }
      if (successSms) {
        funnelArr.push({
          name: '短信成功',
          value: successSms,
          rateText: `短信成功率 ${percentageSmsSuccess}`,
          rateTextTip: '(短信成功名单数/触发名单数)',
        });
      }
      setFunnel(funnelArr);
    }
    setChartLoading(false);
  };

  // 意向分类
  const getProcessIntentions = async () => {
    setChartLoading(true);
    const res = await taskIntent({ taskGuid: currentTask?.taskGuid });

    if (res?.data) {
      setIntentionCat(formatData(res?.data?.details || []));
      setTotal(res?.data?.total);
    }
    setChartLoading(false);
  };

  // 命中标签
  const getProcessWithTags = async () => {
    setChartLoading(true);
    const res = await taskTag({ taskGuid: currentTask?.taskGuid });

    if (res?.data) {
      setTags(formatData(res?.data?.details || []));
      setTotal(res?.data?.total);
    }
    setChartLoading(false);
  };

  // 呼叫状态
  const getProcessWithResults = async () => {
    setChartLoading(true);
    const res = await taskCallStatus({ taskGuid: currentTask?.taskGuid });
    if (res?.data) {
      setCallResult(formatData(res?.data?.details || []));
      setTotal(res?.data?.total);
    }
    setChartLoading(false);
  };

  // 呼叫轮次统计
  const getTaskCallRound = async () => {
    setChartLoading(true);
    const res = await taskCallRound({ taskGuid: currentTask?.taskGuid });
    if (res?.data) {
      setCallRound(formatData(res?.data?.details || [], 2));
      setTotal(res?.data?.total);
    }
    setChartLoading(false);
  };

  // 接通轮次统计
  const getTaskThroughRound = async () => {
    setChartLoading(true);
    const res = await taskThroughRound({ taskGuid: currentTask?.taskGuid });
    if (res?.data) {
      setThroughRound(formatData(res?.data?.details || [], 2));
      setTotal(res?.data?.total);
    }
    setChartLoading(false);
  };

  // 接通率轮次统计
  const getTaskThroughRateRound = async () => {
    setChartLoading(true);
    const res = await taskThroughRateRound({ taskGuid: currentTask?.taskGuid });
    if (res?.data) {
      setThroughRateRound(formatData(res?.data?.details || [], 2));
      setTotal(res?.data?.total);
    }
    setChartLoading(false);
  };

  useEffect(() => {
    if ([2, 3].includes(taskType)) {
      setChartOpts(chartList2);
    } else {
      setChartOpts(chartList1);
    }
  }, [taskType]);

  useEffect(() => {
    if (currentTask?.taskGuid) {
      switch (chartType) {
        case 'roster':
          getTaskPersonList();
          break;
        case 'funnel':
          getProcessFunnelInfo();
          break;
        case 'intention':
          getProcessIntentions();
          break;
        case 'tag':
          getProcessWithTags();
          break;
        case 'callStatus':
          getProcessWithResults();
          break;
        case 'call':
          getTaskCallRound();
          break;
        case 'connect':
          getTaskThroughRound();
          break;
        case 'connectRate':
          getTaskThroughRateRound();
          break;
        default:
          break;
      }
    }
  }, [chartType, currentTask?.taskGuid]);

  useEffect(() => {
    if (currentTask?.taskGuid) {
      getOveralls();
    }
  }, [currentTask?.taskGuid]);

  const EmptyDom = (
    <Empty
      image={Empty.PRESENTED_IMAGE_SIMPLE}
      imageStyle={{ marginTop: '150px' }}
    />
  );

  return (
    <div className={styles.baseRecord}>
      {/* card数据 */}
      <div className={styles.cardRow}>
        <Space size={30}>
          <ConnectCard
            title="名单完成率"
            percentage={overall?.percentageComplete}
            txt1="待呼数"
            num1={overall?.totalWaiting}
            txt2="总名单数"
            num2={overall?.total}
            tooltip="名单完成率=（总名单数-待呼数）/总名单数"
          />
          <ConnectCard
            title="名单接通率"
            percentage={overall?.percentagePut}
            txt1="接通名单数"
            num1={overall?.totalPut}
            txt2="外呼名单数"
            num2={overall?.totalCall}
            tooltip="名单接通率=接通名单数/外呼名单数"
          />
          <ConnectCard
            title="外呼接通率"
            percentage={overall?.percentageDialoguePut}
            txt1="接通数"
            num1={overall?.totalDialoguePut}
            txt2="外呼数"
            num2={overall?.totalDialogue}
            tooltip="外呼接通率=接通数/外呼数"
          />
        </Space>
      </div>
      {[3].includes(taskType) && (
        <div className={styles.cardRow}>
          <Space size={30}>
            <ConnectCard
              title="外呼转接率"
              percentage={overall?.percentageCallTransfer}
              txt1="触发转接数"
              num1={overall?.totalTransfer}
              txt2="外呼数"
              num2={overall?.totalDialogue}
              tooltip="外呼转接率= 触发转接数/外呼数"
            />
            <ConnectCard
              title="接通转接率"
              percentage={overall?.percentageThrough}
              txt1="触发转接数"
              num1={overall?.totalTransfer}
              txt2="接通数"
              num2={overall?.totalDialoguePut}
              tooltip="接通转接率= 触发转接数/接通数"
            />
            <ConnectCard
              title="名单转接率"
              percentage={overall?.percentagePersonTransfer}
              txt1="触发转接名单数"
              num1={overall?.totalTransfer}
              txt2="外呼名单数"
              num2={overall?.totalCall}
              tooltip="名单转接率= 触发转接名单数/外呼名单数"
            />
          </Space>
        </div>
      )}
      <Divider />
      {/* 统计数据 */}
      <Radio.Group
        value={chartType}
        onChange={(e) => setChartType(e.target.value)}
      >
        {chartOpts?.map((item) => (
          <Radio.Button value={item.value} key={item.value}>
            {item.label}
          </Radio.Button>
        ))}
      </Radio.Group>
      <Spin spinning={chartLoading} wrapperClassName={styles.chartBox}>
        {(() => {
          switch (chartType) {
            case 'roster':
              return personList.length ? (
                <RingChart
                  data={personList}
                  total={total}
                  height={380}
                  title="总名单数"
                  container="roster"
                />
              ) : (
                EmptyDom
              );
            case 'call':
              return callRound.length ? (
                <RingChart
                  data={callRound}
                  total={total}
                  height={380}
                  title="任务外呼"
                  container="call"
                />
              ) : (
                EmptyDom
              );
            case 'connect':
              return throughRound.length ? (
                <RingChart
                  data={throughRound}
                  total={total}
                  height={380}
                  title="任务接通"
                  container="connect"
                />
              ) : (
                EmptyDom
              );
            case 'connectRate':
              return throughRateRound.length ? (
                <RingChart
                  data={throughRateRound}
                  total={total}
                  height={380}
                  title="任务接通"
                  container="connectRate"
                />
              ) : (
                EmptyDom
              );
            case 'funnel':
              return funnel.length ? (
                <FunnelChart
                  data={funnel}
                  height={380}
                  container="zhld"
                  otherProps={{ legend: false }}
                />
              ) : (
                EmptyDom
              );
            case 'intention':
              return intentionCat.length ? (
                <RingChart
                  data={intentionCat}
                  total={total}
                  height={380}
                  title="接通数"
                  container="intention"
                />
              ) : (
                EmptyDom
              );
            case 'tag':
              return tags.length ? <BarChart data={tags} /> : EmptyDom;
            case 'callStatus':
              return callResult.length ? (
                <RingChart
                  data={callResult}
                  total={total}
                  height={380}
                  title="外呼数"
                  container="callStatus"
                />
              ) : (
                EmptyDom
              );
            default:
              return <></>;
          }
        })()}
      </Spin>
    </div>
  );
};

export default BaseRecord;
