import React from 'react';
import { Form, Input, Select, Button, Row, Col, Space } from 'antd';
import { TaskType, TaskStatus } from '../config';
import { HaTaskPageParams } from '@/api/project/task';

interface IProps {
  onSearch: (data: HaTaskPageParams) => void;
  onReset: () => void;
}

const colLayout = { xl: 6, sm: 12, xs: 24 };

const SearchTask: React.FC<IProps> = ({ onSearch, onReset }) => {
  const [form] = Form.useForm();

  // 重置
  const handleReset = () => {
    form.resetFields();
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    onSearch?.(res);
  };

  return (
    <Form form={form}>
      <Row wrap={false}>
        <Col flex="auto">
          <Row gutter={16}>
            <Col {...colLayout}>
              <Form.Item name="taskName">
                <Input allowClear placeholder="任务名称" width={'254px'} />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="taskType">
                <Select
                  showSearch
                  optionFilterProp="label"
                  placeholder="任务类型"
                  allowClear
                  options={TaskType}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="status">
                <Select
                  showSearch
                  optionFilterProp="label"
                  placeholder="任务状态"
                  allowClear
                  options={TaskStatus}
                />
              </Form.Item>
            </Col>
            <Col flex="1" style={{ marginLeft: '15px' }}>
              <Space>
                <Button onClick={handleReset}>重置</Button>
                <Button type="primary" htmlType="submit" onClick={handleSearch}>
                  搜索
                </Button>
              </Space>
            </Col>
          </Row>
        </Col>
      </Row>
    </Form>
  );
};
export default SearchTask;
