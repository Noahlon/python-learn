import React, { useEffect, useState, useRef } from 'react';
import { Button } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { PlusOutlined } from '@ant-design/icons';
import ResizeTable from '@/components/ResizeTable';
import SearchTask from './components/SearchTask';
import { useLocation, useModel } from '@umijs/max';
import { taskColumns, DEFAULT_QUERY_PARAMS } from './config';
import { parse } from 'query-string';
import {
  haTaskPage,
  TaskPageTable,
  HaTaskPageParams,
} from '@/api/project/task';
import TaskCreateEdit from './components/TaskCreateEdit';
import TaskDrawer from './components/TaskDrawer';
import styles from './index.less';

const TaskList: React.FC = () => {
  const { currentTab, projectDetail } = useModel('project.model');
  const [tableData, setTableData] = useState([]);
  const [tableLoading, setTableLoading] = useState(false);
  const location = useLocation();
  const query = parse(location.search) as { guid: string };
  // pagination
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [tableTotal, setTableTotal] = useState<number>();
  // 搜索params
  const queryParams = useRef(DEFAULT_QUERY_PARAMS);
  // 当前编辑的任务Guid
  const [currentTaskGuid, setCurrentTaskGuid] = useState<string>();

  const [modalType, setModalType] = useState<number>(undefined);

  // 任务模版列表
  const fetchTaskList = async () => {
    const params = {
      ...queryParams.current,
      projectGuid: query?.guid,
    };
    setTableLoading(true);
    const res = await haTaskPage(params);
    if (res?.data) {
      setTableData(res.data?.list);
      setTableTotal(res?.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // 页面页数change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    queryParams.current.pageNum = pageNum;
    if (pageSize || pageSize === 0) {
      queryParams.current.pageSize = pageSize;
    }
    setPagination({ pageNum, pageSize });
    fetchTaskList();
  };

  // 任务详情columns
  const columns: ColumnsType<TaskPageTable> = [
    ...taskColumns,
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 100,
      render: (_, record: TaskPageTable) => (
        <a
          onClick={() => {
            setCurrentTaskGuid(record.taskGuid);
          }}
        >
          详情
        </a>
      ),
    },
  ];

  // 搜索
  const handleSearch = (res: HaTaskPageParams) => {
    queryParams.current = { ...queryParams.current, ...res };
    handlePageChange(1);
  };

  // 重置
  const handleReset = () => {
    queryParams.current = DEFAULT_QUERY_PARAMS;
    setPagination(DEFAULT_QUERY_PARAMS);
    fetchTaskList();
  };

  useEffect(() => {
    if (currentTab === 'taskList') {
      fetchTaskList();
    }
  }, [currentTab]);
  //新增 或编辑任务
  const taskEditAdd = (type: number) => {
    setModalType(type);
  };
  return (
    <>
      <div className={styles.taskListWrap}>
        {/* 搜索区域 */}
        <SearchTask onSearch={handleSearch} onReset={handleReset} />
        {projectDetail?.projectStatus === 1 && (
          <div className={styles.addButton}>
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => {
                taskEditAdd(2);
              }}
              style={{ borderRadius: '3px' }}
            >
              创建任务
            </Button>
          </div>
        )}
        {/* 任务详情列表 */}
        <ResizeTable
          columns={columns}
          dataSource={tableData}
          rowKey="guid"
          containerId="taskListId"
          loading={tableLoading}
          pagination={{
            onChange: handlePageChange,
            defaultPageSize: 100,
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            total: tableTotal,
          }}
        />
      </div>
      {/* 任务列表 新增/编辑modal */}
      {modalType && (
        <TaskCreateEdit
          modalType={modalType}
          closeModal={() => {
            setModalType(undefined);
          }}
          onOk={fetchTaskList}
        />
      )}
      {/* task详情 */}
      <TaskDrawer
        taskGuid={currentTaskGuid}
        onCancel={() => setCurrentTaskGuid(undefined)}
        onOk={fetchTaskList}
      />
    </>
  );
};
export default TaskList;
