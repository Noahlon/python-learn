import React from 'react';
import { Form, Input, Select, Button, Row, Col, Space } from 'antd';
import { ChainListParams } from '@/api/smsShortLink';
import { useModel } from '@umijs/max';
import { statusOpts } from '../config';
import { SEARCHLAYOUT } from '@/constants/processconfig';

interface IProps {
  onSearch: (data: ChainListParams) => void;
  onReset: () => void;
}

const SearchProject: React.FC<IProps> = ({ onSearch, onReset }) => {
  const { tenantOpts } = useModel('common');
  const [form] = Form.useForm();

  // 重置
  const handleReset = () => {
    form.resetFields();
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    onSearch?.(res);
  };

  return (
    <Form form={form} style={{ padding: '20px 20px 0' }}>
      <Row wrap={false}>
        <Col flex="auto">
          <Row gutter={16}>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="projectName" label="项目名称">
                <Input allowClear placeholder="请输入项目名称" />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="tenantCodeList" label="租户">
                <Select
                  placeholder="请选择租户"
                  allowClear
                  showSearch
                  mode="multiple"
                  maxTagCount="responsive"
                  optionFilterProp="label"
                  options={tenantOpts}
                />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="projectStatus" label="状态">
                <Select placeholder="状态" allowClear options={statusOpts} />
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none" style={{ marginLeft: '15px' }}>
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default SearchProject;
