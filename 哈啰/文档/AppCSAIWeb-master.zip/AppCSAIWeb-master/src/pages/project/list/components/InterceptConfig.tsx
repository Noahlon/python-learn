import { Button, Cascader, Form, Radio, message } from 'antd';
import React, { Fragment, useCallback, useEffect } from 'react';
import { LAYOUTLABEL } from '@/constants/processconfig';
import { interceptOptions, getInterceptDesc } from '../config';
import { useModel } from '@umijs/max';
import { UpdateStrateg, UpdateStrategyParams } from '@/api/project/projectInfo';
import styles from '../index.less';

type StrategyProp = UpdateStrategyParams & {
  predictionBiz?: [string, string, string];
  seatsCallOutBiz?: [string, string, string];
};

interface Prop {
  onOk: () => void;
}

const InterceptConfig: React.FC<Prop> = ({ onOk }) => {
  const { projectDetail } = useModel('project.model');
  const { bizTree, fetchBizTreeOpts } = useModel('common');
  const [form] = Form.useForm();

  const handleSubmit = async () => {
    const res = await form.validateFields();

    res?.interceptList?.forEach((item: StrategyProp) => {
      if (item?.predictionBiz?.length === 3 && item.predictionSwitch === 1) {
        item.predictionLevelOneBizId = item.predictionBiz[0];
        item.predictionLevelTwoBizId = item.predictionBiz[1];
        item.predictionSceneBizId = item.predictionBiz[2];
      }
      delete item.predictionBiz;
      if (
        item?.seatsCallOutBiz?.length === 3 &&
        item.seatsCallOutSwitch === 1
      ) {
        item.seatsCallOutLevelOneBizId = item.seatsCallOutBiz[0];
        item.seatsCallOutLevelTwoBizId = item.seatsCallOutBiz[1];
        item.seatsCallOutSceneBizId = item.seatsCallOutBiz[2];
      }
      delete item.seatsCallOutBiz;
    });

    const apiRes = await UpdateStrateg({
      projectGuid: projectDetail?.guid,
      projectInfoRequests: res.interceptList,
    });

    if (apiRes?.success) {
      onOk();
      message.success('拦截策略保存成功');
    }
  };

  const handleValidate = (_, values: string[]) => {
    if (values?.length !== 3) {
      return Promise.reject(new Error('请选择到三级行业'));
    }
    return Promise.resolve();
  };

  const getStrategy = useCallback(
    (index: number) => {
      return projectDetail?.projectUpdateStrategyRequests?.[index]?.strategy;
    },
    [projectDetail?.guid],
  );

  useEffect(() => {
    if (projectDetail?.projectUpdateStrategyRequests) {
      fetchBizTreeOpts();

      const list = projectDetail?.projectUpdateStrategyRequests?.map(
        (item: UpdateStrategyParams) => {
          const {
            aiCallOutSwitch,
            collaborateSwitch,
            predictionSwitch,
            seatsCallOutSwitch,
            predictionLevelOneBizId,
            predictionLevelTwoBizId,
            predictionSceneBizId,
            seatsCallOutLevelOneBizId,
            seatsCallOutLevelTwoBizId,
            seatsCallOutSceneBizId,
            strategy,
          } = item;
          const obj: StrategyProp = {
            aiCallOutSwitch,
            collaborateSwitch,
            predictionSwitch,
            seatsCallOutSwitch,
            strategy,
          };
          if (predictionLevelOneBizId) {
            obj.predictionBiz = [
              predictionLevelOneBizId,
              predictionLevelTwoBizId,
              predictionSceneBizId,
            ];
          }
          if (seatsCallOutLevelOneBizId) {
            obj.seatsCallOutBiz = [
              seatsCallOutLevelOneBizId,
              seatsCallOutLevelTwoBizId,
              seatsCallOutSceneBizId,
            ];
          }
          return obj;
        },
      );
      form.setFieldsValue({ interceptList: list });
    }
  }, [projectDetail?.guid]);

  return (
    <Form form={form} {...LAYOUTLABEL} className={styles.interceptConfig}>
      <Form.Item noStyle>
        <Form.List name="interceptList">
          {(fields) =>
            fields?.map(({ key, name }) => (
              <Fragment key={key}>
                <h4>
                  {getStrategy(name) === 'frequencyLimit'
                    ? '限频策略'
                    : '黑名单策略'}
                </h4>
                <Form.Item
                  label="AI外呼场景"
                  name={[name, 'aiCallOutSwitch']}
                  extra={getInterceptDesc(
                    getStrategy(name) === 'frequencyLimit' ? '1' : '3',
                  )}
                >
                  <Radio.Group options={interceptOptions} optionType="button" />
                </Form.Item>
                <Form.Item
                  label="协作外呼场景"
                  name={[name, 'collaborateSwitch']}
                  extra={getInterceptDesc(
                    getStrategy(name) === 'frequencyLimit' ? '1' : '3',
                  )}
                >
                  <Radio.Group options={interceptOptions} optionType="button" />
                </Form.Item>
                <Form.Item
                  label="预测外呼场景"
                  extra={getInterceptDesc(
                    getStrategy(name) === 'frequencyLimit' ? '2' : '4',
                  )}
                  shouldUpdate={(prev, cur) =>
                    prev?.[name]?.predictionSwitch !==
                    cur?.[name]?.predictionSwitch
                  }
                >
                  {({ getFieldValue }) => (
                    <>
                      <Form.Item name={[name, 'predictionSwitch']} noStyle>
                        <Radio.Group
                          options={interceptOptions}
                          optionType="button"
                        />
                      </Form.Item>
                      {getFieldValue('interceptList')?.[name]
                        ?.predictionSwitch === 1 && (
                        <Form.Item
                          name={[name, 'predictionBiz']}
                          rules={[{ validator: handleValidate }]}
                          noStyle
                        >
                          <Cascader
                            allowClear
                            changeOnSelect
                            showSearch
                            options={bizTree}
                            placeholder="请选择行业"
                            style={{ marginTop: 10 }}
                            fieldNames={{ label: 'name', value: 'id' }}
                          />
                        </Form.Item>
                      )}
                    </>
                  )}
                </Form.Item>
                <Form.Item
                  label="座席主动外呼场景"
                  extra={getInterceptDesc(
                    getStrategy(name) === 'frequencyLimit' ? '2' : '4',
                  )}
                  shouldUpdate={(prev, cur) =>
                    prev?.[name]?.seatsCallOutSwitch !==
                    cur?.[name]?.seatsCallOutSwitch
                  }
                >
                  {({ getFieldValue }) => (
                    <>
                      <Form.Item name={[name, 'seatsCallOutSwitch']} noStyle>
                        <Radio.Group
                          options={interceptOptions}
                          optionType="button"
                        />
                      </Form.Item>
                      {getFieldValue('interceptList')?.[name]
                        ?.seatsCallOutSwitch === 1 && (
                        <Form.Item
                          name={[name, 'seatsCallOutBiz']}
                          rules={[{ validator: handleValidate }]}
                          noStyle
                        >
                          <Cascader
                            allowClear
                            changeOnSelect
                            showSearch
                            options={bizTree}
                            placeholder="请选择行业"
                            style={{ marginTop: 10 }}
                            fieldNames={{ label: 'name', value: 'id' }}
                          />
                        </Form.Item>
                      )}
                    </>
                  )}
                </Form.Item>
              </Fragment>
            ))
          }
        </Form.List>
      </Form.Item>
      <Form.Item noStyle>
        <div className={styles.editModalFooter}>
          <Button onClick={onOk} className={styles.cancelBtn}>
            取消
          </Button>
          <Button type="primary" onClick={handleSubmit}>
            确定
          </Button>
        </div>
      </Form.Item>
    </Form>
  );
};

export default InterceptConfig;
