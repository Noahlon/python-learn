import React, { memo, useEffect, useState } from 'react';
import { Modal, Spin, Tabs } from 'antd';
import BaseConfig from './BaseConfig';
import InterceptConfig from './InterceptConfig';
import { useModel } from '@umijs/max';
interface Prop {
  open: boolean;
  guid: string;
  isAddAfter?: boolean;
  onOk?: () => void;
  onCancel: () => void;
}

const UpdateModal: React.FC<Prop> = memo(
  ({ open, guid, isAddAfter, onCancel, onOk }) => {
    const { fetchProjectDetail, detailLoading } = useModel('project.model');
    const [activeKey, setActiveKey] = useState('base');

    // 取消
    const handleCancel = () => {
      onCancel?.();
      setActiveKey('base');
    };

    const handleBaseOk = () => {
      fetchProjectDetail(guid);
      onOk?.();
      handleCancel();
    };

    useEffect(() => {
      if (open) {
        fetchProjectDetail(guid);
        if (isAddAfter) {
          setActiveKey('intercept');
        }
      }
    }, [open, isAddAfter]);

    return (
      <Modal
        open={open}
        width="650px"
        title="编辑"
        destroyOnClose
        onCancel={handleCancel}
        footer={null}
      >
        <Spin spinning={detailLoading}>
          <Tabs
            activeKey={activeKey}
            onChange={(activeKey) => setActiveKey(activeKey)}
            items={[
              {
                label: `基础信息`,
                key: 'base',
                children: (
                  <BaseConfig onOk={handleBaseOk} onCancel={handleCancel} />
                ),
              },
              {
                label: `拦截策略`,
                key: 'intercept',
                children: <InterceptConfig onOk={handleCancel} />,
              },
            ]}
          />
        </Spin>
      </Modal>
    );
  },
);
export default UpdateModal;
