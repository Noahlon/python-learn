import {
  AllSkillGroupRes,
  queryAllSkillGroup,
} from '@/api/accountPermission/skillGroup';
import {
  HumanEnumRes,
  NameStatisticsObj,
  getRosterEnumList,
  queryNameNStatistics,
} from '@/api/project/nameInfo';
import {
  ProjectDetailObj,
  queryProjectDetail,
} from '@/api/project/projectInfo';
import { useState } from 'react';
import { TypeTab } from './detail/components/nameList/config';

const ProjectModel = () => {
  // 项目详情数据
  const [projectDetail, setProjectDetail] = useState<ProjectDetailObj>();
  const [detailLoading, setDetailLoading] = useState(false);
  // 名单所有枚举
  const [rosterEunmList, setRosterEunmList] = useState<HumanEnumRes['data']>(
    [],
  );
  // 所有技能组
  const [allSkillGroup, setAllSkillGroup] = useState<AllSkillGroupRes['data']>(
    [],
  );
  // 名单列表Statistics
  const [rosterSummary, setRosterSummary] = useState<NameStatisticsObj>();

  // 当前的列表tab
  const [currentTab, setCurrentTab] = useState<TypeTab>('nameList');

  // 名单的流转状态
  const [rosterWanderStatus, setRosterWanderStatus] = useState<string>(null);

  // fetch详情数据
  const fetchProjectDetail = async (guid: string) => {
    setDetailLoading(true);
    const res = await queryProjectDetail({ guid });
    if (res?.data) {
      setProjectDetail(res.data);
    }
    setDetailLoading(false);
  };

  // fetch名单所有枚举
  const fetchRosterEnum = async () => {
    const res = await getRosterEnumList();
    setRosterEunmList(res?.data);
  };

  // fetch租户下所有技能组
  const fetchAllSkillGroup = async (tenantCodeList: number[]) => {
    const res = await queryAllSkillGroup({ tenantCodeList });
    setAllSkillGroup(res?.data);
  };

  // fetch名单列表Statistics
  const fetchRosterSummary = async (guid: string) => {
    const res = await queryNameNStatistics({ projectGuid: guid });
    if (res?.data) {
      setRosterSummary(res.data);
    }
  };

  return {
    projectDetail,
    setProjectDetail,
    detailLoading,
    fetchProjectDetail,
    fetchRosterEnum,
    rosterEunmList,
    allSkillGroup,
    fetchAllSkillGroup,
    currentTab,
    setCurrentTab,
    rosterSummary,
    fetchRosterSummary,
    rosterWanderStatus,
    setRosterWanderStatus,
  };
};

export default ProjectModel;
