import React, { FC, useState, useEffect, useCallback } from 'react';
import { Table, Radio, Select, Typography, message } from 'antd';
import { debounce, throttle } from 'lodash';
import { queryList } from '@/api/BatchOperation';
import { getTaskList, ITaskInfo } from '@/api/taskCenter';
import { httpReplace } from '@/utils';
import styles from './index.less';

const BatchOperation: FC = () => {
  const [data, setData] = useState([]);
  const [totalRecord, setTotalCount] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [btn, setBtn] = useState(0);
  const [tableHeight, setTableHeight] = useState<string | number>('auto');
  const [value, setValue] = useState('');
  const [list, setList] = useState<ITaskInfo[]>([]);

  // 分页
  const [pageIndex, setPageIndex] = useState(1);
  const [pageSize, setPageSize] = useState(100);

  // 高度变化
  const handleHeightEvent = debounce(async () => {
    const ele = document.getElementById('tableId');
    const _height = (ele?.clientHeight || 300) - 119;
    setTableHeight(_height < 101 ? 500 : _height);
  }, 200);

  // 获取下拉菜单
  const handleTaskSearch = useCallback(
    debounce(async (name: string) => {
      const { list } = await getTaskList({
        pageNum: 1,
        pageSize: 100,
        name,
      });
      setList(list || []);
    }, 500),
    [],
  );

  // api
  const searchList = async (obj) => {
    setLoading(true);
    const {
      data: { list, totalRecord },
    } = await queryList(obj);
    setData(list);
    setTotalCount(totalRecord);
    setLoading(false);
  };

  // 换页
  function onPageChange(page: number, size: number) {
    const params:any = { pageSize: size, pageNum: 1 };
    params.pageSize = size;
    params.namelistType = btn || undefined;
    params.taskGuid=  value || undefined;
    params.pageNum = page;
    if (size !== pageSize) {
      setPageIndex(1);
      setPageSize(size);
      params.pageNum = 1;
    } else {
      setPageIndex(page);
    }
      searchList(params);
  }

  useEffect(() => {
    // handleSearch();
    searchList({ pageNum: 1, pageSize: 100 });
    handleHeightEvent();
    window.addEventListener('resize', handleHeightEvent);
    return () => window.removeEventListener('resize', handleHeightEvent);
  }, []);

  // 搜索
  const search = useCallback(
    throttle(async (val) => {
      if (val !== '') {
        searchList({
          pageNum: 1,
          pageSize: 100,
          taskGuid: val,
          namelistType: btn || undefined,
        });
        setPageSize(100);
        setPageIndex(1);
      }
      setValue(val);
    }, 1000),
    [value, btn],
  );

  // 按钮切换
  const buttonChange = (e) => {
    if (e.target.value !== 0) {
      searchList({
        pageNum: 1,
        pageSize: 100,
        namelistType: e.target.value,
        taskGuid: value || undefined,
      });
    } else {
      searchList({ pageNum: 1, pageSize: 100, taskGuid: value || undefined });
    }
    setPageIndex(1);
    setPageSize(100);
    setBtn(e.target.value);
  };
  const handleExport = async (url: string) => {
    const dest = message.loading('正在下载');
    let elink = document.createElement('a');
    elink.style.display = 'none';
    let newUrl = httpReplace(url);
    elink.href = newUrl;
    // elink.download = '名单模版';
    document.body.appendChild(elink);
    elink.click();
    setTimeout(() => {
      document.body.removeChild(elink);
    }, 300);
    dest?.();
  };

  const columns = [
    {
      title: '文件名称',
      dataIndex: 'fileName',
      width: 260,
    },
    {
      title: '任务名称',
      dataIndex: 'taskName',
      width: 180,
    },
    {
      title: '操作状态',
      dataIndex: 'statusDesc',
      width: 120,
    },
    {
      title: '操作类型',
      dataIndex: 'namelistType',
      width: 120,
      render: (text) => (text === 1 ? '添加呼叫' : '取消呼叫'),
    },
    {
      title: '成功条数',
      dataIndex: 'successCount',
      width: 100,
    },
    {
      title: '重复条数',
      dataIndex: 'duplicateCount',
      width: 100,
    },
    {
      title: '失败条数',
      dataIndex: 'failedCount',
      width: 100,
      render: (text) => (text ? text : '-'),
    },
    {
      title: '操作时间',
      dataIndex: 'createTime',
      width: 200,
    },
    {
      title: '操作人',
      dataIndex: 'createBy',
      width: 260,
    },
    {
      title: '操作',
      width: 120,
      dataIndex: 'failedCount',
      fixed: 'right',
      render: (text, record) => {
        return text ? (
          <Typography.Link onClick={() => handleExport(record.failedUrl)}>
            下载失败数据
          </Typography.Link>
        ) : (
          <span style={{ color: '#999' }}>下载失败数据</span>
        );
      },
    },
  ];

  return (
    <div className={styles.batchoperation}>
      <div className={styles.btn}>
        <Radio.Group
          value={btn}
          onChange={buttonChange}
          style={{ marginRight: '20px' }}
        >
          <Radio.Button value={0}>全部</Radio.Button>
          <Radio.Button value={1}>添加呼叫</Radio.Button>
          <Radio.Button value={2}>取消呼叫</Radio.Button>
        </Radio.Group>
        <Select
          showSearch
          style={{ width: '300px' }}
          placeholder="任务名称"
          getPopupContainer={(triggerNode) =>
            triggerNode.parentElement || document.body
          }
          defaultActiveFirstOption={false}
          showArrow={true}
          filterOption={false}
          onChange={(val) => search(val)}
          onSearch={handleTaskSearch}
          notFoundContent={null}
          options={list.map((d) => ({
            value: d.guid,
            label: d.name,
          }))}
          allowClear
        />
      </div>
      <div className={styles.tree} id="tableId">
        <Table
          loading={loading}
          rowKey={(record) => record.guid}
          columns={columns}
          dataSource={data}
          pagination={{
            showSizeChanger: true,
            total: totalRecord,
            current: pageIndex,
            pageSize: pageSize,
            onChange: onPageChange,
            showTotal: (total) => `共 ${total} 条`,
          }}
          scroll={{ y: tableHeight }}
        />
      </div>
    </div>
  );
};

export default BatchOperation;
