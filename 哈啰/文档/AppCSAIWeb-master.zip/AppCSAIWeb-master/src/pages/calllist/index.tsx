import React, {
  FC,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  Space,
  Typography,
  Pagination,
  message,
  Popover,
  Tooltip,
  notification,
} from 'antd';
import { debounce } from 'lodash';
import moment from 'moment';
import { v1 as uuidv1 } from 'uuid';

import {
  addComplaint,
  exportCallList,
  AddComplaintParams,
  getCallList,
  ICallList,
} from '@/api/call';
import { useModel } from '@umijs/max';
import { showEmptyLine, text1Tooltip } from '@/utils/format';
import { ProTable } from '@ant-design/pro-components';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import PlayAudio from '../../components/PlayAudio';
import CallDetail from './components/CallDetail';
import BlackGroupModal from './components/BlackGroupModal';
import CancelBlackModal from './components/CancelBlackModal';
import CallSearch, {
  callIsTransferOption,
  callStrategyOption,
  ccServerOption,
  callLossOption,
} from './components/CallSearch';
import { VList } from 'virtuallist-antd';
import styles from './index.less';

// 挂断方
export const releaseInitiatorOption = [
  { label: '未知', value: 0 },
  { label: '呼叫方', value: 1 },
  { label: '被叫方', value: 2 },
];

// 意图类型
export const intentionTypeOption = [
  { label: '短语', value: 1 },
  { label: '算法', value: 2 },
  { label: '核心句', value: 3 },
  { label: '短语+算法', value: 4 },
  { label: '算法+短语', value: 5 },
];

const labelWrapStyle = {
  width: '100%',
  overflow: 'hidden',
};

const labelTableWrapStyle = {
  ...labelWrapStyle,
  display: 'flex',
};

const labelItemStyle = {
  padding: '3px 10px',
  color: '#999',
  background: 'rgba(214, 214, 215, 0.6)',
  fontSize: '12px',
  borderRadius: '3px',
  margin: '2px 5px 2px 0',
  display: 'inline-block',
};

const labelTableItemStyle = {
  ...labelItemStyle,
  flexShrink: 0,
};

const formatType = 'YYYY-MM-DD HH:mm:ss';

const DEFAULT_CALL_PARAMS = {
  createTime: [
    moment(moment('00:00:00', 'HH:mm:ss')).format(formatType),
    moment(moment('23:59:59', 'HH:mm:ss')).format(formatType),
  ],
};

const persistenceKey = 'calllist250530';

const CallList: FC = () => {
  const queryParams = useRef(DEFAULT_CALL_PARAMS);
  const { callResultList, handleCallResultList } = useModel('speech');
  const [tableData, setTableData] = useState<ICallList[]>([]);
  const [isLoading, setLoading] = useState(false);
  const [pageSize, setPageSize] = useState(100);
  const [tableHeight, setTableHeight] = useState<number>();
  const [total, setTotal] = useState(0);
  const [pageIndex, setPageIndex] = useState(1);
  // 导出
  const [exportLoading, setExportLoading] = useState(false);
  // 播放
  const [showPlayModel, setShowPlayModel] = useState(false);
  // 文本
  const [showTextModel, setShowTextModel] = useState(false);
  const [curInfo, setCurInfo] = useState<ICallList | undefined>(undefined);
  const [curTextInfo, setCurTextInfo] = useState<ICallList | undefined>(
    undefined,
  );
  const [isOverflow, setOverflow] = useState(false);

  // 黑名单组Modal
  const [currentRecord, setCurrentRecord] = useState<ICallList>();
  const [blackGroupOpen, setBlackGroupOpen] = useState(false);
  const [cancelBlackOpen, setCancelBlackOpen] = useState(false);

  // 播放
  const handlerGetDetail = useCallback((info: ICallList) => {
    setCurInfo(info);
    setShowPlayModel(true);
  }, []);

  // 查看文本
  const handlerShowText = useCallback((info: ICallList) => {
    setCurTextInfo(info);
    setShowTextModel(true);
  }, []);

  const formatApiParams = (param) => {
    if (Array.isArray(param.createTime) && param.createTime.length) {
      param.startCreateTime = moment(param.createTime[0]).format(formatType);
      param.endCreateTime = moment(param.createTime[1]).format(formatType);
      delete param.createTime;
    }
    if (Array.isArray(param.hangupTime) && param.hangupTime.length) {
      param.startHangupTime = moment(param.hangupTime[0]).format(formatType);
      param.endHangupTime = moment(param.hangupTime[1]).format(formatType);
      delete param.hangupTime;
    }
    if (Array.isArray(param.answerTime) && param.answerTime.length) {
      param.startAnswerTime = moment(param.answerTime[0]).format(formatType);
      param.endAnswerTime = moment(param.answerTime[1]).format(formatType);
      delete param.answerTime;
    }
    if (Array.isArray(param.dialTime) && param.dialTime.length) {
      param.startDialTime = moment(param.dialTime[0]).format(formatType);
      param.endDialTime = moment(param.dialTime[1]).format(formatType);
      delete param.dialTime;
    }
    if (Array.isArray(param.citys) && param.citys.length) {
      const _citys = [];
      param.citys.forEach((item) => {
        if (Array.isArray(item) && item.length) {
          _citys.push(item[item.length - 1]);
        }
      });
      param.citys = _citys;
    }
    // 命中意图包含/不包含
    if (param.intentListData) {
      param[param.intentListType] = param.intentListData;
      delete param.intentListData;
    }
    delete param.intentListType;
    return param;
  };

  const handlerGetLists = useCallback(
    async (params) => {
      setLoading(true);
      const param: any = {
        pageNum: params.pageNum || pageIndex,
        pageSize: params.pageSize || pageSize,
        ...queryParams.current,
      };
      if (Array.isArray(param.createTime) && param.createTime.length) {
        param.startCreateTime = moment(param.createTime[0]).format(formatType);
        param.endCreateTime = moment(param.createTime[1]).format(formatType);
        delete param.createTime;
      }
      if (Array.isArray(param.hangupTime) && param.hangupTime.length) {
        param.startHangupTime = moment(param.hangupTime[0]).format(formatType);
        param.endHangupTime = moment(param.hangupTime[1]).format(formatType);
        delete param.hangupTime;
      }
      if (Array.isArray(param.answerTime) && param.answerTime.length) {
        param.startAnswerTime = moment(param.answerTime[0]).format(formatType);
        param.endAnswerTime = moment(param.answerTime[1]).format(formatType);
        delete param.answerTime;
      }
      if (Array.isArray(param.dialTime) && param.dialTime.length) {
        param.startDialTime = moment(param.dialTime[0]).format(formatType);
        param.endDialTime = moment(param.dialTime[1]).format(formatType);
        delete param.dialTime;
      }
      if (Array.isArray(param.citys) && param.citys.length) {
        const _citys = [];
        param.citys.forEach((item) => {
          if (Array.isArray(item) && item.length) {
            _citys.push(item[item.length - 1]);
          }
        });
        param.citys = _citys;
      }
      // 命中意图包含/不包含
      if (param.intentListData) {
        param[param.intentListType] = param.intentListData;
        delete param.intentListData;
      }
      delete param.intentListType;
      const callListRes = await getCallList(param);
      if (callListRes?.success) {
        setTableData(callListRes.data?.list as ICallList[]);
        setTotal(Number(callListRes.data?.totalRecord) || 0);
      } else {
        setTableData([]);
      }
      setLoading(false);
    },
    [pageSize, pageIndex],
  );

  // 标记
  const handleComplaint = async (
    record: ICallList,
    type: boolean,
    groupIdList?: string[],
  ) => {
    const params: AddComplaintParams = {
      dialogueGuid: record.guid,
      isComplaint: type,
      calledNumber: record.calledNumber,
    };
    if (groupIdList) {
      params.groupIdList = groupIdList;
    }
    const res: any = await addComplaint(params);
    if (res.success) {
      if (res?.data?.complaintDesc) {
        notification.warning({
          message: '提示',
          description: res?.data?.complaintDesc || '未知错误信息',
        });
      } else {
        message.success('操作成功');
      }

      const _data = [...tableData];
      const callItem = _data.find((item) => item.guid === record.guid);
      if (callItem) callItem.isComplaint = !callItem.isComplaint;
      setTableData(_data);
    }
  };

  // 黑名单组标记
  const handleBlackComplaint = async (res) => {
    const { groupIdList } = res || {};
    await handleComplaint(currentRecord, true, groupIdList);
  };

  const column: any = [
    {
      title: '被叫号码',
      dataIndex: 'calledNumber',
      key: 'calledNumber',
      width: 150,
      fixed: 'left',
      render: (text: string) => {
        return (
          <div className={styles.textCenter}>
            <div className={styles.phoneellipsis}>
              <Tooltip placement="topLeft" title={text}>
                {text}
              </Tooltip>
            </div>
          </div>
        );
      },
    },
    {
      title: 'MD5',
      dataIndex: 'phoneNumberMd5',
      width: 240,
      key: 'phoneNumberMd5',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '租户',
      dataIndex: 'tenantName',
      width: 240,
      key: 'tenantName',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '租户计费数',
      dataIndex: 'tenantBilling',
      width: 180,
      key: 'tenantBilling',
      render: (text: number) => (text === 0 ? 0 : text ? text : '-'),
    },
    {
      title: '拨号时间',
      dataIndex: 'dialTime',
      width: 200,
      key: 'dialTime',
    },
    {
      title: '外呼结果',
      dataIndex: 'calloutResult',
      key: 'calloutResult',
      width: 200,
      render: (text: number) => {
        const item = callResultList?.find((item) => item.value === text);
        return text1Tooltip(item?.label || text);
      },
    },
    {
      title: '呼叫中心',
      dataIndex: 'ccServer',
      width: 200,
      key: 'ccServer',
      render: (val: string) => {
        return ccServerOption.find((item) => item.value === val)?.label || '-';
      },
    },
    {
      title: '接听时间',
      dataIndex: 'answerTime',
      width: 200,
      key: 'answerTime',
    },
    {
      title: '坐席接听时间',
      dataIndex: 'seatAnswerTime',
      width: 200,
      key: 'seatAnswerTime',
    },
    {
      title: '任务名称',
      width: 260,
      dataIndex: 'taskName',
      key: 'taskName',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '话术名称',
      dataIndex: 'speechName',
      width: 260,
      key: 'speechName',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '用户最终意向',
      dataIndex: 'intentClassify',
      key: 'intentClassify',
      width: 150,
    },
    {
      title: '最终意向描述',
      dataIndex: 'intentClassifyName',
      key: 'intentClassifyName',
      width: 150,
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '标签',
      dataIndex: 'tags',
      key: 'tags',
      width: 200,
      // ellipsis: true,
      render: (text: string) => {
        if (text) {
          try {
            const _array = JSON.parse(text);
            if (Array.isArray(_array)) {
              const getContent = (type?: string) => (
                <div
                  style={
                    type === 'table' ? labelTableWrapStyle : labelWrapStyle
                  }
                >
                  {_array.map((item) => (
                    <span
                      key={`${uuidv1()}${item}`}
                      style={
                        type === 'table' ? labelTableItemStyle : labelItemStyle
                      }
                    >
                      {item}
                    </span>
                  ))}
                </div>
              );
              return (
                <Popover
                  content={getContent()}
                  trigger="hover"
                  placement="topLeft"
                  className={styles.labelPop}
                  overlayStyle={{ maxWidth: '500px' }}
                  // getPopupContainer={(triggerNode) =>
                  //   triggerNode.parentElement || document.body
                  // }
                >
                  {getContent('table')}
                </Popover>
              );
            }
          } catch (error) {}
        }
      },
    },
    {
      title: '对话次数',
      dataIndex: 'speechCount',
      key: 'speechCount',
      width: 150,
      render: (text: number) => text,
    },
    {
      title: '说话次数',
      dataIndex: 'userSpeakCount',
      key: 'userSpeakCount',
      width: 150,
      render: (text: number) => text,
    },
    {
      title: '命中意图',
      dataIndex: 'recognizedIntent',
      key: 'recognizedIntent',
      width: 200,
      // ellipsis: true,
      render: (text: string) => {
        if (text) {
          try {
            const _array = JSON.parse(text);
            if (Array.isArray(_array)) {
              const getContent = (type?: string) => (
                <div
                  style={
                    type === 'table' ? labelTableWrapStyle : labelWrapStyle
                  }
                >
                  {_array.map((item) => (
                    <span
                      key={`${uuidv1()}${item}`}
                      style={
                        type === 'table' ? labelTableItemStyle : labelItemStyle
                      }
                    >
                      {item}
                    </span>
                  ))}
                </div>
              );
              return (
                <Popover
                  content={getContent()}
                  trigger="hover"
                  placement="topLeft"
                  overlayStyle={{ maxWidth: '500px' }}
                  // getPopupContainer={(triggerNode) =>
                  //   triggerNode.parentElement || document.body
                  // }
                >
                  {getContent('table')}
                </Popover>
              );
            }
          } catch (error) {}
        }
      },
    },
    {
      title: '意图识别类型',
      dataIndex: 'intentionObtainType',
      key: 'intentionObtainType',
      width: 130,
      render: (text: number) =>
        intentionTypeOption.find((item) => item.value === text)?.label,
    },
    {
      title: '命中语料',
      width: 200,
      dataIndex: 'hitCorpus',
      key: 'hitCorpus',
      // ellipsis: true,
      render: (text: string[]) => {
        if (Array.isArray(text) && text?.length) {
          const getContent = (type?: string) => (
            <div
              style={type === 'table' ? labelTableWrapStyle : labelWrapStyle}
            >
              {text.map((item) => (
                <span
                  key={`${uuidv1()}${item}`}
                  style={
                    type === 'table' ? labelTableItemStyle : labelItemStyle
                  }
                >
                  {item}
                </span>
              ))}
            </div>
          );
          return (
            <Popover
              content={getContent()}
              trigger="hover"
              placement="topLeft"
              className={styles.labelPop}
              overlayStyle={{ maxWidth: '500px' }}
              // getPopupContainer={(triggerNode) =>
              //   triggerNode.parentElement || document.body
              // }
            >
              {getContent('table')}
            </Popover>
          );
        }
      },
    },
    {
      title: '触发转接',
      dataIndex: 'isTriggerTransfer',
      width: 150,
      key: 'isTriggerTransfer',
      render: (text: boolean) => {
        return callIsTransferOption.find((item) => item.value === text)?.label;
      },
    },
    {
      title: '转接结果',
      dataIndex: 'isTransfer',
      width: 150,
      key: 'isTransfer',
      render: (text: boolean) => {
        return callIsTransferOption.find((item) => item.value === text)?.label;
      },
    },
    {
      title: '转接成功',
      dataIndex: 'transferSuccessDesc',
      width: 200,
      key: 'transferSuccessDesc',
      render: (text) => {
        return showEmptyLine(text);
      },
    },
    {
      title: '挂断方',
      dataIndex: 'releaseInitiator',
      width: 150,
      key: 'releaseInitiator',
      render: (text: number) => {
        const item = releaseInitiatorOption.find((item) => item.value === text);
        if (item) {
          return item.label;
        }
        return '-';
      },
    },
    {
      title: '挂断原因',
      dataIndex: 'callEndReason',
      width: 150,
      key: 'callEndReason',
    },
    {
      title: '运营商',
      dataIndex: 'carrier',
      width: 150,
      key: 'carrier',
    },
    {
      title: '省市',
      dataIndex: 'province',
      width: 200,
      key: 'province',
      render: (text: string, record: ICallList) => {
        if (text && record.city) {
          return text1Tooltip(`${text}/${record.city}`);
        } else if (text) {
          return text1Tooltip(text);
        } else if (record.city) {
          return text1Tooltip(record.city);
        }
        return '-';
      },
    },
    {
      title: '呼叫次数',
      dataIndex: 'tryCallNum',
      width: 150,
      key: 'tryCallNum',
    },
    {
      title: '线路类型',
      dataIndex: 'lineType',
      width: 150,
      key: 'lineType',
    },
    {
      title: '供应商名称',
      dataIndex: 'suppliersName',
      width: 230,
      key: 'suppliersName',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '供应商编号',
      dataIndex: 'suppliersCode',
      width: 200,
      key: 'suppliersCode',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '供应线路名称',
      dataIndex: 'suppliersLineName',
      width: 230,
      key: 'suppliersLineName',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '线路组编号',
      dataIndex: 'tenantLineGroupCode',
      width: 200,
      key: 'tenantLineGroupCode',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '供应线路编号',
      dataIndex: 'suppliersLineCode',
      width: 200,
      key: 'suppliersLineCode',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '主叫号码',
      dataIndex: 'callingNumber',
      width: 150,
      key: 'callingNumber',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '外显号码',
      dataIndex: 'realCallingNumber',
      width: 200,
      key: 'realCallingNumber',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '供应商计费数',
      dataIndex: 'costUnit',
      width: 150,
      key: 'costUnit',
    },

    {
      title: 'ASR服务商',
      dataIndex: 'asrServer',
      width: 150,
      key: 'asrServer',
      render: (text) => {
        switch (text) {
          case 'alimrcp':
            return '阿里云';
          case 'baimrcp':
            return '百度';
          case 'xunfei':
            return '讯飞';
        }
      },
    },
    {
      title: 'TTS服务商',
      dataIndex: 'ttsServer',
      width: 150,
      key: 'ttsServer',
      render: (text) => {
        switch (text) {
          case 'baimrcp':
            return '百度';
          case 'alimrcp':
            return '阿里云';
          case 'xunfei':
            return '讯飞超拟人TTS';
          case 'cosyvoice-v1':
            return 'CosyVoice大模型';
        }
      },
    },
    {
      title: '响铃时长（秒）',
      dataIndex: 'durationRing',
      key: 'durationRing',
      width: 150,
      render: (text: number) => text,
    },
    {
      title: '通话时长（秒）',
      dataIndex: 'durationCall',
      width: 150,
      key: 'durationCall',
      render: (text: number) => text,
    },
    {
      title: 'AI段通话时长',
      dataIndex: 'durationCallAi',
      width: 150,
      key: 'durationCallAi',
      render: (text) => {
        return showEmptyLine(text);
      },
    },
    {
      title: '转接等待时长',
      dataIndex: 'waitDuration',
      width: 200,
      key: 'waitDuration',
      render: (text) => {
        return showEmptyLine(text);
      },
    },
    {
      title: '人工段通话时长',
      dataIndex: 'durationCallManual',
      width: 150,
      key: 'durationCallManual',
      render: (text) => {
        return showEmptyLine(text);
      },
    },
    {
      title: '命中三方黑名单',
      dataIndex: 'isHitBlackList',
      width: 200,
      key: 'isHitBlackList',
      render: (text, record) => {
        if (record?.isHitBlackList !== undefined) {
          if (record?.isHitBlackList) return '是';
          return '否';
        } else {
          return '-';
        }
      },
    },
    {
      title: '外呼策略',
      dataIndex: 'callStrategy',
      width: 200,
      key: 'callStrategy',
      render: (text: number) => {
        return (
          callStrategyOption.find((item) => item.value === text)?.label || ''
        );
      },
    },
    {
      title: ' 黑名单供应商',
      dataIndex: 'blacklistSupplierName',
      width: 200,
      key: 'blacklistSupplierName',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '服务器名称/IP',
      dataIndex: 'callCenterIp',
      width: 180,
      key: 'callCenterIp',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '标签限频命中规则名称',
      dataIndex: 'featureLimitRuleName',
      key: 'featureLimitRuleName',
      width: 200,
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '标签限频事件源',
      dataIndex: 'featureRuleTypeName',
      key: 'featureRuleTypeName',
      width: 200,
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '触发短信',
      dataIndex: 'hitSms',
      width: 150,
      key: 'hitSms',
      render: (text: number) => text,
    },
    {
      title: '机器人sessionId',
      dataIndex: 'bizReqId',
      width: 330,
      key: 'bizReqId',
      render(text) {
        return (
          <CopyToClipboard
            text={text}
            onCopy={() => message.success('复制成功')}
          >
            <a>{text}</a>
          </CopyToClipboard>
        );
      },
    },
    {
      title: '任务ID',
      width: 230,
      dataIndex: 'taskGuid',
      key: 'taskGuid',
      render: (text: string) => text1Tooltip(text),
    },
    // {
    //   title: '线路小号',
    //   dataIndex: 'realCallingNumber',
    //   key: 'realCallingNumber',
    // },
    // {
    //   title: 'ASR模型名称',
    //   dataIndex: 'asrModel',
    //   width: '2%',
    //   key: 'asrModel',
    // },
    {
      title: '一级行业',
      dataIndex: 'bizName',
      width: 150,
      key: 'bizName',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '二级行业',
      dataIndex: 'bizChildName',
      width: 150,
      key: 'bizChildName',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '场景名称',
      dataIndex: 'bizSceneName',
      width: 150,
      key: 'bizSceneName',
      render: (text: string) => text1Tooltip(text),
    },

    {
      title: '转接时间',
      dataIndex: 'transferTime',
      width: 200,
      key: 'transferTime',
    },
    {
      title: '挂断时间',
      dataIndex: 'hangupTime',
      width: 200,
      key: 'hangupTime',
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      width: 200,
      key: 'createTime',
    },
    {
      title: '项目名称',
      dataIndex: 'projectName',
      width: 230,
      key: 'projectName',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '项目ID',
      dataIndex: 'projectGuid',
      width: 200,
      key: 'projectGuid',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '任务类型',
      dataIndex: 'projectTaskTypeDesc',
      width: 200,
      key: 'projectTaskTypeDesc',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '技能组',
      dataIndex: 'skillGroupName',
      width: 260,
      key: 'skillGroupName',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '座席',
      dataIndex: 'seatName',
      width: 260,
      key: 'seatName',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '触发转接语料数',
      dataIndex: 'transferCorpusCount',
      width: 200,
      key: 'transferCorpusCount',
    },
    {
      title: '触发转接次数',
      dataIndex: 'transferCount',
      width: 200,
      key: 'transferCount',
    },
    {
      title: '振铃次数',
      dataIndex: 'ringCount',
      width: 200,
      key: 'ringCount',
    },
    {
      title: '是否呼损',
      dataIndex: 'callLoss',
      width: 200,
      key: 'callLoss',
      render: (val: boolean) => {
        return callLossOption.find((item) => item.value === val)?.label || '-';
      },
    },
    {
      title: '呼损分类',
      dataIndex: 'callLossClassDesc',
      width: 200,
      key: 'callLossClassDesc',
    },
    {
      title: 'userGuid',
      dataIndex: 'userGuid',
      width: 160,
      key: 'userGuid',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: 'userNewId',
      dataIndex: 'userNewId',
      width: 120,
      key: 'userNewId',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '命中黑名单组名',
      dataIndex: 'blackGroupName',
      width: 120,
      key: 'blackGroupName',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '命中黑名单组ID',
      dataIndex: 'blackGroupId',
      width: 120,
      key: 'blackGroupId',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '租户侧意向分类',
      dataIndex: 'outIntentClassify',
      width: 150,
      key: 'outIntentClassify',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '租户侧意向分类名称',
      dataIndex: 'outIntentClassifyName',
      width: 150,
      key: 'outIntentClassifyName',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '用户特征标签',
      dataIndex: 'userCharacteristicLabel',
      key: 'userCharacteristicLabel',
      width: 150,
    },
    {
      title: '模型意向分类',
      dataIndex: 'modelIntentionClassify',
      key: 'modelIntentionClassify',
      width: 150,
    },
    {
      title: '规则意向分类',
      dataIndex: 'ruleIntentionClassify',
      key: 'ruleIntentionClassify',
      width: 150,
    },
    {
      title: '操作',
      dataIndex: 'handle',
      key: 'handle',
      width: 200,
      fixed: 'right',
      render: function operation(text: string, record: ICallList) {
        return (
          <Space direction="horizontal">
            <Typography.Link
              disabled={!record.durationCall}
              onClick={() => handlerGetDetail(record)}
            >
              播放
            </Typography.Link>
            <Typography.Link
              disabled={!record.durationCall}
              onClick={() => handlerShowText(record)}
            >
              查看
            </Typography.Link>
            {record?.isComplaint ? (
              <svg
                className={styles.bannerComplaintIcon}
                aria-hidden="true"
                onClick={() => {
                  setCurrentRecord(record);
                  setCancelBlackOpen(true);
                }}
              >
                <use xlinkHref="#icon-qizhi-"></use>
              </svg>
            ) : (
              <svg
                className={styles.bannerIcon}
                aria-hidden="true"
                onClick={() => {
                  setCurrentRecord(record);
                  setBlackGroupOpen(true);
                }}
              >
                <use xlinkHref="#icon-qizhi"></use>
              </svg>
            )}
          </Space>
        );
      },
    },
  ];

  // 获取高度变化
  const handleHeightEvent = debounce(async () => {
    // setTimeout(() => {
    const wrapEle = document.getElementById('callWrap');
    const searchEle = document.getElementById('callSearchWrap');
    const paginationEle = document.getElementById('callPaginationWrap');
    const _wrapHeight = wrapEle?.clientHeight || 700;
    const _searchHeight = searchEle?.clientHeight || 67;
    const paginationHeight = paginationEle?.clientHeight || 52;
    try {
      const _height = _wrapHeight - _searchHeight - paginationHeight - 55 - 50;
      setTableHeight(_height < 301 ? 500 : _height);
      if (_height < 301) {
        setOverflow(true);
      } else {
        setOverflow(false);
      }
    } catch (e) {}
    // }, 0);
  }, 200);

  // 分页
  const onChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      const params = { pageSize: size, pageNum: 1 };
      if (size !== pageSize) {
        setPageIndex(1);
        setPageSize(size);
      } else {
        setPageIndex(page);
        params.pageNum = page;
      }
      handlerGetLists(params);
    },
    [pageSize],
  );

  // 搜索
  const handleSearchClick = useCallback(
    debounce(
      (data) => {
        setPageIndex(1);
        queryParams.current = data;
        handlerGetLists({
          pageNum: 1,
        });
      },
      1000,
      { leading: true },
    ),
    [pageSize, pageIndex],
  );

  // 重置
  const handleReset = useCallback(() => {
    setPageIndex(1);
    queryParams.current = DEFAULT_CALL_PARAMS;
    handlerGetLists({
      pageNum: 1,
    });
  }, [pageSize, pageIndex]);

  // 导出
  /* eslint-disable @typescript-eslint/no-unused-vars */
  const handleExport = async () => {
    const exportFieldList = JSON.parse(
      localStorage.getItem(persistenceKey) || '{}',
    );

    //根据order属性对过滤后的数组进行排序
    function sort(arr) {
      return arr.sort(([_, a], [__, b]) => {
        return a?.order - b?.order;
      });
    }
    function getSortedKeysByShowAndOrder(obj) {
      // 将对象转换为键值对数组
      const entries = Object.entries(obj);

      // 过滤掉show为false的键值对
      const filteredEntries = entries.filter(
        ([key, value]) => value?.show !== false,
      );

      const left = filteredEntries.filter(
        ([_, value]) => value?.fixed === 'left',
      );
      const right = filteredEntries.filter(
        ([_, value]) => value?.fixed === 'right',
      );
      const middle = filteredEntries.filter(([_, value]) => !value?.fixed);

      const sortedEntries = [...sort(left), ...sort(middle), ...sort(right)];

      // 从排序后的键值对数组中提取键
      return sortedEntries.map(([key]) => key);
    }

    const sortedKeys = getSortedKeysByShowAndOrder(exportFieldList).filter(
      (key) => key !== 'handle',
    );

    let index = sortedKeys.indexOf('province');
    if (index !== -1) {
      sortedKeys[index] = 'provinceCity';
    }

    const _params = {
      pageNum: pageIndex,
      pageSize: pageSize,
      ...queryParams.current,
      exportFieldList: JSON.stringify(sortedKeys),
    };
    const params = formatApiParams(_params);
    setExportLoading(true);
    const res = await exportCallList(params);
    if (res?.success) {
      message.success('导出成功，请前往【文件导出管理】页面进行下载');
    }
    setExportLoading(false);
  };

  // 展开
  const handleOpen = useCallback(() => {
    handleHeightEvent();
  }, []);

  useEffect(() => {
    if (!callResultList?.length) handleCallResultList();
    handleHeightEvent();
    setPageIndex(1);
    handlerGetLists({
      pageNum: 1,
    });
    window.addEventListener('resize', handleHeightEvent);
    return () => window.removeEventListener('resize', handleHeightEvent);
  }, []);

  // 虚拟列表（防止多次render）
  const vComponents = useMemo(
    () =>
      VList({
        height: tableHeight,
        resetTopWhenDataChange: false,
      }),
    [tableHeight],
  );

  const virtualTable = useMemo(() => {
    return (
      // <Table
      //   style={{ width: '100%' }}
      //   columns={column}
      //   dataSource={tableData}
      //   loading={isLoading}
      //   rowKey={() => uuidv1()}
      //   scroll={{ y: tableHeight, x: 1200 }}
      //   pagination={false}
      //   components={vComponents}
      // />
      <ProTable
        columns={column}
        dataSource={tableData}
        ErrorBoundary={false}
        rowKey={() => uuidv1()}
        search={false}
        components={vComponents}
        pagination={false}
        loading={isLoading}
        scroll={{ y: tableHeight, x: 1000 }}
        options={{
          fullScreen: false,
          reload: false,
          density: false,
          setting: true,
        }}
        columnsState={{
          persistenceKey: persistenceKey,
          persistenceType: 'localStorage',
        }}
      />
    );
  }, [tableData, isLoading, tableHeight, column]);

  return (
    <>
      <div className={styles.callContent} id="callWrap">
        <div className={styles.search} id="callSearchWrap">
          <CallSearch
            onSearch={handleSearchClick}
            onReset={handleReset}
            onOpen={handleOpen}
            onExport={handleExport}
            exportLoading={exportLoading}
          />
        </div>
        <div
          // style={{ minWidth: 1200 }}
          className={
            isOverflow
              ? styles.tableContent
              : `${styles.tableContent} ${styles.hidden}`
          }
          id="callTableWrap"
        >
          {virtualTable}
        </div>
        <div className={styles.subPagination} id="callPaginationWrap">
          <Pagination
            current={pageIndex}
            showSizeChanger={true}
            pageSize={pageSize}
            total={total}
            showTotal={(total) => `总共 ${total} 条`}
            onChange={onChange}
            pageSizeOptions={[50, 100, 300, 500]}
          />
        </div>
      </div>
      {/* 语音播放器Modal */}
      <PlayAudio
        visible={showPlayModel}
        url={curInfo?.recordFile}
        cancel={useCallback(() => {
          setShowPlayModel(false);
          setCurInfo(undefined);
        }, [])}
      />
      {/* 通话详情Drawer */}
      <CallDetail
        open={showTextModel}
        curInfo={curTextInfo}
        callData={useMemo(
          () => tableData.filter((item) => item.durationCall),
          [tableData],
        )}
        onCancel={useCallback(() => {
          setCurTextInfo(undefined);
          setShowTextModel(false);
        }, [tableData, showTextModel, curTextInfo])}
      />

      {/* 黑名单组Modal */}
      <BlackGroupModal
        open={blackGroupOpen}
        onOk={handleBlackComplaint}
        onCancel={() => {
          setCurrentRecord(undefined);
          setBlackGroupOpen(false);
        }}
      />
      {/* 黑名单组取消Modal */}
      <CancelBlackModal
        record={currentRecord}
        open={cancelBlackOpen}
        onOk={() => handleComplaint(currentRecord, false)}
        onCancel={() => setCancelBlackOpen(false)}
      />
    </>
  );
};
export default CallList;
