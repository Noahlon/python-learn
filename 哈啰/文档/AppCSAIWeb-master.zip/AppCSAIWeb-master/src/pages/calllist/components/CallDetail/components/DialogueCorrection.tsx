import React, { useEffect } from 'react';
import { Modal, Input, message, Row, Col, Radio, Form, Checkbox } from 'antd';
import { correction } from '@/api/call';

interface props {
  open?: boolean;
  onOk: (record?) => void;
  onCancel: () => void;
  sessionId?: string;
  correctionInfo?: any;
}

const genderOptions = [
  { label: '男', value: 'M' },
  { label: '女', value: 'W' },
  { label: '未知', value: 'U' },
];

const accuracyOptions = [
  { label: '是', value: 'Y' },
  { label: '否', value: 'N' },
];

const accuracyListOptions = [
  { label: '意图识别问题', value: '1' },
  { label: '意向分类不准', value: '2' },
  { label: '智能助理', value: '3' },
  { label: '环境背景音', value: '4' },
];

const layout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 22 },
};

const DialogueCorrection: React.FC<props> = ({
  open,
  onOk,
  onCancel,
  sessionId,
  correctionInfo,
}) => {
  const [form] = Form.useForm();
  const handleOk = async () => {
    const res = await form.validateFields();
    correction({
      sessionId,
      ...res,
    }).then((res) => {
      if (res.code === '0') {
        message.success('操作成功');
        onOk?.();
      }
    });
  };

  const accuracyChange = () => {
    form.setFieldsValue({ accuracyReasonList: [] });
  };

  useEffect(() => {
    if (open) {
      form.setFieldsValue({ ...correctionInfo });
    }
  }, [open]);

  return (
    <Modal
      open={open}
      title="话单标记"
      width={'600px'}
      onOk={handleOk}
      onCancel={onCancel}
      destroyOnClose={true}
    >
      <Form {...layout} form={form}>
        <Form.Item
          name="accuracy"
          rules={[{ required: true, message: '请选择是否准确' }]}
          label="是否准确"
        >
          <Radio.Group onChange={accuracyChange}>
            {accuracyOptions?.map((item) => {
              return (
                <Radio key={item.value} value={item.value}>
                  {item.label}
                </Radio>
              );
            })}
          </Radio.Group>
        </Form.Item>
        <Form.Item
          noStyle
          shouldUpdate={(prev, cur) => prev.accuracy !== cur.accuracy}
        >
          {({ getFieldValue }) => {
            const accuracy = getFieldValue('accuracy');
            return accuracy === 'N' ? (
              <Form.Item
                name="accuracyReasonList"
                style={{ paddingLeft: '92px' }}
              >
                <Checkbox.Group>
                  <Row wrap={true} gutter={8}>
                    {accuracyListOptions?.map((item) => {
                      return (
                        <Col span={8} key={item.value}>
                          <Checkbox
                            style={{ marginBottom: 8 }}
                            value={item.value}
                          >
                            {item.label}
                          </Checkbox>
                        </Col>
                      );
                    })}
                  </Row>
                </Checkbox.Group>
              </Form.Item>
            ) : null;
          }}
        </Form.Item>
        <Form.Item
          name="gender"
          label="性别"
          rules={[{ required: true, message: '请选择性别' }]}
        >
          <Radio.Group>
            {genderOptions?.map((item) => {
              return (
                <Radio key={item.value} value={item.value}>
                  {item.label}
                </Radio>
              );
            })}
          </Radio.Group>
        </Form.Item>
        <Form.Item name="remark" style={{ paddingLeft: '55px' }}>
          <Input.TextArea
            placeholder="请输入其他描述，最多50字"
            allowClear
            maxLength={50}
            showCount
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default DialogueCorrection;
