//返回值
export const formList = [
  {
    type: '1',
    typeName: '是否准确',
    typeSort: 1,
    childList: [
      {
        itemCode: 'Y', //AccuracyEnum枚举key
        itemName: '准确',
        itemSort: 1,
      },
      {
        itemCode: 'N', //AccuracyEnum枚举key
        itemName: '不准确',
        itemSort: 2,
        childList: [
          {
            itemCode: '1', //AccuracyReasonEnum枚举key
            itemName: '意图识别问题',
            itemSort: 1,
          },
          {
            itemCode: '2', //AccuracyReasonEnum枚举key
            itemName: '意向分类不准',
            itemSort: 2,
          },
          {
            itemCode: '3', //AccuracyReasonEnum枚举key
            itemName: '智能助理',
            itemSort: 3,
          },
          {
            itemCode: '4', //AccuracyReasonEnum枚举key
            itemName: '环境背景音',
            itemSort: 4,
          },
        ],
      },
    ],
  },
  {
    type: '2',
    typeName: '性别',
    typeSort: 2,
    childList: [
      {
        itemCode: 'M', //GenderEnum枚举key
        itemName: '男',
        itemSort: 1,
      },
      {
        itemCode: 'W', //GenderEnum枚举key
        itemName: '女',
        itemSort: 2,
      },
      {
        itemCode: 'U', //GenderEnum枚举key
        itemName: '未知',
        itemSort: 3,
      },
    ],
  },
];
