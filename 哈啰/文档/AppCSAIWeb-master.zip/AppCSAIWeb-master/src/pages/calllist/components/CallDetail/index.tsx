import React, {
  memo,
  useCallback,
  useEffect,
  useRef,
  useState,
  Fragment,
} from 'react';
import {
  Button,
  Drawer,
  message,
  Popover,
  Radio,
  Space,
  Spin,
  Tag,
  Tooltip,
  Modal,
} from 'antd';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import AudioPlayer from 'react-h5-audio-player';
import 'react-h5-audio-player/lib/styles.css';
import ReactECharts from 'echarts-for-react';
import {
  CopyOutlined,
  VerticalLeftOutlined,
  VerticalRightOutlined,
  InfoCircleOutlined,
} from '@ant-design/icons';
import ChatDetail from '@/components/ChatDetail';
import {
  getCallDetail,
  ICallDetail,
  ICallList,
  phraseCorrection,
} from '@/api/call';
import { getRulesList, IRules } from '@/api/speechFlow';
import styles from './index.less';
import { httpReplace } from '@/utils';
import { useModel } from '@umijs/max';
import { hangPartyOption } from '@/pages/speech/config';
import { intentionTypeOption } from '../..';
import { useAccess } from '@umijs/max';
import WaveSurferComponent from './components/WaveSurferComponent';
import { downloadCustomNameFile } from '@/utils';
import DialogueCorrection from './components/DialogueCorrection';
interface IProps {
  open: boolean;
  onCancel?: () => void;
  curInfo?: ICallList;
  callData: ICallList[];
}

const CallDetail: React.FC<IProps> = ({
  open,
  onCancel,
  curInfo,
  callData,
}) => {
  const chartRef = useRef<any>(null);
  const access = useAccess();
  const refWrap = useRef<any>(null);
  const ref = useRef<any>(null);
  const { callResultList, handleCallResultList } = useModel('speech');
  const [rate, setRate] = useState(1);
  // 话单标记
  const [markOpen, setMarkOpen] = useState(false);

  // 聊天列表
  const [info, setInfo] = useState<ICallDetail>({});
  const [callDetail, setCallDetail] = useState(null);
  const [loading, setLoading] = useState(false);
  const [callIndex, setCallIndex] = useState(1);
  const [rulesList, setRulesList] = useState<IRules[]>([]);
  const [recordFile, setRecordFile] = useState('');
  const detailInfo = useRef<any>(null);
  const [isUpdateScroll, setUpdateScroll] = useState(true);
  const [option, setOption] = useState({})
  // 查看对话趋势
  const [trendOpen, setTrendOpen] = useState(false);
  // 获取数字大小
  const getCount = (start: number | undefined, end: number | undefined) => {
    if ((start || start === 0) && (end || end === 0)) {
      return (
        <>
          {start}-{end}
        </>
      );
    } else if (start || start === 0) {
      return <>&nbsp;&ge;&nbsp;{start}</>;
    } else if (end || end === 0) {
      return <>&nbsp;&le;&nbsp;{end}</>;
    }
    return '';
  };

  // 获取标签内容
  const getRulesContent = useCallback(
    (rule: IRules) => {
      return (
        <div>
          {rule?.purposeRule?.callConnectStatusList?.length > 0 && (
            <p>
              呼叫状态：
              {rule?.purposeRule?.callConnectStatusList?.map((it, index) => (
                <span key={it}>
                  {index !== 0 ? ' , ' : ' '}
                  {callResultList?.find((i) => i.value === it)?.label}
                </span>
              ))}
            </p>
          )}
          {(rule?.purposeRule?.hitQACorpus?.hitCorpuses?.length > 0 ||
            rule?.purposeRule?.hitQACorpus?.selectAll) && (
            <p>
              命中答疑库：&nbsp;
              {rule?.purposeRule?.hitQACorpus?.selectAll
                ? '全部'
                : rule?.purposeRule?.hitQACorpus?.hitCorpuses
                    ?.map((i) => `‘${i.corpusName}’`)
                    ?.join('、')}
              ；&nbsp;
              {getCount(
                rule?.purposeRule?.hitQACorpus?.num,
                rule?.purposeRule?.hitQACorpus?.max,
              )}
            </p>
          )}
          {(rule?.purposeRule?.globalPriority?.hitCorpuses?.length > 0 ||
            rule?.purposeRule?.globalPriority?.selectAll) && (
            <p>
              命中全局优先：&nbsp;
              {rule?.purposeRule?.globalPriority?.selectAll
                ? '全部'
                : rule?.purposeRule?.globalPriority?.hitCorpuses
                    ?.map((i) => `‘${i.corpusName}’`)
                    ?.join('、')}
              ；&nbsp;
              {getCount(
                rule?.purposeRule?.globalPriority?.num,
                rule?.purposeRule?.globalPriority?.max,
              )}
            </p>
          )}
          {rule?.purposeRule?.hitIntention?.hitIntentions?.length > 0 && (
            <p>
              命中意图：&nbsp;
              {rule?.purposeRule?.hitIntention?.hitIntentions
                ?.map((i) => `‘${i.name}’`)
                ?.join('、')}
              ；&nbsp;
              {getCount(
                rule?.purposeRule?.hitIntention?.num,
                rule?.purposeRule?.hitIntention?.max,
              )}
            </p>
          )}
          {rule?.purposeRule?.hitLabel?.labels?.length > 0 && (
            <p>
              命中标签：&nbsp;
              {rule?.purposeRule?.hitLabel?.labels
                ?.map((i) => `‘${i.labelName}’`)
                ?.join('、')}
              ；&nbsp;
              {getCount(
                rule?.purposeRule?.hitLabel?.num,
                rule?.purposeRule?.hitLabel?.max,
              )}
            </p>
          )}
          {!!rule?.purposeRule?.hitLabelGroup?.labelGroups?.length && (
            <p>
              标签组：&nbsp;
              {rule?.purposeRule?.hitLabelGroup?.labelGroups
                ?.map((i) => `‘${i.labelGroupName}’`)
                ?.join('、')}
              ；&nbsp;
              {getCount(
                rule?.purposeRule?.hitLabelGroup?.num,
                rule?.purposeRule?.hitLabelGroup?.max,
              )}
            </p>
          )}
          {!!rule?.purposeRule?.hitIntentionPath?.length && (
            <p>
              意图路径：&nbsp;
              {rule?.purposeRule?.hitIntentionPath
                ?.map((i) => `‘${i.name}’`)
                ?.join(' → ')}
              ；
            </p>
          )}
          {rule?.purposeRule?.userSayRegexpStr && (
            <p>用户说话：{rule?.purposeRule?.userSayRegexpStr}</p>
          )}
          {(rule?.purposeRule?.releaseInitiator ||
            rule?.purposeRule?.releaseInitiator === 0) && (
            <p>
              挂机方：
              {
                hangPartyOption.find(
                  (item) => item.value === rule?.purposeRule?.releaseInitiator,
                )?.label
              }
            </p>
          )}
          {rule?.purposeRule?.callDuration &&
            !!Object.keys(rule?.purposeRule?.callDuration)?.length && (
              <p>
                通话时长：
                {getCount(
                  rule?.purposeRule?.callDuration?.min,
                  rule?.purposeRule?.callDuration?.max,
                )}
              </p>
            )}
          {rule?.purposeRule?.dialogueRounds &&
            !!Object.keys(rule?.purposeRule?.dialogueRounds)?.length && (
              <p>
                对话次数：
                {getCount(
                  rule?.purposeRule?.dialogueRounds?.min,
                  rule?.purposeRule?.dialogueRounds?.max,
                )}
              </p>
            )}
          {rule?.purposeRule?.userSayTimes &&
            !!Object.keys(rule?.purposeRule?.userSayTimes)?.length && (
              <p>
                说话次数：
                {getCount(
                  rule?.purposeRule?.userSayTimes?.min,
                  rule?.purposeRule?.userSayTimes?.max,
                )}
              </p>
            )}
          {rule?.purposeRule?.affirmativeNumber &&
            !!Object.keys(rule?.purposeRule?.affirmativeNumber)?.length && (
              <p>
                肯定次数：
                {getCount(
                  rule?.purposeRule?.affirmativeNumber?.min,
                  rule?.purposeRule?.affirmativeNumber?.max,
                )}
              </p>
            )}
          {rule?.purposeRule?.negativeNumber &&
            !!Object.keys(rule?.purposeRule?.negativeNumber)?.length && (
              <p>
                否定次数：
                {getCount(
                  rule?.purposeRule?.negativeNumber?.min,
                  rule?.purposeRule?.negativeNumber?.max,
                )}
              </p>
            )}
          {rule?.purposeRule?.questioningNumber &&
            !!Object.keys(rule?.purposeRule?.questioningNumber)?.length && (
              <p>
                疑问次数：
                {getCount(
                  rule?.purposeRule?.questioningNumber?.min,
                  rule?.purposeRule?.questioningNumber?.max,
                )}
              </p>
            )}
          {rule?.purposeRule?.lastIntentionNegative !== undefined && (
            <p>
              最后是否否定：
              {rule?.purposeRule?.lastIntentionNegative ? '是' : '否'}
            </p>
          )}
          {rule?.purposeRule?.lastIntentionAffirmative !== undefined && (
            <p>
              最后是否肯定：
              {rule?.purposeRule?.lastIntentionAffirmative ? '是' : '否'}
            </p>
          )}
        </div>
      );
    },
    [callResultList],
  );

  // 播放速度
  const handlePlay = (e) => {
    e.target.playbackRate = rate;
  };

  // 获取通话详情
  const handleCallDetail = async () => {
    if (!callDetail) return;
    setLoading(true);
    const res = await getCallDetail({
      dialogueGuid: callDetail.guid,
      createTime: callDetail.createTime,
    });
    if (res.success) {
      setInfo(res.data);
      detailInfo.current = res?.data?.callDialogueResDTO || {};
      const url = httpReplace(res.data?.callDialogueResDTO?.recordFile);
      setRecordFile(url);
    }
    if (
      Array.isArray(res.data?.hitAdvancedRules) &&
      res.data?.hitAdvancedRules.length
    ) {
      const rulesRes = await getRulesList({ ids: res.data?.hitAdvancedRules });
      if (rulesRes.success && rulesRes.data?.length) {
        setRulesList(rulesRes.data);
      }
    } else {
      setRulesList([]);
    }

    setLoading(false);
  };

  // 上一个
  const handlePre = () => {
    if (loading) return;
    const zIndex = callIndex - 1;
    const callItem = callData[zIndex];
    if (callItem) {
      setCallDetail(callItem);
      setCallIndex(zIndex);
      setUpdateScroll(true);
    }
  };

  // 下一个
  const handleNext = () => {
    if (loading) return;
    const zIndex = callIndex + 1;
    const callItem = callData[zIndex];
    if (callItem) {
      setCallDetail(callItem);
      setCallIndex(zIndex);
      setUpdateScroll(true);
    }
  };
  const renderPropertyType = (propertyType) => {
    switch (propertyType) {
      case 1:
        return <Tag color="green">肯定</Tag>;
      case 2:
        return <Tag color="red">否定</Tag>;
      case 3:
        return <Tag color="orange">疑问</Tag>;
      case 4:
        return <Tag>其他</Tag>;
      default:
        return null;
    }
  };

  const getLabelContent = useCallback((text, type?: string) => {
    if (text) {
      try {
        let _array;
        if (type) {
          _array = text; // 1:肯定；2:否定；3:疑问；4：其他；
        } else {
          _array = JSON.parse(text);
        }
        if (Array.isArray(_array) && _array.length) {
          let labelItem;
          if (type) {
            labelItem = _array.map((item) =>
              renderPropertyType(item.propertyType),
            );
          } else {
            labelItem = _array.map((item, index) => (
              <span key={`${item}_${index}`} className={styles.labelItem}>
                {item}
              </span>
            ));
          }

          return (
            <Popover
              content={
                <div className={styles.labelPopContent}>{labelItem}</div>
              }
              trigger="hover"
              placement="topLeft"
              className={styles.labelPop}
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
            >
              <div className={styles.labelContent}>{labelItem}</div>
            </Popover>
          );
        }
        return '-';
      } catch (error) {}
    }
    return '-';
  }, []);

  useEffect(() => {
    handleCallDetail();
  }, [callDetail]);

  const handleHeightEvent = (e) => {
    switch (e.keyCode) {
      case 39:
        handleNext();
        break;
      case 37:
        handlePre();
        break;
    }
  };

  useEffect(() => {
    if (curInfo) {
      const position = callData.findIndex(
        (item) => item.guid === curInfo?.guid,
      );
      if (position > -1) {
        setCallDetail(curInfo);
        setCallIndex(position);
      } else {
        setCallDetail(callData[0]);
        setCallIndex(0);
      }
      if (!callResultList?.length) handleCallResultList();
    }
    return () => {
      setCallDetail(null);
    };
  }, [curInfo]);

  useEffect(() => {
    window.addEventListener('keyup', handleHeightEvent);
    return () => window.removeEventListener('keyup', handleHeightEvent);
  }, [curInfo, callIndex, loading]);

  const audioDownLoad = (url) => {
    try {
      const name = new Date().getTime().toString();
      let filename = url.split('?')[0];
      let parts = filename.split('.').pop();
      const filenames = name + '.' + parts;
      downloadCustomNameFile(url, filenames);
    } catch (error) {
      console.log(error);
    }
  };

  const handleClickChange = () => {
    setMarkOpen(true);
  };

  const handleCorrectCancel = () => {
    setMarkOpen(false);
  };

  const handleCorrectOk = () => {
    setMarkOpen(false);
    handleCallDetail();
  };
  // 单语句纠错
  const updateDetail = async (value: any, speakId: string) => {
    try {
      await phraseCorrection({
        sessionId: detailInfo?.current?.sessionId || '',
        speakId,
        ...value,
      });
      setUpdateScroll(false);
      handleCallDetail();
    } catch (error) {
    }
  };
  // 查看对话趋势
  const showTrend = (data?:any)=>{
    // 准备x轴数据
    const xData = data.map(item => item.speakTime);
    // 准备y轴数据
    const yData = data.map(item => item.value);
    // 准备label数据
    const labelData = data.map(item => `${item.intentionClassifyName}`);
    const intentionClassify = data.map(item => `${item.intentionClassify}`);
    const speakContent = data.map(item => `${item.speakContent}`);
   const option = {
      tooltip: {
        trigger: 'axis',
        formatter: function (params) {
          const param = params[0];
          const dataIndex = param.dataIndex;
          return `${param.name}<br/>意向分类: ${intentionClassify[dataIndex]} <br/>用户文本: ${speakContent[dataIndex]}`;
        }
      },
      grid: {
        left: '1%', // 为yAxis标签腾出更多空间
        right: '2%',
        bottom: '1%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: xData,
        axisLabel: {
          interval: 0,
          rotate: 0,
        }
      },
      yAxis: {
        type: 'value',
        interval: 1,
        width:'100',
        axisLabel: {
          fontSize: 12, // 调整字体大小以适应空间
          lineHeight: 16 // 调整行高使文本更易读
        }
      },
      dataZoom: [
        {
          show: true,
          realtime: true,
          start: 0,
          end: 50,
          xAxisIndex: [0, 1]
        },
        {
          type: 'inside',
          realtime: true,
          start: 0,
          end: 50,
          xAxisIndex: [0, 1]
        }
      ],
      series: [{
        data: yData,
        type: 'line',
        smooth: true,
        itemStyle: {
          color: '#327ab7',
        },
        lineStyle: {
          color: '#327ab7',
        },
        label: {
          show: true,
          position: 'top',
          formatter: function (params) {
            return labelData[params.dataIndex];
          }
        }
      }]
    };
    setOption(option);
    setTimeout(() => {
      setTrendOpen(true);
    },500)
    
  }
  return (
    <Drawer
      title="对话详情"
      width={1100}
      open={open}
      destroyOnClose
      bodyStyle={{ padding: '0 14px' }}
      onClose={() => {
        onCancel?.();
        // setChatList({});
      }}
      extra={
        <Space>
          <Button type="primary" ghost onClick={handleClickChange}>
            话单标记
          </Button>

          <span className={styles.count}>
            {callIndex + 1}/{callData.length}
          </span>
          <Button
            type="primary"
            icon={<VerticalRightOutlined />}
            disabled={!callIndex || loading}
            onClick={handlePre}
          >
            上一个
          </Button>
          <Button
            type="primary"
            icon={<VerticalLeftOutlined />}
            disabled={callIndex === callData.length - 1 || loading}
            onClick={handleNext}
          >
            下一个
          </Button>
        </Space>
      }
    >
      <Spin spinning={loading} wrapperClassName={styles.spinContent}>
        <div className={styles.callDetail}>
          <div className={styles.left}>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                被叫号码：
                <span className={styles.callNumber}>
                  <Popover
                    placement="topLeft"
                    content={info?.callDialogueResDTO?.calledNumber}
                  >
                    {info?.callDialogueResDTO?.calledNumber}
                  </Popover>
                </span>
                <CopyToClipboard
                  text={info?.callDialogueResDTO?.bizReqId}
                  onCopy={() => message.success('复制成功')}
                >
                  <CopyOutlined className={styles.copy} />
                </CopyToClipboard>
                <svg className={styles.bannerIcon} aria-hidden="true">
                  <use
                    xlinkHref={
                      info?.callDialogueResDTO?.isComplaint
                        ? '#icon-qizhi-'
                        : '#icon-qizhi'
                    }
                  ></use>
                </svg>
              </div>
            </div>

            <div className={styles.detailRow}>
              归属地：{info?.callDialogueResDTO?.province}/
              {info?.callDialogueResDTO?.city}
            </div>

            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                任务名称：{info?.callDialogueResDTO?.taskName}
              </div>
            </div>

            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                话术名称：
                <Popover
                  // placement="bottomLeft"
                  // trigger="click"
                  content={info?.callDialogueResDTO?.speechName}
                >
                  <div className={styles.value}>
                    {info?.callDialogueResDTO?.speechName}
                  </div>
                </Popover>
              </div>
            </div>

            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                识别类型：
                {
                  intentionTypeOption.find(
                    (item) =>
                      item.value ===
                      info?.callDialogueResDTO?.intentionObtainType,
                  )?.label
                }
              </div>
              <div className={styles.infoItem}>
                ASR服务商：{info?.callDialogueResDTO?.asrServer}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                TTS服务商：
                {info?.callDialogueResDTO?.ttsServerName
                  ? info?.callDialogueResDTO?.ttsServerName +
                    '/' +
                    info?.callDialogueResDTO?.ttsCodeName
                  : ''}
              </div>
            </div>

            <div className={styles.detailSubtitle}>外呼结果</div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                用户最终意向：{info?.callDialogueResDTO?.intentClassify || '-'}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                最终意向描述：
                {info?.callDialogueResDTO?.intentClassifyName || '-'}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                <span className={styles.text}>命中语料意图：</span>
                {getLabelContent(info?.callDialogueResDTO?.recognizedIntent)}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                <span className={styles.text}>命中意图属性：</span>
                {getLabelContent(info?.hitIntentionPropertySet, 'object')}
                {/* {getLabelContent([{propertyName:'肯定',propertyType:1},{propertyName:'否定',propertyType:2}],'object')} */}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                <span className={styles.text}>命中标签：</span>
                {getLabelContent(info?.callDialogueResDTO?.tags)}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                <span className={styles.text}>
                  通话时长（秒）：{info?.callDialogueResDTO?.durationCall}
                </span>
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                对话轮次：{info?.callDialogueResDTO?.speechCount}
              </div>
              <div className={styles.infoItem}>
                说话次数：{info?.callDialogueResDTO?.userSpeakCount}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                命中高级规则：
                {rulesList?.length > 0
                  ? rulesList?.map((item, index) => (
                      <Popover
                        key={item.id}
                        // placement="bottomLeft"
                        // trigger="click"
                        content={getRulesContent(item)}
                      >
                        <div className={styles.ruleItem}>
                          {item.ruleName || `规则${index + 1}`}; &nbsp;
                        </div>
                      </Popover>
                    ))
                  : '-'}
              </div>
            </div>

            <div className={styles.detailSubtitle}>线路信息</div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                供应线路：{info?.callDialogueResDTO?.suppliersLineName}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                主叫号码：{info?.callDialogueResDTO?.callingNumber}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                外显号码：{info?.callDialogueResDTO?.realCallingNumber}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                供应商名称：{info?.callDialogueResDTO?.suppliersName}
              </div>
            </div>
            {info?.callDialogueResDTO?.isTriggerTransfer && (
              <Fragment>
                <div className={styles.detailSubtitle}>座席信息</div>
                <div className={styles.detailRow}>
                  <div className={styles.infoItem}>
                    技能组：{info?.callDialogueResDTO?.skillGroupName || '-'}
                  </div>
                </div>
                <div className={styles.detailRow}>
                  <div className={styles.infoItem}>
                    座席姓名：{info?.callDialogueResDTO?.seatName}
                  </div>
                </div>
              </Fragment>
            )}

            <div className={styles.detailSubtitle}>
              模型识别信息
              <Tooltip
                placement="topLeft"
                title="大模型根据话单的对话数据识别结果"
              >
                <InfoCircleOutlined />
              </Tooltip>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                用户特征标签：
                {info?.modelIdentificationInformation?.userCharacteristicLabel || '-'}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                规则意向分类：
                {info?.modelIdentificationInformation?.ruleIntentionClassify || '-'}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                模型意向分类：
                {info?.modelIdentificationInformation?.modelIntentionClassify || '-'}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                意向分析原因：{info?.modelIdentificationInformation?.inferenceReason || '-'}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
              机器人回复建议：
                {info?.modelIdentificationInformation?.modelSuggestion &&
                info?.modelIdentificationInformation?.modelSuggestion?.length ? (
                  info?.modelIdentificationInformation?.modelSuggestion.join(',')
                ) : (
                  '-'
                )}
              </div>
            </div>
            <div className={styles.detailRow}>
              <div className={styles.infoItem}>
                对话意向趋势：
                {info?.modelIdentificationInformation?.intentionTrend &&
                info?.modelIdentificationInformation?.intentionTrend?.length ? (
                  <Button
                    type="link"
                    size="small"
                    onClick={() => {
                      showTrend(info?.modelIdentificationInformation?.intentionTrend)
                    }}
                  >
                    查看
                  </Button>
                ) : (
                  '-'
                )}
              </div>
            </div>
          </div>
          <div className={styles.right}>
            <div className={styles.chatWrap}>
              <ChatDetail
                info={info}
                isCalllist={true}
                isErrorCorrection={true}
                isUpdateScroll={isUpdateScroll}
                update={updateDetail}
              />
            </div>
            <div className={styles.bottom}>
              <Space className={styles.rate}>
                <Radio.Group
                  value={rate}
                  onChange={(e) => {
                    setRate(e.target.value);
                    const _audio = refWrap.current.querySelectorAll('audio');
                    _audio[0].playbackRate = e.target.value;
                  }}
                >
                  <Radio value={0.5}>0.5</Radio>
                  <Radio value={1}>1</Radio>
                  <Radio value={1.5}>1.5</Radio>
                  <Radio value={2}>2</Radio>
                  <Radio value={2.5}>2.5</Radio>
                </Radio.Group>
                {access?.authCodeList?.includes('Call-Voice-Download') && (
                  <Button
                    onClick={() => audioDownLoad(recordFile)}
                    disabled={!recordFile}
                    type="link"
                  >
                    下载
                  </Button>
                )}
              </Space>
              <div ref={refWrap}>
                <AudioPlayer
                  ref={ref}
                  src={recordFile}
                  autoPlay={false}
                  autoPlayAfterSrcChange={false}
                  onPlay={(e) => handlePlay(e)}
                  progressJumpStep={12 * 1000}
                  customAdditionalControls={[]}
                />
              </div>
              <div
                style={{
                  marginTop: '20px',
                  boxShadow: ' 0 0 3px 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <WaveSurferComponent audioUrl={recordFile} />
              </div>
              {/* <div
                style={{ height: '100px' }}
                id="wave-content"
                ref={containerRef}
              ></div> */}
            </div>
          </div>
        </div>
      </Spin>
      {markOpen && (
        <DialogueCorrection
          open={markOpen}
          onOk={handleCorrectOk}
          onCancel={handleCorrectCancel}
          sessionId={callDetail?.sessionId}
          correctionInfo={info?.callDialogueResDTO?.correctionInfo}
        ></DialogueCorrection>
      )}
      {trendOpen && (
        <Modal
          title="对话意向趋势"
          open={trendOpen}
          onCancel={() => {
            setTrendOpen(false);
          }}
          footer={null}
          width={'1200px'}
        >
          <div style={{ width: '100%', height: '400px' }}>
            <ReactECharts
              ref={chartRef}
              option={option}
              style={{ width: '100%', height: '100%' }}
            />
          </div>
        </Modal>
      )}
    </Drawer>
  );
};

export default memo(CallDetail);
