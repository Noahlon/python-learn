import { Button, Form, Modal, Select } from 'antd';
import React, { useEffect, useState } from 'react';
import { getBlackCard } from '@/api/blacklist';
import { ICallList, getComplainBlaGroup } from '@/api/call';

interface Prop {
  open: boolean;
  onOk: () => Promise<void>;
  onCancel: () => void;
  record: ICallList;
}

const BlackGroup: React.FC<Prop> = ({ open, onOk, onCancel, record }) => {
  const [form] = Form.useForm();
  const [blackOpts, setBlackOpts] = useState([]);
  const [cancelLoading, setCancelLoading] = useState(false);

  // fetch黑名单组
  const fetcBlackGroup = async () => {
    const res = await getBlackCard();
    setBlackOpts(res?.data || []);
  };

  // 预览黑名单组tooltip
  const fetchComplaintBlacklist = async () => {
    const res = await getComplainBlaGroup({ sessionId: record.sessionId });
    const _list = res?.data?.map((item) => item?.blacklistGroupId) || [];
    form.setFieldsValue({ groupIdList: _list });
  };

  const handleCancel = () => {
    form.resetFields();
    onCancel();
  };

  const handleOk = async () => {
    setCancelLoading(true);
    await onOk();
    setCancelLoading(false);
    handleCancel();
  };

  useEffect(() => {
    if (open && record) {
      fetchComplaintBlacklist();
      fetcBlackGroup();
    }
  }, [open, record]);

  return (
    <Modal
      open={open}
      onCancel={handleCancel}
      destroyOnClose
      title="编辑标记"
      width={600}
      footer={
        <Button loading={cancelLoading} onClick={handleOk}>
          取消标记
        </Button>
      }
    >
      <Form form={form}>
        <Form.Item label="黑名单组" name="groupIdList" required>
          <Select
            allowClear
            mode="multiple"
            disabled
            placeholder="请选择黑名单组"
            fieldNames={{ label: 'groupName', value: 'id' }}
            options={blackOpts}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default BlackGroup;
