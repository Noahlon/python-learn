import React, { FC, memo, useCallback, useEffect, useState } from 'react';
import {
  Form,
  Input,
  Cascader,
  Select,
  Button,
  Row,
  Col,
  DatePicker,
  Space,
  SelectProps,
} from 'antd';
import { useAccess, useModel } from '@umijs/max';
import { getZeroOrPositiveInt } from '@/utils';
import { timeRanges } from '@/config';
import { lineTypeOption } from '@/pages/lineSupplier';
import { releaseInitiatorOption, intentionTypeOption } from '../..';
import moment from 'moment';
import { getIntentionListAll } from '@/api/language';
import { getTenantList } from '@/api/tenant';
import { getRuleType, ruleTypeRes, blackListSupplierList } from '@/api/call';
import { DownloadOutlined } from '@ant-design/icons';
import { getProvinceCityList } from '@/api/common';
import styles from '../../index.less';

const { RangePicker } = DatePicker;
const { SHOW_CHILD } = Cascader;
const layout = {
  labelCol: { span: 9 },
  wrapperCol: { span: 18 },
};

// tts 服务器
const ttsServeOption = [
  { label: '百度', value: 'baimrcp' },
  { label: '阿里云', value: 'alimrcp' },
  { label: 'CosyVoice大模型', value: 'cosyvoice-v1' },
  { label: '讯飞超拟人TTS', value: 'xunfei' },
];

// asr 服务器
const asrServeOption = [
  { label: '百度', value: 'baimrcp' },
  { label: '阿里云', value: 'alimrcp' },
  { label: '讯飞', value: 'xunfei' },
];

// 是否触发短信，
const hitSmsOption = [
  { label: '未触发', value: 0 },
  { label: '触发', value: 1 },
];

// 是否标记，
const isComplaintOpts = [{ label: '是', value: true }];

// 外呼策略
export const callStrategyOption = [
  { label: '差异化', value: 0 },
  { label: '平台限制', value: 1 },
  { label: '差异化外呼&平台限频', value: 2 },
  { label: '无', value: 3 },
];

// 是否转接
export const callIsTransferOption = [
  { label: '否', value: false },
  { label: '是', value: true },
];

// 呼叫中心
export const ccServerOption = [
  { label: '中弘CC', value: 'zhongHongCC' },
  { label: '自研CC', value: 'independentCC' },
  { label: '中弘CC2.0', value: 'selfInnovateCCV2' },
];

// 任务类型
export const callTaskType = [
  { label: '手动下发任务', value: 0 },
  { label: 'AI外呼任务', value: 1 },
  { label: '预测外呼任务', value: 2 },
  { label: '人机协作任务', value: 3 },
];

// 转接成功
export const tansferSuccess = [
  { label: '是', value: true },
  { label: '否', value: false },
];

// 是否呼损
export const callLossOption = [
  { label: '是', value: true },
  { label: '否', value: false },
];
// 命中意图
export const intentListOption = [
  { label: '包含', value: 'recognizedIntentList' },
  { label: '不包含', value: 'excludeIntenList' },
];

interface IProps {
  onSearch?: (data: any) => void;
  onExport: (res) => void;
  exportLoading: boolean;
  onReset?: () => void;
  onOpen?: () => void;
}

const CallSearch: FC<IProps> = ({
  onSearch,
  onReset,
  onOpen,
  onExport,
  exportLoading,
}) => {
  const access = useAccess();
  const [form] = Form.useForm();
  const { callResultList } = useModel('speech');
  const [open, setOpen] = useState(false);
  const [cityOpt, setCityOpt] = useState([]);
  const [intentionClassifysList, setIntentionClassifysList] = useState([]);
  const [tenantOpts, setTenantOpts] = useState<SelectProps['options']>([]);
  const [featureRuleTypeOpts, setFeatureRuleTypeOpts] = useState<ruleTypeRes[]>(
    [],
  );
  // 三方黑名单供应商列表
  const [blackListSupplierData, setBlackListSupplierList] = useState<any[]>();

  const handleInputNumber = useCallback((type, value) => {
    getZeroOrPositiveInt(value).then((value) =>
      form.setFieldsValue({
        [type]: value,
      }),
    );
  }, []);

  // 获取省市数据
  const getCityOpt = useCallback(async () => {
    const opt = [];
    // todo 异步获取行政区数据
    const DISTRICTS: any = await getProvinceCityList();
    DISTRICTS.forEach((item) => {
      if (item['level'] === 1) {
        const citys = [];
        DISTRICTS.forEach((i) => {
          if (item.area_code === i.parent_code)
            citys.push({ value: i.area_name, label: i.area_name });
        });
        opt.push({
          value: item.area_code,
          label: item.area_name,
          children: citys,
        });
      }
    });
    setCityOpt(opt);
  }, []);

  // 获取租户
  const handleGetTenantList = async () => {
    const res = await getTenantList({ pageNum: 1, pageSize: 200 });
    if (res.success && res.data) {
      const opts = res.data?.map((item) => ({
        label: item.name,
        value: item.code,
      }));
      setTenantOpts(opts);
    }
  };

  // 获取意向分类
  const getIntentionOpt = useCallback(async () => {
    const res = await getIntentionListAll({
      pageSize: 200,
      pageNum: 1,
    });
    if (res) {
      setIntentionClassifysList(res);
    }
  }, []);

  // 重置
  const handleReset = () => {
    form.resetFields();
    form.setFieldsValue({
      intentListType: 'recognizedIntentList',
      createTime: [
        moment('00:00:00', 'HH:mm:ss'),
        moment('23:59:59', 'HH:mm:ss'),
      ],
    });
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    onSearch?.(res);
  };

  const getFeatureRuleTypeOpts = () => {
    getRuleType().then((res) => {
      if (res?.code === '0') {
        setFeatureRuleTypeOpts(res.data);
      }
    });
  };

  // 三方黑名单
  const handleBlackListSupplierList = async () => {
    const res = await blackListSupplierList();
    if (res?.success) {
      setBlackListSupplierList(res?.data);
    }
  };

  useEffect(() => {
    getFeatureRuleTypeOpts();
    handleGetTenantList();
    getCityOpt();
    getIntentionOpt();
    form.setFieldsValue({
      createTime: [
        moment('00:00:00', 'HH:mm:ss'),
        moment('23:59:59', 'HH:mm:ss'),
      ],
    });
    handleBlackListSupplierList();
  }, []);

  return (
    <Form form={form} {...layout}>
      <Row wrap={false}>
        <Col flex="auto" className={open ? null : styles.isHide}>
          <div className={styles.formItem}>
            <Form.Item name="taskName" label="任务名称">
              <Input
                placeholder="请输入任务名称"
                onChange={(e) =>
                  form.setFieldsValue({
                    ['taskName']: e.target.value.trim(),
                  })
                }
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="taskGuid" label="任务ID">
              <Input
                placeholder="请输入任务ID"
                onChange={(e) =>
                  form.setFieldsValue({
                    ['taskGuid']: e.target.value.trim(),
                  })
                }
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="createTime" label="创建时间">
              <RangePicker
                style={{ width: '100%' }}
                placeholder={['开始', '结束']}
                showTime={{
                    hideDisabledOptions: true,
                    defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                }}
                ranges={timeRanges}
                allowClear={false}
                // format="YYYY-MM-DD"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="carrier" label="运营商">
              <Input placeholder="请输入运营商" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item label="通话时长">
              <div className={styles.many}>
                <div className={styles.inputWrap}>
                  <Form.Item name="startDurationCall">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('startDurationCall', e.target.value)
                      }
                      placeholder="开始(秒)"
                    />
                  </Form.Item>
                </div>
                <span className={styles.division}>-</span>
                <div className={styles.inputWrap}>
                  <Form.Item name="endDurationCall">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('endDurationCall', e.target.value)
                      }
                      placeholder="结束(秒)"
                    />
                  </Form.Item>
                </div>
              </div>
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="speechName" label="话术名称">
              <Input placeholder="请输入话术名称" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="dialTime" label="拨号时间">
              <RangePicker
                style={{ width: '100%' }}
                placeholder={['开始', '结束']}
                showTime={{
                  hideDisabledOptions: true,
                  defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
              }}
                ranges={timeRanges}
                // format="YYYY-MM-DD"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="releaseInitiator" label="挂断方">
              <Select
                placeholder="请选择挂断方"
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
              >
                {releaseInitiatorOption.map((item) => (
                  <Select.Option key={item.label} value={item.value}>
                    {item.label}
                  </Select.Option>
                ))}
              </Select>
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item label="等待时长">
              <div className={styles.many}>
                <div className={styles.inputWrap}>
                  <Form.Item name="startDurationWait">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('startDurationWait', e.target.value)
                      }
                      placeholder="开始(秒)"
                    />
                  </Form.Item>
                </div>
                <span className={styles.division}>-</span>
                <div className={styles.inputWrap}>
                  <Form.Item name="endDurationWait">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('endDurationWait', e.target.value)
                      }
                      placeholder="结束(秒)"
                    />
                  </Form.Item>
                </div>
              </div>
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="callingNumber" label="主叫号码">
              <Input placeholder="请输入主叫号码" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="calloutResultList" label="外呼结果">
              <Select
                placeholder="请选择外呼结果"
                allowClear
                mode="multiple"
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                filterOption={(input, option) =>
                  (option?.label ?? '')
                    .toLowerCase()
                    .includes(input.toLowerCase())
                }
                options={callResultList}
                maxTagCount="responsive"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item label="响铃时长">
              <div className={styles.many}>
                <div className={styles.inputWrap}>
                  <Form.Item name="startDurationRing">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('startDurationRing', e.target.value)
                      }
                      placeholder="开始(秒)"
                    />
                  </Form.Item>
                </div>
                <span className={styles.division}>-</span>
                <div className={styles.inputWrap}>
                  <Form.Item name="endDurationRing">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('endDurationRing', e.target.value)
                      }
                      placeholder="结束(秒)"
                    />
                  </Form.Item>
                </div>
              </div>
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="calledNumber" label="被叫号码">
              <Input placeholder="请输入被叫号码" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="answerTime" label="接听时间">
              <RangePicker
                style={{ width: '100%' }}
                placeholder={['开始', '结束']}
                showTime={{
                  hideDisabledOptions: true,
                  defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
              }}
                ranges={timeRanges}
                // format="YYYY-MM-DD"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="hitSms" label="触发短信">
              <Select
                placeholder="请选择是否触发短信"
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
              >
                {hitSmsOption.map((item) => (
                  <Select.Option key={item.label} value={item.value}>
                    {item.label}
                  </Select.Option>
                ))}
              </Select>
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item label="说话次数">
              <div className={styles.many}>
                <div className={styles.inputWrap}>
                  <Form.Item name="startUserSpeakCount">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('startUserSpeakCount', e.target.value)
                      }
                      placeholder="开始"
                    />
                  </Form.Item>
                </div>
                <span className={styles.division}>-</span>
                <div className={styles.inputWrap}>
                  <Form.Item name="endUserSpeakCount">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('endUserSpeakCount', e.target.value)
                      }
                      placeholder="结束"
                    />
                  </Form.Item>
                </div>
              </div>
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="realCallingNumber" label="外显号码">
              <Input placeholder="请输入外显号码" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="hangupTime" label="挂断时间">
              <RangePicker
                style={{ width: '100%' }}
                placeholder={['开始', '结束']}
                showTime={{
                  hideDisabledOptions: true,
                  defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
              }}
                ranges={timeRanges}
                // format="YYYY-MM-DD"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="citys" label="省市">
              <Cascader
                showSearch
                options={cityOpt}
                placeholder="请选择省市"
                multiple
                maxTagCount="responsive"
                showCheckedStrategy={SHOW_CHILD}
                // fieldNames={{ label: 'classifyName', value: 'classifyId' }}
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item label="对话次数">
              <div className={styles.many}>
                <div className={styles.inputWrap}>
                  <Form.Item name="startSpeechCount">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('startSpeechCount', e.target.value)
                      }
                      placeholder="开始"
                    />
                  </Form.Item>
                </div>
                <span className={styles.division}>-</span>
                <div className={styles.inputWrap}>
                  <Form.Item name="endSpeechCount">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('endSpeechCount', e.target.value)
                      }
                      placeholder="结束"
                    />
                  </Form.Item>
                </div>
              </div>
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="tenantList" label="租户">
              <Select
                placeholder="请选择租户"
                allowClear
                mode="multiple"
                maxTagCount="responsive"
                filterOption={(input, option) =>
                  (option?.label as string)
                    .toLowerCase()
                    .includes(input.toLowerCase())
                }
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                options={tenantOpts}
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="intentClassifyList" label="用户最终意向">
              <Select
                placeholder="请选择用户最终意向"
                allowClear
                mode="multiple"
                maxTagCount="responsive"
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
              >
                {intentionClassifysList.map((item, index) => (
                  <Select.Option
                    key={`${item.classification}_${index}`}
                    value={item.classification}
                  >
                    {item.classification}
                  </Select.Option>
                ))}
              </Select>
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="tagsList" label="标签">
              <Select placeholder="请输入标签" mode="tags" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="intentionObtainType" label="意图识别类型">
              <Select
                placeholder="请选择意图识别类型"
                options={intentionTypeOption}
                allowClear
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="bizReqId" label="sessionId">
              <Input placeholder="请输入sessionId" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="suppliersName" label="供应商名称">
              <Input placeholder="请输入供应商名称" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="suppliersCode" label="供应商编号">
              <Input placeholder="请输入供应商编号" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="suppliersLineName" label="供应线路名称">
              <Input placeholder="请输入供应线路名称" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="suppliersLineCode" label="供应线路编号">
              <Input placeholder="请输入供应线路编号" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="lineTypes" label="线路类型">
              <Select
                placeholder="请选择线路类型"
                allowClear
                mode="multiple"
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                options={lineTypeOption}
                maxTagCount="responsive"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="isComplaint" label="是否标记">
              <Select
                placeholder="请选择标记"
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                options={isComplaintOpts}
                maxTagCount="responsive"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="callCenterIp" label="服务机器名称/IP">
              <Input placeholder="请输入服务机器名称" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="asrServer" label="ASR服务商">
              <Select
                options={asrServeOption}
                allowClear
                placeholder="请输入ASR服务商"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="ttsServer" label="TTS服务商">
              <Select
                options={ttsServeOption}
                allowClear
                placeholder="请输入TTS服务商"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="isHitBlackList" label="命中三方黑名单">
              <Select
                options={[
                  { label: '是', value: true },
                  { label: '否', value: false },
                ]}
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                placeholder="请选择"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="blacklistSupplier" label="黑名单供应商">
              <Select
                options={blackListSupplierData}
                fieldNames={{ label: 'desc', value: 'supplier' }}
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                placeholder="请选择黑名单供应商"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="userHitCorpus" label="命中语料">
              <Input placeholder="请输入语料" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="callStrategy" label="外呼策略">
              <Select
                options={callStrategyOption}
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                placeholder="请选择外呼策略"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item label="呼叫轮数">
              <div className={styles.many}>
                <div className={styles.inputWrap}>
                  <Form.Item name="startTryCallNum">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('startTryCallNum', e.target.value)
                      }
                      placeholder="开始"
                    />
                  </Form.Item>
                </div>
                <span className={styles.division}>-</span>
                <div className={styles.inputWrap}>
                  <Form.Item name="endTryCallNum">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('endTryCallNum', e.target.value)
                      }
                      placeholder="结束"
                    />
                  </Form.Item>
                </div>
              </div>
            </Form.Item>
          </div>

          <div className={styles.formItem}>
            <Form.Item name="isTriggerTransfer" label="触发转接">
              <Select
                options={callIsTransferOption}
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                placeholder="请选择是否触发转接"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="isTransfer" label="转接结果">
              <Select
                options={callIsTransferOption}
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                placeholder="请选择转接结果"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item label="AI对话时长">
              <div className={styles.many}>
                <div className={styles.inputWrap}>
                  <Form.Item name="startDurationCallAi">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('startDurationCallAi', e.target.value)
                      }
                      placeholder="开始(秒)"
                    />
                  </Form.Item>
                </div>
                <span className={styles.division}>-</span>
                <div className={styles.inputWrap}>
                  <Form.Item name="endDurationCallAi">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('endDurationCallAi', e.target.value)
                      }
                      placeholder="结束(秒)"
                    />
                  </Form.Item>
                </div>
              </div>
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item label="人工对话时长">
              <div className={styles.many}>
                <div className={styles.inputWrap}>
                  <Form.Item name="startDurationCallManual">
                    <Input
                      onChange={(e) =>
                        handleInputNumber(
                          'startDurationCallManual',
                          e.target.value,
                        )
                      }
                      placeholder="开始(秒)"
                    />
                  </Form.Item>
                </div>
                <span className={styles.division}>-</span>
                <div className={styles.inputWrap}>
                  <Form.Item name="endDurationCallManual">
                    <Input
                      onChange={(e) =>
                        handleInputNumber(
                          'endDurationCallManual',
                          e.target.value,
                        )
                      }
                      placeholder="结束(秒)"
                    />
                  </Form.Item>
                </div>
              </div>
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="featureLimitRuleName" label="标签限频命中规则">
              <Input placeholder="请输入标签限频命中规则" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="featureRuleType" label="标签限频事件源">
              <Select
                fieldNames={{
                  label: 'featureRuleTypeName',
                  value: 'featureRuleType',
                }}
                options={featureRuleTypeOpts}
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                placeholder="请选择标签限频事件源"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="ccServer" label="呼叫中心">
              <Select
                options={ccServerOption}
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                placeholder="请选择呼叫中心"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="projectName" label="项目名称">
              <Input placeholder="请输入项目名称" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="projectTaskTypeList" label="任务类型">
              <Select
                options={callTaskType}
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                filterOption={(input, option) =>
                  (option?.label as string)
                    .toLowerCase()
                    .includes(input.toLowerCase())
                }
                placeholder="请选择任务类型"
                mode="multiple"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="skillGroupName" label="技能组">
              <Input placeholder="请输入技能组" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="seatName" label="座席">
              <Input placeholder="请输入座席" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="transferSuccess" label="转接成功">
              <Select
                options={tansferSuccess}
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                placeholder="请选择是否转接成功"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="callLoss" label="是否呼损">
              <Select
                options={callLossOption}
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                placeholder="请选择是否是否呼损"
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item label="触发转接次数">
              <div className={styles.many}>
                <div className={styles.inputWrap}>
                  <Form.Item name="transferCountStart">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('transferCountStart', e.target.value)
                      }
                      placeholder="开始"
                    />
                  </Form.Item>
                </div>
                <span className={styles.division}>-</span>
                <div className={styles.inputWrap}>
                  <Form.Item name="transferCountEnd">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('transferCountEnd', e.target.value)
                      }
                      placeholder="结束"
                    />
                  </Form.Item>
                </div>
              </div>
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item label="振铃次数">
              <div className={styles.many}>
                <div className={styles.inputWrap}>
                  <Form.Item name="ringCountStart">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('ringCountStart', e.target.value)
                      }
                      placeholder="开始"
                    />
                  </Form.Item>
                </div>
                <span className={styles.division}>-</span>
                <div className={styles.inputWrap}>
                  <Form.Item name="ringCountEnd">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('ringCountEnd', e.target.value)
                      }
                      placeholder="结束"
                    />
                  </Form.Item>
                </div>
              </div>
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="phoneNumberMd5" label="MD5">
              <Input placeholder="请输入32位MD5" />
            </Form.Item>
          </div>
          {/* <div className={styles.formItem}>
            <Form.Item name="asrModel" label="ASR模型名称">
              <Input placeholder="请输入ASR模型名称" />
            </Form.Item>
          </div> */}
          <div className={styles.formItem}>
            <Form.Item label="命中意图">
              <Space.Compact block>
                <Form.Item
                  name="intentListType"
                  initialValue={'recognizedIntentList'}
                  className={styles.formItemSelect}
                >
                  <Select
                    options={intentListOption}
                    getPopupContainer={(triggerNode) =>
                      triggerNode.parentElement || document.body
                    }
                  >
                    <Select.Option value="recognizedIntentList">
                      包含
                    </Select.Option>
                    <Select.Option value="excludeIntenList">
                      不包含
                    </Select.Option>
                  </Select>
                </Form.Item>
                <Form.Item
                  name="intentListData"
                  className={styles.formItemSelect1}
                >
                  <Select placeholder="请输入命中意图" mode="tags" />
                </Form.Item>
              </Space.Compact>
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="blackGroupName" label="命中黑名单组名">
              <Input placeholder="请输入命中黑名单组名" />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="blackGroupId" label="命中黑名单组ID">
              <Input
                placeholder="请输入命中黑名单组ID"
                onChange={(e) =>
                  form.setFieldsValue({
                    ['blackGroupId']: e.target.value.trim(),
                  })
                }
              />
            </Form.Item>
          </div>
          <div className={styles.formItem}>
            <Form.Item name="outIntentClassifyList" label="租户侧意向分类">
              <Select
                placeholder="请选择租户侧意向分类"
                allowClear
                mode="multiple"
                maxTagCount="responsive"
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
              >
                {intentionClassifysList.map((item, index) => (
                  <Select.Option
                    key={`${item.classification}_${index}`}
                    value={item.classification}
                  >
                    {item.classification}
                  </Select.Option>
                ))}
              </Select>
            </Form.Item>
          </div>
          {/**
           * todo 合并分支注意 start
          */}
          <div className={styles.formItem}>
            <Form.Item name="userCharacteristicLabel" label="用户特征标签">
              <Input placeholder="请输用户特征标签" />
            </Form.Item>
          </div>
          {/**
           * todo 合并分支注意 end
          */}
        </Col>
        <Col flex="none" style={{ marginLeft: '10px', position: 'relative' }}>
          <Space style={{ marginTop: '5px' }}>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            {access?.authCodeList?.includes('CallList-Download') && (
              <Button
                icon={<DownloadOutlined />}
                onClick={onExport}
                loading={exportLoading}
              >
                导出
              </Button>
            )}
            <Button onClick={handleReset}>重置</Button>
            <Button
              type="link"
              size="small"
              onClick={() => {
                setOpen(!open);
                onOpen?.();
              }}
            >
              {open ? '收起' : '展开'}
            </Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default memo(CallSearch);
