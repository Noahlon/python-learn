import React, { useEffect, useRef, useState } from 'react';
import WaveSurfer from 'wavesurfer.js';
import { Radio } from 'antd';
import { PauseCircleFilled, PlayCircleFilled } from '@ant-design/icons';
const WaveSurferComponent = ({ audioUrl }) => {
  const waveRef = useRef(null);
  const wavesurferRef = useRef(null);
  const currentAudioBuffer = useRef(null);
  const leftAudioBuffer = useRef(null);
  const nullAudioBuffer = useRef(null);
  const rightAudioBuffer = useRef(null);
  const [channel, setChannel] = useState(3);
  const [plainOptions, setplainOptions] = useState([]);
  const [isPlaying, setPlaying] = useState(false);

  useEffect(() => {
    if (waveRef.current && audioUrl) {
      wavesurferRef.current = WaveSurfer.create({
        container: waveRef.current,
        mediaControls: true,
        splitChannels: true,
        height: 50,
        backend: 'WebAudio',
      });

      wavesurferRef.current.load(audioUrl);

      wavesurferRef.current.on('ready', () => {
        currentAudioBuffer.current =
          wavesurferRef.current.backend && wavesurferRef.current.backend.buffer;
        setPlaying(false);
        if (
          currentAudioBuffer.current &&
          currentAudioBuffer.current.numberOfChannels === 2
        ) {
          setplainOptions([
            {
              label: '被叫方',
              value: 1,
            },
            {
              label: '呼叫方',
              value: 2,
            },
            {
              label: '全部',
              value: 3,
            },
          ]);
          nullAudioBuffer.current = new Float32Array(
            currentAudioBuffer.current.length,
          );
          leftAudioBuffer.current = new Float32Array(
            currentAudioBuffer.current.length,
          );
          rightAudioBuffer.current = new Float32Array(
            currentAudioBuffer.current.length,
          );
          currentAudioBuffer.current.copyFromChannel(
            leftAudioBuffer.current,
            0,
            0,
          );
          currentAudioBuffer.current.copyFromChannel(
            rightAudioBuffer.current,
            1,
            0,
          );
        } else {
          setplainOptions([]);
        }
      });

      wavesurferRef.current.on('click', () => {
        wavesurferRef.current.playPause();
      });

      // 清理函数，组件卸载时销毁wavesurfer实例
      return () => {
        wavesurferRef.current?.destroy();
        setPlaying(false);
        setChannel(3);
      };
    }
  }, [audioUrl]); // 依赖audioUrl，当audioUrl变化时重新加载音频

  useEffect(() => {
    if (
      wavesurferRef.current &&
      waveRef.current &&
      currentAudioBuffer.current?.numberOfChannels === 2
    ) {
      let left, right;
      if (channel === 2) {
        left = nullAudioBuffer.current;
        right = rightAudioBuffer.current;
      } else if (channel === 1) {
        left = leftAudioBuffer.current;
        right = nullAudioBuffer.current;
      } else if (channel === 3) {
        left = leftAudioBuffer.current;
        right = rightAudioBuffer.current;
      }
      currentAudioBuffer.current.copyToChannel(left, 0, 0);
      currentAudioBuffer.current.copyToChannel(right, 1, 0);
      wavesurferRef.current.drawBuffer();
      wavesurferRef.current?.seekTo(0);
      wavesurferRef.current.pause();
      setPlaying(false);
    }
  }, [channel]);

  const handleChannelChange = (event) => {
    setChannel(parseInt(event.target.value, 10));
  };

  const handleClick = () => {
    wavesurferRef?.current?.playPause();
    setPlaying(wavesurferRef?.current?.isPlaying());
  };

  return (
    <div>
      <div id="waveRef" ref={waveRef} style={{ width: '100%' }}></div>
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          paddingBottom: '5px',
          alignItems: 'center',
          width: '520px',
        }}
      >
        <Radio.Group
          options={plainOptions}
          onChange={handleChannelChange}
          value={channel}
        />
        <div onClick={handleClick} style={{ cursor: 'pointer' }}>
          {isPlaying ? (
            <PauseCircleFilled style={{ color: '#868686', fontSize: 33 }} />
          ) : (
            <PlayCircleFilled style={{ color: '#868686', fontSize: 33 }} />
          )}
        </div>
      </div>
    </div>
  );
};

export default WaveSurferComponent;
