import { Form, Modal, Select } from 'antd';
import React, { useEffect, useState } from 'react';
import { getBlackCard } from '@/api/blacklist';

interface Prop {
  open: boolean;
  onOk: (res) => Promise<void>;
  onCancel: () => void;
}

const BlackGroup: React.FC<Prop> = ({ open, onOk, onCancel }) => {
  const [form] = Form.useForm();
  const [searchValue, setSearchValue] = useState('');
  const [blackOpts, setBlackOpts] = useState([]);
  const [submitLoading, setSubmitLoading] = useState(false);

  // fetch黑名单组
  const fetcBlackGroup = async () => {
    const res = await getBlackCard();
    setBlackOpts(res?.data || []);
  };

  const handleCancel = () => {
    form.resetFields();
    onCancel();
  };

  const handleOk = async () => {
    const res = await form.validateFields();
    setSubmitLoading(true);
    await onOk(res);
    setSubmitLoading(false);
    handleCancel();
  };

  useEffect(() => {
    if (open) {
      fetcBlackGroup();
    } else {
      setSearchValue('');
    }
  }, [open]);

  return (
    <Modal
      title="请选择需要加入的黑名单组"
      open={open}
      onCancel={handleCancel}
      destroyOnClose
      width={600}
      onOk={handleOk}
      confirmLoading={submitLoading}
    >
      <Form form={form}>
        <Form.Item
          label="黑名单组"
          name="groupIdList"
          rules={[{ required: true, message: '请选择黑名单组' }]}
        >
          <Select
            allowClear
            showSearch
            mode="multiple"
            optionFilterProp="groupName"
            placeholder="请选择黑名单组"
            fieldNames={{ label: 'groupName', value: 'id' }}
            options={blackOpts}
            onSearch={setSearchValue}
            searchValue={searchValue}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default BlackGroup;
