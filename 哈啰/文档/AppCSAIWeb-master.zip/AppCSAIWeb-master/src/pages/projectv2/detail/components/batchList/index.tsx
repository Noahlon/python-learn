import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Button, Popover, Space } from 'antd';
import ResizeTable from '@/components/ResizeTable';
import type { ColumnsType } from 'antd/es/table';
import { rosterBatchPage, RosterBatchPageObj } from '@/api/projectv2/batch';
import {
  VerticalAlignBottomOutlined,
  RedoOutlined,
  PlusOutlined,
} from '@ant-design/icons';
import NameListUploadModal from './component/nameListUploadModal';
import { useLocation, useModel } from '@umijs/max';
import { parse } from 'query-string';

import styles from './index.less';
export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 100,
};
const BatchList: React.FC = () => {
  const { currentTab, projectDetail } = useModel('projectv2.model');
  const [tableData, setTableData] = useState([]);
  const [tableLoading, setTableLoading] = useState(false);
  const [tableTotal, setTableTotal] = useState<number>();
  const location = useLocation();
  const query = parse(location.search) as { guid: string };
  const [open, setOpen] = useState(false);
  // 搜索params
  const queryParams = useRef(DEFAULT_QUERY_PARAMS);
  // pagination
  const [pagination, setPagination] = useState({
    pageNum: 1,
    pageSize: 100,
  });
  const getRosterBatchPage = async () => {
    const params = {
      ...queryParams.current,
      projectGuid: query?.guid,
    };
    setTableLoading(true);
    const res = await rosterBatchPage(params);
    if (res?.data) {
      setTableData(res.data?.list);
      setTableTotal(res?.data?.totalRecord);
    }
    setTableLoading(false);
  };
  // 页面页数change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    queryParams.current.pageNum = pageNum;
    if (pageSize || pageSize === 0) {
      queryParams.current.pageSize = pageSize;
    }
    setPagination({ pageNum, pageSize });
    getRosterBatchPage();
  };
  const columns: ColumnsType<RosterBatchPageObj> = [
    {
      title: '批次名称',
      dataIndex: 'batchName',
      fixed: 'left',
      width: 200,
      render: (text) => {
        return (
          <Popover content={text} trigger="hover" placement="topLeft">
            <div className={styles.showText}>{text}</div>
          </Popover>
        );
      },
    },
    {
      title: '批次ID',
      dataIndex: 'batchGuid',
      width: 200,
    },
    {
      title: '名单数',
      dataIndex: 'nameListCount',
      width: 100,
    },
    {
      title: '新增名单数',
      dataIndex: 'newlyAddCount',
      width: 100,
    },
    {
      title: '重复名单数',
      dataIndex: 'repeatCount',
      width: 100,
    },
    {
      title: '失败名单数',
      dataIndex: 'failCount',
      width: 100,
    },
    {
      title: '创建人',
      dataIndex: 'createdByName',
      width: 100,
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      width: 200,
    },
    {
      title: '操作',
      fixed: 'right',
      width: 100,
      render: (_, record: RosterBatchPageObj) => {
        if (record?.operation === 0) {
          return (
            <Space className={styles.actionDefaultText}>
              <RedoOutlined />
              处理中
            </Space>
          );
        } else if (record?.operation === 1) {
          return (
            <Button type="link" href={record.failOssUrl}>
              <VerticalAlignBottomOutlined />
              失败数据
            </Button>
          );
        }
        return <div className={styles.actionDefaultText}>-</div>;
      },
    },
  ];
  // 取消上传
  const handleUploadCancen = useCallback(() => {
    setOpen(false);
  }, []);

  // 上传名单
  const handleUploadOk = useCallback(() => {
    handleUploadCancen();
    handlePageChange(1);
  }, []);
  useEffect(() => {
    if (currentTab === 'batchList') {
      getRosterBatchPage();
    }
  }, [currentTab]);
  return (
    <div className={styles.batchListBox}>
      {projectDetail?.projectStatus === 1 && (
        <div className={styles.improtBox}>
          <Button
            type="primary"
            onClick={() => setOpen(true)}
            icon={<PlusOutlined />}
          >
            添加名单
          </Button>
        </div>
      )}
      <ResizeTable
        columns={columns}
        dataSource={tableData}
        scroll={{ x: 'max-content' }}
        rowKey="batchGuid"
        containerId="batchListId"
        loading={tableLoading}
        pagination={{
          onChange: handlePageChange,
          defaultPageSize: 100,
          current: pagination.pageNum,
          pageSize: pagination.pageSize,
          total: tableTotal,
        }}
      />
      <NameListUploadModal
        open={open}
        onOk={handleUploadOk}
        projectGuid={query?.guid}
        onCancel={handleUploadCancen}
      />
    </div>
  );
};

export default BatchList;
