import { TaskDetailObj } from '@/api/projectv2/task';
import React from 'react';
import BaseDesc from './BaseDesc';
import BaseSeatRecord from './BaseSeatRecord';

interface Prop {
  currentTask: TaskDetailObj;
  handleOk: () => void;
}

const Manmachine: React.FC<Prop> = ({ currentTask, handleOk }) => {
  return (
    <div>
      <BaseDesc taskType={3} currentTask={currentTask} />
      <BaseSeatRecord
        taskType={3}
        currentTask={currentTask}
        handleOk={handleOk}
      />
    </div>
  );
};

export default Manmachine;
