import React, { memo, useEffect, useState } from 'react';
import TopInfo from './TopInfo';
import { Drawer, Spin, Tabs } from 'antd';
import { RosterDetail, getRosterDetail } from '@/api/projectv2/nameInfo';
import FollowRrcord from './FollowRrcord';
import ImportRrcord from './ImportRrcord';
import WanderRrcord from './WanderRrcord';

interface Prop {
  guid: string;
  projectGuid: string;
  onCancel: () => void;
}

const NameDetail: React.FC<Prop> = memo(({ guid, projectGuid, onCancel }) => {
  const [info, setInfo] = useState<RosterDetail>();
  const [infoLoading, setiInfoLoading] = useState(false);

  const fetchRosterDetail = async () => {
    setiInfoLoading(true);
    const params = {
      rosterGuid: guid,
      projectGuid,
    };
    const res = await getRosterDetail(params);
    if (res?.data) {
      setInfo(res.data);
    }
    setiInfoLoading(false);
  };

  useEffect(() => {
    if (!!guid) {
      fetchRosterDetail();
    }
    return () => {
      if (!!guid) {
        setInfo(undefined);
      }
    };
  }, [guid]);

  return (
    <Drawer
      title="详情"
      open={!!guid}
      onClose={onCancel}
      width={800}
      destroyOnClose
    >
      <Spin spinning={infoLoading}>
        <TopInfo data={info?.rosterInfoDTO} />
        <Tabs
          defaultActiveKey="1"
          destroyInactiveTabPane
          items={[
            {
              label: `跟进记录`,
              key: '1',
              children: <FollowRrcord data={info?.rosterInfoDTO} />,
            },
            {
              label: `流转记录`,
              key: '2',
              children: <WanderRrcord data={info?.rosterWanderInfoList} />,
            },
            {
              label: `上传记录`,
              key: '3',
              children: <ImportRrcord data={info?.rosterImportRecordDTOList} />,
            },
          ]}
        />
      </Spin>
    </Drawer>
  );
});

export default NameDetail;
