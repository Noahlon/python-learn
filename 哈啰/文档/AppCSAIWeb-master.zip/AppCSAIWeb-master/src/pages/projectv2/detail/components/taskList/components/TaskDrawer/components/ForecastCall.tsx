import { TaskDetailObj } from '@/api/projectv2/task';
import React from 'react';
import BaseDesc from './BaseDesc';
import BaseSeatRecord from './BaseSeatRecord';

interface Prop {
  currentTask: TaskDetailObj;
  handleOk: () => void;
}

const ForecastCall: React.FC<Prop> = ({ currentTask, handleOk }) => {
  return (
    <div>
      <BaseDesc taskType={2} currentTask={currentTask} />
      <BaseSeatRecord
        taskType={2}
        currentTask={currentTask}
        handleOk={handleOk}
      />
    </div>
  );
};

export default ForecastCall;
