import { RosterDetail } from '@/api/projectv2/nameInfo';
import { Col, Descriptions, Row, Tag, Typography } from 'antd';
import React from 'react';
import { formatEmptyData, formatStringEllipsis } from '@/utils/format';
import styles from './index.less';

interface Prop {
  data: RosterDetail['rosterInfoDTO'];
}

const { Item } = Descriptions;
const { Paragraph } = Typography;

const TopInfo: React.FC<Prop> = ({ data }) => {
  return (
    <Row className={styles.topInfo} gutter={16}>
      <Col span={12}>
        <div className={styles.leftDesc}>
          <Descriptions title={data?.phoneNum} column={1}>
            <Item label="项目名称">{data?.projectName}</Item>
            <Item label="接通/外呼次数">
              {data?.throughCount}{' '}
              {data?.calloutCount || data?.calloutCount === 0 ? '/' : '-'}{' '}
              {data?.calloutCount}
            </Item>
            <Item label="跟进节点">
              {formatEmptyData(data?.followNodeSetName)}
            </Item>
            <Item label="最近跟进结果">
              {data?.followStatusDesc ? (
                <Tag
                  className={styles.followTag}
                  color={
                    data?.followStatus === 0
                      ? 'processing'
                      : data?.followStatus === 1
                      ? 'success'
                      : 'error'
                  }
                >
                  {data?.followStatusDesc}
                </Tag>
              ) : (
                '-'
              )}
            </Item>
            <Item label="技能组">{formatEmptyData(data?.skillGroupName)}</Item>
            <Item label="座席">{formatEmptyData(data?.seatsName)}</Item>
            <Item label="添加时间">{formatEmptyData(data?.addTime)}</Item>
          </Descriptions>
        </div>
      </Col>
      <Col span={12}>
        <div className={styles.rightDesc}>
          <Descriptions title="名单信息" column={1}>
            <Item label="姓名">{data?.customerName ?? '-'}</Item>
            <Item label="公司名称">{data?.companyName ?? '-'}</Item>
            <Item label="user_guid">
              {data?.uploadGuid ? (
                <Paragraph copyable={{ text: data.uploadGuid }}>
                  {formatStringEllipsis(data.uploadGuid)}
                </Paragraph>
              ) : (
                '-'
              )}
            </Item>
            <Item label="user_newid">
              {data?.uploadNewid ? (
                <Paragraph copyable={{ text: data.uploadNewid }}>
                  {formatStringEllipsis(data.uploadNewid)}
                </Paragraph>
              ) : (
                '-'
              )}
            </Item>
            <Item label="md5">
              {data?.phoneNumMd5 ? (
                <Paragraph copyable={{ text: data.phoneNumMd5 }}>
                  {formatStringEllipsis(data.phoneNumMd5)}
                </Paragraph>
              ) : (
                '-'
              )}
            </Item>
          </Descriptions>
        </div>
      </Col>
    </Row>
  );
};

export default TopInfo;
