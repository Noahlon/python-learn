import { TaskDetailObj } from '@/api/projectv2/task';
import { toThousands } from '@/utils';
import { Descriptions, Table, Tag } from 'antd';
import React from 'react';
import { formatSeconds } from '@/utils/format';
import { TaskStatus, manualColumns } from '../../../config';
import styles from '../index.less';

interface Prop {
  currentTask: TaskDetailObj;
}

const Manual: React.FC<Prop> = ({ currentTask }) => {
  return (
    <div className={styles.manualBox}>
      <Descriptions column={1}>
        <Descriptions.Item label="任务类型">
          {currentTask?.taskTypeDesc}
        </Descriptions.Item>
        <Descriptions.Item label="任务状态">
          <Tag
            color={
              TaskStatus?.find((item) => item.value === currentTask?.status)
                ?.tagColor
            }
          >
            {currentTask?.statusDesc}
          </Tag>
        </Descriptions.Item>
        <Descriptions.Item label="执行时间">
          {currentTask.exeTime}
        </Descriptions.Item>
        <Descriptions.Item label="名单数">
          {toThousands(currentTask.telephoneCount)}
        </Descriptions.Item>
        <Descriptions.Item label="自动提交时间">
          {formatSeconds(
            Number(
              JSON.parse(currentTask.ext || '{}')?.followupRecordAutoCommitTime,
            ),
          )}
        </Descriptions.Item>
      </Descriptions>
      <div className={styles.title}>下发明细</div>
      <Table
        size="small"
        columns={manualColumns}
        dataSource={currentTask?.skillGroupList}
        rowKey="skillGroupGuid"
        scroll={{ x: 'max-content', y: 'calc(100% - 110px)' }}
        pagination={false}
        className={styles.tableBox}
        summary={(pageData) => {
          let totalSeats = 0;
          let totalLists = 0;
          pageData.forEach(({ seatCount, rosterCount }) => {
            totalSeats += Number(seatCount);
            totalLists += Number(rosterCount);
          });

          return totalSeats > 0 ? (
            <Table.Summary fixed>
              <Table.Summary.Row>
                <Table.Summary.Cell index={0}>总计</Table.Summary.Cell>
                <Table.Summary.Cell index={1} />
                <Table.Summary.Cell index={2}>
                  <span>{totalSeats}</span>
                </Table.Summary.Cell>
                <Table.Summary.Cell index={3}>
                  <span>{totalLists}</span>
                </Table.Summary.Cell>
              </Table.Summary.Row>
            </Table.Summary>
          ) : null;
        }}
      />
    </div>
  );
};

export default Manual;
