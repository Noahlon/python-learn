import { FollowRecordRes } from '@/api/projectv2/nameInfo';
import { LAYOUTLABELSMALL } from '@/constants/processconfig';
import FormRecord from '@/pages/followConfig/component/PreviewModal/FormRecord';
import { disabledTime } from '@/utils/date';
import { DatePicker, Divider, Form, Input, Modal, Radio } from 'antd';
import moment from 'moment';
import React, { useEffect } from 'react';

interface Prop {
  curFormData: FollowRecordRes['data'][0];
  onCancel: () => void;
}

const followupOpts = [
  {
    value: 0,
    label: '跟进中',
  },
  {
    value: 1,
    label: '跟进成功',
  },
  {
    value: 2,
    label: '跟进失败',
  },
];

const FollowModal: React.FC<Prop> = ({ curFormData, onCancel }) => {
  const [form] = Form.useForm();

  useEffect(() => {
    const { followupResult, nextFollowTime, remark, followupNodeName } =
      curFormData || {};
    const formObj = {
      followupResult,
      nextFollowTime,
      remark,
      followupNodeName,
    };
    form.setFieldsValue(formObj);
  }, [curFormData?.formFields]);

  return (
    <Modal
      title="查看"
      width={650}
      open={!!curFormData}
      forceRender
      destroyOnClose
      onCancel={onCancel}
      footer={null}
    >
      <Form form={form} layout="horizontal" {...LAYOUTLABELSMALL}>
        <Form.Item label="跟进结果" name="followupResult" required>
          <Radio.Group
            options={followupOpts}
            optionType="button"
            buttonStyle="solid"
          />
        </Form.Item>
        <Form.Item
          label="下次跟进时间"
          name="nextFollowTime"
          getValueFromEvent={(...[, dateString]) => dateString}
          getValueProps={(value) => ({
            value: value ? moment(value) : undefined,
          })}
        >
          <DatePicker
            showTime
            format="YYYY-MM-DD HH:mm:ss"
            disabledDate={(current) => {
              return current && current < moment().startOf('day');
            }}
            disabledTime={disabledTime}
            style={{ width: '100%' }}
          />
        </Form.Item>
        <Form.Item label="跟进备注" name="remark">
          <Input.TextArea rows={4} />
        </Form.Item>
        <Form.Item label="跟进节点" name="followupNodeName">
          <Input />
        </Form.Item>
      </Form>
      <Divider />
      <FormRecord currentFormData={curFormData?.formFields} />
    </Modal>
  );
};

export default FollowModal;
