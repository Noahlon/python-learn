import { TaskDetailObj } from '@/api/projectv2/task';
import React from 'react';
import BaseDesc from './BaseDesc';
import BaseRecord from './BaseRecord';
import { Divider } from 'antd';
import styles from '../index.less';

interface Prop {
  currentTask: TaskDetailObj;
}

const AIcall: React.FC<Prop> = ({ currentTask }) => {
  return (
    <div>
      <BaseDesc taskType={1} currentTask={currentTask} />
      <Divider />
      <p className={styles.title}>统计数据</p>
      <BaseRecord taskType={1} currentTask={currentTask} />
    </div>
  );
};

export default AIcall;
