import { EditOutlined, LeftOutlined, RightOutlined } from '@ant-design/icons';
import { Button, Descriptions, Popover, Space, Spin, Typography } from 'antd';
import React, { Fragment, memo, useCallback, useEffect, useState } from 'react';
import UpdateModal from '../../../list/components/UpdateModal';
import SmsPreView from '@/components/smsPreview';
import FollowFormPreview from '@/pages/followConfig/component/PreviewModal';
import { toThousands } from '@/utils';
import { useModel } from '@umijs/max';
import { formatStatus } from '@/pages/project/list/config';
import { SmsTemplateObj, querySmsTemplate } from '@/api/smsTemplate';
import { formatEmptyData } from '@/utils/format';
import styles from './index.less';

const { Item } = Descriptions;

const ProjectInfo: React.FC = memo(() => {
  const { fetchTenantOpts, tenantOpts } = useModel('common');
  const { projectDetail, detailLoading } = useModel('projectv2.model');
  // 收缩/展开
  const [isExpand, setIsExpand] = useState(true);
  // 编辑信息
  const [updateProjectOpen, setUpdateProjectOpen] = useState(false);
  // 预览表单
  const [previewFormGuid, setPreviewFormGuid] = useState('');

  //短信opts
  const [smsOpts, setSmsOpts] = useState<SmsTemplateObj[]>([]);

  // 获取短信opts
  const fetchSmsTemplate = async () => {
    const res = await querySmsTemplate({
      pageNum: 1,
      pageSize: 999,
      tenantList: [projectDetail?.tenantCode],
      bpoVersion: 2,
    });
    if (res?.data) {
      setSmsOpts(res.data?.list);
    }
  };

  // 预览表单
  const handlePreviewForm = () => {
    setPreviewFormGuid(projectDetail?.formGuid);
  };

  useEffect(() => {
    if (projectDetail?.guid) {
      fetchSmsTemplate();
      if (!tenantOpts?.length) {
        fetchTenantOpts(2);
      }
    }
  }, [projectDetail?.guid]);

  return (
    <>
      <div
        className={`${styles.projectInfoWrap} ${isExpand ? '' : styles.hide}`}
      >
        <div className={styles.content}>
          {isExpand ? (
            <Spin spinning={detailLoading}>
              <Descriptions
                title={
                  <div className={styles.titleBox}>
                    {projectDetail?.projectName}
                    <Button
                      icon={<EditOutlined />}
                      type="link"
                      onClick={() => setUpdateProjectOpen(true)}
                    />
                  </div>
                }
                className={styles.topInfo}
                column={1}
              >
                <Item label="项目状态">
                  <Typography.Text
                    type={
                      projectDetail?.projectStatus === 1
                        ? 'success'
                        : 'secondary'
                    }
                  >
                    {formatStatus(projectDetail?.projectStatus, 'label')}
                  </Typography.Text>
                </Item>
                <Item label="项目ID">{projectDetail?.guid}</Item>
                <Item label="租户">{projectDetail?.tenantName}</Item>
                <Item label="跟进表单">
                  <Space>
                    {projectDetail?.formName}
                    <a
                      onClick={handlePreviewForm}
                      className={styles.previewAnchor}
                    >
                      预览
                    </a>
                  </Space>
                </Item>
                <Item label="跟进节点">
                  <Popover
                    content={
                      <>
                        {projectDetail?.nodeList?.map((item) => (
                          <div key={item.nodeGuid}>{item.nodeName}</div>
                        ))}
                      </>
                    }
                    placement="rightTop"
                  >
                    <a>{projectDetail?.followNodeSetName}</a>
                  </Popover>
                </Item>
                <Item label="线路名称">
                  {projectDetail?.callLineNameList?.join(' / ')}
                </Item>
                <Item label="营销短信">
                  {projectDetail?.smsInfoList?.length > 0 ? (
                    <div>
                      {projectDetail.smsInfoList.map((item, index) => (
                        <Fragment key={item.smsTemplateGuid}>
                          {index !== 0 && '、'}
                          <Popover
                            content={
                              <SmsPreView
                                curSms={smsOpts?.find(
                                  (it) => it?.id === item.smsTemplateGuid,
                                )}
                              />
                            }
                            placement="rightTop"
                            overlayClassName="smsConfigsPopover"
                          >
                            <a>{item.smsTemplateName}</a>
                          </Popover>
                        </Fragment>
                      ))}
                    </div>
                  ) : (
                    '-'
                  )}
                </Item>
                <Item label="预计结项日期">
                  {formatEmptyData(projectDetail?.closingDate)}
                </Item>
                <Item label="下发有效期（天）">
                  {formatEmptyData(projectDetail?.validityPeriod)}
                </Item>
                <Item label="项目描述">
                  {formatEmptyData(projectDetail?.projectDesc)}
                </Item>
                <Item label="复制明文号码">
                  {Number(projectDetail?.canCopyPhone) === 1
                    ? '可复制'
                    : '不可复制'}
                </Item>
                <Item label="创建人">{projectDetail?.createdByName}</Item>
                <Item label="创建时间">{projectDetail?.createTime}</Item>
              </Descriptions>
              <Descriptions title="执行情况" column={1}>
                <Item label="名单批次数">
                  {formatEmptyData(projectDetail?.batchCount)}
                </Item>
                <Item label="总名单数">
                  {toThousands(projectDetail?.totalRosterCount, true)}
                </Item>
                <Item label="执行中任务/总任务数">
                  {projectDetail?.runningTaskCount ||
                  projectDetail?.totalTaskCount
                    ? `${projectDetail?.runningTaskCount} / ${projectDetail?.totalTaskCount}`
                    : '-'}
                </Item>
              </Descriptions>
            </Spin>
          ) : (
            <>
              <h4>项目信息</h4>
              <div className={styles.titleBox}>
                {projectDetail?.projectName}
              </div>
            </>
          )}
        </div>
        <div className={styles.bottomBtn}>
          <Button
            icon={
              isExpand ? (
                <LeftOutlined className={styles.expand} />
              ) : (
                <RightOutlined className={styles.expand} />
              )
            }
            type="link"
            onClick={() => setIsExpand((status) => !status)}
          >
            {isExpand ? '收起' : '展开'}
          </Button>
        </div>
      </div>
      {/* 项目列表新增/编辑modal */}
      <UpdateModal
        open={updateProjectOpen}
        guid={projectDetail?.guid}
        onCancel={useCallback(() => setUpdateProjectOpen(false), [])}
      />
      {/* 预览表单 */}
      {previewFormGuid && (
        <FollowFormPreview
          formGuid={previewFormGuid}
          onClose={() => setPreviewFormGuid('')}
          source={2}
        />
      )}
    </>
  );
});

export default ProjectInfo;
