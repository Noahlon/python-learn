import React, { useEffect } from 'react';
import { summaryLeft, summaryright } from '../config';
import { toThousands } from '@/utils';
import { useLocation, useModel } from '@umijs/max';
import { parse } from 'query-string';
import styles from '../index.less';

const Summary: React.FC = () => {
  const { rosterSummary, fetchRosterSummary, currentTab, rosterWanderStatus } =
    useModel('projectv2.model');
  const location = useLocation();
  const query = parse(location.search) as { guid: string };

  useEffect(() => {
    if (currentTab === 'nameList') {
      fetchRosterSummary(query?.guid);
    }
  }, [currentTab, rosterWanderStatus]);

  return (
    <div className={styles.summaryWrap}>
      <div className={`${styles.summaryContent}`}>
        {summaryLeft.map((item) => (
          <div className={styles.summaryItem} key={item.value}>
            <div className={styles.summaryLabel}>{item.label}</div>
            <div className={styles.summaryValue}>
              {toThousands(rosterSummary?.[item?.value], true)}
            </div>
          </div>
        ))}
      </div>
      <div className={`${styles.summaryContent}`}>
        {summaryright.map((item) => (
          <div className={styles.summaryItem} key={item.value}>
            <div className={styles.summaryLabel}>{item.label}</div>
            <div className={styles.summaryValue}>
              {toThousands(rosterSummary?.[item?.value], true)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Summary;
