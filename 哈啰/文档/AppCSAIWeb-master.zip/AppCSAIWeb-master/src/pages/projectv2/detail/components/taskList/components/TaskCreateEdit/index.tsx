import {
  TaskDetailObj,
  haTaskCreate,
  haTaskUpdate,
} from '@/api/projectv2/task';
import {
  Modal,
  Form,
  message,
  Radio,
  Input,
  DatePicker,
  Select,
  Row,
  Col,
  Button,
  Checkbox,
  Popover,
  Collapse,
  InputNumber,
  Tooltip,
  Switch,
} from 'antd';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useModel } from '@umijs/max';
import moment from 'moment';
import { LAYOUTLABELFIVE } from '@/constants/processconfig';
import { TaskType } from '../../config';
import { disabledTime } from '@/utils/date';
import SkillGroupForm from '@/components/skillGroupForm';
import { queryAllSkillGroup } from '@/api/accountPermission/skillGroup2.0';
import { getTenantConcurrencytask, listTaskTemplate } from '@/api/taskCenter';
import { getSpeechOpts } from '@/api/speech';
import PhoneTime from '@/components/phoneTime';
import AutoRetryCall from '@/components/autoRetryCall';
import {
  CloseCircleOutlined,
  DownOutlined,
  InfoCircleOutlined,
  PlusOutlined,
  UpOutlined,
} from '@ant-design/icons';
import { querySmsTemplate } from '@/api/smsTemplate';
import SmsPreView from '@/components/smsPreview';
import AutoCommitTimeItem from '@/components/AutoCommitTimeItem';
import { getIntentionList } from '@/api/language';
import { taskTransferOpts } from '@/pages/taskCenter/config';
import { queryTenantLinegroupPage } from '@/api/tenantManage';

const timeRangeDefault = {
  callDuration: [{ startTime: '09:00', endTime: '20:00' }],
  timeRange: ['09:00', '20:00'],
};

interface IProps {
  onOk?: () => void;
  closeModal?: () => void;
  modalType: number; // 1编辑 2新增
  taskRecord?: TaskDetailObj;
}

const TaskCreateEdit: React.FC<IProps> = (props) => {
  const { modalType, closeModal, onOk, taskRecord } = props;

  const [form] = Form.useForm();
  //监听话术表单变化
  const faqGuidValue = Form.useWatch('faqGuid', form);
  // 获取项目详情
  const { projectDetail, autoAdjustConcurrencyTime } =
    useModel('projectv2.model');
  /**
   * 保存当前任务类型传入skillGroupForm组件
   **/
  const [curTaskType, setCurTaskType] = useState<number>(0);
  const [confirmLoading, setConfirmLoading] = useState(false);
  // 技能组opts
  const [skillGroupOpts, setSkillGroupOpts] = useState([]);
  // 任务模版opts
  const [taskTempOpts, setTaskTempOpts] = useState([]);
  // 话术opts
  const [faqGuidOpts, setFaqGuidList] = useState([]);
  const [currentFaqGuid, setCurrentFaqGuid] = useState<string>(undefined); //当前话术id
  // 意向opts
  const [intentionClassifysOpts, setIntentionClassifysOpts] = useState([]);
  // 短信opts
  const [smsOpts, setSmsOpts] = useState([]);
  // 外呼线路opts
  const [callLineOpts, setCallLineOpts] = useState([]);

  const [createType, setCreateType] = useState('custom'); // ai外呼创建方式
  const [concurrency, setConcurrencty] = useState<number>(null);
  const [multipleSmsLink, setMultipleSmsLink] = useState<number>(0); // 千人千链checkbox
  const [activeKey2, setActiveKey2] = useState<string[]>(['2']);
  const [activeKey3, setActiveKey3] = useState<string[]>(['3']);
  const [autoConcurrency, setAutoConcurrency] = useState<boolean>(false);
  // 短信气泡框显示
  const [smsPopoverOpen, setSmsPopoverOpen] = useState(false);
  const isHoverPopoverRef = useRef(false); // 是否hover在短信气泡框上
  const [currentSmsPopover, setCurrentSmsPopover] = useState(undefined);

  // fetch租户下的技能组opts
  const fetchAllSkillGroupOpts = async () => {
    const res = await queryAllSkillGroup({
      tenantCodeList: [projectDetail?.tenantCode],
    });
    setSkillGroupOpts(res?.data || []);
  };

  // fetch所有任务模版opts
  const fetchTaskTempOpts = async () => {
    const res = await listTaskTemplate({
      tenantList: [projectDetail?.tenantCode],
      bpoVersion: 2,
    });
    setTaskTempOpts(res || []);
  };

  // fetch话术opts
  const fetchFaqOpts = async (transfer: boolean) => {
    const params = {
      tenantCode: projectDetail?.tenantCode,
      transfer,
      bpoVersion: 2,
    };
    const res = await getSpeechOpts(params);
    setFaqGuidList(res?.data || []);
  };

  // fetch短信opts
  const fetchSmsOpts = async () => {
    const res = await querySmsTemplate({
      pageNum: 1,
      pageSize: 999,
      tenantList: [projectDetail?.tenantCode],
      bpoVersion: 2,
    });
    if (res?.data) {
      setSmsOpts(res.data?.list);
    }
  };

  // 获取意向分类opts
  // 对接电话邦，意向分类与话术强相关
  const fetchIntentionOpts = async (faqGuid: string) => {
    const speechGuid = faqGuidOpts?.find(
      (item) => item.guid === faqGuid,
    )?.speechGuid;
    const res = await getIntentionList({
      pageSize: 200,
      pageNum: 1,
      bpoVersion: 2,
      orderByName: true,
      speechGuid,
    });
    if (res) {
      setIntentionClassifysOpts(res);
    }
  };

  // 获取外呼线路下拉列表
  const fetchCallLineOpts = async () => {
    const res = await queryTenantLinegroupPage({
      tenantCode: projectDetail?.tenantCode,
      bpoVersion: 2,
    });

    if (res?.data) {
      setCallLineOpts(res.data);
    }
  };

  // 预计可用30秒下发数
  const getConcurrencys = async (id: string) => {
    const { data } = await getTenantConcurrencytask({
      code: projectDetail?.tenantCode,
      tenantLineGroupId: id,
      bpoVersion: 2,
    });
    setConcurrencty(data || 0);
  };

  const updataForm = async (val: any) => {
    setConfirmLoading(true);
    let param = {
      ...val,
      projectGuid: projectDetail?.guid,
      tenant: projectDetail?.tenantCode,
    };

    // AI外呼
    if ([1].includes(curTaskType)) {
      // 模版name
      const curTemp = taskTempOpts?.find(
        (item) => item?.guid === param.templateGuid,
      );
      param.templateName = curTemp?.name;
    }

    // AI外呼，人机协作【1,3】
    if ([1, 3].includes(curTaskType)) {
      // 千人千链
      param.multipleSmsLink = multipleSmsLink;
      // 话术
      const curFaq = faqGuidOpts?.find((item) => item?.guid === param.faqGuid);
      param.faqName = curFaq?.speechName;
      param.faqGuid = curFaq?.guid;
    }

    // AI外呼，预测外呼，人机协作【1,2,3】
    if ([1, 2, 3].includes(curTaskType)) {
      const callTimeRange = param?.exeCallTime?.timeRange;
      const callDuration = param?.exeCallTime?.callDuration;
      let autoRetryJson = {} as any;
      if (Array.isArray(param?.autoRetry)) {
        const autoRetry = param?.autoRetry!.filter((e) => e.checked);
        autoRetry.forEach((e) => {
          if (e.value === 'first') {
            autoRetryJson['first'] = e.num;
          }
          if (e.value === 'second') {
            autoRetryJson['second'] = e.num;
          }
          if (e.value === 'third') {
            autoRetryJson['third'] = e.num;
          }
        });
      } else {
        autoRetryJson = param?.autoRetry;
        if (autoRetryJson && Object.keys(autoRetryJson)?.length) {
        }
      }

      let smsConfigsList = [];
      if (param?.smsConfigs?.length) {
        smsConfigsList = param.smsConfigs.map((item) => ({
          classification: item.classification,
          smsTemplateId: item.smsTemplateId,
        }));
      }
      const json: any = { autoRetry: autoRetryJson, callDuration };
      if (smsConfigsList.length > 0) {
        json.smsConfigs = smsConfigsList;
      }
      let startTime = '';
      let endTime = '';
      if (callTimeRange?.length) {
        startTime = callTimeRange[0] || '';
        endTime = callTimeRange[1] || '';
      }

      delete param.autoRetry;
      delete param.smsConfigs;
      delete param.exeCallTime;
      param.exeStartTime = startTime;
      param.exeEndTime = endTime;
      param.ext = JSON.stringify(json);
    }

    // 手动下发，预测外呼，人机协作【0,2,3】
    if ([0, 2, 3].includes(curTaskType)) {
      let _ext = JSON.parse(param.ext || '{}');
      _ext.followupRecordAutoCommitTime = param.followupRecordAutoCommitTime;
      param.ext = JSON.stringify(_ext);
      delete param.followupRecordAutoCommitTime;
    }

    if (taskRecord?.templateGuid) {
      param.templateGuid = taskRecord?.templateGuid;
      param.templateName = taskRecord?.templateName;
    }

    //人机协作
    if ([3].includes(curTaskType)) {
      param.autoAdviceLoadCount = !!param?.autoAdviceLoadCount;
    }
    const action = modalType === 1 ? haTaskUpdate : haTaskCreate;
    // 编辑
    if (modalType === 1) {
      param.taskGuid = taskRecord?.taskGuid;
    }

    const res = await action({ ...param });
    if (res?.success) {
      message.success({
        content: '操作成功',
        className: 'customMessageTop',
      });
      onOk?.();
      closeModal();
    }

    setConfirmLoading(false);
  };

  // 提交
  const handlerOk = async () => {
    const res = await form.validateFields();

    if (!projectDetail?.guid) {
      message.error('项目异常，请刷新重试');
      return;
    }

    // 手动下发，预测外呼，人机协作 [0, 2, 3]
    if ([0, 2, 3].includes(curTaskType) && res?.skillGroupList?.length > 0) {
      res.skillGroupList = res?.skillGroupList.map((item) => {
        const obj: any = {
          skillGroupGuid: item.skillGroupGuid,
          skillGroupName: item.skillGroupName,
          callLossDistribute: item.callLossDistribute,
        };
        // 手动下发有名单数 && 编辑
        if (curTaskType === 0 && modalType === 1) {
          obj.rosterCount = item.rosterCount;
        }
        return obj;
      });
    }

    // 校验短链 Ai外呼，人机协作 [1, 3]
    if ([1, 3].includes(curTaskType)) {
      let checkChain = false;
      if (form.getFieldValue('smsConfigs')) {
        const smsconfigs = form
          .getFieldValue('smsConfigs')
          ?.map((item) => item['smsTemplateId']);
        checkChain = smsOpts.some(
          (item) => smsconfigs.includes(item.id) && item.chainId,
        );
      }

      if (checkChain && multipleSmsLink) {
        Modal.confirm({
          title: '关联的短信模版中插入的链接为短链，建议使用原始链接',
          content: '还要继续提交吗？',
          okText: '继续',
          cancelText: '取消',
          onOk() {
            updataForm(res);
          },
        });
        return;
      }
    }

    updataForm(res);
  };

  // 取消
  const handleCancel = () => {
    form.resetFields();
    closeModal?.();
  };

  // 任务类型change
  const handleChangeTaskType = (val: number) => {
    // 先reset表单
    const allField = Object.keys(form.getFieldsValue())?.filter(
      (key) => key !== 'taskType',
    );
    form.resetFields(allField);
    setCurTaskType(val);
    setConcurrencty(null); // 预计可用并发文案置空
  };

  // 设置默认的表单数据
  const setDefaultForm = () => {
    const data = {
      exeCallTime: { ...timeRangeDefault },
      autoRetry: {},
      thirdBlacklistIntercept: 0,
      featureIntercept: 0,
    };
    form.setFieldsValue(data);
  };

  // AI外呼创建方式change
  const handleChangeCreateType = (val: string) => {
    setCreateType(val);
    const allField = Object.keys(form.getFieldsValue())?.filter(
      (key) => !['taskType'].includes(key),
    );
    form.resetFields(allField);
    setDefaultForm();
    setConcurrencty(null); // 预计可用并发文案置空
  };

  // 设置表单数据
  const setTaskForm = (data) => {
    // 先reset表单
    const allField = Object.keys(form.getFieldsValue())?.filter(
      (key) => !['taskType', 'templateGuid'].includes(key),
    );

    form.resetFields(allField);

    let timeData = { ...timeRangeDefault };
    let ext: any = {};
    let _smsConfigs = [];
    try {
      ext = JSON.parse(data?.ext);
    } catch (error) {}
    if (ext) {
      if (ext?.callDuration) {
        const len = data?.exeStartTime?.length;
        const startTime = data?.exeStartTime?.slice(0, len - 3);
        const endTime = data?.exeEndTime?.slice(0, len - 3);
        timeData['callDuration'] = ext?.callDuration;
        timeData['timeRange'] = [startTime, endTime];
      }

      if (ext?.smsConfigs?.length) {
        _smsConfigs = ext.smsConfigs.map((item) => {
          return {
            classification: item.classification,
            smsTemplateId: item.smsTemplateId,
          };
        });
      }
    }

    if ([0, 1].includes(data?.multipleSmsLink)) {
      setMultipleSmsLink(data.multipleSmsLink);
    }

    if (data?.tenantLineGroupId) {
      getConcurrencys(data?.tenantLineGroupId);
    }

    // 拦截配置设置了就展开
    if (data.thirdBlacklistIntercept !== 0 || data.featureIntercept !== 0) {
      setActiveKey3(['3']);
    } else {
      setActiveKey3(undefined);
    }

    if ([1, 2, 3].includes(data?.taskType)) {
      data.exeCallTime = timeData;
      data.autoRetry = ext?.autoRetry || {};
      data.thirdBlacklistIntercept = data.thirdBlacklistIntercept ?? 0;
      data.featureIntercept = data.featureIntercept ?? 0;
    }

    // 手动下发，预测外呼，人机协作【0,2,3】
    if ([0, 2, 3].includes(data?.taskType)) {
      data.followupRecordAutoCommitTime = ext?.followupRecordAutoCommitTime;
    }

    if ([1, 3].includes(data?.taskType)) {
      data.smsConfigs = _smsConfigs;
    }

    // 判断如果没有话术就不显示
    const _formData = JSON.parse(JSON.stringify(data || {}));
    const isContainFaq = faqGuidOpts?.some(
      (item) => item?.guid === _formData?.faqGuid,
    );
    if (!isContainFaq) {
      // 话术没有找到该话术id，在useEffect等话术列表更新再试一次
      delete _formData?.faqGuid;
      setCurrentFaqGuid(data?.faqGuid);
    }
    setAutoConcurrency(data?.autoAdviceLoadCount);
    form.setFieldsValue(_formData);
  };

  //话术变化
  const handleFaqChange = () => {
    // const _smsConfigs = form.getFieldValue('smsConfigs');
    // const value = _smsConfigs?.map((_, index) => [
    //   'smsConfigs',
    //   index,
    //   'classification',
    // ]);
    // if (!!value?.length) form.resetFields(value);
  };

  useEffect(() => {
    if (faqGuidOpts?.length > 0 && currentFaqGuid) {
      const isContainFaq = faqGuidOpts?.some(
        (item) => item?.guid === currentFaqGuid,
      );
      if (isContainFaq) {
        form.setFieldsValue({ faqGuid: currentFaqGuid });
      } else {
        handleFaqChange();
      }
    }
  }, [faqGuidOpts, currentFaqGuid]);

  // 任务模版change
  const handleChangeTemplate = (val: string) => {
    const curTemp = taskTempOpts?.find((item) => item?.guid === val) || {};
    // 模版TaskType的替换成任务类型的TaskType
    curTemp.taskType = curTaskType;
    setTaskForm(curTemp);
  };

  // 鼠标移到挂机短信的某一行
  const handleSmsMouseEnter = (e, index: number) => {
    // 如果气泡框挡住了元素，就不显示气泡框
    if (isHoverPopoverRef.current) {
      isHoverPopoverRef.current = false;
      return;
    }

    // 判断鼠标是否在下拉框上（是就隐藏短信气泡框）
    const target = e.target?.getBoundingClientRect();
    const currentTarget = e.currentTarget?.getBoundingClientRect();
    if (Math.abs(target?.top - currentTarget?.top) > currentTarget?.height) {
      setSmsPopoverOpen(false);
      return;
    }

    const curSmsConfig = form.getFieldValue('smsConfigs')[index];
    const { classification, smsTemplateId } = curSmsConfig || {};
    const curSmsTemplate =
      smsOpts.find((item) => item.id === smsTemplateId) || {};

    curSmsTemplate.classification = classification;

    setCurrentSmsPopover(curSmsTemplate);
    setSmsPopoverOpen(true);
  };

  // 验证自动补呼
  const handleValidatorRetry = async (_, value) => {
    if (!value) return Promise.resolve();
    if (Array.isArray(value) && value.length) {
      for (let index = 0; index < value.length; index++) {
        if (value[index].checked) {
          if (
            !value[index].num ||
            Number(value[index].num) < 1 ||
            Number(value[index].num) > 600
          )
            return Promise.reject('时间间隔不能为空且在1-600分钟之间');
        }
      }
    } else {
      const nums = Object.values(value);
      for (let index = 0; index < nums.length; index++) {
        if (
          !nums[index] ||
          Number(nums[index]) < 1 ||
          Number(nums[index]) > 600
        )
          return Promise.reject('时间间隔不能为空且在1-600分钟之间');
      }
    }
    return Promise.resolve();
  };

  // 验证技能组
  const handleValidatorSkillGroup = async (_, value) => {
    // 手动下发 & 编辑时
    if (curTaskType === 0 && modalType === 1) {
      if (
        value?.some(
          (item) =>
            item?.rosterCount === undefined || item?.rosterCount === null,
        )
      ) {
        return Promise.reject(new Error('名单数不能为空'));
      }
      // 下发名单数不允许大于任务名单数
      const totalRosterCount = value?.reduce((total, item) => {
        return total + (item?.rosterCount || 0);
      }, 0);
      if (totalRosterCount > taskRecord?.telephoneCount) {
        return Promise.reject(new Error('下发名单数不允许大于任务名单数'));
      }
    }
    return Promise.resolve();
  };

  // 意向分类验证
  const handleValidatorClassification = async (_, value, index) => {
    const _list = form.getFieldValue('smsConfigs');
    if (_list?.length) {
      const flatList = _list.map((it) => it?.classification).filter(Boolean);
      const val = flatList[index];
      const isRepeat = flatList.indexOf(val) !== flatList.lastIndexOf(val);
      if (isRepeat) return Promise.reject('意向分类不能重复');
    }
    if (!value) return Promise.reject('请选择意向分类');
    return Promise.resolve();
  };

  // 验证期望并发
  const handleValidatorExpectCount = async (_, value) => {
    if (concurrency === null || concurrency === undefined) {
      return Promise.reject(new Error('请先选择外呼线路'));
    }

    if (value === null || value === undefined) {
      return Promise.reject(new Error('请输入期望并发'));
    }

    if (value > concurrency) {
      return Promise.reject(new Error('期望并发不能大于可用并发'));
    }

    return Promise.resolve();
  };

  // 意向分类change
  const handleClassificationChange = () => {
    const _smsConfigs = form.getFieldValue('smsConfigs');
    const value = _smsConfigs?.map((_, index) => [
      'smsConfigs',
      index,
      'classification',
    ]);
    if (!!value?.length) form.validateFields(value);
  };

  //切换话术时，更新意向分类
  useEffect(() => {
    if ([1, 3].includes(curTaskType)) {
      if (faqGuidValue) {
        fetchIntentionOpts(faqGuidValue);
      } else {
        handleFaqChange();
        setIntentionClassifysOpts([]);
      }
    }
  }, [faqGuidValue]);

  useEffect(() => {
    // 当concurrency变化时验证expectLoadCount字段
    form.validateFields(['expectLoadCount']);
  }, [concurrency]);

  useEffect(() => {
    // 设置默认表单(任务变化 和 编辑时)
    if ([1, 2, 3].includes(curTaskType) && modalType === 2) {
      setDefaultForm();
    }
    // fetch表单的options
    if ([0, 2, 3].includes(curTaskType)) {
      fetchAllSkillGroupOpts(); // 技能组
    }
    if ([1].includes(curTaskType)) {
      fetchTaskTempOpts(); // 任务模版
    }
    if ([1, 3].includes(curTaskType)) {
      setFaqGuidList([]); // 先把话术列表置为空
      fetchFaqOpts(curTaskType === 1 ? false : true); // 话术
      fetchSmsOpts(); // 短信模版
      // fetchIntentionOpts(); // 意向分类
    }
    if ([1, 2, 3].includes(curTaskType)) {
      fetchCallLineOpts(); // 外呼线路
    }
  }, [curTaskType]);

  useEffect(() => {
    // 编辑时
    if (modalType === 1) {
      if (!!taskRecord) {
        // 设置表单数据
        setTaskForm({ ...taskRecord });

        setCurTaskType(taskRecord?.taskType);
      }
    } else {
      form.setFieldsValue({ taskType: 0 });
    }
  }, [modalType, taskRecord]);
  // 自定义验证器，确保输入是2位小数
  const validateDecimal = (rule, value) => {
    const regex = /^\d+(\.\d{1,2})?$/;
    if (!regex.test(value)) {
      return Promise.reject(new Error('输入不得超过2位小数'));
    }
    return Promise.resolve();
  };
  // render线路配置
  const LineFormItem = (
    <>
      <Form.Item
        label="外呼线路"
        name="tenantLineGroupId"
        rules={[{ required: true }]}
      >
        <Select
          showSearch
          placeholder="请选择外呼线路"
          onChange={getConcurrencys}
          getPopupContainer={(triggerNode) =>
            triggerNode.parentElement || document.body
          }
          optionFilterProp="tenantLineGroupName"
          fieldNames={{
            label: 'tenantLineGroupName',
            value: 'tenantLineGroupId',
          }}
          options={callLineOpts}
        />
      </Form.Item>
      <Form.Item noStyle>
        <Form.Item
          label={
            <Tooltip
              placement="topLeft"
              title="配置值为期望值，实际并发是根据租户线路情况进行锁定"
            >
              <InfoCircleOutlined style={{ marginRight: '10px' }} />
              <span>期望并发</span>
            </Tooltip>
          }
          name="expectLoadCount"
          style={{ margin: '0' }}
          rules={[
            {
              required: true,
              validator: handleValidatorExpectCount,
            },
          ]}
        >
          <InputNumber
            min={1}
            placeholder="请输入"
            style={{
              width: '100%',
            }}
          />
        </Form.Item>
        <div
          style={{
            margin: '5px 0 15px 140px',
            color: '#999',
            height: '22px',
          }}
        >
          {concurrency ? `预计可用并发${concurrency}` : '无可用并发'}
        </div>
      </Form.Item>
      {[3].includes(curTaskType) && [
        <Form.Item label="超并发" style={{ marginBottom: '0' }} key="multiple">
          <Form.Item
            label="外呼并发"
            name="multiple"
            style={{ display: 'inline-block' }}
          >
            <InputNumber
              min={1}
              max={800}
              placeholder="1-800"
              style={{
                width: '100px',
              }}
            />
          </Form.Item>
          <span
            style={{
              display: 'inline-block',
              marginLeft: '10px',
              marginTop: '5px',
            }}
          >
            倍超并发外呼
          </span>
        </Form.Item>,
        <Form.Item
          label={
            <Tooltip
              placement="topLeft"
              title={
                <>
                  <span>
                    (当前空闲坐席数 - 在途数 +
                    (N平均振铃时长)秒后挂断空闲坐席数)
                  </span>
                  <span>接通率 x 触发转接率</span>
                  <span>*手工系数</span>
                </>
              }
            >
              <InfoCircleOutlined style={{ marginRight: '10px' }} />
              <span>自动调整并发</span>
            </Tooltip>
          }
          key="autoAdviceLoadCount"
          name="autoAdviceLoadCount"
          valuePropName="checked"
          help={`自动并发将在任务执行中状态下保持${autoAdjustConcurrencyTime}分钟后执行`}
          style={{ marginBottom: '24px' }}
        >
          <Switch
            onChange={(e: boolean) => setAutoConcurrency(e)}
            checkedChildren="是"
            unCheckedChildren="否"
          />
        </Form.Item>,
        autoConcurrency && (
          <Form.Item noStyle>
            <Form.Item
              label="手工系数"
              name="autoAdjustCoefficient"
              rules={[
                {
                  validator: validateDecimal,
                  message: '输入不得超过2位小数',
                },
              ]}
            >
              <InputNumber
                min={0}
                max={999}
                precision={2}
                placeholder="请输入0-999的数字"
                style={{
                  width: '180px',
                }}
              />
            </Form.Item>
          </Form.Item>
        ),
      ]}
    </>
  );

  // render技能组
  const SkillGroupItem = useMemo(
    () => (
      <Form.Item
        label="技能组"
        name="skillGroupList"
        rules={[{ validator: handleValidatorSkillGroup }]}
        style={{ marginBottom: 0 }}
      >
        <SkillGroupForm
          curTaskType={curTaskType || 0}
          showRoster={[0].includes(curTaskType) && !!taskRecord?.telephoneCount}
          defaultList={taskRecord?.skillGroupList || []}
          skillGroupOpts={skillGroupOpts}
          waitRosterWithOutTaskCount={taskRecord?.telephoneCount}
        />
      </Form.Item>
    ),
    [curTaskType, taskRecord, skillGroupOpts],
  );

  // render自动提交时间
  const AutoSubmitTimeItem = useMemo(() => <AutoCommitTimeItem />, []);

  return (
    <Modal
      title={modalType === 1 ? '编辑' : '新增'}
      open={!!modalType}
      confirmLoading={confirmLoading}
      onOk={handlerOk}
      onCancel={handleCancel}
      width={700}
      forceRender
    >
      <Form form={form} {...LAYOUTLABELFIVE}>
        <Form.Item
          label="任务类型"
          name="taskType"
          rules={[{ required: true }]}
        >
          <Radio.Group onChange={(e) => handleChangeTaskType(e.target.value)}>
            {TaskType?.map((item) => (
              <Radio.Button
                key={item.value}
                value={item.value}
                disabled={modalType === 1}
              >
                {item.label}
              </Radio.Button>
            ))}
          </Radio.Group>
        </Form.Item>
        {[1].includes(curTaskType) && (
          <>
            {modalType !== 1 && (
              <Form.Item label="创建方式" required>
                <Radio.Group
                  defaultValue="custom"
                  onChange={(e) => handleChangeCreateType(e.target.value)}
                >
                  <Radio.Button value="custom">自定义</Radio.Button>
                  <Radio.Button value="template">任务模版</Radio.Button>
                </Radio.Group>
              </Form.Item>
            )}
            {createType === 'template' && (
              <Form.Item
                label="任务模版"
                name="templateGuid"
                rules={[{ required: true }]}
              >
                <Select
                  showSearch
                  options={taskTempOpts}
                  placeholder="请选择"
                  optionFilterProp="name"
                  fieldNames={{
                    label: 'name',
                    value: 'guid',
                  }}
                  onChange={(e) => handleChangeTemplate(e)}
                />
              </Form.Item>
            )}
          </>
        )}
        <Form.Item
          label="任务名称"
          name="taskName"
          rules={[{ required: true, message: '请输入任务名称' }]}
        >
          <Input maxLength={80} placeholder="请输入，限制80字" />
        </Form.Item>
        {[0].includes(curTaskType) && (
          <>
            <Form.Item
              label="执行时间"
              name="exeTime"
              getValueFromEvent={(...[, dateString]) => dateString}
              getValueProps={(value) => ({
                value: value ? moment(value) : undefined,
              })}
              rules={[{ required: true, message: '请选择执行时间' }]}
            >
              <DatePicker
                style={{ width: '100%' }}
                showToday={false}
                showTime
                disabledDate={(current) => {
                  return current && current < moment().startOf('day');
                }}
                disabledTime={disabledTime}
              />
            </Form.Item>
            {taskRecord?.telephoneCount > 0 && (
              <Form.Item
                label="名单数"
                rules={[{ required: true, message: '请选择日期' }]}
                name="telephoneCount"
              >
                <Input disabled />
              </Form.Item>
            )}
            {SkillGroupItem}
            {/* 自动提交时间 */}
            {AutoSubmitTimeItem}
          </>
        )}

        {[1, 3].includes(curTaskType) && (
          <Form.Item
            label="执行话术"
            name="faqGuid"
            rules={[{ required: true }]}
          >
            <Select
              showSearch
              placeholder="请选择执行话术"
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
              optionFilterProp="speechName"
              fieldNames={{
                label: 'speechName',
                value: 'guid',
              }}
              onChange={handleFaqChange}
              options={faqGuidOpts}
            />
          </Form.Item>
        )}

        {[1, 2, 3].includes(curTaskType) && (
          <>
            <Form.Item
              label="拨打时段"
              name="exeCallTime"
              rules={[{ required: true }]}
            >
              <PhoneTime />
            </Form.Item>
            {/* 自动提交时间 */}
            {curTaskType !== 1 && AutoSubmitTimeItem}
            <Form.Item
              label="自动补呼"
              name="autoRetry"
              style={{ marginBottom: '30px' }}
              rules={[{ validator: handleValidatorRetry }]}
            >
              <AutoRetryCall />
            </Form.Item>
          </>
        )}

        {[1, 3].includes(curTaskType) && (
          <Form.Item label="挂机短信" style={{ marginBottom: 0 }}>
            <Form.List name="smsConfigs" initialValue={[]}>
              {(fields, { add, remove }) => (
                <>
                  <Form.Item noStyle>
                    <Row justify="space-between">
                      <Col>
                        <Button
                          onClick={() =>
                            add({
                              classification: undefined,
                              smsTemplateId: undefined,
                            })
                          }
                          icon={<PlusOutlined />}
                          type="primary"
                          style={{ margin: '5px 0 20px 0' }}
                          size="small"
                        >
                          添加
                        </Button>
                      </Col>
                      <Row justify="end">
                        <Col>
                          <Checkbox
                            checked={!!multipleSmsLink}
                            onChange={(e) =>
                              setMultipleSmsLink(e.target.checked ? 1 : 0)
                            }
                          >
                            千人千链
                          </Checkbox>
                        </Col>
                        <Col
                          onMouseEnter={() => {
                            isHoverPopoverRef.current = true;
                          }}
                        >
                          <Popover
                            overlayClassName="smsConfigsPopover"
                            open={smsPopoverOpen}
                            content={<SmsPreView curSms={currentSmsPopover} />}
                            getPopupContainer={(triggerNode) =>
                              triggerNode.parentElement || document.body
                            }
                            placement="rightTop"
                          >
                            <div style={{ height: '22px' }} />
                          </Popover>
                        </Col>
                      </Row>
                    </Row>
                  </Form.Item>
                  {fields.map(({ key, name }) => (
                    <Row
                      key={key}
                      style={{
                        marginBottom: '24px',
                      }}
                    >
                      <Col
                        span={22}
                        onMouseEnter={(e) => handleSmsMouseEnter(e, name)}
                        onMouseLeave={() => setSmsPopoverOpen(false)}
                      >
                        <Row>
                          <Col span={10}>
                            <Form.Item
                              noStyle
                              shouldUpdate={(prevValues, curValues) => {
                                return (
                                  prevValues.smsConfigs !== curValues.smsConfigs
                                );
                              }}
                            >
                              {() => (
                                <Form.Item
                                  label="意向分类"
                                  colon={false}
                                  style={{
                                    marginRight: '10px',
                                    marginBottom: 0,
                                  }}
                                  name={[name, 'classification']}
                                  rules={[
                                    {
                                      validator: (rule, value) =>
                                        handleValidatorClassification(
                                          rule,
                                          value,
                                          name,
                                        ),
                                    },
                                  ]}
                                >
                                  <Select
                                    showSearch
                                    placeholder="请选择"
                                    getPopupContainer={(triggerNode) =>
                                      triggerNode.parentElement || document.body
                                    }
                                    fieldNames={{
                                      label: 'classification',
                                      value: 'classification',
                                    }}
                                    allowClear
                                    options={intentionClassifysOpts}
                                    onChange={handleClassificationChange}
                                    onDropdownVisibleChange={() =>
                                      setSmsPopoverOpen(false)
                                    }
                                  />
                                </Form.Item>
                              )}
                            </Form.Item>
                          </Col>
                          <Col span={14}>
                            <Form.Item
                              name={[name, 'smsTemplateId']}
                              rules={[
                                {
                                  required: true,
                                  message: '请选择短信模版',
                                },
                              ]}
                              style={{
                                marginBottom: 0,
                              }}
                            >
                              <Select
                                showSearch
                                options={smsOpts}
                                fieldNames={{
                                  label: 'templateName',
                                  value: 'id',
                                }}
                                optionFilterProp="templateName"
                                getPopupContainer={(triggerNode) =>
                                  triggerNode.parentElement || document.body
                                }
                                placeholder={'请选择短信模版'}
                                onDropdownVisibleChange={() =>
                                  setSmsPopoverOpen(false)
                                }
                              />
                            </Form.Item>
                          </Col>
                        </Row>
                      </Col>
                      <Col
                        span={1}
                        style={{
                          margin: '4px 0 0 5px',
                          fontSize: '18px',
                          color: '#2d8cf0',
                          cursor: 'pointer',
                        }}
                        onClick={() => {
                          remove(name);
                          handleClassificationChange();
                        }}
                      >
                        <CloseCircleOutlined />
                      </Col>
                    </Row>
                  ))}
                </>
              )}
            </Form.List>
          </Form.Item>
        )}

        {/* 线路配置 */}
        {[1].includes(curTaskType) && (
          <>
            <Collapse
              ghost
              activeKey={activeKey2}
              expandIconPosition="end"
              expandIcon={(panelProps) =>
                panelProps?.isActive ? <DownOutlined /> : <UpOutlined />
              }
              onChange={(val: string[]) => setActiveKey2(val)}
            >
              <Collapse.Panel
                header="线路配置"
                key="2"
                className="customCollapse"
              >
                {LineFormItem}
              </Collapse.Panel>
            </Collapse>
          </>
        )}

        {[2, 3].includes(curTaskType) && (
          <>
            {LineFormItem}
            {SkillGroupItem}
          </>
        )}

        {[1, 2, 3].includes(curTaskType) && (
          <>
            {/* 拦截配置 */}
            <Collapse
              ghost
              activeKey={activeKey3}
              expandIconPosition="end"
              expandIcon={(panelProps) =>
                panelProps?.isActive ? <DownOutlined /> : <UpOutlined />
              }
              onChange={(val: string[]) => setActiveKey3(val)}
            >
              <Collapse.Panel
                header="拦截配置"
                key="3"
                className="customCollapse"
              >
                <Form.Item label="外部黑名单" name="thirdBlacklistIntercept">
                  <Radio.Group options={taskTransferOpts} optionType="button" />
                </Form.Item>
                <Form.Item label="规则拦截" name="featureIntercept">
                  <Radio.Group options={taskTransferOpts} optionType="button" />
                </Form.Item>
              </Collapse.Panel>
            </Collapse>
          </>
        )}
      </Form>
    </Modal>
  );
};
export default TaskCreateEdit;
