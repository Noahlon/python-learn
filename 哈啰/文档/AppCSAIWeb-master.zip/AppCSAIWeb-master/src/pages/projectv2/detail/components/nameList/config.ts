import { RosterListObj } from '@/api/projectv2/nameInfo';
import { text1Tooltip } from '@/utils/format';
import { Badge, Popover, Tag } from 'antd';
import { PresetStatusColorType } from 'antd/es/_util/colors';
import { ColumnsType } from 'antd/es/table';
import React from 'react';

// summary
export const summaryLeft = [
  { label: '总名单', value: 'nameListCount' },
  { label: '待下发', value: 'toBeIssuedCount' },
  { label: '待分配', value: 'toBeAllocatedCount' },
  { label: '已分配', value: 'allocatedCount' },
  { label: '已回收', value: 'collectedCount' },
];

export const summaryright = [
  { label: '待跟进', value: 'waitCount' },
  { label: '跟进中', value: 'followingCount' },
  { label: '跟进成功', value: 'followSuccessCount' },
  { label: '跟进失败', value: 'followFailCount' },
];

// 流转状态
export const wanderStatusOpts = [
  { label: '全部名单', value: null, badgeStatus: 'processing' },
  { label: '待下发', value: 0, badgeStatus: 'processing' },
  { label: '待分配', value: 1, badgeStatus: 'processing' },
  { label: '已分配', value: 2, badgeStatus: 'success' },
  { label: '已回收', value: 3, badgeStatus: 'default' },
];

export const firstSearchTypes = [
  { label: '手机号', value: 'phoneNum' },
  { label: 'md5', value: 'phoneNumMd5' },
  { label: 'guid', value: 'uploadGuid' },
  { label: 'newid', value: 'uploadNewid' },
];

/**
 * 固定 & 动态的表单
 */
enum FieldType {
  // 单选
  SELECT = 'select',
  // 多选
  MULTIPLESELECT = 'multipleSelect',
  // select tags
  SELECTTAGS = 'selectTags',
  // 输入框
  INPUT = 'input',
  // 数字区间输入框
  NUMBERINTERVAL = 'numberInterval',
  // 时间区间
  DATETIMERANGE = 'dateTimeRange',
  // 级联
  CASCADER = 'cascader',
}

export interface FieldObj {
  fieldType: FieldType;
  fieldName: string;
  fieldKey: string;
  fieldOptions?: any[];
  startField?: string; // 起始值（数字/时间）
  endField?: string; // 结束值（数字/时间）
  showSearch?: boolean; // 是否可搜索
  fieldTypeDesc?: string; // 字段类型描述(例如：多选)
  fieldNames?: { label?: string; value?: string; desc?: string }; // 下拉框字段替换
}

export const allFixedFilterList: FieldObj[] = [
  {
    fieldType: FieldType.MULTIPLESELECT,
    fieldName: '跟进状态',
    fieldKey: 'followStatuList',
  },
  {
    fieldType: FieldType.INPUT,
    fieldName: '跟进节点',
    fieldKey: 'followupNodeName',
  },
  {
    fieldType: FieldType.INPUT,
    fieldName: '任务名称',
    fieldKey: 'taskName',
  },
];

export const defaultAllDynamicFieldList: FieldObj[] = [
  {
    fieldType: FieldType.SELECT,
    fieldName: '是否呼损',
    fieldKey: 'isCallLoss',
    fieldTypeDesc: '单选',
  },
  {
    fieldType: FieldType.INPUT,
    fieldName: '运营商',
    fieldKey: 'carrier',
    fieldTypeDesc: '文本精准搜索',
  },
  {
    fieldType: FieldType.CASCADER,
    fieldName: '省市',
    fieldKey: 'citys',
    fieldTypeDesc: '级联选择',
  },
  {
    fieldType: FieldType.SELECT,
    fieldName: '任务类型',
    fieldKey: 'taskType',
    fieldTypeDesc: '单选',
  },
  {
    fieldType: FieldType.MULTIPLESELECT,
    fieldName: '任务状态',
    fieldKey: 'taskStatuList',
    fieldTypeDesc: '多选',
  },
  {
    fieldType: FieldType.NUMBERINTERVAL,
    fieldName: '执行次数',
    fieldKey: 'executeCount',
    startField: 'executeCountStart',
    endField: 'executeCountEnd',
    fieldTypeDesc: '数字区间',
  },
  {
    fieldType: FieldType.MULTIPLESELECT,
    fieldName: '执行结果',
    fieldKey: 'executeStatuList',
    fieldTypeDesc: '多选',
    showSearch: true,
  },
  {
    fieldType: FieldType.MULTIPLESELECT,
    fieldName: '最近一次外呼结果',
    fieldKey: 'calloutResultList',
    fieldTypeDesc: '多选',
    showSearch: true,
  },
  {
    fieldType: FieldType.SELECT,
    fieldName: '技能组',
    fieldKey: 'skillGroupGuid',
    showSearch: true,
    fieldTypeDesc: '单选',
    fieldNames: { label: 'skillGroupName', value: 'skillGroupGuid' },
  },
  {
    fieldType: FieldType.INPUT,
    fieldName: '座席',
    fieldKey: 'seatsGuidOrName',
    fieldTypeDesc: '账号/名称精准搜索',
  },
  {
    fieldType: FieldType.INPUT,
    fieldName: '最近一次跟进备注',
    fieldKey: 'followRemark',
    fieldTypeDesc: '文本模糊搜索',
  },
  {
    fieldType: FieldType.NUMBERINTERVAL,
    fieldName: '外呼次数',
    fieldKey: 'calloutCount',
    startField: 'startCalloutCount',
    endField: 'endCalloutCount',
    fieldTypeDesc: '数字区间',
  },
  {
    fieldType: FieldType.NUMBERINTERVAL,
    fieldName: '接通次数',
    fieldKey: 'throughCount',
    startField: 'startThroughCount',
    endField: 'endThroughCount',
    fieldTypeDesc: '数字区间',
  },
  {
    fieldType: FieldType.NUMBERINTERVAL,
    fieldName: '外呼次数（座席）',
    fieldKey: 'seatCalloutCount',
    startField: 'startSeatCalloutCount',
    endField: 'endSeatCalloutCount',
    fieldTypeDesc: '数字区间',
  },
  {
    fieldType: FieldType.NUMBERINTERVAL,
    fieldName: '接通次数（座席）',
    fieldKey: 'seatThroughCount',
    startField: 'startSeatThroughCount',
    endField: 'endSeatThroughCount',
    fieldTypeDesc: '数字区间',
  },
  {
    fieldType: FieldType.MULTIPLESELECT,
    fieldName: 'AI意向分类',
    fieldKey: 'intentClassifyList',
    fieldTypeDesc: '多选',
  },
  {
    fieldType: FieldType.SELECTTAGS,
    fieldName: 'AI标签',
    fieldKey: 'intentionLabelList',
    fieldTypeDesc: '输入标签',
  },
  {
    fieldType: FieldType.DATETIMERANGE,
    fieldName: '最近外呼时间',
    fieldKey: 'calloutTime',
    startField: 'startCalloutTime',
    endField: 'endCalloutTime',
    fieldTypeDesc: '时间区间',
  },
  {
    fieldType: FieldType.DATETIMERANGE,
    fieldName: '最近接通时间',
    fieldKey: 'throughTime',
    startField: 'startThroughTime',
    endField: 'endThroughTime',
    fieldTypeDesc: '时间区间',
  },
  {
    fieldType: FieldType.DATETIMERANGE,
    fieldName: '下次跟进时间',
    fieldKey: 'nextFollowTime',
    startField: 'startNextFollowTime',
    endField: 'endNextFollowTime',
    fieldTypeDesc: '时间区间',
  },
  {
    fieldType: FieldType.DATETIMERANGE,
    fieldName: '回收时间',
    fieldKey: 'collectedTime',
    startField: 'startCollectedTime',
    endField: 'endCollectedTime',
    fieldTypeDesc: '时间区间',
  },
  {
    fieldType: FieldType.DATETIMERANGE,
    fieldName: '分配时间',
    fieldKey: 'assignedTime',
    startField: 'startAssignedTime',
    endField: 'endAssignedTime',
    fieldTypeDesc: '时间区间',
  },
  {
    fieldType: FieldType.DATETIMERANGE,
    fieldName: '下发时间',
    fieldKey: 'distributeTime',
    startField: 'startDistributeTime',
    endField: 'endDistributeTime',
    fieldTypeDesc: '时间区间',
  },
  {
    fieldType: FieldType.DATETIMERANGE,
    fieldName: '添加时间',
    fieldKey: 'addTime',
    startField: 'startAddTime',
    endField: 'endAddTime',
    fieldTypeDesc: '时间区间',
  },
];

// 名单列表columns
export const rosterListColumns: ColumnsType<RosterListObj> = [
  {
    title: '省市',
    dataIndex: 'province',
    width: 150,
    render: (text: string, record) => {
      if (!text && !record.city) {
        return '-';
      }
      return text1Tooltip((text ? text + '/' : '') + record.city);
    },
  },
  {
    title: '流转状态',
    dataIndex: 'wanderStatusDesc',
    render: (text: string, record) => {
      return React.createElement(Badge, {
        status: wanderStatusOpts?.find(
          (item) => item.value === record?.wanderStatus,
        )?.badgeStatus as PresetStatusColorType,
        text,
      });
    },
  },
  {
    title: '跟进状态',
    dataIndex: 'followStatusDesc',
    render: (text: string) => (text ? text : '-'),
  },
  {
    title: '是否呼损',
    dataIndex: 'isCallLoss',
    render: (text: number) => {
      if (text === 0) {
        return '否';
      } else if (text === 1) {
        return '是';
      }
      return '-';
    },
  },
  {
    title: '跟进节点',
    dataIndex: 'followNodeSetName',
    render: (text: string) => text1Tooltip(text),
  },
  {
    title: '任务类型',
    dataIndex: 'taskTypeDesc',
    render: (text: string) => (text ? text : '-'),
  },
  {
    title: '任务名称',
    dataIndex: 'taskName',
    render: (text: string) => text1Tooltip(text),
  },
  {
    title: '任务状态',
    dataIndex: 'taskStatusDesc',
    render: (text: string) => (text ? text : '-'),
  },
  {
    title: '执行次数',
    dataIndex: 'executeCount',
    render: (text: number) => text ?? '-',
  },
  {
    title: '执行结果',
    dataIndex: 'executeStatusDesc',
    render: (text: string) => (text ? text : '-'),
  },
  {
    title: '最近一次外呼结果',
    dataIndex: 'callResultStatusDesc',
    render: (text: string) => text1Tooltip(text),
  },
  {
    title: '技能组',
    dataIndex: 'skillGroupName',
    render: (text: string) => text1Tooltip(text),
  },
  {
    title: '座席',
    dataIndex: 'seatsName',
    render: (text: string) => text1Tooltip(text),
  },
  {
    title: '最近一次跟进备注',
    dataIndex: 'followRemark',
    render: (text: string) => text1Tooltip(text),
  },
  {
    title: '外呼次数',
    dataIndex: 'calloutCount',
    render: (text: number) => text ?? '-',
  },
  {
    title: '接通次数',
    dataIndex: 'throughCount',
    render: (text: number) => text ?? '-',
  },
  {
    title: '外呼次数（座席）',
    dataIndex: 'seatCalloutCount',
    render: (text: number) => text ?? '-',
  },
  {
    title: '接通次数（座席）',
    dataIndex: 'seatThroughCount',
    render: (text: number) => text ?? '-',
  },
  {
    title: 'AI意向分类',
    dataIndex: 'intentClassify',
    render: (text: string) => (text ? text : '-'),
  },
  {
    title: 'AI标签',
    dataIndex: 'intentionLabel',
    render: (text: string) => {
      if (text) {
        let textArr;
        try {
          textArr = JSON.parse(text);
        } catch (error) {
          textArr = [text];
        }
        if (textArr?.length > 0) {
          const textNode = textArr?.map((item: string, index: number) =>
            React.createElement(Tag, { key: index }, item),
          );
          return React.createElement(
            Popover,
            { content: textNode, placement: 'topLeft' },
            textNode,
          );
        }
      }
      return '-';
    },
  },
  {
    title: '最近外呼时间',
    dataIndex: 'calloutTime',
    render: (text: string) => (text ? text : '-'),
  },
  {
    title: '最近接通时间',
    dataIndex: 'throughTime',
    render: (text: string) => (text ? text : '-'),
  },
  {
    title: '下次跟进时间',
    dataIndex: 'nextFollowTime',
    render: (text: string) => (text ? text : '-'),
  },
  {
    title: '回收时间',
    dataIndex: 'collectedTime',
    render: (text: string) => (text ? text : '-'),
  },
  {
    title: '分配时间',
    dataIndex: 'assignedTime',
    render: (text: string) => (text ? text : '-'),
  },
  {
    title: '下发时间',
    dataIndex: 'distributeTime',
    render: (text: string) => (text ? text : '-'),
  },
  {
    title: '添加时间',
    dataIndex: 'addTime',
    render: (text: string) => (text ? text : '-'),
  },
  {
    title: '数据源',
    dataIndex: 'dataSource',
    render: (text: string) => (text ? text : '-'),
  },
];

export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 300,
};

export const mobileIconSrc =
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAADaRJREFUeF7tmguYHFWVx3+nZpIAwSymB+KiKGxABELQdM9kJsBuHgsIRFCUAMJmCTOTkFUU0SBIkqrK8JKHQCKvZPJA+FwMkBVQsy5Zg+ySeXT1BEEWXTcYVsCNzER5hITJdJ1NVb+nqrt6YILfJ9zvy5fpuueex/+ee+65517hPd7kPW4/7wPwvge8xxF495aAmToc3AtADsfgcFSPAKlF+B0qzyDyIDt3/IzrT/zjuzknexcA68mDkFHnAJ9BOSnSMJGXcN072CW38+3Eq5H0w0Cw9wCwnUtQLgX+Zsh6Cr9GuYNnn7+dB2alhzx+CAOGHwAz+QWQSxGOH4Ie5Uh7UK7ETvzbMPAKZTG8AJjOTQhfr6issAWXpzE0hcuTJbSGXJBdKh8dxGMBVuKmvQHC8AFgOvchnF9WSdUkGDdhx9dGGmI5nwVtA5lQoJV7seKzI8cOkWB4ALBSG0BnlJHdj7AY9/WbsacNVK3flT0HMspdAlycH6M8gJ2YVTWPKgjfOQC280uUY0JlKS+g2sqS+sdC++92RvAyx4KO8fv3lc1cMSj6m6kLMHQJymE+zTCD8M4AsJJ9IGPLAN3JgFzE1fHnAv1Wz7mQvgQkDowq7Zc1COsw44/mv5tdH4eauxCmDTcIbw8As3MMUlthn5Z1vLnzQm444fUS4xY5x1Kj3wI5N9I71QuQxg3Ykx7xaW/8xWh29Lfnxw6TJwwdALPjUGTEb8sHO7kdO/7lQL/pnIxwN3BopPElBLIKK95c8AZnOULrcHnC0AAwnUkIqbIGiCzEjF8TNL77QsTwjB85NOOz1EoKO5HIj7WSN4NcNhwgVA+A2fP3iBsezPzgZDRjT1oVMNB2rkS5NtJwkUdx9b9B38jGlSkIXozItTc5+vkxzMpmhmbSQsTMdOpyrPp5kTJCCKoDYHH3ORjG/eVn3jgNc9L6QL+VXAYSXA4lhLocw1jO4njQsxalTsTYkwmKnpofoq9/EHvan/zfprMO4XMZDORr2PFbhwpCNAC2M9/Py8u1dHoKbZM7gm6fehDRz5cHjR2g8zHr741U2nSuQLiuAMLAIdiNL/q/reRmkE/6f4t8GjP+00h+RQSVAbCTV6FydRmGuzBoYHHimaDxyU2INFVQZCuGzGZx/D+qVtbLB0SLwToKK/Erf7ztbEX5GMJz9L91Ktcc/0K1fCsDYG2eAumHgA+Vei0vgDsdu+H5oNs73g5RPtL7KXHtLOxPbQ1T8vaNB+5fO1LGiQyMG/HWmJ4507buytOZyamIbMz/NtwGFjckWeiMp0Y3I/IBkHVY8fKeN0ho9BLw83L+pWhcN/0DZ3Bt47YSXqYaSGpn5UivP0HfODMsJW7vqjt9TxD8IsIXi/i+LshKY+eAPWfanzLrvs0ZT5r/KSwHacKOd2KnPofqOv+70oqdaK/GC0IBWNFRNxXcqa1N2y2fielcjHAn6KOMHnkeC47bUcLccvYDXgG8/8s0WYMVnxPWuaqrbqarWsj8AkT6lJuWuXOP70v6XUt/M4rtrxY84y3jIK6b9Ap2qhXdsyPAFnSfE7An/F8UCKEAtHfGPDebqqp2AYQ97mfXPx5geN3TH6S//zmUcWWFqd6IXX95WP/KrtglqiyNUhTlZUXOb23qzehgOXVZ0L1fz6PxI7DFxXa+iXI9ym3YCa8gU7GFe0Bn7AKBTMARmdkyuffHoVyucf6a3TwBHF5eil6LVX9VWP+KzrpbBI1UMjdWYKercloehCU9x+G6T2X7v4eV+McsOKuBC1H3JOyGDZUQCAJw1aYPc82Ul9o7Y23AQm9wutY9YF7ij6W5/8Kuw6ipeQjhUxWMvxWr/mth/e2dsR8CZ0bNUFi/qkzLg2AmT0MkN0HfwUp8HbP7Q4jhbc1P5EEptzAD372qjp34hve9vSO2FuFshYHWxr4RedqFHUdRW7u2tGAxmFP57GxFR+xxEf4uyniBDa6Kn1qLoaei5JdRCQi2czZKrtCSqR7ZqXNQvQkrccjQPMByNoJu8tx2ZU/dwdrPetCJAn9obuwrrPOSVDQgYilW4quDv27cSO2W/WLdaCWvyY5Srmhp6vt2MY8VHbGzRPyl6QfbtNI4r6mvy6cpBkE5xa8j2s4duO5y7IbcMgkoGlwCOcOU+diJu1Z1xCanhUcEDhL4VXNj31F5LmEgqNyIHQ8EvNWdBx6RFnc9yvjomZd5zY29XjQPtBVdsemi+gMQLwhS43LUnCl9mYTIdC5DuBl4mhGjTuaqY7f5O5iduKuczCAAmcDiBY5aRGdh1j/mbYsimktAOloa+6aUAeFqrMSiwcKWbxp7ilEj96IcGGH8DkTntEze/kAlutWbDzgg/VaNN6sf8+hG1crB/5Do/b0/xnJuA74C2RriEmcyixMZLwlp4YlQYT/9Jeqe6WV8g0Dobmnsm1wEwlRG7LOFhcf+brCM9s66c0HvqeIo/KIYzGlu6AtGbbPnaMT9EqqvYNdnchNgZVfsSVX8yRi5b+3+s4/btgOvzPZ7fRDkDCCymhy2BM7Arn8EM194+DFWYqYnpAQE4de708yYP6XvpXLotm+qm4ehZd0vN07gGa981nxCrxPg5RlvuGvzdUeVW7DjmVqAF6izOYv3d0tjX8aeTAnNC+DHocYx2JP+q3oP8ILgmHGn8dq20SgbfCbsSVSyQW2VUzfJHdDc0XWbYehZFzVs3zRYwIquugWiekM5wfnvok+kB2ovmnf8H7aEGi/pH4FkCqK5pqzETrQEQBCebZnclymlL+46BaPmflRvK/aawTKCHmClloHuwkosoHiPVbVzjFZ1jj3aRZ7NMtulymWtTX13er/XOAeNHxhIezP0T5HGw8O4uy9qmfLa9lDjcbsRRofzkfux4ud5fd/7xbjR/TsHfpTJXmVla1NvBhw7OQ/XUOx4aED1SEKWQPdZiPEQua2kONIHQXjaC8S+MOV/ES8l5RgkMth59Pc0N/bNEUHDZ97NAVzGfv0sZv3Duc4VXX91mLi1jyBMoHgLXZKKhxZbsgNDANh8AJLevKfw+BJu/G/9/Np0vo/go00QhH8PHJcjpl6RW1sbe0MzRKzkBJBgjaGYZ5nCR3t3bAYu/+rtYKIyt7mpd0WUF4bvAqZfxFxdbCx2ykE1U6MTmYsZ95n7y0GkEKSiJKJmS+N278Yn2OzkSahUvghVnRZ6KMtyW9ERmy+SqWCVZItl9CpfD7BSq0EvBL6KlVjKN346mv1j3vFy/6wnnI5d/5M8CPB9EC9glm2ifKW5qW9ZKIGZvBSRWyrip9mz/2AiM/kd4LVcjGrvHHsjyMX77jfw0fMnvlrxwUV5ADL1fy/5ORQxZmNOupe25JGkJZN1+RDLqdhxz+W4p+sDsX5GXi1adJdXUPRlhW+2NvbdF258Ua2/HAI60ITd2BnotpLrQT6d8UwuxUx4iRArOmJ3tjb1zY9yyMoVodxSENIMuDNoa/g5pnMCQqGWJ3IuZvwHOUEru2KzVf1K7VTgKVX9+T4jjLvzmdpgjSzHy/q+UFFRg8bQbM4MqT2KtmDWr4wyPNcfXRIzk99F5EtAL9p/JPaU7WQys+IoHZlxBRTyMza8revkCsr2ozVHhtYPrdSzoEeHj9XzsOrLl/GLBkUDkFHUc/PpiPwGM/5xf7yfoWkPqpnLzSorMD5t2+YjGBi4J7JyzJ5bZyvxZsBIO/Uiqh8ONX5QkhTlCdEA+MamJiL+sfhgoBsrkTkHZDzBq+Xl3gE9TJrraCt/+CBTZPWKLUWPHwapqdqBXV84cBV3m84bZZOjCqW3ckBUB4A32u4+B83fDhXKT4Nzdejf4xXeJcbjJduVmZqJwVxUP1NxVlQewo4HY4L34oxRpZXoYkaZt0TXR8344P7qAfBnvPg+jsLR138DyNKSK6zMstjpLxvVGEK4y5ZopN/Fqr8kYMSiVJwaDR6UcoTqzsNuKJvuVgJlaAD4npAyUc0dSUsrP6azFCFoQDXTInwLM1G4/sqNCd5LlHJTPRu7/sFqRITRDB2AIAhrsBKFer/3+kPdyysXS4tUEbbhuldgN6wJBjv/rWH5krnLTJYkwivWVSLy9gDwmFuOV3rKnct/iLrzsRsyFxHeRYnq5Yh4r0Q/EaqLsBtlGbp7GXZT8JrMTN6AyIKydgjTMROFa7IqDX5nMWDwaDN5f9ZIb8E7iFweUMpOeUHvfFSzBVXZiqpXourGTvQE9Da9w9jAnRWe0bgYtRNZ/MnKp8UqAXn7HpATYDr/WfoqVK5Fx7ZhH1a4uqpSGbwXKOhSRMq8MtXfgjRgJXqrZRlF984ByLi8l9GdXiSsG5U27Lj3Pbp5t7u1+uXsY4raMktmI2ZiejSzoVEMDwCeTO9EJlJ6xlf+GXQD7Hsf9oT+YJDrmYGbPtE3XIhVUL000A7NxorUwweAJ8ZONqPiHU0zDx8LzXsh+jOQbXtehXj/PoLItIoXqrmxRQWYYbQ7z2p4AfDYLupqorb2ysiML9qax7MFmeCNdPTYqimGH4Cc6GpT3zBV9/KsF4vcewAUAyF6NuA9ct6n7NSorMfwqsQjHsOeGHx6U/WcDo1w7wOQB2LtSIzx08D9CC6HYIj3zng7uNvZVeP4Lzz+DO3dA+DPYFw1It8HoBqU/pJp3veAv+TZrca297wH/D/LmyaMoG1AAAAAAABJRU5ErkJggg==';
export const unicomIconSrc =
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFUAAABACAYAAABr7jtyAAAAAXNSR0IArs4c6QAADUtJREFUeF7VXAmQHFUZ/v7ezXZPAhqBUIWKRgosSEQioHIUErAAQ4BwLCs3GwIIEhNIdnoSAobIkZ2eZDkCcgWEQBRyAIWGG+VQhBIRJEGpAgIIQSRIJZKdns3ufM7rndnMTrr7dc+xVXlVW1u773//+9/3rv/9RwuGuFjzOR4GxkNwKIDxAN4d+CHecxPowjTZGEcss5NHGQYmUrA78tgD6jewhsAbQrwBA3e7SVkbh2cttFJL4zhtWxZwjEF0gThK024NBNe6SblDx9/jmUeyMCntGtqNAtzdl8ftPbPkdR3fWuuHBNSEw5MJLIslrODxvGBGT4e84dcukWEbiftj8QQ+IHFRLiUPx2wXi7zhoFoOHwXwo1hSbSFekzfQVgmsleYUCBZXyRMCJLO2LKi2va5dQ0FNOOwgkNEJoTsOyoE1HU4X4LoaeYLEkbmUPFkrH7/2DQN1uMN988BLAJrrILi3Yo08jgMwvw78FIsnXVuOrBOvQWwaBmrC4UMEJtVR6DUAxtaRH4Q4OZuSFfXkqXg1DFTL4YcAvhwksBCrILiHQILAtwTYr6hiVT9G4j4xcEM2KX9OZHggidvDJoKCdC4ps6rv0L9lQ0A1u7ib9OLtIGEpmJ5Lyg3l9VVpCOUMiHluSq6o7NNy+IeQyXrZteW72waoDo8prLzfBgi7rqUZe2+cIf+trK8a2ABAFf+Ew4MJ/DEIONeWui+sujNUwltpXgHBXN+BhABQBCGeTqvhhzS3twSBL7RtBlQzZKWS+GsuJfsHrRwrzdMLz8x7Y2xJX1221H6Yw3FNwN+2+ZWqO1PzxJielPyjcqBmmueL4NYYgJZIA4E1HaYFsAN4fubaskMV/YU2acj2946AsNufWOam5McVF9UlBLpqGOBWwCbSbKVgeQjP+11bTqmhT9+mDQNVq6cKfu0m5fTiGXw5BL+ow+AGgE1keALpAdoUqIUQ03OpwVpIHWRonJ6aSPMACp4PfVEJ7nGTclbR2qQMLsHKvaAPDAbIA6N4aZkZHiuEUupbQkD6tK8JP9w8U16rB5DlPBq2UotHwJUALtMIfZdry2QNsP8TA+3Io53AsWFahenwaIEHaCKsXxIX5lJyS70BVfwaCioyHGECzwvxnVDhiTvclJwbAOzHBNpztjyGubSsEVgF4PBB/EortJNHiWAFBNtpwFri2nJ2IwBtPKgAPJWGWAnBbppB3Oba8pMKYNfCQLvbIc+V2m5/DXfc3IzfATigfMtbC/lD9GElgC+GrlDgodxotKJN+rZZUJXg3js87wG7S9hABLg5a8tPS8AaRHt3Sl6ubJNYyF3Zh1UgHlBPUyvD8eg/Q3fUAPWI24xWzJBsowAdkpVaEt7K8HASKwu20JEaYBdlbZmmgA2y+qv2LQu4Z0+H/NNyeAj6z9CdNUA95ebRilmyoZGAakFVakkeOFCIUcriJMDbBF4WwZossBpJ2RRHQLOTE8XwtqgZukUF1+WScomOd6KTB7EJK8DwHQDiueY+tPa0YFTYRFX215LmXk2CMYXFsLcY2DdP9BjERzTwqrsJv8EV0u0no+9FZTlsh+A8EAeFDOx9Ap05W27WDd5K86qCFtCrtmoEhbx4VGJhzpaOIN6JNL9H8Sboq5r+X5RmtOZzMKUJD/u5Z3yOl4OYx5WFyRh8IQ4m3CiCJezFQne2KI/wQBkEqjWfo9HkGUJ03sktDIhVJDrdWeJrCTIdLhBg5qBLJc0zCxfXEt1kEHBytqQq6YYv4H55dUYDXw9d8cArImiVHHpo4kEQyswXaitIpJmkQKmCobuprF+1W6e6ttxV+t8AqMOv5i5swaMk9tEN1rfex1qUcHgjgYsG0ZfUn6jvfMF8NymXlniMcDiuDx6gOm1iNYnWlhFYv7nbo1dxBqWyFbBmF3c3+tBVMPj468EaUAhM8NS+AT31Vg6zNuAhAEdXBWixEYGLc7Zcr/600lwMwZSwCYjhxLvKteXylk7ubfSfyXto5HwzL2jrGY53rG4sAzHBh34A2KKapvTf79cyfgPYr9uWV7yVajlUK+HqWhgOLH3B6aQ3Od67PrAUV6zlULkz9M48Yh4Eygizp0bOtQbR1j0Sr5kbsEyA40Po+x2KxIIA4ONC8phrywTBXLZYI/AqgL3icqiJvuy4sBzOA/Dzmvj177sPpQ9t2VnyQsLhScUADqNmvvEYnC2RjMJqlfQLrZR35dYdHa+fCmqf89fM0BF6ITzVlk/QhzZ3tjxTYlC0AyhDzYhqmXrtiE8EWE5gB4i3C78Qwu8lsRwqK3vgVvVzN4S6S3TSh/mTMlxEYqqOhU/9hkIwWlvOlicq66w0D4N4IUc7VcF3LfpwTvlEKXuGlcerxSA4X5YK1E+hZsC/zHZt6fSrqgpYnT9Jne8ZLgYDLjh/GbNFQJU9wLcUzZAK2F1jALsewImuLcp8OaiYnZwgBh4J4qVAZWBHfThs0CxVEMYCNgKgJfZWhktBnBYBgL5CqGRbNiUP6GiHdXKfwutoGQTf1NECyJFoCwtksxyuDrL/Vg1qJMNyufRxQHW4FIgEKig4LpeUIHf4gARDDaryv3/Jb/YoyOSSspXTLDagJeYRgA3Vb4OWWB6HurO2mAcryYZ8+5sOVwhwUpC8lRbyYsCDespWF9cUdlGluYhS1UWFvGCfnqT8vd4XlRCnZVPy4gDfKBeV6fBCAX6pOWfWCPEs+0PKqwNTcxSYaToiNalUgIHRboe8V+qqbiqV4C3J44mIKtXrsl2GO/cSaia+EeEArx9JufIfFtESs0c3j5HKZhpD+a93NOEc75ka4w2uHaJyzAmgfOlhz9R3DQNt3R3yl0SaKQp81bbyzgRoixri7unWt3JY5Gdq3tNja9+BwGpXcMCAlcp0qN7JJ2tRCyHIGxhbMgKHXDibQExyU/K0meY0EXgGmNBCnOGmZGkiw1PIgnFYX3pdW4bhJm4XxaBS9cVbIYcITs0m5b5B9tSqgRV87u6EUZgsbnk/fqY/EZyYTcqDlsNzAS9+NLwIznGT8qsSUaRndT/xeteWUdvfyB2jmP4UsJLHUgHG6UTyqyfxs1xKblR1W1n+Yyn0/RxecJNycJAgg4zUwGRlzI0KTJBv3nJ4VuEOuFs7eMFbblL2SFzFr0QyUl/LkWYv5gpxsZb3FoI3CVxf7gHxd6eoBLJmnIU8joF4/qmtCoFXDODerC3X6gRQ7hQBNmRTkileINqQcGpCcqwMJ4O4U9c3AC+w15zP3aK6U8wMJwpxJuCZGoPKGuXBNfO4fsNs+aycSBtMoTL0pAm7gMVQc8E69uGjsOdrkBQtGU4y6BnDQ0vUlJzIRwjwlGvLEToPbaVQw9PcPy/4duGCHFMMn/+IwDrk8WRuljweNAgtqDoAotYXdUZlXdeVOa4t1ygrf1h2nnqEZG1ZbqZ5gQi0zkcKVuSSUtNFrBO8VD8koJoOjxQgcGYHhN3iDVCeiDNF0J5NikobGlTKwti9OCzT4UUCeJeEpix2bTlPR1RrfcNBLdozfx9B0E7XltmJNGdSUMrGex9Eu5sSlQzhlcq8ABEvG2W6meE0oV49I7AgZ0stxnDtUBoKqopKAfG0TgoSXbmUzDTTnCqCRRX06ylozyVlVUiihecYTHRyBg0s1PUH4F7XFnURNaQ0DtQuJqxeD9ADwyQX4KasLVOtTp4HA7cF0HYLvDDKwKRhITqyKVlY9Ns7OrQalZim+m0YqKbDroIaFR66I7jdTcr5VoZngLhHB0SE+imuLXdG9NC+7m7CvpgnvRH4xiJpGKiWw/c17ouBGFGdnyzqiAgsz9nSpuitDOeAUOFGwSWCfTdq3+V0DQG1GEUSmGYDwX1uUk4tFyTSyg7FZwugJTIrw7kgtsoCLGNzp2uLf8BHNWgW2zQEVM1NvK65F+M+v1Q+qZQ7qsWqsl35Cq2ssxwqD+sRARg949pyWA34+TZtCKhh9oPilyECjeJexCEwYEDRDTgMUNU2QKMosf3QtUUXNagTYav6IQdVgFTWlsDbOW5+qrKzqpdV0MjDsg8B9Li2RI3uiwzukINKYGXOllY/CeMCWuIRBqzmSPlXQVv4WmS0IhI2BNSilScwuAF5nO/OkkG21GoB1QEbGtdQtGBFxCoyWUNALfq9PtZIcQsEf/JoCGWPvSCy1AGEKkhY+vBo4eMICcPAWO33W4qpRrX2W9m+IaCqTiyHL+heUzEHU28Hner+B35hPTHlGpqLyrt1wz+kEFfuun+YhiqfypYT4goShb5hK9VbrRleBWJOFEFCaAaFktfJ8/uBAUxSUc81yubbvKGgFoFdgn7XRDWlER/76qFgYi4pT1UjUJQ2DQfVOwrSXCiCGVEEKqO5K28gU+fP0q0xiMu6U6J16cSUdRD5kIBaXLFTQKgkW5WhF1ZUTtK88hSaIOLiZ5JUlrY+AYS4o0lw2SZb/l0LYFHaDhmoJWGGp3k8gSMoGANiLATNJN6B9P9IL26pTPbSDSThUHk91WQdQpW7IPhP4TmsbAvvgng2L3hmsy0qr2FIyv8B55LpNyDwOHYAAAAASUVORK5CYII=';
export const telecomIconSrc =
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAABxJJREFUeF7tmnuMXFUdxz9nprSQghgNhmeoUqWCIVYehVJii1EeaQ1K2qSdOzv3tkWMvIIFgmBim5BW5dUoj5R2d+50zpSk/cMHklWQUOUhUYGiIJaQQEKtIamUN7Ru58eemdnZ3c59nDszd5vN7kn2n53f4/v73t8553d/v6uY4EtN8PiZJGAyAyY4A5NbYIInwOQhOD62gFM+DgZmMrW6g74V73Uzaw8dAXl/BchcRH0B5E9I5gUqhV+FBuf4jwOzgNeB1xCeRcmzaG97J4SMPQFO39eQ7FqUXBQAvB9kHdp7ouU3p7ga1E8CdHYDWxB+T8V9LCkZ6RKQ23gilSt2NUE5xYtBFYFjI4EKF1FxHxkl01NaSFW+D3wTmBqi/woi91Px1tsSkQ4B5imTWYpwMhV3SQ3MsuJXySiTxp+OBydvDqb4Iire31ozoffUmm3UFcDxwbZkDdpbHe+HLt8C5gkLy1AqB2RqALRbJ9nxzf6+zAZUQ+Y5dr02h+1rBgJ18n1zkMwzofZEfkTF+2mcv+5kQK64HJXJgVzYcPg2Qi+HyY/xvY/JF12klvoJV/VG9PI7Ig7G3wKLwo3Kd9Der6OcdkbA4q1HMu1Ds99WDDuRNbB/A/rK/w7vfb8fuNgi+neA51Ecg3A6sIsD+2bz4JV7grPAvwNhVYTdp9DuvHQIWOafSQYTfMOBeh+qi1quJadvLmSesgj+YciuQud3ktOnwcBqlNwXec05fgnoCbet9qALx3SfAMdfOniYmeA/VzeunkYXzg905JTWg1wXQ8AHqMy5lHtetCBqWMTx/w6cGaGzG+2e0F0CDr6PFS9Rdr8S6KSn9FmqYoKKvvaQtWjv1oTB3w7cEKPzENr9dvcIyPn3oLiqadAEL9nL0PlXA53kij9AqXvjA8t+MdRGkLLjmxrB1AMxK/46tD8EHb8P8EZ5VNxC2V0XisLxtwBmu0StfrR7aVwotd97SrOpigZOs5DfDdmz0PnhwzhAyY6AfHExora26E+RL+N7/w4Fk/dfRmr1e/gSdS2Vwi9jA3L8y1E8gPCZWNmaQPzTN1J2BIQeNhGp21P6ElXZGQtWppxOxflXqFy9BP5e9H1/kLawrVmBxgCIJ8DxjfMNgXainl79pjBbIHxFH6DJA68/0vBDua0t4PjmzSy8mAgjIV9ah8jNMQ+gF+2ubMrkiucC81Hq65aF08Hm30O7n4rNuhECNhlg3uYi71LgkdrhtMUrN207fkyZWntaKxE+BhYM9gQWgOkNtL22o90FSbVtCHgfmG5nWJkT93mQ3wDm6X/eTq9DKcWdlN24miDQiQ0BfwXO7hBiWuqPgtyO9h5t14EFAaGdmHZ9dq4nvIFSP0cX7unUmAUBpiF54M+Db/YzO3XWBf3dIBthyoa4AsfWVzwBxlLO/waKP9oaTUGu64EPYbQjwEg7xfmNpuT8FAJsNSm8hcL0EfqZNtBP78q30vBrT8CQd1OSwtBfWHOyTaxqJ8iTwONpBj0SXHICmkRsmgnZy0EtRHHyYAvspMRRC6+jzLVZ/QMy9YnIkjixcTuF9gk42L5bPJb/M4MMM6gyA6XC3xKHdIcapnZYU5HqHgEj4S0tnUFWXohFnFEnsrnwn1i5FAXSIWB571Hsz+4FspHYq2oOWwqm0DpkKx0CareGH/8OIeq7kfPAkbT0bJpNJrsX3zOzwa6tFAkoPgNqTiRSxdWU3fCWWb54KaKcRuPzHbR7TtcibxhKkQB/42Bff/hVNxC53IX2wvv6TumHIHc2VDej3cI4IqDvasjEtbqeRLsXhAbl+JuaQ5e4/mObzKSXAfneeUi2dcw9ugrZx553j6b/2n2B+B3/OWB2/bf4MVc7HKRHwOJ7j2Ta9PivOZS6gHLBVH+jl1M+FQ6MaLhmZ9WmRl1e6RFQvwlMYMETo2YgahW6cFdLXDn/JhQ/a/x/F9pNXmlakJUuAbnizbEVoeIvlN25rRkwiryH0e5Ci3gSi6RLQL40D5Hoc8BAVrKEsretib7eCn9oRDTL0O6DiaOzUEiXgPo2+CcQPDscAqjU78hW8/je27V/5fz/oZoDkB1ot3EQWkSUUCR9AnL+rShus8C1A+R6qE2gRo60b0S74R9JWBiOEkmfgIJ/CgcwWXBEG1j3QPaMbrW/gvynT0B9G5hT/vrEBCjWU3aT6yVwNDYELN56BId/+BjCefbY5E0ymW+xufAPe53kkmNDgMGV77sQydh/yFiVnlGTpuSxWWmMHQE1EkLG7C1Q7UbbVhHGCI0tAcMk3B0+bxy74GslSDdYTGzDLc5iQK0FLgEOBz4aLJnNmOvuTj9+Torl0BAwhPKaX0xj71HnsW/602xbsj8p+G7IH1oCuhFBhzYmCeiQwHGvPpkB4/4RdhjAZAZ0SOC4V5/wGfAJz60RXwYlqooAAAAASUVORK5CYII=';

export const supportCarrierOpts = [
  { label: '中国移动', value: 1, icon: mobileIconSrc },
  { label: '中国联通', value: 2, icon: unicomIconSrc },
  { label: '中国电信', value: 3, icon: telecomIconSrc },
  { label: '虚拟', value: 4 },
  { label: '未知', value: 5 },
];

export type TypeTab = 'nameList' | 'taskList' | 'batchList';

export const outTimeOptions = [
  {
    key: 1,
    label: '坐席振铃超时未接自动回收',
  },
  {
    key: 2,
    label: '坐席振铃超时未接自动回收',
  },
];

export const autoCommitOptions = [
  {
    key: 1,
    label: '自动提交',
  },
  {
    key: 2,
    label: '自动提交',
  },
  {
    key: 3,
    label: '手动提交',
  },
];

export const callLossOpts = [
  { label: '是', value: 1 },
  { label: '否', value: 0 },
];
