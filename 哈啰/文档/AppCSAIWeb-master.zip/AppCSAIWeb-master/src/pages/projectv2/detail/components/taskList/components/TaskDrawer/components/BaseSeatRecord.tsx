import {
  SeatStatisticsRes,
  TaskDetailObj,
  saveTaskMultiple,
  querySeatStatisticsInfo,
  queryAverageWaitSeconds,
  TaskSeatWaitRes,
  queryTaskSeatWaitInfo,
  saveAutoadvice,
  // 强制签入列表
  singDeat,
  // 强制签出  taskGuid= currentTask?.taskGuid  seatGuid
  singLogut,
} from '@/api/projectv2/task';
import React, { useEffect, useRef, useState } from 'react';
import BaseRecord from './BaseRecord';
import {
  Button,
  Empty,
  Form,
  InputNumber,
  Modal,
  Pagination,
  Popover,
  Space,
  Spin,
  Switch,
  Tabs,
  message,
  Tooltip,
  Input,
  Popconfirm,
} from 'antd';
import {
  EditOutlined,
  EyeOutlined,
  MessageFilled,
  InfoCircleOutlined,
} from '@ant-design/icons';
import { text1Tooltip } from '@/utils/format';
import { LAYOUTLABEL } from '@/constants/processconfig';
import { useModel } from '@umijs/max';
//import {}
import { debounce } from 'lodash';
import styles from '../index.less';

interface Prop {
  currentTask: TaskDetailObj;
  taskType: number;
  handleOk: () => void;
}

const BaseSeatRecord: React.FC<Prop> = ({
  currentTask,
  taskType,
  handleOk,
}) => {
  // 备注编辑
  const [multipleOpen, setMultipleOpen] = useState(false);
  const [form] = Form.useForm();
  const { autoAdjustConcurrencyTime } = useModel('projectv2.model');

  const [accessKey, setAccessKey] = useState('1');
  const [seatListLoading, setSeatListLoading] = useState(false);
  // 座席统计数据
  const [seatStatisticsList, setSeatStatisticsList] = useState<
    SeatStatisticsRes['data']
  >([]);
  // 分页展示座席统计数据
  const [showSeatList, setShowSeatList] = useState<SeatStatisticsRes['data']>(
    [],
  );
  // 15分钟内平均等待时长
  const [averageWaitSeconds, setAverageWaitSeconds] = useState<string>();

  // 当前排队座席信息
  const [taskSeatWaitloading, setTaskSeatWaitloading] = useState(false);
  const [taskSeatWaitInfo, setTaskSeatWaitInfo] =
    useState<TaskSeatWaitRes['data']>();
  const [seatWaitOpen, setSeatWaitOpen] = useState(false);
  const seatWaitRef = useRef(null);
  // const [autoadviceLoading, setAutoadviceLoading] = useState(false);
  const [openType, setOpenType] = useState<string>('multiple');
  const [autoConcurrency, setAutoConcurrency] = useState<boolean>(false);
  // 签入列表
  const [singDeatList, setSingDeatList] = useState([]);
  const [newsingDeatList, setNewSingDeatList] = useState([]);
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  // （先不做分页）
  // const handleSeatScroll = debounce((target: HTMLDivElement) => {
  //   const { scrollHeight, scrollTop, clientHeight } = target || {};
  //   if (scrollHeight - scrollTop - clientHeight < 1) {
  //     console.log('e');
  //   }
  // }, 500);

  // fetch任务下座席统计数据
  const fetchSeatStatisticsInfo = async () => {
    setSeatListLoading(true);
    const res = await querySeatStatisticsInfo({
      taskGuid: currentTask?.taskGuid,
    });
    setSeatStatisticsList(res?.data);
    setShowSeatList([...(res?.data || [])].slice(0, 20));
    setSeatListLoading(false);
  };

  // fetch任务下座席统计数据
  const fetchAverageWaitSeconds = async () => {
    const res = await queryAverageWaitSeconds({
      taskGuid: currentTask?.taskGuid,
    });
    setAverageWaitSeconds(res?.data);
  };

  // fetch当前排队座席信息
  const fetchTaskSeatWaitInfo = async () => {
    setTaskSeatWaitloading(true);
    const res = await queryTaskSeatWaitInfo({
      taskGuid: currentTask?.taskGuid,
    });
    setTaskSeatWaitInfo(res?.data);
    setTaskSeatWaitloading(false);
  };

  // fetch页面上显示数据的接口
  const fetchPageAllApi = () => {
    fetchSeatStatisticsInfo();
    fetchAverageWaitSeconds();
    fetchTaskSeatWaitInfo();
  };

  // tabs change
  const handleChangeAccessKey = (e: string) => {
    if (e === '2' && currentTask?.taskGuid) {
      fetchPageAllApi();
    }
    setAccessKey(e);
  };

  // 关闭编辑倍数modal
  const handleEditClose = () => {
    setMultipleOpen(false);
    setOpenType('');
    form.resetFields();
  };

  // 停止轮询
  const stopSeatWaitLoop = () => {
    if (seatWaitRef.current) {
      clearInterval(seatWaitRef.current);
      seatWaitRef.current = null;
    }
  };

  // 轮询查座席等待信息
  const startSeatWaitLoop = () => {
    stopSeatWaitLoop();
    seatWaitRef.current = setInterval(() => {
      fetchPageAllApi(); // 座席情况接口轮询
    }, 2000);
  };

  // change排队信息open
  const handleChangeSeatOpen = (open: boolean) => {
    setSeatWaitOpen(open);
    if (open) {
      startSeatWaitLoop();
    } else {
      stopSeatWaitLoop();
    }
  };

  // 打开编辑并发倍数
  const handleMultipleOpen = (type) => {
    setMultipleOpen(true);
    setOpenType(type);
    setAutoConcurrency(currentTask?.autoAdviceLoadCount);
    // 打开编辑弹框需要刷新详情，因为弹框注解字段在详情中
    handleOk?.();
    form.setFieldsValue({
      multiple: Number(currentTask?.multiple) || undefined,
      autoAdviceLoadCount: currentTask?.autoAdviceLoadCount,
      autoAdjustCoefficient: currentTask?.autoAdjustCoefficient,
    });
  };

  // 提交倍数
  const handleOkMultiple = async () => {
    if (!currentTask?.taskGuid) {
      message.error('任务异常，请刷新重试');
    }
    const res = await form.validateFields();
    const params = {
      taskGuid: currentTask?.taskGuid,
      ...res,
    };
    let apiRes;
    if (openType === 'multiple') {
      apiRes = await saveTaskMultiple(params);
    } else {
      apiRes = await saveAutoadvice(params);
    }
    if (apiRes?.success) {
      handleOk?.();
      setMultipleOpen(false);
      message.success('调整完成');
    }
  };

  useEffect(() => {
    return stopSeatWaitLoop;
  }, []);
  // 自定义验证器，确保输入是2位小数
  const validateDecimal = (rule, value) => {
    const regex = /^\d+(\.\d{1,2})?$/;
    if (!regex.test(value)) {
      return Promise.reject(new Error('输入不得超过2位小数'));
    }
    return Promise.resolve();
  };
  /**
   * 强制签入列表
   * */
  const getsingDeat = async () => {
    const res = await singDeat({
      taskGuid: currentTask?.taskGuid,
    });
    if (res?.success) {
      setSingDeatList(res?.data);
      setNewSingDeatList(res?.data);
    }
  };
  /**
   * 强制签出
   * */
  const setSingLogut = async (seatGuid) => {
    const res = await singLogut({
      taskGuid: currentTask?.taskGuid,
      seatGuid,
    });
    if (res?.success) {
      message.success('强制签出成功');
      getsingDeat();
    }
  };
  /**
   * 强制签出弹层
   */
  const getCheckoutOpen = () => {
    setCheckoutOpen(true);
    getsingDeat();
  };
  /**
   * 过滤 singDeatList数据
   */
  const setSearch = (value) => {
    if (value) {
      const getsingDeatList = JSON.parse(JSON.stringify(newsingDeatList));
      const newList = getsingDeatList.filter((item) => {
        console.log(value);
        return item.seatName.indexOf(value) !== -1;
      });
      setSingDeatList(newList);
    } else {
      setSingDeatList(newsingDeatList);
    }
  };

  return (
    <div className={styles.baseSeatRecord}>
      <div className={styles.seatConfig}>
        <div>
          <span>当前生效并发：</span>
          <span>{currentTask?.effectiveConcurrency}</span>
        </div>
        <div className={styles.seatConfigTop}>
          <Space>
            <div className={styles.numDesc}>
              = {currentTask?.multiple || 0} *空闲座席数（
              {currentTask?.waitSeatCount || 0}）
            </div>
            <Button
              type="link"
              icon={<EditOutlined />}
              onClick={() => handleMultipleOpen('multiple')}
            >
              编辑
            </Button>
          </Space>
          <div className={styles.autoAdviceContent}>
            <div className={styles['autoAdviceTop']}>
              <div>
                {currentTask?.autoAdviceLoadCount && (
                  <span>手工系数：{currentTask?.autoAdjustCoefficient}</span>
                )}
              </div>

              <div>
                <span>自动调整并发：</span>
                <Switch disabled checked={currentTask?.autoAdviceLoadCount} />
                <Button
                  type="link"
                  icon={<EditOutlined />}
                  onClick={() => handleMultipleOpen('auto')}
                >
                  编辑
                </Button>
              </div>
            </div>
            {currentTask?.autoAdviceLoadCount && (
              <div className={styles['autoAdviceTips']}>
                <div className={styles['autoAdviceTipsLeft']}>
                  <span className={styles['left-top']}>
                    当前空闲坐席数({currentTask?.waitSeatCount || 0}) - 在途数(
                    {currentTask?.onWayCount}) + (
                    {currentTask?.predictRingDuration})秒后挂断空闲坐席数(
                    {currentTask?.exceedRingDurationCount})
                  </span>
                  <span className={styles['left-bottom']}>
                    接通率({currentTask?.putThoughRate}) x 触发转接率(
                    {currentTask?.triggerTransferRate})
                  </span>
                </div>
                <span style={{ marginLeft: '5px' }}>
                  {' '}
                  * 手工系数({currentTask?.autoAdjustCoefficient})
                </span>
              </div>
            )}
          </div>
        </div>
        {/* <div>
          当前并发：
          <span className={styles.concurrentNum}>
            {currentTask?.actualLoadCount || 0}
          </span>
        </div> */}
      </div>
      <Tabs
        accessKey={accessKey}
        destroyInactiveTabPane
        onChange={handleChangeAccessKey}
        items={[
          {
            label: `统计数据`,
            key: '1',
            children: (
              <BaseRecord taskType={taskType} currentTask={currentTask} />
            ),
          },
          {
            label: `座席情况`,
            key: '2',
            children: (
              <>
                <Space size="middle">
                  <div>近15分钟平均等待时长：{averageWaitSeconds}</div>
                  <div>当前排队：{taskSeatWaitInfo?.length || 0}</div>
                  <Popover
                    open={seatWaitOpen}
                    onOpenChange={handleChangeSeatOpen}
                    placement="bottomLeft"
                    title="排队列表"
                    overlayClassName={styles.standWrap}
                    content={
                      <div
                        className={styles.standList}
                        // onScroll={(e: any) => handleSeatScroll(e.target)}
                      >
                        <Spin spinning={taskSeatWaitloading}>
                          {taskSeatWaitInfo?.length > 0 ? (
                            <>
                              {taskSeatWaitInfo.map((item) => (
                                <div
                                  className={styles.standItem}
                                  key={item.seatGuid}
                                >
                                  <div className={styles.standSeat}>
                                    <div>{item.seatName}</div>
                                    <div>{item.time}</div>
                                  </div>
                                  <div className={styles.skillGroup}>
                                    {item.skillGroupName}
                                  </div>
                                </div>
                              ))}
                            </>
                          ) : (
                            <Empty />
                          )}
                        </Spin>
                      </div>
                    }
                    trigger="click"
                  >
                    <Button type="link" icon={<EyeOutlined />}>
                      查看
                    </Button>
                  </Popover>
                  <Button type="primary" danger onClick={getCheckoutOpen}>
                    强制退出
                  </Button>
                </Space>
                <Spin spinning={seatListLoading}>
                  {seatStatisticsList?.length ? (
                    <div className={styles.cardWrap}>
                      {showSeatList?.map((item, index) => (
                        <div className={styles.card} key={String(index)}>
                          <div className={styles.topSkillBox}>
                            <MessageFilled className={styles.cardIcon} />
                            {text1Tooltip(item.skillGroupName)}
                          </div>
                          <Space size={12}>
                            <div className={styles.sign}>
                              <div className={styles.cardLabel}>当前签到</div>
                              <div className={styles.cardValue}>
                                {text1Tooltip(item.signInSeatCount)}
                              </div>
                            </div>
                            <div className={styles.distribute}>
                              <div className={styles.cardLabel}>已下发</div>
                              <div className={styles.cardValue}>
                                {text1Tooltip(item.issuedPersonListCount)}
                              </div>
                            </div>
                          </Space>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <Empty
                      style={{ marginTop: 30 }}
                      description="暂无座席统计数据"
                    />
                  )}
                </Spin>
                {seatStatisticsList?.length > 0 && (
                  <Pagination
                    className={styles.paginationBox}
                    size="small"
                    defaultCurrent={1}
                    pageSize={20}
                    total={seatStatisticsList.length}
                    onChange={(e) => {
                      setShowSeatList(
                        seatStatisticsList.slice((e - 1) * 20, e * 20),
                      );
                    }}
                    showTotal={(total) => `总共 ${total} 组`}
                  />
                )}
              </>
            ),
          },
        ]}
      />
      {/**
       * 强制签出
       */}
      <Modal
        title="强制退出"
        open={checkoutOpen}
        width={400}
        forceRender
        onCancel={() => setCheckoutOpen(false)}
        footer={null}
        className={styles['multiplModal']}
      >
        <div>
          <div className={styles.search}>
            <Input
              placeholder="请输入坐席名称"
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className={styles.checkoutBox}>
            {singDeatList?.length > 0 ? (
              singDeatList.map((item, index) => (
                <Popconfirm
                  key={String(index)}
                  placement="topLeft"
                  title={
                    <div>
                      点击后无论座席是否在工作状态,都将
                      <div>
                        强制登出,确认要登出座席
                        {item?.seatName}吗？
                      </div>
                    </div>
                  }
                  onConfirm={() => setSingLogut(item?.seatGuid)}
                  okText="确认"
                  cancelText="取消"
                >
                  <div className={styles.item}>{item?.seatName}</div>
                </Popconfirm>
              ))
            ) : (
              <Empty style={{ marginTop: 30 }} description="暂无数据" />
            )}
          </div>
        </div>
      </Modal>
      {/* 编辑并发倍数 */}
      <Modal
        title="编辑"
        open={multipleOpen}
        forceRender
        onCancel={handleEditClose}
        onOk={handleOkMultiple}
        className={styles['multiplModal']}
      >
        <Form form={form} {...LAYOUTLABEL}>
          {openType === 'multiple'
            ? [
                <Form.Item label="外呼并发" key="multiple">
                  <Space align="center">
                    <Form.Item
                      name="multiple"
                      rules={[{ required: true, message: '请输入' }]}
                      noStyle
                    >
                      <InputNumber
                        min={1}
                        max={[2].includes(taskType) ? 300 : 800}
                        placeholder={`1-${
                          [2].includes(taskType) ? '300' : '800'
                        }`}
                      />
                    </Form.Item>

                    <span>倍超并发外呼</span>
                  </Space>
                </Form.Item>,
                currentTask?.callCompletingRate && (
                  <div style={{ color: '#777' }}>
                    注：当前外呼接通率{currentTask?.callCompletingRate}%，建议
                    {currentTask?.adviceMultiple}倍超并发外呼
                  </div>
                ),
              ]
            : [
                <Form.Item
                  label={
                    <Tooltip
                      placement="topLeft"
                      title={
                        <>
                          <span>
                            (当前空闲坐席数 - 在途数 +
                            (N平均振铃时长)秒后挂断空闲坐席数) 接通率 x
                            触发转接率
                          </span>
                          <span>*手工系数</span>
                        </>
                      }
                    >
                      <InfoCircleOutlined style={{ marginRight: '10px' }} />
                      <span>自动调整并发</span>
                    </Tooltip>
                  }
                  key="autoAdviceLoadCount"
                  name="autoAdviceLoadCount"
                  rules={[{ required: true }]}
                  valuePropName="checked"
                  help={`自动并发将在任务执行中状态下保持${autoAdjustConcurrencyTime}分钟后执行`}
                  style={{ marginBottom: '24px' }}
                >
                  <Switch
                    onChange={(e: boolean) => setAutoConcurrency(e)}
                    checkedChildren="是"
                    unCheckedChildren="否"
                  />
                </Form.Item>,
                autoConcurrency && (
                  <Form.Item noStyle>
                    <Form.Item
                      label="手工系数"
                      name="autoAdjustCoefficient"
                      rules={[
                        {
                          validator: validateDecimal,
                          message: '输入不得超过2位小数',
                        },
                      ]}
                    >
                      <InputNumber
                        min={0}
                        max={999}
                        style={{
                          width: '180px',
                        }}
                      />
                    </Form.Item>
                  </Form.Item>
                ),
              ]}
        </Form>
      </Modal>
    </div>
  );
};

export default BaseSeatRecord;
