import {
  FollowRecordRes,
  RosterDetail,
  getFollowRecord,
} from '@/api/projectv2/nameInfo';
import {
  Divider,
  Empty,
  Popover,
  Radio,
  Space,
  Spin,
  Steps,
  Tag,
  Typography,
} from 'antd';
import React, { useCallback, useEffect, useState } from 'react';
import { formatMomentDate } from '@/utils/format';
import FollowModal from './FollowModal';
import SmsSimplePreview from '@/components/smsSimplePreview';
import {
  ContainerOutlined,
  MailOutlined,
  PlaySquareFilled,
} from '@ant-design/icons';
import PlayAudio from '@/components/PlayAudio';
import { outTimeOptions, autoCommitOptions } from '../../config';
import styles from './index.less';

interface Prop {
  data: RosterDetail['rosterInfoDTO'];
}

const FollowRrcord: React.FC<Prop> = ({ data }) => {
  const [record, setRecord] = useState<FollowRecordRes['data']>();
  const [followLoading, setFollowLoading] = useState(false);
  const [recordType, setRecordType] = useState<number | undefined>(undefined);
  // 预览表单
  const [curFormData, setCurFormData] = useState<FollowRecordRes['data'][0]>();
  // 试听语音
  const [curPlayUrl, setCurPlayUrl] = useState<string>();

  // fetch跟进记录
  const fetchFollowRecord = async () => {
    const params = {
      rosterGuid: data.guid,
      projectGuid: data.projectGuid,
      recordType,
    };
    setFollowLoading(true);
    const res = await getFollowRecord(params);
    setRecord(res?.data);
    setFollowLoading(false);
  };

  const renderOuttimeFlag = (flag: number) => {
    return outTimeOptions.find((item) => item.key === flag)?.label;
  };

  const renderAutoCommitFlag = (flag: number) => {
    return autoCommitOptions.find((item) => item.key === flag)?.label;
  };

  useEffect(() => {
    if (data?.projectGuid) {
      fetchFollowRecord();
    }
  }, [data?.projectGuid, recordType]);

  return (
    <>
      <div className={styles.followBox}>
        <Radio.Group
          value={recordType}
          onChange={(e) => setRecordType(e.target.value)}
          className={styles.types}
        >
          <Radio.Button value={undefined}>全部</Radio.Button>
          <Radio.Button value={1}>人工</Radio.Button>
          <Radio.Button value={2}>任务</Radio.Button>
          <Radio.Button value={3}>手动</Radio.Button>
        </Radio.Group>
        <Spin spinning={followLoading}>
          {record?.length > 0 ? (
            <Steps
              progressDot
              direction="vertical"
              items={record.map((item) => ({
                title: formatMomentDate(item.callTime),
                status: 'finish',
                description: (
                  <div className={styles.taskInfo}>
                    {/* 任务信息 */}
                    <Space.Compact block className={styles.infoItem}>
                      <div>{item.taskTypeDesc}</div>
                      <Divider type="vertical" className={styles.line} />
                      <div>{item.taskName}</div>
                    </Space.Compact>
                    <Space.Compact block className={styles.infoItem}>
                      <div>{item.callResultDesc}</div>
                      {item.callDuration ? (
                        <>
                          <Divider type="vertical" className={styles.line} />
                          <span>{item.callDuration}秒</span>
                        </>
                      ) : null}
                      {/* 接通状态才显示链接(callResult === 18) */}
                      {item.callRecordingUrl && item.callResult === 18 && (
                        <PlaySquareFilled
                          className={styles.actionIcon}
                          onClick={() => setCurPlayUrl(item.callRecordingUrl)}
                        />
                      )}
                    </Space.Compact>
                    {item.intentClassifyType && (
                      <Space.Compact block className={styles.infoItem}>
                        <div>{item.intentClassifyType}类</div>
                        <Divider type="vertical" className={styles.line} />
                        <div>{item.intentClassifyTypeDesc}</div>
                      </Space.Compact>
                    )}
                    {/* 振铃超时坐席未接/振铃坐席拒接 */}
                    {item?.outtimeFlag && (
                      <Typography.Text type="success">
                        {renderOuttimeFlag(item.outtimeFlag)}
                      </Typography.Text>
                    )}
                    {/* 座席跟进信息 */}
                    {item.taskType !== 1 && (
                      <div className={styles.seatInfo}>
                        <div className={styles.seatTop}>
                          <div className={styles.seatLeft}>
                            <div>{item.seatName}</div>
                            <Divider type="vertical" className={styles.line} />
                            <div>跟进节点 {item.followupNodeName ?? '-'}</div>
                            <Divider type="vertical" className={styles.line} />
                            <div className={styles.seatFollowTime}>
                              下次跟进时间{' '}
                              {item?.nextFollowTime
                                ? formatMomentDate(item.nextFollowTime)
                                : '-'}
                            </div>
                            <div className={styles.actionIcons}>
                              {item?.formFields?.length > 0 && (
                                <ContainerOutlined
                                  className={styles.actionIcon}
                                  onClick={() => setCurFormData(item)}
                                />
                              )}
                              {item?.autocommitFlag && (
                                <Typography.Text
                                  type="success"
                                  style={{ marginLeft: '12px' }}
                                >
                                  {renderAutoCommitFlag(item.autocommitFlag)}
                                </Typography.Text>
                              )}
                              {item?.messageRecord && (
                                <Popover
                                  content={
                                    <SmsSimplePreview
                                      curSms={item.messageRecord}
                                    />
                                  }
                                  placement="rightTop"
                                  overlayClassName="smsConfigsPopover"
                                  trigger={'click'}
                                >
                                  <MailOutlined className={styles.actionIcon} />
                                </Popover>
                              )}
                            </div>
                          </div>
                          <Tag
                            color={
                              item.followupResult === 0
                                ? 'processing'
                                : item.followupResult === 1
                                ? 'success'
                                : 'error'
                            }
                            className={styles.seatTag}
                          >
                            {item.followupResultDesc}
                          </Tag>
                        </div>
                        {item.remark && (
                          <div className={styles.seatRemark}>{item.remark}</div>
                        )}
                      </div>
                    )}
                  </div>
                ),
              }))}
            />
          ) : (
            <Empty style={{ marginTop: 30 }} />
          )}
        </Spin>
      </div>
      {/* 预览表单 */}
      {curFormData && (
        <FollowModal
          curFormData={curFormData}
          onCancel={() => setCurFormData(undefined)}
        />
      )}
      {/* 试听音频 */}
      <PlayAudio
        visible={!!curPlayUrl}
        url={curPlayUrl}
        showDownLoad={false}
        cancel={useCallback(() => setCurPlayUrl(undefined), [])}
      />
    </>
  );
};

export default FollowRrcord;
