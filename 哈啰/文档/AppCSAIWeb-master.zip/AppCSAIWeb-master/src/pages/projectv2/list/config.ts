export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 100,
};

export const statusOpts = [
  { label: '进行中', value: 1, badgeStatus: 'processing' },
  { label: '已完结', value: 2, badgeStatus: 'default' },
];

export const formatStatus = (val: number, prop: 'label' | 'badgeStatus') => {
  const cur = statusOpts.find((item) => item.value === val);
  return cur?.[prop];
};

export const getInterceptDesc = (type: string) => {
  switch (type) {
    case '1':
      return '根据任务关联话术走平台限频策略';
    case '2':
      return '根据配置的行业场景走平台限频策略';
    case '3':
      return '根据任务关联话术走平台黑名单策略';
    case '4':
      return '根据配置的行业场景走平台黑名单策略';
  }
};

export const interceptOptions = [
  { label: '开启', value: 1 },
  { label: '关闭', value: 0 },
];
