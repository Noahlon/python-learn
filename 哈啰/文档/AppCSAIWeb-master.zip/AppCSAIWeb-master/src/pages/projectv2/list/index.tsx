import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  Badge,
  BadgeProps,
  Button,
  Card,
  Empty,
  Modal,
  Pagination,
  Space,
  Spin,
} from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import {
  queryProjectList,
  ProjectListObj,
  ProjectListParams,
} from '@/api/projectv2/projectInfo';
import { history, useAccess, useModel } from '@umijs/max';
import SearchProject from './components/SearchProject';
import UpdateModal from './components/UpdateModal';
import BaseConfig from './components/BaseConfig';
import { formatEmptyData, text1Tooltip } from '@/utils/format';
import { DEFAULT_QUERY_PARAMS, formatStatus } from './config';
import { toThousands } from '@/utils';
import styles from './index.less';

const ProjectList: React.FC = () => {
  const { fetchTenantOpts } = useModel('common');
  const { setProjectDetail } = useModel('projectv2.model');
  const access = useAccess();
  const [tableData, setTableData] = useState<ProjectListObj[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  // pagination
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [tableTotal, setTableTotal] = useState<number>();
  // 搜索params
  const queryParams = useRef(DEFAULT_QUERY_PARAMS);
  // 项目列表新增/编辑
  const [createOpen, setCreateOpen] = useState(false);
  const [updateOpen, setUpdateOpen] = useState(false);
  const [currentGuid, setCurrentGuid] = useState<string>(undefined);
  // 创建完成后
  const [isAddAfter, setIsAddAfter] = useState(false);

  // fetch项目列表列表
  const fetchProjectList = async () => {
    const params = {
      ...queryParams.current,
    };

    setTableLoading(true);
    const res = await queryProjectList(params);
    if (res?.data) {
      setTableData(res.data?.list);
      setTableTotal(res?.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // 页面页数change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchProjectList();
  };

  // 搜索
  const handleSearch = (res: ProjectListParams) => {
    queryParams.current = { ...queryParams.current, ...res };
    handlePageChange(1);
  };

  // 重置
  const handleReset = () => {
    queryParams.current = DEFAULT_QUERY_PARAMS;
    setPagination(DEFAULT_QUERY_PARAMS);
    fetchProjectList();
  };

  // 新增/编辑刷新项目列表
  const handleOk = (guid?: string) => {
    if (!currentGuid) {
      handlePageChange(1);
      setCreateOpen(false);
      // 新建后打开编辑弹框
      setIsAddAfter(true);
      setCurrentGuid(guid);
      setUpdateOpen(true);
    } else {
      fetchProjectList();
    }
  };

  const renderActions = useCallback(
    (item: ProjectListObj) => {
      const actions = [];
      {/*Call-Project2.0-Detail-Btn */}
      if (access?.authCodeList?.includes('Call-Project2.0-Detail-Btn')) {
        actions.push(
          <span
            key="detail"
            onClick={() => {
              history.push(`/projectv2/detail?guid=${item.guid}`);
            }}
          >
            详情
          </span>,
        );
      }
      {/* Call-Project2.0-Edit*/}
      if (access?.authCodeList?.includes('Call-Project2.0-Edit')) {
        actions.push(
          <div
            key="edit"
            onClick={() => {
              setCurrentGuid(item.guid);
              setUpdateOpen(true);
            }}
          >
            编辑
          </div>,
        );
      }

      return actions;
    },
    [access?.authCodeList],
  );

  useEffect(() => {
    fetchProjectList();
    fetchTenantOpts(2);
  }, []);

  return (
    <>
      <div className={styles.projectListWrap}>
        {/* 搜索区域 */}
        <SearchProject onSearch={handleSearch} onReset={handleReset} />
        {/* Call-Project2.0-Add */}
        {access?.authCodeList?.includes('Call-Project2.0-Add') && (
          <div className={styles.addButton}>
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => {
                setCurrentGuid(undefined);
                setProjectDetail(undefined);
                setCreateOpen(true);
              }}
            >
              创建项目
            </Button>
          </div>
        )}
        {/* 项目列表列表 */}
        <Spin spinning={tableLoading} wrapperClassName={styles.listContent}>
          {tableData?.length ? (
            <Space size={[16, 24]} wrap className={styles.cardBox}>
              {tableData.map((item) => (
                <Card key={item.guid} actions={renderActions(item)}>
                  <div className={styles.cardContent}>
                    <div className={styles.titleBox}>
                      <h3 className={styles.title}>
                        {text1Tooltip(item.projectName)}
                      </h3>
                      <Space size={5}>
                        <Badge
                          status={
                            formatStatus(
                              item?.projectStatus,
                              'badgeStatus',
                            ) as BadgeProps['status']
                          }
                        />
                        {formatStatus(item?.projectStatus, 'label')}
                      </Space>
                    </div>
                    <div className={styles.cardItem}>
                      <div className={styles.cardLabel}>租户：</div>
                      {text1Tooltip(item.tenantName)}
                    </div>
                    <div className={styles.cardItem}>
                      <div className={styles.cardLabel}>总名单数：</div>
                      {toThousands(item.totalRosterCount, true)}
                    </div>
                    <div className={styles.cardItem}>
                      <div className={styles.cardLabel}>名单批次数：</div>
                      {formatEmptyData(item.rosterBatchCount)}
                    </div>
                    <div className={styles.cardItem}>
                      <div className={styles.cardLabel}>
                        执行中任务/总任务数：
                      </div>
                      {item.runningTaskCount || item.totalTaskCount
                        ? `${item.runningTaskCount}/${item.totalTaskCount}`
                        : '-'}
                    </div>
                    <div className={styles.cardItem}>
                      <div className={styles.cardLabel}>预计结项日期：</div>
                      {formatEmptyData(item.closingDate)}
                    </div>
                  </div>
                </Card>
              ))}
            </Space>
          ) : (
            <Empty />
          )}
        </Spin>
        {tableData?.length > 0 && (
          <Pagination
            current={pagination.pageNum}
            showSizeChanger={true}
            pageSize={pagination.pageSize}
            total={tableTotal}
            showTotal={(total) => `总共 ${total} 条`}
            onChange={handlePageChange}
            className={styles.paginationBox}
          />
        )}
      </div>
      {/* 新增modal */}
      <Modal
        open={createOpen}
        width="650px"
        title="新建"
        destroyOnClose
        footer={null}
        onCancel={() => setCreateOpen(false)}
      >
        <BaseConfig
          onOk={useCallback(handleOk, [currentGuid])}
          onCancel={useCallback(() => {
            setCreateOpen(false);
            setIsAddAfter(false);
          }, [])}
        />
      </Modal>
      {/* 编辑modal */}
      <UpdateModal
        open={updateOpen}
        guid={currentGuid}
        isAddAfter={isAddAfter}
        onOk={useCallback(handleOk, [currentGuid])}
        onCancel={useCallback(() => {
          setUpdateOpen(false);
          setProjectDetail(undefined);
          setIsAddAfter(false);
        }, [])}
      />
    </>
  );
};
export default ProjectList;
