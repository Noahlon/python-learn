import {
  Button,
  Cascader,
  DatePicker,
  Form,
  Input,
  InputNumber,
  Modal,
  Select,
  Switch,
  Tooltip,
  message,
  Radio,
} from 'antd';
import React, { memo, useEffect, useState } from 'react';
import { LAYOUTLABEL } from '@/constants/processconfig';
import { useModel } from '@umijs/max';
import { SmsTemplateObj, querySmsTemplate } from '@/api/smsTemplate';
import moment from 'moment';
import { InfoCircleOutlined } from '@ant-design/icons';
import {
  FormListRes,
  NodeListRes,
  ProjectUpdateParams,
  querySeatFormList,
  querySeatNodeList,
  saveProject,
  updateProjectInfo,
  updateProjectStatus,
} from '@/api/projectv2/projectInfo';
import { findAllSuppliers } from '@/api/lineSupplier';
import styles from '../index.less';

interface Prop {
  onOk: (guid?: string) => void;
  onCancel: () => void;
}

const BaseConfig: React.FC<Prop> = memo(({ onOk, onCancel }) => {
  const { tenantOpts } = useModel('common');
  const { projectDetail } = useModel('projectv2.model');
  const [form] = Form.useForm();
  const [smsTempOtps, setSmsTempOtps] = useState<SmsTemplateObj[]>([]);
  const [seatFormOpts, setSeatFormOpts] = useState<FormListRes['data']>([]);
  const [seatNodeOpts, setSeatNodeOpts] = useState<NodeListRes['data']>([]);
  const [lineOpts, setLineOpts] = useState([]); // 线路opts
  const [confirmLoading, setConfirmLoading] = useState(false);
  // 状态
  const [statusChecked, setStatusChecked] = useState(true);
  const [statusLoading, setStatusLoading] = useState(false);

  // 获取短信opts
  const fetchSmsTempOpts = async (tenant: number) => {
    const res = await querySmsTemplate({
      pageNum: 1,
      pageSize: 999,
      tenantList: [tenant],
      bpoVersion: 2,
    });
    if (res?.data) {
      setSmsTempOtps(res.data?.list);
    }
  };

  // 获取表单opts
  const fetchSeatFormOpts = async () => {
    const res = await querySeatFormList();
    setSeatFormOpts(res?.data || []);
  };

  // 获取节点opts
  const fetchSeatNodeOpts = async () => {
    const res = await querySeatNodeList();
    setSeatNodeOpts(res?.data || []);
  };

  // 获取线路opts
  const fetchAllSuppliers = async () => {
    const res = await findAllSuppliers({
      bpoVersion: 2,
    });
    if (res.data) {
      const opt = res.data?.map((item) => {
        const _children = [];
        if (item.callLineDTOList) {
          item.callLineDTOList.forEach((i) => {
            _children.push({ label: i.supporterLineName, value: i.guid });
          });
        }
        return {
          label: item.supplierName,
          value: item.guid,
          children: _children,
        };
      });
      setLineOpts(opt);
    }
  };

  // 状态change
  const handleChangeStatus = async (status: boolean) => {
    if (!status) {
      const params = {
        guid: projectDetail?.guid,
        projectStatus: 2,
      };
      setStatusLoading(true);
      const res = await updateProjectStatus(params);
      setStatusLoading(false);
      if (!res.success) {
        return;
      }

      Modal.confirm({
        title: '项目状态切换至已完结？',
        content: '完结后的项目名单无法继续外呼跟进',
        onOk: () => {
          setStatusChecked(status);
        },
      });
    } else {
      setStatusChecked(status);
    }
  };

  // 验证线路
  const handleValidatorLine = (_, val) => {
    if (!val?.length) return Promise.resolve();
    if (val?.length === 1) return Promise.reject('请选择正确线路');
    return Promise.resolve();
  };

  // 租户change
  const handleChangeTenant = (tenant: number) => {
    fetchSmsTempOpts(tenant);
    form.setFieldsValue({ smsGuidList: undefined });
  };

  // 添加/编辑
  const UpdateProject = async (params: ProjectUpdateParams) => {
    const isUpdate = !!projectDetail?.guid;
    setConfirmLoading(true);

    if (isUpdate) {
      params.guid = projectDetail?.guid;
    }
    const action = isUpdate ? updateProjectInfo : saveProject;
    const res = await action(params);

    if (res?.success) {
      message.success(isUpdate ? '基本信息保存成功' : '添加成功');
      if (isUpdate) {
        onOk?.();
      } else {
        setTimeout(() => {
          onOk?.(res?.data?.guid);
        }, 0);
      }
    }
    setConfirmLoading(false);
  };

  // 提交
  const handleSumit = async () => {
    let params = await form.validateFields();
    params.projectName = params.projectName?.trim();
    params.projectStatus = statusChecked ? 1 : 2;
    UpdateProject(params);
  };

  useEffect(() => {
    fetchSeatFormOpts();
    fetchSeatNodeOpts();
    fetchAllSuppliers();
  }, []);

  useEffect(() => {
    if (!!projectDetail) {
      const _info = JSON.parse(JSON.stringify(projectDetail));
      _info.smsGuidList = _info?.smsInfoList?.map(
        (item) => item.smsTemplateGuid,
      );
      form.setFieldsValue(_info);
      setStatusChecked(_info?.projectStatus === 1 ? true : false);
      if (_info.tenantCode) {
        fetchSmsTempOpts(_info.tenantCode);
      }
    } else {
      setStatusChecked(true);
      form.setFieldsValue({ projectStatus: 1, canCopyPhone: 0 });
    }
  }, [projectDetail?.guid]);

  const labelView = () => {
    return (
      <Tooltip placement="topLeft" title="名单下发达到有效期后会自动回收">
        <InfoCircleOutlined style={{ marginRight: '5px' }} />
        <span>下发有效期</span>
      </Tooltip>
    );
  };

  return (
    <Form form={form} {...LAYOUTLABEL} labelWrap>
      <Form.Item
        label="项目名称"
        name="projectName"
        rules={[{ required: true }]}
      >
        <Input maxLength={30} placeholder="请输入项目名称，限制30字" />
      </Form.Item>
      <Form.Item
        name="tenantCode"
        label="租户"
        rules={[{ required: true, message: '请选择租户' }]}
      >
        <Select
          placeholder="请选择租户"
          disabled={!!projectDetail?.guid}
          allowClear
          showSearch
          optionFilterProp="label"
          options={tenantOpts}
          onChange={handleChangeTenant}
        />
      </Form.Item>
      <Form.Item
        name="formGuid"
        label="跟进表单"
        rules={[{ required: true, message: '请选择跟进表单' }]}
      >
        <Select
          placeholder="请选择跟进表单"
          allowClear
          showSearch
          optionFilterProp="formName"
          fieldNames={{ label: 'formName', value: 'formGuid' }}
          options={seatFormOpts}
        />
      </Form.Item>
      <Form.Item
        name="followNodeSetGuid"
        label="跟进节点"
        rules={[{ required: true, message: '请选择跟进节点' }]}
      >
        <Select
          placeholder="请选择跟进节点"
          allowClear
          showSearch
          optionFilterProp="followNodeSetName"
          fieldNames={{
            label: 'followNodeSetName',
            value: 'followNodeSetGuid',
          }}
          options={seatNodeOpts}
        />
      </Form.Item>
      <Form.Item
        label="外呼线路"
        name="callLineGuidList"
        rules={[
          { required: true },
          { validator: (rule, value) => handleValidatorLine(rule, value) },
        ]}
      >
        <Cascader
          options={lineOpts}
          showSearch
          placeholder="请选择外呼线路"
          getPopupContainer={(triggerNode) =>
            triggerNode.parentElement || document.body
          }
        />
      </Form.Item>
      <Form.Item name="smsGuidList" label="营销短信">
        <Select
          placeholder="请选择营销短信"
          allowClear
          showSearch
          optionFilterProp="templateName"
          mode="multiple"
          options={smsTempOtps}
          fieldNames={{
            label: 'templateName',
            value: 'id',
          }}
        />
      </Form.Item>
      <Form.Item
        label="状态"
        required
        valuePropName="checked"
        rules={[{ required: true, message: '请选择状态' }]}
      >
        <Switch
          disabled={!projectDetail?.guid}
          checked={statusChecked}
          loading={statusLoading}
          onChange={handleChangeStatus}
          checkedChildren="进行中"
          unCheckedChildren="已完结"
        />
      </Form.Item>
      <Form.Item name="validityPeriod" label={labelView()}>
        <InputNumber
          min={1}
          max={99999}
          precision={0}
          addonAfter="天"
          placeholder="请输入1-99999的整数"
          style={{ width: '100%' }}
        />
      </Form.Item>
      <Form.Item
        name="closingDate"
        label="预计结项日期"
        getValueFromEvent={(...[, dateString]) => dateString}
        getValueProps={(value) => ({
          value: value ? moment(value) : undefined,
        })}
      >
        <DatePicker
          style={{ width: '100%' }}
          placeholder="请选择"
          disabledDate={(current) => {
            return current && current < moment().subtract(1, 'day');
          }}
        />
      </Form.Item>
      <Form.Item label="项目描述" name="projectDesc">
        <Input.TextArea
          maxLength={300}
          placeholder="请输入项目描述，限制300字"
        />
      </Form.Item>
      <Form.Item
        label={
          <div>
            <div className="notice">复制明文号码</div>
            <div className={styles.labelDesc}>(仅支持复制客户自有名单)</div>
          </div>
        }
        name="canCopyPhone"
      >
        <Radio.Group>
          <Radio value={1}>可复制</Radio>
          <Radio value={0}>不可复制</Radio>
        </Radio.Group>
      </Form.Item>
      <Form.Item noStyle>
        <div className={styles.editModalFooter}>
          <Button onClick={onCancel} className={styles.cancelBtn}>
            取消
          </Button>
          <Button loading={confirmLoading} type="primary" onClick={handleSumit}>
            确定
          </Button>
        </div>
      </Form.Item>
    </Form>
  );
});

export default BaseConfig;
