import {
  AllSkillGroupRes,
  queryAllSkillGroup,
} from '@/api/accountPermission/skillGroup2.0';
import {
  HumanEnumRes,
  NameStatisticsObj,
  getRosterEnumList,
  queryNameNStatistics,
} from '@/api/projectv2/nameInfo';
import {
  ProjectDetailObj,
  queryProjectDetail,
  queryAdviceEffectTime,
} from '@/api/projectv2/projectInfo';
import { useState } from 'react';
import { TypeTab } from './detail/components/nameList/config';

const ProjectModel = () => {
  // 项目详情数据
  const [projectDetail, setProjectDetail] = useState<ProjectDetailObj>();
  const [detailLoading, setDetailLoading] = useState(false);
  // 名单所有枚举
  const [rosterEunmList, setRosterEunmList] = useState<HumanEnumRes['data']>(
    [],
  );
  // 所有技能组
  const [allSkillGroup, setAllSkillGroup] = useState<AllSkillGroupRes['data']>(
    [],
  );
  // 名单列表Statistics
  const [rosterSummary, setRosterSummary] = useState<NameStatisticsObj>();

  // 当前的列表tab
  const [currentTab, setCurrentTab] = useState<TypeTab>('nameList');

  // 名单的流转状态
  const [rosterWanderStatus, setRosterWanderStatus] = useState<string>(null);

  //自动调整并发执行时间
  const [autoAdjustConcurrencyTime, setAutoAdjustConcurrencyTime] =
    useState<number>(0);

  // fetch详情数据
  const fetchProjectDetail = async (guid: string) => {
    setDetailLoading(true);
    const res = await queryProjectDetail({ guid });
    if (res?.data) {
      setProjectDetail(res.data);
    }
    setDetailLoading(false);
  };

  // fetch名单所有枚举
  const fetchRosterEnum = async () => {
    const res = await getRosterEnumList();
    setRosterEunmList(res?.data);
  };

  // fetch租户下所有技能组
  const fetchAllSkillGroup = async (tenantCodeList: number[]) => {
    const res = await queryAllSkillGroup({ tenantCodeList });
    setAllSkillGroup(res?.data);
  };

  // fetch名单列表Statistics
  const fetchRosterSummary = async (guid: string) => {
    const res = await queryNameNStatistics({ projectGuid: guid });
    if (res?.data) {
      setRosterSummary(res.data);
    }
  };

  // 自动调整并发执行时间
  const fetchAdviceEffectTime = async () => {
    const res = await queryAdviceEffectTime();
    if (res?.data) {
      setAutoAdjustConcurrencyTime(res.data);
    }
  };

  return {
    projectDetail,
    setProjectDetail,
    detailLoading,
    fetchProjectDetail,
    fetchRosterEnum,
    rosterEunmList,
    allSkillGroup,
    fetchAllSkillGroup,
    currentTab,
    setCurrentTab,
    rosterSummary,
    fetchRosterSummary,
    rosterWanderStatus,
    setRosterWanderStatus,
    autoAdjustConcurrencyTime,
    fetchAdviceEffectTime,
  };
};

export default ProjectModel;
