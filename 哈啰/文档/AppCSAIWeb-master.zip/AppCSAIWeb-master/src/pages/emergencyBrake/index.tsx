import React, { useEffect, useState } from 'react';
import { Typography, Button, Popconfirm, message } from 'antd';
import { queryEmergencyStatus, changeEmergencyStatus } from '@/api/emergency';
import styles from './index.less';

const { Text } = Typography;

const emergencyStatusList = [
  { label: '运行中', value: 0 },
  { label: '已停止', value: 1 },
];

const EmergencyBrake: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<number>();

  // fetch状态
  const fetchEmergencyStatus = async () => {
    const res = await queryEmergencyStatus({
      emergencyCode: 'task_emergency_code',
    });
    if (res?.success) {
      setStatus(res.data);
    }
  };

  // change状态
  const changeStatus = async (val: number) => {
    setLoading(true);
    const params = { emergencyCode: 'task_emergency_code', status: val };
    const res = await changeEmergencyStatus(params);
    if (res?.success) {
      fetchEmergencyStatus();
      message.success('操作成功');
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchEmergencyStatus();
  }, []);

  return (
    <div className={styles.emergencyBrake}>
      <div className={styles.text}>
        当前系统外呼任务状态：
        <Text
          className={styles.status}
          type={status === 0 ? 'success' : 'danger'}
        >
          {emergencyStatusList.find((item) => item.value === status)?.label}
        </Text>
      </div>
      {status === 0 && (
        <Popconfirm
          title="确认一键停止吗？"
          placement="bottom"
          onConfirm={() => changeStatus(1)}
        >
          <Button type="primary" danger loading={loading}>
            一键停止
          </Button>
        </Popconfirm>
      )}
      {status === 1 && (
        <Popconfirm
          title="确认解除限制吗？"
          placement="bottom"
          onConfirm={() => changeStatus(0)}
        >
          <Button type="primary" loading={loading}>
            解除限制
          </Button>
        </Popconfirm>
      )}
    </div>
  );
};

export default EmergencyBrake;
