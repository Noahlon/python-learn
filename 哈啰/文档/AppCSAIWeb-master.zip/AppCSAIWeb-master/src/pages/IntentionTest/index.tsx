import React, { useEffect, useRef, useState } from 'react';
import {
  Button,
  Form,
  Input,
  Cascader,
  Table,
  Typography,
  Space,
  Tooltip,
  Tag,
} from 'antd';
import {
  intentionTest,
  findIntentionTestRecord,
  getIntentionTree,
} from '@/api/intention';
import { v1 as uuidv1 } from 'uuid';
import ItentionLearningModal from '@/components/ItentionLearningModal';
import { useAccess } from '@umijs/max';
import styles from './index.less';

const Intentiontest: React.FC = () => {
  const access = useAccess();
  const modalRef = useRef(null);
  const [form] = Form.useForm();
  const tableRef = useRef();
  const [tableHeight, setTableHeight] = useState(300);
  const [tableData, setTableData] = useState<any>([]);
  const [expandedRowKeys, setExpKey] = useState([]);
  const [expArr, setExpArr] = useState([]);
  const [exeData, setExeData] = useState<any>();
  const [treeData, setTreeData] = useState([]);
  const [tableLoading, setTableLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const testRes = useRef({
    sentence: '',
    tree: '',
  });

  /**
   * api
   */
  // 意图测试tree
  const getIntentionTrees = async () => {
    const { data } = await getIntentionTree();
    if (data) {
      setTreeData(data);
    } else setTreeData([]);
  };

  // table表格数据
  const getTableData = async (pageNum: number, pageSize: number) => {
    setTableLoading(true);
    const { data } = await findIntentionTestRecord({ pageNum, pageSize });
    if (data) {
      setTotal(data?.totalRecord);
      setTableData(data?.list);
      const arr: any = [];
      if (data?.list?.length > 0) {
        data?.list.forEach((it) => {
          arr.push({
            id: it.id,
            exp: false,
          });
        });
        setExpArr(arr);
      }
    }
    setTableLoading(false);
  };
  // 意图测试
  const intentionTests = async (sentence: string, kcGuid: string) => {
    const { data } = await intentionTest({ sentence, kcGuid });
    if (data) {
      setExeData(data);
    }
  };

  const columns: any = [
    {
      title: '测试句',
      dataIndex: 'sentence',
      key: 'sentence',
      fixed: 'left',
      ellipsis: true,
      render: (text) => {
        return <Tooltip title={text}>{text}</Tooltip>;
      },
    },
    { title: '行业', dataIndex: 'bizNames', key: 'bizNames' },
    {
      title: '意图集合',
      dataIndex: 'kcName',
      key: 'kcName',
      render: (text) => {
        return <Tooltip title={text}>{text}</Tooltip>;
      },
    },
    {
      title: '短语命中',
      dataIndex: 'matchWithPhrase',
      key: 'matchWithPhrase',
      render: (_, record) => {
        return record?.matchWithPhrase?.length > 0
          ? record?.matchWithPhrase?.map((it) => it?.standardQName)?.join(';')
          : '-';
      },
    },
    {
      title: '算法命中',
      dataIndex: 'matchWithAlgorithm',
      key: 'matchWithAlgorithm',
      render: (_, record) => {
        return record?.matchWithAlgorithm?.length > 0
          ? record?.matchWithAlgorithm?.map((it) => it.name)?.join(';')
          : '-';
      },
    },
    {
      title: '核心句命中',
      dataIndex: 'matchWithKernalSentence',
      key: 'matchWithKernalSentence',
      render: (_, record) => {
        return record?.matchWithKernalSentence?.length > 0
          ? record?.matchWithKernalSentence?.map((it) => it?.name)?.join(';')
          : '-';
      },
    },
    { title: '创建人', dataIndex: 'author', key: 'author' },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      key: 'createTime',
      render: (text) => {
        return text ? text.replace('T', ' ') : '-';
      },
    },
    {
      title: '操作',
      dataIndex: 'e',
      key: 'e',
      fixed: 'right',
      render: (_, record: any) => {
        let str = '';
        const exp = (id) => {
          expArr?.forEach((it) => {
            if (id === it.id) {
              if (it.exp) {
                it.exp = false;
                str = '';
              } else {
                it.exp = true;
                str = it.id;
              }
            } else {
              it.exp = false;
            }
          });
          if (str) {
            setExpKey([str]);
          } else setExpKey([]);
        };
        return (
          <Space>
            {access?.authCodeList?.includes('Call-Intention-Trial-Edit') && (
              <>
                <Typography.Link onClick={() => exp(record.id)}>
                  {expArr?.find((it) => it.id === record.id)?.exp
                    ? '收起'
                    : '展开'}
                </Typography.Link>
                <Typography.Link
                  onClick={() => {
                    modalRef?.current?.openModal(record.kcGuid);
                  }}
                >
                  学习
                </Typography.Link>
              </>
            )}
          </Space>
        );
      },
    },
  ];

  // 执行
  const exe = async () => {
    const res = await form.validateFields();
    if (res.sentence && res.kcGuidArr) {
      testRes.current.sentence = res.sentence;
      await intentionTests(res.sentence, res.kcGuidArr[2]);
      getTableData(1, 100);
    }
  };

  useEffect(() => {
    if (tableRef.current) {
      // @ts-ignore
      setTableHeight(tableRef.current.clientHeight - 119);
    }
    getTableData(1, 100);
    getIntentionTrees();
  }, []);

  return (
    <div className={styles.intentionTest}>
      <div className={styles.left}>
        <Form layout="vertical" form={form}>
          <Form.Item
            rules={[{ required: true }]}
            label="测试句："
            name="sentence"
          >
            <Input.TextArea autoSize={{ minRows: 8 }} maxLength={120} />
          </Form.Item>
          <Form.Item
            rules={[
              { required: true, message: '' },
              {
                validator: (_, value) => {
                  if (value?.length !== 3)
                    return Promise.reject('请选择意图集合');
                  else return Promise.resolve();
                },
              },
            ]}
            label="意图集合："
            name="kcGuidArr"
          >
            <Cascader
              options={treeData}
              fieldNames={{ label: 'name', value: 'id' }}
              placeholder="请选择"
              allowClear
              onChange={(_, selectedOptions) => {
                if (selectedOptions?.length === 3) {
                  testRes.current.tree = selectedOptions[2]?.name;
                } else testRes.current.tree = '';
              }}
            />
          </Form.Item>
        </Form>
        <Button type="primary" onClick={exe}>
          执行
        </Button>
        {exeData ? (
          <div className={styles.res}>
            <h2>测试结果：</h2>
            <p>
              | 测试句：
              <span>{testRes?.current?.sentence}</span>
            </p>
            <p>
              | 意图集合： <span>{testRes?.current?.tree}</span>
            </p>
            <p>
              | 分词结果：{' '}
              {exeData?.segments?.map((it) =>
                it !== ' ' ? (
                  <Tag key={uuidv1()} color="#48C199">
                    {it}
                  </Tag>
                ) : (
                  <></>
                ),
              )}
            </p>
            <p>
              | 核心句命中：
              {exeData?.matchWithKernalSentence?.length > 0
                ? exeData?.matchWithKernalSentence?.map((it) => (
                    <p key={it.faqId}>
                      {it.name} {it.kernelSentence ?? ''}
                    </p>
                  ))
                : '-'}
            </p>
            <p>
              | 短语命中：
              {exeData?.matchWithPhrase?.length > 0
                ? exeData?.matchWithPhrase?.map((it) => (
                    <p key={it.standardQId}>
                      {it.standardQName} {`(${it.hitPhrases.join('、')})`}
                    </p>
                  ))
                : '-'}
            </p>
            <p>
              | 算法命中：
              {exeData?.matchWithAlgorithm?.length > 0
                ? exeData?.matchWithAlgorithm?.map((it) => (
                    <p key={it.intentionId}>
                      {it.name} {it.score ? `(${it.score})` : ''}
                    </p>
                  ))
                : '-'}
            </p>
          </div>
        ) : (
          <></>
        )}
      </div>
      <div className={styles.right}>
        <h2>测试历史</h2>
        <div ref={tableRef} className={styles.table}>
          <Table
            columns={columns}
            dataSource={tableData}
            rowKey={(record) => record.id}
            loading={tableLoading}
            expandable={{
              expandedRowRender: (record) => (
                <div className={styles.exp}>
                  <div className={styles.box}>
                    <p className={styles.nowrap}>分词结果：</p>
                    <Tooltip title={record?.segments?.join('\xa0\xa0')}>
                      <p className={styles.row}>
                        {record?.segments?.map((it) => (
                          <Tag
                            key={uuidv1()}
                            color="#48C199"
                            style={{ fontSize: 14 }}
                          >
                            {it}
                          </Tag>
                        ))}
                      </p>
                    </Tooltip>
                  </div>
                  <div className={styles.box}>
                    <p className={styles.nowrap}>核心句命中：</p>
                    {record?.matchWithKernalSentence?.length > 0
                      ? record?.matchWithKernalSentence?.map((it) => (
                          <p key={it.faqId}>
                            {it.name}{' '}
                            {it.kernelSentence ? `(${it.kernelSentence})` : ''}
                          </p>
                        ))
                      : '-'}
                  </div>
                  <div className={styles.box}>
                    <p className={styles.nowrap}>算法命中：</p>
                    {record?.matchWithAlgorithm?.length > 0
                      ? record?.matchWithAlgorithm?.map((it) => (
                          <p key={it.intentionId}>
                            {it.name} {it.score ? `(${it.score})` : ''}
                          </p>
                        ))
                      : '-'}
                  </div>
                  <div className={styles.box}>
                    <p className={styles.nowrap}>短语命中：</p>
                    {record?.matchWithPhrase?.length ? (
                      <Tooltip
                        title={record?.matchWithPhrase?.map((it) => (
                          <p key={it.standardQId}>
                            {it.standardQName} {`(${it.hitPhrases.join('、')})`}
                          </p>
                        ))}
                      >
                        {record?.matchWithPhrase?.length > 2
                          ? record?.matchWithPhrase?.slice(0, 2)?.map((it) => (
                              <p key={it.standardQId}>
                                {it.standardQName}{' '}
                                {`(${it.hitPhrases.join('、')})`}
                              </p>
                            ))
                          : record?.matchWithPhrase?.map((it) => (
                              <p key={it.standardQId}>
                                {it.standardQName}{' '}
                                {`(${it.hitPhrases.join('、')})`}
                              </p>
                            ))}
                      </Tooltip>
                    ) : (
                      '-'
                    )}
                  </div>
                </div>
              ),
              expandedRowKeys: expandedRowKeys,
              showExpandColumn: false,
            }}
            scroll={{ y: tableHeight, x: 1600 }}
            pagination={{
              showSizeChanger: false,
              pageSize: 100,
              total: total,
              showTotal: (total) => `共${total}项数据`,
              onChange: (val) => {
                setPage(val);
                getTableData(val, 100);
              },
            }}
          />
        </div>
      </div>
      <ItentionLearningModal
        ref={modalRef}
        type="ITENTIONTEST"
        getTableData={getTableData}
        page={page}
      />
    </div>
  );
};
export default Intentiontest;
