import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Space, Table, Typography, Input, Pagination, Button } from 'antd';

import { useAccess } from 'umi';
import { debounce } from 'lodash';
import styles from './index.less';
import { getApiList, IApi } from '@/api/speechFlow';
import EditApiModal from './components/EditApiModal';

type StatusType = 0 | 1 | 2 | 3;
enum StatusEnum {
  '禁用' = 0,
  '待测试' = 1,
  '测试通过' = 2,
  '已发布' = 3,
}

const ApiManage: React.FC = () => {
  const access = useAccess();
  const queryParams = useRef({
    pageNum: 1,
    pageSize: 100,
    serviceName: undefined,
    search: undefined,
    businessType: 'T10call',
  });
  const [tableData, setTableData] = useState<IApi[]>([]);
  const [isLoading, setLoading] = useState<boolean>(false);
  const [total, setTotal] = useState<number>(0);
  const [pageIndex, setPageIndex] = useState<number>(1);
  const [pageSize, setPageSize] = useState(100);
  const [tableHeight, setTableHeight] = useState<string | number>('auto');
  const [serviceSearch, setServiceSearch] = useState<undefined | string>(
    undefined,
  );
  const [actionSearch, setActionhSpeech] = useState('');
  // 1--新增 2--编辑  3--复制 4--查看
  const [type, setType] = useState(undefined);
  const [curInfo, setCurInfo] = useState<IApi>(undefined);
  // 获取高度变化
  const handleHeightEvent = debounce(async () => {
    const ele = document.getElementById('apiTableWrap');
    const _height = (ele?.clientHeight || 300) - 55;
    setTableHeight(_height < 101 ? 500 : _height);
  }, 200);

  const handlerGetLists = async () => {
    setLoading(true);
    const res = await getApiList(queryParams.current);
    if (res.code === 0 && res?.data.list && res?.data.list?.length) {
      setTableData(res?.data?.list);
      setTotal(Number(res?.data?.total) || 0);
    } else {
      setTableData([]);
    }
    setLoading(false);
  };

  // 分页
  const onChange = (page: number | undefined, size: number | undefined) => {
    if (size !== pageSize) {
      queryParams.current.pageNum = 1;
      queryParams.current.pageSize = size;
      setPageIndex(1);
      setPageSize(size);
    } else {
      setPageIndex(page);
      queryParams.current.pageNum = page;
    }
    handlerGetLists();
  };

  // 编辑
  const handleEdit = async (info: IApi) => {
    setType(2);
    setCurInfo(info);
  };

  const column: any = [
    {
      title: '服务名',
      dataIndex: 'serviceName',
      key: 'serviceName',
      width: 140,
    },
    {
      title: '接口说明',
      dataIndex: 'apiIllustrate',
      key: 'apiIllustrate',
      width: 200,
    },
    {
      title: '接口action',
      dataIndex: 'apiAction',
      key: 'apiAction',
      width: 220,
    },
    {
      title: '接口路径',
      dataIndex: 'apiIface',
      key: 'apiIface',
      width: 220,
    },
    {
      title: '方法名',
      dataIndex: 'apiMethod',
      key: 'apiMethod',
      width: 200,
    },
    {
      title: '当前版本',
      dataIndex: 'apiVersion',
      key: 'apiVersion',
      width: 120,
    },
    {
      title: '状态',
      dataIndex: 'apiStatus',
      key: 'apiStatus',
      width: 100,
      render(status: StatusType) {
        return <span>{StatusEnum[status]}</span>;
      },
    },
    {
      title: '创建人',
      dataIndex: 'creatorName',
      width: 80,
      key: 'creatorName',
    },
    {
      title: '修改人',
      dataIndex: 'modifierName',
      width: 80,
      key: 'modifierName',
    },
    {
      title: '操作',
      dataIndex: 'guid',
      key: 'guid',
      fixed: 'right',
      width: 100,
      render: function operation(text: string, record: IApi) {
        return (
          <Space direction="horizontal">
            {access?.authCodeList?.includes('Call-Api-Edit') && (
              <Typography.Link onClick={() => handleEdit(record)}>
                编辑
              </Typography.Link>
            )}
          </Space>
        );
      },
    },
  ];

  const handleSearchDebounce = useCallback(
    debounce(() => {
      handlerGetLists();
    }, 1000),
    [],
  );

  // 服务名搜索
  const handleServiceChange = useCallback((e) => {
    queryParams.current.serviceName = e.target.value;
    queryParams.current.pageNum = 1;
    setServiceSearch(e.target.value);
    setPageIndex(1);
    handleSearchDebounce();
  }, []);

  // action搜索
  const handleActionChange = (e) => {
    queryParams.current.search = e.target.value || undefined;
    queryParams.current.pageNum = 1;
    setActionhSpeech(e.target.value);
    setPageIndex(1);
    handleSearchDebounce();
  };

  // 编辑取消
  const handleEditCancel = () => {
    setType(0);
    setCurInfo(undefined);
  };

  // 编辑提交
  const handleEditOk = () => {
    handleEditCancel();
    handlerGetLists();
  };

  useEffect(() => {
    handlerGetLists();
    handleHeightEvent();
    window.addEventListener('resize', handleHeightEvent);
    return () => window.removeEventListener('resize', handleHeightEvent);
  }, []);
  return (
    <>
      <div className={styles.apiWrap}>
        <div className={styles.search}>
          <div className={styles.condition}>
            <Input
              value={serviceSearch}
              placeholder="请输入服务名"
              onChange={handleServiceChange}
              className={styles.speechName}
            />
            <Input
              value={actionSearch}
              placeholder="请输入action或接口说明"
              onChange={handleActionChange}
              className={styles.speechName}
            />
          </div>
          <Button type="primary" onClick={() => setType(1)}>
            新增
          </Button>
        </div>
        <div className={styles.tableContent} id="apiTableWrap">
          <Table
            columns={column}
            dataSource={tableData}
            loading={isLoading}
            rowKey={(record) => record.guid}
            scroll={{ y: tableHeight, x: 2000 }}
            pagination={false}
          ></Table>
        </div>
        <div className={styles.subPagination}>
          <Pagination
            current={pageIndex}
            showSizeChanger={true}
            pageSize={pageSize}
            total={total}
            showTotal={(total) => `总共 ${total} 条`}
            onChange={onChange}
          />
        </div>
      </div>

      <EditApiModal
        type={type}
        info={curInfo}
        onOk={handleEditOk}
        onCancel={handleEditCancel}
      />
    </>
  );
};

export default ApiManage;
