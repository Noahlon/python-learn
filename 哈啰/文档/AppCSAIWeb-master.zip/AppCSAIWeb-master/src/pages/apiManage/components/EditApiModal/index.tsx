import React, { FC, useEffect, useRef, useState } from 'react';
import { Form, Input, Steps, Button, message, Drawer } from 'antd';
import { getResParamList, IApi, IApiParam } from '@/api/speechFlow';
import styles from './index.less';
import { addApi, updateApi } from '@/api/apiManage';
import ListCom from '../ListCom/inde';

const steps = [
  {
    key: 'first',
    title: 'API配置',
  },
  {
    key: 'second',
    title: '入参映射',
  },
  {
    key: 'last',
    title: '出参映射',
  },
];

export interface Prop {
  type?: number;
  info?: IApi;
  onOk?: () => void;
  onCancel?: () => void;
}

const EditApiModal: FC<Prop> = ({ type, onOk, onCancel, info }) => {
  const [form] = Form.useForm();
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [step, setSetp] = useState<number>(0);
  const [jsonList, setJsonList] = useState<IApiParam[]>([]);
  const JsonRef = useRef<HTMLElement | null>(null);
  const [initVersion, setInitVersion] = useState<string | null>(null);
  const [outJsonList, setOutJsonList] = useState<IApiParam[]>([]);
  const outJsonRef = useRef<HTMLElement | null>(null);

  const validateMessages = {
    // eslint-disable-next-line no-template-curly-in-string
    required: '${label}是必填项!',
  };

  const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };

  // 取消
  const handleCancel = () => {
    form.resetFields();
    setConfirmLoading(false);
    onCancel?.();
  };

  const printIt = (data) => {
    setJsonList(data);
  };

  // 出参映射相关函数
  const outPrintIt = (val) => {
    setOutJsonList(val);
  };

  // 步骤1表单校验
  const submit = async () => {
    try {
      await form.validateFields();
      setSetp((val) => val + 1);
    } catch (errorInfo) {
      console.log('Failed:', errorInfo);
    }
  };
  // 给requestParam递归便利附值apiGuid
  const dealRequestParam = (res: any[]) =>
    // eslint-disable-next-line array-callback-return
    res.map((item) => {
      item.apiGuid = info?.guid;
      if (item.children?.length) {
        item.children = dealRequestParam(item.children);
      }
      return item;
    });
  // 步骤2入参校验
  const jsonSubmit = () => {
    (JsonRef.current as HTMLElement)
      .validateData()
      // eslint-disable-next-line @typescript-eslint/require-await
      .then(async () => {
        setSetp((val) => val + 1);
      })
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      .catch((e) => {
        // message.error('rrrr');
      });
  };

  // 下一步
  const nextStep = () => {
    if (step === 0) {
      submit();
    } else if (step === 1) {
      jsonSubmit();
    }
  };

  // 步骤三出参校验并总的提交
  const outJsonSubmit = async () => {
    const formValues = form.getFieldsValue();
    const enterReq = await (JsonRef.current as HTMLElement).validateData();
    const _enterReq = dealRequestParam(enterReq);
    (outJsonRef.current as HTMLElement)
      .validateData()
      .then(async (res) => {
        // 需要判断用户有无手动更新版本号
        const _version = formValues.apiVersion;
        const param = {
          guid: info?.guid,
          ...formValues,
          businessType: 'T10call',
          requestParam: _enterReq,
          responseParam: dealRequestParam(res),
          apiVersion: _version === initVersion ? undefined : _version,
        };
        setConfirmLoading(true);
        const api = type === 1 ? addApi : updateApi;
        const result = await api(param);
        if (result.code === 0) {
          message.success('更新成功');
          onOk?.();
        }
        setConfirmLoading(false);
      })
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      .catch((e) => {
        // message.error('rrrr');
      });
  };

  const getApiInfo = async () => {
    const res = await getResParamList(info.guid);
    if (res?.data?.guid) {
      const {
        apiIface,
        apiAction,
        apiIllustrate,
        serviceName,
        apiMethod,
        apiVersion,
        soaGroup,
        soaTag,
        businessType,
        requestParam = [],
        responseParam = [],
      } = res.data;
      setInitVersion(apiVersion);
      // 表单附值
      form.setFieldsValue({
        apiIface,
        apiAction,
        apiIllustrate,
        serviceName,
        apiMethod,
        businessType: businessType ? businessType.split(',') : [],
        apiVersion,
        soaGroup,
        soaTag,
      });
      // 入参json附值
      setJsonList(requestParam);
      // 出参json附值
      setOutJsonList(responseParam);
    }
  };

  useEffect(() => {
    if (info && type) {
      getApiInfo();
    } else {
      form.resetFields();
    }
    if (!type) {
      // 入参json附值
      setJsonList([]);
      // 出参json附值
      setOutJsonList([]);
    }
    setSetp(0);
    setConfirmLoading(false);
  }, [type, info]);

  return (
    <>
      <Drawer
        open={!!type}
        title={
          type === 1
            ? '新建'
            : type === 2
            ? '编辑'
            : type === 3
            ? '复制'
            : '查看'
        }
        footer={false}
        forceRender
        width={'85%'}
        onClose={handleCancel}
        // getContainer={false}
        destroyOnClose={true}
        bodyStyle={{ padding: '20px' }}
      >
        <div className={styles.contentWrap}>
          <Steps current={step} items={steps} className={styles.stepsWrap} />
          <div className={styles.contentInnerWrap}>
            <Form
              style={{ display: step === 0 ? 'block' : 'none' }}
              {...layout}
              form={form}
              validateMessages={validateMessages}
            >
              <Form.Item
                name="apiIface"
                label="接口路径"
                rules={[{ required: true }]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name="apiAction"
                label="接口action"
                rules={[{ required: true }]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name="apiIllustrate"
                label="接口说明"
                rules={[{ required: true }]}
              >
                <Input.TextArea />
              </Form.Item>
              <Form.Item
                name="serviceName"
                label="服务名"
                rules={[{ required: true }]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name="apiMethod"
                label="方法名"
                rules={[{ required: true }]}
              >
                <Input />
              </Form.Item>
              {/* <Form.Item
                name="businessType"
                label="业务线"
              >
                <Select placeholder="请选择业务线" mode='multiple'>
                  {
                    businessList.map((item) => (
                      <Option key={item.typecode} value={item.typecode}>{item.name}</Option>
                    ))
                  }
                </Select>
              </Form.Item> */}
              <Form.Item
                name="apiVersion"
                label="版本号"
                rules={[
                  {
                    pattern: new RegExp(
                      '^([1-9]\\d|[1-9])(.([1-9]\\d|\\d))(.([1-9]\\d\\d|[1-9]\\d|\\d))$',
                    ),
                    message:
                      '不符合规则,请重新输入版本号。版本号规则：[1-99].[0-99].[0-999]',
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item name="soaGroup" label="soa分组">
                <Input />
              </Form.Item>
              <Form.Item name="soaTag" label="soa tag">
                <Input />
              </Form.Item>
            </Form>
            <div
              className={styles.editorWrap}
              style={{ display: step === 1 ? 'block' : 'none' }}
            >
              {!!type && (
                <ListCom cRef={JsonRef} onChange={printIt} value={jsonList} />
              )}
            </div>
            <div
              className={styles.editorWrap}
              style={{ display: step === 2 ? 'block' : 'none' }}
            >
              {!!type && (
                <ListCom
                  cRef={outJsonRef}
                  type="out"
                  onChange={outPrintIt}
                  value={outJsonList}
                />
              )}
            </div>
          </div>
          <div className={styles.botButWrap}>
            <Button
              type="primary"
              disabled={step === 0}
              onClick={() => setSetp((val) => val - 1)}
            >
              上一步
            </Button>
            <Button
              type="primary"
              disabled={step === 2}
              onClick={() => nextStep()}
            >
              下一步
            </Button>
            {step === 2 && (
              <Button
                type="primary"
                loading={confirmLoading}
                onClick={() => outJsonSubmit()}
              >
                提交
              </Button>
            )}
          </div>
        </div>
      </Drawer>
    </>
  );
};
export default EditApiModal;
