import {
  Input,
  Select,
  Space,
  Button,
  Dropdown,
  Checkbox,
  Modal,
  message,
  MenuProps,
} from 'antd';
import React, {
  useEffect,
  useImperativeHandle,
  FC,
  useRef,
  useState,
} from 'react';
import cloneDeep from 'lodash/cloneDeep';
import { EditOutlined } from '@ant-design/icons';

import styles from './index.less';

export interface IItemParam {
  docDisplay: 1;
  fieldAlias: string;
  paramDescription: string;
  paramField: string;
  paramType: string;
  parentField: string | null;
  requireType: 0 | 1;
  defaultValue?: string;
  __key?: string;
  children: IItemParam[];
}

let indexKey = 0;
let addKey = 0;

const InputModal = ({ value, onChange, top, ...props }) => {
  const [visible, setVisible] = useState(false);
  const [v, setV] = useState('');

  const onOpen = () => {
    if (top) return;
    setVisible(true);
    setV(value);
  };
  const onOk = () => {
    onChange(v);
    setVisible(false);
  };

  return (
    <>
      <Input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        addonAfter={<EditOutlined onClick={onOpen} />}
        {...props}
      />
      <Modal
        title="默认值"
        open={visible}
        onCancel={() => setVisible(false)}
        onOk={onOk}
      >
        <Input.TextArea value={v} onChange={(e) => setV(e.target.value)} />
      </Modal>
    </>
  );
};

interface IListItem {
  index: number;
  top?: boolean;
  value: any;
  current?: any[];
  parentType?: string;
  onChange: (v?: any) => void;
  onAddTop?: () => void;
  type?: 'enter' | 'out'; // 入参 / 出参
}

const ListItem: FC<IListItem> = ({
  value,
  current = [],
  index,
  parentType,
  top,
  onChange,
  onAddTop,
  type = 'enter',
}) => {
  const onSelectChange = (v) => {
    value.paramType = v;
    if (v === 'array') {
      value.children = [
        {
          paramType: 'string',
          __key: indexKey,
          paramField: 'items',
        },
      ];
      indexKey += 1;
    } else {
      value.children = [];
    }
    onChange();
  };

  const onInputChange = (e: any) => {
    value.paramField = e.target.value;
    onChange();
  };

  const onAliasChange = (e: any) => {
    value.fieldAlias = e.target.value;
    onChange();
  };

  const setRequire = (list: IItemParam[] = [], req) => {
    if (list?.length) {
      list.forEach((it) => {
        it.requireType = req;
        if (it.children?.length) {
          setRequire(it.children, req);
        }
      });
    }
  };

  const onRequiredChange = (e: any) => {
    if (top) {
      onChange(e.target.checked ? 1 : 0);
      return;
    }
    value.requireType = e.target.checked ? 1 : 0;
    setRequire(value.children, value.requireType);
    onChange();
  };

  const onDesChange = (v: string) => {
    value.paramDescription = v;
    onChange();
  };

  const onDefaultValueInputChange = (e: any) => {
    value.defaultValue = e.target.value;
    onChange();
  };

  const onAdd = () => {
    current.push({
      paramType: 'string',
      __key: indexKey,
      paramField: `field_${++addKey}`,
      fieldAlias: '',
      paramDescription: '',
      parentField: parentType || null,
      requireType: 0,
      children: [],
    });
    indexKey += 1;
    onChange();
  };

  const onAddChild = () => {
    if (value.children) {
      value.children.push({
        paramType: 'string',
        __key: indexKey,
        paramField: `field_${++addKey}`,
        fieldAlias: '',
        paramDescription: '',
        parentField: parentType || null,
        requireType: 0,
        children: [],
      });
    } else {
      value.children = [
        {
          paramType: 'string',
          __key: indexKey,
          paramField: `field_${++addKey}`,
          fieldAlias: '',
          paramDescription: '',
          parentField: parentType || null,
          requireType: 0,
          children: [],
        },
      ];
    }
    indexKey += 1;
    onChange();
  };

  const onDelete = () => {
    current.splice(index, 1);
    onChange();
  };

  let addMenuItems: MenuProps['items'] = [
    {
      label: (
        <a href="#" onClick={onAddChild}>
          添加子节点
        </a>
      ),
      key: '1',
    },
    {
      label: (
        <a href="#" onClick={onAdd}>
          添加兄弟节点
        </a>
      ),
      key: '2',
    },
  ];

  const getDisabled = () => {
    if (top) return true;
    if (parentType === 'array') return true;
    return false;
  };

  const getDisableAias = () => !!top;

  const getDefaultValueInputDisabled = () => {
    if (top) return true;
    if (['object', 'array'].includes(value.paramType)) return true;
    return false;
  };

  const getButton = () => {
    if (top) return <Button onClick={onAddTop}>添加</Button>;
    if (parentType === 'array') {
      if (value.paramType === 'object')
        return <Button onClick={onAddChild}>添加子节点</Button>;
      return null;
    }
    if (parentType !== 'array' && value.paramType === 'object') {
      return (
        <Dropdown
          menu={{ items: addMenuItems }}
          trigger={['click']}
          placement="bottomLeft"
        >
          <Button>添加</Button>
        </Dropdown>
      );
    }
    return <Button onClick={onAdd}>添加</Button>;
  };

  return (
    <div className={styles.wrap}>
      <Space className={styles.space}>
        <Input
          maxLength={256}
          className={styles.first}
          placeholder="请输入参数名field，必填"
          disabled={getDisabled()}
          value={value.paramField}
          onChange={onInputChange}
        />
        <Input
          placeholder="参数别名"
          disabled={getDisableAias()}
          value={value.fieldAlias}
          onChange={onAliasChange}
        />
        <Checkbox
          checked={value.requireType === 1}
          onChange={onRequiredChange}
        />
        <Select
          style={{ width: 90 }}
          placeholder="请选择"
          disabled={getDisableAias()}
          value={value.paramType}
          onChange={onSelectChange}
        >
          <Select.Option value="object">object</Select.Option>
          <Select.Option value="array">array</Select.Option>
          <Select.Option value="string">string</Select.Option>
          <Select.Option value="long">long</Select.Option>
          <Select.Option value="double">double</Select.Option>
          <Select.Option value="boolean">boolean</Select.Option>
          <Select.Option value="integer">integer</Select.Option>
          <Select.Option value="date">date</Select.Option>
        </Select>
        <InputModal
          value={value.paramDescription}
          placeholder="备注说明"
          disabled={getDisableAias()}
          onChange={onDesChange}
          top
        />
        {type === 'enter' && (
          <Input
            maxLength={256}
            className={styles.first}
            placeholder="默认值"
            disabled={getDefaultValueInputDisabled()}
            value={value.defaultValue}
            onChange={onDefaultValueInputChange}
          />
        )}
        <Space className={styles.handle}>
          {getButton()}
          {!getDisableAias() && <Button onClick={onDelete}>删除</Button>}
        </Space>
      </Space>
    </div>
  );
};

interface IList {
  deep?: number;
  value: any[];
  data?: any[];
  parentType?: string;
  onChange: (v: any[]) => void;
  type?: 'enter' | 'out'; // 入参 / 出参
}

const List: FC<IList> = ({
  deep = 1,
  data,
  value = [],
  parentType,
  onChange,
  type = 'enter',
}) => {
  const onItemChange = () => {
    onChange(cloneDeep(data || value));
  };

  return (
    <>
      {value.map((it, inds) => (
        <div
          style={{ paddingLeft: deep > 0 ? 20 : 0 }}
          key={`param_${it.__key}`}
        >
          <ListItem
            type={type}
            index={inds}
            current={value}
            parentType={parentType}
            onChange={onItemChange}
            value={it}
          />
          <List
            type={type}
            value={it.children || []}
            parentType={it.paramType}
            data={data || value}
            deep={deep + 1}
            onChange={onChange}
          />
        </div>
      ))}
    </>
  );
};

interface IListComProps {
  onChange: (v: IItemParam[]) => void;
  value: IItemParam[];
  cRef: React.MutableRefObject<any>;
  type?: 'enter' | 'out'; // 入参 / 出参
}

const ListCom: FC<IListComProps> = ({
  onChange,
  value = [],
  cRef,
  type = 'enter',
}) => {
  const [filterList, setList] = useState<any[]>([]);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [isReadOnly, setIsReadOnly] = useState<boolean>(false);
  const [top, setTop] = useState<any>({
    paramType: 'object',
    paramField: 'root',
  });
  // const ref = useRef<IItemParam[]>([]);
  const isFirstInRef = useRef(true);

  const addId = (arr) => {
    arr.forEach((it) => {
      it.__key = indexKey;
      indexKey += 1;
      if (it.children?.length) {
        addId(it.children);
      }
    });
  };

  const validate = (list): string => {
    const str: string[] = [];
    const strAlias: string[] = [];
    let flag = '';
    for (let i = 0; i < list.length; i++) {
      const fe: string = list[i].paramField;
      const feAlias: string = list[i].fieldAlias;
      const feDes: string = list[i].paramDescription;
      const regExp = /^[A-Za-z_][A-Za-z_0-9]*$/;
      if (!fe) {
        flag = '请补全参数映射的filed值！';
        break;
      }
      if (!regExp.test(fe)) {
        flag = '参数名必须是非数字开头的字母、数字、下划线组合!';
        break;
      }
      if (!feDes) {
        flag = '请补全参数映射的备注！';
        break;
      }
      if (str.includes(fe)) {
        flag = `存在相同的同级field值：${fe}`;
        break;
      }
      if (feAlias && strAlias.includes(feAlias)) {
        flag = `存在相同的同级别名：${feAlias}`;
        break;
      }
      str.push(fe);
      strAlias.push(feAlias);

      if (list[i].children?.length) {
        const val = validate(list[i].children);
        if (val) {
          flag = val;
          break;
        }
      }
    }
    return flag;
  };

  const filterVal = (list: IItemParam[] = [], obj?: IItemParam[]) => {
    const data: IItemParam[] = obj || [];
    list.forEach((item) => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { children, __key, ...other } = item;
      const items: IItemParam = {
        ...other,
        fieldAlias: item.fieldAlias || item.paramField,
        children: [],
      };
      if (item.children?.length) {
        filterVal(children, items.children);
      }
      data.push(items);
    });
    return data;
  };

  const validateData = () =>
    new Promise((res, rej) => {
      const val = validate(value);
      if (!val) {
        res('');
      } else {
        message.error(val);
        rej();
      }
    }).then(() =>
      // console.log(value);
      // console.log(filterVal(value));
      filterVal(value),
    );

  const setReadOnly = (flag: boolean) => setIsReadOnly(flag);
  useImperativeHandle(cRef, () => ({
    validateData,
    setReadOnly,
  }));

  useEffect(() => {
    if (isFirstInRef.current && value?.length) {
      isFirstInRef.current = false;
      const list = cloneDeep(value);
      addId(list);
      setList([...list]);
    }
  }, [value]);

  const onAddTop = () => {
    const data: IItemParam[] = [
      ...value,
      {
        paramType: 'string',
        __key: indexKey,
        paramField: `field_${++addKey}`,
      } as unknown as IItemParam,
    ];
    onChange(cloneDeep(data));
    setList(data);
    indexKey += 1;
  };

  const setRequire = (list: IItemParam[] = [], req) => {
    if (list?.length) {
      list.forEach((it) => {
        it.requireType = req;
        if (it.children?.length) {
          setRequire(it.children, req);
        }
      });
    }
  };

  const change = (requireType) => {
    setTop({
      ...top,
      requireType,
    });
    setRequire(value, requireType);
    onChange(cloneDeep(value));
    setList([...value]);
  };

  return (
    <>
      <div className={styles.titleWrap}>
        <div className={styles.left}>{`soa${
          type === 'enter' ? '入参' : '出参'
        }名称【必填】`}</div>
        <div
          className={styles.right}
          style={{ width: type === 'enter' ? '877px' : '690px' }}
        >
          <span>soa{`${type === 'enter' ? '入参' : '出参'}别名【选填】`}</span>
          <span>是否必填</span>
          <span>参数类型</span>
          <span>备注说明【必填】</span>
          {type === 'enter' && <span>默认值</span>}
        </div>
      </div>
      <div className={styles.contentWrap}>
        {isReadOnly && <div className={styles.mask} />}
        <ListItem
          type={type}
          index={0}
          value={top}
          top
          onChange={change}
          onAddTop={onAddTop}
        />
        <List type={type} onChange={onChange} value={filterList} />
      </div>
    </>
  );
};

// const LisOutt: FC = () => {
//   const [obj, setObj] = useState<IItemParam[]>([]);
//   const ref = useRef<any>();

//   const onChange = (data) => {
//     setObj(data);
//   };

//   const onSubmit = () => {
//     ref.current.validateData().then((res) => {
//       message.success('sss');
//     }).catch((e) => {
//       // message.error('rrrr');
//     });
//   };

//   return <div>
//     <ListCom cRef={ref} onChange={onChange} value={obj} />
//     <Button onClick={onSubmit}>点击</Button>
//   </div>;
// };

export default ListCom;
