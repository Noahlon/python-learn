import React, { FC, useEffect, useState } from 'react';
import { DraggableArea } from 'react-draggable-tags';
const Drag: FC = () => {
  const [data, setData] = useState([]);
  useEffect(() => {
    if (data.length === 0) {
      setData([
        { id: 1, content: 'apple' },
        { id: 2, content: 'olive' },
        { id: 3, content: 'banana' },
        { id: 4, content: 'lemon' },
        { id: 5, content: 'orange' },
        { id: 6, content: 'grape' },
        { id: 7, content: 'strawberry' },
        { id: 8, content: 'cherry' },
        { id: 9, content: 'peach' },
      ]);
    }
  }, [data]);
  //拖拽结束后触发的函数,返回已经改变的data
  const onChange = (tags) => {
    console.log('--', tags);
  };
  //渲染每项
  const itemRender = ({ tag }) => {
    return (
      <div
        style={{ border: '1px dashed red', color: '#c3c3c3', margin: '5px' }}
      >
        {tag.content}
      </div>
    );
  };
  return (
    <div className="Simple">
      <DraggableArea
        tags={data}
        render={itemRender}
        onChange={onChange}
        // olive={(e) => console.log(e)}
        // onDragEnd={() => console.log('jjj')}
        // orange={() => console.log('aaa')}
      />
    </div>
  );
};
export default Drag;

// import React, { useEffect, useState } from "react"
// import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
// //每一项的样式
// const getItemStyle = () => ({
//     background: "white",
//     height: 50,
//     border: "1px solid red",
//     width: "100%",
//     margin: "0 0 20px 0"
// })
// // 重新记录数组顺序
// const reorder = (list, startIndex, endIndex) => {
//     const result = Array.from(list);
//     //删除并记录 删除元素
//     const [removed] = result.splice(startIndex, 1);
//     //将原来的元素添加进数组
//     result.splice(endIndex, 0, removed);
//     return result;
// };
// export default function App() {
//     const [data, setData] = useState([])
//     useEffect(() => {
//         if (data.length === 0) {
//             //初始化数据
//             const newData = Array.from({ length: 5 }, (item, index) => ({ key: "key" + index, content: "item" + index }))
//             setData(newData)
//         }
//     }, [data])
//     //拖拽结束
//     const onDragEnd = (result) => {
//         if (!result.destination) {
//             return;
//         }
//         //获取拖拽后的数据 重新赋值
//         const newData = reorder(data, result.source.index, result.destination.index)
//         setData(newData)
//     }
//     return <DragDropContext onDragEnd={onDragEnd}>
//         {/* direction代表拖拽方向  默认垂直方向  水平方向:horizontal */}
//         <Droppable droppableId="droppable">
//             {(provided, snapshot) => (
//                 //这里是拖拽容器 在这里设置容器的宽高等等...
//                 <div
//                     {...provided.droppableProps}
//                     ref={provided.innerRef}
//                     style={{
//                         width: 300,
//                         padding: 10
//                     }}
//                 >
//                     {/* 这里放置所需要拖拽的组件,必须要被 Draggable 包裹 */}
//                     {
//                         data.map((item, index) => (
//                             <Draggable
//                                 index={index}
//                                 key={item.key}
//                                 direction="horizontal"
//                                 draggableId={item.key}
//                             >
//                                 {(provided, snapshot) => (
//                                     //在这里写你的拖拽组件的样式 dom 等等...
//                                     <div
//                                         ref={provided.innerRef}
//                                         {...provided.draggableProps}
//                                         {...provided.dragHandleProps}
//                                         style={{ ...getItemStyle(), ...provided.draggableProps.style }}
//                                     >
//                                         {item.content}
//                                     </div>
//                                 )}

//                             </Draggable>
//                         ))
//                     }
//                     {/* 这个不能少 */}
//                     {provided.placeholder}
//                 </div>
//             )}
//         </Droppable>
//     </DragDropContext>
// }
