import moment from 'moment';
import { message } from 'antd';

export const DEFAULT_UPWARD_MESSAGE_PARAMS: Partial<any> = {
  createTime: [
    // moment().subtract(29, 'days').startOf('day').format('YYYY-MM-DD HH:mm:ss'),
    moment().startOf('day').format('YYYY-MM-DD HH:mm:ss'),
    moment().endOf('day').format('YYYY-MM-DD HH:mm:ss'),
  ],
  pageNum: 1,
  pageSize: 100,
};

// 手机号脱敏处理
export const maskPhoneNumber = (phoneNumber: string) => {
 // 判断是海外手机号还是国内手机号
 if (phoneNumber.startsWith('+')) {
    // 海外手机号格式 +国家代码 前三位-后四位，例如 +1 123-4567
    return phoneNumber.replace(/(\+\d{1,3} \d{3})-(\d{4})/, '$1-****');
  } else {
    // 国内手机号格式 13/14/15/17/18/19 开头的11位数字，例如 13812345678
    return phoneNumber.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
  }  
// return phoneNumber.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
}

// 复制手机号
export const copyPhone = (val: string) => {
  if (navigator.clipboard?.writeText) {
    navigator.clipboard.writeText(val).then(function() {
      message.info('复制成功');
    })
    .catch(function(err) {
      console.error('Failed to copy text: ', err);
    });
  } else {
    document.execCommand(val);
    message.info('复制成功');
  }
}

export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 100,
};