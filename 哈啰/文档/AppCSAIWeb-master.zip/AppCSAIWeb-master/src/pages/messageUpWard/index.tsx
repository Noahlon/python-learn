import React, { useEffect, useRef, useState } from 'react';
import { Tooltip, message } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import moment from 'moment';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { v1 as uuidv1 } from 'uuid';
import ResizeTable from '@/components/ResizeTable';
import { formatType } from '@/config';
import {
  getUpwardSmsRecordList,
  UpWardSmsRecordList,
  UpWardSmsRecordParams,
} from '@/api/messageList';
import styles from './index.less';
import MessageSearch from './components/MessageSearch';
import {
  DEFAULT_UPWARD_MESSAGE_PARAMS,
  maskPhoneNumber,
  DEFAULT_QUERY_PARAMS,
} from './config';

const SmsRecordList: React.FC = () => {
  const queryParams = useRef(DEFAULT_UPWARD_MESSAGE_PARAMS);
  const [tableData, setTableData] = useState<UpWardSmsRecordList[]>([]);
  const [isLoading, setLoading] = useState(false);
  // const [pageSize, setPageSize] = useState(100);
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [total, setTotal] = useState(0);

  // fetch列表数据
  const fetchList = async () => {
    const paramsObj: UpWardSmsRecordParams = {
      // pageNum: params.pageNum || pageIndex,
      // pageSize: params.pageSize || pageSize,
      ...queryParams.current,
    };
    // 创建时间
    if (
      Array.isArray(paramsObj.createTime) &&
      paramsObj?.createTime?.length === 2
    ) {
      paramsObj.replySendStartTime = moment(paramsObj.createTime[0]).format(
        formatType,
      );
      paramsObj.replySendEndTime = moment(paramsObj.createTime[1]).format(
        formatType,
      );
    }
    delete paramsObj.createTime;
    setLoading(true);
    try {
      const smsRecordListRes = await getUpwardSmsRecordList(paramsObj);
      if (smsRecordListRes?.success) {
        setTableData(smsRecordListRes.data?.list as UpWardSmsRecordList[]);
        setTotal(Number(smsRecordListRes.data?.totalRecord) || 0);
      } else {
        setTableData([]);
      }
    } catch (error) {}
    setLoading(false);
  };
  // variable
  const column: ColumnsType<UpWardSmsRecordList> = [
    {
      title: '手机号码',
      dataIndex: 'phoneNumber',
      key: 'phoneNumber',
      width: 150,
      fixed: 'left',
      render: (text: string) => {
        return text ? (
          <div>
            <CopyToClipboard
              text={text}
              onCopy={() => message.success('复制成功')}
            >
              <a>{maskPhoneNumber(text)}</a>
            </CopyToClipboard>
          </div>
        ) : (
          <div>-</div>
        );
      },
    },
    {
      title: '通话sessionid',
      dataIndex: 'sessionId',
      width: 200,
      key: 'sessionId',
    },
    {
      title: '租户名称',
      dataIndex: 'tenantName',
      width: 200,
      key: 'tenantName',
    },
    {
      title: '短信供应商',
      dataIndex: 'smsProvider',
      width: 200,
      key: 'smsProvider',
    },
    {
      title: '下行短信内容',
      dataIndex: 'content',
      key: 'content',
      width: 200,
      ellipsis: {
        showTitle: false,
      },
      render: (text) => (
        <Tooltip placement="topLeft" title={text}>
          {text}
        </Tooltip>
      ),
    },
    {
      title: '上行发送时间',
      dataIndex: 'replySendTime',
      key: 'replySendTime',
      width: 200,
    },
    {
      title: '上行短信内容',
      dataIndex: 'replyContent',
      key: 'replyContent',
      width: 200,
      ellipsis: {
        showTitle: false,
      },
      render: (text) => (
        <Tooltip placement="topLeft" title={text}>
          {text}
        </Tooltip>
      ),
    },
    {
      title: '记录创建时间',
      dataIndex: 'createTime',
      width: 200,
      key: 'createTime',
    },
  ];

  // 分页change
  const onChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchList();
  };

  // 请求第一页数据
  const fetchListOfPageOne = (data?: UpWardSmsRecordParams) => {
    queryParams.current = !!data ? data : DEFAULT_UPWARD_MESSAGE_PARAMS;
    fetchList();
  };

  // 分页change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchList();
  };

  // 搜索
  const handleSearch = (res: UpWardSmsRecordParams) => {
    const params = { ...queryParams.current };
    queryParams.current = { ...params, ...res };
    handlePageChange(1);
  };
  // 重置
  const handleReset = () => {
    queryParams.current = DEFAULT_UPWARD_MESSAGE_PARAMS;
    setPagination(DEFAULT_QUERY_PARAMS);
    fetchList();
  };

  useEffect(() => {
    fetchListOfPageOne();
  }, []);
  // 排序change
  const handleTableChange = (pagination) => {
    handlePageChange(pagination.current, pagination.pageSize);
  };
  return (
    <>
      <div className={styles.messageUpWrapper} id="messageWrap">
        <div className={styles.search} id="meesageSearchWrap">
          <MessageSearch onSearch={handleSearch} onReset={handleReset} />
        </div>
        <ResizeTable
          columns={column}
          dataSource={tableData}
          scroll={{ x: 2200 }}
          rowKey={() => uuidv1()}
          containerId="messageUpWard"
          loading={isLoading}
          pagination={{
            onChange: onChange,
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: [100, 200, 500],
            total: total,
          }}
          onChange={handleTableChange}
        />
      </div>
    </>
  );
};
export default SmsRecordList;
