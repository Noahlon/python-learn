import React, { memo, useEffect, useState } from 'react';
import {
  Form,
  Input,
  Select,
  Button,
  Row,
  Col,
  DatePicker,
  Space,
  SelectProps,
  message,
} from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import { timeRanges, formatType } from '@/config';
import { useAccess } from '@umijs/max';
import moment from 'moment';
import { debounce } from 'lodash';
import { querySmsSupplier } from '@/api/smsSupplier';
import { getTenantList } from '@/api/tenant';
import {
  UpWardSmsRecordParams,
  exportUpwardSmsRecord,
} from '@/api/messageList';
import styles from '../../index.less';

const { RangePicker } = DatePicker;
const defaultStartDate = moment().startOf('day'); // moment().subtract(29, 'days').startOf('day'); // 当前日期的前29天
const defaultEndDate = moment().endOf('day'); // 当前日期

const { TextArea } = Input;

interface IProps {
  onSearch?: (data: UpWardSmsRecordParams) => void;
  onReset?: () => void;
  onExport?: (data: UpWardSmsRecordParams) => void;
}

const colLayout2 = { xl: 7, sm: 12, xs: 24 };
const colLayout3 = { xl: 10, sm: 12, xs: 24 };

const MessageSearch: React.FC<IProps> = ({ onSearch, onReset }) => {
  const [form] = Form.useForm();
  const access = useAccess();
  const [uploadLoading, setUploadLoading] = useState<boolean>(false);
  const [openForm] = useState(true); //展和收起
  const [tenantOpts, setTenantOpts] = useState<SelectProps['options']>([]); // 租户options
  const [smsProviderOpts, setSmsProviderOpts] = useState<
    SelectProps['options']
  >([]); // 短信提供商options
  const [lastFilter, setLastFilter] = useState();
  // fetch租户数据
  const fetchTenanList = async () => {
    const res = await getTenantList({ pageNum: 1, pageSize: 200 });
    if (res.success && res.data) {
      const opts = res.data?.map((item) => ({
        label: item.name,
        value: item.code,
      }));
      setTenantOpts(opts);
    }
  };

  // 获取供应商数据
  const fetchAllSupplier = async () => {
    const res = await querySmsSupplier({
      pageNum: 1,
      pageSize: 999,
    });
    if (res?.data) {
      const opts = res.data?.list?.map((item) => ({
        label: item.supplierName,
        value: item.supplierType,
      }));
      setSmsProviderOpts(opts);
    }
  };
  // 重置
  const handleReset = () => {
    form.resetFields();
    form.setFieldValue('createTime', [defaultStartDate, defaultEndDate]);
    onReset?.();
  };

  // 搜索
  const handleSearch = debounce(async () => {
    try {
      const res = await form.validateFields();
      setLastFilter(res); // 保存上一次筛选的条件
      onSearch?.(res);
    } catch (e) {}
  }, 200);
  // 导出
  const handleExport = async () => {
    setUploadLoading(true);
    const params = !lastFilter
      ? {
          replySendStartTime: '',
          replySendEndTime: '',
          createTime: [defaultStartDate, defaultEndDate],
        }
      : lastFilter;
    // 创建时间
    if (Array.isArray(params.createTime) && params?.createTime?.length === 2) {
      params.replySendStartTime = moment(params.createTime[0]).format(
        formatType,
      );
      params.replySendEndTime = moment(params.createTime[1]).format(formatType);
    }
    delete params.createTime;
    const res = await exportUpwardSmsRecord(params);
    if (res?.success) {
      message.success('导出成功，请前往【文件导出管理】页面进行下载');
    }
    setUploadLoading(false);
  };
  useEffect(() => {
    fetchTenanList();
    fetchAllSupplier();
  }, []);
  const handleEnterPress = (e: any) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault(); // 阻止默认的换行行为
      handleSearch();
    }
  };
  return (
    <Form
      form={form}
      initialValues={{
        createTime: [defaultStartDate, defaultEndDate],
      }}
    >
      <Row wrap={false}>
        <Col
          flex="auto"
          className={styles.leftSearch + ' ' + (openForm ? '' : styles.isHide)}
        >
          <Row gutter={16}>
            <Col {...colLayout2}>
              <Form.Item name="phoneNumber" label="手机号码">
                <Input placeholder="请输入手机号" />
              </Form.Item>
            </Col>
            <Col {...colLayout2}>
              <Form.Item name="tenantIdList" label="租户名称">
                <Select
                  placeholder="请选择租户"
                  allowClear
                  showSearch
                  showArrow
                  mode="multiple"
                  maxTagCount="responsive"
                  filterOption={(input, option) =>
                    (option?.label as string)
                      .toLowerCase()
                      .includes(input.toLowerCase())
                  }
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  options={tenantOpts}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout3}>
              <Form.Item name="createTime" label="上行发送时间">
                <RangePicker
                  style={{ width: '100%' }}
                  placeholder={['开始时间', '结束时间']}
                  showTime
                  ranges={timeRanges}
                  allowClear={false}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout2}>
              <Form.Item name="replyContent" label="上行短信内容">
                <TextArea
                  autoSize
                  onPressEnter={handleEnterPress}
                  rows={1}
                  maxLength={20}
                  showCount
                  placeholder="请输入上行短信内容"
                />
              </Form.Item>
            </Col>
            <Col {...colLayout2}>
              <Form.Item name="smsProvider" label="短信供应商">
                <Select
                  placeholder="请选择短信供应商"
                  showSearch
                  allowClear
                  filterOption={(input, option) =>
                    (option?.label as string)
                      .toLowerCase()
                      .includes(input.toLowerCase())
                  }
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  options={smsProviderOpts}
                ></Select>
              </Form.Item>
            </Col>
            <Col {...colLayout3}>
              <Space style={{ float: 'right' }}>
                <Button type="primary" htmlType="submit" onClick={handleSearch}>
                  查询
                </Button>
                {access?.authCodeList?.includes('SMSLogs-UpWard-Export') && (
                  <Button
                    icon={<DownloadOutlined />}
                    loading={uploadLoading}
                    style={{ marginLeft: '5px' }}
                    onClick={handleExport}
                  >
                    导出
                  </Button>
                )}
                <Button onClick={handleReset}>重置</Button>
              </Space>
            </Col>
          </Row>
        </Col>
      </Row>
    </Form>
  );
};
export default memo(MessageSearch);
