import React, { useEffect, useState, useRef, useCallback } from 'react';
import { Button, Popconfirm, Space } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { PlusOutlined } from '@ant-design/icons';
import ResizeTable from '@/components/ResizeTable';
import {
  seatAccountListPage,
  SeatAccountObj,
  SeatAccountParams,
  seatAccountResetPassword,
} from '@/api/accountPermission/seatAccount';
import { text1Tooltip } from '@/utils/format';
import { Modal } from 'antd';
import { useAccess } from '@umijs/max';
import SearchSeat from './components/SearchSeat';
import UpdateSeatModal from './components/UpdateSeatModal';
import BatchModal from './components/BatchModal';
import UploadModal from './components/UploadModal';
import { DEFAULT_QUERY_PARAMS } from './config';
import styles from './index.less';

const SeatSetting: React.FC = () => {
  const access = useAccess();
  const [tableData, setTableData] = useState<SeatAccountObj[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  // pagination
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [tableTotal, setTableTotal] = useState<number>();
  // 搜索params
  const queryParams = useRef(DEFAULT_QUERY_PARAMS);
  // 座席账号新增/编辑
  const [updateSeatOpen, setUpdateSeatOpen] = useState(false);
  const [currentSeat, setCurrentSeat] = useState<SeatAccountObj>(undefined);

  // 批量编辑
  const [selectedRowKeys, setSelectedRowKeys] = useState<string[]>([]);
  const [batchEditOpen, setBatchEditOpen] = useState(false);

  // 批量上传
  const [batchUploadOpen, setBatchUploadOpen] = useState(false);

  // fetch座席账号列表
  const fetchSeatList = async () => {
    const params = {
      ...queryParams.current,
    };
    setTableLoading(true);
    const res = await seatAccountListPage(params);
    if (res?.code === 0) {
      setTableData(res.data?.list);
      setTableTotal(res?.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // 页面页数change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchSeatList();
  };

  const onSelectChange = (newSelectedRowKeys: string[]) => {
    setSelectedRowKeys(newSelectedRowKeys);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
  };

  // 搜索
  const handleSearch = (res: SeatAccountParams) => {
    queryParams.current = { ...queryParams.current, ...res };
    handlePageChange(1);
  };

  // 重置
  const handleReset = () => {
    queryParams.current = DEFAULT_QUERY_PARAMS;
    setPagination(DEFAULT_QUERY_PARAMS);
    fetchSeatList();
  };

  // 新增/编辑刷新座席账号列表
  const handleOk = () => {
    if (!currentSeat) {
      handlePageChange(1);
    } else {
      fetchSeatList();
    }
  };
  // 重置密码
  const resetPassword = async (seatGuid: string) => {
    const res = await seatAccountResetPassword({ seatGuid });
    if (res?.code === 0) {
      Modal.confirm({
        title: '重置成功',
        content: `重置后的密码为${res?.data}`,
      });
    }
  };
  // 座席账号columns
  const columns: ColumnsType<SeatAccountObj> = [
    {
      title: 'GUID',
      dataIndex: 'seatGuid',
      width: 200,
    },
    {
      title: '用户姓名',
      dataIndex: 'seatName',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '用户名',
      dataIndex: 'seatAccount',
      width: 180,
    },
    {
      title: '手机号',
      dataIndex: 'phoneNum',
    },
    {
      title: '邮箱',
      dataIndex: 'email',
      render: (text: string) => text1Tooltip(text),
    },
    {
      title: '技能组',
      dataIndex: 'skillGroupName',
      width: 160,
    },
    {
      title: '状态',
      dataIndex: 'status',
      width: 90,
      render: (text: number) => {
        return text === 1 ? '启用' : '禁用';
      },
    },
    {
      title: '添加人',
      dataIndex: 'createdBy',
      width: 250,
      ellipsis: true,
    },
    {
      title: '添加时间',
      dataIndex: 'createTime',
    },
    {
      title: '最近更新',
      dataIndex: 'updateTime',
      render: (text: string) => {
        return text ? text : '-';
      },
    },
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 160,
      render: (_, record) => (
        <Space size="middle">
          {access?.authCodeList?.includes('Call-Permission-Seat-Edit') && (
            <a
              onClick={() => {
                setCurrentSeat(record);
                setUpdateSeatOpen(true);
              }}
            >
              编辑
            </a>
          )}
          {access?.authCodeList?.includes(
            'Call-Permission-Seat-Reset-Password',
          ) && (
            <Popconfirm
              placement="topLeft"
              title="确认重置密码"
              onConfirm={() => resetPassword(record.seatGuid)}
            >
              <a>重置密码</a>
            </Popconfirm>
          )}
        </Space>
      ),
    },
  ];
  useEffect(() => {
    fetchSeatList();
  }, []);

  return (
    <>
      <div className={styles.seatSettingWrap}>
        {/* 搜索区域 */}
        <SearchSeat onSearch={handleSearch} onReset={handleReset} />
        <Space size="middle" className={styles.btnBox}>
          {access?.authCodeList?.includes('Call-Permission-Seat-Add') && (
            <Button
              type="primary"
              className={styles.btn}
              icon={<PlusOutlined />}
              onClick={() => {
                setCurrentSeat(undefined);
                setUpdateSeatOpen(true);
              }}
            >
              新增
            </Button>
          )}
          {access?.authCodeList?.includes(
            'Call-Permission-Seat-Btach-Upload',
          ) && (
            <Button
              type="primary"
              ghost
              className={styles.btn}
              onClick={() => {
                setBatchUploadOpen(true);
              }}
            >
              批量导入
            </Button>
          )}
          {access?.authCodeList?.includes(
            'Call-Permission-Seat-Btach-Edit',
          ) && (
            <Button
              type="primary"
              ghost
              className={styles.btn}
              disabled={selectedRowKeys?.length === 0}
              onClick={() => {
                setBatchEditOpen(true);
              }}
            >
              批量编辑
            </Button>
          )}
        </Space>
        {/* 座席账号列表 */}
        <ResizeTable
          columns={columns}
          // dataSource={[{seatGuid:'1',seatName:'eden'},{seatGuid:'2'}]} //todo
          dataSource={tableData}
          scroll={{ x: 2000 }}
          rowKey="seatGuid"
          loading={tableLoading}
          rowSelection={rowSelection}
          pagination={{
            onChange: handlePageChange,
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            total: tableTotal,
          }}
        />
      </div>
      {/* 座席账号新增/编辑modal */}
      <UpdateSeatModal
        open={updateSeatOpen}
        data={currentSeat}
        onOk={useCallback(handleOk, [])}
        onCancel={useCallback(() => setUpdateSeatOpen(false), [])}
      />
      {/* 批量编辑 */}
      <BatchModal
        onOk={handlePageChange}
        data={selectedRowKeys}
        open={batchEditOpen}
        onCancel={useCallback(() => setBatchEditOpen(false), [])}
      />
      {/* 上传modal */}
      <UploadModal
        visible={batchUploadOpen}
        onCancel={useCallback(() => setBatchUploadOpen(false), [])}
        onOk={handlePageChange}
      />
    </>
  );
};
export default SeatSetting;
