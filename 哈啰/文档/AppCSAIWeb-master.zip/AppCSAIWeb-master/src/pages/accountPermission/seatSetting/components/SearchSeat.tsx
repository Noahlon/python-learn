import React,{useEffect,useState} from 'react';
import { Form, Input, Select, Button, Row, Col, Space } from 'antd';
import { SeatAccountParams,seatAccountQueryAll } from '@/api/accountPermission/seatAccount';
import { SEARCHLAYOUT } from '@/constants/processconfig';

interface IProps {
  onSearch: (data: SeatAccountParams) => void;
  onReset: () => void;
}
interface ISStatus{
  value:number;
  label:string;
}

const statusData:ISStatus[] = [
  {
    value:0,
    label:'禁用'
  },
  {
    value:1,
    label:'启用'
  }
]

interface SkillGroupListPrams {
	skillGroupGuid?:string;
	skillGroupName?:string;
}

const SearchData: React.FC<IProps> = ({ onSearch, onReset }) => {
  const [form] = Form.useForm();
  const [skillGroupList, setSkillGroupList] = useState<SkillGroupListPrams[]>([])
 //获取所有技能组
 const AccountQueryAll = async () => {
  const res = await seatAccountQueryAll();
  if(res?.code === 0){
    setSkillGroupList(res?.data)
  }
}
  // 重置
  const handleReset = () => {
    form.resetFields();
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    onSearch?.(res);
  };
  useEffect(()=>{
    AccountQueryAll()
  },[])

  return (
    <Form form={form} style={{ padding: '20px 20px 0' }}>
      <Row wrap={false}>
        <Col flex="auto">
          <Row gutter={16}>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="seatAccount" label="用户名">
                <Input allowClear placeholder="请输入用户名" />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="skillGroupGuid" label="技能组">
                  <Select
                  placeholder="请选择技能组"
                  showSearch
                  allowClear
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  filterOption={(input, option: any) =>
                    (option?.skillGroupName ?? '').includes(input)
                  }
                  options={skillGroupList}
                  fieldNames={{value:'skillGroupGuid',label:'skillGroupName'}}
                />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="status" label="状态">
                <Select
                  placeholder="请选择状态"
                  maxTagCount="responsive"
                  optionFilterProp="label"
                  options={statusData}
                />
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none" style={{ marginLeft: '15px' }}>
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default SearchData;
