import React, { useState, memo, useEffect } from 'react';
import {
  Form,
  Modal,
  Input,
  message,
  Select,
  Upload,
  Space,
  Popover,
  Image,
} from 'antd';
import {
  seatAccountModify,
  SeatAccountModifyParams,
  SeatAccountObj,
  seatAccountQueryAll,
  seatAccountQueryDefaultAvatar,
} from '@/api/accountPermission/seatAccount';
import { LAYOUTLABELFIVE } from '@/constants/processconfig';
import { LoadingOutlined, PlusOutlined } from '@ant-design/icons';
import { RcFile } from 'antd/es/upload';
import { uploadFile } from '@/api/language';
import { validateEmail, validatePhoneNumberLength20 } from '@/utils/validate';

interface Prop {
  open: boolean;
  data: SeatAccountObj;
  onOk: () => void;
  onCancel: () => void;
}
interface SkillGroupListPrams {
  skillGroupGuid?: string;
  skillGroupName?: string;
}
const UpdateDataModal: React.FC<Prop> = memo(
  ({ open, data, onCancel, onOk }) => {
    const [form] = Form.useForm();
    const [confirmLoading, setConfirmLoading] = useState(false);
    const [imageUrl, setImageUrl] = useState<string>();
    const [loading, setLoading] = useState(false);
    const [skillGroupList, setSkillGroupList] = useState<SkillGroupListPrams[]>(
      [],
    );
    const [avatarList, setAvatarList] = useState<string[]>([]);
    //用户头像
    const getAvatar = async () => {
      const res = await seatAccountQueryDefaultAvatar();
      if (res?.code === 0) {
        setAvatarList(res?.data);
      }
    };
    //获取所有技能组
    const AccountQueryAll = async () => {
      const res = await seatAccountQueryAll();
      if (res?.code === 0) {
        setSkillGroupList(res?.data);
      }
    };
    // 取消
    const handleCancel = () => {
      form.resetFields();
      setImageUrl('');
      onCancel?.();
    };

    // 添加/编辑
    const saveAccountModify = async (params: SeatAccountModifyParams) => {
      const isUpdate = !!data?.seatGuid;
      setConfirmLoading(true);
      if (isUpdate) {
        params.seatGuid = data.seatGuid;
      }
      params.avatar = imageUrl || data?.avatar;
      const res = await seatAccountModify(params);

      if (res?.code === 0) {
        message.success(isUpdate ? '编辑成功' : '添加成功');
        onOk?.();
        handleCancel();
      }
      setConfirmLoading(false);
    };

    const beforeUpload = (file: RcFile) => {
      const isLt1M = file.size / 1024 / 1024 < 1;
      if (!isLt1M) {
        message.error('图片最大1MB!');
      }
      return isLt1M;
    };

    const handleCustomRequest = async ({ file }) => {
      const formData = new FormData();
      formData.append('file', file);
      try {
        setLoading(true);
        const res = (await uploadFile(formData)) as any;
        if (res) {
          setImageUrl(res?.url);
        }
      } catch (e) {
        // 上传失败
      }
      setLoading(false);
    };

    // 提交
    const handleOk = async () => {
      let params = await form.validateFields();
      params.seatAccount = params.seatAccount?.trim();
      params.seatName = params.seatName?.trim();
      saveAccountModify(params);
    };

    useEffect(() => {
      if (open) {
        // 获取所有技术组
        AccountQueryAll();
        // 默认头像
        getAvatar();
        if (!!data) {
          form.setFieldsValue(data);
        } else {
          setImageUrl('');
        }
      }
    }, [data, open]);

    return (
      <Modal
        open={open}
        title={!!data?.seatGuid ? '编辑' : '新建'}
        forceRender
        width="600px"
        onOk={handleOk}
        onCancel={handleCancel}
        confirmLoading={confirmLoading}
        getContainer={false}
      >
        <Form form={form} {...LAYOUTLABELFIVE} autoComplete="off">
          <Form.Item label="头像">
            <Space>
              <Upload
                accept="image/jpeg, image/png"
                name="avatar"
                listType="picture-card"
                className="avatar-uploader"
                showUploadList={false}
                beforeUpload={beforeUpload}
                customRequest={handleCustomRequest}
              >
                {imageUrl || data?.avatar ? (
                  <img
                    src={imageUrl || data?.avatar}
                    alt="avatar"
                    style={{ width: '100%' }}
                  />
                ) : (
                  <div>
                    {loading ? <LoadingOutlined /> : <PlusOutlined />}
                    <div style={{ marginTop: 8 }}>上传</div>
                  </div>
                )}
              </Upload>
              <Popover
                placement="rightTop"
                content={
                  <Space wrap style={{ maxWidth: 320 }}>
                    {avatarList?.map((item, index) => (
                      <Image
                        key={String(index)}
                        width={100}
                        src={item}
                        preview={false}
                        style={{ cursor: 'pointer' }}
                        onClick={() => setImageUrl(item)}
                      />
                    ))}
                  </Space>
                }
              >
                <a style={{ marginBottom: 10 }}>默认头像</a>
              </Popover>
            </Space>
          </Form.Item>
          <Form.Item
            label="用户名"
            name="seatAccount"
            rules={[{ required: true, message: '请输入用户名' }]}
          >
            <Input
              maxLength={50}
              disabled={!!data}
              placeholder="请输入用户名"
            />
          </Form.Item>
          <Form.Item
            label="用户姓名"
            name="seatName"
            rules={[{ required: true, message: '请输入用户姓名' }]}
          >
            <Input
              maxLength={20}
              // disabled={!!data}
              placeholder="请输入用户姓名"
            />
          </Form.Item>
          <Form.Item
            label="手机号"
            name="phoneNum"
            rules={[
              () => ({
                validator(_, value) {
                  if (!value) {
                    return Promise.resolve();
                  }
                  if (value && validatePhoneNumberLength20(value)) {
                    return Promise.resolve();
                  }
                  return Promise.reject(
                    new Error('请输入手机号1-20位手机号码!'),
                  );
                },
              }),
            ]}
          >
            <Input
              maxLength={20}
              placeholder="请输入手机号"
              style={{ width: '100%' }}
            />
          </Form.Item>
          <Form.Item
            label="邮箱"
            name="email"
            rules={[
              () => ({
                validator(_, value) {
                  if (!value) {
                    return Promise.resolve();
                  }
                  if (value && validateEmail(value)) {
                    return Promise.resolve();
                  }
                  return Promise.reject(new Error('请输入正确邮箱地址!'));
                },
              }),
            ]}
          >
            <Input maxLength={50} placeholder="请输入邮箱" />
          </Form.Item>
          <Form.Item name="skillGroupGuid" label="技能组">
            <Select
              placeholder="请选择技能组"
              showSearch
              allowClear
              filterOption={(input, option: any) =>
                (option?.skillGroupName ?? '').includes(input)
              }
              options={skillGroupList}
              fieldNames={{ value: 'skillGroupGuid', label: 'skillGroupName' }}
            />
          </Form.Item>
        </Form>
      </Modal>
    );
  },
);

export default UpdateDataModal;
