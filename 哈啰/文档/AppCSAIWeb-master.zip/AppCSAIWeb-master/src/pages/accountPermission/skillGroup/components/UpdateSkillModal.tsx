import React, { useState, memo, useEffect, useMemo } from 'react';
import {
  Form,
  Modal,
  Input,
  message,
  Select,
  Switch,
  Space,
  Button,
  Table,
  Spin,
  notification,
} from 'antd';
import { useAccess, useModel } from '@umijs/max';
import { LAYOUTLABELFIVE } from '@/constants/processconfig';
import { seatColumns } from '../config';
import { ColumnsType } from 'antd/es/table';
import {
  SeatAccountObj,
  SeatObj,
  SkillUpdateParams,
  preDelSeat,
  preDelTenant,
  querySeatAccount,
  queryskillGroupDetail,
  updateSkillGroup,
} from '@/api/accountPermission/skillGroup';

interface Prop {
  open: boolean;
  skillGroupGuid: string;
  onOk: () => void;
  onCancel: () => void;
}

const UpdateSkillModal: React.FC<Prop> = memo(
  ({ open, skillGroupGuid, onCancel, onOk }) => {
    const access = useAccess();
    const { tenantOpts } = useModel('common');
    const [form] = Form.useForm();
    const [confirmLoading, setConfirmLoading] = useState(false);
    const [statusChecked, setStatusChecked] = useState(false);
    const [detailLoading, setDetailLoading] = useState(false);
    // 座席opts
    const [seatOptions, setSeatOptions] = useState<SeatAccountObj[]>([]);
    // 组长opts
    const [groupLeader, setGroupLeader] = useState<SeatAccountObj[]>([]);
    // 当前的座席list
    const [tableData, setTableData] = useState<SeatObj[]>([]);
    // 新增和删除的座席list
    const [addedSeatList, setAddedSeatList] = useState<string[]>([]);
    const [deletedSeatList, setDeletedSeatList] = useState<string[]>([]);

    // 已选中租户
    const [tenantList, setTenantList] = useState([]);

    // 技能组详情
    const fetchSkillGroupDetail = async () => {
      setDetailLoading(true);
      const res = await queryskillGroupDetail({ skillGroupGuid });
      setDetailLoading(false);
      if (res?.data) {
        const _data = JSON.parse(JSON.stringify(res.data));
        const { tenantList, seatList, status, managerList } = _data;
        _data.managerGuidList =
          managerList?.map((item) => item?.managerGuid) || [];
        form.setFieldsValue(_data);
        setStatusChecked(status === 1 ? true : false);
        setTableData(seatList);
        setTenantList(tenantList?.map((item) => item.code));
      }
    };

    // fetch组长opts
    const fetchGroupLeaderOpts = async () => {
      const res = await querySeatAccount();
      if (res?.data) {
        setGroupLeader(res.data);
      }
    };

    // fetch座席opts
    const fetchSeatOpts = async () => {
      const res = await querySeatAccount({ skillGroupFilterTag: true });
      if (res?.data) {
        setSeatOptions(res.data);
      }
    };

    // 取消
    const handleCancel = () => {
      form.resetFields();
      setTableData([]);
      setAddedSeatList([]);
      setDeletedSeatList([]);
      setTenantList([]);
      setStatusChecked(false);

      onCancel?.();
    };

    // 添加/编辑技能组
    const updateSkillGroupApi = async (params: SkillUpdateParams) => {
      const isUpdate = !!skillGroupGuid;
      setConfirmLoading(true);

      if (isUpdate) {
        params.skillGroupGuid = skillGroupGuid;
      }
      const res = await updateSkillGroup(params);

      if (res?.success) {
        message.success(isUpdate ? '编辑成功' : '添加成功');
        onOk?.();
        handleCancel();
      }
      setConfirmLoading(false);
    };

    // 状态change
    const handleChangeStatus = (status: boolean) => {
      if (!status) {
        Modal.confirm({
          title: '禁用该技能组？',
          content: '禁用后的技能组组长和座席无法查看名单数据',
          onOk: () => {
            setStatusChecked(status);
          },
        });
      } else {
        setStatusChecked(status);
      }
    };

    // 租户change
    const handleTenantChange = async (list) => {
      // 如果是新建
      if (!skillGroupGuid) {
        setTenantList(list);
        return;
      }
      // 如果是编辑，租户删除
      if (list?.length < tenantList?.length) {
        const arr = tenantList.filter((item) => !list.includes(item));
        const params = {
          tenantCode: arr[0],
          skillGroupGuid: skillGroupGuid,
        };
        const res = await preDelTenant(params);
        if (!res?.data?.delSuccess) {
          return notification.error({
            message: '提示',
            description: res?.data?.errorMsg || '不可删除',
          });
        }
      }
      setTenantList(list);
    };

    // 提交
    const handleOk = async () => {
      let params = await form.validateFields();
      params.skillGroupName = params.skillGroupName?.trim();

      if (!tenantList?.length) {
        return message.error('请选择租户');
      }

      params.tenantList = tenantList;
      params.status = statusChecked ? 1 : 0;

      if (addedSeatList?.length > 0) {
        params.addedSeatList = addedSeatList;
      }
      if (deletedSeatList?.length > 0) {
        params.deletedSeatList = deletedSeatList;
      }
      updateSkillGroupApi(params);
    };

    // 删除座席
    const deleteSeat = (record: SeatObj) => {
      // 表格中删除座席
      const seatIndex = tableData?.findIndex(
        (item) => item?.seatGuid === record?.seatGuid,
      );
      const tableArr = JSON.parse(JSON.stringify(tableData));
      tableArr.splice(seatIndex, 1);
      setTableData(tableArr);

      // 删除后的座席回到座席下拉列表中
      if (seatOptions?.some((item) => item?.seatGuid !== record?.seatGuid)) {
        setSeatOptions([...seatOptions, record]);
      }

      // 删除的座席是否在add列表中
      const isContainAdd = addedSeatList?.includes(record.seatGuid);
      if (isContainAdd) {
        const _addList = JSON.parse(JSON.stringify(addedSeatList));
        const _filterList = _addList?.filter(
          (addId: string) => addId !== record.seatGuid,
        );
        setAddedSeatList(_filterList);
      } else {
        setDeletedSeatList((list) => [record.seatGuid, ...list]);
      }
    };

    const handleDelete = async (record: SeatObj) => {
      // 如果是新增，不需要确认
      if (!skillGroupGuid) {
        deleteSeat(record);
        return;
      }

      const params = {
        seatGuid: record.seatGuid,
        skillGroupGuid,
      };
      // 是否可以删除
      const res = await preDelSeat(params);

      if (!res?.data?.delSuccess) {
        return notification.error({
          message: '提示',
          description: res?.data?.errorMsg || '不可删除',
        });
      }

      // 二次确认
      Modal.confirm({
        title: '删除该座席？',
        content: '删除后，无法继续下发名单至该座席',
        onOk: () => {
          deleteSeat(record);
        },
      });
    };

    // 添加座席
    const handleAdd = (guidArr: string[]) => {
      const curSeat = seatOptions?.find((item) => item.seatGuid === guidArr[0]);
      setTableData((tableData) => [curSeat, ...tableData]);
      setAddedSeatList((list) => [...guidArr, ...list]);
    };

    // 可添加座席的列表
    const showSeatList = useMemo(() => {
      const arr = seatOptions?.filter((item) => {
        const isContain = tableData.some((it) => it.seatGuid === item.seatGuid);
        return !isContain;
      });

      return arr;
    }, [seatOptions, tableData]);

    const columns: ColumnsType<SeatObj> = [
      ...seatColumns,
      {
        title: '操作',
        dataIndex: 'action',
        fixed: 'right',
        width: 80,
        render: (_, record) => <a onClick={() => handleDelete(record)}>删除</a>,
      },
    ];

    useEffect(() => {
      if (open) {
        fetchSeatOpts();
        fetchGroupLeaderOpts();

        if (!!skillGroupGuid) {
          fetchSkillGroupDetail();
        } else {
          setStatusChecked(true);
          form.setFieldValue('status', 1);
        }
      }
    }, [skillGroupGuid, open]);

    // 渲染modal footer
    const renderFooter = () => {
      if (
        !skillGroupGuid ||
        (!!skillGroupGuid &&
          access?.authCodeList?.includes('Call-Permission-SKill-Group-Edit'))
      ) {
        return (
          <div style={{ textAlign: 'right' }}>
            <Space>
              <Button onClick={handleCancel}>取消</Button>
              <Button
                type="primary"
                onClick={handleOk}
                loading={confirmLoading}
              >
                确定
              </Button>
            </Space>
          </div>
        );
      }
      return null;
    };

    return (
      <Modal
        open={open}
        title={!!skillGroupGuid ? '编辑' : '新建'}
        forceRender
        width={700}
        maskClosable={false}
        onCancel={handleCancel}
        getContainer={false}
        footer={renderFooter()}
      >
        <Spin spinning={detailLoading}>
          <Form form={form} {...LAYOUTLABELFIVE}>
            <Form.Item
              label="技能组名称"
              name="skillGroupName"
              rules={[{ required: true }]}
            >
              <Input maxLength={30} placeholder="请输入技能组名称，限制30字" />
            </Form.Item>
            <Form.Item
              name="managerGuidList"
              label="经理"
              rules={[{ required: true, message: '请选择经理' }]}
            >
              <Select
                placeholder="请选择经理"
                allowClear
                mode="multiple"
                showSearch
                optionFilterProp="label"
                options={groupLeader?.map((item) => {
                  return {
                    label: `${item.seatName}（${item.seatAccount}）`,
                    value: item.seatGuid,
                  };
                })}
              />
            </Form.Item>
            <Form.Item
              name="groupLeaderGuid"
              label="组长"
              rules={[{ required: true, message: '请选择组长' }]}
            >
              <Select
                placeholder="请选择组长"
                allowClear
                showSearch
                optionFilterProp="label"
                options={groupLeader?.map((item) => {
                  return {
                    label: `${item.seatName}（${item.seatAccount}）`,
                    value: item.seatGuid,
                  };
                })}
              />
            </Form.Item>
            <Form.Item
              label="适用租户"
              rules={[{ required: true, message: '请选择适用租户' }]}
              required
            >
              <Select
                placeholder="请选择租户"
                mode="multiple"
                maxTagCount="responsive"
                allowClear
                showSearch
                optionFilterProp="label"
                value={tenantList}
                onChange={(e) => handleTenantChange(e)}
                options={tenantOpts}
              />
            </Form.Item>
            <Form.Item
              label="状态"
              name="status"
              rules={[{ required: true, message: '请选择状态' }]}
            >
              <Switch
                checked={statusChecked}
                onChange={handleChangeStatus}
                checkedChildren="启用中"
                unCheckedChildren="已禁用"
              />
            </Form.Item>
            <Form.Item label="座席数">
              <span>{tableData?.length}</span>
            </Form.Item>
            <Form.Item label="座席">
              <Select
                placeholder="添加座席到下面表格"
                showSearch
                allowClear
                mode="multiple"
                value={[]}
                onChange={handleAdd}
                style={{ width: '100%' }}
                optionFilterProp="label"
                options={showSeatList?.map((item) => {
                  return {
                    label: `${item.seatName}（${item.seatAccount}）`,
                    value: item.seatGuid,
                  };
                })}
              />
            </Form.Item>
            {tableData?.length > 0 && (
              <Table
                columns={columns}
                dataSource={tableData}
                scroll={{ y: 300 }}
                rowKey="seatGuid"
                size="small"
                pagination={{
                  pageSize: 50,
                  showQuickJumper: false,
                  showSizeChanger: false,
                  showTotal: (total: number) => `总共 ${total} 位`,
                }}
                style={{ marginLeft: 24 }}
              />
            )}
            <Form.Item label="备注" name="remark">
              <Input.TextArea
                placeholder="请输入备注，限制150字"
                maxLength={150}
              />
            </Form.Item>
          </Form>
        </Spin>
      </Modal>
    );
  },
);

export default UpdateSkillModal;
