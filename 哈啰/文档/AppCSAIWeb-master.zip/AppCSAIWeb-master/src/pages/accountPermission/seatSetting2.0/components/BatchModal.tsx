import { Form, Modal, Select, message } from 'antd';
import React, { useEffect, useState } from 'react';
import {
  seatAccountBatchEdit,
  SeatAccountBatchEditPrams,
  seatAccountQueryAll,
} from '@/api/accountPermission/seatAccount2.0';
interface Prop {
  open: boolean;
  onCancel: () => void;
  onOk: (pageNum: number) => void;
  data: string[];
}
interface SkillGroupListParams {
  skillGroupGuid?: string;
  skillGroupName?: string;
}
const BatchModal: React.FC<Prop> = ({ open, onCancel, data, onOk }) => {
  const [form] = Form.useForm();
  const [skillGroupList, setSkillGroupList] = useState<SkillGroupListParams[]>(
    [],
  );
  //获取所有技能组
  const AccountQueryAll = async () => {
    const res = await seatAccountQueryAll();
    if (res?.code === 0) {
      setSkillGroupList(res?.data);
    }
  };
  useEffect(() => {
    if (open) {
      // 获取所有技术组
      AccountQueryAll();
    } else {
      form.resetFields();
    }
  }, [open]);
  const handleOk = async () => {
    let params = await form.validateFields();
    const args: SeatAccountBatchEditPrams = {
      ...params,
      seatGuidList: data,
    };
    const res = await seatAccountBatchEdit(args);
    if (res?.code === 0) {
      message.success('批量编辑成功!');
      onCancel();
      onOk(1);
    }
  };
  return (
    <Modal
      open={open}
      title="批量编辑"
      forceRender
      width="600px"
      onOk={handleOk}
      onCancel={onCancel}
    >
      <Form form={form}>
        <Form.Item
          label="技能组"
          name="skillGroupGuid"
          rules={[{ required: true, message: '请选择技能组' }]}
        >
          <Select
            placeholder="请选择技能组"
            showSearch
            allowClear
            getPopupContainer={(triggerNode) =>
              triggerNode.parentElement || document.body
            }
            filterOption={(input, option: any) =>
              (option?.skillGroupName ?? '').includes(input)
            }
            options={skillGroupList}
            fieldNames={{ value: 'skillGroupGuid', label: 'skillGroupName' }}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default BatchModal;
