export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 100,
};

// 短链列表column
