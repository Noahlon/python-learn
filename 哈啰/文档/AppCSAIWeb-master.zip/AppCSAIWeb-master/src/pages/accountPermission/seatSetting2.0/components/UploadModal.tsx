import FileUploadShowList from '@/components/FileUploadShowList';
import { InboxOutlined } from '@ant-design/icons';
import { Button, Modal, message } from 'antd';
import React, { useRef, useState } from 'react';
import { httpReplace } from '@/utils';
import styles from '../index.less';
import {
  seatAccountBatchImport,
  seatAccountDownloadTemplate,
} from '@/api/accountPermission/seatAccount2.0';

interface Prop {
  visible: boolean;
  onCancel: () => void;
  onOk: (pageNum: number) => void;
}

const UploadModal: React.FC<Prop> = ({ onCancel, onOk, visible }) => {
  const ref = useRef();
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [fileList, setFileList] = useState([]);

  // 下载模板
  const downLoad = async () => {
    const res = await seatAccountDownloadTemplate();
    if (res?.code === 0) {
      const dest = message.loading('正在下载');
      let elink = document.createElement('a');
      elink.style.display = 'none';
      let newUrl = httpReplace(res?.data);
      elink.href = newUrl;
      // elink.download = '名单模版';
      document.body.appendChild(elink);
      elink.click();
      setTimeout(() => {
        document.body.removeChild(elink);
      }, 300);
      dest?.();
    }
  };
  // 导入取消
  const handleImportCancel = () => {
    onCancel();
    // @ts-ignore
    if (ref.current) ref.current?.clearData();
    setFileList([]);
  };

  // 批量导入
  const handleImportOk = async () => {
    const list = fileList?.filter((item) => item.status === 'done');
    if (!list?.length) return message.error('请先上传文件');
    setConfirmLoading(true);
    const dest = message.loading('正在导入');
    const res = await seatAccountBatchImport({
      fileUrl: list[0].url,
      fileName: list[0].name,
    });
    if (res?.code === 0) {
      Modal.success({
        title: `成功导入${res?.data?.successCount}条，失败${res?.data?.failCount}条`,
        content: (
          <a
            target="_blank"
            rel="noreferrer"
            href={res?.data.failDataDownLoadUrl}
          >
            下载失败数据
          </a>
        ),
      });
      handleImportCancel();
      onOk(1);
    }
    dest?.();
    setConfirmLoading(false);
  };

  return (
    <Modal
      open={visible}
      title="批量导入"
      forceRender={true}
      width={'540px'}
      onOk={handleImportOk}
      onCancel={handleImportCancel}
      confirmLoading={confirmLoading}
      getContainer={false}
      destroyOnClose={true}
    >
      <FileUploadShowList
        ref={ref}
        showUploadList={true}
        uploadType=".xlsx, .xls"
        sizeLimit={10}
        onChange={(list) => setFileList(list)}
      >
        <div className={styles.uploadIcon}>
          <InboxOutlined />
        </div>
        <div className={styles.notice}>点击上传 / 将文件拖拽到这里</div>
        <div className={styles.uploadType}>
          请上传xlsx，.xls文件，大小在10M以内
        </div>
      </FileUploadShowList>
      <div style={{ textAlign: 'right' }}>
        <Button type="link" size="small" onClick={downLoad}>
          下载模版
        </Button>
      </div>
    </Modal>
  );
};

export default UploadModal;
