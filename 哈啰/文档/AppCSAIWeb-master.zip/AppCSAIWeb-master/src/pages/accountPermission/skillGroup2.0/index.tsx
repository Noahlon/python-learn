import React, { useEffect, useState, useRef, useCallback } from 'react';
import { Button, Card, Empty, Pagination, Space, Spin } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import {
  SkillGroupObj,
  querySkillGroup,
  SkillUpdateParams,
} from '@/api/accountPermission/skillGroup2.0';
import { useAccess, useModel } from '@umijs/max';
import SearchSkill from './components/SearchSkill';
import UpdateSkillModal from './components/UpdateSkillModal';
import { text1Tooltip, text2Tooltip } from '@/utils/format';
import { DEFAULT_QUERY_PARAMS, statusOpts } from './config';
import styles from './index.less';

const SkillGroup: React.FC = () => {
  const { fetchTenantOpts } = useModel('common');
  const access = useAccess();
  const [tableData, setTableData] = useState<SkillGroupObj[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  // pagination
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [tableTotal, setTableTotal] = useState<number>();
  // 搜索params
  const queryParams = useRef(DEFAULT_QUERY_PARAMS);
  // 技能组新增/编辑
  const [updateSkillOpen, setUpdateSkillOpen] = useState(false);
  const [skillGroupGuid, setCurrentSkillGuid] = useState<string>(undefined);

  // fetch技能组列表
  const fetchSkillGroup = async () => {
    const params = {
      ...queryParams.current,
    };

    setTableLoading(true);
    const res = await querySkillGroup(params);
    if (res?.data) {
      setTableData(res.data?.list);
      setTableTotal(res?.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // 页面页数change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchSkillGroup();
  };

  // 搜索
  const handleSearch = (res: SkillUpdateParams) => {
    queryParams.current = { ...queryParams.current, ...res };
    handlePageChange(1);
  };

  // 重置
  const handleReset = () => {
    queryParams.current = DEFAULT_QUERY_PARAMS;
    setPagination(DEFAULT_QUERY_PARAMS);
    fetchSkillGroup();
  };

  // 新增/编辑刷新技能组列表
  const handleOk = () => {
    if (!skillGroupGuid) {
      handlePageChange(1);
    } else {
      fetchSkillGroup();
    }
  };

  useEffect(() => {
    fetchSkillGroup();
    fetchTenantOpts(2);
  }, []);

  return (
    <>
      <div className={styles.skillGroupWrap}>
        {/* 搜索区域 */}
        <SearchSkill onSearch={handleSearch} onReset={handleReset} />
        {/* Call-Permission-SKill-Group2.0-Add bpo2.0 使用的是 Call-Permission-SKill-Group-Add  */}
        {access?.authCodeList?.includes('Call-Permission-SKill-Group2.0-Add') && (
          <div className={styles.addButton}>
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => {
                setCurrentSkillGuid(undefined);
                setUpdateSkillOpen(true);
              }}
            >
              新增技能组
            </Button>
          </div>
        )}
        {/* 技能组列表 */}
        <Spin spinning={tableLoading} wrapperClassName={styles.listContent}>
          {tableData?.length ? (
            <Space size={[16, 24]} wrap className={styles.cardBox}>
              {tableData.map((item) => (
                <Card
                  key={item.skillGroupGuid}
                  hoverable
                  onClick={() => {
                    setCurrentSkillGuid(item.skillGroupGuid);
                    setUpdateSkillOpen(true);
                  }}
                >
                  <div className={styles.cardContent}>
                    <h3 className={styles.title}>
                      {text1Tooltip(`${item.skillGroupName}`)}
                    </h3>
                    <div className={styles.cardItem}>
                      <span className={styles.cardLabel}>状态：</span>
                      <span className={item.status === 0 ? styles.error : ''}>
                        {
                          statusOpts.find((it) => it.value === item.status)
                            ?.label
                        }
                      </span>
                    </div>
                    <div className={styles.cardItem}>
                      <span className={styles.cardLabel}>经理：</span>
                      {text1Tooltip(
                        item?.managerList
                          ?.map((item) => item?.managerName)
                          ?.join('、'),
                      )}
                    </div>
                    <div className={styles.cardItem}>
                      <span className={styles.cardLabel}>组长：</span>
                      {text1Tooltip(item.groupLeaderName)}
                    </div>
                    <div className={styles.cardItem}>
                      <span className={styles.cardLabel}>座席数：</span>
                      <div>{item.seatCount}</div>
                    </div>

                    <div className={styles.cardItem}>
                      <span className={styles.cardLabel}>适用租户：</span>
                      {text1Tooltip(
                        `${item.tenantList
                          ?.map((item) => item.name)
                          ?.join('、')}`,
                      )}
                    </div>

                    <div
                      className={`${styles.cardItem}`}
                      style={{ alignItems: 'baseline' }}
                    >
                      <span className={styles.cardLabel}>备注：</span>
                      <div className={styles.remark}>
                        {text2Tooltip(item.remark)}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </Space>
          ) : (
            <Empty />
          )}
        </Spin>
        {tableData?.length > 0 && (
          <Pagination
            current={pagination.pageNum}
            showSizeChanger={true}
            pageSize={pagination.pageSize}
            total={tableTotal}
            showTotal={(total) => `总共 ${total} 条`}
            onChange={handlePageChange}
            className={styles.paginationBox}
          />
        )}
      </div>
      {/* 技能组新增/编辑modal */}
      <UpdateSkillModal
        open={updateSkillOpen}
        skillGroupGuid={skillGroupGuid}
        onOk={useCallback(handleOk, [])}
        onCancel={useCallback(() => setUpdateSkillOpen(false), [])}
      />
    </>
  );
};
export default SkillGroup;
