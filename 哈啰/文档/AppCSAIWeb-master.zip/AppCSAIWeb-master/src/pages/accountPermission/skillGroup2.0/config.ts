import { SeatObj } from '@/api/accountPermission/skillGroup2.0';
import type { ColumnsType } from 'antd/es/table';

export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 100,
};

export const statusOpts = [
  { label: '启用中', value: 1 },
  { label: '已禁用', value: 0 },
];

export const seatColumns: ColumnsType<SeatObj> = [
  {
    title: '用户姓名',
    dataIndex: 'seatName',
  },
  {
    title: '用户名',
    dataIndex: 'seatAccount',
  },
  {
    title: '添加时间',
    dataIndex: 'createTime',
  },
];
