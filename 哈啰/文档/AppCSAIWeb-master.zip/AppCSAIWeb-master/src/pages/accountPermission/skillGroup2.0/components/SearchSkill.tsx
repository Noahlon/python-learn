import React from 'react';
import { Form, Input, Select, Button, Row, Col, Space } from 'antd';
import { SkillGroupParams } from '@/api/accountPermission/skillGroup2.0';
import { useModel } from '@umijs/max';
import { statusOpts } from '../config';
import { SEARCHLAYOUT } from '@/constants/processconfig';

interface IProps {
  onSearch: (data: SkillGroupParams) => void;
  onReset: () => void;
}

const SearchSkill: React.FC<IProps> = ({ onSearch, onReset }) => {
  const { tenantOpts } = useModel('common');
  const [form] = Form.useForm();

  // 重置
  const handleReset = () => {
    form.resetFields();
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    onSearch?.(res);
  };

  return (
    <Form form={form} style={{ padding: '20px 20px 0' }}>
      <Row wrap={false}>
        <Col flex="auto">
          <Row gutter={16}>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="skillGroupName" label="技能组名称">
                <Input allowClear placeholder="请输入技能组名称" />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="status" label="状态">
                <Select placeholder="状态" allowClear options={statusOpts} />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="tenantList" label="租户">
                <Select
                  placeholder="请选择租户"
                  allowClear
                  showSearch
                  mode="multiple"
                  maxTagCount="responsive"
                  optionFilterProp="label"
                  options={tenantOpts}
                />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="managerName" label="经理">
                <Input allowClear placeholder="请输入经理" />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="groupLeaderName" label="组长">
                <Input allowClear placeholder="请输入组长" />
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none" style={{ marginLeft: '15px' }}>
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default SearchSkill;
