import type { ColumnsType } from 'antd/es/table';
import { text1Tooltip } from '@/utils/format';
import { AccessListObj } from '@/api/accountPermission/dataSetting';

export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 100,
};

// 短链列表columns
export const dataSettingColumns: ColumnsType<AccessListObj> = [
  {
    title: 'GUID',
    dataIndex: 'guid',
    fixed: 'left',
    width: 130,
  },
  {
    title: '用户名',
    dataIndex: 'userName',
  },
  {
    title: '用户姓名',
    dataIndex: 'trueName',
    render: (text: string) => text1Tooltip(text),
    width: 160,
  },
  {
    title: '账号类型',
    dataIndex: 'userSourceDesc',
    width: 160,
  },
  {
    title: '租户权限',
    dataIndex: 'tenantNameList',
    render: (arr: string[] = []) => {
      const text = arr.join('、');
      return text1Tooltip(text);
    },
  },
  {
    title: '添加人',
    dataIndex: 'createBy',
  },
  {
    title: '添加时间',
    dataIndex: 'createTime',
    width: 180,
  },
  {
    title: '最近更新',
    dataIndex: 'updateTime',
    width: 180,
  },
];
