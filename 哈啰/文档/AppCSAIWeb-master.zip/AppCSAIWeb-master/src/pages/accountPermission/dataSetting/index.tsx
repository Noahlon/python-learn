import React, { useEffect, useState, useRef, useCallback } from 'react';
import { Button } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { PlusOutlined } from '@ant-design/icons';
import ResizeTable from '@/components/ResizeTable';
import {
  queryAccessList,
  queryUserSourceList,
  AccessListParams,
  AccessListObj,
  UserSourceListRes,
} from '@/api/accountPermission/dataSetting';
import { useAccess, useModel } from '@umijs/max';
import SearchData from './components/SearchData';
import UpdateDataModal from './components/UpdateDataModal';
import { dataSettingColumns, DEFAULT_QUERY_PARAMS } from './config';
import styles from './index.less';

const DataSetting: React.FC = () => {
  const { fetchTenantOpts } = useModel('common');
  const access = useAccess();
  const [tableData, setTableData] = useState<AccessListObj[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  // pagination
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [tableTotal, setTableTotal] = useState<number>();
  // 搜索params
  const queryParams = useRef(DEFAULT_QUERY_PARAMS);
  // 数据权限新增/编辑
  const [updateDataOpen, setUpdateDataOpen] = useState(false);
  const [currentData, setCurrentData] = useState<AccessListObj>(undefined);
  // 账号类型opts
  const [useSourceOpts, setUseSourceOpts] = useState<UserSourceListRes['data']>(
    [],
  );

  // fetch数据权限列表
  const fetchDataList = async () => {
    const params = {
      ...queryParams.current,
    };
    setTableLoading(true);
    const res = await queryAccessList(params);
    if (res?.data) {
      setTableData(res.data?.list);
      setTableTotal(res?.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // fetch账号类型opts
  const fetchUserSourceOpts = async () => {
    const res = await queryUserSourceList();
    if (res?.data) {
      setUseSourceOpts(res.data);
    }
  };

  // 页面页数change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchDataList();
  };

  // 数据权限columns
  const columns: ColumnsType<AccessListObj> = [
    ...dataSettingColumns,
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 100,
      render: (_, record) => (
        <>
          {access?.authCodeList?.includes('Call-Permission-Data-Edit') && (
            <a
              onClick={() => {
                setCurrentData(record);
                setUpdateDataOpen(true);
              }}
            >
              编辑
            </a>
          )}
        </>
      ),
    },
  ];

  // 搜索
  const handleSearch = (res: AccessListParams) => {
    queryParams.current = { ...queryParams.current, ...res };
    handlePageChange(1);
  };

  // 重置
  const handleReset = () => {
    queryParams.current = DEFAULT_QUERY_PARAMS;
    setPagination(DEFAULT_QUERY_PARAMS);
    fetchDataList();
  };

  // 新增/编辑刷新数据权限列表
  const handleOk = () => {
    if (!currentData) {
      handlePageChange(1);
    } else {
      fetchDataList();
    }
    // 刷新租户列表，后端有延迟
    setTimeout(() => {
      fetchTenantOpts();
    }, 1000);
  };

  useEffect(() => {
    fetchDataList();
    fetchTenantOpts();
    fetchUserSourceOpts();
  }, []);

  return (
    <>
      <div className={styles.dataSettingWrap}>
        {/* 搜索区域 */}
        <SearchData
          useSourceOpts={useSourceOpts}
          onSearch={handleSearch}
          onReset={handleReset}
        />

        {access?.authCodeList?.includes('Call-Permission-Data-Add') && (
          <div className={styles.addButton}>
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => {
                setCurrentData(undefined);
                setUpdateDataOpen(true);
              }}
            >
              设置权限
            </Button>
          </div>
        )}
        {/* 数据权限列表 */}
        <ResizeTable
          columns={columns}
          dataSource={tableData}
          scroll={{ x: 1800 }}
          rowKey="id"
          loading={tableLoading}
          pagination={{
            onChange: handlePageChange,
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            total: tableTotal,
          }}
        />
      </div>
      {/* 数据权限新增/编辑modal */}
      <UpdateDataModal
        open={updateDataOpen}
        useSourceOpts={useSourceOpts}
        data={currentData}
        onOk={useCallback(handleOk, [])}
        onCancel={useCallback(() => setUpdateDataOpen(false), [])}
      />
    </>
  );
};
export default DataSetting;
