import React from 'react';
import { Form, Input, Select, Button, Row, Col, Space } from 'antd';
import { useModel } from '@umijs/max';
import { SEARCHLAYOUT } from '@/constants/processconfig';
import {
  AccessListParams,
  UserSourceListRes,
} from '@/api/accountPermission/dataSetting';

interface IProps {
  useSourceOpts: UserSourceListRes['data'];
  onSearch: (data: AccessListParams) => void;
  onReset: () => void;
}

const SearchData: React.FC<IProps> = ({ onSearch, onReset, useSourceOpts }) => {
  const { tenantOpts } = useModel('common');
  const [form] = Form.useForm();

  // 重置
  const handleReset = () => {
    form.resetFields();
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    onSearch?.(res);
  };

  return (
    <Form form={form} style={{ padding: '20px 20px 0' }}>
      <Row wrap={false}>
        <Col flex="auto">
          <Row gutter={16}>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="userName" label="用户名">
                <Input allowClear placeholder="请输入用户名" />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="trueName" label="用户姓名">
                <Input allowClear placeholder="请输入用户姓名" />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="userSource" label="账号类型">
                <Select
                  placeholder="请选择账号类型"
                  allowClear
                  showSearch
                  optionFilterProp="userSourceName"
                  fieldNames={{
                    label: 'userSourceName',
                    value: 'userSourceCode',
                  }}
                  options={useSourceOpts}
                />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="tenant" label="租户">
                <Select
                  placeholder="请选择租户"
                  allowClear
                  showSearch
                  optionFilterProp="label"
                  options={tenantOpts}
                />
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none" style={{ marginLeft: '15px' }}>
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default SearchData;
