import React, { useState, memo, useEffect, useRef } from 'react';
import { Form, Modal, Input, message, Select } from 'antd';
import {
  cteateAccess,
  queryAccessUserInfo,
  updateAccess,
  AccessListObj,
  AccessUpdateParams,
  UserSourceListRes,
} from '@/api/accountPermission/dataSetting';
import { useModel } from '@umijs/max';
import { LAYOUTLABELFIVE } from '@/constants/processconfig';
import SelectAll from '@/components/SelectAll';
import { debounce } from 'lodash';

interface Prop {
  open: boolean;
  useSourceOpts: UserSourceListRes['data'];
  data: AccessListObj;
  onOk: () => void;
  onCancel: () => void;
}

const UpdateDataModal: React.FC<Prop> = memo(
  ({ open, data, onCancel, onOk, useSourceOpts }) => {
    const { tenantOpts } = useModel('common');
    const [form] = Form.useForm();
    const showTrueName = Form.useWatch('trueName', form);
    const [confirmLoading, setConfirmLoading] = useState(false);
    const guidRef = useRef(undefined);

    // 取消
    const handleCancel = () => {
      form.resetFields();
      onCancel?.();
    };

    // 添加/编辑短链
    const updateAccessApi = async (params: AccessUpdateParams) => {
      const isUpdate = !!data?.id;
      setConfirmLoading(true);

      if (isUpdate) {
        params.id = data.id;
        params.guid = data.guid;
      } else {
        params.guid = guidRef.current;
      }
      const action = isUpdate ? updateAccess : cteateAccess;
      const res = await action(params);

      if (res?.success) {
        message.success(isUpdate ? '编辑成功' : '添加成功');
        onOk?.();
        handleCancel();
      }
      setConfirmLoading(false);
    };

    // 账户类型change
    const handleChangeSource = () => {
      form.setFieldsValue({ userName: '', trueName: '' });
    };

    const handleDebounceChange = debounce(async () => {
      const { userName, userSource } = form.getFieldsValue([
        'userName',
        'userSource',
      ]);
      if (userName && (userSource || userSource === 0)) {
        const params = { email: userName, userSource };
        const res = await queryAccessUserInfo(params);
        if (res?.data) {
          const { trueName, employeeId } = res.data || {};
          guidRef.current = employeeId;
          form.setFieldsValue({ trueName });
        }
      }
    }, 500);

    // 用户名change
    const handleChangeName = () => {
      form.setFieldsValue({ trueName: '' });
      handleDebounceChange();
    };

    // 提交
    const handleOk = async () => {
      let params = await form.validateFields();
      if (params.tenantIdList?.[0] === 'all') {
        params.superButton = 1;
        params.tenantIdList = [];
      } else {
        params.superButton = 0;
      }
      updateAccessApi(params);
    };

    useEffect(() => {
      if (open && !!data) {
        const _data = JSON.parse(JSON.stringify(data));
        if (_data.superButton) {
          _data.tenantIdList = ['all'];
        }
        form.setFieldsValue(_data);
      }
      return () => {
        if (open && guidRef.current) {
          guidRef.current = undefined;
        }
      };
    }, [data, open]);

    return (
      <Modal
        open={open}
        title={!!data?.id ? '编辑' : '新建'}
        forceRender
        width="600px"
        onOk={handleOk}
        onCancel={handleCancel}
        confirmLoading={confirmLoading}
        getContainer={false}
      >
        <Form form={form} {...LAYOUTLABELFIVE}>
          <Form.Item
            name="userSource"
            label="账户类型"
            rules={[{ required: true, message: '请选择账户类型' }]}
          >
            <Select
              disabled={!!data}
              placeholder="请选择账户类型"
              allowClear
              showSearch
              options={useSourceOpts}
              onChange={handleChangeSource}
              optionFilterProp="userSourceName"
              fieldNames={{
                label: 'userSourceName',
                value: 'userSourceCode',
              }}
            />
          </Form.Item>
          <Form.Item
            label="用户名"
            name="userName"
            rules={[{ required: true, message: '请输入用户名' }]}
          >
            <Input
              maxLength={50}
              disabled={!!data}
              allowClear
              placeholder="请输入用户名"
              onChange={handleChangeName}
            />
          </Form.Item>
          <Form.Item
            label="用户姓名"
            name="trueName"
            rules={[{ required: true, message: '请先填写真实的用户名' }]}
          >
            <span>{showTrueName ? showTrueName : '-'}</span>
          </Form.Item>
          <Form.Item
            name="tenantIdList"
            label="租户权限"
            rules={[{ required: true, message: '请选择租户权限' }]}
          >
            <SelectAll
              placeholder="请选择租户"
              mode="multiple"
              showSearch
              allowClear
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
              filterOption={(input, option: any) =>
                (option?.label ?? '').includes(input)
              }
              options={tenantOpts}
            />
          </Form.Item>
        </Form>
      </Modal>
    );
  },
);

export default UpdateDataModal;
