import React, { FC, useEffect, useState } from 'react';
import {
  Button,
  Modal,
  Space,
  Table,
  Typography,
  Form,
  Input,
  Popconfirm,
  message,
  Pagination,
  Upload,
} from 'antd';
import { useSearchParams, history } from '@umijs/max';
import {
  getList,
  LANGUAGEs,
  addKB,
  deleteKB,
  editKB,
  tenantList,
  IDialogueReq,
  dialogueTest,
  exportSpeech,
  uploadFile,
  importSpeech,
} from '@/api/language';
import { IBooleanRes } from '@/api/baseInterface';
import moment from 'moment';
import styles from '@/pages/kbmanage/index.less';
import KcList from './components/KcList';
import { CloudUploadOutlined } from '@ant-design/icons';

const Language: FC = () => {
  const [searchParams] = useSearchParams();
  const [form] = Form.useForm();
  const [voiceForm] = Form.useForm();
  const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };
  const { TextArea } = Input;
  const [tableData, setTableData] = useState<LANGUAGEs[]>([]);
  const [isLoading, setLoading] = useState(false);
  const [isUploadLoading, setIsUploadLoading] = useState(false);

  const [isModalOpen, setModalOpen] = useState(false);
  const [guid, setGuid] = useState('');
  const [pageSize, setPageSize] = useState(10);
  const [tableHeight, setTableHeight] = useState<string | number>('auto');
  const [total, setTotal] = useState(0);
  const [bizList, setTenantList] = useState([]);
  const [tenantId, setTenantId] = useState(undefined);
  const [tenantName, setTenantName] = useState('');
  const [pageIndex, setPageIndex] = useState(1);
  const [curInfo, setCurInfo] = useState(null);
  // 语音测试
  const [showVoiceTestModel, setShowVoiceTestModel] = useState(false);
  // const [languageId, setLanguageId] = useState<string>('')
  // 0查看 1编辑 2新增
  const [modalType, setModalType] = useState<number>(0);

  // 语音测试
  const handlerShowVoice = async (record: any) => {
    setCurInfo(record);
    setShowVoiceTestModel(true);
  };

  // 关闭语音测试
  const handleCloseCallTest = () => {
    setCurInfo(null);
    setShowVoiceTestModel(false);
    voiceForm.setFieldsValue({ iphone: '' });
  };

  // 语音测试提交
  const handleCallTest = async () => {
    const val = await voiceForm.validateFields();
    const params: IDialogueReq = {
      tenant: curInfo?.tenant,
      userPhone: val.iphone,
      bizScene: '1',
      speechId: curInfo?.guid,
    };
    const res = await dialogueTest(params);
    if (typeof res === 'string' || typeof res === 'number') {
      message.success('操作成功');
      handleCloseCallTest();
    } else {
      message.error(res?.msg || '操作失败');
    }
  };

  // 导出话术
  const handlerExport = async (record: any) => {
    const dest = message.loading('正在导出');
    const res = await exportSpeech({ guid: record.guid });
    if (res.success && res.data) {
      let elink = document.createElement('a');
      elink.style.display = 'none';
      // let newUrl = (res?.aliOssUrl as unknown as string).replace('http', 'https');
      elink.href = res?.data.aliOssUrl as unknown as string;
      elink.download = '话术列表';
      document.body.appendChild(elink);
      elink.click();
      setTimeout(() => {
        document.body.removeChild(elink);
      }, 300);
    }
    dest?.();
  };

  const column = [
    {
      title: '话术名称',
      dataIndex: 'speechName',
      key: 'speechName',
    },
    {
      title: '业务线',
      dataIndex: 'tenant',
      width: '15%',
      key: 'tenant',
      render: (tenant) => {
        const item =
          // eslint-disable-next-line @typescript-eslint/no-use-before-define
          bizList && bizList?.length
            ? // eslint-disable-next-line @typescript-eslint/no-use-before-define
              bizList?.find((e: any) => String(e?.tenant) === String(tenant))
            : ({} as any);
        return <div>{item?.desc}</div>;
      },
    },
    {
      title: '最近更新时间',
      dataIndex: 'updateTime',
      width: '23%',
      key: 'updateTime',
      render: (text: string) => moment(text).format('YYYY.MM.DD HH:mm:ss'),
    },
    {
      title: '操作',
      dataIndex: 'guid',
      key: 'guid',
      width: '40%',
      fixed: 'right',
      render: function operation(text: string, record: LANGUAGEs) {
        return (
          <Space direction="horizontal">
            {
              <Typography.Link
                onClick={() =>
                  // eslint-disable-next-line @typescript-eslint/no-use-before-define
                  handlerGetDetail(
                    record?.guid,
                    record?.speechName,
                    record?.businessType,
                    record?.speechId,
                    record?.desc,
                    1,
                  )
                }
              >
                编辑
              </Typography.Link>
            }
            {
              <Typography.Link
                onClick={() =>
                  // eslint-disable-next-line @typescript-eslint/no-use-before-define
                  handleGoCreateKL(record)
                }
              >
                知识维护
              </Typography.Link>
            }
            {
              <Typography.Link
                onClick={() =>
                  history?.push({
                    pathname: `/language/processConfig`,
                    search: `?speechGuid=${record?.guid}&title=${record.speechName}&tenant=${record.tenant}`,
                  })
                }
              >
                流程维护
              </Typography.Link>
            }
            {
              <Typography.Link onClick={() => handlerShowVoice(record)}>
                语音测试
              </Typography.Link>
            }
            {
              <Typography.Link onClick={() => handlerExport(record)}>
                导出
              </Typography.Link>
            }
            {
              <Popconfirm
                title="是否确认删除该话术？"
                // eslint-disable-next-line @typescript-eslint/no-use-before-define
                onConfirm={() => handlerDelete(record?.guid)}
              >
                <Typography.Link>删除</Typography.Link>
              </Popconfirm>
            }
          </Space>
        );
      },
    },
  ];
  const handlerGetDetail = (
    guid: string,
    languageName: string,
    businessType: number,
    speechId: string,
    description: string,
    type: number,
  ) => {
    setGuid(guid);
    setModalType(type);
    form.setFieldsValue({
      name: languageName,
      businessType,
      description,
    });
    setModalOpen(true);
  };

  // 获取高度变化
  const handleHeightEvent = () => {
    const ele = document.getElementById('klTableWrap');
    setTableHeight((ele?.clientHeight || 300) - 55);
  };

  // 知识维护跳转
  const handleGoCreateKL = (record: LANGUAGEs) => {
    const item =
      bizList && bizList?.length
        ? bizList?.find((e: any) => e?.tenant === record.tenant)
        : ({} as any);
    history?.push({
      pathname: '/language/klmaintain',
      search: `?guid=${record?.guid}&tenant=${
        record.tenant
      }&tenantName=${encodeURIComponent(item.desc)}&title=${encodeURIComponent(
        record?.speechName,
      )}`,
    });
  };
  const handlerGetLists = async (params) => {
    if (!tenantId) return;
    setLoading(true);
    const param: any = {
      tenant: tenantId,
      pageNum: params.pageNum || pageIndex,
      pageSize: params.pageSize || pageSize,
    };
    const data = await getList(param);
    if (data) {
      if (data.list && data.list?.length) {
        setTableData(data.list as LANGUAGEs[]);
        setTotal(Number(data?.totalRecord) || 0);
        setTimeout(() => {
          handleHeightEvent();
        }, 0);
      } else {
        setTableData([]);
      }
    } else {
      setTableData([]);
    }
    setLoading(false);
  };

  // 导入话术
  const customRequest = async ({ file }) => {
    const formData = new FormData();
    formData.append('file', file);
    const dest = message.loading('正在导入');
    try {
      setIsUploadLoading(true);
      const res = (await uploadFile(formData)) as any;
      if (res.url) {
        const resp = (await importSpeech({ aliOssUrl: res?.url })) as any;
        if (resp.success) {
          message.success('导入成功');
          setPageIndex(1);
          handlerGetLists({
            pageNum: 1,
          });
        }
      }
    } catch (e) {
      // 上传失败
    }
    dest?.();
    setIsUploadLoading(false);
  };

  const handlerUpdate = () => {
    form.validateFields().then(async (val: any) => {
      const param: any = {
        speechName: val?.name,
        bizScene: 1,
        tenant: tenantId,
        flowCanvasInfo: '',
        desc: val?.description,
      };
      if (modalType === 2) {
        // const classifyId = await insertOrderClassify(classifyParam);
        const action = addKB;
        // param.speechId = classifyId;
        // if (modalType == 1) {
        //   param.kbGuid = kbId;
        // }
        action(param)
          .then((data: IBooleanRes) => {
            if (data?.success) {
              message.success('操作成功');
              setPageIndex(1);
              handlerGetLists({
                pageNum: 1,
              });
              setModalOpen(false);
              form.setFieldsValue({
                name: '',
                categoryId: undefined,
                description: '',
              });
            } else {
              // message.error(data?.info ? data?.info : '操作失败');
            }
          })
          .catch((e: any) => e);
      } else {
        param.guid = guid;
        editKB(param)
          .then((data: IBooleanRes) => {
            if (data?.success) {
              message.success('操作成功');
              setPageIndex(1);
              handlerGetLists({
                pageNum: 1,
              });
              setModalOpen(false);
              form.setFieldsValue({
                name: '',
                categoryId: undefined,
                description: '',
              });
            } else {
              // message.error(data?.info ? data?.info : '操作失败');
            }
          })
          .catch((e: any) => e);
      }
    });
  };
  const handlerDelete = async (guid: string) => {
    const data = await deleteKB({
      guid,
      flowCanvasInfo: '',
      nodes: '',
      nodePhases: '',
    });
    // eslint-disable-next-line @typescript-eslint/no-unused-expressions
    if (data?.success) {
      message.success('删除话术成功');
      setPageIndex(1);
      handlerGetLists({
        pageNum: 1,
      });
    } else {
      message.error(data?.info ? data?.info : '删除话术失败');
    }
  };

  const onChange = (page: number | undefined, size: number | undefined) => {
    const params = { pageSize: size, pageNum: 1 };
    if (size !== pageSize) {
      setPageIndex(1);
      setPageSize(size);
    } else {
      setPageIndex(page);
      params.pageNum = page;
    }
    handlerGetLists(params);
  };

  const getTenantList = async () => {
    const data = await tenantList({ pageNum: 1, pageSize: 999 });
    const urlTenant = searchParams.get('tenant');
    if (data && data?.length) {
      setTenantList(data);
      if (urlTenant) {
        const urlTenantName = searchParams.get('tenantName') || '';
        setTenantId(urlTenant);
        setTenantName(urlTenantName);
        form.setFieldsValue({
          tenantName: urlTenantName,
        });
      } else {
        setTenantId(data[0]?.tenant);
        setTenantName(data[0]?.desc);
        form.setFieldsValue({
          tenantName: data[0]?.desc,
        });
      }
    } else {
      setTenantList([]);
    }
  };
  const handleClickKl = (item) => {
    history?.replace({
      pathname: '/language',
      search: `?tenant=${item.tenant}&tenantName=${item.desc}`,
    });
    // setSearchParams({tenant: item.tenant, tenantName: item.desc})
    setTenantId(item.tenant);
    setTenantName(item.desc);
    form.setFieldsValue({
      tenantName: item.desc,
    });
  };

  useEffect(() => {
    if (tenantId === -18000) return;
    setPageIndex(1);
    handlerGetLists({
      pageNum: 1,
    });
  }, [tenantId]);

  useEffect(() => {
    getTenantList();
    // handlerBusinessList();
  }, []);
  return (
    <>
      <div className={styles.klContent}>
        <div className={styles.klLeft}>
          <div className={styles.klTop}>业务线</div>
          <div className={styles.klList}>
            {bizList.map((e: any, index) => {
              return (
                <div
                  key={index}
                  className={styles.itemKl}
                  onClick={() => handleClickKl(e)}
                >
                  <div
                    className={[
                      styles.itemKlName,
                      e.tenant?.toString() === tenantId?.toString()
                        ? styles.itemKlActive
                        : '',
                    ].join(' ')}
                  >
                    {e.desc}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        {tenantId !== -18000 && (
          <div className={styles.klRight}>
            <div className={styles.header}>
              <span className={styles.title}>话术维护</span>
              <div>
                <Button
                  type="primary"
                  className={styles.btn}
                  onClick={() => {
                    setModalType(2);
                    setModalOpen(true);
                  }}
                >
                  新建话术
                </Button>
                <Upload
                  maxCount={1}
                  fileList={[]}
                  accept=".json"
                  customRequest={(...item) => customRequest(...item) as any}
                >
                  <Button
                    loading={isUploadLoading}
                    icon={<CloudUploadOutlined />}
                    style={{ marginLeft: '5px' }}
                  >
                    导入
                  </Button>
                </Upload>
              </div>
            </div>
            <div className={styles.tableContent} id="klTableWrap">
              <Table
                columns={column}
                dataSource={tableData}
                loading={isLoading}
                rowKey={(record) => record.guid}
                scroll={{ y: tableHeight, x: 850 }}
                pagination={false}
              ></Table>
            </div>
            <div className={styles.subPagination}>
              <Pagination
                current={pageIndex}
                showSizeChanger={true}
                pageSize={pageSize}
                total={total}
                showTotal={(total) => `总共 ${total} 条`}
                onChange={onChange}
              />
            </div>
          </div>
        )}
        {tenantId === -18000 && (
          <div className={styles.klRight}>
            <KcList tenantId={tenantId} tenantName={tenantName} />
          </div>
        )}
      </div>
      <Modal
        title={
          modalType === 2
            ? '新增话术'
            : modalType === 1
            ? '编辑话术'
            : '查看话术'
        }
        forceRender
        open={isModalOpen}
        footer={modalType === 0 ? null : undefined}
        onOk={handlerUpdate}
        onCancel={() => {
          setModalOpen(false);
          // setLanguageId('');
          form.setFieldsValue({
            name: '',
            categoryId: undefined,
            description: '',
          });
        }}
        width={'540px'}
        getContainer={false}
      >
        <Form form={form} {...layout}>
          <Form.Item label="话术名称" name="name" rules={[{ required: true }]}>
            <Input maxLength={20} placeholder="请输入话术名称，限制20字" />
          </Form.Item>
          <Form.Item
            label="业务线"
            name="tenantName"
            rules={[{ required: true }]}
          >
            <Input disabled maxLength={20} />
          </Form.Item>
          {/* <Form.Item
            label="话术分类"
            name="categoryId"
            rules={[{ required: true }]}
          >
            <FourCategories modalType={modalType} onChange={handleChange} />
          </Form.Item> */}
          <Form.Item
            label="话术描述"
            name="description"
            rules={[{ required: true }]}
          >
            <TextArea
              rows={4}
              maxLength={200}
              placeholder="请输入话术，限制200字"
              showCount
            ></TextArea>
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        title="语音测试"
        open={showVoiceTestModel}
        width={'440px'}
        onOk={handleCallTest}
        onCancel={handleCloseCallTest}
        getContainer={false}
      >
        <Form form={voiceForm} {...layout}>
          <Form.Item
            label="手机号"
            name="iphone"
            rules={[
              {
                required: true,
                max: 11,
                pattern: /^1\d{10}$/,
                message: '请输入正确的手机号',
              },
            ]}
          >
            <Input maxLength={11} placeholder="请输入手机号" />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};
export default Language;
