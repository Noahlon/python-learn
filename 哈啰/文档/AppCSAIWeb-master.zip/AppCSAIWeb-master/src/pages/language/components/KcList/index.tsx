import React, { FC, useEffect, useState } from 'react';
import {
  Button,
  Space,
  Table,
  Typography,
  Popconfirm,
  message,
  Pagination,
  Upload,
} from 'antd';
import { history } from 'umi';
import {
  kcList,
  createKc,
  editKc,
  deleteKc,
  importKc,
  uploadFile,
  exportkc,
} from '@/api/language';
import styles from '@/pages/kbmanage/index.less';
import AddKcModal from '@/pages/klmaintain/components/AddKcModal';
import { CloudUploadOutlined } from '@ant-design/icons';

export interface Prop {
  tenantId?: number;
  tenantName?: string;
}

export interface IKCList {
  tenant?: number | string;
  description?: string;
  guid?: string;
  name?: string;
}

const KcList: FC<Prop> = ({ tenantId, tenantName }) => {
  const [tableData, setTableData] = useState<IKCList[]>([]);
  const [isLoading, setLoading] = useState<boolean>(false);
  const [pageSize, setPageSize] = useState(10);
  const [tableHeight, setTableHeight] = useState<string | number>('auto');
  const [total, setTotal] = useState<number>(0);
  // 0关闭 1编辑 2新增 3查看
  const [modalKcType, setModalKcType] = useState<number>(0);
  const [curKcInfo, setCurKcInfo] = useState(undefined);
  const [pageIndex, setPageIndex] = useState<number>(1);
  const [isUploadLoading, setIsUploadLoading] = useState(false);

  // 编辑
  const handleEditKc = (type, item) => {
    setCurKcInfo(item);
    setModalKcType(type);
  };

  // 导出话术
  const handlerExport = async (record: any) => {
    const dest = message.loading('正在导出');
    const res = await exportkc({ guid: record.guid });
    if (res.success && res.data) {
      let elink = document.createElement('a');
      elink.style.display = 'none';
      // let newUrl = (res?.aliOssUrl as unknown as string).replace('http', 'https');
      elink.href = res?.data.aliOssUrl as unknown as string;
      elink.download = '知识集合列表';
      document.body.appendChild(elink);
      elink.click();
      setTimeout(() => {
        document.body.removeChild(elink);
      }, 300);
    }
    dest?.();
  };

  const column = [
    {
      title: '集合名称',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '集合备注',
      dataIndex: 'description',
      key: 'description',
    },
    {
      title: '操作',
      dataIndex: 'guid',
      key: 'guid',
      fixed: 'right',
      render: function operation(text: string, record: IKCList) {
        return (
          <Space direction="horizontal">
            {
              <Typography.Link onClick={() => handleEditKc(1, record)}>
                编辑
              </Typography.Link>
            }
            {
              <Typography.Link
                onClick={() =>
                  history?.push({
                    pathname: '/language/klmaintain',
                    search: `?guid=${record?.guid}&tenant=${
                      record.tenant
                    }&tenantName=${encodeURIComponent(
                      '全局',
                    )}&kcId=${encodeURIComponent(record?.guid)}`,
                  })
                }
              >
                知识维护
              </Typography.Link>
            }
            {
              <Typography.Link onClick={() => handlerExport(record)}>
                导出
              </Typography.Link>
            }
            {
              <Popconfirm
                title="是否确认删除该集合？"
                // eslint-disable-next-line @typescript-eslint/no-use-before-define
                onConfirm={() => handlerDelete(record?.guid)}
              >
                <Typography.Link>删除</Typography.Link>
              </Popconfirm>
            }
          </Space>
        );
      },
    },
  ];

  // 获取高度变化
  const handleHeightEvent = () => {
    const ele = document.getElementById('klTableWrap');
    setTableHeight((ele?.clientHeight || 300) - 55);
  };

  // 获取table数据
  const handlerGetLists = async (params) => {
    if (!tenantId) return;
    setLoading(true);
    const param: any = {
      tenants: [tenantId],
      pageNum: params.pageNum || pageIndex,
      pageSize: params.pageSize || pageSize,
    };
    const data = await kcList(param);
    if (data) {
      if (data.list && data.list?.length) {
        setTableData(data.list as IKCList[]);
        setTotal(Number(data?.totalRecord) || 0);
        setTimeout(() => {
          handleHeightEvent();
        }, 0);
      } else {
        setTableData([]);
      }
    } else {
      setTableData([]);
    }
    setLoading(false);
  };

  // 删除
  const handlerDelete = async (guid: string) => {
    const res = await deleteKc({ guid });
    if (res?.success) {
      message.success('删除成功');
      setPageIndex(1);
      handlerGetLists({
        pageNum: 1,
      });
    }
  };

  // 分页
  const onChange = (page: number | undefined, size: number | undefined) => {
    const params = { pageSize: size, pageNum: 1 };
    if (size !== pageSize) {
      setPageIndex(1);
      setPageSize(size);
    } else {
      setPageIndex(page);
      params.pageNum = page;
    }
    handlerGetLists(params);
  };

  // 新增编辑
  const handlerKlOk = (val) => {
    const params = {
      tenant: tenantId,
      name: val?.name,
      description: val?.guidDesc,
      guid: modalKcType === 1 ? val.guid : undefined,
    };
    const action = modalKcType === 2 ? createKc : editKc;
    action(params)
      .then((data: any) => {
        if (data?.success) {
          message.success('操作成功');
          setPageIndex(1);
          handlerGetLists({
            pageNum: 1,
          });
          setModalKcType(0);
          setCurKcInfo(undefined);
        } else {
        }
      })
      .catch((e: any) => {
        console.log(e);
      });
  };

  // 导入话术
  const customRequest = async ({ file }) => {
    const formData = new FormData();
    formData.append('file', file);
    const dest = message.loading('正在导入');
    try {
      setIsUploadLoading(true);
      const res = (await uploadFile(formData)) as any;
      if (res.url) {
        const resp = (await importKc({ aliOssUrl: res?.url })) as any;
        if (resp.data && resp.success) {
          message.success('导入成功');
          setPageIndex(1);
          handlerGetLists({
            pageNum: 1,
          });
        }
      }
    } catch (e) {
      // 上传失败
    }
    dest?.();
    setIsUploadLoading(false);
  };

  useEffect(() => {
    setPageIndex(1);
    handlerGetLists({
      pageNum: 1,
    });
  }, [tenantId]);

  return (
    <>
      <div className={styles.header}>
        <span className={styles.title}>知识集合</span>
        <div>
          <Button
            type="primary"
            className={styles.btn}
            onClick={() => {
              handleEditKc(2, undefined);
            }}
          >
            新建知识集合
          </Button>
          <Upload
            maxCount={1}
            fileList={[]}
            accept=".json"
            customRequest={(...item) => customRequest(...item) as any}
          >
            <Button
              loading={isUploadLoading}
              icon={<CloudUploadOutlined />}
              style={{ marginLeft: '5px' }}
            >
              导入
            </Button>
          </Upload>
        </div>
      </div>
      <div className={styles.tableContent} id="klTableWrap">
        <Table
          columns={column}
          dataSource={tableData}
          loading={isLoading}
          rowKey={(record) => record.guid}
          scroll={{ y: tableHeight, x: 850 }}
          pagination={false}
        ></Table>
      </div>
      <div className={styles.subPagination}>
        <Pagination
          current={pageIndex}
          showSizeChanger={true}
          pageSize={pageSize}
          total={total}
          showTotal={(total) => `总共 ${total} 条`}
          onChange={onChange}
        />
      </div>
      <AddKcModal
        tenantName={tenantName}
        tenant={tenantId}
        type={modalKcType}
        info={curKcInfo}
        onOk={handlerKlOk}
        onCancel={() => {
          setCurKcInfo(undefined);
          setModalKcType(0);
        }}
      />
    </>
  );
};
export default KcList;
