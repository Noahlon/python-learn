import React, { useEffect, useRef, useState } from 'react';
import { queryCommendIntention, CommendIntentionObj } from '@/api/intention';
import { List, message } from 'antd';
import { debounce } from 'lodash';
import { useModel } from '@umijs/max';
import styles from './index.less';

const DEFAULT_DATA = [
  {
    faqId: '-1',
    name: '未知',
  },
];

interface Prop {
  recommendKey: number;
}

const RecommendList: React.FC<Prop> = ({ recommendKey }) => {
  const { selectedFaqId, setSelectedFaqId } = useModel('Intention');
  const [loading, setLoading] = useState(false);
  const [recommendData, setRecommendData] = useState<CommendIntentionObj[]>([]);
  const pageNumRef = useRef(1);
  const totalPagesRef = useRef<number>(undefined);

  const getCommendIntention = async (isScroll = false) => {
    if (
      isScroll &&
      totalPagesRef.current !== undefined &&
      pageNumRef.current > totalPagesRef.current
    ) {
      message.info('已经到底啦');
      return;
    }

    if (!isScroll) {
      pageNumRef.current = 1;
    } else {
      pageNumRef.current = pageNumRef.current + 1;
    }

    setLoading(true);
    const params = {
      pageSize: 100,
      pageNum: pageNumRef.current,
    };
    const res = await queryCommendIntention(params);
    if (res?.data?.list) {
      const { list, totalPages } = res.data;
      if (isScroll) {
        setRecommendData([...recommendData, ...list]);
      } else {
        setRecommendData([...DEFAULT_DATA, ...list]);
      }
      totalPagesRef.current = totalPages;
    }
    setLoading(false);
  };

  const changeFaqId = (id: string) => {
    // 二次点击时取消选中
    if (id === selectedFaqId) {
      setSelectedFaqId(null);
    } else {
      setSelectedFaqId(id);
    }
  };

  const handleScroll = debounce((target: HTMLDivElement) => {
    const { scrollHeight, scrollTop, clientHeight } = target || {};
    if (scrollHeight - scrollTop === clientHeight) {
      getCommendIntention(true);
    }
  }, 500);

  useEffect(() => {
    return () => {
      setSelectedFaqId(undefined);
      pageNumRef.current = 1;
      totalPagesRef.current = undefined;
    };
  }, []);

  useEffect(() => {
    getCommendIntention();
  }, [recommendKey]);

  return (
    <div
      className={styles.recommendListWrap}
      onScroll={(e: React.UIEvent<HTMLDivElement>) => handleScroll(e.target)}
    >
      <List
        size="small"
        header={<div className={styles.title}>推荐命中意图</div>}
        bordered
        className={styles.listComp}
        dataSource={recommendData}
        loading={loading}
        renderItem={(item) => (
          <List.Item
            className={`${styles.item} ${
              item.faqId === selectedFaqId ? styles.active : ''
            }`}
            onClick={() => changeFaqId(item.faqId)}
          >
            {item.name}
          </List.Item>
        )}
      />
    </div>
  );
};

export default RecommendList;
