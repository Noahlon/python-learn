import React, { useEffect, useRef, useState } from 'react';
import {
  Button,
  Cascader,
  DatePicker,
  Form,
  Input,
  Modal,
  Popover,
  Space,
  Table,
  Typography,
  Tag,
} from 'antd';
import {
  findIntentionLearningRecord,
  IntentionLearningRecordType,
  ignoreIntentionRecord,
} from '@/api/intention';
import { v1 as uuidv1 } from 'uuid';
import { getDropList } from '@/api/blacklist';
import moment from 'moment';
import ItentionLearningModal from '@/components/ItentionLearningModal';
import { ExclamationCircleOutlined } from '@ant-design/icons';
import RecommendList from '../RecommendList';
import { useAccess, useModel } from '@umijs/max';
import styles from './index.less';

const labelWrapStyle = {
  width: '100%',
  overflow: 'hidden',
};

const labelTableWrapStyle = {
  ...labelWrapStyle,
  display: 'flex',
};

const labelItemStyle = {
  padding: '3px 10px',
  color: '#999',
  background: 'rgba(214, 214, 215, 0.6)',
  fontSize: '12px',
  borderRadius: '3px',
  margin: '2px 5px 2px 0',
  display: 'inline-block',
};

const labelTableItemStyle = {
  ...labelItemStyle,
  flexShrink: 0,
};

const PendingHandle: React.FC = () => {
  const { selectedFaqId, setSelectedFaqId } = useModel('Intention');
  const [form] = Form.useForm();
  const access = useAccess();
  const ref = useRef(null);
  const tableRef = useRef();
  const [tableHeight, setTableHeight] = useState(300);
  const [tableLoading, setTableLoading] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>([]);
  const [total, setTotal] = useState(0);
  const [filedsTree, setFiledsTree] = useState([]);
  const [modalArr, setModalArr] = useState([]);
  const [page, setPage] = useState(1);
  const [obj, setObj] = useState();
  const [recommendKey, setRecommendKey] = useState(0);
  const selectedFaqIdRef = useRef(undefined);

  // form值转化接口所需值
  const search = async () => {
    const res = await form.validateFields();
    console.log(res);
    let obj: any = {};
    if (res?.userInput) {
      obj = {
        userInput: res.userInput,
      };
    }
    if (res?.speechName) {
      obj = {
        ...obj,
        speechName: res.speechName,
      };
    }
    if (res?.bizIdArr) {
      obj = {
        ...obj,
        bizId: res.bizIdArr[1],
      };
    }
    if (res?.commendIntentionName) {
      obj = {
        ...obj,
        commendIntentionName: res.commendIntentionName,
      };
    }
    if (res?.commendCollectionName) {
      obj = {
        ...obj,
        commendCollectionName: res.commendCollectionName,
      };
    }
    if (res?.createTime) {
      obj = {
        ...obj,
        startCreateTime: moment(res?.createTime[0]._d).format(
          'YYYY-MM-DD HH:mm:ss',
        ),
        endCreateTime: moment(res?.createTime[1]._d).format(
          'YYYY-MM-DD HH:mm:ss',
        ),
      };
    }
    if (res?.txtLength?.userInputLengthStart) {
      obj = {
        ...obj,
        userInputLengthStart: +res?.txtLength?.userInputLengthStart,
      };
    }
    if (res?.txtLength?.userInputLengthEnd) {
      obj = {
        ...obj,
        userInputLengthEnd: +res?.txtLength?.userInputLengthEnd,
      };
    }
    setObj(obj);
    return obj;
  };

  /**
   * tableData
   */
  const getTableData = async (
    pageNum: number,
    pageSize: number,
    obj: IntentionLearningRecordType = {},
  ) => {
    setTableLoading(true);
    let params = obj;
    if (selectedFaqIdRef.current) {
      params = { commendIntentionId: selectedFaqIdRef.current };
    }
    const { data } = await findIntentionLearningRecord({
      pageSize,
      pageNum,
      status: 0,
      ...params,
    });
    if (data?.list?.length > 0) {
      setTableData(data?.list);
      setTotal(data?.totalRecord);
    } else {
      if (selectedFaqId) {
        // 如果选择聚类意图，列表没数据就刷新聚类意图
        setSelectedFaqId(null);
        setRecommendKey((key) => key + 1);
      }
      setTableData([]);
      setTotal(0);
    }
    setSelectedRowKeys([]);
    setTableLoading(false);
  };
  // 模糊搜索-所属行业
  const getFiledsTree = async () => {
    const { data } = await getDropList({ includeScene: true });
    if (data) {
      data.forEach((it) => {
        it?.children.forEach((item) => {
          item.children = [];
        });
      });
      setFiledsTree(data);
    } else {
      setFiledsTree([]);
    }
  };
  // 忽略
  const ignoreIntentionRecords = async (recordIds) => {
    await ignoreIntentionRecord({ recordIds });
    const obj = await search();
    // 数据库反映延迟
    setTimeout(() => {
      getTableData(page, 100, obj);
    }, 1000);
  };

  // 单条忽略
  const singleIgnore = (id) => {
    ignoreIntentionRecords([id]);
  };

  // 单条学习
  const singleLearn = (id) => {
    ref?.current?.openModal();
    setModalArr([id]);
  };

  const columns: any = [
    {
      title: '用户文本',
      dataIndex: 'userInput',
      key: 'userInput',
      fixed: 'left',
      width: 312,
      ellipsis: true,
    },
    {
      title: '分词结果',
      dataIndex: 'segments',
      key: 'segments',
      render: (text) => {
        return text?.length ? text.join(' ') : '-';
      },
    },
    { title: '话术', dataIndex: 'speechName', key: 'speechName' },
    {
      title: '行业',
      dataIndex: 'bizSceneName',
      key: 'bizSceneName',
      render: (_, record) => {
        return `${record?.bizName}/${record?.bizSecondName}/${record?.bizSceneName}`;
      },
    },
    {
      title: '意图集合',
      dataIndex: 'kcs',
      key: 'kcs',
      width: 260,
      render: (text: string) => {
        if (text?.length > 0) {
          try {
            if (Array.isArray(text)) {
              const getContent = (name?: string) => (
                <div
                  style={
                    name === 'table' ? labelTableWrapStyle : labelWrapStyle
                  }
                >
                  {text.map((item) => (
                    <span
                      key={`${uuidv1()}${item.name}`}
                      style={
                        name === 'table' ? labelTableItemStyle : labelItemStyle
                      }
                    >
                      {item.name}
                    </span>
                  ))}
                </div>
              );
              return (
                <Popover
                  content={getContent()}
                  trigger="hover"
                  placement="topLeft"
                  // className={styles.labelPop}
                  // getPopupContainer={(triggerNode) =>
                  //   triggerNode.parentElement || document.body
                  // }
                >
                  {getContent('table')}
                </Popover>
              );
            }
          } catch (error) {}
        } else {
          return '-';
        }
      },
    },
    {
      title: '推荐集合',
      dataIndex: 'commendCollectionName',
      key: 'commendCollectionName',
      render: (text: string) => {
        return text ?? '-';
      },
    },
    {
      title: '推荐意图',
      dataIndex: 'commendIntentionName',
      key: 'commendIntentionName',
      width: 360,
      render: (text: string, record) => {
        return (
          <Space>
            <span>{text ?? '-'}</span>
            {record?.rate && <Tag color="default">{record.rate}</Tag>}
          </Space>
        );
      },
    },
    {
      title: '来源通话记录sessionid',
      dataIndex: 'sessionId',
      key: 'sessionId',
      width: 360,
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      key: 'createTime',
      render: (text) => {
        return text?.replace('T', ' ');
      },
    },
    {
      title: '操作',
      dataIndex: 'e',
      key: 'e',
      fixed: 'right',
      width: 100,
      render: (_, record) => {
        return (
          <Space>
            {access?.authCodeList?.includes('Call-Intention-Learn-Edit') && (
              <>
                <Typography.Link onClick={() => singleIgnore(record.id)}>
                  忽略
                </Typography.Link>
                <Typography.Link onClick={() => singleLearn(record.id)}>
                  学习
                </Typography.Link>
              </>
            )}
          </Space>
        );
      },
    },
  ];

  const onSelectChange = (newSelectedRowKeys: React.Key[]) => {
    // console.log('selectedRowKeys changed: ', newSelectedRowKeys);
    setSelectedRowKeys(newSelectedRowKeys);
    setModalArr(newSelectedRowKeys);
  };

  const rowSelection: any = {
    selectedRowKeys,
    onChange: onSelectChange,
  };

  // 模糊搜索
  const searchClick = async () => {
    setSelectedFaqId(undefined); // 取消选中推荐意图
    setPage(1);
    const obj = await search();
    setRecommendKey((key) => key + 1);
    setTimeout(() => {
      getTableData(1, 100, obj);
    }, 10);
  };

  // 模糊重置
  const reset = () => {
    setSelectedFaqId(undefined); // 取消选中推荐意图
    setPage(1);
    form.resetFields();
    setTimeout(() => {
      getTableData(1, 100);
    }, 10);
  };

  useEffect(() => {
    selectedFaqIdRef.current = selectedFaqId;
    if (selectedFaqId) {
      const params = { commendIntentionId: selectedFaqId };
      setPage(1);
      getTableData(1, 100, params);
      form.resetFields();
    } else if (selectedFaqId === null) {
      // 二次点击取消选中推荐意图
      setPage(1);
      getTableData(1, 100);
      form.resetFields();
    }
  }, [selectedFaqId]);

  useEffect(() => {
    if (tableRef?.current) {
      // @ts-ignore
      setTableHeight(tableRef.current.clientHeight - 119);
    }
    getTableData(1, 100);
    getFiledsTree();
  }, []);

  return (
    <div className={styles.pendinghandle}>
      <div className={styles.top}>
        <div className={styles.form}>
          <Form form={form} layout="inline">
            <Form.Item label="用户文本" name="userInput">
              <Input
                placeholder="请输入"
                style={{ width: '260px' }}
                allowClear
              />
            </Form.Item>
            <Form.Item label="用户文本">
              <Input.Group compact>
                <Form.Item
                  name={['txtLength', 'userInputLengthStart']}
                  rules={[{ pattern: /^[0-9]*$/, message: '' }]}
                  noStyle
                >
                  <Input placeholder="请输入" style={{ width: 115 }} />
                </Form.Item>
                <Input
                  placeholder="-"
                  disabled
                  style={{ textAlign: 'center', width: 30 }}
                />
                <Form.Item
                  name={['txtLength', 'userInputLengthEnd']}
                  rules={[{ pattern: /^[0-9]*$/, message: '' }]}
                  noStyle
                >
                  <Input placeholder="请输入" style={{ width: 117 }} />
                </Form.Item>
              </Input.Group>
            </Form.Item>
            <Form.Item label="话术名称" name="speechName">
              <Input
                placeholder="请输入"
                style={{ width: '260px' }}
                allowClear
              />
            </Form.Item>
            <Form.Item label="所属行业" name="bizIdArr">
              <Cascader
                style={{ width: '260px' }}
                allowClear
                placeholder="请选择"
                options={filedsTree}
                fieldNames={{
                  label: 'name',
                  value: 'id',
                }}
              />
            </Form.Item>
            <Form.Item label="创建时间" name="createTime">
              <DatePicker.RangePicker
                style={{ width: '260px' }}
                showTime
                allowClear
                placeholder={['请选择', '请选择']}
                disabledDate={(current) => {
                  return (
                    current < moment().subtract(30, 'days') ||
                    current > moment().endOf('days')
                  );
                }}
              />
            </Form.Item>
            <Form.Item label="推荐集合" name="commendCollectionName">
              <Input
                placeholder="请输入"
                style={{ width: '260px' }}
                allowClear
              />
            </Form.Item>
            <Form.Item label="推荐意图" name="commendIntentionName">
              <Input
                placeholder="请输入"
                style={{ width: '260px' }}
                allowClear
              />
            </Form.Item>
          </Form>
          <div style={{ flex: '1' }}>
            <Button
              type="primary"
              style={{ marginRight: 10 }}
              onClick={searchClick}
            >
              查询
            </Button>
            <Button onClick={reset}>重置</Button>
          </div>
        </div>
        {access?.authCodeList?.includes('Call-Intention-Learn-Edit') && (
          <div style={{ marginBottom: 20 }}>
            <Button
              type="primary"
              style={{ marginRight: '10px' }}
              disabled={!selectedRowKeys?.length}
              onClick={() => {
                Modal.confirm({
                  title: '提示',
                  icon: <ExclamationCircleOutlined />,
                  content: '确定批量忽略吗？',
                  okText: '确认',
                  cancelText: '取消',
                  onOk: () => {
                    ignoreIntentionRecords(modalArr);
                  },
                });
              }}
            >
              批量忽略
            </Button>
            <Button
              type="primary"
              disabled={!selectedRowKeys?.length}
              onClick={ref?.current?.openModal}
            >
              批量学习
            </Button>
          </div>
        )}
      </div>
      <div className={styles.contentWrap}>
        <RecommendList recommendKey={recommendKey} />
        <div className={styles.table} ref={tableRef}>
          <Table
            columns={columns}
            dataSource={tableData}
            rowSelection={rowSelection}
            rowKey={(record) => record.id}
            loading={tableLoading}
            scroll={{ y: tableHeight, x: 2200 }}
            pagination={{
              pageSize: 100,
              current: page,
              total: total,
              showSizeChanger: false,
              showTotal: (total) => `共${total}项数据`,
              onChange: (val) => {
                getTableData(val, 100, obj);
                setPage(val);
              },
            }}
          />
        </div>
      </div>
      <ItentionLearningModal
        ref={ref}
        getTableData={() => {
          getTableData(page, 100, obj);
        }}
        type="ITENTIONLAERNING"
        modalArr={modalArr}
        page={page}
        formObj={obj}
      />
    </div>
  );
};
export default PendingHandle;
