import React, {
  useState,
  forwardRef,
  useImperativeHandle,
  useEffect,
} from 'react';
import { Cascader, Form, Input, Modal } from 'antd';
import { getSpeechListByTrade } from '@/api/speech';
import { setIntentionSetting, getIntentionSetting } from '@/api/intention';
import { isIntegerBarringZero, getIdList } from '@/utils';

const getArrByOpt = (guid, data) => {
  let obj: any;

  let brk: boolean = false;
  for (let i = 0; i < data.length; i++) {
    if (!brk) {
      for (let j = 0; j < data[i]?.children?.length; j++) {
        if (!brk) {
          for (let k = 0; k < data[i]?.children[j]?.children?.length; k++) {
            if (!brk) {
              if (data[i]?.children[j]?.children[k].guid === guid) {
                obj = {
                  speechGroupId: data[i].children[j].children[k].speechGroupId,
                  speechName: data[i].children[j].children[k].speechName,
                };
                brk = true;
              }
            } else break;
          }
        } else break;
      }
    } else break;
  }

  return obj;
};

interface PropTypes {
  ref: any;
}

const SettingModal: React.FC<PropTypes> = forwardRef(({}, ref) => {
  const [formSetting] = Form.useForm();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [opt, setOpt] = useState([]);
  const [speechGroupInfos, setSpeechGroupInfos] = useState<any>([]);
  const [inputFlag, setInputFlag] = useState<boolean>();

  // 设置级联
  const getSettingOpt = async () => {
    const { data } = await getSpeechListByTrade({ status: 1 });
    if (data) {
      setOpt(data);
    } else {
      setOpt([]);
    }
  };
  // 设置
  const setIntentionSettings = async (textLength, speechGroupInfos) => {
    await setIntentionSetting({ textLength, speechGroupInfos });
  };
  // 获取设置
  const getIntentionSettings = async () => {
    const { data } = await getIntentionSetting();
    // let brk: boolean = false;
    const arr: any = [];
    if (data) {
      data?.speechGroupInfos?.forEach((o) => {
        // for (let i = 0; i < opt.length; i++) {
        //   if (!brk) {
        //     for (let j = 0; j < opt[i]?.children?.length; j++) {
        //       if (!brk) {
        //         for (
        //           let k = 0;
        //           k < opt[i]?.children[j]?.children?.length;
        //           k++
        //         ) {
        //           if (!brk) {
        //             if (
        //               opt[i]?.children[j]?.children[k].speechGroupId ===
        //               o.speechGroupId
        //             ) {
        //               arr.push([
        //                 opt[i].guid,
        //                 opt[i]?.children[j].guid,
        //                 opt[i]?.children[j]?.children[k].guid,
        //               ]);
        //               brk = true;
        //             }
        //           } else break;
        //         }
        //       } else break;
        //     }
        //   } else break;
        // }
        // brk = false;
        arr.push(getIdList(opt, 'speechGroupId', o.speechGroupId, 'guid'));
      });
      formSetting.setFieldValue('textLength', data?.textLength + '');
      formSetting.setFieldValue('speechGroupInfos', arr);
    }
  };

  // 关闭弹窗并清空
  const clear = () => {
    setIsModalOpen(false);
    formSetting.resetFields();
  };

  // 弹窗确认
  const handleOk = async () => {
    const res = await formSetting.validateFields();
    console.log(res);
    if (speechGroupInfos?.length) {
      setIntentionSettings(+res?.textLength, speechGroupInfos);
    } else if (inputFlag) {
      const newSpeechGroupInfos = [];
      res.speechGroupInfos.forEach((it) => {
        newSpeechGroupInfos.push(getArrByOpt(it[2], opt));
      });
      console.log('newSpeechGroupInfos', newSpeechGroupInfos);
      setIntentionSettings(+res?.textLength, newSpeechGroupInfos);
    }
    clear();
  };

  useImperativeHandle(ref, () => ({
    openModal: () => {
      setIsModalOpen(true);
    },
  }));

  useEffect(() => {
    getSettingOpt();
  }, []);

  useEffect(() => {
    if (isModalOpen) {
      getIntentionSettings();
    } else {
      setSpeechGroupInfos([]);
      setInputFlag(false);
    }
  }, [isModalOpen]);

  return (
    <Modal title="设置" open={isModalOpen} onOk={handleOk} onCancel={clear}>
      <Form form={formSetting} labelCol={{ span: 6 }} wrapperCol={{ span: 14 }}>
        <Form.Item
          name="textLength"
          label="文本长度>=："
          rules={[
            { required: true, message: '' },
            {
              validator: (_, value) => {
                const res = isIntegerBarringZero(value);
                if (res) return Promise.resolve();
                else return Promise.reject('请输入输入>=1的整数');
              },
            },
          ]}
        >
          <Input
            onChange={(val) => {
              if (val) {
                setInputFlag(true);
              } else setInputFlag(false);
            }}
          />
        </Form.Item>
        <Form.Item
          name="speechGroupInfos"
          label="话术范围："
          rules={[
            { required: true, message: '' },
            {
              validator: (_, value) => {
                let bool = false;
                for (let i = 0; i < value.length; i++) {
                  if (value[i]?.length !== 3) {
                    bool = true;
                    break;
                  } else {
                    bool = false;
                  }
                }
                if (bool) {
                  return Promise.reject('请输入话术范围');
                } else return Promise.resolve();
              },
            },
          ]}
        >
          <Cascader
            multiple
            placeholder="请选择"
            allowClear
            showCheckedStrategy={Cascader.SHOW_CHILD}
            options={opt}
            fieldNames={{ label: 'name', value: 'guid' }}
            onChange={(val, selcectOpt: any) => {
              // console.log('selcectOpt', selcectOpt);
              // console.log('val', val);
              let arr: any = [];
              selcectOpt.forEach((it) => {
                if (it?.length === 3) {
                  arr.push({
                    speechGroupId: it[2]?.speechGroupId,
                    speechName: it[2]?.name,
                  });
                }
              });
              setSpeechGroupInfos(arr);
            }}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
});
export default SettingModal;
