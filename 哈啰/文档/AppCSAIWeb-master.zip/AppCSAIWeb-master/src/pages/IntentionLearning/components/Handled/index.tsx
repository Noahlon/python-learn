import React, { useEffect, useRef, useState } from 'react';
import {
  Button,
  Cascader,
  DatePicker,
  Form,
  Input,
  Popover,
  Select,
  Space,
  Table,
  Tag,
} from 'antd';
import { getDropList } from '@/api/blacklist';
import { v1 as uuidv1 } from 'uuid';
import {
  findIntentionLearningRecord,
  IntentionLearningRecordType,
} from '@/api/intention';
import moment from 'moment';
import styles from './index.less';

const selcetOpt = [
  { label: '已忽略', value: 1 },
  { label: '已学习', value: 2 },
];

const labelWrapStyle = {
  width: '100%',
  overflow: 'hidden',
};

const labelTableWrapStyle = {
  ...labelWrapStyle,
  display: 'flex',
};

const labelItemStyle = {
  padding: '3px 10px',
  color: '#999',
  background: 'rgba(214, 214, 215, 0.6)',
  fontSize: '12px',
  borderRadius: '3px',
  margin: '2px 5px 2px 0',
  display: 'inline-block',
};

const labelTableItemStyle = {
  ...labelItemStyle,
  flexShrink: 0,
};

const Handled: React.FC = () => {
  const [form] = Form.useForm();
  const tableRef = useRef();
  const [tableHeight, setTableHeight] = useState(300);
  const [tableLoading, setTableLoading] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [total, setTotal] = useState(0);
  const [filedsTree, setFiledsTree] = useState([]);
  const [page, setPage] = useState(1);

  /**
   * tableData
   */
  const getTableData = async (
    pageNum: number,
    pageSize: number,
    obj: IntentionLearningRecordType = {},
  ) => {
    setTableLoading(true);
    const { data } = await findIntentionLearningRecord({
      pageSize,
      pageNum,
      status: 1,
      ...obj,
    });
    if (data?.list) {
      setTableData(data?.list);
      setTotal(data?.totalRecord);
    } else setTableData([]);
    setTableLoading(false);
  };
  // 模糊搜索-所属行业
  const getFiledsTree = async () => {
    const { data } = await getDropList({ includeScene: true });
    if (data) {
      data.forEach((it) => {
        it?.children.forEach((item) => {
          item.children = [];
        });
      });
      setFiledsTree(data);
    } else {
      setFiledsTree([]);
    }
  };

  const columns: any = [
    {
      title: '用户文本',
      dataIndex: 'userInput',
      key: 'userInput',
      fixed: 'left',
      width: 312,
    },
    {
      title: '处理结果',
      dataIndex: 'handleResult',
      key: 'handleResult',
      width: 100,
      render: (text) => {
        switch (text) {
          case 0:
            return '默认';
          case 1:
            return '已忽略';
          case 2:
            return '已学习';
        }
      },
    },
    { title: '话术', dataIndex: 'speechName', key: 'speechName' },
    {
      title: '行业',
      dataIndex: 'bizSceneName',
      key: 'bizSceneName',
      width: 150,
      render: (_, record) => {
        return `${record?.bizName}/${record?.bizSecondName}/${record?.bizSceneName}`;
      },
    },
    {
      title: '意图集合',
      dataIndex: 'learnKc',
      key: 'learnKc',
      width: 260,
      render: (text: any) => {
        if (text) {
          const getContent = (name?: string) => {
            return (
              <div
                style={name === 'table' ? labelTableWrapStyle : labelWrapStyle}
              >
                {text.map((item) => (
                  <span
                    key={`${uuidv1()}${item.name}`}
                    style={
                      name === 'table' ? labelTableItemStyle : labelItemStyle
                    }
                  >
                    {item.name}
                  </span>
                ))}
              </div>
            );
          };
          return (
            <Popover
              content={getContent()}
              trigger="hover"
              placement="topLeft"
              // className={styles.labelPop}
              // getPopupContainer={(triggerNode) =>
              //   triggerNode.parentElement || document.body
              // }
            >
              {getContent('table')}
            </Popover>
          );
        } else {
          return '-';
        }
      },
    },
    {
      title: '推荐集合',
      dataIndex: 'commendCollectionName',
      key: 'commendCollectionName',
      render: (text: string) => {
        return text ?? '-';
      },
    },
    {
      title: '推荐意图',
      dataIndex: 'commendIntentionName',
      key: 'commendIntentionName',
      width: 360,
      render: (text: string, record) => {
        return (
          <Space>
            <span>{text ?? '-'}</span>
            {record?.rate && <Tag color="default">{record.rate}</Tag>}
          </Space>
        );
      },
    },
    {
      title: '来源通话记录sessionid',
      dataIndex: 'sessionId',
      key: 'sessionId',
      width: 360,
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      key: 'createTime',
      render: (text) => {
        return text?.replace('T', ' ');
      },
    },
    {
      title: '操作人',
      dataIndex: 'author',
      key: 'author',
      render: (text) => {
        return text ? text : '-';
      },
    },
    {
      title: '操作时间',
      dataIndex: 'handleTime',
      key: 'handleTime',
      fixed: 'right',
      render: (text) => {
        return text?.replace('T', ' ');
      },
    },
  ];

  const search = async () => {
    const res = await form.validateFields();
    let obj: any = {};
    if (res?.userInput) {
      obj = {
        userInput: res.userInput,
      };
    }
    if (res?.speechName) {
      obj = {
        ...obj,
        speechName: res.speechName,
      };
    }
    if (res?.bizIdArr) {
      obj = {
        ...obj,
        bizId: res.bizIdArr[1],
      };
    }
    if (res?.handleResult) {
      obj = {
        ...obj,
        handleResult: res.handleResult,
      };
    }
    if (res?.commendIntentionName) {
      obj = {
        ...obj,
        commendIntentionName: res.commendIntentionName,
      };
    }
    if (res?.commendCollectionName) {
      obj = {
        ...obj,
        commendCollectionName: res.commendCollectionName,
      };
    }
    if (res?.handleTime) {
      obj = {
        ...obj,
        startHandleTime: moment(res?.handleTime[0]._d).format(
          'YYYY-MM-DD HH:mm:ss',
        ),
        endHandleTime: moment(res?.handleTime[1]._d).format(
          'YYYY-MM-DD HH:mm:ss',
        ),
      };
    }
    if (res?.createTime) {
      obj = {
        ...obj,
        startCreateTime: moment(res?.createTime[0]._d).format(
          'YYYY-MM-DD HH:mm:ss',
        ),
        endCreateTime: moment(res?.createTime[1]._d).format(
          'YYYY-MM-DD HH:mm:ss',
        ),
      };
    }
    if (res?.txtLength?.userInputLengthStart) {
      obj = {
        ...obj,
        userInputLengthStart: +res?.txtLength?.userInputLengthStart,
      };
    }
    if (res?.txtLength?.userInputLengthEnd) {
      obj = {
        ...obj,
        userInputLengthEnd: +res?.txtLength?.userInputLengthEnd,
      };
    }
    return obj;
  };

  // 模糊搜索
  const searchClick = async () => {
    setPage(1);
    const obj = await search();
    getTableData(1, 100, obj);
  };

  const resetForm = () => {
    setPage(1);
    form.resetFields();
    getTableData(1, 100);
  };

  useEffect(() => {
    if (tableRef.current) {
      // @ts-ignore
      setTableHeight(tableRef.current.clientHeight - 119);
    }
    getTableData(1, 100);
    getFiledsTree();
  }, []);

  return (
    <div className={styles.handled}>
      <div className={styles.form}>
        <Form form={form} style={{ width: '80%' }} layout="inline">
          <Form.Item label="用户文本" name="userInput">
            <Input placeholder="请输入" allowClear style={{ width: '260px' }} />
          </Form.Item>
          <Form.Item label="用户文本">
            <Input.Group compact>
              <Form.Item
                name={['txtLength', 'userInputLengthStart']}
                rules={[{ pattern: /^[0-9]*$/, message: '' }]}
                noStyle
              >
                <Input placeholder="请输入" style={{ width: 115 }} />
              </Form.Item>
              <Input
                placeholder="-"
                disabled
                style={{ textAlign: 'center', width: 30 }}
              />
              <Form.Item
                name={['txtLength', 'userInputLengthEnd']}
                rules={[{ pattern: /^[0-9]*$/, message: '' }]}
                noStyle
              >
                <Input placeholder="请输入" style={{ width: 117 }} />
              </Form.Item>
            </Input.Group>
          </Form.Item>
          <Form.Item label="话术名称" name="speechName">
            <Input placeholder="请输入" allowClear style={{ width: '260px' }} />
          </Form.Item>
          <Form.Item label="所属行业" name="bizIdArr">
            <Cascader
              style={{ width: '260px' }}
              allowClear
              options={filedsTree}
              placeholder="请选择"
              fieldNames={{
                label: 'name',
                value: 'id',
              }}
            />
          </Form.Item>
          <Form.Item label="处理结果" name="handleResult">
            <Select
              options={selcetOpt}
              placeholder="请选择"
              allowClear
              style={{ width: '260px' }}
            />
          </Form.Item>
          <Form.Item label="处理时间" name="handleTime">
            <DatePicker.RangePicker
              style={{ width: '260px' }}
              showTime
              allowClear
              placeholder={['请选择', '请选择']}
              disabledDate={(current) => {
                return (
                  current < moment().subtract(30, 'days') ||
                  current > moment().endOf('days')
                );
              }}
            />
          </Form.Item>
          <Form.Item label="创建时间" name="createTime">
            <DatePicker.RangePicker
              style={{ width: '260px' }}
              showTime
              allowClear
              placeholder={['请选择', '请选择']}
              disabledDate={(current) => {
                return (
                  current < moment().subtract(30, 'days') ||
                  current > moment().endOf('days')
                );
              }}
            />
          </Form.Item>
          <Form.Item label="推荐集合" name="commendCollectionName">
            <Input placeholder="请输入" style={{ width: '260px' }} allowClear />
          </Form.Item>
          <Form.Item label="推荐意图" name="commendIntentionName">
            <Input placeholder="请输入" style={{ width: '260px' }} allowClear />
          </Form.Item>
        </Form>
        <div>
          <Button
            type="primary"
            style={{ marginRight: 10 }}
            onClick={searchClick}
          >
            查询
          </Button>
          <Button onClick={resetForm}>重置</Button>
        </div>
      </div>
      <div className={styles.contentWrap}>
        <div className={styles.table} ref={tableRef}>
          <Table
            columns={columns}
            dataSource={tableData}
            rowKey={(record) => record.id}
            loading={tableLoading}
            scroll={{ y: tableHeight, x: 2200 }}
            pagination={{
              showSizeChanger: false,
              current: page,
              pageSize: 100,
              total: total,
              showTotal: (total) => `${total} 条数据`,
              onChange: async (val) => {
                const obj = await search();
                getTableData(val, 100, obj);
                setPage(val);
              },
            }}
          />
        </div>
      </div>
    </div>
  );
};
export default Handled;
