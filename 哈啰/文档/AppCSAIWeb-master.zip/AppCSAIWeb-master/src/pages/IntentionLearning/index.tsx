import React, { useRef } from 'react';
import styles from './index.less';
import { Tabs, Button } from 'antd';
import PendingHandle from './components/PendingHandle';
import SettingModal from './components/SettingModal';
import Handled from './components/Handled';
import { useAccess } from '@umijs/max';

const IntentionLearning: React.FC = () => {
  const modalRef = useRef(null);
  const access = useAccess();

  return (
    <div className={styles.intentionLearning}>
      <Tabs
        tabBarExtraContent={
          access?.authCodeList?.includes('Call-Intention-Learn-Edit') ? (
            <Button
              type="link"
              onClick={() => {
                if (modalRef.current) modalRef.current?.openModal();
              }}
            >
              设置
            </Button>
          ) : null
        }
        destroyInactiveTabPane
        items={[
          {
            label: '待处理',
            key: '1',
            children: <PendingHandle />,
          },
          {
            label: '已处理',
            key: '2',
            children: <Handled />,
          },
        ]}
      />
      <SettingModal ref={modalRef} />
    </div>
  );
};
export default IntentionLearning;
