import React from 'react';
import {
  Form,
  Input,
  Select,
  Button,
  Row,
  Col,
  Space,
  SelectProps,
  DatePicker,
} from 'antd';

import { SmsMonitorParams } from '@/api/smsMonitor';
import moment from 'moment';

const { RangePicker } = DatePicker;
interface IProps {
  tenantOpts: SelectProps['options'];
  onSearch: (data: SmsMonitorParams) => void;
  onReset: () => void;
}

const colLayout = { xl: 8, sm: 12, xs: 24 };

const SearchTemplate: React.FC<IProps> = ({
  onSearch,
  onReset,
  tenantOpts,
}) => {
  const [form] = Form.useForm();

  // 重置
  const handleReset = () => {
    form.resetFields();
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    onSearch?.(res);
  };

  return (
    <Form
      form={form}
      style={{ padding: '20px 20px 0' }}
      initialValues={{
        date: [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
      }}
    >
      <Row wrap={false}>
        <Col flex="auto">
          <Row gutter={16}>
            <Col {...colLayout}>
              <Form.Item name="date" label="日期">
                <RangePicker
                  allowClear={false}
                  disabledDate={(current) =>
                    current && current > moment().subtract(1, 'days')
                  }
                  style={{ width: '100%' }}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="templateName" label="短信模版">
                <Input placeholder="请输入短信模版" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="tenantIds" label="租户">
                <Select
                  placeholder="请选择租户"
                  allowClear
                  mode="multiple"
                  maxTagCount="responsive"
                  filterOption={(input, option) =>
                    (option?.label as string)
                      .toLowerCase()
                      .includes(input.toLowerCase())
                  }
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  options={tenantOpts}
                />
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none" style={{ marginLeft: '15px' }}>
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default SearchTemplate;
