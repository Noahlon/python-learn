import React, { useEffect, useState, useRef } from 'react';
import type { ColumnsType } from 'antd/es/table';
import ResizeTable from '@/components/ResizeTable';
import SearchTask from './SearchTask';
import TaskInfoModal from './TaskInfoModal';
import { taskChainColumns, DEFAULT_QUERY_PARAMS } from '../../config';
import {
  queryTaskChainRecord,
  TaskChainListObj,
  TaskChainListParams,
} from '@/api/smsShortLink';
import moment from 'moment';
import styles from '../../index.less';

const TaskChain: React.FC = () => {
  const [tableData, setTableData] = useState<TaskChainListObj[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  // pagination
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [tableTotal, setTableTotal] = useState<number>();
  // 搜索params
  const queryParams = useRef({ ...DEFAULT_QUERY_PARAMS });

  // 当前千人千链的taskGuid
  const [currentTask, setCurrentTask] = useState<TaskChainListObj>(undefined);

  // fetch千人千链列表
  const fetchTaskChainRecord = async () => {
    const params = {
      startCreateTime: moment().startOf('day').format('YYYY-MM-DD HH:mm:ss'),
      endCreateTime: moment().endOf('day').format('YYYY-MM-DD HH:mm:ss'),
      ...queryParams.current,
    };
    setTableLoading(true);
    const res = await queryTaskChainRecord(params);
    if (res?.data) {
      setTableData(res.data?.list);
      setTableTotal(res.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // 页面页数change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchTaskChainRecord();
  };

  // 短信模版columns
  const columns: ColumnsType<TaskChainListObj> = [
    ...taskChainColumns,
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 100,
      render: (_, record) => <a onClick={() => setCurrentTask(record)}>详情</a>,
    },
  ];

  // 搜索
  const handleSearch = (res: TaskChainListParams) => {
    queryParams.current = { ...queryParams.current, ...res };
    handlePageChange(1);
  };

  // 重置
  const handleReset = () => {
    queryParams.current = DEFAULT_QUERY_PARAMS;
    setPagination(DEFAULT_QUERY_PARAMS);
    fetchTaskChainRecord();
  };

  useEffect(() => {
    fetchTaskChainRecord();
  }, []);

  return (
    <>
      <div className={styles.taskChainWrap}>
        {/* 搜索区域 */}
        <SearchTask onSearch={handleSearch} onReset={handleReset} />
        {/* 千人千链列表 */}
        <ResizeTable
          columns={columns}
          dataSource={tableData}
          scroll={{ x: 1200 }}
          rowKey="taskGuid"
          containerId="taskChainTable"
          loading={tableLoading}
          pagination={{
            onChange: handlePageChange,
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            total: tableTotal,
          }}
        />
        {/* 千人千链详情modal */}
        <TaskInfoModal
          taskInfo={currentTask}
          onCancel={() => setCurrentTask(undefined)}
        />
      </div>
    </>
  );
};
export default TaskChain;
