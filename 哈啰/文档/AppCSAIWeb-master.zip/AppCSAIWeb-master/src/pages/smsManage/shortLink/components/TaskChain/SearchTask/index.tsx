import React from 'react';
import { Form, Input, Select, Button, Row, Col, Space, DatePicker } from 'antd';
import { TaskChainListParams } from '@/api/smsShortLink';
import moment from 'moment';
import { useModel } from '@umijs/max';
import { formatType } from '@/config';

interface IProps {
  onSearch: (data: TaskChainListParams) => void;
  onReset: () => void;
}

const { RangePicker } = DatePicker;
const colLayout = { xl: 8, sm: 12, xs: 24 };

const SearchTask: React.FC<IProps> = ({ onSearch, onReset }) => {
  const { tenantOpts } = useModel('common');
  const [form] = Form.useForm();

  // 重置
  const handleReset = () => {
    form.resetFields();
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    if (res?.createTime?.length > 1) {
      res.startCreateTime = moment(res.createTime[0]).format(formatType);
      res.endCreateTime = moment(res.createTime[1]).format(formatType);
    }
    delete res?.createTime;
    onSearch?.(res);
  };

  return (
    <Form
      form={form}
      style={{ padding: '20px 20px 0' }}
      initialValues={{
        createTime: [moment().startOf('day'), moment().endOf('day')],
      }}
    >
      <Row wrap={false}>
        <Col flex="auto">
          <Row gutter={16}>
            <Col {...colLayout}>
              <Form.Item name="tenantIds" label="租户">
                <Select
                  placeholder="请选择租户"
                  showSearch
                  allowClear
                  mode="multiple"
                  maxTagCount="responsive"
                  optionFilterProp="label"
                  options={tenantOpts}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="taskName" label="任务名称">
                <Input allowClear placeholder="请输入任务名称" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="createTime" label="创建时间">
                <RangePicker
                  showTime
                  placeholder={['开始时间', '结束时间']}
                  allowClear={false}
                />
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none" style={{ marginLeft: '15px' }}>
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default SearchTask;
