import React, { useEffect, useState, memo, useRef } from 'react';
import { Drawer, Button, Row, Col, DatePicker } from 'antd';
import {
  queryChainHitInfo,
  exportChainHitLog,
  ChainHitLogInfoParams,
  ChainHitLogObj,
} from '@/api/smsShortLink';
import { DEFAULT_QUERY_PARAMS, chainInfoColumns } from '../../config';
import { DownloadOutlined } from '@ant-design/icons';
import ResizeTable from '@/components/ResizeTable';
import moment from 'moment';
import { formatType } from '@/config';
import { handleDownload } from '@/utils';
import { isEmpty } from 'lodash';
import styles from '../../index.less';

const { RangePicker } = DatePicker;

interface Props {
  shortChainUrl: string;
  isTaskModal?: boolean;
  onCancel: () => void;
}

const ChainLogModal: React.FC<Props> = memo(
  ({ shortChainUrl, isTaskModal, onCancel }) => {
    const [tableData, setTableData] = useState<ChainHitLogObj[]>([]);
    const [tableTotal, setTableTotal] = useState<number>();
    const [tableLoading, setTableLoading] = useState(false);
    const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
    // 搜索params
    const queryParams = useRef<ChainHitLogInfoParams>({
      ...DEFAULT_QUERY_PARAMS,
    });
    const [exportLoading, setExportLoading] = useState(false);

    // fetch短链详情列表
    const fetchChainLog = async () => {
      setTableLoading(true);
      const params = {
        ...queryParams.current,
        shortChainUrl,
      };
      const res = await queryChainHitInfo(params);
      if (res?.data) {
        setTableData(res.data?.list);
        setTableTotal(res.data?.totalRecord);
      }
      setTableLoading(false);
    };

    // 页面pagination change
    const handlePageChange = (pageNum: number, pageSize?: number) => {
      const paginationObj = {
        pageNum,
        pageSize: pageSize ?? queryParams.current.pageSize,
      };
      queryParams.current = { ...queryParams.current, ...paginationObj };
      setPagination(paginationObj);
      fetchChainLog();
    };

    // 点击时间change
    const handleChangeTime = (
      dates: [moment.Moment | null, moment.Moment | null],
    ) => {
      let params = {};
      if (dates?.length > 1) {
        const startCreateTime = moment(dates[0]).format(formatType);
        const endCreateTime = moment(dates[1]).format(formatType);
        params = {
          startCreateTime,
          endCreateTime,
        };
      }
      queryParams.current = { ...queryParams.current, ...params };
      if (isEmpty(params)) {
        delete queryParams.current.startCreateTime;
        delete queryParams.current.endCreateTime;
      }
      handlePageChange(1);
    };

    // 导出
    const handleExport = async () => {
      setExportLoading(true);
      try {
        const params = { ...queryParams.current, shortChainUrl };
        delete params.pageNum;
        delete params.pageSize;
        const res = await exportChainHitLog(params);
        if (res?.data?.ossUrl) {
          handleDownload(res.data.ossUrl, '短链点击详情');
        }
      } catch (error) {}
      setExportLoading(false);
    };

    useEffect(() => {
      if (shortChainUrl) {
        fetchChainLog();
      } else {
        queryParams.current = { ...DEFAULT_QUERY_PARAMS };
        setPagination({ ...DEFAULT_QUERY_PARAMS });
      }
    }, [shortChainUrl]);

    return (
      <>
        <Drawer
          open={!!shortChainUrl}
          width={900}
          onClose={onCancel}
          title={isTaskModal ? '点击明细' : '访问详情'}
        >
          <div className={styles.chainLogModal}>
            {!isTaskModal && (
              <Row justify="space-between" style={{ marginBottom: '20px' }}>
                <Col>
                  <RangePicker
                    allowClear
                    showTime={{
                      hideDisabledOptions: true,
                      defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                    }}
                    placeholder={['点击开始时间', '点击结束时间']}
                    onChange={handleChangeTime}
                  />
                </Col>
                <Col>
                  <Button
                    type="primary"
                    icon={<DownloadOutlined />}
                    loading={exportLoading}
                    onClick={handleExport}
                  >
                    导出
                  </Button>
                </Col>
              </Row>
            )}
            {/* 短链详情列表 */}
            <ResizeTable
              columns={chainInfoColumns}
              dataSource={tableData}
              scroll={{ x: 1200 }}
              rowKey="id"
              containerId="chainLogTable"
              loading={tableLoading}
              pagination={{
                onChange: handlePageChange,
                current: pagination.pageNum,
                pageSize: pagination.pageSize,
                total: tableTotal,
              }}
            />
          </div>
        </Drawer>
      </>
    );
  },
);

export default ChainLogModal;
