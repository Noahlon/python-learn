import React from 'react';
import type { ColumnsType } from 'antd/es/table';
import {
  ChainObj,
  ChainHitLogObj,
  TaskChainListObj,
  TaskChainObj,
} from '@/api/smsShortLink';
import { Badge, Typography } from 'antd';
import { text2Tooltip } from '@/utils/format';
import { toThousands } from '@/utils';

/**
 * variable
 */
export const statusMaps = [
  { label: '已禁用', value: 0 },
  { label: '启用中', value: 1 },
];

export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 100,
};

// 短链列表columns
export const chainManageColumns: ColumnsType<ChainObj> = [
  {
    title: '短链名称',
    dataIndex: 'shortChainName',
    fixed: 'left',
    render: (text: string) => text2Tooltip(text, 160),
  },
  {
    title: '归属租户',
    dataIndex: 'tenantName',
    width: 150,
  },
  {
    title: '原始链接',
    dataIndex: 'originalUrl',
    render: (text: string) => text2Tooltip(text, 260),
  },
  {
    title: '短链',
    dataIndex: 'shortChainUrl',
    render: (text: string) => {
      return React.createElement(
        Typography.Paragraph,
        { copyable: { text }, style: { marginBottom: 0, display: 'flex' } },
        text2Tooltip(text),
      );
    },
  },
  {
    title: '有效期',
    dataIndex: 'effectiveDate',
    render: (text: number) => {
      return text + '天';
    },
    width: 100,
  },
  {
    title: '绑定模版',
    dataIndex: 'templateNames',
    render: (text: string) => text2Tooltip(text, 200),
  },
  {
    title: '状态',
    dataIndex: 'status',
    render: (text: number) => {
      return React.createElement(Badge, {
        status: text === 0 ? 'error' : 'success',
        text: statusMaps.find((it) => it.value === text)?.label,
      });
    },
    width: 100,
  },
  {
    title: '点击数',
    dataIndex: 'hitNum',
    width: 110,
    render: (text) => {
      return toThousands(text);
    },
  },
  {
    title: '创建人',
    dataIndex: 'author',
    width: 130,
  },
  {
    title: '创建时间',
    dataIndex: 'createTime',
  },
];

// 短链详情columns
export const chainInfoColumns: ColumnsType<ChainHitLogObj> = [
  {
    title: '点击时间',
    dataIndex: 'hitTime',
    fixed: 'left',
    width: 180,
  },
  {
    title: '手机机型',
    dataIndex: 'mobilePhoneModel',
    render: (text: string) => text ?? '-',
    width: 100,
  },
  {
    title: '操作系统',
    dataIndex: 'operatingSystem',
    width: 100,
    render: (text: string) => text ?? '-',
  },
  {
    title: '浏览器',
    dataIndex: 'browser',
    render: (text: string) => text ?? '-',
  },
  {
    title: 'IP地址',
    dataIndex: 'ip',
    render: (text: string) => text ?? '-',
  },
  {
    title: 'IP归属地',
    dataIndex: 'ipAddress',
    width: 100,
    render: (text: string) => text ?? '-',
  },
  {
    title: 'IP所属运营商',
    dataIndex: 'ipAddressOwner',
    render: (text: string) => text ?? '-',
    width: 120,
  },
  {
    title: '屏幕分辨率',
    dataIndex: 'screenResolution',
    render: (text: string) => text ?? '-',
  },
];

// 千人千链列表columns
export const taskChainColumns: ColumnsType<TaskChainListObj> = [
  {
    title: '任务名称',
    dataIndex: 'taskName',
    fixed: 'left',
    render: (text: string) => text2Tooltip(text, 300),
  },
  {
    title: '任务id',
    dataIndex: 'taskGuid',
    render: (text: string) => text2Tooltip(text, 300),
  },
  {
    title: '租户名称',
    dataIndex: 'tenantName',
    width: 160,
  },
  {
    title: '短链数',
    dataIndex: 'shortChainNum',
    width: 100,
  },
  {
    title: '点击数',
    dataIndex: 'hitToTalNum',
    width: 100,
  },
  {
    title: '点击UV',
    dataIndex: 'hitUVNum',
    width: 100,
  },
  {
    title: '创建时间',
    dataIndex: 'createTime',
  },
];

// 千人千链详情columns
export const taskInfoColumns: ColumnsType<TaskChainObj> = [
  {
    title: '手机号',
    dataIndex: 'phoneNumber',
    fixed: 'left',
    width: 130,
  },
  {
    title: '原始链接',
    dataIndex: 'originalUrl',
    render: (text: string) => text2Tooltip(text, 300),
  },
  {
    title: '短链',
    dataIndex: 'shortChainUrl',
    render: (text: string) => text2Tooltip(text, 300),
  },
  {
    title: '意向分类',
    dataIndex: 'intentClassify',
    width: 80,
  },
  {
    title: '手机机型',
    dataIndex: 'mobilePhoneModel',
    render: (text: string) => text ?? '-',
    width: 100,
  },
  {
    title: '操作系统',
    dataIndex: 'operatingSystem',
    render: (text: string) => text ?? '-',
    width: 100,
  },
  {
    title: '浏览器',
    dataIndex: 'browser',
    render: (text: string) => text ?? '-',
  },
  {
    title: 'IP地址',
    dataIndex: 'ip',
    render: (text: string) => text ?? '-',
  },
  {
    title: 'IP归属地',
    dataIndex: 'ipAddress',
    render: (text: string) => text ?? '-',
  },
  {
    title: 'IP所属运营商',
    dataIndex: 'ipAddressOwner',
    render: (text: string) => text ?? '-',
    width: 100,
  },
  {
    title: '屏幕分辨率',
    dataIndex: 'screenResolution',
    render: (text: string) => text ?? '-',
  },
  {
    title: '点击次数',
    dataIndex: 'hitNum',
    width: 100,
  },
  {
    title: 'md5',
    dataIndex: 'userMd5',
    render: (text: string) => text ?? '-',
  },
  {
    title: 'userguid',
    dataIndex: 'userGuid',
    render: (text: string) => text ?? '-',
  },
  {
    title: 'usernewid',
    dataIndex: 'userNewId',
    width: 200,
    render: (text: string) => text ?? '-',
  },
  {
    title: '最近点击',
    dataIndex: 'lastHitTime',
  },
  {
    title: '创建时间',
    dataIndex: 'createTime',
  },
];
