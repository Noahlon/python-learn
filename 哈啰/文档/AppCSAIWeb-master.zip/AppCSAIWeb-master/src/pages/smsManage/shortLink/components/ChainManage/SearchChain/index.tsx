import React from 'react';
import { Form, Input, Select, Button, Row, Col, Space, DatePicker } from 'antd';
import { ChainListParams } from '@/api/smsShortLink';
import { useModel } from '@umijs/max';
import moment from 'moment';
import { formatType } from '@/config';
import { statusMaps } from '../../../config';

interface IProps {
  onSearch: (data: ChainListParams) => void;
  onReset: () => void;
}

const { RangePicker } = DatePicker;
const colLayout = { xl: 8, sm: 12, xs: 24 };

const SearchChain: React.FC<IProps> = ({ onSearch, onReset }) => {
  const { tenantOpts } = useModel('common');
  const [form] = Form.useForm();

  // 重置
  const handleReset = () => {
    form.resetFields();
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    if (res?.createTime?.length > 1) {
      res.startCreateTime = moment(res.createTime[0]).format(formatType);
      res.endCreateTime = moment(res.createTime[1]).format(formatType);
    }
    delete res?.createTime;
    onSearch?.(res);
  };

  return (
    <Form form={form} style={{ padding: '20px 20px 0' }}>
      <Row wrap={false}>
        <Col flex="auto">
          <Row gutter={16}>
            <Col {...colLayout}>
              <Form.Item name="tenantIds" label="租户">
                <Select
                  placeholder="请选择租户"
                  allowClear
                  showSearch
                  mode="multiple"
                  maxTagCount="responsive"
                  optionFilterProp="label"
                  options={tenantOpts}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="status" label="状态">
                <Select
                  placeholder="请选择状态"
                  allowClear
                  options={statusMaps}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="shortChainName" label="短链名称">
                <Input allowClear placeholder="请输入短链名称" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="originalUrl" label="原始链接">
                <Input allowClear placeholder="请输入原始链接" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="shortChainUrl" label="短链">
                <Input allowClear placeholder="请输入短链" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="templateName" label="绑定模版">
                <Input allowClear placeholder="请输入绑定模版" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="createTime" label="创建时间">
                <RangePicker
                  allowClear
                  showTime={{
                      hideDisabledOptions: true,
                      defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                  }}
                  placeholder={['开始时间', '结束时间']}
                />
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none" style={{ marginLeft: '15px' }}>
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default SearchChain;
