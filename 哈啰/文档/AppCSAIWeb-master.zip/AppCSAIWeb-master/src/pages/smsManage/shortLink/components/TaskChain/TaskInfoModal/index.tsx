import React, { useEffect, useState, useCallback, useRef } from 'react';
import type { ColumnsType } from 'antd/es/table';
import { Drawer, Button, Descriptions } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import ResizeTable from '@/components/ResizeTable';
import ChainLogModal from '../../ChainLogModal';
import {
  queryTaskChainRecordInfo,
  queryTaskChainInfo,
  exportTaskChain,
  ChainHitLogInfoParams,
  TaskChainObj,
  TaskChainListObj,
  TaskChainInfoObj,
} from '@/api/smsShortLink';
import { DEFAULT_QUERY_PARAMS, taskInfoColumns } from '../../../config';
import { handleDownload } from '@/utils';
import styles from '../../../index.less';

interface Props {
  taskInfo: TaskChainListObj;
  onCancel: () => void;
}

const TaskInfoModal: React.FC<Props> = ({ taskInfo, onCancel }) => {
  const [tableData, setTableData] = useState<TaskChainObj[]>([]);
  const [tableTotal, setTableTotal] = useState<number>();
  const [tableLoading, setTableLoading] = useState(false);
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  // 搜索params
  const queryParams = useRef<ChainHitLogInfoParams>({
    ...DEFAULT_QUERY_PARAMS,
  });
  // 详情
  const [taskDetail, setTaskDetail] = useState<TaskChainInfoObj['data']>();
  // 当前短链点击详情
  const [curShortChainUrl, setCurShortChainUrl] = useState<string>(undefined);
  const [exportLoading, setExportLoading] = useState(false);

  // fetch短链详情列表
  const fetchRecordInfo = async () => {
    setTableLoading(true);
    const params = {
      taskGuid: taskInfo.taskGuid,
      ...queryParams.current,
    };
    const res = await queryTaskChainRecordInfo(params);
    if (res?.data) {
      setTableData(res.data?.list);
      setTableTotal(res.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // fetch短链详情
  const fetchInfo = async () => {
    const params = {
      taskGuid: taskInfo.taskGuid,
    };
    const res = await queryTaskChainInfo(params);
    if (res?.data) {
      setTaskDetail(res.data);
    }
  };

  // 页面pagination change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchRecordInfo();
  };

  // 导出
  const handleExport = async () => {
    setExportLoading(true);
    try {
      const params = { taskGuid: taskInfo.taskGuid };
      const res = await exportTaskChain(params);
      if (res?.data?.ossUrl) {
        handleDownload(res.data.ossUrl);
      }
    } catch (error) {}
    setExportLoading(false);
  };

  // 短信模版columns
  const columns: ColumnsType<TaskChainObj> = [
    ...taskInfoColumns,
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 100,
      render: (_, record) => (
        <a onClick={() => setCurShortChainUrl(record.shortChainUrl)}>详情</a>
      ),
    },
  ];

  useEffect(() => {
    if (taskInfo?.taskGuid) {
      fetchRecordInfo();
      fetchInfo();
    } else {
      queryParams.current = { ...DEFAULT_QUERY_PARAMS };
      setPagination({ ...DEFAULT_QUERY_PARAMS });
    }
  }, [taskInfo]);

  return (
    <>
      <Drawer
        open={!!taskInfo?.taskGuid}
        width={900}
        onClose={onCancel}
        title="详情"
      >
        <div className={styles.taskInfoModal}>
          <div>
            <Descriptions contentStyle={{ paddingRight: 12 }}>
              <Descriptions.Item label="任务名称">
                {taskInfo?.taskName}
              </Descriptions.Item>
              <Descriptions.Item label="任务ID">
                {taskInfo?.taskGuid}
              </Descriptions.Item>
              <Descriptions.Item label="点击数">
                {taskDetail?.hitToTalNum}
              </Descriptions.Item>
              <Descriptions.Item label="租户名称">
                {taskInfo?.tenantName}
              </Descriptions.Item>
              <Descriptions.Item label="短链数">
                {taskDetail?.shortChainNum}
              </Descriptions.Item>
              <Descriptions.Item label="点击UV">
                {taskDetail?.hitUVNum}
              </Descriptions.Item>
            </Descriptions>
            <Button
              type="primary"
              icon={<DownloadOutlined />}
              loading={exportLoading}
              onClick={handleExport}
            >
              导出列表
            </Button>
          </div>
          {/* 短链详情列表 */}
          <ResizeTable
            columns={columns}
            dataSource={tableData}
            scroll={{ x: 3000 }}
            rowKey="id"
            containerId="taskInfoTable"
            loading={tableLoading}
            pagination={{
              onChange: handlePageChange,
              current: pagination.pageNum,
              pageSize: pagination.pageSize,
              total: tableTotal,
            }}
            style={{ marginTop: '20px' }}
          />

          {/* 短链访问详情modal */}
          <ChainLogModal
            shortChainUrl={curShortChainUrl}
            isTaskModal={true}
            onCancel={useCallback(() => setCurShortChainUrl(undefined), [])}
          />
        </div>
      </Drawer>
    </>
  );
};

export default TaskInfoModal;
