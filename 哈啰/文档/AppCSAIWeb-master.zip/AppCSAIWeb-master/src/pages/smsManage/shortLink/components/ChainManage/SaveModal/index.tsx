import React, { useState, memo, useEffect } from 'react';
import { Form, Modal, Input, message, InputNumber, Select } from 'antd';
import { saveChain, ChainSaveParams, ChainObj } from '@/api/smsShortLink';
import { useModel } from '@umijs/max';
import { LAYOUTLABELFIVE } from '@/constants/processconfig';

const { TextArea } = Input;
interface Prop {
  open: boolean;
  data: ChainObj;
  onOk: () => void;
  onCancel: () => void;
}

const ChainManageSaveModel: React.FC<Prop> = memo(
  ({ open, data, onCancel, onOk }) => {
    const { tenantOpts } = useModel('common');
    const [form] = Form.useForm();
    const [confirmLoading, setConfirmLoading] = useState(false);

    const handleOriginalUrlBlur = (value: string) => {
      if (!value) {
        return;
      }
      // 过滤空格和换行
      const filteredValue = value
        .trim()
        .replace(/\s+/g, '')
        .replace(/\n+/g, '');

      form.setFieldsValue({ originalUrl: filteredValue });
    };

    // 取消
    const handleCancel = () => {
      form.resetFields();
      onCancel?.();
    };

    // 添加/编辑短链
    const saveChainApi = async (params: ChainSaveParams) => {
      const isUpdate = !!data?.id;
      setConfirmLoading(true);

      if (isUpdate) {
        params.id = data.id;
      }
      const res = await saveChain(params);

      if (res?.success) {
        message.success(isUpdate ? '编辑成功' : '添加成功');
        onOk?.();
        handleCancel();
      }
      setConfirmLoading(false);
    };

    // 提交
    const handleOk = async () => {
      let params = await form.validateFields();
      params.shortChainName = params.shortChainName?.trim();
      saveChainApi(params);
    };

    useEffect(() => {
      if (open) {
        if (!!data) {
          form.setFieldsValue(data);
        } else {
          form.setFieldValue('effectiveDate', 30);
        }
      }
    }, [data, open]);

    return (
      <Modal
        open={open}
        title={!!data?.id ? '编辑短链' : '添加短链'}
        forceRender
        width="600px"
        onOk={handleOk}
        onCancel={handleCancel}
        confirmLoading={confirmLoading}
        getContainer={false}
      >
        <Form form={form} {...LAYOUTLABELFIVE}>
          <Form.Item
            label="短链名称"
            name="shortChainName"
            rules={[{ required: true }]}
          >
            <Input maxLength={50} placeholder="请输入短链名称，限制50字" />
          </Form.Item>
          <Form.Item
            label="原始链接"
            name="originalUrl"
            rules={[{ required: true }]}
          >
            <TextArea
              disabled={!!data}
              onBlur={(e) => handleOriginalUrlBlur(e.target.value)}
              maxLength={300}
              rows={3}
              placeholder="请输入原始链接，限制300字"
            />
          </Form.Item>
          <Form.Item
            name="tenantId"
            label="租户"
            rules={[{ required: true, message: '请选择租户' }]}
          >
            <Select
              disabled={!!data}
              placeholder="请选择租户"
              allowClear
              showSearch
              optionFilterProp="label"
              options={tenantOpts}
            />
          </Form.Item>
          <Form.Item
            label="有效期"
            name="effectiveDate"
            rules={[{ required: true }]}
          >
            <InputNumber
              precision={0}
              min={1}
              placeholder="请输入有效期，最大365天"
              addonAfter="天"
              style={{ width: '100%' }}
            />
          </Form.Item>
          <Form.Item label="备注" name="remark">
            <TextArea
              maxLength={120}
              rows={3}
              placeholder="请输入备注，限制120字"
            />
          </Form.Item>
        </Form>
      </Modal>
    );
  },
);

export default ChainManageSaveModel;
