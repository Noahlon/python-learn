import React, { useEffect } from 'react';
import ChainManage from './components/ChainManage';
import TaskChain from './components/TaskChain';
import { Tabs } from 'antd';
import { useModel } from '@umijs/max';
import styles from './index.less';

const ShortLink: React.FC = () => {
  const { fetchTenantOpts } = useModel('common');

  useEffect(() => {
    fetchTenantOpts();
  }, []);

  return (
    <div className={`${styles.shortLinkWrap} tabsFullHeight`}>
      <Tabs
        defaultActiveKey="1"
        destroyInactiveTabPane
        items={[
          {
            label: `短链管理`,
            key: '1',
            children: <ChainManage />,
          },
          {
            label: `千人千链`,
            key: '2',
            children: <TaskChain />,
          },
        ]}
      />
    </div>
  );
};
export default ShortLink;
