import React, { useEffect, useState, useRef, useCallback } from 'react';
import { Button, Space, Popconfirm, message, Typography } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { PlusOutlined } from '@ant-design/icons';
import ResizeTable from '@/components/ResizeTable';
import SearchChain from './SearchChain';
import SaveModel from './SaveModal';
import ChainLogModal from '../ChainLogModal';
import {
  queryChainList,
  changeChainStatus,
  ChainListParams,
  ChainObj,
} from '@/api/smsShortLink';
import { useAccess } from '@umijs/max';
import { chainManageColumns, DEFAULT_QUERY_PARAMS } from '../../config';
import styles from '../../index.less';

const ChainManage: React.FC = () => {
  const access = useAccess();
  const [tableData, setTableData] = useState<ChainObj[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  // pagination
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [tableTotal, setTableTotal] = useState<number>();
  // 搜索params
  const queryParams = useRef(DEFAULT_QUERY_PARAMS);
  // 短链新增/编辑
  const [chainSaveOpen, setChainSaveOpen] = useState(false);
  const [currentChain, setCurrentChain] = useState<ChainObj>(undefined);
  // 短链访问详情
  const [curShortChainUrl, setCurShortChainUrl] = useState<string>(undefined);

  // fetch短链列表
  const fetchChainList = async () => {
    const params = {
      ...queryParams.current,
    };
    setTableLoading(true);
    const res = await queryChainList(params);
    if (res?.data) {
      setTableData(res.data?.list);
      setTableTotal(res?.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // 页面页数change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchChainList();
  };

  // 启用禁用短链
  const handleChangeStatus = async (id: string, status: number) => {
    const params = {
      id,
      statusChange: status,
    };
    const res = await changeChainStatus(params);
    if (res?.success) {
      fetchChainList();
      message.success('操作成功');
    }
  };

  // 短链columns
  const columns: ColumnsType<ChainObj> = [
    ...chainManageColumns,
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 200,
      render: (_, record) => (
        <Space size="middle">
          {access?.authCodeList?.includes('Sms-Manage-ShortLink-Status') && (
            <>
              {record.status === 0 ? (
                <Popconfirm
                  title="启用该短链？"
                  onConfirm={() => handleChangeStatus(record.id, 1)}
                >
                  <a>
                    <Typography.Text type="success">启用</Typography.Text>
                  </a>
                </Popconfirm>
              ) : (
                <Popconfirm
                  title="禁用该短链？"
                  onConfirm={() => handleChangeStatus(record.id, 0)}
                >
                  <a>
                    <Typography.Text type="danger">禁用</Typography.Text>
                  </a>
                </Popconfirm>
              )}
            </>
          )}
          {access?.authCodeList?.includes('Sms-Manage-ShortLink-Detail') && (
            <a onClick={() => setCurShortChainUrl(record.shortChainUrl)}>
              访问详情
            </a>
          )}
          {access?.authCodeList?.includes('Sms-Manage-ShortLink-Edit') && (
            <a
              onClick={() => {
                setCurrentChain(record);
                setChainSaveOpen(true);
              }}
            >
              编辑
            </a>
          )}
        </Space>
      ),
    },
  ];

  // 搜索
  const handleSearch = (res: ChainListParams) => {
    queryParams.current = { ...queryParams.current, ...res };
    handlePageChange(1);
  };

  // 重置
  const handleReset = () => {
    queryParams.current = DEFAULT_QUERY_PARAMS;
    setPagination(DEFAULT_QUERY_PARAMS);
    fetchChainList();
  };

  // 新增/编辑刷新短链列表
  const handleOk = () => {
    if (!currentChain) {
      handlePageChange(1);
    } else {
      fetchChainList();
    }
  };

  useEffect(() => {
    fetchChainList();
  }, []);

  return (
    <>
      <div className={styles.chainManageWrap}>
        {/* 搜索区域 */}
        <SearchChain onSearch={handleSearch} onReset={handleReset} />

        {access?.authCodeList?.includes('Sms-Manage-ShortLink-Add') && (
          <div className={styles.addButton}>
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => {
                setCurrentChain(undefined);
                setChainSaveOpen(true);
              }}
            >
              新建
            </Button>
          </div>
        )}
        {/* 短链列表 */}
        <ResizeTable
          columns={columns}
          dataSource={tableData}
          scroll={{ x: 2000 }}
          rowKey="id"
          containerId="chainListTable"
          loading={tableLoading}
          pagination={{
            onChange: handlePageChange,
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            total: tableTotal,
          }}
        />
      </div>
      {/* 短链新增/编辑modal */}
      <SaveModel
        open={chainSaveOpen}
        data={currentChain}
        onOk={useCallback(handleOk, [])}
        onCancel={useCallback(() => setChainSaveOpen(false), [])}
      />
      {/* 短链访问详情modal */}
      <ChainLogModal
        shortChainUrl={curShortChainUrl}
        onCancel={useCallback(() => setCurShortChainUrl(undefined), [])}
      />
    </>
  );
};
export default ChainManage;
