import React from 'react';
import { ModelTrainObj, ResultListObj, VerifyListObj } from '@/api/modelTrain';
import { Badge, Typography } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { PresetStatusColorType } from 'antd/es/_util/colors';
import { text2Tooltip } from '@/utils/format';
import { BaseType } from 'antd/lib/typography/Base';

// 模型状态opts
export const modelStatusMap = [
  { label: '待训练', value: 'TO_BE_TRAINED', badgeStatus: 'default' },
  { label: '训练中', value: 'TRAINING', badgeStatus: 'processing' },
  { label: '待验证', value: 'TO_BE_VERIFY', badgeStatus: 'processing' },
  { label: '验证中', value: 'VERIFYING', badgeStatus: 'processing' },
  { label: '验证完成', value: 'VERIFY_COMPLETED', badgeStatus: 'success' },
  { label: '已废弃', value: 'DISCARD', badgeStatus: 'error' },
];

// 验证结果-判断结果opts
export const identifyResultMap = [
  { label: '正确', value: 1, textStatus: 'default' },
  { label: '错误', value: 0, textStatus: 'danger' },
];

// 模型列表columns
export const modelColumns: ColumnsType<ModelTrainObj> = [
  {
    title: '模型名称',
    dataIndex: 'modelName',
    fixed: 'left',
    width: 200,
  },
  {
    title: '模型ID',
    dataIndex: 'modelAlgorithmId',
    width: 160,
  },
  {
    title: '行业',
    dataIndex: 'biz',
    width: 180,
    render: (_, record) => {
      return `${record.levelOneBizName}/${record.levelTwoBizName}/${record.bizSceneName}`;
    },
  },
  {
    title: '版本',
    dataIndex: 'modelVersion',
  },
  {
    title: '状态',
    dataIndex: 'modelStatus',
    width: 120,
    render: (text: string) => {
      const curObj = modelStatusMap.find((item) => item.value === text);
      return React.createElement(Badge, {
        status: curObj?.badgeStatus as PresetStatusColorType,
        text: curObj?.label,
      });
    },
  },
  {
    title: '测试结果',
    dataIndex: 'modelTestResult',
    render: (text) => {
      return text ?? '-';
    },
  },
  {
    title: '意图数',
    dataIndex: 'intentionCount',
  },
  {
    title: '训练句子数',
    dataIndex: 'knowledgeCount',
  },
  {
    title: '验证时间',
    dataIndex: 'verifyTime',
    width: 180,
    sorter: true,
    sortDirections: ['descend', 'ascend'],
    render: (text) => {
      return text ? text : '-';
    },
  },
  {
    title: '训练时间',
    dataIndex: 'trainingTime',
    width: 180,
    sorter: true,
    sortDirections: ['descend', 'ascend'],
    render: (text) => {
      return text ? text : '-';
    },
  },
  {
    title: '创建时间',
    dataIndex: 'createTime',
    width: 180,
    sorter: true,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: '备注',
    dataIndex: 'modelRemark',
    width: 260,
    render: (text: string) => text2Tooltip(text),
  },
];

// 回归验证列表columns
export const verifyColumns: ColumnsType<VerifyListObj> = [
  {
    title: '验证句子',
    dataIndex: 'knowledgeDesc',
    width: 300,
  },
  {
    title: '正确意图',
    dataIndex: 'knowledgeName',
    width: 200,
  },
  {
    title: '错误提示',
    dataIndex: 'errorDesc',
    render: (text: string) => {
      return text ? text : '-';
    },
  },
];

// 验证结果列表columns
export const resultColumns: ColumnsType<ResultListObj> = [
  {
    title: '验证句子',
    dataIndex: 'verifyKnowledge',
    width: 300,
  },
  {
    title: '正确意图',
    dataIndex: 'correctIntention',
    width: 200,
  },
  {
    title: '模型识别意图',
    dataIndex: 'identifyIntention',
    render: (text: string) => {
      return text ? text : '-';
    },
    width: 200,
  },
  {
    title: '判断结果',
    dataIndex: 'identifyResult',
    render: (text: number) => {
      const curObj = identifyResultMap.find((item) => item.value === text);
      return React.createElement(
        Typography.Text,
        {
          type: curObj?.textStatus as BaseType,
        },
        curObj?.label,
      );
    },
    fixed: 'right',
    width: 100,
  },
];

export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 25,
};

export const DEFAULT_QUERY_PARAMS_2 = {
  pageNum: 1,
  pageSize: 100,
};
