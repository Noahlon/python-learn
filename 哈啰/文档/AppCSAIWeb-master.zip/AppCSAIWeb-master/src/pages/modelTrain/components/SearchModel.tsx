import React from 'react';
import { Form, Input, Cascader, Select, Button, Row, Col, Space } from 'antd';
import { SmsTemplateParams } from '@/api/smsTemplate';
import { useModel } from '@umijs/max';
import { modelStatusMap } from '../config';

interface IProps {
  onSearch: (data: SmsTemplateParams) => void;
  onReset: () => void;
}

const colLayout = { xl: 8, sm: 12, xs: 24 };
const SearchModel: React.FC<IProps> = ({ onSearch, onReset }) => {
  const { bizTree } = useModel('common');
  const [form] = Form.useForm();

  // 重置
  const handleReset = () => {
    form.resetFields();
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    if (res?.bizIdList?.length > 0) {
      res.bizId = res.bizIdList.at(-1);
      res.level = res.bizIdList.length;
      delete res.bizIdList;
    }
    onSearch?.(res);
  };

  return (
    <Form form={form}>
      <Row wrap={false}>
        <Col flex="auto">
          <Row gutter={16}>
            <Col {...colLayout}>
              <Form.Item name="modelName" label="模型名称">
                <Input allowClear placeholder="请输入模型名称" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="bizIdList" label="行业">
                <Cascader
                  allowClear
                  changeOnSelect
                  showSearch
                  options={bizTree}
                  placeholder="请选择行业"
                  fieldNames={{ label: 'name', value: 'id' }}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="modelStatus" label="状态">
                <Select
                  mode="multiple"
                  allowClear
                  optionFilterProp="label"
                  placeholder="请选择状态"
                  options={modelStatusMap}
                />
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none" style={{ marginLeft: '15px' }}>
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default SearchModel;
