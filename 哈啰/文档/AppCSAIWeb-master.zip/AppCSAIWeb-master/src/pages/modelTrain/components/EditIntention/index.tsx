import React, { FC, useEffect } from 'react';
import { Form, Modal, Input, message } from 'antd';
import {
  modelDimCreate,
  modelDimEdit,
  modelDimQueryData,
} from '@/api/modelTrain';
import { ICommonResponse } from '@/api/baseInterface';

export interface Prop {
  type?: number;
  info?: modelDimQueryData;
  modelId: string;
  onOk?: () => void;
  onCancel?: () => void;
}

const EditIntention: FC<Prop> = ({
  type,
  onOk,
  onCancel,
  info,
  modelId = '',
}) => {
  const [form] = Form.useForm();
  const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };

  // 提交
  const handleOk = async () => {
    let param = await form.validateFields();
    param.modelId = modelId;
    if (type === 2 && info?.guid) param.faqId = info?.faqId;
    const api = type === 1 ? modelDimCreate : modelDimEdit;
    const res: ICommonResponse = await api(param);
    if (res.success) {
      message.success('操作成功');
      onOk?.();
    }
  };

  useEffect(() => {
    if (info && type) {
      console.log(info);
      form.setFieldsValue(info);
    } else {
      form.resetFields();
    }
  }, [type]);

  return (
    <>
      <Modal
        open={!!type}
        title={type === 1 ? '添加意图' : '编辑意图'}
        forceRender={true}
        width={'540px'}
        onOk={handleOk}
        onCancel={() => {
          form.resetFields();
          onCancel?.();
        }}
        getContainer={false}
      >
        <Form form={form} {...layout}>
          <Form.Item
            label="意图名称"
            name="name"
            rules={[
              { required: true },
              {
                validator: (_, value) => {
                  if (value && value.trim() === '') {
                    return Promise.reject(new Error('请输入意图名称'));
                  }
                  if (value && value.length > 20) {
                    return Promise.reject(
                      new Error('意图名称长度为20字符以内'),
                    );
                  }
                  return Promise.resolve();
                },
              },
            ]}
          >
            <Input placeholder="请输入意图名称" maxLength={20} />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};
export default EditIntention;
