import { keySingleRender } from '@/utils';
import { CloseOutlined } from '@ant-design/icons';
import {
  Button,
  Empty,
  message,
  Pagination,
  Popconfirm,
  Space,
  Spin,
  Tooltip,
} from 'antd';
import React, { FC, useCallback, useEffect, useRef, useState } from 'react';
import AddSimilar from '../AddSimilar';
import {
  modelDimQueryData,
  modelKnowledgeQuestion,
  modelKnowledgeQuestionList,
  modelKnowledgeQuestionReq,
  modelTrainDeleteFaq,
  modelTrainDeleteFaqAll,
} from '@/api/modelTrain';
import styles from './index.less';

export interface Prop {
  intention?: modelDimQueryData;
  searchText?: string;
  modelStatus?: boolean;
  modelId: string;
  onOk?: () => void;
}

const SimilarityList: FC<Prop> = ({
  intention,
  searchText,
  modelStatus = false,
  modelId,
  onOk,
}) => {
  const [similarQData, setSimilarQData] =
    useState<modelKnowledgeQuestionList[]>();
  const [loading, setLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [showAddModal, setAddModal] = useState(false);
  const [pageSize, setPageSize] = useState(100);
  const [pageIndex, setPageIndex] = useState(1);
  const [loadingCopy, setLoadingCopy] = useState(false);
  const queryParams = useRef({
    pageNum: 1,
    pageSize: 100,
  });
  // 相似问列表
  const fetchExtendFaqList = async () => {
    if (!intention?.faqId) {
      setSimilarQData([]);
      setTotal(0);
      return;
    }
    setLoading(true);
    const param: modelKnowledgeQuestionReq = {
      pageNum: queryParams.current.pageNum,
      pageSize: queryParams.current.pageSize,
      faqId: intention?.faqId,
    };
    const res = await modelKnowledgeQuestion(param);
    if (res.code === '0') {
      const { list, pageNum, pageSize, totalRecord } = res.data;
      setSimilarQData(list);
      setPageSize(pageSize);
      setPageIndex(pageNum);
      setTotal(totalRecord);
    }
    setLoading(false);
  };

  // 删除全部
  const handleDeleteAll = async () => {
    setLoading(true);
    const res = await modelTrainDeleteFaqAll({
      faqId: intention?.faqId,
      modelId,
    });
    if (res.success) {
      message.success('清除成功');
      fetchExtendFaqList();
    }
    setLoading(false);
    onOk?.();
  };

  // 删除单个
  const handleDeleteSimilar = async (info) => {
    setLoading(true);
    const res = await modelTrainDeleteFaq({
      guid: info.guid,
      modelId,
    });
    if (res.success) {
      message.success('操作成功');
      fetchExtendFaqList();
    }
    setLoading(false);
    onOk?.();
  };

  // 关闭新增弹框
  const handleAddCancel = useCallback(() => {
    setAddModal(false);
  }, []);

  // 新增提交
  const handleAddOk = useCallback(() => {
    handleAddCancel();
    fetchExtendFaqList();
    onOk?.();
  }, [intention]);

  // 分页
  const onChange = (page: number | undefined, size: number | undefined) => {
    if (size !== pageSize) {
      queryParams.current.pageNum = 1;
      queryParams.current.pageSize = size;
      setPageIndex(1);
      setPageSize(size);
    } else {
      setPageIndex(page);
      queryParams.current.pageNum = page;
    }
    fetchExtendFaqList();
  };

  const copyClick = async () => {
    const param: modelKnowledgeQuestionReq = {
      pageNum: 1,
      pageSize: 10000,
      faqId: intention?.faqId,
    };
    setLoadingCopy(true);
    const res = await modelKnowledgeQuestion(param);
    if (res?.code === '0') {
      const { list } = res.data;
      const text = list?.map((item) => item?.similarFaqName)?.join(';');
      // 原生操作剪切板
      navigator.clipboard.writeText(text);
      message.success('复制成功');
    }
    setLoadingCopy(false);
  };

  useEffect(() => {
    queryParams.current.pageNum = 1;
    queryParams.current.pageSize = 100;
    fetchExtendFaqList();
  }, [intention]);

  return (
    <>
      <div className={styles.top}>
        <div>相似问{total}个</div>
        <Space>
          <Button
            type="link"
            disabled={similarQData?.length === 0}
            loading={loadingCopy}
            onClick={() => copyClick()}
          >
            复制
          </Button>
          {modelStatus && (
            <Popconfirm
              title="清除全部相似问？"
              onConfirm={handleDeleteAll}
              disabled={similarQData?.length === 0}
            >
              <Button type="link" disabled={similarQData?.length === 0}>
                清除
              </Button>
            </Popconfirm>
          )}
          {modelStatus && (
            <Button type="link" onClick={() => setAddModal(true)}>
              新增
            </Button>
          )}
        </Space>
      </div>

      <Spin spinning={loading}>
        <div className={styles.content}>
          {!!similarQData?.length ? (
            similarQData?.map((item) => (
              <div key={item.guid} className={styles.item}>
                {modelStatus && (
                  <CloseOutlined
                    className={styles.icon}
                    onClick={() => handleDeleteSimilar(item)}
                  />
                )}
                <Tooltip title={item.similarFaqName}>
                  <div
                    className={styles.text}
                    dangerouslySetInnerHTML={{
                      __html: keySingleRender(item.similarFaqName, searchText),
                    }}
                  ></div>
                </Tooltip>
              </div>
            ))
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
          )}
        </div>
      </Spin>
      <Pagination
        current={pageIndex}
        showSizeChanger={true}
        pageSize={pageSize}
        total={total}
        onChange={onChange}
        pageSizeOptions={[100, 200, 500]}
      />
      <AddSimilar
        open={showAddModal}
        onCancel={handleAddCancel}
        onOk={handleAddOk}
        faqId={intention?.faqId}
        modelId={modelId}
      />
    </>
  );
};
export default SimilarityList;
