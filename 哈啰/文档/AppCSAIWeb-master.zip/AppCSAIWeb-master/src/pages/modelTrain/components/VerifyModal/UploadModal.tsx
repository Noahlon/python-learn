import FileUploadShowList from '@/components/FileUploadShowList';
import { InboxOutlined } from '@ant-design/icons';
import { Button, Modal, message } from 'antd';
import React, { useRef, useState } from 'react';
import { uploadModelVerify } from '@/api/modelTrain';
import styles from './index.less';

interface Prop {
  modelId: string;
  visible: boolean;
  onCancel: () => void;
  onOk: () => void;
}

const UploadModal: React.FC<Prop> = ({ onCancel, onOk, modelId, visible }) => {
  const ref = useRef();
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [fileList, setFileList] = useState([]);

  // 导入取消
  const handleImportCancel = () => {
    onCancel();
    // @ts-ignore
    if (ref.current) ref.current?.clearData();
    setFileList([]);
  };

  // 批量导入
  const handleImportOk = async () => {
    const list = fileList?.filter((item) => item.status === 'done');
    if (!list?.length) return message.error('请先上传文件');
    setConfirmLoading(true);
    const dest = message.loading('正在导入');
    const res = await uploadModelVerify({
      modelId,
      ossUrl: list[0].url,
    });
    if (res?.success) {
      handleImportCancel();
      onOk();
    }
    dest?.();
    setConfirmLoading(false);
  };

  return (
    <Modal
      open={visible}
      title="批量导入"
      forceRender={true}
      width={'540px'}
      onOk={handleImportOk}
      onCancel={handleImportCancel}
      confirmLoading={confirmLoading}
      getContainer={false}
      destroyOnClose={true}
    >
      <FileUploadShowList
        ref={ref}
        showUploadList={true}
        uploadType=".xlsx"
        onChange={(list) => setFileList(list)}
      >
        <div className={styles.uploadIcon}>
          <InboxOutlined />
        </div>
        <div className={styles.notice}>点击上传 / 将文件拖拽到这里</div>
        <div className={styles.uploadType}>请上传xlsx文件，大小在10M以内</div>
      </FileUploadShowList>
      <div style={{ textAlign: 'right' }}>
        <Button
          type="link"
          size="small"
          href="https://m.hellobike.com/resource/helloyun/26691/%E6%A8%A1%E5%9E%8B%E9%AA%8C%E8%AF%81-%E6%84%8F%E5%9B%BE%E5%AF%BC%E5%85%A5%E6%A8%A1%E7%89%88.xlsx"
        >
          下载模版
        </Button>
      </div>
    </Modal>
  );
};

export default UploadModal;
