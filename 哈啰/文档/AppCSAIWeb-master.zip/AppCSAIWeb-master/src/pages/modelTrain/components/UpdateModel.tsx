import React, { useState, memo, useEffect } from 'react';
import { Form, Modal, Input, message, Cascader, Upload, Button } from 'antd';
import {
  saveModelTrain,
  updateModelTrain,
  SaveModelParams,
  UpdateModelParams,
  ModelTrainObj,
} from '@/api/modelTrain';
import { useModel } from '@umijs/max';
import { UploadOutlined } from '@ant-design/icons';
import { uploadMusic } from '@/api/language';
import styles from '../index.less';

const { TextArea } = Input;
const layout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 19 },
};

interface Prop {
  open: boolean;
  data: ModelTrainObj;
  onOk: () => void;
  onCancel: () => void;
}

const UpdateModel: React.FC<Prop> = memo(({ open, data, onCancel, onOk }) => {
  const { bizTree } = useModel('common');
  const [form] = Form.useForm();
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [fileList, setFileList] = useState([]); // 训练集文件list
  const [uploadLoading, setUploadLoading] = useState(false);

  // 取消
  const handleCancel = () => {
    form.resetFields();
    setConfirmLoading(false);
    onCancel?.();
  };

  // fetch添加/编辑模型
  const updateModel = async (params: SaveModelParams & UpdateModelParams) => {
    const isUpdate = !!data?.modelId;
    setConfirmLoading(true);

    const action = isUpdate ? updateModelTrain : saveModelTrain;
    if (isUpdate) {
      (params as UpdateModelParams).modelId = data.modelId;
    }
    const res = await action(params);

    if (res?.success) {
      message.success(isUpdate ? '编辑成功' : '新建成功');
      onOk?.();
      handleCancel();
    }
    setConfirmLoading(false);
  };

  // 提交
  const handleOk = async () => {
    const params = await form.validateFields();

    if (!data?.modelId) {
      // 训练入参
      if (fileList?.[0]?.url) {
        params.modelUrl = fileList[0].url;
      } else {
        return message.error('请先上传训练集文件');
      }

      // 行业入参
      if (params.biz?.length === 3) {
        const [levelOneBizId, levelTwoBizId, bizSceneId] = params.biz;
        params.levelOneBizId = levelOneBizId;
        params.levelTwoBizId = levelTwoBizId;
        params.bizSceneId = bizSceneId;
        bizTree?.forEach((oneItem) => {
          if (oneItem?.id === levelOneBizId) {
            params.levelOneBizName = oneItem?.name;
            oneItem?.children?.forEach((twoItem) => {
              if (twoItem?.id === levelTwoBizId) {
                params.levelTwoBizName = twoItem?.name;
                twoItem?.children?.forEach((threeItem) => {
                  if (threeItem?.id === bizSceneId) {
                    params.bizSceneName = threeItem?.name;
                  }
                });
              }
            });
          }
        });
      } else {
        return message.error('请选择到三级场景');
      }
    }
    // 删除biz
    delete params.biz;

    params.modelName = params.modelName?.trim();
    updateModel(params);
  };

  // 验证所属行业
  const handleValidate = (_, value) => {
    if (!value) {
      return Promise.reject(new Error('请选择行业'));
    }
    if (value?.length < 3) {
      return Promise.reject(new Error('请选择到三级场景'));
    }
    return Promise.resolve();
  };

  // 上传训练集文件
  const customRequest = async ({ file }: any) => {
    setUploadLoading(true);
    const formData = new FormData();
    formData.append('file', file);
    const dest = message.loading('正在上传文件');

    try {
      const res = (await uploadMusic(formData)) as any;
      if (res?.url) {
        setFileList([
          {
            status: 'done',
            name: file?.name,
            url: res?.url,
          },
        ]);
      } else {
        setFileList([]);
      }
    } catch (error) {
      setFileList([
        {
          uid: '-5',
          name: file.name,
          status: 'error',
        },
      ]);
    }

    setUploadLoading(false);
    dest?.();
  };

  useEffect(() => {
    if (!!data && open) {
      const currentModel = JSON.parse(JSON.stringify(data));
      const { levelOneBizId, levelTwoBizId, bizSceneId } = currentModel || {};
      currentModel.biz = [levelOneBizId, levelTwoBizId, bizSceneId];
      form.setFieldsValue(currentModel);
    }
  }, [data, open]);

  useEffect(() => {
    if (!open) {
      setFileList([]);
    }
  }, [open]);

  return (
    <Modal
      open={open}
      title={!!data?.modelId ? '编辑' : '新建'}
      forceRender
      width="600px"
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={confirmLoading}
      getContainer={false}
    >
      <Form form={form} {...layout}>
        <Form.Item
          label="模型名称"
          name="modelName"
          rules={[{ required: true }]}
        >
          <Input maxLength={50} placeholder="请输入模型名称，限制50字" />
        </Form.Item>
        <Form.Item
          label="所属行业"
          name="biz"
          rules={[{ required: true, validator: handleValidate }]}
        >
          <Cascader
            showSearch
            options={bizTree}
            disabled={!!data?.modelId}
            placeholder="请选择行业"
            fieldNames={{ label: 'name', value: 'id' }}
          />
        </Form.Item>
        {data?.modelId ? (
          <Form.Item label="模型ID">
            <span>{data.modelAlgorithmId}</span>
          </Form.Item>
        ) : (
          <Form.Item
            label={<div className={styles.required}>训练集</div>}
            extra="支持扩展名：.xlsx"
          >
            <>
              <Upload
                maxCount={1}
                fileList={fileList}
                accept=".xlsx"
                customRequest={(item) => customRequest(item)}
                disabled={uploadLoading}
                onRemove={() => setFileList([])}
              >
                <Button
                  disabled={uploadLoading}
                  icon={<UploadOutlined style={{ color: '#c0c0c0' }} />}
                >
                  上传文件
                </Button>
              </Upload>
              <Button
                type="link"
                style={{ position: 'absolute', left: '120px', top: 0 }}
                href="https://m.hellobike.com/resource/helloyun/26691/%E6%A8%A1%E5%9E%8B%E8%AE%AD%E7%BB%83%E5%AF%BC%E5%85%A5%E6%A8%A1%E7%89%88.xlsx"
              >
                下载模版
              </Button>
            </>
          </Form.Item>
        )}

        <Form.Item label="备注" name="modelRemark">
          <TextArea
            maxLength={120}
            rows={3}
            placeholder="请输入备注，限制120字"
          />
        </Form.Item>
      </Form>
    </Modal>
  );
});

export default UpdateModel;
