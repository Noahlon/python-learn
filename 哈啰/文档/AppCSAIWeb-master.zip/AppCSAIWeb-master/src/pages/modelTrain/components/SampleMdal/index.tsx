import { Button, Drawer, Empty, Input, Modal, Spin, message } from 'antd';
import React, { memo, useEffect, useRef, useState } from 'react';
import {
  DeleteOutlined,
  EditOutlined,
  ExclamationCircleOutlined,
  InboxOutlined,
  VerticalAlignBottomOutlined,
} from '@ant-design/icons';
import SimilarityList from '../SimilarityList';
import EditIntention from '../EditIntention';
import FileUploadShowList from '@/components/FileUploadShowList';
import { httpReplace } from '@/utils';
import { debounce } from 'lodash';
import {
  ModelTrainObj,
  modelDimDelete,
  modelDimQuery,
  modelDimQueryData,
  modelDimQueryReq,
  modelKnowledgeDownload,
  modelKnowledgeUpload,
} from '@/api/modelTrain';
import styles from '../../index.less';

interface Props {
  open: boolean;
  onOk?: () => void;
  onCancel: () => void;
  modelInfo?: ModelTrainObj;
}

const SampleModal: React.FC<Props> = memo(
  ({ open, onCancel, modelInfo, onOk }) => {
    const [type, setType] = useState(undefined);
    const [curInfo, setCurInfo] = useState<modelDimQueryData>(undefined);
    const [showImportModal, setShowImportModal] = useState(false);
    const [confirmLoading, setConfirmLoading] = useState(false);
    const ref = useRef();
    const [fileList, setFileList] = useState([]);
    const [fileUploadFailUrl, setFileUploadFailUrl] = useState('');

    const [intentionList, setIntentionList] = useState<modelDimQueryData[]>([]);
    const [loading, setLoading] = useState(false);
    const [selectIntention, setSelectIntention] = useState<modelDimQueryData>();
    const [searchContent, setSearchContent] = useState('');

    const getEditStatus = () => {
      return modelInfo?.modelStatus === 'TO_BE_TRAINED';
    };

    const getIntentionContent = async (param: modelDimQueryReq) => {
      const res = await modelDimQuery(param);
      if (res.success && res.data?.length) {
        setIntentionList(res.data);
        setSelectIntention(res.data[0]);
      } else {
        setIntentionList([]);
        setSelectIntention(undefined);
      }
      setLoading(false);
    };

    // 导入取消
    const handleImportCancel = () => {
      setShowImportModal(false);
      if (ref.current) ref.current?.clearData();
      setFileUploadFailUrl('');
      setFileList([]);
    };

    // 获取意图集合列表
    const handlerGetLists = async (content: string = '') => {
      // if (!selectIntention?.[1]) return;
      setLoading(true);
      const param: any = {
        modelId: modelInfo?.modelId,
        content, // 查询内容
      };
      getIntentionContent(param);
    };

    // 导入提交
    const handleImportOk = async () => {
      const list = fileList?.filter((item) => item.status === 'done');
      if (!list?.length) return message.error('请先上传文件');
      setConfirmLoading(true);
      const dest = message.loading('正在导入');
      const res = await modelKnowledgeUpload({
        modelId: modelInfo?.modelId,
        ossUrl: list[0].url,
      });
      if (res.success && res.data) {
        if (res?.data?.success) {
          handleImportCancel();
        } else if (res?.data?.ossUrl) {
          setFileUploadFailUrl(httpReplace(res?.data?.ossUrl));
        }
        setSearchContent('');
        handlerGetLists();
        onOk?.();
      }
      dest?.();
      setConfirmLoading(false);
    };

    // 编辑提交
    const handleEditOk = () => {
      setType(0);
      setCurInfo(undefined);
      handlerGetLists(searchContent);
      onOk?.();
    };

    // 导出
    const handleExport = async () => {
      Modal.confirm({
        title: '批量导出',
        icon: <ExclamationCircleOutlined />,
        content: '导出列表意图及其相似问',
        onOk() {
          const dest = message.loading('正在导出');
          modelKnowledgeDownload({ modelId: modelInfo?.modelId }).then(
            (res) => {
              if (res.success && res.data) {
                let elink = document.createElement('a');
                elink.style.display = 'none';
                let newUrl = httpReplace(res?.data as unknown as string);
                elink.href = newUrl;
                elink.download = '批量导出';
                document.body.appendChild(elink);
                elink.click();
                setTimeout(() => {
                  document.body.removeChild(elink);
                }, 300);
              }
              dest?.();
            },
          );
        },
      });
    };

    // 导入
    const handleImport = () => {
      setShowImportModal(true);
    };

    // 删除
    const handleDeleteIntention = (info: modelDimQueryData) => {
      Modal.confirm({
        title: '删除意图',
        icon: <ExclamationCircleOutlined />,
        content: '同时删除意图下的全部句子',
        onOk() {
          return modelDimDelete({ faqId: info?.faqId }).then((res) => {
            if (res?.success) {
              message.success('操作成功');
              handlerGetLists(searchContent);
              onOk?.();
            }
          });
        },
      });
    };

    const handleSearchChange = debounce((val: string) => {
      setSearchContent(val);
      const param = {
        modelId: modelInfo?.modelId,
        content: val || '', // 查询内容
      };
      getIntentionContent(param);
    }, 1000);

    useEffect(() => {
      if (open) {
        handlerGetLists();
      } else {
        setSearchContent('');
      }
    }, [open]);

    return (
      <Drawer
        open={open}
        width={900}
        title="样本训练"
        forceRender
        onClose={onCancel}
        getContainer={false}
      >
        {/* 样本训练 */}
        <div className={styles.trainModalBox}>
          <div className={styles.topModalBox}>
            <div className={styles.leftInput}>
              {open && (
                <Input
                  placeholder="请输入"
                  style={{ width: 250 }}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  allowClear
                />
              )}
            </div>
            <div className={styles.rightBtn}>
              {getEditStatus() && (
                <Button
                  type="primary"
                  onClick={() => {
                    setType(1);
                  }}
                  className={styles.btn}
                >
                  新建意图
                </Button>
              )}
              {getEditStatus() && (
                <Button
                  type="primary"
                  onClick={() => handleImport()}
                  className={styles.btn}
                >
                  批量导入
                </Button>
              )}

              <Button
                icon={<VerticalAlignBottomOutlined />}
                onClick={() => {
                  handleExport();
                }}
                className={styles.btn}
              >
                批量导出
              </Button>
            </div>
          </div>
          <div className={styles.content}>
            <div className={styles.intentionLeft}>
              <div className={styles.intentionLeftListWrap}>
                <div className={`${styles.intentionLeftListCount}`}>
                  意图名称（{intentionList?.length || 0}个）
                </div>
                <Spin spinning={loading} style={{ minHeight: '30px' }}>
                  {!!intentionList?.length ? (
                    intentionList.map((item, index) => (
                      <div key={index} className={styles.intentionItem}>
                        <div
                          onClick={() => setSelectIntention(item)}
                          className={[
                            styles.intentionItemName,
                            item.faqId === selectIntention?.faqId
                              ? styles.intentionItemActive
                              : '',
                          ].join(' ')}
                        >
                          {item.name}
                        </div>
                        <div className={styles.actionIcons}>
                          {getEditStatus() && (
                            <EditOutlined
                              style={{ marginRight: 8 }}
                              className={
                                item.faqId === selectIntention?.faqId
                                  ? ''
                                  : styles.initIcons
                              }
                              onClick={() => {
                                setType(2);
                                setCurInfo(item);
                              }}
                            />
                          )}
                          {getEditStatus() && (
                            <DeleteOutlined
                              className={
                                item.faqId === selectIntention?.faqId
                                  ? ''
                                  : styles.initIcons
                              }
                              onClick={() => handleDeleteIntention(item)}
                            />
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                  )}
                </Spin>
              </div>
            </div>
            <div className={styles.intentionRight}>
              {!!selectIntention ? (
                <SimilarityList
                  intention={selectIntention}
                  modelStatus={getEditStatus()}
                  modelId={modelInfo?.modelId}
                  searchText={searchContent}
                  onOk={onOk}
                />
              ) : (
                <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
              )}
            </div>
          </div>
          <EditIntention
            type={type}
            info={curInfo}
            modelId={modelInfo?.modelId}
            onCancel={() => {
              setType(0);
              setCurInfo(undefined);
            }}
            onOk={handleEditOk}
          />
          <Modal
            open={showImportModal}
            title="批量导入"
            forceRender={true}
            width={'540px'}
            onOk={handleImportOk}
            onCancel={handleImportCancel}
            confirmLoading={confirmLoading}
            getContainer={false}
            destroyOnClose={true}
          >
            <FileUploadShowList
              ref={ref}
              showUploadList={true}
              uploadType=".xlsx"
              onChange={(list) => setFileList(list)}
            >
              <div className={styles.uploadIcon}>
                <InboxOutlined />
              </div>
              <div className={styles.notice}>点击或将文件拖拽到这里上传</div>
              <div className={styles.uploadType}>
                支持扩展名：.xlsx&nbsp;&nbsp;大小在10M以内
              </div>
            </FileUploadShowList>
            <div style={{ textAlign: 'right' }}>
              <Button
                type="link"
                size="small"
                href="https://m.hellobike.com/resource/helloyun/26691/%E6%A8%A1%E5%9E%8B%E8%AE%AD%E7%BB%83%E5%AF%BC%E5%85%A5%E6%A8%A1%E7%89%88.xlsx"
              >
                导入模版
              </Button>
            </div>
            {fileUploadFailUrl && (
              <div className={styles.errorUploadWrap}>
                <VerticalAlignBottomOutlined
                  className={styles.errorUploadIcon}
                />
                <a
                  rel="noreferrer"
                  target="_blank"
                  href={fileUploadFailUrl}
                  className={styles.errorUploadText}
                >
                  下载导入失败数据
                </a>
              </div>
            )}
          </Modal>
        </div>
      </Drawer>
    );
  },
);

export default SampleModal;
