import {
  VerifyListObj,
  VerifyListParams,
  delAllVerify,
  delOneVerify,
  downloadModelVerify,
  getVerifyDetail,
  getVerifyList,
  submitModelVerify,
} from '@/api/modelTrain';
import { ColumnsType } from 'antd/es/table';
import {
  Button,
  Col,
  Divider,
  Drawer,
  Input,
  Modal,
  Popconfirm,
  Row,
  Space,
  Typography,
  message,
} from 'antd';
import { DownloadOutlined, UploadOutlined } from '@ant-design/icons';
import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import ResizeTable from '@/components/ResizeTable';
import UploadModal from './UploadModal';
import { verifyColumns, DEFAULT_QUERY_PARAMS_2 } from '../../config';
import { debounce } from 'lodash';
import { handleDownload } from '@/utils';
import styles from './index.less';

interface Prop {
  modelId: string;
  onOk: () => void;
  onCancel: () => void;
}

const { Title, Text } = Typography;

const VerifyModal: React.FC<Prop> = memo(({ modelId, onOk, onCancel }) => {
  const [tableData, setTableData] = useState<VerifyListObj[]>([]);
  const [tableTotal, setTableTotal] = useState<number>();
  const [tableLoading, setTableLoading] = useState(false);
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS_2 });
  // 搜索params
  const queryParams = useRef<VerifyListParams>({
    ...DEFAULT_QUERY_PARAMS_2,
  } as VerifyListParams);

  // 导入open
  const [uploadOpen, setUploadOpen] = useState(false);

  // 导出loading
  const [downLoading, setDownLoading] = useState(false);

  // 提交loading
  const [submitLoading, setSubmitLoading] = useState(false);

  // fetch验证数据list
  const fetchVerifyList = async () => {
    setTableLoading(true);
    const params = {
      ...queryParams.current,
      modelId,
    };
    const res = await getVerifyList(params);
    if (res?.data) {
      const { list, totalRecord } = res.data || {};
      setTableData(list);
      setTableTotal(totalRecord);
    } else {
      setTableData([]);
      setTableTotal(undefined);
    }

    setTableLoading(false);
  };

  // 初始化数据
  const initData = () => {
    fetchVerifyList();
  };

  // 提交验证
  const handleSubmitVerify = async () => {
    setSubmitLoading(true);
    const verifyRes = await getVerifyDetail({ modelId }); // 点击提交验证，验证和获取数据
    setSubmitLoading(false);
    if (!verifyRes?.success) {
      return;
    }

    if (!tableData?.length) {
      Modal.warn({
        title: '请先上传验证样本',
      });
      return;
    }

    const {
      submitIntentionCount,
      modelIntentionCount,
      intentionOverRate,
      knowledgeCount,
    } = verifyRes?.data || {};
    Modal.confirm({
      title: '提交数据进行模型回归验证？',
      content: (
        <div>
          <div>意图数：{submitIntentionCount}</div>
          <div>
            意图覆盖率：{intentionOverRate}（模型中意图数{modelIntentionCount}）
          </div>
          <div>验证句子数：{knowledgeCount}</div>
          <div>提交后样本数据不支持编辑</div>
        </div>
      ),
      onOk: async () => {
        const res = await submitModelVerify({ modelId });
        if (res?.success) {
          onOk();
          onCancel();
          message.success('提交训练成功');
        }
      },
    });
  };

  // 删除单个
  const handleDelOne = async (id: string) => {
    const res = await delOneVerify({ id });
    if (res?.success) {
      initData();
    }
  };

  // 清除所有
  const handleClearAll = async () => {
    const res = await delAllVerify({ modelId });
    if (res?.success) {
      initData();
      message.success('清除成功');
    }
  };

  // 导出
  const handleDownloadData = async () => {
    setDownLoading(true);
    const res = await downloadModelVerify({ modelId });
    if (res?.data) {
      handleDownload(res.data);
      message.success('导出成功');
    }
    setDownLoading(false);
  };

  // columns
  const tableColumns: ColumnsType<VerifyListObj> = [
    ...verifyColumns,
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 100,
      render: (_, record) => (
        <a onClick={() => handleDelOne(record.id)}>删除</a>
      ),
    },
  ];

  // 页面pagination change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchVerifyList();
  };

  // 搜索防抖一秒
  const debounceFetchVerifyList = debounce((value: string) => {
    queryParams.current.name = value;
    handlePageChange(1);
  }, 1000);

  // 关闭弹框reset数据
  const resetModal = () => {
    queryParams.current = { ...DEFAULT_QUERY_PARAMS_2 } as VerifyListParams;
    setPagination({ ...DEFAULT_QUERY_PARAMS_2 });
  };

  useEffect(() => {
    if (!!modelId) {
      initData();
    } else {
      resetModal();
    }
  }, [modelId]);

  return (
    <Drawer open={!!modelId} width={900} onClose={onCancel} title="回归验证">
      <div className={styles.verifyModal}>
        <div className={styles.top}>
          <div>
            <Title level={4}>提交模型验证</Title>
            <Text type="secondary">
              用下列测试数据验证模型的准确率，默认使用该行业最近一次的训练数据作为验证样本
            </Text>
          </div>
          <Button
            type="primary"
            loading={submitLoading}
            onClick={handleSubmitVerify}
          >
            提交验证
          </Button>
        </div>
        <Divider />
        <Title level={4}>验证样本</Title>
        <Row justify="space-between" className={styles.form}>
          <Col>
            {!!modelId && (
              <Input
                placeholder="请输入"
                className={styles.input}
                onChange={(e) => debounceFetchVerifyList(e.target.value)}
                allowClear
              />
            )}
          </Col>
          <Col>
            <Space size="middle">
              <Popconfirm
                title="清空列表全部数据"
                placement="topRight"
                onConfirm={handleClearAll}
              >
                <a>清空</a>
              </Popconfirm>
              <Button
                icon={<UploadOutlined />}
                type="primary"
                onClick={() => setUploadOpen(true)}
              >
                批量导入
              </Button>
              <Button
                icon={<DownloadOutlined />}
                onClick={handleDownloadData}
                loading={downLoading}
              >
                批量导出
              </Button>
            </Space>
          </Col>
        </Row>
        {/* 表格 */}
        <ResizeTable
          columns={tableColumns}
          dataSource={tableData}
          scroll={{ x: 800 }}
          rowKey="id"
          containerId="verifyModel"
          loading={tableLoading}
          pagination={{
            onChange: handlePageChange,
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            total: tableTotal,
          }}
        />
        {/* 批量上传 */}
        <UploadModal
          modelId={modelId}
          visible={uploadOpen}
          onOk={useCallback(() => initData(), [modelId])}
          onCancel={useCallback(() => {
            setUploadOpen(false);
          }, [])}
        />
      </div>
    </Drawer>
  );
});

export default VerifyModal;
