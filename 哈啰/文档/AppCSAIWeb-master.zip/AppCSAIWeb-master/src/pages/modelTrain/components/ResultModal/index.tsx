import {
  ResultDetailObj,
  ResultListObj,
  ResultListParams,
  downloadTrainResult,
  getTrainResultDetail,
  getTrainResultList,
} from '@/api/modelTrain';
import {
  Button,
  Col,
  Descriptions,
  Divider,
  Drawer,
  Input,
  Row,
  Select,
  Space,
  Typography,
  message,
} from 'antd';
import React, { memo, useEffect, useRef, useState } from 'react';
import { DownloadOutlined } from '@ant-design/icons';
import ResizeTable from '@/components/ResizeTable';
import {
  resultColumns,
  identifyResultMap,
  DEFAULT_QUERY_PARAMS_2,
} from '../../config';
import { debounce } from 'lodash';
import { showEmptyLine } from '@/utils/format';
import { handleDownload } from '@/utils';
import styles from './index.less';

interface Prop {
  modelId: string;
  onCancel: () => void;
}

const { Title } = Typography;

const ResultModal: React.FC<Prop> = memo(({ modelId, onCancel }) => {
  const [tableData, setTableData] = useState<ResultListObj[]>([]);
  const [tableTotal, setTableTotal] = useState<number>();
  const [tableLoading, setTableLoading] = useState(false);
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS_2 });
  // 搜索params
  const queryParams = useRef<ResultListParams>({
    ...DEFAULT_QUERY_PARAMS_2,
  } as ResultListParams);

  // 详情数据
  const [resultDetail, setResultDetail] = useState<ResultDetailObj>();

  // 导出loading
  const [downLoading, setDownLoading] = useState(false);

  // fetch验证数据list
  const fetchResultList = async () => {
    setTableLoading(true);
    const params = {
      ...queryParams.current,
      modelId,
    };
    const res = await getTrainResultList(params);
    if (res?.data) {
      const { list, totalRecord } = res.data || {};
      setTableData(list);
      setTableTotal(totalRecord);
    }
    setTableLoading(false);
  };

  // fetch验证数据detail
  const fetchResultDetail = async () => {
    const res = await getTrainResultDetail({ modelId });
    if (res?.data) {
      setResultDetail(res.data);
    }
  };

  // 导出
  const handleDownloadData = async () => {
    setDownLoading(true);
    const res = await downloadTrainResult({ modelId });
    if (res?.data) {
      handleDownload(res.data);
      message.success('导出成功');
    }
    setDownLoading(false);
  };

  // 页面pagination change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchResultList();
  };

  // 搜索防抖一秒
  const debounceFetchResultList = debounce((value: string) => {
    queryParams.current.name = value;
    handlePageChange(1);
  }, 1000);

  // 判断结果change
  const handleChangeIdentify = (e: number) => {
    queryParams.current.verifyResult = e;
    handlePageChange(1);
  };

  // 关闭弹框reset数据
  const resetModal = () => {
    queryParams.current = { ...DEFAULT_QUERY_PARAMS_2 } as ResultListParams;
    setPagination({ ...DEFAULT_QUERY_PARAMS_2 });
  };

  useEffect(() => {
    if (!!modelId) {
      fetchResultList();
      fetchResultDetail();
    } else {
      resetModal();
    }
  }, [modelId]);

  return (
    <Drawer open={!!modelId} width={900} onClose={onCancel} title="验证结果">
      <div className={styles.resultModal}>
        <div>
          <Title level={4}>模型验证结果</Title>
          <Descriptions title="">
            <Descriptions.Item label="意图覆盖率">
              {showEmptyLine(resultDetail?.intentionOverRate)}
            </Descriptions.Item>
            <Descriptions.Item label="识别准确率">
              {showEmptyLine(resultDetail?.identifyRate)}
            </Descriptions.Item>
            <Descriptions.Item label="验证样本数">
              {showEmptyLine(resultDetail?.knowledgeCount)}
            </Descriptions.Item>
          </Descriptions>
        </div>
        <Divider className={styles.divider} />
        <Title level={4}>验证样本</Title>
        <Row justify="space-between" className={styles.form}>
          <Col>
            {!!modelId && (
              <Space size="middle">
                <Input
                  placeholder="请输入"
                  className={styles.formItem}
                  onChange={(e) => debounceFetchResultList(e.target.value)}
                  allowClear
                />
                <Select
                  options={identifyResultMap}
                  placeholder="请选择判断结果"
                  onChange={(e) => handleChangeIdentify(e)}
                  allowClear
                  className={styles.formItem}
                />
              </Space>
            )}
          </Col>
          <Col>
            <Button
              icon={<DownloadOutlined />}
              onClick={handleDownloadData}
              loading={downLoading}
            >
              批量导出
            </Button>
          </Col>
        </Row>
        {/* 表格 */}
        <ResizeTable
          columns={resultColumns}
          dataSource={tableData}
          scroll={{ x: 800 }}
          rowKey="id"
          containerId="resultModel"
          loading={tableLoading}
          pagination={{
            onChange: handlePageChange,
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            total: tableTotal,
          }}
        />
      </div>
    </Drawer>
  );
});

export default ResultModal;
