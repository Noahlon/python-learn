import { DownOutlined, UpOutlined } from '@ant-design/icons';
import { Collapse, Steps } from 'antd';
import React, { useState } from 'react';
import styles from '../index.less';

const TopFlow: React.FC = () => {
  const [activeKey, setActiveKey] = useState('1');

  const handleChange = () => {
    if (activeKey === '1') {
      setActiveKey(undefined);
    } else {
      setActiveKey('1');
    }
  };

  const CustomIcon = (num: number) => {
    return (
      <div className={styles.customStepIcon}>
        <span className={styles.customStepText}>{num}</span>
      </div>
    );
  };

  return (
    <Collapse
      activeKey={activeKey}
      expandIconPosition="end"
      expandIcon={() => ''}
      collapsible="icon"
      ghost
    >
      <Collapse.Panel
        header={<div className={styles.topTitle}>模型训练流程</div>}
        key="1"
        extra={
          <div className={styles.topExtra} onClick={handleChange}>
            {!!activeKey ? (
              <>
                收起 <UpOutlined className={styles.icon} />
              </>
            ) : (
              <>
                展开 <DownOutlined className={styles.icon} />
              </>
            )}
          </div>
        }
      >
        <Steps
          current={4}
          items={[
            {
              title: '创建模型',
              description:
                '创建行业的意图标注集，数据确认无误后，可提交模型训练',
              icon: CustomIcon(1),
            },
            {
              title: '模型训练',
              description: '模型提交训练完成后，可进入模型验证阶段',
              icon: CustomIcon(2),
            },
            {
              title: '模型回归验证',
              description:
                '用测试数据验证模型的准确率，用户自行判断该模型准确率是否达上线标准',
              icon: CustomIcon(3),
            },
            {
              title: '模型上线',
              description:
                '验证通过的模型，用户手动操作上线，上线后，该行业下的意图识别将会调用新的模型',
              icon: CustomIcon(4),
            },
          ]}
          className={styles.steps}
        />
      </Collapse.Panel>
    </Collapse>
  );
};

export default TopFlow;
