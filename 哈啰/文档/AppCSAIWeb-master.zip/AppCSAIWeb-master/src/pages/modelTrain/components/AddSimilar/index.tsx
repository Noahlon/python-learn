import React, { useState, memo } from 'react';
import { Modal, Button, Input, message, Spin, Empty, Table } from 'antd';
import styles from './index.less';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { CloseOutlined } from '@ant-design/icons';
import {
  modelTrainExtendDistinct,
  modelTrainKnowledgeInsert,
} from '@/api/modelTrain';
import { v1 as uuidv1 } from 'uuid';

interface IProps {
  open?: boolean;
  onOk?: () => void;
  onCancel?: () => void;
  faqId: string;
  modelId: string;
}

const AddSimilarQOrPhrase: React.FC<IProps> = ({
  open,
  onOk,
  onCancel,
  faqId,
  modelId,
}) => {
  const [text, setText] = useState('');
  const [data, setData] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const errorColumns: any = [
    {
      title: '相似问',
      dataIndex: 'extendFaqName',
      key: 'extendFaqName',
      width: 500,
      align: 'center',
    },
    {
      title: '失败原因',
      dataIndex: 'errorDesc',
      key: 'errorDesc',
      width: 300,
      align: 'center',
    },
  ];

  const showError = (msgs) => {
    Modal.error({
      title: <span>添加失败详情</span>,
      icon: null,
      width: 800,
      content: (
        <>
          <div className={styles.failedTable}>
            <Table
              columns={errorColumns}
              dataSource={msgs}
              rowKey={(record) => record.id}
              pagination={false}
            />
          </div>
        </>
      ),
      closable: true,
      okText: false,
      cancelText: false,
    });
  };

  const createData = async () => {
    if (loading) return;
    if (!text) {
      return message.warning('请填写内容');
    }
    const regex = /[^;；]+/g;

    const matches = text.match(regex);
    const common = matches.filter((item) => data.includes(item));
    const unique = matches.filter((item) => !data.includes(item));
    const msgs = [];
    const param = {
      faqId,
      extendFaqName: common.length ? unique.join(';') : text,
      modelId,
    };
    if (common.length) {
      const _msgs = common.map((item) => {
        return {
          extendFaqName: item,
          errorDesc: '添加列表中已存在',
          id: uuidv1(),
        };
      });
      _msgs.forEach((item) => msgs.push(item));
    }
    if (common.length && unique.length === 0) {
      showError(msgs);
      setText('');
      return;
    }
    setLoading(true);
    const res = await modelTrainExtendDistinct(param);
    if (res?.success) {
      const { modelSaveKnowledgeDTOS, knowledgeList } = res.data;
      if (knowledgeList?.length) {
        const _data = JSON.parse(JSON.stringify(data));
        res.data?.knowledgeList?.forEach((item) => {
          if (_data.findIndex((i) => i === item) === -1) _data.push(item);
        });
        setData(_data);
      }
      if (modelSaveKnowledgeDTOS?.length) {
        const _msgs = modelSaveKnowledgeDTOS.map((item) => {
          return {
            extendFaqName: item.similarFaqName,
            errorDesc: item.errorDesc,
            id: uuidv1(),
          };
        });
        _msgs.forEach((item) => msgs.push(item));
      }
      if (msgs.length) {
        showError(msgs);
      }
    }

    setLoading(false);
    setText('');
  };

  const handleDelete = async (text) => {
    const _data = JSON.parse(JSON.stringify(data));
    const zIndex = _data.findIndex((item) => item === text);
    if (zIndex > -1) {
      _data.splice(zIndex, 1);
    }
    message.success('删除成功');
    setData(_data);
  };

  const handleCancel = () => {
    setData([]);
    setText('');
    setLoading(false);
    onCancel?.();
  };

  const handleAddOk = async () => {
    if (!data?.length) return message.error('请添加数据');
    let param = {
      faqId,
      extendFaqName: data.join(';'),
      modelId,
    };
    const res = await modelTrainKnowledgeInsert(param);
    if (res.success) {
      message.success('添加成功');
      setData([]);
      setText('');
      setLoading(false);
      onOk?.();
    }
  };

  const handleInputChange = (e: {
    target: { value: React.SetStateAction<string> };
  }) => {
    setText(e.target.value);
  };

  return (
    <>
      <Modal
        title="新增相似问"
        className="custom-draggable-modal"
        open={open}
        onCancel={handleCancel}
        onOk={handleAddOk}
        destroyOnClose={true}
        width={600}
      >
        <div className={styles.input}>
          <div style={{ minWidth: 'fit-content' }}>相似问</div>
          <Input
            style={{ margin: '0 5px' }}
            placeholder="请输入"
            maxLength={8000}
            value={text}
            onChange={handleInputChange}
            onPressEnter={createData}
            showCount
          />
          <Button
            onClick={createData}
            loading={loading}
            style={{ marginRight: '5px' }}
          >
            添加
          </Button>
          <CopyToClipboard
            text={!data?.length ? undefined : data?.join(';')}
            onCopy={(val) => {
              if (!val) {
                message.error('没有可复制的数据');
              } else {
                message.success('复制成功');
              }
            }}
          >
            <Button type="primary">复制</Button>
          </CopyToClipboard>
        </div>
        <div className={styles.notice}>相似问之间可用分号相隔</div>
        <Spin spinning={loading}>
          <div className={styles.content}>
            {!!data?.length ? (
              data?.map((item) => (
                <div key={item} className={styles.item}>
                  <CloseOutlined
                    className={styles.icon}
                    onClick={() => handleDelete(item)}
                  />
                  <div>{item}</div>
                </div>
              ))
            ) : (
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
            )}
          </div>
        </Spin>
      </Modal>
    </>
  );
};

export default memo(AddSimilarQOrPhrase);
