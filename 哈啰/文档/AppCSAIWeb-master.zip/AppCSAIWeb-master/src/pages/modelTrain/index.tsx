import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Button, Modal, Space, message } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import { useAccess, useModel } from '@umijs/max';
import { DEFAULT_QUERY_PARAMS, modelColumns } from './config';
import {
  commitModelTrain,
  discardModel,
  getModelTrainList,
  ModelListParams,
  ModelTrainObj,
} from '@/api/modelTrain';
import TopFlow from './components/TopFlow';
import SampleModal from './components/SampleMdal';
import SearchModel from './components/SearchModel';
import UpdateModel from './components/UpdateModel';
import VerifyModal from './components/VerifyModal';
import ResultModal from './components/ResultModal';
import ResizeTable from '@/components/ResizeTable';
import styles from './index.less';

const ModelTrain: React.FC = () => {
  const access = useAccess();
  const { fetchBizTreeOpts } = useModel('common');
  // table data
  const [tableData, setTableData] = useState<ModelTrainObj[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  // pagination
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [tableTotal, setTableTotal] = useState<number>();
  // 搜索params
  const queryParams = useRef<ModelListParams>(DEFAULT_QUERY_PARAMS);
  // 模型新增/编辑
  const [updateModelOpen, setUpdateModelOpen] = useState(false);
  const [currentModel, setCurrentModel] = useState<ModelTrainObj>(undefined);

  // 样本训练open
  // const [sampleOpen, setSampleOpen] = useState(false);
  const [currentSampleModel, setCurrentSampleModel] =
    useState<ModelTrainObj>(undefined);

  // 当前回归验证modelId
  const [currentVerifyModelId, setCurrentVerifyModelId] =
    useState<string>(undefined);

  // 当前验证结果modelId
  const [currentResultModelId, setCurrentResultModelId] =
    useState<string>(undefined);

  // fetch模型列表
  const fetchModelList = async () => {
    setTableLoading(true);
    const params = { ...queryParams.current };
    const res = await getModelTrainList(params);
    if (res?.data) {
      setTableData(res.data?.list || []);
      setTableTotal(res.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // 提交训练
  const handleCommitTrain = (record: ModelTrainObj) => {
    if (!record.intentionCount || !record.knowledgeCount) {
      Modal.warning({
        title: '请上传训练样本',
        cancelText: false,
      });
      return;
    }
    Modal.confirm({
      title: '提交样本数据进行模型训练？',
      content: (
        <div>
          <div>意图数：{record.intentionCount}</div>
          <div>训练相似问数：{record.knowledgeCount}</div>
          <div>提交后样本数据不支持编辑</div>
        </div>
      ),
      onOk: async () => {
        const res = await commitModelTrain({ modelId: record.modelId });
        if (res?.success) {
          fetchModelList();
          message.success('提交训练成功');
        }
      },
    });
  };

  // 废弃模型
  const handleDiscard = (modelId: string) => {
    Modal.confirm({
      title: '废弃该模型？',
      content: '该操作不支持撤回',
      onOk: async () => {
        const res = await discardModel({ modelId });
        if (res?.success) {
          fetchModelList();
          message.success('废弃成功');
        }
      },
    });
  };

  // 模型列表columns
  const tableColumns: ColumnsType<ModelTrainObj> = [
    ...modelColumns,
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 260,
      render: (_, record) => (
        <Space size="middle">
          {/* 编辑 */}
          {access?.authCodeList?.includes('Call-Intention-Model-Edit') && (
            <a
              onClick={() => {
                setCurrentModel(record);
                setUpdateModelOpen(true);
              }}
            >
              编辑
            </a>
          )}
          {/* 训练样本 */}
          {access?.authCodeList?.includes(
            'Call-Intention-Model-Training-Samples',
          ) &&
            ['TO_BE_TRAINED', 'TO_BE_VERIFY', 'VERIFY_COMPLETED'].includes(
              record.modelStatus,
            ) && (
              <a
                onClick={() => {
                  setCurrentSampleModel(record);
                  // setSampleOpen(true);
                }}
              >
                训练样本
              </a>
            )}
          {/* 提交训练 */}
          {access?.authCodeList?.includes(
            'Call-Intention-Model-Submit-Training',
          ) &&
            ['TO_BE_TRAINED'].includes(record.modelStatus) && (
              <a onClick={() => handleCommitTrain(record)}>提交训练</a>
            )}
          {/* 回归验证 */}
          {access?.authCodeList?.includes(
            'Call-Intention-Model-Validate-Result',
          ) &&
            ['TO_BE_VERIFY'].includes(record.modelStatus) && (
              <a onClick={() => setCurrentVerifyModelId(record.modelId)}>
                回归验证
              </a>
            )}
          {/* 验证结果 */}
          {access?.authCodeList?.includes(
            'Call-Intention-Model-Validate-Result',
          ) &&
            ['VERIFYING', 'VERIFY_COMPLETED'].includes(record.modelStatus) && (
              <a onClick={() => setCurrentResultModelId(record.modelId)}>
                验证结果
              </a>
            )}
          {/* 废弃 */}
          {access?.authCodeList?.includes('Call-Intention-Model-Abandon') &&
            ['TO_BE_TRAINED', 'TO_BE_VERIFY', 'VERIFY_COMPLETED'].includes(
              record.modelStatus,
            ) && (
              <a
                style={{ color: '#ff4d4f' }}
                onClick={() => handleDiscard(record.modelId)}
              >
                废弃
              </a>
            )}
        </Space>
      ),
    },
  ];

  // 分页change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchModelList();
  };

  // 排序change
  const handleTableChange = (pagination, _, sorter) => {
    if (!!sorter?.order) {
      queryParams.current.sort = 1;
      queryParams.current.sortParam = sorter?.field;
      queryParams.current.sortAsc = sorter?.order === 'descend' ? -1 : 1;
    } else {
      queryParams.current.sort = undefined;
      queryParams.current.sortParam = undefined;
      queryParams.current.sortAsc = undefined;
    }
    handlePageChange(pagination.current, pagination.pageSize);
  };

  // 搜索
  const handleSearch = (res: ModelListParams) => {
    const params = { ...queryParams.current };
    delete params.bizId;
    delete params.level;
    queryParams.current = { ...params, ...res };
    handlePageChange(1);
  };

  // 重置
  const handleReset = () => {
    queryParams.current = DEFAULT_QUERY_PARAMS;
    setPagination(DEFAULT_QUERY_PARAMS);
    fetchModelList();
  };

  // 新增/编辑后更新列表
  const handleUpdateModel = useCallback(() => {
    // 如果是新增模版就重置列表参数
    if (!currentModel) {
      handlePageChange(1);
    } else {
      fetchModelList();
    }
  }, []);

  useEffect(() => {
    fetchModelList();
    fetchBizTreeOpts();
  }, []);

  return (
    <>
      <div className={styles.modelTrainWrap}>
        {/* 模型训练流程（静态数据） */}
        <TopFlow />
        <div className={styles.content}>
          {/* 搜索 */}
          <SearchModel onSearch={handleSearch} onReset={handleReset} />
          {/* 新增 */}
          {access?.authCodeList?.includes('Call-Intention-Model-Add') && (
            <Button
              className={styles.addModel}
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => {
                setCurrentModel(undefined);
                setUpdateModelOpen(true);
              }}
            >
              新建模型
            </Button>
          )}
          {/* 表格 */}
          <ResizeTable
            columns={tableColumns}
            dataSource={tableData}
            scroll={{ x: 2200 }}
            rowKey="modelId"
            containerId="modelTrain"
            loading={tableLoading}
            pagination={{
              onChange: handlePageChange,
              current: pagination.pageNum,
              pageSize: pagination.pageSize,
              pageSizeOptions: [25, 50, 100],
              total: tableTotal,
            }}
            onChange={handleTableChange}
          />
        </div>
      </div>
      {/* 新增/编辑模型modal */}
      <UpdateModel
        open={updateModelOpen}
        data={currentModel}
        onOk={handleUpdateModel}
        onCancel={useCallback(() => setUpdateModelOpen(false), [])}
      />
      {/* 样本训练modal */}
      <SampleModal
        open={!!currentSampleModel}
        modelInfo={currentSampleModel}
        onOk={useCallback(fetchModelList, [])}
        onCancel={useCallback(() => {
          fetchModelList();
          setCurrentSampleModel(undefined);
        }, [])}
      />
      {/* 回归验证modal */}
      <VerifyModal
        modelId={currentVerifyModelId}
        onOk={useCallback(fetchModelList, [])}
        onCancel={useCallback(() => setCurrentVerifyModelId(undefined), [])}
      />
      {/* 验证结果modal */}
      <ResultModal
        modelId={currentResultModelId}
        onCancel={useCallback(() => setCurrentResultModelId(undefined), [])}
      />
    </>
  );
};

export default ModelTrain;
