import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Table, Pagination, Tooltip, message } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { debounce } from 'lodash';
import moment from 'moment';
import { v1 as uuidv1 } from 'uuid';
import { formatType } from '@/config';
import {
  exportRecordList,
  getSmsRecordList,
  ISmsRecord,
  ISmsRecordListParams,
} from '@/api/messageList';
import MessageSearch from './components/MessageSearch';
import { DEFAULT_MESSAGE_PARAMS } from './config';
import { maskPhoneNumber } from '../messageUpWard/config';
import styles from './index.less';

const SmsRecordList: React.FC = () => {
  const queryParams = useRef(DEFAULT_MESSAGE_PARAMS);
  const [tableData, setTableData] = useState<ISmsRecord[]>([]);
  const [isLoading, setLoading] = useState(false);
  const [pageSize, setPageSize] = useState(100);
  const [tableHeight, setTableHeight] = useState<number | string>();
  const [total, setTotal] = useState(0);
  const [pageIndex, setPageIndex] = useState(1);
  const [isOverflow, setOverflow] = useState(false);
  // 导出
  const [exportLoading, setExportLoading] = useState(false);

  // fetch列表数据
  const fetchList = useCallback(
    async (params: ISmsRecordListParams) => {
      const paramsObj: ISmsRecordListParams = {
        pageNum: params.pageNum || pageIndex,
        pageSize: params.pageSize || pageSize,
        ...queryParams.current,
      };
      // 创建时间
      if (
        Array.isArray(paramsObj.createTime) &&
        paramsObj?.createTime?.length === 2
      ) {
        paramsObj.createTimeStart = moment(paramsObj.createTime[0]).format(
          formatType,
        );
        paramsObj.createTimeEnd = moment(paramsObj.createTime[1]).format(
          formatType,
        );
      }
      // 提交时间
      if (
        Array.isArray(paramsObj.commitTime) &&
        paramsObj?.commitTime?.length === 2
      ) {
        paramsObj.commitTimeStart = moment(paramsObj.commitTime[0]).format(
          formatType,
        );
        paramsObj.commitTimeEnd = moment(paramsObj.commitTime[1]).format(
          formatType,
        );
      }
      delete paramsObj.createTime;
      delete paramsObj.commitTime;
      // 城市
      if (paramsObj?.cityList?.length) {
        paramsObj.cityList = paramsObj.cityList.map((item) => item[1]);
      }
      setLoading(true);
      try {
        const smsRecordListRes = await getSmsRecordList(paramsObj);
        if (smsRecordListRes?.success) {
          setTableData(smsRecordListRes.data?.list as ISmsRecord[]);
          setTotal(Number(smsRecordListRes.data?.totalRecord) || 0);
        } else {
          setTableData([]);
        }
      } catch (error) {}
      setLoading(false);
    },
    [pageSize, pageIndex],
  );

  const formatApiParams = (paramsObj) => {
    // 创建时间
    if (
      Array.isArray(paramsObj.createTime) &&
      paramsObj?.createTime?.length === 2
    ) {
      paramsObj.createTimeStart = moment(paramsObj.createTime[0]).format(
        formatType,
      );
      paramsObj.createTimeEnd = moment(paramsObj.createTime[1]).format(
        formatType,
      );
    }
    // 提交时间
    if (
      Array.isArray(paramsObj.commitTime) &&
      paramsObj?.commitTime?.length === 2
    ) {
      paramsObj.commitTimeStart = moment(paramsObj.commitTime[0]).format(
        formatType,
      );
      paramsObj.commitTimeEnd = moment(paramsObj.commitTime[1]).format(
        formatType,
      );
    }
    delete paramsObj.createTime;
    delete paramsObj.commitTime;
    // 城市
    if (paramsObj?.cityList?.length) {
      paramsObj.cityList = paramsObj.cityList.map((item) => item[1]);
    }
    return paramsObj;
  };

  // 导出
  const handleExport = async () => {
    const _params = {
      pageNum: pageIndex,
      pageSize: pageSize,
      ...queryParams.current,
    };
    const params = formatApiParams(_params);
    setExportLoading(true);
    const res = await exportRecordList(params);
    if (res?.success) {
      message.success('导出成功，请前往【文件导出管理】页面进行下载');
    }
    setExportLoading(false);
  };

  // variable
  const column: ColumnsType<ISmsRecord> = [
    {
      title: '手机号码',
      dataIndex: 'phoneNumber',
      key: 'phoneNumber',
      width: 150,
      fixed: 'left',
      render: (text: string) => {
        return text ? (
          <div>
            <CopyToClipboard
              text={text}
              onCopy={() => message.success('复制成功')}
            >
              <a>{maskPhoneNumber(text)}</a>
            </CopyToClipboard>
          </div>
        ) : (
          <div>-</div>
        );
      },
    },
    {
      title: '运营商',
      dataIndex: 'carrierDesc',
      width: 180,
      key: 'carrierDesc',
      render: (text) => {
        return text || '-';
      },
    },
    {
      title: '省市',
      dataIndex: 'provinceAndCity',
      width: 180,
      key: 'provinceAndCity',
    },
    {
      title: '任务名称',
      width: 200,
      dataIndex: 'taskName',
      key: 'taskName',
      render: (text) => {
        return text || '-';
      },
    },
    {
      title: '话术名称',
      dataIndex: 'speechName',
      width: 230,
      key: 'speechName',
    },
    {
      title: '租户名称',
      dataIndex: 'tenantName',
      width: 200,
      key: 'tenantName',
    },
    {
      title: '短信服务商',
      dataIndex: 'smsProvider',
      width: 200,
      key: 'smsProvider',
    },
    {
      title: '短信签名',
      dataIndex: 'signature',
      width: 200,
      key: 'signature',
    },
    {
      title: '提交结果',
      dataIndex: 'commitResultDesc',
      key: 'commitResultDesc',
      width: 120,
    },
    {
      title: '发送结果',
      dataIndex: 'sendResultDesc',
      key: 'sendResultDesc',
      width: 120,
    },
    {
      title: '短信内容',
      dataIndex: 'messageContent',
      key: 'messageContent',
      width: 200,
      ellipsis: {
        showTitle: false,
      },
      render: (text) => (
        <Tooltip placement="topLeft" title={text}>
          {text}
        </Tooltip>
      ),
    },
    {
      title: '通话sessionid',
      dataIndex: 'sessionId',
      width: 200,
      key: 'sessionId',
    },
    {
      title: '通道名称',
      dataIndex: 'smsChannelName',
      width: 200,
      key: 'smsChannelName',
    },
    {
      title: '路由结果',
      dataIndex: 'routeResult',
      width: 180,
      key: 'routeResult',
    },
    {
      title: '触发类型',
      dataIndex: 'recordType',
      width: 180,
      key: 'recordType',
    },
    {
      title: '提交时间',
      dataIndex: 'commitTime',
      width: 200,
      key: 'commitTime',
    },
    {
      title: '回执返回时间',
      dataIndex: 'recieveResultTime',
      width: 200,
      key: 'recieveResultTime',
    },
    {
      title: '返回状态码',
      dataIndex: 'recieveResultCode',
      width: 180,
      key: 'recieveResultCode',
    },
    {
      title: '计费数',
      dataIndex: 'billingNum',
      width: 180,
      key: 'billingNum',
    },
    {
      title: '项目名称',
      dataIndex: 'projectName',
      width: 200,
      key: 'projectName',
      render: (text) => {
        return text || '-';
      },
    },
    {
      title: '项目ID',
      dataIndex: 'projectGuid',
      width: 200,
      key: 'projectGuid',
      render: (text) => {
        return text || '-';
      },
    },
    {
      title: '短信来源',
      dataIndex: 'smsSourceDesc',
      width: 200,
      key: 'smsSourceDesc',
      render: (text) => {
        return text || '-';
      },
    },
    {
      title: '任务类型',
      dataIndex: 'projectTaskTypeDesc',
      width: 200,
      key: 'projectTaskTypeDesc',
      render: (text) => {
        return text || '-';
      },
    },
    {
      title: '技能组',
      dataIndex: 'skillGroupName',
      width: 200,
      key: 'skillGroupName',
      render: (text) => {
        return text || '-';
      },
    },
    {
      title: '座席',
      dataIndex: 'seatName',
      width: 200,
      key: 'seatName',
      render: (text) => {
        return text || '-';
      },
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      width: 200,
      key: 'createTime',
    },
  ];

  // 获取高度变化
  const handleHeightEvent = debounce(async () => {
    const wrapEle = document.getElementById('messageWrap');
    const searchEle = document.getElementById('meesageSearchWrap');
    const paginationEle = document.getElementById('messagePaginationWrap');
    const _wrapHeight = wrapEle?.clientHeight || 700;
    const _searchHeight = searchEle?.clientHeight || 67;
    const paginationHeight = paginationEle?.clientHeight || 52;
    try {
      const _height = _wrapHeight - _searchHeight - paginationHeight - 55;
      setTableHeight(_height < 301 ? 500 : _height);
      if (_height < 301) {
        setOverflow(true);
      } else {
        setOverflow(false);
      }
    } catch (e) {}
  }, 200);

  // 分页
  const onChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      const params = { pageSize: size, pageNum: 1 };
      if (size !== pageSize) {
        setPageIndex(1);
        setPageSize(size);
      } else {
        setPageIndex(page);
        params.pageNum = page;
      }
      fetchList(params);
    },
    [pageSize],
  );

  // 请求第一页数据
  const fetchListOfPageOne = (data?: ISmsRecordListParams) => {
    setPageIndex(1);
    queryParams.current = !!data ? data : DEFAULT_MESSAGE_PARAMS;
    fetchList({ pageNum: 1 });
  };

  // 搜索
  const handleSearch = useCallback(
    (data: ISmsRecordListParams) => fetchListOfPageOne(data),
    [pageSize, pageIndex],
  );

  // 重置
  const handleReset = useCallback(fetchListOfPageOne, [pageSize, pageIndex]);

  useEffect(() => {
    fetchListOfPageOne();
    handleHeightEvent();
    window.addEventListener('resize', handleHeightEvent);
    return () => window.removeEventListener('resize', handleHeightEvent);
  }, []);

  return (
    <>
      <div className={styles.messageWrapper} id="messageWrap">
        <div className={styles.search} id="meesageSearchWrap">
          <MessageSearch
            onSearch={handleSearch}
            onReset={handleReset}
            onOpen={useCallback(handleHeightEvent, [])}
            onExport={handleExport}
            exportLoading={exportLoading}
          />
        </div>
        <div
          className={
            isOverflow
              ? styles.tableContent
              : `${styles.tableContent} ${styles.hidden}`
          }
        >
          <Table
            columns={column}
            dataSource={tableData}
            loading={isLoading}
            rowKey={() => uuidv1()}
            scroll={{ y: tableHeight }}
            pagination={false}
          />
        </div>
        <div className={styles.subPagination} id="messagePaginationWrap">
          <Pagination
            current={pageIndex}
            showSizeChanger={true}
            pageSize={pageSize}
            total={total}
            showTotal={(total) => `总共 ${total} 条`}
            onChange={onChange}
            pageSizeOptions={[100, 200, 500]}
          />
        </div>
      </div>
    </>
  );
};
export default SmsRecordList;
