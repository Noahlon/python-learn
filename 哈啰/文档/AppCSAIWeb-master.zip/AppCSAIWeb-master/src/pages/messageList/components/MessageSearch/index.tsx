import React, { memo, useCallback, useEffect, useState } from 'react';
import {
  Form,
  Input,
  Cascader,
  Select,
  Button,
  Row,
  Col,
  DatePicker,
  Space,
  SelectProps,
} from 'antd';
import { timeRanges } from '@/config';
import { getProvinceCityList } from '@/api/common';
import moment from 'moment';
import { querySmsSupplier } from '@/api/smsSupplier';
import { getTenantList } from '@/api/tenant';
import { getEnumListByType } from '@/api/common';
import { ISmsRecordListParams } from '@/api/messageList';
import { DownloadOutlined } from '@ant-design/icons';
import { useAccess } from '@umijs/max';
import { supportCarrierOpts } from '@/pages/lineSupplier/config';
import styles from '../../index.less';

const { RangePicker } = DatePicker;
const { SHOW_CHILD } = Cascader;

interface IProps {
  onSearch?: (data: ISmsRecordListParams) => void;
  onReset?: () => void;
  onOpen?: () => void;
  exportLoading: boolean;
  onExport: (data) => void;
}

const colLayout = { xl: 8, sm: 12, xs: 24 };

const MessageSearch: React.FC<IProps> = ({
  onSearch,
  onReset,
  onOpen,
  onExport,
  exportLoading,
}) => {
  const access = useAccess();
  const [form] = Form.useForm();
  const [openForm, setFormOpen] = useState(false); //展和收起
  const [cityOpts, setCityOpts] = useState([]); // 城市options
  const [tenantOpts, setTenantOpts] = useState<SelectProps['options']>([]); // 租户options
  const [smsProviderOpts, setSmsProviderOpts] = useState([]); // 短信提供商options
  const [commitOpts, setCommitOpts] = useState([]); // 提交结果options
  const [sendOpts, setSendOpts] = useState([]); // 发送结果options
  const [routeResultOpts, setRouteResultOpts] = useState([]); // 路由结果options
  const [recordTypeOpts, setRecordTypeOpts] = useState([]); // 触发类型options
  const [smsSourceOpts, setSmsSourceOpts] = useState([]); // 短信来源options
  const [taskTypeOpts, setTaskTypeOpts] = useState([]); // 任务类型options

  // fetch省市数据(本地)
  const fetchCityOpt = useCallback(async () => {
    const opt = [];
    // todo 异步获取行政区数据
    const DISTRICTS: any = await getProvinceCityList();
    DISTRICTS.forEach((item) => {
      if (item['level'] === 1) {
        const citys = [];
        DISTRICTS.forEach((i) => {
          if (item.area_code === i.parent_code)
            citys.push({ value: i.area_name, label: i.area_name });
        });
        opt.push({
          value: item.area_code,
          label: item.area_name,
          children: citys,
        });
      }
    });
    setCityOpts(opt || []);
  }, []);

  // fetch租户数据
  const fetchTenanList = async () => {
    const res = await getTenantList({ pageNum: 1, pageSize: 200 });
    if (res.success && res.data) {
      const opts = res.data?.map((item) => ({
        label: item.name,
        value: item.code,
      }));
      setTenantOpts(opts);
    }
  };

  // 获取供应商数据
  const fetchAllSupplier = async () => {
    const res = await querySmsSupplier({
      pageNum: 1,
      pageSize: 999,
    });
    if (res?.data) {
      setSmsProviderOpts(res.data?.list);
    }
  };

  // fetch枚举列表数据
  const fetchEnumList = async () => {
    // 1-提交结果 2-发送结果 3-路由结果 4-触发类型  6-短信来源 7-任务类型
    const params = {
      typeList: [1, 2, 3, 4, 6, 7],
    };
    const res = await getEnumListByType(params);
    if (res?.data?.length) {
      res.data.forEach((item) => {
        if (item?.type === 1) {
          setCommitOpts(item.enumConstantDTOList || []);
        }
        if (item?.type === 2) {
          setSendOpts(item.enumConstantDTOList || []);
        }
        if (item?.type === 3) {
          setRouteResultOpts(item.enumConstantDTOList || []);
        }
        if (item?.type === 4) {
          setRecordTypeOpts(item.enumConstantDTOList || []);
        }
        if (item?.type === 6) {
          setSmsSourceOpts(item.enumConstantDTOList || []);
        }
        if (item?.type === 7) {
          setTaskTypeOpts(item.enumConstantDTOList || []);
        }
      });
    }
  };

  // 重置
  const handleReset = () => {
    form.resetFields();
    form.setFieldValue('createTime', [
      moment().startOf('day'),
      moment().endOf('day'),
    ]);
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    onSearch?.(res);
  };

  useEffect(() => {
    fetchTenanList();
    fetchAllSupplier();
    fetchCityOpt();
    fetchEnumList();
  }, []);

  return (
    <Form
      form={form}
      initialValues={{
        createTime: [moment().startOf('day'), moment().endOf('day')],
      }}
    >
      <Row wrap={false}>
        <Col
          flex="auto"
          className={styles.leftSearch + ' ' + (openForm ? '' : styles.isHide)}
        >
          <Row gutter={16}>
            <Col {...colLayout}>
              <Form.Item name="phoneNumber">
                <Input placeholder="请输入手机号" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="createTime">
                <RangePicker
                  style={{ width: '100%' }}
                  placeholder={['创建开始', '创建结束']}
                  showTime
                  ranges={timeRanges}
                  allowClear={false}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="taskName">
                <Input placeholder="请输入任务名称" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="speechName">
                <Input placeholder="请输入话术名称" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="tenantIdList">
                <Select
                  placeholder="请选择租户"
                  allowClear
                  mode="multiple"
                  maxTagCount="responsive"
                  filterOption={(input, option) =>
                    (option?.label as string)
                      .toLowerCase()
                      .includes(input.toLowerCase())
                  }
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  options={tenantOpts}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="sendResult">
                <Select
                  placeholder="请选择发送结果"
                  allowClear
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                >
                  {sendOpts.map((item) => (
                    <Select.Option key={item.code} value={item.code}>
                      {item.value}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="commitResult">
                <Select
                  placeholder="请选择提交结果"
                  allowClear
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                >
                  {commitOpts.map((item) => (
                    <Select.Option key={item.code} value={item.code}>
                      {item.value}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="signature">
                <Input placeholder="请输入短信签名" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="sessionId">
                <Input placeholder="请输入通话sessionId" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="smsProviderType">
                <Select
                  placeholder="请选择短信服务商"
                  allowClear
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                >
                  {smsProviderOpts.map((item) => (
                    <Select.Option
                      key={item.supplierType}
                      value={item.supplierType}
                    >
                      {item.supplierName}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="cityList">
                <Cascader
                  options={cityOpts}
                  placeholder="请选择省市"
                  multiple
                  maxTagCount="responsive"
                  showCheckedStrategy={SHOW_CHILD}
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="smsChannelName">
                <Input placeholder="请输入通道名称" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="routeResult">
                <Select
                  placeholder="请选择路由结果"
                  allowClear
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  mode="multiple"
                >
                  {routeResultOpts.map((item) => (
                    <Select.Option key={item.code} value={item.code}>
                      {item.value}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="recordType">
                <Select
                  placeholder="请选择触发类型"
                  allowClear
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  mode="multiple"
                >
                  {recordTypeOpts.map((item) => (
                    <Select.Option key={item.code} value={item.code}>
                      {item.value}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="commitTime">
                <RangePicker
                  style={{ width: '100%' }}
                  placeholder={['提交时间开始', '提交时间结束']}
                  showTime
                  ranges={timeRanges}
                  allowClear={true}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="projectName">
                <Input placeholder="请输入项目名称" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="smsSourceList">
                <Select
                  placeholder="请选择短信来源"
                  allowClear
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  mode="multiple"
                >
                  {smsSourceOpts.map((item) => (
                    <Select.Option key={item.code} value={item.code}>
                      {item.value}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="projectTaskTypeList">
                <Select
                  placeholder="请选择任务类型"
                  allowClear
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  filterOption={(input, option) =>
                    (option?.label as string)
                      .toLowerCase()
                      .includes(input.toLowerCase())
                  }
                  mode="multiple"
                >
                  {taskTypeOpts.map((item) => (
                    <Select.Option key={item.code} value={item.code}>
                      {item.value}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="skillGroupName">
                <Input placeholder="请输入技能组名称" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="seatName">
                <Input placeholder="请输入座席名称" />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="carrierType">
                <Select
                  placeholder="请选择运营商"
                  allowClear
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                >
                  {supportCarrierOpts.map((item) => (
                    <Select.Option key={item.value} value={item.value}>
                      {item.label}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none">
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            {access?.authCodeList?.includes('SMSLogs-DownWard-Export') && (
              <Button
                icon={<DownloadOutlined />}
                onClick={onExport}
                loading={exportLoading}
              >
                导出
              </Button>
            )}
            <Button onClick={handleReset}>重置</Button>
            <Button
              type="link"
              size="small"
              onClick={() => {
                setFormOpen(!openForm);
                onOpen?.();
              }}
            >
              {openForm ? '收起' : '展开'}
            </Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default memo(MessageSearch);
