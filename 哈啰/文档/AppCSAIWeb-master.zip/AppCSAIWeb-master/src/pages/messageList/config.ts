import moment from 'moment';

export const DEFAULT_MESSAGE_PARAMS: Partial<any> = {
  createTime: [
    moment().startOf('day').format('YYYY-MM-DD HH:mm:ss'),
    moment().endOf('day').format('YYYY-MM-DD HH:mm:ss'),
  ],
};

// 提交结果列表
// export const COMMIT_REAULT = [
//   { label: '提交成功', value: 0 },
//   { label: '提交失败', value: 1 },
// ];

// 发送结果列表
// export const SEND_REAULT = [
//   { label: '发送成功', value: 0 },
//   { label: '发送失败', value: 1 },
//   { label: '结果未知', value: 2 },
// ];
