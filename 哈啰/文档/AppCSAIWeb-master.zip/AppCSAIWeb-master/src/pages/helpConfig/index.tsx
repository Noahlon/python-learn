import React, { FC, useEffect, useState } from 'react';
import '@wangeditor/editor/dist/css/style.css'; // 引入 css
import styles from './index.less';
import RichText from '@/components/RichText';
import { notification } from 'antd';
import { helpcenterModify, helpcenterDetail } from '@/api/followForm';

const HelpConfig: FC = () => {
  const [value, setValue] = useState('');

  const saveHandle = async (html: string) => {
    const args = {
      content: html,
    };
    const res = await helpcenterModify(args);
    if (res?.code === 0) {
      setValue(html);
      notification.success({
        message: `操作成功`,
        description: '帮助中心保存成功!',
        placement: 'topRight',
      });
    }
  };
  const getDetail = async () => {
    const res = await helpcenterDetail();
    if (res?.code === 0) {
      setValue(res?.data);
    }
  };

  useEffect(() => {
    getDetail();
  }, []);

  return (
    <div className={styles.helpConfigWrap}>
      <RichText value={value} save={saveHandle} showBtn={true}></RichText>
    </div>
  );
};

export default HelpConfig;
