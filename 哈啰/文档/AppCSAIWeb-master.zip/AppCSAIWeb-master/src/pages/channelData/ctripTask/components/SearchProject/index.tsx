import React from 'react';
import { Form, Input, Select, Button, Row, Col, Space, DatePicker } from 'antd';
import { SEARCHLAYOUT } from '@/constants/processconfig';
import { timeRanges } from '@/config';
import { taskStateOpts } from '../../config';
import { businessCtripTaskListReq } from '@/api/crtipTask';
import moment from 'moment';

interface IProps {
  onSearch: (data: businessCtripTaskListReq) => void;
  onReset: () => void;
}
type BusinessCtripTaskListReqWithOptionalUploadTime =
  businessCtripTaskListReq & {
    uploadTime?: moment.Moment[];
  };

const { RangePicker } = DatePicker;

const SearchProject: React.FC<IProps> = ({ onSearch, onReset }) => {
  const [form] = Form.useForm();

  // 重置
  const handleReset = () => {
    form.resetFields();
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res: BusinessCtripTaskListReqWithOptionalUploadTime =
      await form.validateFields();
    const { uploadTime } = res;
    res.startTime = uploadTime?.[0].format('YYYY-MM-DD HH:mm:ss');
    res.endTime = uploadTime?.[1].format('YYYY-MM-DD HH:mm:ss');
    onSearch?.(res);
  };

  return (
    <Form form={form} style={{ padding: '20px 20px 0' }}>
      <Row wrap={false}>
        <Col flex="auto">
          <Row gutter={16}>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="taskId" label="任务ID">
                <Input allowClear placeholder="请输入任务ID" />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="uploadTime" label="导入时间">
                <RangePicker
                  style={{ width: '100%' }}
                  placeholder={['开始', '结束']}
                  showTime={{
                      hideDisabledOptions: true,
                      defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                  }}
                  ranges={timeRanges}
                  allowClear
                />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="taskState" label="任务状态">
                <Select
                  placeholder="任务状态"
                  allowClear
                  options={taskStateOpts}
                />
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none" style={{ marginLeft: '15px' }}>
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default SearchProject;
