import React, { useEffect, useState, useRef } from 'react';
import { Button } from 'antd';
import { CloudUploadOutlined } from '@ant-design/icons';
import { useAccess } from '@umijs/max';
import SearchProject from './components/SearchProject';
import { DEFAULT_QUERY_PARAMS, dataSettingColumns } from './config';
import ResizeTable from '@/components/ResizeTable';
import { ColumnsType } from 'antd/es/table';
import {
  businessCtripExport,
  businessCtripTaskDownload,
  businessCtripTaskList,
  businessCtripTaskListReq,
  ctripTaskList,
} from '@/api/crtipTask';
import styles from './index.less';
import { httpReplace } from '@/utils';
import { debounce } from 'lodash';
import XiechengUpload from './components/XiechengUpload';

const ChannelData: React.FC = () => {
  const access = useAccess();
  const [uploadOpen, setUploadOpen] = useState(false);
  const [tableData, setTableData] = useState<ctripTaskList[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  // pagination
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [tableTotal, setTableTotal] = useState<number>();
  // 搜索params
  const queryParams = useRef(DEFAULT_QUERY_PARAMS);

  // fetch项目列表列表
  const fetchProjectList = async () => {
    const params = {
      ...queryParams.current,
    };
    setTableLoading(true);
    const res = await businessCtripTaskList(params);
    if (res?.code === 0) {
      setTableData(res?.data?.list);
      setTableTotal(res?.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // 页面页数change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchProjectList();
  };

  // 搜索
  const handleSearch = (res: businessCtripTaskListReq) => {
    queryParams.current = { ...queryParams.current, ...res };
    handlePageChange(1);
  };

  // 重置
  const handleReset = () => {
    queryParams.current = DEFAULT_QUERY_PARAMS;
    setPagination(DEFAULT_QUERY_PARAMS);
    fetchProjectList();
  };

  // 下载文件
  const handleDownLoad = async (url: string) => {
    if (!url) return;
    let elink = document.createElement('a');
    elink.style.display = 'none';
    let newUrl = httpReplace(url);
    elink.href = newUrl;
    document.body.appendChild(elink);
    elink.click();
    setTimeout(() => {
      document.body.removeChild(elink);
    }, 300);
  };

  // downType 1.下载上传名单  2. 下载已完成名单
  const clickBusinessCtripExport = debounce(
    async (downType: number, id: string) => {
      const res =
        downType === 1
          ? await businessCtripTaskDownload({ taskId: id })
          : await businessCtripExport({ taskId: id });
      const { code, data } = res;
      if (code === 0) {
        handleDownLoad(data);
      }
    },
    300,
  );

  // 携程撞库 columns
  const columns: ColumnsType<ctripTaskList> = [
    ...dataSettingColumns,
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 180,
      render: (_, record) => (
        <>
          <div style={{ display: 'flex' }}>
            {access?.authCodeList?.includes('Channel-Data-Download-Roster') && (
              <div style={{ marginRight: '10px' }}>
                <a
                  onClick={() => {
                    clickBusinessCtripExport(1, record?.id);
                  }}
                >
                  下载上传名单
                </a>
              </div>
            )}
            {access?.authCodeList?.includes(
              'Channel-Data-Download-Finish-Roster',
            ) &&
              record?.taskState === 3 && (
                <div>
                  <a
                    onClick={() => {
                      clickBusinessCtripExport(2, record?.id);
                    }}
                  >
                    下载完成名单
                  </a>
                </div>
              )}
          </div>
        </>
      ),
    },
  ];

  const handleOk = () => {
    setUploadOpen(false);
    fetchProjectList();
  };

  // 取消上传
  const uploadcCheckcancel = () => {
    setUploadOpen(false);
  };

  useEffect(() => {
    fetchProjectList();
  }, []);

  return (
    <>
      <div className={styles.projectListWrap}>
        {/* 搜索区域 */}
        <SearchProject onSearch={handleSearch} onReset={handleReset} />
        {access?.authCodeList?.includes('Channel-Data-Import-Roster') && (
          <div className={styles.addButton}>
            <Button
              type="primary"
              icon={<CloudUploadOutlined />}
              onClick={() => {
                setUploadOpen(true);
              }}
            >
              导入名单
            </Button>
          </div>
        )}
        {/* 携程撞库任务list */}
        <ResizeTable
          columns={columns}
          dataSource={tableData}
          scroll={{ x: 1800 }}
          rowKey="id"
          loading={tableLoading}
          pagination={{
            onChange: handlePageChange,
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            total: tableTotal,
          }}
        />
      </div>
      {/** 携程批量上传 */}
      <XiechengUpload
        onCancel={uploadcCheckcancel}
        onOk={handleOk}
        open={uploadOpen}
      ></XiechengUpload>
    </>
  );
};

export default ChannelData;
