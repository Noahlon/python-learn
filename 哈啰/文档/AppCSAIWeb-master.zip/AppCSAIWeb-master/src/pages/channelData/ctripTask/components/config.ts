import { showEmptyLine } from '@/utils/format';

export const downLoadTemplateUrl =
  'https://m.hellobike.com/resource/gallery/171/IY8qbIVE-I.xlsx';

// 携程撞库uplpad columns
export const columns: any = [
  {
    title: '文件名',
    dataIndex: 'name',
    render(val: string) {
      return showEmptyLine(val);
    },
  },
  {
    title: '失败原因',
    dataIndex: 'reason',
    width: 220,
    render(val: string) {
      return showEmptyLine(val);
    },
  },
];
