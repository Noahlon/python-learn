import { showEmptyLine } from '@/utils/format';
import { ColumnsType } from 'antd/es/table';

export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 100,
};

export const taskStateOpts = [
  { label: '待执行', value: 1 },
  { label: '执行中', value: 2 },
  { label: '执行完成', value: 3 },
  { label: '撞库失败', value: -1 },
];

// 携程撞库 columns
export const dataSettingColumns: ColumnsType = [
  {
    title: '任务ID',
    dataIndex: 'id',
    width: 200,
    fixed: 'left',
    render(val: string) {
      return showEmptyLine(val);
    },
  },
  {
    title: '导入名单数',
    dataIndex: 'uploadQty',
    width: 160,
    render(val: number) {
      return showEmptyLine(val);
    },
  },
  {
    title: '返回名单数',
    dataIndex: 'returnQty',
    width: 160,
    render(val: number) {
      return showEmptyLine(val);
    },
  },
  {
    title: '可外呼名单数',
    dataIndex: 'canCallQty',
    width: 160,
    render(val: number) {
      return showEmptyLine(val);
    },
  },
  {
    title: '不可外呼名单数',
    dataIndex: 'canotCallQty',
    width: 160,
    render(val: number) {
      return showEmptyLine(val);
    },
  },
  {
    title: '导入人',
    dataIndex: 'uploadUser',
    width: 160,
    render(val: string) {
      return showEmptyLine(val);
    },
  },
  {
    title: '导入时间',
    dataIndex: 'createTimeStr',
    width: 200,
    render(val: string) {
      return showEmptyLine(val);
    },
  },
  {
    title: '任务状态',
    dataIndex: 'taskStateStr',
    width: 160,
    render(val: string) {
      return showEmptyLine(val);
    },
  },
];
