import React, { useState, useRef, FC, useEffect } from 'react';
import { Button, Form, Modal, Table, Upload, message } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import styles from './index.less';
import { uploadMusic } from '@/api/language';
import { executePromises } from '@/utils';
import { businessCtripTaskUpload } from '@/api/crtipTask';
import { columns, downLoadTemplateUrl } from '../config';

const layout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 14 },
};

interface Iprops {
  onCancel: () => void;
  onOk: () => void;
  open: boolean;
}

/**
 * 上传 执行时机
 * 1. beforeupload 拦截
 * 2. (before触发setmsg showerrormsg 如有)- onchange 塞数据(setFileList)
 * 3. customRequest(所有上传完成执行 showerrormsg) oss上传完成
 * @returns
 */

const XiechengUpload: FC<Iprops> = (props) => {
  const { onCancel, onOk, open } = props;
  const [fileList, setFileList] = useState([]);
  const removeFilesRef = useRef([]);
  const [isloading, setIsloading] = useState(false);
  const [form] = Form.useForm();
  const [isShowMsg, setIsShowMsg] = useState(false);

  const uploadFiledListUidRef = useRef([]); // 上传失败的list uid  存储大于10MB 或者 文件类型不合法 的 uid
  const uploadFileWaitRef = useRef([]); // 以数组形式存储，单次数上传的oss的promise，如：上传成功3个就是3个promise
  const ossTotalCountRef = useRef(0); // 单次oss上传总数量
  const fileTotalCountRef = useRef(0); // 单次上传总数量
  const fileSuccessCountRef = useRef(0); // 单次上传成功数量
  const fileFailedCountRef = useRef(0); // 被拦截
  const fileFailedOssCountRef = useRef(0); // oss上传失败
  const fileReasonCountsRef = useRef([]); // 失败信息
  const beforeClickFilelistRef = useRef([]); // 点击前的fileList

  const handleError = (file, msg = '') => {
    // 失败
    fileFailedOssCountRef.current += 1;
    fileSuccessCountRef.current -= 1;
    fileReasonCountsRef.current.push({
      uid: file.uid,
      name: file.name,
      reason: msg || 'oss上传失败',
    });
    setFileList(
      fileList.map((item) => {
        if (item.uid === file.uid) {
          item.status = 'error';
        }
        return item;
      }),
    );
  };

  // 批量上传
  const handleBatchUpload = async (Info) => {
    const formData = new FormData();
    const file = Info.file;
    formData.append('file', file);
    uploadFileWaitRef.current.push(
      new Promise((resolve, reject) => {
        uploadMusic(formData)
          .then((res: any) => {
            if (res?.url) {
              setFileList(
                fileList.map((item) => {
                  if (item.uid === file.uid) {
                    item.status = 'success';
                  }
                  return item;
                }),
              );
              resolve({
                uid: file.uid,
                fileName: file.name,
                ossUrl: res?.url || '',
              });
            } else {
              handleError(file, res?.msg);
              reject(false);
            }
          })
          .catch(() => {
            // 失败
            handleError(file);
            reject(false);
          })
          .finally(() => {
            ossTotalCountRef.current += 1;
            // max-size 或不合法 文件 提前出发err-msg，导致计数器清空，后续上传出现不了ErrMsg的情况～ 原因是出现 ossTotalCountRef.current为上传成功数量大于fileTotalCountRef.current为0（被提前清空）
            // ossTotalCountRef.current > fileTotalCountRef.current 所以打上这个补丁～
            if (
              ossTotalCountRef.current ===
                fileTotalCountRef.current - fileFailedCountRef.current ||
              ossTotalCountRef.current > fileTotalCountRef.current
            ) {
              setIsShowMsg(true);
            }
          });
      }),
    );
  };

  const uploadcCheckOk = () => {
    const dest = message.loading('正在上传', 0);
    setIsloading(true);
    executePromises(uploadFileWaitRef.current)
      .then(async (result) => {
        const datas = result.reduce((total, item) => {
          if (item.status === 'fulfilled') {
            return [...total, item.value];
          }
          return total;
        }, []);

        // 筛选 1.不被删除的文件 2.拿到每个文件的ossUrl
        const uploadFileUrls = datas
          .filter((item) => !removeFilesRef.current?.includes(item.uid))
          .map((item) => item?.ossUrl);
        const res = await businessCtripTaskUpload({
          uploadFileUrls,
        });
        if (res?.code === 0) {
          message.success('上传成功');
        }
      })
      .catch(() => {
        message.error('上传失败');
      })
      .finally(() => {
        uploadFileWaitRef.current = [];
        setFileList([]);
        form.resetFields();
        dest?.();
        setIsloading(false);
        onOk();
      });
  };

  const checkOkModalInfo = async () => {
    const param = await form.validateFields();
    console.log('param', param);
    Modal.confirm({
      title: '请确认是否提交任务',
      content: '提交后将立即执行撞库任务',
      okText: '确认',
      centered: true,
      cancelText: '取消',
      onOk() {
        uploadcCheckOk();
      },
    });
  };

  const handleChange = ({ fileList }) => {
    const newFileList = fileList.filter(
      (item: any) => item.size / 1024 / 1024 <= 10,
    );
    setFileList(newFileList);
    if (!!uploadFiledListUidRef.current.length) {
      setFileList((pre) => {
        const _fileList = pre.filter(
          (item) => !uploadFiledListUidRef.current.includes(item.uid),
        );
        return _fileList;
      });
    }
  };

  const handleBeforeUpload = (file, _fileList) => {
    const fileCount = _fileList.length;
    const isLtFile = file.size / 1024 / 1024 <= 10;
    const fileName = file?.name;
    const fileType = file.name.split('.').pop();
    fileTotalCountRef.current = _fileList?.length;
    // filelist需要删除已上传的文件（非法）
    if (fileList.length >= 30 || fileCount + fileList.length > 30) {
      fileFailedCountRef.current += 1;
      fileReasonCountsRef.current.push({
        uid: file.uid,
        name: fileName,
        reason: '上传文件数量最大为30个',
        errorType: 'errorMaxSize',
      });

      setIsShowMsg(true);
      return false;
    }

    if (!isLtFile) {
      fileFailedCountRef.current += 1;
      fileReasonCountsRef.current.push({
        uid: file.uid,
        name: fileName,
        reason: '上传文件大小不能超过10MB',
        errorType: 'errorMaxLt',
      });
      uploadFiledListUidRef.current.push(file.uid);
      setIsShowMsg(true);
      return false;
    }

    if (fileType !== 'xlsx' && fileType !== 'csv') {
      fileFailedCountRef.current += 1;
      fileReasonCountsRef.current.push({
        uid: file.uid,
        name: fileName,
        reason: '文件上传类型不合法',
        errorType: 'errorType',
      });
      uploadFiledListUidRef.current.push(file.uid);
      setIsShowMsg(true);
      return false;
    }

    fileSuccessCountRef.current += 1;
    return true;
  };

  const handleOk = () => {
    checkOkModalInfo();
  };

  const handleCancel = () => {
    setFileList([]);
    form.resetFields();
    onCancel?.();
  };

  useEffect(() => {
    if (fileList.length === 0) {
      form.resetFields();
    }
  }, [fileList]);

  /**
   * 如果上传成功数量大于30，全部拦截掉。
   */
  const renderErrorMsgs = (total: number, success: number, failed: number) => {
    Modal.info({
      title: <a>上传文件信息</a>,
      icon: null,
      wrapClassName: 'modalFilesInfo',
      width: 500,
      content: (
        <div>
          <div>文件总数：{total}</div>
          <div className={styles.fileUpInfo}>上传成功：{success}</div>
          <div className={styles.fileUpInfo}>上传失败：{failed}</div>
          <div className={styles.tableContent}>
            {!!fileReasonCountsRef.current.length && (
              <Table
                columns={columns}
                className={styles.failedList}
                dataSource={fileReasonCountsRef.current}
                rowKey={(record) => record.uid}
                scroll={{ y: 300 }}
                pagination={false}
              ></Table>
            )}
          </div>
        </div>
      ),
      closable: true,
      okText: false,
      cancelText: false,
      afterClose: () => {
        setIsShowMsg(false);
      },
    });
    const isMaxSizeError = fileReasonCountsRef.current.every(
      (item) => item.errorType === 'errorMaxSize',
    );
    if (isMaxSizeError) {
      // 设置超时函数表示想延时1s在onchange执行完成后 set
      setTimeout(() => {
        setFileList([...beforeClickFilelistRef.current]);
      }, 1000);
    }

    fileSuccessCountRef.current = 0;
    fileFailedCountRef.current = 0;
    fileTotalCountRef.current = 0;
    ossTotalCountRef.current = 0;
    fileFailedOssCountRef.current = 0;
    fileReasonCountsRef.current = [];

    beforeClickFilelistRef.current = [...fileList];
    setIsShowMsg(false);
  };

  useEffect(() => {
    if (fileTotalCountRef.current > 0 && isShowMsg) {
      renderErrorMsgs(
        fileTotalCountRef.current,
        fileSuccessCountRef.current,
        fileFailedCountRef.current + fileFailedOssCountRef.current,
      );
    }
  }, [isShowMsg]);

  const removeFiles = (file) => {
    setFileList((pre) => {
      const _fileList = pre.filter((item) => item.uid !== file.uid);
      beforeClickFilelistRef.current = [..._fileList];
      return _fileList;
    });
    removeFilesRef.current.push(file.uid);
  };

  useEffect(() => {
    fileSuccessCountRef.current = 0;
    fileFailedCountRef.current = 0;
    fileTotalCountRef.current = 0;
    fileReasonCountsRef.current = [];
    beforeClickFilelistRef.current = [];
    ossTotalCountRef.current = 0;
    uploadFileWaitRef.current = [];
    fileFailedOssCountRef.current = 0;
  }, [open]);

  return (
    <>
      {/* 导入携程名单modal */}
      <Modal
        open={open}
        width="600px"
        title="导入携程名单"
        maskClosable={false}
        destroyOnClose
        centered
        footer={[
          <Button key="cancel" onClick={handleCancel}>
            取消
          </Button>,
          <Button
            type="primary"
            key="ok"
            onClick={handleOk}
            loading={isloading}
          >
            确定
          </Button>,
        ]}
        onCancel={handleCancel}
      >
        <div className={styles.modalWrap}>
          <Form {...layout} form={form}>
            <div className={styles.uploadItems}>
              <Form.Item
                label="上传名单"
                name="uploadList"
                rules={[
                  {
                    required: true,
                    message: '请选择文件',
                  },
                  {
                    validator: () => {
                      const isAllError =
                        fileList.length > 0 &&
                        fileList.every((item) => item.status === 'error');
                      if (isAllError) return Promise.reject();
                      return Promise.resolve();
                    },
                    message: '请选择文件',
                  },
                  {
                    validator: () => {
                      const isExitsLoading =
                        fileList.length > 0 &&
                        fileList.some((item) => item.status === 'uploading');
                      if (isExitsLoading) return Promise.reject();
                      return Promise.resolve();
                    },
                    message: '请等待所有文件oss上传完成',
                    validateTrigger: ['change'],
                  },
                ]}
                extra={
                  <Button
                    type="link"
                    style={{ position: 'absolute', left: '120px', top: 0 }}
                    href={downLoadTemplateUrl}
                  >
                    下载模版
                  </Button>
                }
              >
                <Upload
                  maxCount={30}
                  fileList={fileList}
                  accept=".csv,.xlsx"
                  customRequest={(info) => {
                    handleBatchUpload(info);
                  }}
                  onRemove={(file) => removeFiles(file)}
                  onChange={handleChange}
                  beforeUpload={handleBeforeUpload}
                  multiple
                >
                  <Button icon={<UploadOutlined />}>点击上传</Button>
                </Upload>
              </Form.Item>
            </div>
            <div className={styles.tips}>
              <div>温馨提示：</div>
              <div>最多上传30个文件，每个文件最多10MB</div>
              <div>支持csv、xlsx文件上传</div>
            </div>
          </Form>
        </div>
      </Modal>
    </>
  );
};
export default XiechengUpload;
