import React, { useState, useRef } from 'react';
import { Button, message } from 'antd';
import moment from 'moment';
// import { CloudUploadOutlined } from '@ant-design/icons';
import { useAccess } from '@umijs/max';
import SearchProject from './components/SearchProject';
import { DEFAULT_QUERY_PARAMS, dataSettingColumns } from './config';
import ResizeTable from '@/components/ResizeTable';
import { ColumnsType } from 'antd/es/table';
import { formatType } from '@/config';
import {
  businessMobileExport,
  businessMobileTaskDownload,
  businessCtripTaskList,
  businessMobileListReq,
  mobileTaskList,
  defaultData,
} from '@/api/mobileTask';
import styles from './index.less';
import { httpReplace } from '@/utils';
import { debounce } from 'lodash';
import FailReason from './components/FailReason';
import XiechengUpload from './components/XiechengUpload';

const ChannelData: React.FC = () => {
  const access = useAccess();
  const [defaultParams, setDefaultParams] = useState<defaultData>({});  // 保存默认筛选项
  const [uploadOpen, setUploadOpen] = useState(false);
  const [tableData, setTableData] = useState<mobileTaskList[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  // 失败原因弹框
  const [failOpen, setFailOpen] = useState<boolean>(false);
  // 当前查看的数据
  const [nowItem, setNowItem] = useState();
  // pagination
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [tableTotal, setTableTotal] = useState<number>();
  // 搜索params
  const queryParams = useRef(DEFAULT_QUERY_PARAMS);

  // fetch项目列表列表
  const fetchProjectList = async () => {
    const params = {
      ...queryParams.current,
    };
    // 创建时间
    if (
      Array.isArray(params.uploadTime) &&
      params?.uploadTime?.length === 2
    ) {
      params.startTime = moment(params.uploadTime[0]).format(
        formatType,
      );
      params.endTime = moment(params.uploadTime[1]).format(
        formatType,
      );
    }
    delete params.uploadTime;
    setTableLoading(true);
    const res = await businessCtripTaskList(params);
    if (res?.code === 0) {
      setTableData(res?.data?.list);
      setTableTotal(res?.data?.totalRecord);
    } else {
      setTableData([])
    }
    setTableLoading(false);
  };

  // 页面页数change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchProjectList();
  };

  // 搜索
  const handleSearch = (res: businessMobileListReq) => {
    queryParams.current = { ...queryParams.current, ...res };
    handlePageChange(1);
  };

  // 重置
  const handleReset = () => {
    queryParams.current = { ...DEFAULT_QUERY_PARAMS, ...defaultParams };
    setPagination({ ...DEFAULT_QUERY_PARAMS, ...defaultParams });
    fetchProjectList();
  };

  // 下载文件
  const handleDownLoad = async (url: string) => {
    if (!url) return;
    let elink = document.createElement('a');
    elink.style.display = 'none';
    let newUrl = httpReplace(url);
    elink.href = newUrl;
    document.body.appendChild(elink);
    elink.click();
    setTimeout(() => {
      document.body.removeChild(elink);
    }, 300);
  };

  // downType 1.下载上传名单  2. 下载已完成名单
  const clickBusinessCtripExport = debounce(
    async (downType: number, id: string) => {
      const res =
        downType === 1
          ? await businessMobileTaskDownload({ taskId: id })
          : await businessMobileExport({ taskId: id });
      const { code, data } = res;
      if (code === 0) {
        handleDownLoad(data);
      }
    },
    300,
  );

  // 查看失败原因
  const showFail = (val) => {
    setNowItem(val);
    setFailOpen(true);
  }

  // 携程撞库 columns
  const columns: ColumnsType<mobileTaskList> = [
    ...dataSettingColumns,
    {
      title: '失败原因',
      dataIndex: 'failVersion',
      width: 200,
      render: (val: string, record) => (
        val ? <div onClick={showFail.bind(this, record)} className={styles.blueText}>点击查看</div> : '-'
      ),
    },
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 220,
      render: (_, record) => (
        <>
          <div style={{ display: 'flex' }}>
            {access?.authCodeList?.includes('Channel-Mobile-download-Roster') &&
              record?.taskStatus !== '解析中' && (
                <div style={{ marginRight: '10px' }}>
                  <a
                    onClick={() => {
                      clickBusinessCtripExport(1, record?.id);
                    }}
                  >
                    下载上传名单
                  </a>
                </div>
              )}
            {access?.authCodeList?.includes(
              'Channel-Mobile-download-Finished',
            ) &&
              record?.taskStatus === '执行完成' && (
                <div>
                  <a
                    onClick={() => {
                      clickBusinessCtripExport(2, record?.id);
                    }}
                  >
                    下载完成名单
                  </a>
                </div>
              )
            }
          </div>
        </>
      ),
    },
  ];

  const handleOk = () => {
    setUploadOpen(false);
    fetchProjectList();
  };

  // 取消上传
  const uploadcCheckcancel = () => {
    setUploadOpen(false);
  };
  // 获取默认筛选条件
  const getDefaultParams = (val: defaultData) => {
    setDefaultParams(val);
  }
  return (
    <>
      <div className={styles.mobileListWrap}>
        {/* 搜索区域 */}
        <SearchProject defaultParams={getDefaultParams} onSearch={handleSearch} onReset={handleReset} />
        {access?.authCodeList?.includes('Channel-Mobile-Import') && (
          <div className={styles.addButton}>
            <Button
              type="primary"
              // icon={<CloudUploadOutlined />}
              onClick={() => {
                setUploadOpen(true);
              }}
            >
              新增任务
            </Button>
          </div>
        )}
        {/* 携程撞库任务list */}
        <ResizeTable
          columns={columns}
          dataSource={tableData}
          scroll={{ x: 1800 }}
          rowKey="id"
          loading={tableLoading}
          pagination={{
            onChange: handlePageChange,
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            total: tableTotal,
            pageSizeOptions: [100, 200, 300]
          }}
        />
      </div>
      {/** 携程批量上传 */}
      <XiechengUpload
        onCancel={uploadcCheckcancel}
        onOk={handleOk}
        open={uploadOpen}
      ></XiechengUpload>
      {/* 失败原因 */}
      <FailReason data={nowItem} open={failOpen} closeFail={() => { setFailOpen(false) }}></FailReason>
    </>
  );
};

export default ChannelData;
