import React, { useState, useEffect } from 'react';
import moment from 'moment';
import { Form, Input, Select, Button, Row, Col, Space, DatePicker, SelectProps } from 'antd';
import { SEARCHLAYOUT } from '@/constants/processconfig';
import { timeRanges } from '@/config';
import { debounce } from 'lodash';
import { taskStateOpts } from '../../config';
import { businessMobileListReq, queryChannel, defaultData } from '@/api/mobileTask';

interface IProps {
  onSearch: (data: businessMobileListReq) => void;
  onReset: () => void;
  defaultParams: (data: defaultData) => void;
}
type BusinessCtripTaskListReqWithOptionalUploadTime =
  businessMobileListReq & {
    uploadTime?: moment.Moment[];
  };

const { RangePicker } = DatePicker;

const SearchProject: React.FC<IProps> = ({ onSearch, onReset, defaultParams }) => {
  const [channelOpts, setChannelOpts] = useState<SelectProps['options']>([]); // 短信提供商options
  const [initParams, setDefaultParams] = useState<defaultData>({});
  const [form] = Form.useForm();
  // 获取数据渠道
  const fetchAllChannel = async () => {
    const res = await queryChannel();
    if (res?.data) {
      const opts = res.data?.map((item) => ({
        label: item.desc,
        value: item.key,
      }));
      // form.setFieldsValue({
      //   orgChannel: res.data?.[0].key,
      // });
      // setDefaultParams({ orgChannel: res.data?.[0].key });
      // defaultParams({ orgChannel: res.data?.[0].key });
      setChannelOpts(opts);
      handleSearch();
    } else {
      handleSearch();
    }
  };
  // 重置
  const handleReset = async () => {
    await form.resetFields();
    // form.setFieldsValue({
    //   orgChannel: initParams.orgChannel,
    // });
    onReset?.();
  };

  // 搜索
  const handleSearch = debounce(async () => {
    try {
      const res: BusinessCtripTaskListReqWithOptionalUploadTime = await form.validateFields();
      const { uploadTime } = res;
      res.startTime = uploadTime?.[0].format('YYYY-MM-DD HH:mm:ss');
      res.endTime = uploadTime?.[1].format('YYYY-MM-DD HH:mm:ss');
      onSearch?.(res);
    } catch (e) {}
  }, 200);
  useEffect(() => {
    fetchAllChannel();
  }, []);
  return (
    <Form form={form} 
      initialValues={{
        uploadTime: [moment().startOf('day'), moment().endOf('day')],
      }}
      style={{ padding: '20px 20px 0' }}>
      <Row wrap={false}>
        <Col flex="auto">
          <Row gutter={16}>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="taskId" label="任务ID">
                <Input allowClear placeholder="请输入任务ID" />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="taskName" label="任务名称">
                <Input allowClear placeholder="请输入任务名称" />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="uploadTime" label="导入时间">
                <RangePicker
                  style={{ width: '100%' }}
                  placeholder={['开始', '结束']}
                  showTime
                  ranges={timeRanges}
                  allowClear={false}
                />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="taskStatus" label="任务状态">
                <Select
                  placeholder="任务状态"
                  allowClear
                  options={taskStateOpts}
                />
              </Form.Item>
            </Col>
            <Col {...SEARCHLAYOUT}>
              <Form.Item name="orgChannel" label="数据渠道">
                <Select
                  placeholder="数据渠道"
                  allowClear
                  showSearch
                  filterOption={(input, option) =>
                    (option?.label as string)
                      .toLowerCase()
                      .includes(input.toLowerCase())
                  }
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  options={channelOpts}
                />
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none" style={{ marginLeft: '15px' }}>
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              查询
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default SearchProject;
