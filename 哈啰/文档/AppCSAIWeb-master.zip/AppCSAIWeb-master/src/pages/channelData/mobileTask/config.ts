import moment from 'moment';
import { showEmptyLine } from '@/utils/format';
import { ColumnsType } from 'antd/es/table';

export const DEFAULT_QUERY_PARAMS: Partial<any> ={
  pageNum: 1,
  pageSize: 100,
  uploadTime: [
    moment().startOf('day').format('YYYY-MM-DD HH:mm:ss'),
    moment().endOf('day').format('YYYY-MM-DD HH:mm:ss'),
  ],
  orgChannel: '',
};

export const taskStateOpts = [
  { label: '待执行', value: 1 },
  { label: '解析中', value: 2 },
  { label: '解析完成', value: 3 },
  { label: '执行中', value: 4 },
  { label: '失败', value: 5 },
  { label: '执行完成', value: 6 },
];

// 携程撞库 columns
export const dataSettingColumns: ColumnsType = [
  {
    title: '任务ID',
    dataIndex: 'id',
    width: 200,
    fixed: 'left',
    render(val: string) {
      return showEmptyLine(val);
    },
  },
  {
    title: '任务名称',
    dataIndex: 'taskName',
    width: 160,
    render(val: string) {
      return showEmptyLine(val);
    },
  },
  {
    title: '数据渠道',
    dataIndex: 'orgChannel',
    width: 160,
    render(val: string) {
      return showEmptyLine(val);
    },
  },
  {
    title: '数据模型',
    dataIndex: 'orgModel',
    width: 160,
    render(val: string) {
      return showEmptyLine(val);
    },
  },
  {
    title: '导入名单数',
    dataIndex: 'uploadQty',
    width: 160,
    render(val: number) {
      return showEmptyLine(val);
    },
  },
  {
    title: '返回名单数',
    dataIndex: 'returnQty',
    width: 160,
    render(val: number) {
      return showEmptyLine(val);
    },
  },
  {
    title: '可外呼名单数',
    dataIndex: 'canCallQty',
    width: 160,
    render(val: number) {
      return showEmptyLine(val);
    },
  },
  {
    title: '不可外呼名单数',
    dataIndex: 'canotCallQty',
    width: 160,
    render(val: number) {
      return showEmptyLine(val);
    },
  },
  {
    title: '导入人',
    dataIndex: 'uploadUser',
    width: 160,
    render(val: string) {
      return showEmptyLine(val);
    },
  },
  {
    title: '导入时间',
    dataIndex: 'createTime',
    width: 200,
    render(val: string) {
      return showEmptyLine(val);
    },
  },
  {
    title: '任务状态',
    dataIndex: 'taskStatus',
    width: 160,
    render(val: string) {
      return showEmptyLine(val);
    },
  },
];
