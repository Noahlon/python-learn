import React, { useState, useEffect } from 'react';
import { Modal } from 'antd';
import styles from './index.less';

interface IProps {
  open: boolean;
  data: any;
  closeFail: () => void;
}

const FailReason: React.FC<IProps> = ({ open, data, closeFail }) => {
  const [isModalOpen, setModalOpen] = useState<boolean>(false);
  useEffect(() => {
    setModalOpen(open);
  }, [open]);
  const handleOk = () => {

  };
  const handleCancel = () => {
    setModalOpen(false);
    closeFail();
  };
  return (
    <Modal title="查看失败原因"
      className={styles.failModal}
      footer={null}
      open={isModalOpen}
      // onOk={handleOk}
      onCancel={handleCancel}>
      <p className={styles.blue}>以下文件解析失败</p>
      <p>{data?.failVersion}</p>
    </Modal>
  )
}
export default FailReason;
