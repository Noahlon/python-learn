import React, { FC, useEffect } from 'react';
import { Form, Modal, Input } from 'antd';

const { TextArea } = Input;

export interface IKcForm {
  tenantName: string;
  name: string;
  guidName: string;
  guidDesc?: string;
  guid?: string;
}

export interface Info {
  tenant?: number;
  description?: string;
  guid?: string;
  name?: string;
  speechGuid?: string;
}

export interface Prop {
  type?: number;
  info?: Info;
  speechName?: string;
  tenant?: number;
  tenantName?: string;
  onOk?: (value: IKcForm) => void;
  onCancel?: () => void;
}

const KcList: FC<Prop> = ({
  type,
  onOk,
  onCancel,
  info,
  speechName,
  tenantName,
  tenant,
}) => {
  const [kcForm] = Form.useForm();
  const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };

  // 提交
  const handleOk = async () => {
    let param = await kcForm.validateFields();
    if (info) param = { guid: info.guid, ...param };
    onOk?.(param);
  };

  useEffect(() => {
    if (!type) {
      kcForm.setFieldsValue({
        name: '',
        guidDesc: '',
      });
    }
    if (info && type) {
      kcForm.setFieldsValue({
        name: info.name,
        guidDesc: info.description,
        guidName: speechName,
        tenantName: tenantName,
      });
    } else {
      kcForm.setFieldsValue({
        guidName: speechName,
        tenantName: tenantName,
      });
    }
  }, [type]);

  return (
    <>
      <Modal
        open={!!type}
        title={
          type === 2 ? '新增知识集合' : type === 1 ? '编辑知识集合' : '查看知识'
        }
        forceRender={true}
        width={'540px'}
        onOk={handleOk}
        onCancel={() => {
          kcForm.setFieldsValue({
            name: '',
            guidDesc: '',
          });
          onCancel?.();
        }}
        getContainer={false}
      >
        <Form form={kcForm} {...layout}>
          <Form.Item label="集合名称" name="name" rules={[{ required: true }]}>
            <Input maxLength={128} placeholder="请输入话术名称，限制128字" />
          </Form.Item>
          {![-18000, '-18000'].includes(tenant) && (
            <Form.Item
              label="所属名称"
              name="guidName"
              rules={[{ required: true }]}
            >
              <Input disabled={true} />
            </Form.Item>
          )}
          <Form.Item
            label="所属业务"
            name="tenantName"
            rules={[{ required: true }]}
          >
            <Input disabled={true} />
          </Form.Item>
          <Form.Item
            label="集合备注"
            name="guidDesc"
            rules={[{ required: true }]}
          >
            <TextArea
              rows={4}
              maxLength={255}
              placeholder="请输入，限制255字"
              showCount
            ></TextArea>
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};
export default KcList;
