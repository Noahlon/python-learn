import React, { FC, useEffect, useRef, useState } from 'react';
import {
  Button,
  Modal,
  Space,
  Form,
  Input,
  Upload,
  Popconfirm,
  message,
  Card,
  Select,
  Radio,
} from 'antd';
import {
  createKnowledge,
  editKnowledge,
  getIntentionLabelList,
  getKnowledgeById,
  transferCorpus,
  uploadCorpus,
  uploadMusic,
} from '@/api/language';
import { DownloadOutlined, PlusOutlined } from '@ant-design/icons';
import { useLocation } from '@umijs/max';
import { parse } from 'query-string';
import AudioPlayer from 'react-h5-audio-player';
import 'react-h5-audio-player/lib/styles.css';
import SelectLimit from '@/components/SelectLimit';
import { useModel } from '@umijs/max';
import { TurnOptions } from '@/pages/speech/config';

const { TextArea } = Input;

const layout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 },
};

interface IQuery {
  guid: string;
  tenantName: string;
  title: string;
}

interface IProps {
  modalType: number;
  curItem: any;
  curKl: any;
  onCancel: () => void;
  update: () => void;
}

const prettier = (text: string) => {
  if (text) {
    let reg =
      /^(https?:\/\/)([0-9a-z.]+)(:[0-9]+)?([/0-9a-z.]+)?(\?[0-9a-z&=]+)?(#[0-9-a-z]+)?/i;
    // eslint-disable-next-line no-param-reassign
    text = text.replace(reg, 'https://$2$3$4$5$6');
    return text;
  } else {
    return '';
  }
};

const EditModal: FC<IProps> = ({
  modalType,
  curItem,
  curKl,
  onCancel,
  update,
}) => {
  const [form] = Form.useForm();
  const location = useLocation();
  const {
    intentionClassifysList,
    getClassifysList,
    breakOptions,
    getBreakList,
  } = useModel('speech');
  const [disabled, setDisabled] = useState(false);
  const [loading, setLoading] = useState(false);
  const [intentionLabelList, setIntentionLabelList] = useState([]);

  const query = parse(location.search) as unknown as IQuery;
  const ref = useRef<any[]>([]);
  const refWrap = useRef<any[]>([]);

  const handlePlay = (e) => {
    console.log(e, ref, 'ref1');
    ref.current?.forEach((it) => {
      if (e.target !== it?.audio?.current) it?.audio?.current?.pause();
    });
  };

  const closeAudio = () => {
    ref.current?.forEach((it) => {
      it?.audio?.current?.pause();
    });
  };

  const handlerUpdate = () => {
    setLoading(true);
    form
      .validateFields()
      .then((val: any) => {
        if (val?.knowledgeReplyContentDTOList?.length === 0) {
          message.error('至少上传一个语料');
          return;
        }
        const param: any = {
          name: val?.name,
          kcGuid: curKl?.guid,
          intentionLabels: val.intentionLabels,
          intentionClassification: val.intentionClassification,
          knowledgeReplyContentDTOList: val?.knowledgeReplyContentDTOList?.map(
            (it, ind) => ({
              ...it,
              order: ind,
            }),
          ),
          hitRules: val?.knowledgeReplyContentDTOList?.map((it, ind) => ({
            knowledgeJumpType: it.knowledgeJumpType,
            breakType: it.breakType,
            order: ind + 1,
          })),
          speechId: query.guid,
          priority: val.priority,
        };
        const action = modalType === 2 ? createKnowledge : editKnowledge;
        if (modalType === 1) {
          param.faqId = curItem && curItem!.faqId;
        }
        action(param)
          .then((data: any) => {
            if (data?.success) {
              message.success('操作成功');
              update?.();
              onCancel();
            } else {
            }
          })
          .catch((e: any) => {
            console.log(e);
          });
      })
      .finally(() => {
        setLoading(false);
      });
  };

  // 获取知识详情
  const handlerGetDetail = async (faqId: string) => {
    const res = await getKnowledgeById(faqId);
    if (res.success) {
      let labels = [];
      if (
        Array.isArray(res.data.intentionLabels) &&
        res.data.intentionLabels.length
      ) {
        res.data.intentionLabels.forEach((item) => {
          labels.push(item.code);
        });
      }
      const krcList = [...res.data?.knowledgeReplyContentDTOList] || [];
      krcList.forEach((Item, index) => {
        Item.knowledgeJumpType =
          res.data?.hitRules?.[index]?.knowledgeJumpType || undefined;
        Item.breakType = res.data?.hitRules?.[index]?.breakType || 1;
      });
      form.setFieldsValue({
        name: res.data.name,
        intentionClassification:
          res.data.intentionClassification?.classification,
        intentionLabels: labels,
        knowledgeReplyContentDTOList: krcList,
        priority: res.data?.priority,
      });
    }
  };

  // 获取标签下拉
  const getLabelList = async () => {
    const res = await getIntentionLabelList({ pageSize: 200, pageNum: 1 });
    if (res) {
      const options = res?.map((item) => {
        return {
          value: item.code,
          label: item.desc,
        };
      });
      setIntentionLabelList(options);
    }
  };

  useEffect(() => {
    if (curItem) {
      handlerGetDetail(curItem.faqId);
    }
  }, [curItem]);

  useEffect(() => {
    if (!intentionClassifysList?.length) getClassifysList();
    if (!breakOptions?.length) getBreakList();
    getLabelList();
  }, []);

  // 下载
  // const handleDownLoad = (index: number) => {
  //   const fileUrl = form.getFieldValue('knowledgeReplyContentDTOList')[index]
  //     .corpusFileUri;
  //   console.log(fileUrl);

  //   let oReq = new XMLHttpRequest();
  //   oReq.open('GET', fileUrl, true);
  //   oReq.responseType = 'blob';
  //   oReq.withCredentials = true; //如果跨域
  //   oReq.onload = function () {
  //     let content = oReq.response;
  //     let elink = document.createElement('a');
  //     elink.download = '666.mp3';
  //     elink.referrerPolicy = 'no-referrer';
  //     elink.referrer = 'no-referrer';
  //     elink.style.display = 'none';
  //     let blob = new Blob([content]);
  //     elink.href = URL.createObjectURL(blob);
  //     document.body.appendChild(elink);
  //     elink.click();
  //     document.body.removeChild(elink);
  //   };
  //   oReq.send();

  //   // window.open(fileUrl)
  //   // window.open(fileUrl, '_blank', 'noopener=yes,noreferrer=yes');

  //   // let oReq = new XMLHttpRequest();
  //   // oReq.open("GET", fileUrl, true);
  //   // oReq.responseType = "blob";
  //   // oReq.withCredentials = true; //如果跨域
  //   // oReq.onload = function () {
  //   //   let content = oReq.response;
  //   //   let elink = document.createElement('a');
  //   //   elink.style.display = 'none';
  //   //   let blob = new Blob([content])
  //   //   elink.href = URL.createObjectURL(blob);;
  //   //   // elink.download = '666.mp3';
  //   //   document.body.appendChild(elink);
  //   //   elink.click();
  //   //   document.body.removeChild(elink);
  //   // };
  //   // oReq.send();

  //   // const a = document.createElement('a');
  //   // document.body.append(a);
  //   // a.style.display = 'none';
  //   // const ff = fileUrl.split
  //   // // 指示回复的内容该以何种形式展示(是以内联的形式（即网页或者页面的一部分），还是以附件的形式下载并保存到本地。)
  //   // a.href = fileUrl + '&response-content-disposition=' + encodeURIComponent('attachment; filename="' + fileName + '"');
  //   // a.download = fileName;
  //   // a.click();

  //   // // 多文件时remove放在setTimeout里面
  //   // setTimeout(() => {
  //   //     document.body.removeChild(a);
  //   // }, 300);
  // };

  const customRequest = async (index: number, { file }: any) => {
    const formData = new FormData();
    formData.append('file', file);
    const knowledgeReplyContentDTOList = form.getFieldValue(
      'knowledgeReplyContentDTOList',
    );

    console.log('file', knowledgeReplyContentDTOList);
    try {
      if (!knowledgeReplyContentDTOList[index].contentText) {
        form.validateFields();
        return;
      }
    } catch (e) {
      console.log(e);
    }
    const dest = message.loading('正在生成语料');
    try {
      setDisabled(true);
      const res = (await uploadMusic(formData)) as any;
      const resp = (await uploadCorpus({
        name: file.name,
        corpusFileUri: res?.url,
        contentText: knowledgeReplyContentDTOList[index].contentText,
      })) as any;

      if (resp.corpusFileKey) {
        message.success('分发成功');
        knowledgeReplyContentDTOList[index].corpusFileUri = resp?.corpusFileUri;
        knowledgeReplyContentDTOList[index].corpusFileKey = resp?.corpusFileKey;
        knowledgeReplyContentDTOList[index].corpusStatus = 1;

        console.log(knowledgeReplyContentDTOList, 'sightssights');
        form.setFieldsValue({
          knowledgeReplyContentDTOList: [...knowledgeReplyContentDTOList],
        });
      }
      console.log(
        form.getFieldValue('knowledgeReplyContentDTOList'),
        'sightssights',
        index,
      );
    } catch (e) {
      // 上传失败
    }
    dest?.();
    setDisabled(false);
  };

  // 语料合成
  const handleTransfer = async (index: number) => {
    const knowledgeReplyContentDTOList = form.getFieldValue(
      'knowledgeReplyContentDTOList',
    );

    try {
      if (!knowledgeReplyContentDTOList[index].contentText) {
        form.validateFields();
        return;
      }
    } catch (e) {
      console.log(e);
    }

    const dest = message.loading('正在生成语料');

    try {
      setDisabled(true);
      const res = (await transferCorpus({
        contentText: knowledgeReplyContentDTOList[index].contentText,
      })) as any;

      if (res.corpusFileKey) {
        message.success('操作成功');
        knowledgeReplyContentDTOList[index].corpusFileUri = res?.corpusFileUri;
        knowledgeReplyContentDTOList[index].corpusFileKey = res?.corpusFileKey;
        knowledgeReplyContentDTOList[index].corpusStatus = 1;

        form.setFieldsValue({
          knowledgeReplyContentDTOList: [...knowledgeReplyContentDTOList],
        });
      }
    } catch (error) {
    } finally {
      setDisabled(false);
    }
    dest?.();
  };

  return (
    <Modal
      title={
        modalType === 2 ? '新增知识' : modalType === 1 ? '编辑知识' : '查看知识'
      }
      open={!!modalType}
      footer={modalType === 0 ? null : undefined}
      onOk={handlerUpdate}
      okButtonProps={{
        disabled,
        loading,
      }}
      onCancel={() => {
        onCancel();
        form.resetFields();
      }}
      width={580}
      getContainer={false}
      afterClose={() => {
        form.resetFields();
        closeAudio();
      }}
    >
      <Form form={form} {...layout}>
        <Form.Item label="知识名称" name="name" rules={[{ required: true }]}>
          <Input maxLength={20} placeholder="请输入话术名称，限制20字" />
        </Form.Item>
        <Form.Item label="知识路径">
          <Input
            value={`${decodeURIComponent(query.tenantName)}${
              query.title ? '/' + decodeURIComponent(query.title) : ''
            }/${curKl?.name}`}
            disabled={true}
          />
        </Form.Item>
        <Form.Item label="意向分类" name="intentionClassification">
          <Select
            placeholder="请选择意向分类"
            allowClear
            getPopupContainer={(triggerNode) =>
              triggerNode.parentElement || document.body
            }
          >
            {intentionClassifysList?.map((item, index) => (
              <Select.Option
                key={`${item.classification}_${index}`}
                value={item.classification}
              >
                {item.desc}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item label="标签" name="intentionLabels">
          <SelectLimit
            options={intentionLabelList}
            max={10}
            text="请选择标签"
          />
        </Form.Item>
        <Form.Item
          label="优先级"
          name="priority"
          rules={[
            {
              required: true,
              pattern: /^([1-9]\d{0,3}|10000)$/,
              message: '请输入大于0小于10000的正整数',
            },
          ]}
        >
          <Input placeholder="请输入" />
        </Form.Item>
        <Form.Item label="知识内容">
          <div
            style={{
              maxHeight: '50vh',
              overflow: 'auto',
            }}
          >
            <Form.List
              name="knowledgeReplyContentDTOList"
              initialValue={[
                {
                  contentText: '',
                  corpusFileUri: '',
                  corpusFileKey: '',
                  corpusStatus: 0,
                  breakType: 1,
                },
              ]}
            >
              {(fields, { add, remove }) => (
                <>
                  {fields.map(({ key, ...field }, index) => (
                    <Card
                      style={{
                        marginBottom: 16,
                      }}
                      key={key}
                    >
                      <div>
                        <Form.Item
                          style={{ margin: 0 }}
                          label={`语料${index + 1}`}
                        />
                        <Space align="baseline">
                          <div
                            style={{
                              margin: '0 16px 16px 0',
                            }}
                          >
                            分发状态：
                            <Form.Item
                              noStyle
                              shouldUpdate={(prev, cur) =>
                                prev.knowledgeReplyContentDTOList !==
                                cur.knowledgeReplyContentDTOList
                              }
                            >
                              {({ getFieldValue }) => {
                                return getFieldValue(
                                  'knowledgeReplyContentDTOList',
                                )[index].corpusStatus === 1
                                  ? '已分发'
                                  : '未分发';
                              }}
                            </Form.Item>
                          </div>
                          <Button
                            type="primary"
                            disabled={disabled}
                            onClick={() => handleTransfer(index)}
                          >
                            生成音频
                          </Button>
                          <Upload
                            maxCount={1}
                            fileList={[]}
                            accept=".wav,.mp3"
                            customRequest={(...item) =>
                              customRequest(index, ...item) as any
                            }
                          >
                            <Button disabled={disabled}>上传音频</Button>
                          </Upload>
                          <Popconfirm
                            title="确定要删除吗？"
                            onConfirm={() => remove(field.name)}
                          >
                            <Button disabled={disabled} danger ghost>
                              删除
                            </Button>
                          </Popconfirm>
                        </Space>
                      </div>
                      <div
                        ref={(r) => {
                          if (index === 0) {
                            refWrap.current = [r];
                          } else {
                            refWrap.current.push(r);
                          }
                        }}
                      >
                        <Form.Item
                          {...field}
                          // label="Sight"
                          name={[field.name, 'contentText']}
                          rules={[
                            { required: true, message: '请填写语料内容' },
                          ]}
                        >
                          <TextArea
                            rows={4}
                            maxLength={200}
                            placeholder="请输入，限制200字"
                            showCount
                          ></TextArea>
                        </Form.Item>
                        <Form.Item
                          noStyle
                          shouldUpdate={(prev, cur) =>
                            prev.knowledgeReplyContentDTOList !==
                            cur.knowledgeReplyContentDTOList
                          }
                        >
                          {({ getFieldValue }) => {
                            return getFieldValue(
                              'knowledgeReplyContentDTOList',
                            )[index].corpusFileUri ? (
                              <Form.Item>
                                <Form.Item
                                  label="播放速度"
                                  style={{ marginBottom: '5px' }}
                                >
                                  <Radio.Group
                                    defaultValue={1}
                                    onChange={(e) => {
                                      const _audio =
                                        refWrap.current[index].querySelectorAll(
                                          'audio',
                                        );
                                      _audio[0].playbackRate = e.target.value;
                                    }}
                                  >
                                    <Radio value={0.5}>0.5</Radio>
                                    <Radio value={1}>1</Radio>
                                    <Radio value={1.5}>1.5</Radio>
                                    <Radio value={2}>2</Radio>
                                    <Radio value={2.5}>2.5</Radio>
                                  </Radio.Group>
                                </Form.Item>
                                <AudioPlayer
                                  ref={(r) => {
                                    if (index === 0) {
                                      ref.current = [r];
                                    } else {
                                      ref.current.push(r);
                                    }
                                  }}
                                  src={
                                    getFieldValue(
                                      'knowledgeReplyContentDTOList',
                                    )[index].corpusFileUri
                                  }
                                  header="当前语料文件"
                                  autoPlayAfterSrcChange={false}
                                  onPlay={(e) => handlePlay(e)}
                                  progressJumpStep={12 * 1000}
                                  customAdditionalControls={[]}
                                />
                                <div
                                  style={{
                                    marginTop: 12,
                                  }}
                                >
                                  <a
                                    rel="noreferrer"
                                    target="_blank"
                                    download="test.wav"
                                    // referrerPolicy="no-referrer"
                                    href={prettier(
                                      getFieldValue(
                                        'knowledgeReplyContentDTOList',
                                      )[index].corpusFileUri,
                                    )}
                                  >
                                    <DownloadOutlined /> 下载
                                  </a>
                                  {/* <Button
                                    type="link"
                                    onClick={() => handleDownLoad(index)}
                                  >
                                    <DownloadOutlined />
                                    下载
                                  </Button> */}
                                </div>
                              </Form.Item>
                            ) : null;
                          }}
                        </Form.Item>
                        <Form.Item
                          {...field}
                          label="跳转"
                          name={[field.name, 'knowledgeJumpType']}
                          rules={[{ required: true, message: '请选择' }]}
                        >
                          <Select
                            getPopupContainer={(triggerNode) =>
                              triggerNode.parentElement || document.body
                            }
                          >
                            {TurnOptions.map((item, index) => (
                              <Select.Option
                                key={`${item.value}_${index}`}
                                value={item.value}
                              >
                                {item.label}
                              </Select.Option>
                            ))}
                          </Select>
                        </Form.Item>

                        <Form.Item
                          {...field}
                          label="打断设置"
                          name={[field.name, 'breakType']}
                          // rules={[{ required: true, message: '请选择' }]}
                        >
                          <Select
                            getPopupContainer={(triggerNode) =>
                              triggerNode.parentElement || document.body
                            }
                          >
                            {breakOptions.map((item, index) => (
                              <Select.Option
                                key={`${item.type}_${index}`}
                                value={item.type}
                              >
                                {item.desc}
                              </Select.Option>
                            ))}
                          </Select>
                        </Form.Item>
                      </div>
                    </Card>
                  ))}

                  <Form.Item>
                    <Button
                      type="dashed"
                      onClick={() =>
                        add({
                          contentText: '',
                          corpusFileUri: '',
                          corpusFileKey: '',
                          corpusStatus: 0,
                          knowledgeJumpType: null,
                          breakType: 1,
                        })
                      }
                      block
                      icon={<PlusOutlined />}
                    >
                      添加语料
                    </Button>
                  </Form.Item>
                </>
              )}
            </Form.List>
          </div>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default EditModal;
