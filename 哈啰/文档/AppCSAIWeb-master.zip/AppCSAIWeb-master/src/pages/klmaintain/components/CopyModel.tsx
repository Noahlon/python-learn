import React, { useState, useEffect } from 'react';
import { Cascader, Form, Modal } from 'antd';
import { tenantList, getList, kcList } from '@/api/language';
import { getKnowleCollectList } from '@/api/speechFlow';

export interface options {
  value?: number;
  label?: string;
  children?: options[];
  isLeaf?: boolean;
  loading?: boolean;
}

const CopyModal: React.FC<any> = ({
  visible,
  destroy = false,
  onOk,
  cancel,
  curItem,
}) => {
  const [tenantData, setTenantData] = useState<options[]>([]);
  const [form] = Form.useForm();
  const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };

  // 获取数据
  const getOptionData = async (selectedOptions) => {
    const targetOption = selectedOptions[selectedOptions.length - 1];
    if (targetOption.children) {
      return;
    }
    let list = null;
    if (selectedOptions.length === 1) {
      targetOption.loading = true;
      if (targetOption.value === -18000) {
        const param: any = {
          tenants: [targetOption.value],
          pageNum: 1,
          pageSize: 999,
        };
        const data = await kcList(param);
        list = data?.list || [];
      } else {
        const res = await getList({
          pageSize: 999,
          pageNum: 1,
          tenant: targetOption.value,
        });
        list = res?.list || [];
      }
    }
    if (selectedOptions.length === 2) {
      targetOption.loading = true;
      list = await getKnowleCollectList({
        pageSize: 999,
        pageNum: 1,
        speechGuid: targetOption.value,
      });
    }
    if (Array.isArray(list) && list.length) {
      targetOption.children = list.map((item) => {
        if (selectedOptions.length === 1) {
          if (targetOption.value === -18000) {
            return {
              label:
                item.name?.length > 10
                  ? item.name.substr(0, 10) + '...'
                  : item.name,
              value: item.guid,
            };
          } else {
            return {
              label:
                item.speechName?.length > 10
                  ? item.speechName.substr(0, 10) + '...'
                  : item.speechName,
              value: item.guid,
              isLeaf: false,
            };
          }
        }
        return {
          label:
            item.name?.length > 10
              ? item.name.substr(0, 10) + '...'
              : item.name,
          value: item.guid,
        };
      });
      targetOption.loading = false;
      setTenantData([...tenantData]);
    }
  };

  // 获取业务线列表
  const handleGetTenantList = async () => {
    const data = await tenantList({ pageNum: 1, pageSize: 999 });
    if (data && data.length) {
      const bizList: options[] = data.map((item) => {
        return {
          value: item.tenant,
          label: item.desc,
          isLeaf: false,
        };
      });
      setTenantData(bizList);
    }
  };

  useEffect(() => {
    handleGetTenantList();
  }, []);

  useEffect(() => {
    form.setFieldsValue({
      idList: null,
    });
  }, [visible]);

  // 确认提交
  const handleIsOk = async () => {
    const res = await form.validateFields();
    const params = {
      name: curItem?.name,
      knowledgeReplyContentDTOList: curItem?.knowledgeReplyContentDTOList,
      hitRules: curItem?.hitRules,
      intentionClassification: curItem?.intentionClassification
        ? curItem?.intentionClassification.classification
        : undefined,
      intentionLabels: curItem?.intentionLabels
        ? curItem?.intentionLabels.map((item) => item.code)
        : undefined,
      kcGuid:
        res?.idList[0] === -18000
          ? res?.idList[1]
          : res?.idList[2] || undefined,
      isCopy: true,
      copiedFaqId: curItem.faqId,
    };
    onOk?.(params);
  };

  return (
    <>
      <Modal
        title="复制知识"
        destroyOnClose={destroy}
        open={visible}
        width={'540px'}
        onOk={handleIsOk}
        onCancel={() => cancel()}
        getContainer={false}
      >
        <Form form={form} {...layout}>
          <Form.Item label="请选择" name="idList" rules={[{ required: true }]}>
            <Cascader
              options={tenantData}
              loadData={getOptionData}
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
            />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};

export default CopyModal;
