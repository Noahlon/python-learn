import React, { useState, useEffect } from 'react';
import { Modal, Button, Input, Table, Tooltip, message } from 'antd';
import style from './style.less';
import {
  addPhrase,
  deletePhrase,
  IPhrase,
  LANGUAGEs,
  queryPhrase,
} from '@/api/language';
import { ModalDrag } from '@/components/Dragm';
// import DraggableModal from '../Draggable';

interface IProps {
  visible?: boolean;
  curItem?: LANGUAGEs;
  onOk?: () => void;
  cancel?: () => void;
}
const PhraseModal: React.FC<IProps> = ({ visible, curItem, cancel }) => {
  const [phraseText, setPhraseText] = useState('');
  const [total, setTotal] = useState(0);
  const [phraseList, setPhraseList] = useState<IPhrase[]>();

  // 查询
  const getPhraseList = async () => {
    const res = await queryPhrase({ faqId: curItem.faqId });
    if (res?.success) {
      setPhraseList(res.data);
      setTotal(res.data.length || 0);
    }
  };

  useEffect(() => {
    if (visible) {
      getPhraseList();
    }
  }, [visible]);

  // 新增
  const createPhrase = async () => {
    if (!phraseText) {
      return message.warning('请填写内容');
    }

    // if (phraseText.length > 2501) {
    //   return message.warning('字数超过2500');
    // }
    const res = await addPhrase({
      phrase: phraseText,
      faqId: curItem.faqId,
    });
    if (res?.success) {
      getPhraseList();
      setPhraseText('');
    }
  };

  // 删除
  const handleDeletePhrese = async (record: IPhrase) => {
    const { id } = record;
    const res = await deletePhrase({ id });
    if (res.success) {
      message.success('删除成功');
      getPhraseList();
    }
  };

  const handleCancel = () => {
    cancel?.();
  };

  const handlePhraseText = (e: {
    target: { value: React.SetStateAction<string> };
  }) => {
    setPhraseText(e.target.value);
  };

  const columns = [
    {
      title: '核心短语',
      dataIndex: 'phrase',
      ellipsis: {
        showTitle: false,
      },
      render(text: string) {
        return (
          <Tooltip placement="topLeft" title={text}>
            {text}
          </Tooltip>
        );
      },
    },
    {
      title: '操作',
      key: 'action',
      width: 60,
      render: function Action(text: any, record: IPhrase) {
        return (
          // <Popconfirm
          //   title="你确定要删除吗?"
          //   onConfirm={() => handleDeletePhrese(record)}
          //   okText="确定"
          //   cancelText="取消"
          // >
          //   <span style={{ color: '#FF4D4F', cursor: 'pointer' }}>删除</span>
          // </Popconfirm>
          <span
            style={{ color: '#FF4D4F', cursor: 'pointer' }}
            onClick={() => handleDeletePhrese(record)}
          >
            删除
          </span>
        );
      },
    },
  ];

  return (
    <>
      <Modal
        title={<ModalDrag>核心短语</ModalDrag>}
        className="custom-draggable-modal"
        open={visible}
        onCancel={handleCancel}
        footer={false}
        destroyOnClose={true}
        width={600}
      >
        <div className={style.input}>
          <div style={{ minWidth: 'fit-content' }}>核心短语:</div>
          <Input
            style={{ margin: '0 5px' }}
            placeholder="请输入"
            value={phraseText}
            onChange={handlePhraseText}
            onPressEnter={createPhrase}
            showCount
          />
          <Button onClick={createPhrase}>添加</Button>
        </div>
        <div className={style.tip}>短语之间可用逗号相隔</div>
        <ModalDrag>
          <Table
            rowKey={(record) => record.guid}
            columns={columns}
            dataSource={phraseList}
            // rowSelection={rowSelection}
            pagination={{
              pageSize: 100,
              // simple: true,
              total: total,
              showSizeChanger: false,
              showTotal: (total) => `${total} 条数据`,
            }}
          />
        </ModalDrag>
      </Modal>
    </>
  );
};

export default PhraseModal;
