import React, { useEffect, useState } from 'react';
import { history } from '@umijs/max';
import {
  Button,
  Space,
  Table,
  Typography,
  Popconfirm,
  message,
  Tag,
  Pagination,
  // message,
} from 'antd';
import { parse } from 'query-string';
import { EditOutlined, DeleteOutlined } from '@ant-design/icons';
import {
  LANGUAGEs,
  getKnowledgeList,
  deleteK,
  kcList,
  createKc,
  editKc,
  deleteKc,
  createKnowledge,
} from '@/api/language';
import SimilarQManage from '@/components/similarQManage';
import moment from 'moment';
import styles from '@/pages/kbmanage/index.less';
import EditModal from './components/editModal';
import CopyModal from './components/CopyModel';
import AddKcModal from './components/AddKcModal';
import PhraseModal from './components/PhraseModal';

const KLMaintain: React.FC<{ match: Math; location: any }> = () => {
  const query = parse(location.search) as any;
  const [tableData, setTableData] = useState<any[]>([]);
  const [isLoading, setLoading] = useState<boolean>(false);
  const [total, setTotal] = useState<number>(0);
  const [standardFaqGuid, setStandardFaqGuid] = useState<string>('');
  const [pageIndex, setPageIndex] = useState<number>(1);
  const [pageSize, setPageSize] = useState(200);
  const [similarVisible, setSimilarVisible] = useState<boolean>(false);
  const [phraseVisible, setPhraseVisible] = useState<boolean>(false);

  // 知识集合
  const [klList, setKlList] = useState([]);
  const [curKcInfo, setCurKcInfo] = useState(undefined);
  const [klId, setKlId] = useState('');
  const [curKl, setCurKl] = useState();
  const [modalKlType, setModalKlType] = useState<number>(0);
  // 0关闭 1编辑 2新增 3查看
  const [modalType, setModalType] = useState<number>(0);
  // 复制
  const [showCopyModel, setShowCopyModel] = useState(false);
  const [curItem, setCurItem] = useState<number>(0);
  const [tableHeight, setTableHeight] = useState<string | number>('auto');
  const [curInfo, setCurInfo] = useState(null);
  const handlerGetDetail = async (record: any, type: number) => {
    setCurItem(record);
    setModalType(type);
  };

  // 复制
  const handlerCopy = async (record: any) => {
    setCurInfo(record);
    setShowCopyModel(true);
  };

  // 获取高度变化
  const handleHeightEvent = () => {
    const ele = document.getElementById('klTableWrap');
    setTableHeight((ele?.clientHeight || 300) - 55);
  };

  const handlerGetLists = async (params: any) => {
    if (!klId) return;
    setLoading(true);
    const param: any = {
      kcGuid: klId,
      pageNum: params.pageNum || pageIndex,
      pageSize: params.pageSize || pageSize,
    };
    const data = (await getKnowledgeList(param)) as any;
    if (data) {
      if (data.list && data.list?.length) {
        setTableData(data?.list);
        setTotal(Number(data?.totalRecord) || 0);
        setTimeout(() => {
          handleHeightEvent();
        }, 0);
      } else {
        setTableData([]);
      }
    } else {
      setTableData([]);
    }
    setLoading(false);
  };

  // 知识集合列表
  const getKcList = async (isFirst = false) => {
    const res = await kcList({
      tenants: query?.tenant === '-18000' ? [query?.tenant] : undefined,
      speechGuid: query?.tenant === '-18000' ? undefined : query?.guid,
      pageNum: 1,
      pageSize: 999,
    });
    if (res && res!.list?.length) {
      setKlList(res.list);
      if (isFirst && query?.kcId) {
        setKlId(query?.kcId);
        const kcInfo = res.list.find((item) => item.guid === query?.kcId);
        setCurKl(kcInfo);
      } else {
        setKlId(res.list[0]?.guid);
        setCurKl(res.list[0]);
      }
    } else {
      setKlList([]);
    }
  };
  const handleVisible = (id: string) => {
    console.log(id);
    setStandardFaqGuid(id);
    setSimilarVisible(true);
  };
  const handleChangeVisible = () => {
    setSimilarVisible(false);
  };

  // 短语
  const handlePhraseVisible = (record) => {
    setCurInfo(record);
    setPhraseVisible(true);
  };

  const onChange = (page: number | undefined, size: number | undefined) => {
    const params = { pageSize: size, pageNum: 1 };
    if (size !== pageSize) {
      setPageIndex(1);
      setPageSize(size);
    } else {
      setPageIndex(page);
      params.pageNum = page;
    }
    handlerGetLists(params);
  };

  const onCancel = () => {
    setModalType(0);
    setCurItem(undefined);
  };

  const getListUpdate = () => {
    setPageIndex(1);
    handlerGetLists({
      pageNum: 1,
    });
  };

  const handlerDelete = async (guid: string) => {
    const data = await deleteK({ faqId: guid });
    if (data?.success) {
      message.success('删除成功');
      setPageIndex(1);
      handlerGetLists({
        pageNum: 1,
      });
    }
  };

  const handleClickKl = (item) => {
    history?.replace({
      pathname: '/language/klmaintain',
      search: `?guid=${query?.guid}&tenant=${query?.tenant}&tenantName=${
        query?.tenantName
      }${query?.title ? `&title=${query.title}` : ``}&kcId=${item.guid}`,
    });
    setPageIndex(1);
    setKlId(item.guid);
    setCurKl(item);
  };

  const handlerKlOk = (val) => {
    const typeList = ['-18000', -18000];
    const params = {
      tenant: typeList.includes(query?.tenant) ? -18000 : query?.tenant,
      name: val?.name,
      speechGuid: typeList.includes(query?.tenant) ? undefined : query?.guid,
      speechName: typeList.includes(query?.tenant) ? undefined : query?.title,
      description: val?.guidDesc,
      guid: modalKlType === 1 ? val.guid : undefined,
    };
    const action = modalKlType === 2 ? createKc : editKc;
    action(params)
      .then((data: any) => {
        if (data?.success) {
          message.success('操作成功');
          getKcList();
          setModalKlType(0);
          setCurKcInfo(undefined);
        } else {
        }
      })
      .catch((e: any) => {
        console.log(e);
      });
  };

  const handleEditKl = (item) => {
    setCurKcInfo(item);
    setModalKlType(1);
  };

  // 删除知识集合
  const handleDelete = async (e) => {
    const res = await deleteKc({ guid: e.guid });
    if (res?.success) {
      message.success('删除成功');
      getKcList();
    }
  };

  const getTag = (status: number) => {
    switch (status) {
      case 0:
        return <Tag color="red">未分发</Tag>;
      case 1:
        return <Tag color="volcano">部分分发</Tag>;
      case 2:
        return <Tag color="green">全部分发</Tag>;
      default:
        return;
    }
  };

  // 确认复制
  const handleCopyKl = async (params) => {
    const res = await createKnowledge(params);
    if (res?.success) {
      message.success('复制成功');
      setCurInfo(null);
      setShowCopyModel(false);
    }
  };

  const column = [
    {
      title: '知识名称',
      fixed: 'left',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '优先级',
      dataIndex: 'priority',
      key: 'priority',
    },
    {
      title: '业务线',
      dataIndex: '',
      key: '',
      render: () => {
        return <div>{decodeURIComponent(query.tenantName)}</div>;
      },
    },
    {
      title: '语料数',
      dataIndex: 'replyNum',
      key: 'replyNum',
    },
    {
      title: '意向分类',
      dataIndex: 'intentionClassification',
      key: 'intentionClassification',
      render: (item) => item?.desc || '-',
    },
    {
      title: '标签',
      dataIndex: 'intentionLabels',
      key: 'intentionLabels',
      width: '20%',
      ellipsis: true,
      render: (item) => {
        if (item) {
          return (
            <div className={styles.labelWrap}>
              {item.map((item) => (
                <span key={item.desc} className={styles.labelItem}>
                  {item.desc}
                </span>
              ))}
            </div>
          );
        }
        return '-';
      },
    },
    {
      title: '更新者',
      dataIndex: 'author',
      key: 'author',
    },
    {
      title: '语料分发状态',
      dataIndex: 'corpusStatus',
      key: 'corpusStatus',
      // width: '10%',
      render: (text: string) => getTag(+text),
    },
    {
      title: '最近更新时间',
      dataIndex: 'updateTime',
      key: 'updateTime',
      // width: '10%',
      render: (text: string) => moment(text).format('YYYY.MM.DD HH:mm:ss'),
    },
    {
      title: '操作',
      dataIndex: 'guid',
      key: 'guid',
      fixed: 'right',
      width: '20%',
      render: function operation(text: string, record: LANGUAGEs) {
        return (
          <Space direction="horizontal">
            {
              <Typography.Link onClick={() => handlerGetDetail(record, 1)}>
                编辑
              </Typography.Link>
            }
            {
              <Typography.Link
                onClick={() => {
                  // eslint-disable-next-line @typescript-eslint/no-use-before-define
                  handleVisible(record?.faqId);
                }}
              >
                相似问法
              </Typography.Link>
            }
            {
              <Typography.Link
                onClick={() => {
                  handlePhraseVisible(record);
                }}
              >
                核心短语
              </Typography.Link>
            }
            {
              <Popconfirm
                title="是否确认删除该知识？"
                // eslint-disable-next-line @typescript-eslint/no-use-before-define
                onConfirm={() => handlerDelete(record?.faqId)}
              >
                <Typography.Link>删除</Typography.Link>
              </Popconfirm>
            }
            {
              <Typography.Link onClick={() => handlerCopy(record)}>
                复制
              </Typography.Link>
            }
          </Space>
        );
      },
    },
  ];

  useEffect(() => {
    setPageIndex(1);
    handlerGetLists({
      pageNum: 1,
    });
  }, [klId]);

  useEffect(() => {
    getKcList(true);
  }, []);
  return (
    <>
      <div className={styles.klContent}>
        <div className={styles.klLeft}>
          <div className={styles.createKl}>
            <Button
              type="primary"
              block
              onClick={() => {
                setModalKlType(2);
              }}
            >
              新建知识集合
            </Button>
          </div>
          <div className={styles.klList}>
            {klList.map((e: any, index) => {
              return (
                <div key={index} className={styles.itemKl}>
                  <div
                    onClick={() => handleClickKl(e)}
                    className={[
                      styles.itemKlName,
                      e.guid === klId ? styles.itemKlActive : '',
                    ].join(' ')}
                  >
                    {e.name}
                  </div>
                  <div>
                    <EditOutlined
                      style={{ marginRight: 8 }}
                      onClick={() => handleEditKl(e)}
                    />
                    <Popconfirm
                      title="是否确认删除该知识集合？"
                      // eslint-disable-next-line @typescript-eslint/no-use-before-define
                      onConfirm={() => handleDelete(e)}
                    >
                      <DeleteOutlined />
                    </Popconfirm>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        {klList && klList?.length ? (
          <div className={styles.klRight}>
            <div className={styles.header}>
              <span className={styles.title}>知识维护</span>
              <Button
                type="primary"
                className={styles.btn}
                onClick={() => {
                  setModalType(2);
                  setCurItem(undefined);
                }}
              >
                新建知识
              </Button>
            </div>
            <div className={styles.tableContent} id="klTableWrap">
              <Table
                columns={column}
                dataSource={tableData}
                loading={isLoading}
                rowKey={(record) => record.faqId}
                scroll={{ y: tableHeight, x: 1600 }}
                pagination={false}
              ></Table>
            </div>
            <div className={styles.subPagination}>
              <Pagination
                current={pageIndex}
                showSizeChanger={true}
                pageSize={pageSize}
                total={total}
                showTotal={(total) => `总共 ${total} 条`}
                onChange={onChange}
              />
            </div>
          </div>
        ) : (
          ''
        )}
      </div>
      <SimilarQManage
        similarVisible={similarVisible}
        onChange={handleChangeVisible}
        standardFaqGuid={standardFaqGuid}
      />

      <PhraseModal
        visible={phraseVisible}
        curItem={curInfo}
        onOk={() => {
          setPhraseVisible(false);
          setCurInfo(null);
        }}
        cancel={() => {
          setPhraseVisible(false);
          setCurInfo(null);
        }}
      />

      <EditModal
        curItem={curItem}
        curKl={curKl}
        modalType={modalType}
        onCancel={onCancel}
        update={getListUpdate}
      />

      <CopyModal
        visible={showCopyModel}
        curItem={curInfo}
        onOk={handleCopyKl}
        cancel={() => setShowCopyModel(false)}
      />

      <AddKcModal
        tenantName={query?.tenantName}
        tenant={query?.tenant}
        speechName={query?.title}
        type={modalKlType}
        info={curKcInfo}
        onOk={handlerKlOk}
        onCancel={() => {
          setCurKcInfo(undefined);
          setModalKlType(0);
        }}
      />
    </>
  );
};

export default KLMaintain;
