import {
  getNewIntentionList,
  getNewIntentionListById,
  IntentionCollectInfo,
  intentionDownload,
  IntentionInfo,
  intentionUpload,
} from '@/api/intention';
import { deleteK } from '@/api/language';
import FileUploadShowList from '@/components/FileUploadShowList';
import { httpReplace } from '@/utils';
import {
  ExclamationCircleOutlined,
  InboxOutlined,
  VerticalAlignBottomOutlined,
} from '@ant-design/icons';
import { useAccess } from '@umijs/max';
import {
  Button,
  Empty,
  Form,
  Input,
  message,
  Modal,
  Select,
  Space,
  Tabs,
  Table,
  Tag,
} from 'antd';
import React, { FC, useEffect, useRef, useState } from 'react';
import EditIntention from '../EditIntention';
import PhraseList from '../PhraseList';
import SimilarityList from '../SimilarityList';
import KernelList from '../KernelList';
import Regex from '../Regex';
import styles from './index.less';

const { confirm } = Modal;

interface Prop {
  selectIC?: IntentionCollectInfo;
  onChange?: () => void;
}

const selectTypeOptions = [
  { label: '意图', value: 0 },
  { label: '核心句', value: 3 },
  { label: '正则', value: 4 },
  { label: '短语', value: 2 },
  { label: '相似问', value: 1 },
];

const tabsPane = [
  { label: '核心句', key: 'coreSentence' },
  { label: '正则', key: 'regex' },
  { label: '短语', key: 'phrase' },
  { label: '相似问', key: 'similarity' },
];

const IntentionList: FC<Prop> = ({ selectIC, onChange }) => {
  const access = useAccess();
  const [form] = Form.useForm();
  const ref = useRef();
  const searchText = Form.useWatch('content', form);
  const searchType = Form.useWatch('type', form);
  const [intentionList, setIntentionList] = useState<IntentionInfo[]>([]);
  const [selectIntention, setSelectIntention] = useState<IntentionInfo>();
  const [loading, setLoading] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [tabKey, setTabKey] = useState('coreSentence');
  // 1--新增 2--编辑  3--复制 4--查看
  const [type, setType] = useState(undefined);
  const [curInfo, setCurInfo] = useState(undefined);
  const [showImportModal, setShowImportModal] = useState(false);
  const [fileUploadFailUrl, setFileUploadFailUrl] = useState('');
  const [fileList, setFileList] = useState([]);

  // 获取数据列表
  const handlerGetLists = async (typeApi?: boolean) => {
    if (!selectIC?.guid) return;
    setLoading(true);
    let formData = await form.validateFields();
    let param: any = { kcGuid: selectIC?.guid };
    if (
      !typeApi &&
      selectTypeOptions.map((it) => it.value)?.includes(formData?.type)
    )
      param = { kcGuid: selectIC?.guid, ...formData };
    if (!selectTypeOptions.map((it) => it.value)?.includes(formData?.type)) {
      form.resetFields();
    }
    const api = typeApi ? getNewIntentionListById : getNewIntentionList;
    const res = await api(param);
    if (res.success && res.data?.length) {
      setIntentionList(res.data);
      setSelectIntention(res.data[0]);
    } else {
      setIntentionList([]);
      setSelectIntention(undefined);
    }
    setLoading(false);
  };

  // 编辑提交
  const handleEditOk = async () => {
    form.resetFields();

    if (type === 1) {
      onChange?.();
    }
    setType(0);
    setCurInfo(undefined);
    handlerGetLists();
  };

  // 删除
  const handleDeleteIntention = (info: IntentionInfo) => {
    confirm({
      title: '删除意图',
      icon: <ExclamationCircleOutlined />,
      content: '同时删除该意图下的相似问及核心短语',
      onOk() {
        return new Promise((resolve, reject) => {
          deleteK({ faqId: info.faqId }).then((res) => {
            if (res?.success) {
              message.success('删除成功');
              handlerGetLists();
              onChange?.();
              resolve(true);
            } else {
              reject(false);
            }
          });
        });
      },
      onCancel() {},
    });
  };

  // tab切换
  const handleTabChange = (key: string) => {
    setTabKey(key);
  };

  // 导出
  const handleExport = async () => {
    confirm({
      title: '批量导出',
      icon: <ExclamationCircleOutlined />,
      content: '导出列表意图及其相似问',
      onOk() {
        // return new Promise((resolve, reject) => {
        //   deleteK({ faqId: info.faqId }).then((res) => {
        //     if (res?.success) {
        //       message.success('删除成功');
        //       handlerGetLists();
        //       resolve(true);
        //     } else {
        //       reject(false);
        //     }
        //   });
        // });
        if (!selectIC?.guid) return message.warning('请选择意向');
        const dest = message.loading('正在导出');
        intentionDownload({ kcGuid: selectIC?.guid }).then((res) => {
          if (res.success && res.data) {
            let elink = document.createElement('a');
            elink.style.display = 'none';
            let newUrl = httpReplace(res?.data as unknown as string);
            elink.href = newUrl;
            elink.download = '批量导出';
            document.body.appendChild(elink);
            elink.click();
            setTimeout(() => {
              document.body.removeChild(elink);
            }, 300);
          }
          dest?.();
        });
      },
      onCancel() {},
    });

    // if (!selectIC?.guid) return message.warning('请选择意向');
    // confirm({
    //   title: '批量导出',
    //   icon: <ExclamationCircleOutlined />,
    //   content:
    //     tabKey === 'similarity'
    //       ? '导出列表意图及其相似问？'
    //       : '导出列表意图及其短语？',
    //   onOk() {
    //     return new Promise((resolve) => {
    //       setTimeout(() => {
    //         message.success('操作成功');
    //         resolve(true);
    //       }, 1000);
    //     });
    //   },
    //   onCancel() {},
    // });
  };

  const renderPropertyType = (record) => {
    switch (record.propertyType) {
      case 1:
        return <Tag color="green">{record.propertyName}</Tag>;
      case 2:
        return <Tag color="red">{record.propertyName}</Tag>;
      case 3:
        return <Tag color="orange">{record.propertyName}</Tag>;
      case 4:
        return <Tag>{record.propertyName}</Tag>;
      default:
        return '-';
    }
  };

  // 导入
  const handleImport = () => {
    setShowImportModal(true);
  };

  const columns = [
    {
      title: '意图名称',
      dataIndex: 'name',
      key: 'name',
      render: (_, record) => {
        return (
          <div
            onClick={() => {
              setSelectIntention(record);
            }}
            className={[
              styles.intentionItemName,
              record.faqId === selectIntention?.faqId
                ? styles.intentionItemActive
                : '',
            ].join(' ')}
          >
            {record.name}
          </div>
        );
      },
    },
    {
      title: '属性',
      dataIndex: 'propertyType',
      key: 'propertyType',
      width: 60,
      render: (_, record) => renderPropertyType(record),
    },
    {
      title: '操作',
      dataIndex: 'op',
      key: 'op',
      width: 80,
      render: (op, record) => {
        return access?.authCodeList?.includes('Call-Limit-Blacklist-Edit') ? (
          <>
            {access?.authCodeList?.includes('Call-Intention-Save-Edit') && (
              <span
                className={styles.intentionBtn}
                onClick={() => {
                  setType(2);
                  setCurInfo(record);
                }}
              >
                编辑
              </span>
            )}
            {access?.authCodeList?.includes('Call-Intention-Save-Delete') &&
              record.showDeleteButton !== 0 && (
                <span
                  className={styles.intentionBtn}
                  onClick={() => handleDeleteIntention(record)}
                >
                  删除
                </span>
              )}
          </>
        ) : (
          ''
        );
      },
    },
  ];

  // 导入取消
  const handleImportCancel = () => {
    setShowImportModal(false);
    if (ref.current) {
      ref.current?.clearData();
    }
    setFileUploadFailUrl('');
    setFileList([]);
  };

  // 导入提交
  const handleImportOk = async () => {
    const list = fileList?.filter((item) => item.status === 'done');
    if (!list?.length) return message.error('请先上传文件');
    setConfirmLoading(true);
    const dest = message.loading('正在导入');
    const res = await intentionUpload({
      kcGuid: selectIC?.guid,
      ossUrl: list[0].url,
    });
    if (res.success && res.data) {
      onChange?.();
      if (res?.data?.success) {
        handleImportCancel();
      } else if (res?.data?.ossUrl) {
        setFileUploadFailUrl(httpReplace(res?.data?.ossUrl));
      }
      handlerGetLists();
    }
    dest?.();
    setConfirmLoading(false);
  };

  useEffect(() => {
    form.setFieldsValue({ type: 2, content: '' });
    // form.resetFields();
    handlerGetLists(true);
    setIntentionList([]);
    setCurInfo(undefined);
    // setSelectIntention(undefined);
  }, [selectIC]);

  return (
    <>
      <div className={styles.intentionWrap}>
        <div className={styles.top}>
          <Form form={form} layout="inline">
            <Form.Item name="type">
              <Select
                options={selectTypeOptions}
                placeholder="请选择"
                style={{ width: '100px' }}
                allowClear
              />
            </Form.Item>
            <Form.Item name="content">
              <Input placeholder="请输入" maxLength={50} allowClear />
            </Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              onClick={() => handlerGetLists(false)}
            >
              搜索
            </Button>
          </Form>
          <Space>
            {access?.authCodeList?.includes('Call-Intention-Save-Add') && (
              <Button
                type="primary"
                onClick={() => {
                  setType(1);
                }}
              >
                新建意图
              </Button>
            )}
            {access?.authCodeList?.includes(
              'Call-Intention-Save-BatchImport',
            ) && (
              <Button type="primary" onClick={handleImport}>
                批量导入
              </Button>
            )}
            {access?.authCodeList?.includes(
              'Call-Intention-Save-BatchExport',
            ) && (
              <Button
                icon={<VerticalAlignBottomOutlined />}
                onClick={handleExport}
              >
                批量导出
              </Button>
            )}
          </Space>
        </div>
        <div className={styles.content}>
          <div className={styles.intentionLeft}>
            <div className={styles.intentionLeftListWrap}>
              <div className={styles.intentionLeftListCount}>
                意图{intentionList?.length || 0}个
              </div>
              {/* <Spin spinning={loading} style={{ minHeight: '30px' }}>
                {!!intentionList?.length ? (
                  intentionList.map((item, index) => (
                    <div key={index} className={styles.intentionItem}>
                      <div
                        onClick={() => setSelectIntention(item)}
                        className={[
                          styles.intentionItemName,
                          item.faqId === selectIntention?.faqId
                            ? styles.intentionItemActive
                            : '',
                        ].join(' ')}
                      >
                        {item.name}
                      </div>
                      <div>
                        {access?.authCodeList?.includes(
                          'Call-Intention-Save-Edit',
                        ) && (
                          <EditOutlined
                            style={{ marginRight: 8 }}
                            onClick={() => {
                              setType(2);
                              setCurInfo(item);
                            }}
                          />
                        )}
                        {access?.authCodeList?.includes(
                          'Call-Intention-Save-Delete',
                        ) &&
                          item.showDeleteButton !== 0 && (
                            <DeleteOutlined
                              onClick={() => handleDeleteIntention(item)}
                            />
                          )}
                      </div>
                    </div>
                  ))
                ) : (
                  <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                )}
              </Spin> */}
              <Table
                size="middle"
                columns={columns}
                dataSource={intentionList}
                rowKey={(record) => record.faqId}
                pagination={false}
                loading={loading}
              />
            </div>
          </div>
          <div className={styles.intentionRight}>
            {!!selectIntention ? (
              <Tabs
                // defaultActiveKey="1"
                activeKey={tabKey}
                size="large"
                className={styles.content}
                destroyInactiveTabPane
                items={tabsPane.map((item) => {
                  return {
                    label: (
                      <div style={{ padding: '0 20px' }}>{item.label}</div>
                    ),
                    key: `${item.key}`,
                    children: (
                      <>
                        {item.key === 'coreSentence' && (
                          <KernelList
                            intention={selectIntention}
                            searchText={searchText}
                            searchType={searchType}
                            kcGuid={selectIC?.guid}
                          />
                        )}
                        {item.key === 'regex' && (
                          <Regex
                            intention={selectIntention}
                            searchText={searchText}
                            searchType={searchType}
                            kcGuid={selectIC?.guid}
                          />
                        )}
                        {item.key === 'similarity' && (
                          <SimilarityList
                            intention={selectIntention}
                            searchText={searchText}
                            searchType={searchType}
                            kcGuid={selectIC?.guid}
                          />
                        )}
                        {item.key === 'phrase' && (
                          <PhraseList
                            intention={selectIntention}
                            searchText={searchText}
                            searchType={searchType}
                            kcGuid={selectIC?.guid}
                          />
                        )}
                      </>
                    ),
                  };
                })}
                onTabClick={handleTabChange}
              />
            ) : (
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
            )}
          </div>
        </div>
      </div>

      <EditIntention
        type={type}
        info={curInfo}
        selectICID={selectIC?.guid}
        onCancel={() => {
          setType(0);
          setCurInfo(undefined);
        }}
        onOk={handleEditOk}
      />

      <Modal
        open={showImportModal}
        title="批量导入"
        forceRender={true}
        width={'540px'}
        onOk={handleImportOk}
        onCancel={handleImportCancel}
        confirmLoading={confirmLoading}
        getContainer={false}
        destroyOnClose={true}
      >
        <FileUploadShowList
          ref={ref}
          showUploadList={true}
          uploadType=".csv,.xlsx,.xls"
          onChange={(list) => setFileList(list)}
        >
          <div className={styles.uploadIcon}>
            <InboxOutlined />
          </div>
          <div className={styles.notice}>点击或将文件拖拽到这里上传</div>
          <div className={styles.uploadType}>
            支持扩展名：.csv&nbsp;&nbsp;.xlsx
          </div>
        </FileUploadShowList>
        <div style={{ textAlign: 'right' }}>
          <Button
            type="link"
            size="small"
            href="https://easybike-image.oss-cn-hangzhou.aliyuncs.com/intention/%E6%84%8F%E5%9B%BE%E7%BB%B4%E6%8A%A4%E5%AF%BC%E5%85%A5%E6%A8%A1%E7%89%88.xlsx?OSSAccessKeyId=LTAIwDP3dFcdWEUd&Expires=361745300349&Signature=39BNJwrSA0F%2Fl9f46fxfq0iqi2U%3D"
          >
            导入模版
          </Button>
        </div>
        {fileUploadFailUrl && (
          <div className={styles.errorUploadWrap}>
            <VerticalAlignBottomOutlined className={styles.errorUploadIcon} />
            <a
              rel="noreferrer"
              target="_blank"
              href={fileUploadFailUrl}
              className={styles.errorUploadText}
            >
              下载导入失败数据
            </a>
          </div>
        )}
      </Modal>
    </>
  );
};
export default IntentionList;
