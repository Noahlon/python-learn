import React, { FC, useEffect, useState } from 'react';
import { Form, Modal, Input, message, Select } from 'antd';
import TextArea from 'antd/lib/input/TextArea';
import { createKc, editKc } from '@/api/language';
import { IntentionCollectInfo } from '@/api/intention';
import { modelTrainNameQuery, modelTrainNameQueryReq } from '@/api/modelTrain';

export interface Prop {
  type?: number;
  info?: IntentionCollectInfo;
  bizId: string;
  onOk?: () => void;
  onCancel?: () => void;
}

const EditIntentionCollect: FC<Prop> = ({
  type,
  onOk,
  onCancel,
  info,
  bizId,
}) => {
  const [form] = Form.useForm();
  const [modelOpts, setModelOpts] = useState([]);
  const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };

  // 提交
  const handleOk = async () => {
    let param = await form.validateFields();
    if (type === 2 && info?.guid) param.guid = info?.guid;
    if (type === 1) param.bizId = bizId?.[1];
    const api = type === 1 ? createKc : editKc;
    const res: any = await api(param);
    if (res.success) {
      message.success('操作成功');
      onOk?.();
    }
  };

  // 获取模型列表
  const getModelList = async () => {
    const [levelOneBizId, levelTwoBizId] = bizId;
    const params: modelTrainNameQueryReq = {
      modelStatus: 'VERIFY_COMPLETED',
    };
    if (levelOneBizId) {
      params.levelOneBizId = levelOneBizId;
    }
    if (levelTwoBizId) {
      params.levelTwoBizId = levelTwoBizId;
    }
    const res = await modelTrainNameQuery(params);
    if (res?.data) {
      setModelOpts(res.data);
    }
  };

  useEffect(() => {
    if (info && type) {
      console.log(info);
      form.setFieldsValue(info);
    } else {
      form.resetFields();
    }
    if (type) {
      getModelList();
    }
  }, [type]);

  return (
    <>
      <Modal
        open={!!type}
        title={type === 1 ? '添加意图集合' : '编辑意图集合'}
        forceRender={true}
        width={'540px'}
        onOk={handleOk}
        onCancel={() => {
          form.resetFields();
          onCancel?.();
        }}
        getContainer={false}
      >
        <Form form={form} {...layout}>
          <Form.Item label="集合名称" name="name" rules={[{ required: true }]}>
            <Input placeholder="请输入集合名称" maxLength={20} />
          </Form.Item>
          <Form.Item label="绑定模型" name="modelId">
            <Select
              options={modelOpts}
              showSearch
              optionFilterProp="modelName"
              allowClear
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
              placeholder="请选择"
              fieldNames={{ label: 'modelName', value: 'modelId' }}
            />
          </Form.Item>
          <Form.Item
            label="集合描述"
            name="description"
            rules={[{ required: true }]}
          >
            <TextArea
              rows={4}
              maxLength={120}
              placeholder="请输入，限制120字"
              showCount
            ></TextArea>
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};
export default EditIntentionCollect;
