import React, { FC, useEffect, useState } from 'react';
import { Form, Modal, Input, message, Select } from 'antd';
import { addIntention, editIntention, IntentionInfo } from '@/api/intention';
import { getEnumListByType } from '@/api/common';

export interface Prop {
  type?: number;
  info?: IntentionInfo;
  selectICID: string;
  onOk?: () => void;
  onCancel?: () => void;
}

const EditIntention: FC<Prop> = ({
  type,
  onOk,
  onCancel,
  info,
  selectICID,
}) => {
  const [form] = Form.useForm();
  const [propertyTypeOpts, setPropertyTypeOpts] = useState([]);
  const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };

  // 提交
  const handleOk = async () => {
    let param = await form.validateFields();
    console.log(param);
    param.kcGuid = selectICID;
    if (type === 2 && info?.faqId) param.faqId = info?.faqId;
    if (type === 2 && info?.modelGuid) param.modelGuid = info?.modelGuid;
    const api = type === 1 ? addIntention : editIntention;
    const res = await api(param);
    if (res.success) {
      message.success('操作成功');
      onOk?.();
    }
  };

  //获取意图属性枚举
  const getPropertyTypeOpts = async () => {
    const params = {
      typeList: [8],
    };
    const res = await getEnumListByType(params);
    if (res?.data?.length) {
      res.data.forEach((item) => {
        if (item?.type === 8) {
          setPropertyTypeOpts(
            item.enumConstantDTOList.map((item) => {
              return { label: item.value, value: item.code };
            }) || [],
          );
        }
      });
    }
  };

  useEffect(() => {
    if (type) {
      getPropertyTypeOpts();
    }
    if (info && type) {
      console.log(info);
      form.setFieldsValue(info);
    } else {
      form.resetFields();
    }
  }, [type]);

  return (
    <>
      <Modal
        open={!!type}
        title={type === 1 ? '添加意图' : '编辑意图'}
        forceRender={true}
        width={'540px'}
        onOk={handleOk}
        onCancel={() => {
          form.resetFields();
          onCancel?.();
        }}
        getContainer={false}
      >
        <Form form={form} {...layout}>
          <Form.Item label="意图名称" name="name" rules={[{ required: true }]}>
            <Input placeholder="请输入意图名称" maxLength={20} />
          </Form.Item>
          <Form.Item name="propertyType" label="意图属性">
            <Select
              placeholder="请选择意图属性"
              allowClear
              showSearch
              filterOption={(input, option) =>
                (option?.label as string)
                  .toLowerCase()
                  .includes(input.toLowerCase())
              }
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
              options={propertyTypeOpts}
            />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};
export default EditIntention;
