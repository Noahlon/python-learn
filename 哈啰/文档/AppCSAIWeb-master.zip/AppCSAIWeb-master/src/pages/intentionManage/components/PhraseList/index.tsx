import { deleteAllPhrase, IntentionInfo } from '@/api/intention';
import { deletePhrase, IPhrase, queryPhrase } from '@/api/language';
import { keySingleRender } from '@/utils';
import { CloseOutlined } from '@ant-design/icons';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { Button, Empty, message, Popconfirm, Space, Spin } from 'antd';
import React, { FC, useCallback, useEffect, useState } from 'react';
import AddSimilarQOrPhrase from '../AddSimilarQOrPhrase';
import styles from './index.less';
import { useAccess } from '@umijs/max';

export interface Prop {
  intention?: IntentionInfo;
  searchText?: string;
  searchType?: number;
  kcGuid?: string;
}

const PhraseList: FC<Prop> = ({
  intention,
  searchText,
  searchType,
  kcGuid,
}) => {
  const access = useAccess();
  const [phraseList, setPhraseList] = useState<IPhrase[]>();
  const [loading, setLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [showAddModal, setAddModal] = useState(false);
  // 短语列表
  const getPhraseList = async () => {
    if (!intention?.faqId) {
      setPhraseList([]);
      setTotal(0);
      return;
    }
    setLoading(true);
    const res = await queryPhrase({ faqId: intention?.faqId });
    if (res?.success) {
      setPhraseList(res.data);
      setTotal(res.data.length || 0);
    }
    setLoading(false);
  };

  // 删除全部
  const handleDeleteAll = async () => {
    setLoading(true);
    const res = await deleteAllPhrase({ faqId: intention?.faqId });
    if (res.success) {
      message.success('清除成功');
      getPhraseList();
    }
    setLoading(false);
  };

  // 删除单个
  const handleDeletePhrase = async (info: IPhrase) => {
    setLoading(true);
    const { id } = info;
    const res = await deletePhrase({ id });
    if (res.success) {
      message.success('删除成功');
      getPhraseList();
    }
    setLoading(false);
  };

  // 关闭新增弹框
  const handleAddCancel = useCallback(() => {
    setAddModal(false);
  }, [intention]);

  // 新增提交
  const handleAddOk = useCallback(() => {
    handleAddCancel();
    getPhraseList();
  }, [intention]);

  useEffect(() => {
    getPhraseList();
  }, [intention]);

  return (
    <>
      <div className={styles.top}>
        <div>短语{total}个</div>
        <Space>
          <CopyToClipboard
            text={phraseList?.map((item) => item.phrase)?.join(',')}
            onCopy={() => message.success('复制成功')}
          >
            <Button type="link" disabled={total === 0}>
              复制
            </Button>
          </CopyToClipboard>
          {access?.authCodeList?.includes('Call-Intention-Save-AddPhrase') && (
            <Popconfirm title="清除全部短语？" onConfirm={handleDeleteAll}>
              <Button type="link">清除</Button>
            </Popconfirm>
          )}
          {access?.authCodeList?.includes('Call-Intention-Save-AddPhrase') && (
            <Button type="link" onClick={() => setAddModal(true)}>
              新增
            </Button>
          )}
        </Space>
      </div>

      <Spin spinning={loading}>
        <div className={styles.content}>
          {!!phraseList?.length ? (
            phraseList?.map((item) => (
              <div key={item.id} className={styles.item}>
                {access?.authCodeList?.includes(
                  'Call-Intention-Save-EditPhrase',
                ) && (
                  <CloseOutlined
                    className={styles.icon}
                    onClick={() => handleDeletePhrase(item)}
                  />
                )}
                <div
                  className={styles.text}
                  dangerouslySetInnerHTML={{
                    __html:
                      searchType === 2
                        ? keySingleRender(item.phrase, searchText)
                        : item.phrase,
                  }}
                ></div>
              </div>
            ))
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
          )}
        </div>
      </Spin>
      <AddSimilarQOrPhrase
        open={showAddModal}
        kcGuid={kcGuid}
        onCancel={handleAddCancel}
        onOk={handleAddOk}
        intentionId={intention?.faqId}
        type="phrase"
      />
    </>
  );
};
export default PhraseList;
