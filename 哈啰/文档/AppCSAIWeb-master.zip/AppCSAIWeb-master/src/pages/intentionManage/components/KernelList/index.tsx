import {
  queryKnowledgeKernel,
  deleteAllKernel,
  deleteKnowledgeKernel,
  IntentionInfo,
  QueryKernelObj,
} from '@/api/intention';
import { keySingleRender } from '@/utils';
import { CloseOutlined } from '@ant-design/icons';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { Button, Empty, message, Popconfirm, Space, Spin, Alert } from 'antd';
import React, { useCallback, useEffect, useState } from 'react';
import AddModal from '../AddSimilarQOrPhrase';
import { useAccess } from '@umijs/max';
import styles from './index.less';

export interface Prop {
  intention?: IntentionInfo;
  searchText?: string;
  searchType?: number;
  kcGuid?: string;
}

const KernelList: React.FC<Prop> = ({
  intention,
  searchText,
  searchType,
  kcGuid,
}) => {
  const access = useAccess();
  const [kernelList, setKernelList] = useState<QueryKernelObj[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAddModal, setAddModal] = useState(false);

  // 核心句列表
  const getKernelList = async () => {
    setLoading(true);
    const params = { faqId: intention?.faqId };
    const res = await queryKnowledgeKernel(params);
    if (res?.data) {
      setKernelList(res.data);
    }
    setLoading(false);
  };

  // 删除全部【核心句】
  const handleDeleteAll = async () => {
    setLoading(true);
    const params = { faqId: intention?.faqId };
    const res = await deleteAllKernel(params);
    if (res.success) {
      message.success('清除成功');
      getKernelList();
    }
    setLoading(false);
  };

  // 删除单个【核心句】
  const handleDeleteKernel = async (id: string) => {
    setLoading(true);
    const params = {
      kernelId: id,
    };
    const res = await deleteKnowledgeKernel(params);
    if (res.success) {
      message.success('删除成功');
      getKernelList();
    }
    setLoading(false);
  };

  // 关闭新增弹框
  const handleAddCancel = useCallback(() => {
    setAddModal(false);
  }, [intention]);

  // 新增提交
  const handleAddOk = useCallback(() => {
    getKernelList();
    handleAddCancel();
  }, [intention]);

  useEffect(() => {
    if (intention?.faqId) {
      getKernelList();
    } else {
      setKernelList([]);
    }
  }, [intention]);

  return (
    <>
      <Alert
        style={{ marginBottom: 20 }}
        message="优先识别核心句，精准匹配命中"
        type="info"
        showIcon
      />
      <div className={styles.top}>
        <div>核心句{kernelList?.length}个</div>
        <Space>
          <CopyToClipboard
            text={kernelList?.map((item) => item.sentenceInfo)?.join(';')}
            onCopy={() => message.success('复制成功')}
          >
            <Button type="link" disabled={kernelList?.length === 0}>
              复制
            </Button>
          </CopyToClipboard>
          {access?.authCodeList?.includes('Call-Intention-Save-EditPhrase') && (
            <Popconfirm title="清除全部短语？" onConfirm={handleDeleteAll}>
              <Button type="link">清除</Button>
            </Popconfirm>
          )}
          {access?.authCodeList?.includes('Call-Intention-Save-AddPhrase') && (
            <Button type="link" onClick={() => setAddModal(true)}>
              新增
            </Button>
          )}
        </Space>
      </div>

      <Spin spinning={loading}>
        <div className={styles.content}>
          {!!kernelList?.length ? (
            kernelList?.map((item) => (
              <div key={item.kernelId} className={styles.item}>
                {access?.authCodeList?.includes(
                  'Call-Intention-Save-EditPhrase',
                ) && (
                  <CloseOutlined
                    className={styles.icon}
                    onClick={() => handleDeleteKernel(item.kernelId)}
                  />
                )}
                <div
                  className={styles.text}
                  dangerouslySetInnerHTML={{
                    __html:
                      searchType === 2
                        ? keySingleRender(item.sentenceInfo, searchText)
                        : item.sentenceInfo,
                  }}
                ></div>
              </div>
            ))
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
          )}
        </div>
      </Spin>
      <AddModal
        open={showAddModal}
        kcGuid={kcGuid}
        onCancel={handleAddCancel}
        onOk={handleAddOk}
        intentionId={intention?.faqId}
        type="kernel"
      />
    </>
  );
};
export default KernelList;
