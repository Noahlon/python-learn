import { getExtendFaqList, IExtendFaq } from '@/api/extendFaq';
import { IntentionInfo } from '@/api/intention';
import { keySingleRender } from '@/utils';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { Alert, Button, Empty, message, Space, Spin, Tooltip } from 'antd';
import React, { FC, useCallback, useEffect, useState } from 'react';
import AddSimilarQOrPhrase from '../AddSimilarQOrPhrase';
import styles from './index.less';

export interface Prop {
  intention?: IntentionInfo;
  searchText?: string;
  searchType?: number;
  kcGuid?: string;
}

const SimilarityList: FC<Prop> = ({
  intention,
  searchText,
  searchType,
  kcGuid,
}) => {
  // const access = useAccess();
  const [similarQData, setSimilarQData] = useState<IExtendFaq[]>();
  const [loading, setLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [showAddModal, setAddModal] = useState(false);

  // 相似问列表
  const fetchExtendFaqList = async () => {
    if (!intention?.faqId) {
      setSimilarQData([]);
      setTotal(0);
      return;
    }
    setLoading(true);
    const params: { standardFaqGuid: string; modelGuid?: string } = {
      standardFaqGuid: intention?.faqId,
    };
    if (intention?.modelGuid) {
      params.modelGuid = intention.modelGuid;
    }
    const res = await getExtendFaqList(params);
    setSimilarQData(res);
    setTotal(res.length || 0);
    setLoading(false);
  };

  // 删除全部
  // const handleDeleteAll = async () => {
  //   setLoading(true);
  //   const res = await deleteAllSimilar({ standardFaqGuid: intention?.faqId });
  //   if (res.success) {
  //     message.success('清除成功');
  //     fetchExtendFaqList();
  //   }
  //   setLoading(false);
  // };

  // 删除单个
  // const handleDeleteSimilar = async (info) => {
  //   setLoading(true);
  //   const res = await deleteExtendFaq({
  //     extendFaqGuid: info.guid,
  //   });
  //   if (res.success) {
  //     message.success('操作成功');
  //     fetchExtendFaqList();
  //   }
  //   setLoading(false);
  // };

  // 关闭新增弹框
  const handleAddCancel = useCallback(() => {
    setAddModal(false);
  }, []);

  // 新增提交
  const handleAddOk = useCallback(() => {
    handleAddCancel();
    fetchExtendFaqList();
  }, [intention]);

  useEffect(() => {
    fetchExtendFaqList();
  }, [intention]);

  return (
    <>
      <Alert
        style={{ marginBottom: 20 }}
        message="相似问数据的编辑操作在模型训练中"
        type="info"
        showIcon
      />
      <div className={styles.top}>
        <div>相似问{total}个</div>
        <Space>
          <CopyToClipboard
            text={similarQData?.map((item) => item.extendFaqName)?.join(';')}
            onCopy={() => message.success('复制成功')}
          >
            <Button type="link" disabled={total === 0}>
              复制
            </Button>
          </CopyToClipboard>
          {/* {access?.authCodeList?.includes('Call-Intention-Save-AddPhrase') && (
            <Popconfirm title="清除全部相似问？" onConfirm={handleDeleteAll}>
              <Button type="link">清除</Button>
            </Popconfirm>
          )} */}
          {/* {access?.authCodeList?.includes('Call-Intention-Save-AddPhrase') && (
            <Button type="link" onClick={() => setAddModal(true)}>
              新增
            </Button>
          )} */}
        </Space>
      </div>

      <Spin spinning={loading}>
        <div className={styles.content}>
          {!!similarQData?.length ? (
            similarQData?.map((item) => (
              <div key={item.guid} className={styles.item}>
                {/* {access?.authCodeList?.includes(
                  'Call-Intention-Save-EditPhrase',
                ) && (
                  <CloseOutlined
                    className={styles.icon}
                    onClick={() => handleDeleteSimilar(item)}
                  />
                )} */}
                <Tooltip
                  title={
                    searchType === 1
                      ? keySingleRender(item.extendFaqName, searchText)
                      : item.extendFaqName
                  }
                >
                  <div
                    className={styles.text}
                    dangerouslySetInnerHTML={{
                      __html:
                        searchType === 1
                          ? keySingleRender(item.extendFaqName, searchText)
                          : item.extendFaqName,
                    }}
                  ></div>
                </Tooltip>
              </div>
            ))
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
          )}
        </div>
      </Spin>
      <AddSimilarQOrPhrase
        open={showAddModal}
        kcGuid={kcGuid}
        onCancel={handleAddCancel}
        onOk={handleAddOk}
        intentionId={intention?.faqId}
        type="similar"
      />
    </>
  );
};
export default SimilarityList;
