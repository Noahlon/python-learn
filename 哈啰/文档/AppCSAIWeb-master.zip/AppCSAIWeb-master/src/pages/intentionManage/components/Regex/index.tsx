import {
  knowledgeQueryRegex,
  regexDeleteAll,
  regexDelete,
  copyKnowledgeRegex,
  IntentionInfo,
  QueryRegexObj,
} from '@/api/intention';
import { textHightLight } from '@/utils';
import { CloseOutlined } from '@ant-design/icons';
import CopyToClipboard from 'react-copy-to-clipboard';
import {
  Button,
  Empty,
  message,
  Popconfirm,
  Space,
  Spin,
  Pagination,
} from 'antd';
import React, { useCallback, useEffect, useState, useRef } from 'react';
import AddModal from '../AddSimilarQOrPhrase';
import { useAccess } from '@umijs/max';
import styles from './index.less';

export interface Prop {
  intention?: IntentionInfo;
  searchText?: string;
  searchType?: number;
  kcGuid?: string;
}

const RegexlList: React.FC<Prop> = ({
  intention,
  searchText,
  searchType,
  kcGuid,
}) => {
  const access = useAccess();
  const [kernelList, setKernelList] = useState<QueryRegexObj[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAddModal, setAddModal] = useState(false);
  const queryParams = useRef<any>({ pageNum: 1, pageSize: 100 });
  const [total, setTotal] = useState(0);
  const [apiData, setApiData] = useState('');

  /**
   * 复制
   */
  const handleCopyClick = async () => {
    const res = await copyKnowledgeRegex({ faqId: intention?.faqId });
    if (res?.code === '0') {
      setApiData(res?.data);
    }
  };
  // 列表
  const getRegexlList = async () => {
    setLoading(true);
    queryParams.current = { ...queryParams.current, faqId: intention?.faqId };
    const res = await knowledgeQueryRegex(queryParams.current);
    if (res?.data) {
      setKernelList(res?.data?.list);
      setTotal(res?.data?.totalRecord || 0);
      handleCopyClick();
    }
    setLoading(false);
  };

  // 删除全部【核心句】
  const handleDeleteAll = async () => {
    setLoading(true);
    const params = { faqId: intention?.faqId };
    const res = await regexDeleteAll(params);
    if (res.success) {
      message.success('清除成功');
      getRegexlList();
    }
    setLoading(false);
  };

  // 删除单个【核心句】
  const handleDeleteKernel = async (id: string) => {
    setLoading(true);
    const params = {
      regexId: id,
    };
    const res = await regexDelete(params);
    if (res.success) {
      message.success('删除成功');
      getRegexlList();
    }
    setLoading(false);
  };

  // 关闭新增弹框
  const handleAddCancel = useCallback(() => {
    setAddModal(false);
  }, [intention]);

  // 新增提交
  const handleAddOk = useCallback(() => {
    getRegexlList();
    handleAddCancel();
  }, [intention]);

  useEffect(() => {
    if (intention?.faqId) {
      queryParams.current = { pageNum: 1, pageSize: 100 };
      getRegexlList();
    } else {
      setKernelList([]);
    }
  }, [intention]);

  // 分页
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    queryParams.current = {
      pageNum: pageSize === queryParams.current.pageSize ? pageNum : 1,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    getRegexlList();
  };

  return (
    <>
      <div className={styles.top}>
        <div>正则{total || 0}个</div>
        <Space>
          <CopyToClipboard
            text={apiData}
            onCopy={() => message.success('复制成功')}
          >
            <Button type="link" disabled={total === 0}>
              复制
            </Button>
          </CopyToClipboard>
          {access?.authCodeList?.includes('Call-Intention-Save-EditPhrase') && (
            <Popconfirm
              title="清除该意图下全部正则短语?"
              onConfirm={handleDeleteAll}
            >
              <Button type="link">清除</Button>
            </Popconfirm>
          )}
          {access?.authCodeList?.includes('Call-Intention-Save-AddPhrase') && (
            <Button type="link" onClick={() => setAddModal(true)}>
              新增
            </Button>
          )}
        </Space>
      </div>

      <Spin spinning={loading}>
        <div className={styles.content}>
          {!!kernelList?.length ? (
            kernelList?.map((item) => (
              <div key={item.regexId} className={styles.item}>
                {access?.authCodeList?.includes(
                  'Call-Intention-Save-EditPhrase',
                ) && (
                  <CloseOutlined
                    className={styles.icon}
                    onClick={() => handleDeleteKernel(item.regexId)}
                  />
                )}

                <div
                  className={`${styles.text} ${
                    searchType === 4
                      ? searchText &&
                        textHightLight(item.regexInfo, searchText) &&
                        styles.textHightLight
                      : ''
                  }`}
                >
                  {item.regexInfo}
                </div>
              </div>
            ))
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
          )}
        </div>
        <div className={styles.pagination}>
          <Pagination
            showSizeChanger
            onChange={handlePageChange}
            current={queryParams.current.pageNum}
            pageSize={queryParams.current.pageSize}
            pageSizeOptions={[20, 50, 100]}
            total={total}
          />
        </div>
      </Spin>
      <AddModal
        open={showAddModal}
        kcGuid={kcGuid}
        onCancel={handleAddCancel}
        onOk={handleAddOk}
        intentionId={intention?.faqId}
        type="regex"
      />
    </>
  );
};
export default RegexlList;
