import {
  DeleteOutlined,
  EditOutlined,
  ExclamationCircleOutlined,
  HistoryOutlined,
} from '@ant-design/icons';
import { Button, Cascader, Form, message, Spin, Modal, Tooltip } from 'antd';
import { parse } from 'query-string';
import { history, useAccess } from '@umijs/max';
import React, { FC, useEffect, useMemo, useState } from 'react';
import styles from './index.less';
import IntentionList from './components/IntentionList';
import EditIntentionCollect from './components/EditIntentionCollect';
import { getBizTreeList } from '@/api/biz';
import {
  getTradeIntentionList,
  IntentionCollectInfo,
  refreshPhraseCache,
} from '@/api/intention';
import { deleteKc } from '@/api/language';

const { confirm } = Modal;
interface Option {
  value: string;
  label: string;
  children?: Option[];
}

const IntentionManage: FC = () => {
  const query = parse(location.search);
  const access = useAccess();
  const [intentionCollectList, setIntentionCollectList] = useState<
    IntentionCollectInfo[]
  >([]);
  const [selectIC, setSelectIC] = useState(undefined);
  const [loading, setLoading] = useState(false);
  // 1--新增 2--编辑  3--复制 4--查看
  const [type, setType] = useState(undefined);
  const [curInfo, setCurInfo] = useState<IntentionCollectInfo>(undefined);
  const [selectBizId, setSelectBizId] = useState(undefined);
  const [bizOptions, setBizOptions] = useState<Option[]>([]);

  // 获取意图集合列表
  const handlerGetLists = async () => {
    if (!selectBizId?.[1]) return;
    setLoading(true);
    const param: any = {
      bizId: selectBizId?.[1],
    };
    const res = await getTradeIntentionList(param);
    if (res?.success && res.data?.length) {
      setIntentionCollectList(res.data);
      const IcInfo = res?.data.find((item) => item.guid === query?.IC);
      if (IcInfo) {
        setSelectIC(IcInfo);
      } else {
        setSelectIC(res?.data[0]);
      }
    } else {
      setIntentionCollectList([]);
    }
    setLoading(false);
  };

  // 点击意图集合
  const handleClickIC = (ic) => {
    setSelectIC(ic);
    history?.replace({
      pathname: '/intention/intentionManage',
      search: `?IC=${ic.guid}`,
    });
  };

  // 行业选择
  const onChange = (value: string[]) => {
    if (JSON.stringify(value) === JSON.stringify(selectBizId)) return;
    setSelectBizId(value);
  };

  // 编辑提交
  const handleEditOk = () => {
    setType(0);
    setCurInfo(undefined);
    handlerGetLists();
  };

  // 删除
  const handleDeleteIntentionCollect = (info: IntentionCollectInfo) => {
    console.log(info);
    confirm({
      title: '删除意图集合',
      icon: <ExclamationCircleOutlined />,
      content: '同时删除该集合下的全部意图',
      onOk() {
        return deleteKc({ guid: info?.guid })
          .then((res: any) => {
            if (res?.success) {
              message.success('操作成功');
              handlerGetLists();
            }
          })
          .catch(() => console.log(222));
      },
      onCancel() {},
    });
  };

  useMemo(() => {
    handlerGetLists();
    setSelectIC(undefined);
    setIntentionCollectList([]);
  }, [selectBizId]);

  // 获取行业
  const handleBizList = async () => {
    const res = await getBizTreeList({ includeScene: true });
    if (res.success && res.data?.length) {
      const opts = res.data?.map((item) => {
        return {
          value: item.id,
          label: item.name,
          children: item.children?.map((i) => ({ value: i.id, label: i.name })),
        };
      });
      if (opts?.length) setBizOptions(opts);
      if (opts?.[0]?.children?.[0]?.value)
        setSelectBizId([opts?.[0]?.value, opts?.[0]?.children?.[0]?.value]);
    } else {
      setBizOptions([]);
    }
  };

  // 删除意图
  const handleIntentionChange = () => {
    handlerGetLists();
  };

  // 更新意图缓存
  const handleSaveCache = async (curKCInfo: IntentionCollectInfo) => {
    const res = await refreshPhraseCache({ guid: curKCInfo.guid });
    if (res?.success) message.success('操作成功');
  };

  useEffect(() => {
    handleBizList();
  }, []);

  return (
    <>
      <div className={styles.intentionCollectWrap}>
        <div className={styles.intentionCollectLeft}>
          <div className={styles.industry}>
            <Form.Item label="行业">
              <Cascader
                value={selectBizId}
                options={bizOptions}
                onChange={onChange}
                allowClear={false}
              />
            </Form.Item>
          </div>
          {access?.authCodeList?.includes('Call-Intention-Save-AddIC') && (
            <div className={styles.createIC}>
              <Button
                type="primary"
                block
                onClick={() => {
                  setType(1);
                }}
              >
                新建意图集合
              </Button>
            </div>
          )}
          <div className={styles.iCList}>
            <Spin spinning={loading} style={{ minHeight: '30px' }}>
              {intentionCollectList.map((item, index) => {
                return (
                  <div key={index} className={styles.itemIC}>
                    <div
                      onClick={() => handleClickIC(item)}
                      className={[
                        styles.itemICName,
                        item.guid === selectIC?.guid ? styles.itemICActive : '',
                      ].join(' ')}
                    >
                      <div>
                        {item.name}({item.knowledgeCount})
                      </div>
                      <div className={styles.bindModel}>
                        {item.modelName ? (
                          <Tooltip title={`绑定模型：${item.modelName}`}>
                            绑定模型：{item.modelName}
                          </Tooltip>
                        ) : (
                          '绑定模型：-'
                        )}
                      </div>
                    </div>
                    <div>
                      <HistoryOutlined
                        style={{ marginRight: 8 }}
                        onClick={() => handleSaveCache(item)}
                      />
                      {access?.authCodeList?.includes(
                        'Call-Intention-Save-EditIC',
                      ) && (
                        <EditOutlined
                          style={{ marginRight: 8 }}
                          onClick={() => {
                            setType(2);
                            setCurInfo(item);
                          }}
                        />
                      )}
                      {access?.authCodeList?.includes(
                        'Call-Intention-Save-DeleteIC',
                      ) && (
                        <DeleteOutlined
                          onClick={() => handleDeleteIntentionCollect(item)}
                        />
                      )}
                    </div>
                  </div>
                );
              })}
            </Spin>
          </div>
        </div>
        <div className={styles.intentionCollectRight}>
          <IntentionList selectIC={selectIC} onChange={handleIntentionChange} />
        </div>
      </div>
      <EditIntentionCollect
        type={type}
        info={curInfo}
        bizId={selectBizId}
        onCancel={() => {
          setType(0);
          setCurInfo(undefined);
        }}
        onOk={handleEditOk}
      />
    </>
  );
};
export default IntentionManage;
