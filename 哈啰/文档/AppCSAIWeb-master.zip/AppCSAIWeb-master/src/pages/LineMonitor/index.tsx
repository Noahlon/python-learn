import React, { useEffect } from 'react';
import { Tabs } from 'antd';
import styles from './index.less';
import TenantLineTodayTable from './components/TenantLine/TodayTable';
import TenantLineHistoryTable from './components/TenantLine/HistoryTable';
import SupplierLineTodayTable from './components/SupplierLine/TodayTable';
import SupplierLineHistoryTable from './components/SupplierLine/HistoryTable';
import MultipleLineTodayTable from './components/MultipleLine/TodayTable';
import MultipleLineHistoryTable from './components/MultipleLine/HistoryTable';
import { useModel } from '@umijs/max';

const LineMonitor: React.FC = () => {
  const { fetchTenantOpts } = useModel('common');

  useEffect(() => {
    fetchTenantOpts();
  }, []);

  return (
    <div className={styles.linemonitor}>
      <Tabs
        defaultActiveKey="1"
        destroyInactiveTabPane
        items={[
          {
            label: '租户线路',
            key: '1',
            children: (
              <Tabs
                destroyInactiveTabPane
                items={[
                  {
                    label: '今日',
                    key: '1-1',
                    children: <TenantLineTodayTable />,
                  },
                  {
                    label: '历史',
                    key: '1-2',
                    children: <TenantLineHistoryTable />,
                  },
                ]}
              />
            ),
          },
          {
            label: '供应商线路',
            key: '2',
            children: (
              <Tabs
                destroyInactiveTabPane
                items={[
                  {
                    label: '今日',
                    key: '2-1',
                    children: <SupplierLineTodayTable />,
                  },
                  {
                    label: '历史',
                    key: '2-2',
                    children: <SupplierLineHistoryTable />,
                  },
                ]}
              />
            ),
          },
          {
            label: '租户+供应商线路',
            key: '3',
            children: (
              <Tabs
                destroyInactiveTabPane
                items={[
                  {
                    label: '今日',
                    key: '3-1',
                    children: <MultipleLineTodayTable />,
                  },
                  {
                    label: '历史',
                    key: '3-2',
                    children: <MultipleLineHistoryTable />,
                  },
                ]}
              />
            ),
          },
        ]}
      />
    </div>
  );
};

export default LineMonitor;
