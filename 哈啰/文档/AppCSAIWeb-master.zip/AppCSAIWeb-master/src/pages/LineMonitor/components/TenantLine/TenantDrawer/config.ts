export const timeOptions = [
  {
    label: '5分钟',
    value: 5,
  },
  {
    label: '10分钟',
    value: 10,
  },
  {
    label: '15分钟',
    value: 15,
  },
];

export const abnormalOpt = [
  { label: '0互动', value: 'USER_NOT_SPEAK' },
  { label: '秒挂', value: 'SHORT_CALL_DURATION' },
];
