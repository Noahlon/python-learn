import React, { useRef, useState, useEffect, useCallback } from 'react';
import {
  Input,
  Table,
  Button,
  Pagination,
  DatePicker,
  Form,
  Space,
} from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import { v1 as uuidv1 } from 'uuid';
import styles from './index.less';
import TenantDrawer from '@/pages/LineMonitor/components/TenantLine/TenantDrawer';
import moment from 'moment';
import { useAccess } from '@umijs/max';
import type { ColumnsType } from 'antd/es/table';
import { getLine, ILineInfo, statisticsExport } from '@/api/lineMonitor';
import { RangePickerProps } from 'antd/es/date-picker';
import { convertPer } from '@/utils';
const { RangePicker } = DatePicker;

const HistoryTable: React.FC = () => {
  const queryParams = useRef({
    pageNum: 1,
    pageSize: 100,
    name: undefined,
    statisticsType: 0, // 租户
    startDate: moment().subtract(1, 'days').format('YYYY-MM-DD'),
    endDate: moment().subtract(1, 'days').format('YYYY-MM-DD'),
    sort: undefined,
    sortParam: undefined,
    sortAsc: undefined,
  });
  const access = useAccess();
  const ref = useRef(null);
  const [form] = Form.useForm();
  const [height, setHeight] = useState(null);
  const [open, setOpen] = useState(false);
  const [inputVal, setInputVal] = useState('');
  const [tableLoading, setTableLoading] = useState(false);
  const [dataSource, setDataSource] = useState<ILineInfo[]>([]);
  const [curInfo, setCurInfo] = useState<ILineInfo>(undefined);
  const [total, setTotal] = useState(0);
  const [pageIndex, setPageIndex] = useState(1);
  const [pageSize, setPageSize] = useState(100);
  const [upload, setUpload] = useState(false);
  const [date, setDate] = useState<string[]>([]);

  /**
   * api
   */
  const handlerGetLists = async () => {
    setTableLoading(true);
    setDate([queryParams.current.startDate, queryParams.current.endDate]);
    const res = await getLine(queryParams.current);
    if (res.success) {
      setDataSource(res?.data?.list || []);
      setTotal(res?.data?.totalRecord);
    }
    setTableLoading(false);
  };

  const search = async () => {
    const res = await form.validateFields();
    queryParams.current.startDate = res.data?.length
      ? moment(res.data?.[0]._d).format('YYYY-MM-DD')
      : undefined;
    queryParams.current.endDate = res.data?.length
      ? moment(res.data?.[1]._d).format('YYYY-MM-DD')
      : undefined;
    queryParams.current.name = res.name;
    queryParams.current.pageNum = 1;
    setPageIndex(1);
    handlerGetLists();
  };

  // 分页
  const onChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      if (size !== pageSize) {
        queryParams.current.pageNum = 1;
        queryParams.current.pageSize = size;
        setPageIndex(1);
        setPageSize(size);
      } else {
        setPageIndex(page);
        queryParams.current.pageNum = page;
      }
      handlerGetLists();
    },
    [pageSize],
  );

  const disabledDate: RangePickerProps['disabledDate'] = useCallback(
    (current) => {
      return current && current > moment().subtract(1, 'days');
    },
    [],
  );

  const columns: ColumnsType<any> = [
    {
      title: '日期',
      dataIndex: 'statisticsDate',
      fixed: 'left',
      width: 150,
    },
    {
      title: '租户名称',
      dataIndex: 'tenantName',
      width: 180,
      render: (text) => <a>{text}</a>,
    },
    {
      title: '租户编号',
      dataIndex: 'statisticKey',
      width: 180,
    },
    {
      title: '外呼名单数',
      dataIndex: 'totalCall',
      sorter: true,
      width: 130,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '接通数',
      dataIndex: 'totalPut',
      sorter: true,
      width: 130,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '租户计费数',
      dataIndex: 'tenantBilling',
      width: 200,
      key: 'tenantBilling',
      align: 'center',
      render: (text: number) => (text === 0 ? 0 : text ? text : '-'),
    },
    {
      title: '接通率',
      dataIndex: 'putRate',
      sorter: true,
      width: 130,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '未说话数',
      dataIndex: 'totalNotUserSpeak',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '未说话占比',
      dataIndex: 'notUserSpeakRate',
      width: 150,
      sorter: true,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '秒挂断话数',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      dataIndex: 'totalShortCallDuration',
    },
    {
      title: '秒挂通话占比',
      dataIndex: 'shortCallDurationRate',
      width: 150,
      sorter: true,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '限频数',
      sorter: true,
      width: 130,
      sortDirections: ['descend', 'ascend'],
      dataIndex: 'totalRateLimit',
    },
    {
      title: '限频占比',
      dataIndex: 'rateLimitRate',
      sorter: true,
      width: 130,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '黑名单数',
      dataIndex: 'totalBlack',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '黑名单占比',
      dataIndex: 'totalBlackRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '无可用并发数',
      dataIndex: 'noUsableConcurren',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '无可用并发占比',
      dataIndex: 'noUsableConcurrenRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '线路拦截名单数',
      dataIndex: 'lineInterceptNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '线路拦截率',
      dataIndex: 'lineInterceptNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '平台限频数',
      dataIndex: 'callFrequencyLimit',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '平台限频率',
      dataIndex: 'callFrequencyLimitRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '平台黑名单数',
      dataIndex: 'callblackListLimit',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '平台黑名单率',
      dataIndex: 'callblackListLimitRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '外部黑名单数',
      dataIndex: 'outCallblackListLimit',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '外部黑名单占比',
      dataIndex: 'outCallblackListLimitRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'A类名单数',
      dataIndex: 'aIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'B类名单数',
      dataIndex: 'bIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'C类名单数',
      dataIndex: 'cIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'D类名单数',
      dataIndex: 'dIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'E类名单数',
      dataIndex: 'eIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'F类名单数',
      dataIndex: 'fIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'G类名单数',
      dataIndex: 'gIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'H类名单数',
      dataIndex: 'hIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'I类名单数',
      dataIndex: 'iIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'L类名单数',
      dataIndex: 'lIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'M类名单数',
      dataIndex: 'mIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '未知名单数',
      dataIndex: 'unknownIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'A类占比',
      dataIndex: 'aIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'B类占比',
      dataIndex: 'bIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'C类占比',
      dataIndex: 'cIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'D类占比',
      dataIndex: 'dIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'E类占比',
      dataIndex: 'eIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'F类占比',
      dataIndex: 'fIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'G类占比',
      dataIndex: 'gIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'H类占比',
      dataIndex: 'hIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'I类占比',
      dataIndex: 'iIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'L类占比',
      dataIndex: 'lIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'M类占比',
      dataIndex: 'mIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '未知占比',
      dataIndex: 'unknownIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'ADE类名单数',
      dataIndex: 'adeIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'ADE类占比',
      dataIndex: 'adeIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'AB类名单数',
      dataIndex: 'abIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'AB类占比',
      dataIndex: 'abIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: 'AD类名单数',
      dataIndex: 'adIntentNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: 'AD类占比',
      dataIndex: 'adIntentNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '超时名单数',
      dataIndex: 'timeoutNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '超时占比',
      dataIndex: 'timeoutNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '接听助理名单数',
      dataIndex: 'answeringAssistantNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '接听助理占比',
      dataIndex: 'answeringAssistantNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '运营商提示音名单数',
      dataIndex: 'operatorPromptSoundNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '运营商提示音占比',
      dataIndex: 'operatorPromptSoundNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '有交互名单数',
      dataIndex: 'interactiveNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '有交互名单占比',
      dataIndex: 'interactiveNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
    {
      title: '平均说话次数',
      dataIndex: 'speekAvg',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '有说话名单数',
      dataIndex: 'speekNum',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '有说话占比',
      dataIndex: 'speekNumRate',
      sorter: true,
      width: 150,
      sortDirections: ['descend', 'ascend'],
      render: (text) => `${convertPer(text)}%`,
    },
  ];

  // 导出
  const handleUpload = async () => {
    setUpload(true);
    console.log(queryParams.current);
    const res = await statisticsExport(queryParams.current);
    if (res.data) {
      let elink = document.createElement('a');
      elink.style.display = 'none';
      let newUrl = (res?.data as unknown as string).replace('http', 'https');
      elink.href = newUrl;
      // elink.download = '任务模版';
      document.body.appendChild(elink);
      elink.click();
      setTimeout(() => {
        document.body.removeChild(elink);
      }, 300);
    }
    setUpload(false);
    console.log('导出');
  };

  // 弹框关闭
  const handleCloseDrawer = useCallback(() => {
    setOpen(false);
    setCurInfo(undefined);
  }, []);

  // 筛选
  const handleTableChange = (pagination, filters, sorter) => {
    console.log(pagination, filters, sorter);
    if (!!sorter?.order) {
      queryParams.current.sort = 1;
      queryParams.current.sortParam = sorter?.field;
      queryParams.current.sortAsc = sorter?.order === 'descend' ? -1 : 1;
    } else {
      queryParams.current.sort = undefined;
      queryParams.current.sortParam = undefined;
      queryParams.current.sortAsc = undefined;
    }
    handlerGetLists();
  };

  useEffect(() => {
    if (ref.current) {
      setHeight(ref.current.clientHeight);
    }
    handlerGetLists();
    form.setFieldValue('data', [
      moment().subtract(1, 'days'),
      moment().subtract(1, 'days'),
    ]);
  }, []);

  return (
    <div className={styles.historytable}>
      <div className={styles.search}>
        <div>
          <Form form={form}>
            <Space align="start">
              <Form.Item name="name">
                <Input
                  placeholder="租户"
                  style={{ width: '300px', marginRight: '20px' }}
                  value={inputVal}
                  onChange={(e) => {
                    setInputVal(e.target.value);
                  }}
                  allowClear
                />
              </Form.Item>
              <Form.Item name="data" rules={[{ required: true, message: '' }]}>
                <RangePicker
                  style={{ width: '300px', marginRight: '20px' }}
                  // value={dateVal}
                  allowClear={false}
                  disabledDate={disabledDate}
                />
              </Form.Item>
              <Button type="primary" onClick={search}>
                搜索
              </Button>
            </Space>
          </Form>
        </div>
        {access?.authCodeList?.includes('Call-Line-Linemonitor-Export') && (
          <div style={{ textAlign: 'right' }}>
            <Button
              type="primary"
              style={{ marginRight: '20px' }}
              icon={<DownloadOutlined />}
              loading={upload}
              onClick={handleUpload}
            >
              导出
            </Button>
          </div>
        )}
      </div>
      <div className={styles.box} ref={ref}>
        <div className={styles.table}>
          <Table
            columns={columns}
            dataSource={dataSource}
            loading={tableLoading}
            scroll={{ x: 1900, y: height - 119 }}
            onChange={handleTableChange}
            rowKey={() => uuidv1()}
            rowClassName={useCallback(
              (record) => {
                if (curInfo?.statisticKey === record?.statisticKey)
                  return styles.activity;
                return '';
              },
              [curInfo],
            )}
            pagination={false}
            onRow={(record: ILineInfo) => {
              return {
                onClick: () => {
                  if (
                    access?.authCodeList?.includes('Call-Line-Linemonitor-Info')
                  ) {
                    setCurInfo(record);
                    setOpen(true);
                  }
                },
              };
            }}
          />
        </div>
        <div className={styles.pagination}>
          <Pagination
            current={pageIndex}
            showSizeChanger={true}
            pageSize={pageSize}
            total={total}
            showTotal={(total) => `总共 ${total} 条`}
            onChange={onChange}
          />
        </div>
      </div>
      {open && (
        <TenantDrawer
          open={open}
          info={curInfo}
          closeDrawer={handleCloseDrawer}
          type="tenantHistory"
          date={date}
        />
      )}
    </div>
  );
};

export default HistoryTable;
