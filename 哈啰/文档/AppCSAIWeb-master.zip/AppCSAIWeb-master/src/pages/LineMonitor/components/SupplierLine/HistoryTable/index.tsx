import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Input,
  Table,
  Button,
  Pagination,
  Form,
  DatePicker,
  Space,
} from 'antd';
import moment from 'moment';
import { v1 as uuidv1 } from 'uuid';
import styles from './index.less';
import SupplierDrawer from '@/pages/LineMonitor/components/SupplierLine/SupplierDrawer';
import { useAccess } from '@umijs/max';
import columns from './config';
import type { ColumnsType } from 'antd/es/table';
import { getLine, ILineInfo, statisticsExport } from '@/api/lineMonitor';
import { RangePickerProps } from 'antd/es/date-picker';
import { DownloadOutlined } from '@ant-design/icons';
const { RangePicker } = DatePicker;

const TodayTable: React.FC = () => {
  const queryParams = useRef({
    pageNum: 1,
    pageSize: 100,
    name: undefined,
    statisticsType: 1, // 供应商
    startDate: moment().subtract(1, 'days').format('YYYY-MM-DD'),
    endDate: moment().subtract(1, 'days').format('YYYY-MM-DD'),
    callingNumber: undefined,
    supplierName: undefined,
    sort: undefined,
    sortParam: undefined,
    sortAsc: undefined,
  });
  const ref = useRef();
  const access = useAccess();
  const [form] = Form.useForm();
  const [height, setHeight] = useState(null);
  const [open, setOpen] = useState(false);
  const [dataSource, setDataSource] = useState<ILineInfo[]>([]);
  const [curInfo, setCurInfo] = useState<ILineInfo>(undefined);
  const [tableLoading, setTableLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [pageIndex, setPageIndex] = useState(1);
  const [pageSize, setPageSize] = useState(100);
  const [upload, setUpload] = useState(false);
  const [date, setDate] = useState<string[]>([]);

  const columns2: ColumnsType<any> = [
    {
      title: '日期',
      dataIndex: 'statisticsDate',
      width: 130,
      fixed: 'left',
    },
    {
      title: '线路名称',
      dataIndex: 'lineName',
      width: 180,
      render: (text) => <a>{text}</a>,
    },
  ];

  const disabledDate: RangePickerProps['disabledDate'] = useCallback(
    (current) => {
      return current && current > moment().subtract(1, 'days');
    },
    [],
  );
  /**
   * api
   */
  const handlerGetLists = async () => {
    setTableLoading(true);
    setDate([queryParams.current.startDate, queryParams.current.endDate]);
    const res = await getLine(queryParams.current);
    if (res.success) {
      setDataSource(res?.data?.list || []);
      setTotal(res?.data?.totalRecord);
    }
    setTableLoading(false);
  };

  useEffect(() => {
    form.setFieldValue('data', [
      moment().subtract(1, 'days'),
      moment().subtract(1, 'days'),
    ]);
    if (ref.current) {
      // @ts-ignore
      setHeight(ref.current.clientHeight);
    }
    handlerGetLists();
  }, []);

  // const closeDrawer = () => {
  //   setOpen(false);
  // };

  const search = async () => {
    const res = await form.validateFields();
    queryParams.current.pageNum = 1;
    queryParams.current.name = res.name;
    queryParams.current.callingNumber = res.callingNumber;
    queryParams.current.supplierName = res.supplierName;
    queryParams.current.startDate = res.data?.length
      ? moment(res.data?.[0]._d).format('YYYY-MM-DD')
      : undefined;
    queryParams.current.endDate = res.data?.length
      ? moment(res.data?.[1]._d).format('YYYY-MM-DD')
      : undefined;
    setPageIndex(1);
    handlerGetLists();
  };

  // 分页
  const onChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      if (size !== pageSize) {
        queryParams.current.pageNum = 1;
        queryParams.current.pageSize = size;
        setPageIndex(1);
        setPageSize(size);
      } else {
        setPageIndex(page);
        queryParams.current.pageNum = page;
      }
      handlerGetLists();
    },
    [pageSize],
  );

  // 导出
  const handleUpload = async () => {
    setUpload(true);
    console.log(queryParams.current);
    const res = await statisticsExport(queryParams.current);
    if (res.data) {
      let elink = document.createElement('a');
      elink.style.display = 'none';
      let newUrl = (res?.data as unknown as string).replace('http', 'https');
      elink.href = newUrl;
      // elink.download = '任务模版';
      document.body.appendChild(elink);
      elink.click();
      setTimeout(() => {
        document.body.removeChild(elink);
      }, 300);
    }
    setUpload(false);
  };

  // 弹框关闭
  const handleCloseDrawer = useCallback(() => {
    setOpen(false);
    setCurInfo(undefined);
  }, []);

  // 筛选
  const handleTableChange = (pagination, filters, sorter) => {
    console.log(pagination, filters, sorter);
    if (!!sorter?.order) {
      queryParams.current.sort = 1;
      queryParams.current.sortParam = sorter?.field;
      queryParams.current.sortAsc = sorter?.order === 'descend' ? -1 : 1;
    } else {
      queryParams.current.sort = undefined;
      queryParams.current.sortParam = undefined;
      queryParams.current.sortAsc = undefined;
    }
    handlerGetLists();
  };

  return (
    <div className={styles.todaytable}>
      <div className={styles.search}>
        <div>
          <Form form={form}>
            <Space align="start">
              <Form.Item name="name">
                <Input
                  placeholder="线路名称"
                  style={{ width: '190px', marginRight: '10px' }}
                  allowClear
                />
              </Form.Item>
              <Form.Item name="supplierName">
                <Input
                  placeholder="供应商名称"
                  style={{ width: '190px', marginRight: '10px' }}
                  allowClear
                />
              </Form.Item>
              <Form.Item name="callingNumber">
                <Input
                  placeholder="主叫号码"
                  style={{ width: '190px', marginRight: '10px' }}
                  allowClear
                />
              </Form.Item>
              <Form.Item name="data" rules={[{ required: true, message: '' }]}>
                <RangePicker
                  style={{ width: '260px', marginRight: '20px' }}
                  // value={dateVal}
                  allowClear={false}
                  disabledDate={disabledDate}
                />
              </Form.Item>
              <Button type="primary" onClick={search}>
                搜索
              </Button>
            </Space>
          </Form>
        </div>
        {access?.authCodeList?.includes('Call-Line-Linemonitor-Export') && (
          <div style={{ textAlign: 'right' }}>
            <Button
              type="primary"
              style={{ marginRight: '20px' }}
              icon={<DownloadOutlined />}
              loading={upload}
              onClick={handleUpload}
            >
              导出
            </Button>
          </div>
        )}
      </div>
      <div className={styles.table} ref={ref}>
        <Table
          columns={[...columns2, ...columns]}
          dataSource={dataSource}
          rowKey={() => uuidv1()}
          scroll={{ x: 2050, y: height }}
          onChange={handleTableChange}
          pagination={false}
          loading={tableLoading}
          rowClassName={useCallback(
            (record) => {
              if (curInfo?.statisticKey === record?.statisticKey)
                return styles.activity;
              return '';
            },
            [curInfo],
          )}
          onRow={(record) => {
            return {
              onClick: () => {
                if (
                  access?.authCodeList?.includes('Call-Line-Linemonitor-Info')
                ) {
                  setCurInfo(record);
                  setOpen(true);
                }
              },
            };
          }}
        />
      </div>
      <div className={styles.pagination}>
        <Pagination
          current={pageIndex}
          showSizeChanger={true}
          pageSize={pageSize}
          total={total}
          showTotal={(total) => `总共 ${total} 条`}
          onChange={onChange}
        />
      </div>
      {open && (
        <SupplierDrawer
          open={open}
          info={curInfo}
          closeDrawer={handleCloseDrawer}
          type="supplierHistory"
          date={date}
        />
      )}
    </div>
  );
};

export default TodayTable;
