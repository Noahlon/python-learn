import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Input,
  Table,
  Button,
  Pagination,
  Form,
  DatePicker,
  Select,
} from 'antd';
import moment from 'moment';
import { v1 as uuidv1 } from 'uuid';
import { useAccess } from '@umijs/max';
import { getLine, ILineInfo, statisticsExport } from '@/api/lineMonitor';
import { DownloadOutlined } from '@ant-design/icons';
import { multipleHistoryColumns } from '../config';
import { downloadCustomNameFile } from '@/utils';
import { useModel } from '@umijs/max';
import styles from './index.less';

const { RangePicker } = DatePicker;

const MultipleLineHistoryTable: React.FC = () => {
  const { tenantOpts } = useModel('common');
  const queryParams = useRef({
    pageNum: 1,
    pageSize: 100,
    name: undefined,
    statisticsType: 2,
    startDate: moment().subtract(1, 'days').format('YYYY-MM-DD'),
    endDate: moment().subtract(1, 'days').format('YYYY-MM-DD'),
    tenantCode: undefined,
    supplierName: undefined,
    sort: undefined,
    sortParam: undefined,
    sortAsc: undefined,
  });
  const ref = useRef();
  const access = useAccess();
  const [form] = Form.useForm();
  const [height, setHeight] = useState(null);
  const [dataSource, setDataSource] = useState<ILineInfo[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [pageIndex, setPageIndex] = useState(1);
  const [pageSize, setPageSize] = useState(100);
  const [upload, setUpload] = useState(false);

  /**
   * api
   */
  const handlerGetLists = async () => {
    setTableLoading(true);
    const res = await getLine(queryParams.current);
    if (res.success) {
      setDataSource(res?.data?.list || []);
      setTotal(res?.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // 查询
  const search = async () => {
    const res = await form.validateFields();
    res.pageNum = 1;
    if (res?.date?.length === 2) {
      res.startDate = moment(res.date?.[0]._d).format('YYYY-MM-DD');
      res.endDate = moment(res.date?.[1]._d).format('YYYY-MM-DD');
    }
    delete res.date;
    queryParams.current = { ...queryParams.current, ...res };

    setPageIndex(1);
    handlerGetLists();
  };

  // 分页
  const onChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      if (size !== pageSize) {
        queryParams.current.pageNum = 1;
        queryParams.current.pageSize = size;
        setPageIndex(1);
        setPageSize(size);
      } else {
        setPageIndex(page);
        queryParams.current.pageNum = page;
      }
      handlerGetLists();
    },
    [pageSize],
  );

  // 导出
  const handleUpload = async () => {
    setUpload(true);
    console.log(queryParams.current);
    const res = await statisticsExport(queryParams.current);
    if (res?.data) {
      const nowTime = moment().format('YYYYMMDDHHmmss');
      const name = `租户+供应商线路_${nowTime}.xlsx`;
      downloadCustomNameFile(res.data, name);
    }
    setUpload(false);
  };

  // 筛选
  const handleTableChange = (pagination, filters, sorter) => {
    console.log(pagination, filters, sorter);
    if (!!sorter?.order) {
      queryParams.current.sort = 1;
      queryParams.current.sortParam = sorter?.field;
      queryParams.current.sortAsc = sorter?.order === 'descend' ? -1 : 1;
    } else {
      queryParams.current.sort = undefined;
      queryParams.current.sortParam = undefined;
      queryParams.current.sortAsc = undefined;
    }
    handlerGetLists();
  };

  useEffect(() => {
    form.setFieldValue('date', [
      moment().subtract(1, 'days'),
      moment().subtract(1, 'days'),
    ]);
    if (ref.current) {
      // @ts-ignore
      setHeight(ref.current.clientHeight);
    }
  }, []);

  useEffect(() => {
    // 获取租户列表后初始化数据
    if (tenantOpts?.length > 0) {
      const curTenant = tenantOpts[0];
      form.setFieldsValue({ tenantCode: curTenant?.value });
      queryParams.current.tenantCode = curTenant?.value;
    }
    handlerGetLists();
  }, [tenantOpts]);

  return (
    <div className={styles.historyTable}>
      <div className={styles.search}>
        <Form form={form} layout="inline">
          <Form.Item name="tenantCode" className={styles.formItem}>
            <Select
              placeholder="请选择租户"
              showSearch
              optionFilterProp="label"
              options={tenantOpts}
            />
          </Form.Item>
          <Form.Item name="name" className={styles.formItem}>
            <Input placeholder="线路名称" allowClear />
          </Form.Item>
          <Form.Item name="supplierName" className={styles.formItem}>
            <Input placeholder="供应商名称" allowClear />
          </Form.Item>
          <Form.Item
            name="date"
            rules={[{ required: true, message: '' }]}
            className={styles.rangeDate}
          >
            <RangePicker
              allowClear={false}
              disabledDate={(current) => {
                return current && current > moment().subtract(1, 'days');
              }}
            />
          </Form.Item>
          <Button type="primary" onClick={search}>
            搜索
          </Button>
        </Form>
        {access?.authCodeList?.includes('Call-Line-Linemonitor-Export') && (
          <Button
            type="primary"
            icon={<DownloadOutlined />}
            loading={upload}
            onClick={handleUpload}
          >
            导出
          </Button>
        )}
      </div>
      <div className={styles.table} ref={ref}>
        <Table
          columns={multipleHistoryColumns}
          dataSource={dataSource}
          rowKey={() => uuidv1()}
          scroll={{ x: 2050, y: height }}
          onChange={handleTableChange}
          pagination={false}
          loading={tableLoading}
        />
      </div>
      <div className={styles.pagination}>
        <Pagination
          current={pageIndex}
          showSizeChanger={true}
          pageSize={pageSize}
          total={total}
          showTotal={(total) => `总共 ${total} 条`}
          onChange={onChange}
        />
      </div>
    </div>
  );
};

export default MultipleLineHistoryTable;
