import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import {
  Button,
  Drawer,
  Form,
  Select,
  DatePicker,
  Table,
  Space,
  Empty,
  message,
} from 'antd';
import { Chart } from '@antv/g2';
import RingChart from '@/components/RingChart';
import styles from './index.less';
import { abnormalOpt, timeOptions } from './config';
import moment from 'moment';
import {
  CaretDownOutlined,
  VerticalAlignBottomOutlined,
} from '@ant-design/icons';
import {
  getLineAbnormal,
  getLineCallOut,
  getLineCallPie,
  getLineCallProcess,
  ICallOut,
  ILineAbnormal,
  ILineInfo,
  ILineProcess,
  ILineProvince,
  statisticsCallResultExport,
  statisticsCityExport,
  statisticsProvince,
} from '@/api/lineMonitor';
import { getTenantList, ITenantInfo } from '@/api/tenant';
import { RangePickerProps } from 'antd/es/date-picker';
import { useModel } from '@umijs/max';
import { ChartDataType } from '@/pages/taskCenter/components/SubTask/components/WorkingStatistics/components/Charts/config';
import { accMul, convertPer, httpReplace, isIntegerBarringZero } from '@/utils';
import SelectLimit from '@/components/SelectLimit';

const { RangePicker } = DatePicker;

interface PropsType {
  open: boolean;
  info: ILineInfo;
  closeDrawer: () => void;
  type: 'tenantToday' | 'tenantHistory';
  date?: string[];
}

const ChartDrawer: React.FC<PropsType> = ({
  open,
  closeDrawer,
  info,
  date,
}) => {
  const processChartRef = useRef(null);
  const abnormalChartRef = useRef(null);
  const callOutChartRef = useRef(null);

  const isFirst = useRef(true);
  const [form] = Form.useForm();
  const [tenantData, setTenantList] = useState<ITenantInfo[]>([]);
  const [selectTenantId, setSelectTenantId] = useState<undefined | string>();
  const [selectData, setSelectData] = useState<string[]>();
  const [dataTable, setDataTable] = useState<ILineProvince[]>([]);
  const [isToDay, setIsToDay] = useState(true);
  const [pageIndex, setPageIndex] = useState(1);
  const [pageSize, setPageSize] = useState(100);
  const [total, setTotal] = useState(0);
  const [callOurData, setCallOurData] = useState<ICallOut[]>([]);
  const [callOurInterval, setCallOurInterval] = useState(5);
  const [processData, setProcessData] = useState<ILineProcess[]>([]);
  const [processinterval, setProcessinterval] = useState(5);
  const [processKeys, setProcessKeys] = useState<number[]>([18]);
  const [abnormalData, setAbnormalData] = useState<ILineAbnormal[]>([]);
  const [abnormalinterval, setAbnormalinterval] = useState(5);
  const [abnormalKeys, setAbnormalKeys] = useState<string[]>([
    'USER_NOT_SPEAK',
  ]);
  const [pieData, setPieData] = useState<ChartDataType>([]);
  const [callNumPie, setCallNumPie] = useState(0);
  const { callResultList, handleCallResultList } = useModel('speech');
  const [concurrency, setConcurrency] = useState('');

  // 获取送呼数量折线图
  const handleCallOut = useCallback(
    async ({ tenantId, time }: { tenantId?: string; time?: string[] }) => {
      if (!tenantId && !selectTenantId) return;
      const param = {
        statisticsType: 0,
        statisticKey: tenantId || selectTenantId,
        startDate: time?.[0] || selectData?.[0] || undefined,
        endDate: time?.[1] || selectData?.[1] || undefined,
        interval: callOurInterval,
        pageNum: 1,
        pageSize: 999,
      };
      const res = await getLineCallOut(param);
      if (res?.success) {
        let _data = [];
        if (res.data?.length) {
          res.data.forEach((item) => {
            if (item?.statisticsDate.indexOf(' ') > -1)
              item.statisticsDate = moment(item.statisticsDate).format('HH:mm');
            _data.push({
              ...item,
              value: item.totalCall,
            });
          });
        }
        setCallOurData(_data);
      }
    },
    [callOurInterval, selectTenantId, selectData],
  );

  // 获取外呼结果折线图
  const handleProcess = useCallback(
    async ({ tenantId, time }: { tenantId?: string; time?: string[] }) => {
      if (!tenantId && !selectTenantId) return;
      const param = {
        statisticsType: 0,
        statisticKey: tenantId || selectTenantId,
        startDate: time?.[0] || selectData?.[0] || undefined,
        endDate: time?.[1] || selectData?.[1] || undefined,
        interval: processinterval,
        processStatisticKeyList: processKeys,
        processStatisticKeyType: 0,
        pageNum: 1,
        pageSize: 999,
      };
      const res = await getLineCallProcess(param);
      if (res?.success) {
        let _data = [];
        if (res.data?.length) {
          res.data.forEach((item) => {
            if (item?.statisticsDate.indexOf(' ') > -1)
              item.statisticsDate = moment(item.statisticsDate).format('HH:mm');
            _data.push({
              ...item,
              value: item.callsRate
                ? Number(accMul(item.callsRate, 100).toFixed(2))
                : 0,
            });
          });
        }
        setProcessData(_data);
      }
    },
    [processinterval, processKeys, selectTenantId, selectData],
  );

  // 获取异常指标折线图
  const handleAbnormal = useCallback(
    async ({ tenantId, time }: { tenantId?: string; time?: string[] }) => {
      if (!tenantId && !selectTenantId) return;
      const param = {
        statisticsType: 0,
        statisticKey: tenantId || selectTenantId,
        startDate: time?.[0] || selectData?.[0] || undefined,
        endDate: time?.[1] || selectData?.[1] || undefined,
        interval: abnormalinterval,
        processStatisticKeyList: abnormalKeys,
        processStatisticKeyType: 1,
        pageNum: 1,
        pageSize: 999,
      };
      const res = await getLineAbnormal(param);
      if (res?.success) {
        let _data = [];
        if (res.data?.length) {
          res.data.forEach((item) => {
            if (item?.statisticsDate.indexOf(' ') > -1)
              item.statisticsDate = moment(item.statisticsDate).format('HH:mm');
            _data.push({
              ...item,
              value: item.callsRate
                ? Number(accMul(item.callsRate, 100).toFixed(2))
                : 0,
            });
          });
        }
        setAbnormalData(_data);
      }
    },
    [abnormalinterval, abnormalKeys, selectTenantId, selectData],
  );

  // 获取外呼结果饼图
  const handleProcessPie = useCallback(
    async ({ tenantId, time }: { tenantId?: string; time?: string[] }) => {
      if (!tenantId && !selectTenantId) return;
      const param = {
        statisticsType: 0,
        statisticKey: tenantId || selectTenantId,
        startDate: time?.[0] || selectData?.[0] || undefined,
        endDate: time?.[1] || selectData?.[1] || undefined,
        pageNum: 1,
        pageSize: 999,
      };
      const res = await getLineCallPie(param);
      if (res?.success) {
        let _data = [];
        if (res.data?.list?.length) {
          _data = res.data.list
            ?.filter((item) => !!item.num)
            ?.map((item) => ({
              item: item.desc,
              count: item.num,
              percent: item.rate,
            }));
        }
        setCallNumPie(res.data?.totalCall);
        setPieData(_data);
        setConcurrency(
          `${res.data?.allocatedConcurrency || 0}/${
            res.data?.totalConcurrency || 0
          }`,
        );
      }
    },
    [selectTenantId, selectData],
  );

  // 获取省市分布
  const handleProvince = useCallback(
    async ({
      tenantId,
      time,
      num,
      size,
    }: {
      tenantId?: string;
      time?: string[];
      num?: number;
      size?: number;
    }) => {
      const _num = num || pageIndex;
      const _size = size || pageSize;
      const param = {
        statisticsType: 0,
        statisticKey: tenantId || selectTenantId,
        startDate: time?.[0] || selectData?.[0] || undefined,
        endDate: time?.[1] || selectData?.[1] || undefined,
        pageNum: _num,
        pageSize: _size,
      };
      const res = await statisticsProvince(param);
      if (res?.success) {
        res.data?.statistics?.forEach((item, index) => {
          item.index =
            Number(accMul(Number(_num) - 1, Number(_size))) + index + 1;
        });
        setDataTable(res.data?.statistics);
        setTotal(res.data?.totalCall);
      }
    },
    [pageIndex, pageSize, selectTenantId, selectData],
  );

  // 搜索
  const search = async (isDay?: boolean) => {
    const res = await form.validateFields();
    let time = [];
    if (isFirst.current) {
      time = [...date];
      const todayDate = moment().format('YYYY-MM-DD');
      const _toDay = time?.[0] === todayDate && time?.[1] === todayDate;
      setIsToDay(_toDay);
      if (_toDay) form.setFieldValue('time', []);
      isFirst.current = false;
    } else {
      if (!isDay && !isToDay && !res?.time?.length)
        return message.error('请先选择时间');
      if (isDay || isToDay) {
        time = [moment().format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')];
      } else {
        if (res?.time?.length)
          time = [
            moment(res.time?.[0]._d).format('YYYY-MM-DD'),
            moment(res.time?.[1]._d).format('YYYY-MM-DD'),
          ];
      }
    }
    setSelectTenantId(res.statisticKey);
    setSelectData(time);
    handleCallOut({ tenantId: res.statisticKey, time });
    handleProcess({ tenantId: res.statisticKey, time });
    handleAbnormal({ tenantId: res.statisticKey, time });
    handleProcessPie({ tenantId: res.statisticKey, time });
    handleProvince({ tenantId: res.statisticKey, time, num: 1 });
    setPageIndex(1);
  };

  const columns = [
    {
      title: '排名',
      dataIndex: 'index',
    },
    {
      title: '省',
      dataIndex: 'province',
    },
    {
      title: '市',
      dataIndex: 'city',
    },
    {
      title: '外呼数',
      dataIndex: 'totalCall',
    },
    {
      title: '占比',
      dataIndex: 'totalCallRate',
      render: (text: number) => `${convertPer(text)}%`,
    },
    {
      title: '接通数',
      dataIndex: 'totalPut',
    },
    {
      title: '接通率',
      dataIndex: 'totalPutRate',
      render: (text: number) => `${convertPer(text)}%`,
    },
  ];

  // 获取租户列表
  const handleTenantList = useCallback(async () => {
    const res = await getTenantList({ pageNum: 1, pageSize: 999 });
    if (res?.data) setTenantList(res.data);
  }, []);

  // 不可用日期
  const disabledDate: RangePickerProps['disabledDate'] = useCallback(
    (current) => {
      return (
        current &&
        (current > moment().subtract(1, 'days') ||
          moment().subtract(30, 'days') > current)
      );
    },
    [],
  );

  // 分页
  const onChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      let _num = page;
      let _size = size;
      if (size !== pageSize) {
        setPageIndex(1);
        setPageSize(size);
        _num = 1;
        _size = size;
      } else {
        setPageIndex(page);
        _num = page;
      }
      handleProvince({ num: _num, size: _size });
    },
    [pageSize, pageIndex, selectTenantId, selectData],
  );

  // 外呼结果导出
  const handleCallResultExport = useCallback(async () => {
    const param = {
      statisticsType: 0,
      statisticKey: selectTenantId,
      startDate: selectData?.[0] || undefined,
      endDate: selectData?.[1] || undefined,
      pageNum: 1,
      pageSize: 999,
    };
    const dest = message.loading('正在导出');
    const res = await statisticsCallResultExport(param);
    if (res?.success && res?.data?.ossUrl) {
      let elink = document.createElement('a');
      elink.style.display = 'none';
      elink.href = httpReplace(res?.data.ossUrl);
      // elink.download = '话术列表';
      document.body.appendChild(elink);
      elink.click();
      setTimeout(() => {
        document.body.removeChild(elink);
      }, 300);
    }
    dest?.();
  }, [selectTenantId, selectData]);

  // 省市导出
  const handleCityExport = useCallback(async () => {
    const param = {
      statisticsType: 0,
      statisticKey: selectTenantId,
      startDate: selectData?.[0] || undefined,
      endDate: selectData?.[1] || undefined,
      pageNum: 1,
      pageSize: 999,
    };
    const dest = message.loading('正在导出');
    const res = await statisticsCityExport(param);
    if (res?.success && res?.data?.ossUrl) {
      let elink = document.createElement('a');
      elink.style.display = 'none';
      elink.href = httpReplace(res?.data.ossUrl);
      // elink.download = '话术列表';
      document.body.appendChild(elink);
      elink.click();
      setTimeout(() => {
        document.body.removeChild(elink);
      }, 300);
    }
    dest?.();
  }, [selectTenantId, selectData]);

  useEffect(() => {
    handleTenantList();
    if (!callResultList?.length) handleCallResultList();
  }, []);

  useEffect(() => {
    if (open && !processChartRef.current) {
      processChartRef.current = new Chart({
        container: 'lineProcess',
        autoFit: true,
        height: 300,
        padding: [40, 80, 80, 80],
      });
    }
    if (open && !abnormalChartRef.current) {
      abnormalChartRef.current = new Chart({
        container: 'lineAbnormal',
        autoFit: true,
        height: 300,
        padding: [40, 80, 80, 80],
      });
    }
    if (open && !callOutChartRef.current) {
      callOutChartRef.current = new Chart({
        container: 'callOutProcess',
        autoFit: true,
        height: 300,
        padding: [40, 80, 80, 80],
      });
    }
  }, [open]);

  useEffect(() => {
    if (info?.statisticKey) {
      setSelectTenantId(info.statisticKey);
      form.setFieldValue('statisticKey', Number(info?.statisticKey));
      form.setFieldValue('time', [moment(date?.[0]), moment(date?.[1])]);
      search();
    }
  }, [info]);

  useEffect(() => {
    handleCallOut({});
  }, [callOurInterval]);

  useEffect(() => {
    handleProcess({});
  }, [processinterval, processKeys]);

  useEffect(() => {
    handleAbnormal({});
  }, [abnormalinterval, abnormalKeys]);

  useEffect(() => {
    if (callOutChartRef.current) {
      callOutChartRef.current.clear(); // 清除画布
      callOutChartRef.current.data(callOurData);
      callOutChartRef.current.scale({
        statisticsDate: {
          range: [0, 1],
          type: 'cat',
        },
        totalCall: {
          min: 0,
          nice: true,
        },
      });
      // callOutChartRef.current.axis('statisticsDate', {label: {offset: 30}})
      callOutChartRef.current.tooltip({
        showCrosshairs: true,
        shared: true,
        customItems: (items) => {
          const _list = [];
          items?.forEach((i) => {
            _list.push({
              ...i,
              name: `送呼数量`,
            });
          });
          return _list;
        },
      });
      callOutChartRef.current.line().position('statisticsDate*totalCall');
      // .color('statisticsDate');
      callOutChartRef.current.point().position('statisticsDate*totalCall');
      // .color('statisticsDate');
      callOutChartRef.current.render();
    }
  }, [callOurData]);

  useEffect(() => {
    if (processChartRef.current) {
      processChartRef.current.clear(); // 清除画布
      processChartRef.current.data(processData);
      processChartRef.current.scale({
        statisticsDate: {
          range: [0, 1],
        },
        value: {
          nice: true,
        },
      });
      processChartRef.current.tooltip({
        showCrosshairs: true,
        shared: true,
        title: (title) => `${title}  各占比`,
        customItems: (items) => {
          const _list = [];
          items?.forEach((i) => {
            _list.push({
              ...i,
              value: `${i.value}%  \xa0\xa0\xa0 ${i?.data?.callsCount}`,
            });
          });
          return _list;
        },
      });
      // processChartRef.current.axis('statisticsDate', {
      //   type: 'timeCat',
      //   mask: 'YYYY-MM-DD HH:mm:ss', // 用于解析时间字符串的格式化串
      //   formatter: val => moment(val).format('YYYY-MM-DD HH:mm:ss'),// 将时间戳转换为字符串
      //   // label: {
      //   //   formatter: val => moment(val).format('YYYY-MM-DD HH:mm:ss'),
      //   // },
      // });
      processChartRef.current.axis('value', {
        label: {
          formatter: (val) => {
            if (val === '0' || val === 0 || isIntegerBarringZero(val))
              return val + ' %';
            return Number(val).toFixed(2) + ' %';
          },
        },
      });
      processChartRef.current
        .line()
        .position('statisticsDate*value')
        .color('calloutResultDesc');
      processChartRef.current
        .point()
        .position('statisticsDate*value')
        .color('calloutResultDesc');
      processChartRef.current.render();
    }
  }, [processData]);

  useEffect(() => {
    if (abnormalChartRef.current) {
      abnormalChartRef.current.clear(); // 清除画布
      abnormalChartRef.current.data(abnormalData);
      abnormalChartRef.current.scale({
        statisticsDate: {
          range: [0, 1],
        },
        value: {
          nice: true,
        },
      });
      abnormalChartRef.current.tooltip({
        showCrosshairs: true,
        shared: true,
        title: (title) => `${title}  各占比`,
        customItems: (items) => {
          const _list = [];
          items?.forEach((i) => {
            _list.push({
              ...i,
              value: `${i.value}%  \xa0\xa0\xa0 ${i?.data?.callsCount}`,
            });
          });
          return _list;
        },
      });
      abnormalChartRef.current.axis('value', {
        label: {
          formatter: (val) => {
            if (val === '0' || val === 0 || isIntegerBarringZero(val))
              return val + ' %';
            return Number(val).toFixed(2) + ' %';
          },
        },
      });

      abnormalChartRef.current
        .line()
        .position('statisticsDate*value')
        .color('abnormalTypeDesc');
      abnormalChartRef.current
        .point()
        .position('statisticsDate*value')
        .color('abnormalTypeDesc');
      abnormalChartRef.current.render();
    }
  }, [abnormalData]);

  return (
    <>
      <Drawer
        title=""
        closable={false}
        placement="right"
        onClose={closeDrawer}
        open={open}
        width="70%"
        height="100vh"
        className={styles.draw}
        destroyOnClose
      >
        <Form form={form}>
          <Space align="start">
            <Form.Item
              name="statisticKey"
              label="租户"
              rules={[{ required: true, message: '' }]}
            >
              <Select
                className={styles.searchItem}
                allowClear
                fieldNames={{ label: 'name', value: 'code' }}
                options={tenantData}
              />
            </Form.Item>
            <Button
              type={isToDay ? 'primary' : 'default'}
              onClick={() => {
                setIsToDay(true);
                form.setFieldValue('time', []);
                setTimeout(() => {
                  search(true);
                }, 0);
              }}
            >
              今日
            </Button>
            <Form.Item name="time">
              <RangePicker
                allowClear
                style={{ width: '260px' }}
                onChange={() => setIsToDay(false)}
                disabledDate={disabledDate}
              />
            </Form.Item>
            {isToDay && (
              <div style={{ margin: '4px' }}>
                实时并发/总并发: &nbsp;&nbsp;{concurrency}
              </div>
            )}
            <Form.Item>
              <Button type="primary" onClick={() => search()}>
                搜索
              </Button>
            </Form.Item>
          </Space>
        </Form>
        <h2>过程统计</h2>
        <div className={styles.searchWrap}>
          <div>送呼数量</div>
          {isToDay && (
            <div style={{ color: '#000' }}>
              计量单位：
              <Select
                style={{ width: 100 }}
                value={callOurInterval}
                bordered={false}
                options={timeOptions}
                suffixIcon={<CaretDownOutlined style={{ color: '#000' }} />}
                onChange={(val) => setCallOurInterval(val)}
              />
            </div>
          )}
        </div>
        <div id="callOutProcess" style={{ height: 300 }}></div>
        <div className={styles.searchWrap}>
          <div>
            外呼结果：
            <SelectLimit
              style={{ width: 120 }}
              max={5}
              value={processKeys}
              mode="multiple"
              maxTagCount="responsive"
              bordered={false}
              suffixIcon={<CaretDownOutlined style={{ color: '#000' }} />}
              options={callResultList}
              onChange={(val) => setProcessKeys(val)}
            />
            <CaretDownOutlined style={{ color: '#000' }} />
          </div>
          {isToDay && (
            <div>
              计量单位：
              <Select
                style={{ width: 100 }}
                value={processinterval}
                bordered={false}
                options={timeOptions}
                suffixIcon={<CaretDownOutlined style={{ color: '#000' }} />}
                onChange={(val) => setProcessinterval(val)}
              />
            </div>
          )}
        </div>
        {/* <Space size="large">
          <div className={styles.showTitle}>外呼数：9999</div>
          <div className={styles.showTitle}>接通数：9999</div>
          <div className={styles.showTitle}>接通率：9999</div>
        </Space> */}
        <div id="lineProcess" style={{ height: 300 }}></div>

        <div className={styles.searchWrap}>
          <div>
            异常指标：
            <SelectLimit
              style={{ width: 120 }}
              max={5}
              value={abnormalKeys}
              mode="multiple"
              maxTagCount="responsive"
              bordered={false}
              suffixIcon={<CaretDownOutlined style={{ color: '#000' }} />}
              options={abnormalOpt}
              onChange={(val) => setAbnormalKeys(val)}
            />
            <CaretDownOutlined style={{ color: '#000' }} />
          </div>
          {isToDay && (
            <div style={{ color: '#000' }}>
              计量单位：
              <Select
                style={{ width: 100 }}
                value={abnormalinterval}
                bordered={false}
                options={timeOptions}
                suffixIcon={<CaretDownOutlined style={{ color: '#000' }} />}
                onChange={(val) => setAbnormalinterval(val)}
              />
            </div>
          )}
        </div>
        {/* <Space size="large">
          <div className={styles.showTitle}>接通数：9999</div>
          <div className={styles.showTitle}>秒挂秒挂量：9999</div>
          <div className={styles.showTitle}>秒挂占比：9999</div>
        </Space> */}

        <div id="lineAbnormal" style={{ height: 300 }}></div>

        <div className={styles.third}>
          <div className={styles.left}>
            <h2>
              外呼结果&nbsp;&nbsp;
              <Button
                type="link"
                icon={<VerticalAlignBottomOutlined />}
                onClick={handleCallResultExport}
              >
                导出
              </Button>
            </h2>
            <div className={styles.ring}>
              <div style={{ width: '100%' }}>
                {!!pieData?.length ? (
                  <RingChart
                    data={pieData}
                    total={callNumPie}
                    title="外呼数"
                    container="linePie"
                    height={300}
                  />
                ) : (
                  <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                )}
              </div>
            </div>
          </div>
          <div className={styles.right}>
            <h2>
              省市分布&nbsp;&nbsp;
              <Button
                type="link"
                icon={<VerticalAlignBottomOutlined />}
                onClick={handleCityExport}
              >
                导出
              </Button>
            </h2>
            <div className={styles.table}>
              <Table
                columns={columns}
                dataSource={dataTable}
                scroll={{ y: 335, x: 600 }}
                rowKey={(record) => record.city}
                pagination={{
                  pageSize: pageSize,
                  showSizeChanger: true,
                  current: pageIndex,
                  total: total,
                  showTotal: (total) => `总共 ${total} 条`,
                  onChange: onChange,
                }}
              />
            </div>
          </div>
        </div>
      </Drawer>
    </>
  );
};
export default memo(ChartDrawer);
