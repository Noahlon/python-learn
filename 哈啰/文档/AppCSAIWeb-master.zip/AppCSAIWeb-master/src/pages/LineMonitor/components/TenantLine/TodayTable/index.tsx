import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Input, Table, Button, Pagination, Form } from 'antd';
import moment from 'moment';
import { v1 as uuidv1 } from 'uuid';
import styles from './index.less';
import TenantDrawer from '../TenantDrawer';
import { useAccess } from '@umijs/max';
import { getLine, ILineInfo } from '@/api/lineMonitor';
import { convertPer } from '@/utils';

const { Column, ColumnGroup } = Table;

const TodayTable: React.FC = () => {
  const queryParams = useRef({
    pageNum: 1,
    pageSize: 100,
    name: undefined,
    statisticsType: 0, // 租户
    startDate: moment().format('YYYY-MM-DD'),
    endDate: moment().format('YYYY-MM-DD'),
    sort: undefined,
    sortParam: undefined,
    sortAsc: undefined,
  });
  const ref = useRef();
  const access = useAccess();
  const [form] = Form.useForm();
  const [height, setHeight] = useState(null);
  const [open, setOpen] = useState(false);
  const [dataSource, setDataSource] = useState<ILineInfo[]>([]);
  const [curInfo, setCurInfo] = useState<ILineInfo>(undefined);
  const [tableLoading, setTableLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [pageIndex, setPageIndex] = useState(1);
  const [pageSize, setPageSize] = useState(100);
  const [date, setDate] = useState<string[]>([]);

  /**
   * api
   */
  const handlerGetLists = async () => {
    setTableLoading(true);
    setDate([queryParams.current.startDate, queryParams.current.endDate]);
    const res = await getLine(queryParams.current);
    if (res.success) {
      setDataSource(res?.data?.list || []);
      setTotal(res?.data?.totalRecord);
    }
    setTableLoading(false);
  };

  useEffect(() => {
    if (ref.current) {
      // @ts-ignore
      setHeight(ref.current.clientHeight);
    }
    handlerGetLists();
  }, []);

  // const closeDrawer = () => {
  //   setOpen(false);
  // };

  const search = async () => {
    const res = await form.validateFields();
    queryParams.current.name = res.name;
    queryParams.current.pageNum = 1;
    setPageIndex(1);
    handlerGetLists();
  };

  // 分页
  const onChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      if (size !== pageSize) {
        queryParams.current.pageNum = 1;
        queryParams.current.pageSize = size;
        setPageIndex(1);
        setPageSize(size);
      } else {
        setPageIndex(page);
        queryParams.current.pageNum = page;
      }
      handlerGetLists();
    },
    [pageSize],
  );

  // 弹框关闭
  const handleCloseDrawer = useCallback(() => {
    setOpen(false);
    setCurInfo(undefined);
  }, []);

  // 筛选
  const handleTableChange = (pagination, filters, sorter) => {
    console.log(pagination, filters, sorter);
    if (!!sorter?.order) {
      queryParams.current.sort = 1;
      queryParams.current.sortParam = sorter?.field;
      queryParams.current.sortAsc = sorter?.order === 'descend' ? -1 : 1;
    } else {
      queryParams.current.sort = undefined;
      queryParams.current.sortParam = undefined;
      queryParams.current.sortAsc = undefined;
    }
    handlerGetLists();
  };

  return (
    <div className={styles.todaytable}>
      <div style={{ padding: '0 20px 20px 20px' }}>
        <Form form={form} layout="inline">
          <Form.Item name="name">
            <Input
              placeholder="租户"
              style={{ width: '300px', marginRight: '20px' }}
              allowClear
            />
          </Form.Item>
          <Button type="primary" onClick={search}>
            搜索
          </Button>
        </Form>
      </div>
      <div className={styles.table} ref={ref}>
        {/* 51  3000 */}
        <Table
          dataSource={dataSource}
          scroll={{ x: 1000, y: height - 110 }}
          pagination={false}
          loading={tableLoading}
          rowKey={() => uuidv1()}
          onChange={handleTableChange}
          bordered
          rowClassName={useCallback(
            (record) => {
              if (curInfo?.statisticKey === record?.statisticKey)
                return styles.activity;
              return '';
            },
            [curInfo],
          )}
          onRow={(record: ILineInfo) => {
            return {
              onClick: () => {
                if (
                  access?.authCodeList?.includes('Call-Line-Linemonitor-Info')
                ) {
                  setCurInfo(record);
                  setOpen(true);
                }
              },
            };
          }}
        >
          <Column
            title="租户名称"
            dataIndex="tenantName"
            width={180}
            fixed="left"
            render={(text) => <a>{text}</a>}
          />
          <Column title="租户编号" dataIndex="tenantCode" width={120} />
          <Column
            title="锁定并发"
            dataIndex="totalConcurrency"
            width={120}
            sorter={true}
            sortDirections={['descend', 'ascend']}
          />
          <Column
            title="实时并发"
            dataIndex="allocatedConcurrency"
            width={120}
            sorter={true}
            sortDirections={['descend', 'ascend']}
          />
          <ColumnGroup title="外呼数">
            <Column
              title="近3min"
              dataIndex="totalCallRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="totalCall"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="接通数">
            <Column
              title="近3min"
              dataIndex="totalPutRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="totalPut"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="接通率">
            <Column
              title="近3min"
              dataIndex="putRateRealTime"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="putRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="未说话数">
            <Column
              title="近3min"
              dataIndex="totalNotUserSpeakRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="totalNotUserSpeak"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="未说话占比">
            <Column
              title="近3min"
              dataIndex="notUserSpeakRateRealTime"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="notUserSpeakRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="秒挂通话数">
            <Column
              title="近3min"
              dataIndex="totalShortCallDurationRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="totalShortCallDuration"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="秒挂通话占比">
            <Column
              title="近3min"
              dataIndex="shortCallDurationRateRealTime"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="shortCallDurationRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="限频数">
            <Column
              title="近3min"
              dataIndex="totalRateLimitRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="totalRateLimit"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="限频占比">
            <Column
              title="近3min"
              dataIndex="rateLimitRateRealTime"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="rateLimitRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="黑名单数">
            <Column
              title="近3min"
              dataIndex="totalBlackRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="totalBlack"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="黑名单占比">
            <Column
              title="近3min"
              dataIndex="totalBlackRateRealTime"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="totalBlackRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="无可用并发数">
            <Column
              title="近3min"
              dataIndex="noUsableConcurrenRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="noUsableConcurren"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="无可用并发占比">
            <Column
              title="近3min"
              dataIndex="noUsableConcurrenRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="noUsableConcurrenRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="线路拦截名单数">
            <Column
              title="近3min"
              dataIndex="lineInterceptNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="lineInterceptNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="线路拦截率">
            <Column
              title="近3min"
              dataIndex="lineInterceptNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="lineInterceptNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="平台限频数">
            <Column
              title="近3min"
              dataIndex="callFrequencyLimitRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="callFrequencyLimit"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="平台限频率">
            <Column
              title="近3min"
              dataIndex="callFrequencyLimitRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="callFrequencyLimitRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="平台黑名单数">
            <Column
              title="近3min"
              dataIndex="callblackListLimitRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="callblackListLimit"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="平台黑名单率">
            <Column
              title="近3min"
              dataIndex="callblackListLimitRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="callblackListLimitRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="外部黑名单数">
            <Column
              title="近3min"
              dataIndex="outCallblackListLimitRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="outCallblackListLimit"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="外部黑名单占比">
            <Column
              title="近3min"
              dataIndex="outCallblackListLimitRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="outCallblackListLimitRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="A类名单数">
            <Column
              title="近3min"
              dataIndex="aIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="aIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="B类名单数">
            <Column
              title="近3min"
              dataIndex="bIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="bIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="C类名单数">
            <Column
              title="近3min"
              dataIndex="cIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="cIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="D类名单数">
            <Column
              title="近3min"
              dataIndex="dIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="dIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="E类名单数">
            <Column
              title="近3min"
              dataIndex="eIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="eIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="F类名单数">
            <Column
              title="近3min"
              dataIndex="fIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="fIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="G类名单数">
            <Column
              title="近3min"
              dataIndex="gIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="gIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="H类名单数">
            <Column
              title="近3min"
              dataIndex="hIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="hIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="I类名单数">
            <Column
              title="近3min"
              dataIndex="iIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="iIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>

          <ColumnGroup title="L类名单数">
            <Column
              title="近3min"
              dataIndex="lIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="lIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="M类名单数">
            <Column
              title="近3min"
              dataIndex="mIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="mIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="未知名单数">
            <Column
              title="近3min"
              dataIndex="unknownIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="unknownIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="A类占比">
            <Column
              title="近3min"
              dataIndex="aIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="aIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="B类占比">
            <Column
              title="近3min"
              dataIndex="bIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="bIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="C类占比">
            <Column
              title="近3min"
              dataIndex="cIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="cIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="D类占比">
            <Column
              title="近3min"
              dataIndex="dIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="dIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="E类占比">
            <Column
              title="近3min"
              dataIndex="eIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="eIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="F类占比">
            <Column
              title="近3min"
              dataIndex="fIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="fIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="G类占比">
            <Column
              title="近3min"
              dataIndex="gIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="gIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="H类占比">
            <Column
              title="近3min"
              dataIndex="hIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="hIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="I类占比">
            <Column
              title="近3min"
              dataIndex="iIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="iIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="L类占比">
            <Column
              title="近3min"
              dataIndex="lIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="lIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="M类占比">
            <Column
              title="近3min"
              dataIndex="mIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="mIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="未知占比">
            <Column
              title="近3min"
              dataIndex="unknownIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="unknownIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="ADE类名单数">
            <Column
              title="近3min"
              dataIndex="adeIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="adeIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="ADE类占比">
            <Column
              title="近3min"
              dataIndex="adeIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="adeIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="AB类名单数">
            <Column
              title="近3min"
              dataIndex="abIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="abIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="AB类占比">
            <Column
              title="近3min"
              dataIndex="abIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="abIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="AD类名单数">
            <Column
              title="近3min"
              dataIndex="adIntentNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="adIntentNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="AD类占比">
            <Column
              title="近3min"
              dataIndex="adIntentNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="adIntentNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="超时名单数">
            <Column
              title="近3min"
              dataIndex="timeoutNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="timeoutNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="超时占比">
            <Column
              title="近3min"
              dataIndex="timeoutNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="timeoutNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="接听助理名单数">
            <Column
              title="近3min"
              dataIndex="answeringAssistantNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="answeringAssistantNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="接听助理占比">
            <Column
              title="近3min"
              dataIndex="answeringAssistantNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="answeringAssistantNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="运营商提示音名单数">
            <Column
              title="近3min"
              dataIndex="operatorPromptSoundNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="operatorPromptSoundNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="运营商提示音占比">
            <Column
              title="近3min"
              dataIndex="operatorPromptSoundNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="operatorPromptSoundNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="有交互名单数">
            <Column
              title="近3min"
              dataIndex="interactiveNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="interactiveNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="有交互名单占比">
            <Column
              title="近3min"
              dataIndex="interactiveNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="interactiveNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="平均说话次数">
            <Column
              title="近3min"
              dataIndex="speekAvgRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="speekAvg"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="有说话名单数">
            <Column
              title="近3min"
              dataIndex="speekNumRealTime"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="speekNum"
              width={130}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
          <ColumnGroup title="有说话占比">
            <Column
              title="近3min"
              dataIndex="speekNumRealTimeRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
            <Column
              title="今日"
              dataIndex="speekNumRate"
              width={130}
              render={(text: string) => `${convertPer(text)}%`}
              sorter={true}
              sortDirections={['descend', 'ascend']}
            />
          </ColumnGroup>
        </Table>
      </div>
      <div className={styles.pagination}>
        <Pagination
          current={pageIndex}
          showSizeChanger={true}
          pageSize={pageSize}
          total={total}
          showTotal={(total) => `总共 ${total} 条`}
          onChange={onChange}
        />
      </div>
      {open && (
        <TenantDrawer
          open={open}
          info={curInfo}
          closeDrawer={handleCloseDrawer}
          type="tenantToday"
          date={date}
        />
      )}
    </div>
  );
};

export default TodayTable;
