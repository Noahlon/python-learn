import { ILineInfo } from '@/api/lineMonitor';
import { convertPer } from '@/utils';
import { ColumnsType } from 'antd/es/table';

interface BaseObj {
  dataIndex: string;
  sorter: boolean;
  sortDirections: ('descend' | 'ascend' | null)[];
  render?: (res: number | undefined) => string | number | undefined;
}

export const bigCateOptions = [
  {
    label: '普通',
    value: 1,
  },
  {
    label: '认证',
    value: 2,
  },
];

export const smallCateOptions = [
  {
    label: '小号',
    value: 1,
  },
  {
    label: '固话',
    value: 2,
  },
  {
    label: '混线',
    value: 3,
  },
  {
    label: '品牌认证',
    value: 4,
  },
  {
    label: '中性认证',
    value: 5,
  },
  {
    label: '特殊号段',
    value: 6,
  },
];

const getBaseChildObj = (key: string, isRate = false) => {
  const obj: BaseObj = {
    dataIndex: key,
    sorter: true,
    sortDirections: ['descend', 'ascend'],
  };
  if (isRate) {
    obj.render = (value: number | undefined) => {
      if (value === undefined) return '';
      return convertPer(value) + '%';
    };
  }
  return obj;
};

export const multipleTodayColumns: ColumnsType<ILineInfo> = [
  {
    title: '线路名称',
    dataIndex: 'lineName',
    fixed: 'left',
    width: 260,
  },
  {
    title: '租户名称',
    dataIndex: 'tenantName',
    width: 180,
  },
  {
    title: '主叫号码',
    dataIndex: 'callingNumber',
    width: 160,
  },
  {
    title: '供应商名称',
    dataIndex: 'supplierName',
    width: 200,
  },
  {
    title: '线路大类',
    dataIndex: 'lineCategory',
    width: 130,
    render: (text: number) =>
      bigCateOptions?.find((item) => item.value === text)?.label,
  },
  {
    title: '线路小类',
    dataIndex: 'lineSubCategory',
    width: 130,
    render: (text: number) =>
      smallCateOptions?.find((item) => item.value === text)?.label,
  },
  {
    title: '总并发',
    dataIndex: 'totalConcurrency',
    width: 130,
  },
  {
    title: '实时并发',
    dataIndex: 'allocatedConcurrency',
    width: 130,
  },
  {
    title: '外呼名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('totalCallRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('totalCall'),
      },
    ],
  },
  {
    title: '接通数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('totalPutRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('totalPut'),
      },
    ],
  },
  {
    title: '接通率',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('putRateRealTime', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('putRate', true),
      },
    ],
  },

  {
    title: '未说话数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('totalNotUserSpeakRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('totalNotUserSpeak'),
      },
    ],
  },
  {
    title: '未说话占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('notUserSpeakRateRealTime', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('notUserSpeakRate', true),
      },
    ],
  },

  {
    title: '秒挂通话数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('totalShortCallDurationRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('totalShortCallDuration'),
      },
    ],
  },
  {
    title: '秒挂通话占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('shortCallDurationRateRealTime', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('shortCallDurationRate', true),
      },
    ],
  },
  {
    title: '平均通话时长',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('avgDurationCallRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('avgDurationCall'),
      },
    ],
  },
  {
    title: 'A类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('aIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('aIntentNum'),
      },
    ],
  },
  {
    title: 'B类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('bIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('bIntentNum'),
      },
    ],
  },
  {
    title: 'C类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('cIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('cIntentNum'),
      },
    ],
  },
  {
    title: 'D类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('dIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('dIntentNum'),
      },
    ],
  },
  {
    title: 'E类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('eIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('eIntentNum'),
      },
    ],
  },
  {
    title: 'F类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('fIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('fIntentNum'),
      },
    ],
  },
  {
    title: 'G类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('gIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('gIntentNum'),
      },
    ],
  },
  {
    title: 'H类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('hIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('hIntentNum'),
      },
    ],
  },
  {
    title: 'I类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('iIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('iIntentNum'),
      },
    ],
  },
  {
    title: 'L类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('lIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('lIntentNum'),
      },
    ],
  },
  {
    title: 'M类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('mIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('mIntentNum'),
      },
    ],
  },
  {
    title: '未知名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('unknownIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('unknownIntentNum'),
      },
    ],
  },
  {
    title: 'A类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('aIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('aIntentNumRate', true),
      },
    ],
  },
  {
    title: 'B类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('bIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('bIntentNumRate', true),
      },
    ],
  },
  {
    title: 'C类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('cIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('cIntentNumRate', true),
      },
    ],
  },
  {
    title: 'D类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('dIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('dIntentNumRate', true),
      },
    ],
  },
  {
    title: 'E类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('eIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('eIntentNumRate', true),
      },
    ],
  },
  {
    title: 'F类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('fIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('fIntentNumRate', true),
      },
    ],
  },
  {
    title: 'G类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('gIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('gIntentNumRate', true),
      },
    ],
  },
  {
    title: 'H类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('hIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('hIntentNumRate', true),
      },
    ],
  },
  {
    title: 'I类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('iIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('iIntentNumRate', true),
      },
    ],
  },
  {
    title: 'L类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('lIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('lIntentNumRate', true),
      },
    ],
  },
  {
    title: 'M类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('mIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('mIntentNumRate', true),
      },
    ],
  },
  {
    title: '未知占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('unknownIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('unknownIntentNumRate', true),
      },
    ],
  },
  {
    title: 'ADE类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('adeIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('adeIntentNum'),
      },
    ],
  },
  {
    title: 'ADE类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('adeIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('adeIntentNumRate', true),
      },
    ],
  },
  {
    title: 'AB类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('abIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('abIntentNum'),
      },
    ],
  },
  {
    title: 'AB类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('abIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('abIntentNumRate', true),
      },
    ],
  },
  {
    title: 'AD类名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('adIntentNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('adIntentNum'),
      },
    ],
  },
  {
    title: 'AD类占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('adIntentNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('adIntentNumRate', true),
      },
    ],
  },
  {
    title: '超时名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('timeoutNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('timeoutNum'),
      },
    ],
  },
  {
    title: '超时占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('timeoutNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('timeoutNumRate', true),
      },
    ],
  },
  {
    title: '接听助理名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('answeringAssistantNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('answeringAssistantNum'),
      },
    ],
  },
  {
    title: '接听助理占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('answeringAssistantNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('answeringAssistantNumRate', true),
      },
    ],
  },
  {
    title: '运营商提示音名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('operatorPromptSoundNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('operatorPromptSoundNum'),
      },
    ],
  },
  {
    title: '运营商提示音占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('operatorPromptSoundNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('operatorPromptSoundNumRate', true),
      },
    ],
  },
  {
    title: '有交互名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('interactiveNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('interactiveNum'),
      },
    ],
  },
  {
    title: '有交互名单占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('interactiveNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('interactiveNumRate', true),
      },
    ],
  },
  {
    title: '平均说话次数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('speekAvgRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('speekAvg'),
      },
    ],
  },
  {
    title: '有说话名单数',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('speekNumRealTime'),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('speekNum'),
      },
    ],
  },
  {
    title: '有说话占比',
    children: [
      {
        title: '近3min',
        width: 130,
        ...getBaseChildObj('speekNumRealTimeRate', true),
      },
      {
        title: '今日',
        width: 130,
        ...getBaseChildObj('speekNumRate', true),
      },
    ],
  },
];

export const multipleHistoryColumns: ColumnsType<ILineInfo> = [
  {
    title: '日期',
    dataIndex: 'statisticsDate',
    width: 130,
    fixed: 'left',
  },
  {
    title: '租户名称',
    dataIndex: 'tenantName',
    width: 180,
  },
  {
    title: '线路名称',
    dataIndex: 'lineName',
    width: 260,
  },
  {
    title: '主叫号码',
    dataIndex: 'callingNumber',
    width: 150,
  },
  {
    title: '供应商名称',
    dataIndex: 'supplierName',
    width: 150,
  },
  {
    title: '线路大类',
    dataIndex: 'lineCategory',
    width: 130,
    render: (text: number) =>
      bigCateOptions?.find((item) => item.value === text)?.label,
  },
  {
    title: '线路小类',
    dataIndex: 'lineSubCategory',
    width: 130,
    render: (text: number) =>
      smallCateOptions?.find((item) => item.value === text)?.label,
  },
  {
    title: '计费单元',
    width: 130,
    ...getBaseChildObj('costUnit'),
  },
  {
    title: '通话时长',
    width: 130,
    ...getBaseChildObj('durationCall'),
  },
  {
    title: '平均通话时长',
    width: 150,
    ...getBaseChildObj('avgDurationCall'),
  },
  {
    title: '外呼名单数',
    width: 130,
    ...getBaseChildObj('totalCall'),
  },
  {
    title: '接通数',
    width: 130,
    ...getBaseChildObj('totalPut'),
  },
  {
    title: '接通率',
    width: 130,
    ...getBaseChildObj('putRate', true),
  },
  {
    title: '未说话数',
    width: 130,
    ...getBaseChildObj('totalNotUserSpeak'),
  },
  {
    title: '未说话占比',
    width: 130,
    ...getBaseChildObj('notUserSpeakRate', true),
  },
  {
    title: '秒挂数',
    width: 130,
    ...getBaseChildObj('totalShortCallDuration'),
  },
  {
    title: '秒挂占比',
    width: 130,
    ...getBaseChildObj('shortCallDurationRate', true),
  },
  {
    title: 'A类名单数',
    dataIndex: 'aIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'B类名单数',
    dataIndex: 'bIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'C类名单数',
    dataIndex: 'cIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'D类名单数',
    dataIndex: 'dIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'E类名单数',
    dataIndex: 'eIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'F类名单数',
    dataIndex: 'fIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'G类名单数',
    dataIndex: 'gIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'H类名单数',
    dataIndex: 'hIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'I类名单数',
    dataIndex: 'iIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'L类名单数',
    dataIndex: 'lIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'M类名单数',
    dataIndex: 'mIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: '未知名单数',
    dataIndex: 'unknownIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'A类占比',
    dataIndex: 'aIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: 'B类占比',
    dataIndex: 'bIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: 'C类占比',
    dataIndex: 'cIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: 'D类占比',
    dataIndex: 'dIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: 'E类占比',
    dataIndex: 'eIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: 'F类占比',
    dataIndex: 'fIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: 'G类占比',
    dataIndex: 'gIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: 'H类占比',
    dataIndex: 'hIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: 'I类占比',
    dataIndex: 'iIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: 'L类占比',
    dataIndex: 'lIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: 'M类占比',
    dataIndex: 'mIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: '未知占比',
    dataIndex: 'unknownIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: 'ADE类名单数',
    dataIndex: 'adeIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'ADE类占比',
    dataIndex: 'adeIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: 'AB类名单数',
    dataIndex: 'abIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'AB类占比',
    dataIndex: 'abIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: 'AD类名单数',
    dataIndex: 'adIntentNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: 'AD类占比',
    dataIndex: 'adIntentNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: '超时名单数',
    dataIndex: 'timeoutNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: '超时占比',
    dataIndex: 'timeoutNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: '接听助理名单数',
    dataIndex: 'answeringAssistantNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: '接听助理占比',
    dataIndex: 'answeringAssistantNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: '运营商提示音名单数',
    dataIndex: 'operatorPromptSoundNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: '运营商提示音占比',
    dataIndex: 'operatorPromptSoundNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: '有交互名单数',
    dataIndex: 'interactiveNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: '有交互名单占比',
    dataIndex: 'interactiveNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
  {
    title: '平均说话次数',
    dataIndex: 'speekAvg',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: '有说话名单数',
    dataIndex: 'speekNum',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
  },
  {
    title: '有说话占比',
    dataIndex: 'speekNumRate',
    sorter: true,
    width: 150,
    sortDirections: ['descend', 'ascend'],
    render: (text) => `${convertPer(text)}%`,
  },
];
