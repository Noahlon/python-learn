import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import { Select, Table, Empty, Button, message } from 'antd';
import { Chart } from '@antv/g2';
import RingChart from '@/components/RingChart';
import styles from './index.less';
import moment from 'moment';
import {
  CaretDownOutlined,
  VerticalAlignBottomOutlined,
} from '@ant-design/icons';
import {
  getLineAbnormal,
  getLineCallOut,
  getLineCallPie,
  getLineCallProcess,
  ICallOut,
  ILineAbnormal,
  ILineProcess,
  ILineProvince,
  statisticsCallResultExport,
  statisticsCityExport,
  statisticsProvince,
} from '@/api/lineMonitor';
import { useModel } from '@umijs/max';
import { ChartDataType } from '@/pages/taskCenter/components/SubTask/components/WorkingStatistics/components/Charts/config';
import { accMul, httpReplace, isIntegerBarringZero } from '@/utils';
import {
  abnormalOpt,
  timeOptions,
} from '@/pages/LineMonitor/components/TenantLine/TenantDrawer/config';
import SelectLimit from '@/components/SelectLimit';

interface PropsType {
  date?: string[];
  lineId?: string;
  isToDay?: boolean;
  callNum?: string;
  onResult?: (allocatedConcurrency: number, totalConcurrency: number) => void;
}

const SupplierInfo: React.FC<PropsType> = ({
  date,
  callNum,
  isToDay,
  onResult,
}) => {
  const callOutChartRef = useRef(null);
  const processChartRef = useRef(null);
  const abnormalChartRef = useRef(null);
  const [dataTable, setDataTable] = useState<ILineProvince[]>([]);
  const [pageIndex, setPageIndex] = useState(1);
  const [pageSize, setPageSize] = useState(100);
  const [total, setTotal] = useState(0);
  const [callOurData, setCallOurData] = useState<ICallOut[]>([]);
  const [callOurInterval, setCallOurInterval] = useState(5);
  const [processData, setProcessData] = useState<ILineProcess[]>([]);
  const [processinterval, setProcessinterval] = useState(5);
  const [processKeys, setProcessKeys] = useState<number[]>([18]);
  const [abnormalData, setAbnormalData] = useState<ILineAbnormal[]>([]);
  const [abnormalinterval, setAbnormalinterval] = useState(5);
  const [abnormalKeys, setAbnormalKeys] = useState<string[]>([
    'USER_NOT_SPEAK',
  ]);
  const [pieData, setPieData] = useState<ChartDataType>([]);
  const [callNumPie, setCallNumPie] = useState(0);
  const { callResultList, handleCallResultList } = useModel('speech');

  // 获取送呼数量折线图
  const handleCallOut = useCallback(async () => {
    if (!callNum) return;
    const param = {
      statisticsType: 1,
      statisticKey: callNum,
      startDate: date?.[0] || undefined,
      endDate: date?.[1] || undefined,
      interval: callOurInterval,
      pageNum: 1,
      pageSize: 999,
    };
    const res = await getLineCallOut(param);
    if (res?.success) {
      let _data = [];
      if (res.data?.length) {
        res.data.forEach((item) => {
          if (item?.statisticsDate.indexOf(' ') > -1)
            item.statisticsDate = moment(item.statisticsDate).format('HH:mm');
          _data.push({
            ...item,
            value: item.totalCall,
          });
        });
      }
      setCallOurData(_data);
    }
  }, [callOurInterval, callNum, date]);

  // 获取外呼结果折线图
  const handleProcess = useCallback(async () => {
    if (!callNum) return;
    const param = {
      statisticsType: 1,
      statisticKey: callNum,
      startDate: date?.[0] || undefined,
      endDate: date?.[1] || undefined,
      interval: processinterval,
      processStatisticKeyList: processKeys,
      processStatisticKeyType: 0,
      pageNum: 1,
      pageSize: 999,
    };
    const res = await getLineCallProcess(param);
    if (res?.success) {
      let _data = [];
      if (res.data?.length) {
        res.data.forEach((item) => {
          if (item?.statisticsDate.indexOf(' ') > -1)
            item.statisticsDate = moment(item.statisticsDate).format('HH:mm');
          _data.push({
            ...item,
            value: item.callsRate
              ? Number(accMul(item.callsRate, 100).toFixed(2))
              : 0,
          });
        });
      }
      setProcessData(_data);
    }
  }, [processinterval, processKeys, callNum, date]);

  // 获取异常指标折线图
  const handleAbnormal = useCallback(async () => {
    if (!callNum) return;
    const param = {
      statisticsType: 1,
      statisticKey: callNum,
      startDate: date?.[0] || undefined,
      endDate: date?.[1] || undefined,
      interval: abnormalinterval,
      processStatisticKeyList: abnormalKeys,
      processStatisticKeyType: 1,
      pageNum: 1,
      pageSize: 999,
    };
    const res = await getLineAbnormal(param);
    if (res?.success) {
      let _data = [];
      if (res.data?.length) {
        res.data.forEach((item) => {
          if (item?.statisticsDate.indexOf(' ') > -1)
            item.statisticsDate = moment(item.statisticsDate).format('HH:mm');
          _data.push({
            ...item,
            value: item.callsRate
              ? Number(accMul(item.callsRate, 100).toFixed(2))
              : 0,
          });
        });
      }
      setAbnormalData(_data);
    }
  }, [abnormalinterval, abnormalKeys, callNum, date]);

  // 获取外呼结果饼图
  const handleProcessPie = useCallback(async () => {
    if (!callNum) return;
    const param = {
      statisticsType: 1,
      statisticKey: callNum,
      startDate: date?.[0] || undefined,
      endDate: date?.[1] || undefined,
      pageNum: 1,
      pageSize: 999,
    };
    const res = await getLineCallPie(param);
    if (res?.success) {
      let _data = [];
      if (res.data?.list?.length) {
        _data = res.data.list
          ?.filter((item) => !!item.num)
          ?.map((item) => ({
            item: item.desc,
            count: item.num,
            percent: item.rate,
          }));
      }
      setCallNumPie(res.data?.totalCall);
      setPieData(_data);
      onResult?.(res.data?.allocatedConcurrency, res.data?.totalConcurrency);
    }
  }, [callNum, date]);

  // 获取省市分布
  const handleProvince = useCallback(
    async ({ num, size }: { num?: number; size?: number }) => {
      const _num = num || pageIndex;
      const _size = size || pageSize;
      const param = {
        statisticsType: 1,
        statisticKey: callNum,
        startDate: date?.[0] || undefined,
        endDate: date?.[1] || undefined,
        pageNum: _num,
        pageSize: _size,
      };
      const res = await statisticsProvince(param);
      if (res?.success) {
        res.data?.statistics?.forEach((item, index) => {
          item.index = (Number(_num) - 1) * Number(_size) + index + 1;
        });
        setDataTable(res.data?.statistics);
        setTotal(res.data?.totalCall);
      }
    },
    [pageIndex, pageSize, callNum, date],
  );

  // 外呼结果导出
  const handleCallResultExport = useCallback(async () => {
    const param = {
      statisticsType: 1,
      statisticKey: callNum,
      startDate: date?.[0] || undefined,
      endDate: date?.[1] || undefined,
      pageNum: 1,
      pageSize: 999,
    };
    const dest = message.loading('正在导出');
    const res = await statisticsCallResultExport(param);
    if (res?.success && res?.data?.ossUrl) {
      let elink = document.createElement('a');
      elink.style.display = 'none';
      elink.href = httpReplace(res?.data.ossUrl);
      // elink.download = '话术列表';
      document.body.appendChild(elink);
      elink.click();
      setTimeout(() => {
        document.body.removeChild(elink);
      }, 300);
    }
    dest?.();
  }, [callNum, date]);

  // 省市导出
  const handleCityExport = useCallback(async () => {
    const param = {
      statisticsType: 1,
      statisticKey: callNum,
      startDate: date?.[0] || undefined,
      endDate: date?.[1] || undefined,
      pageNum: 1,
      pageSize: 999,
    };
    const dest = message.loading('正在导出');
    const res = await statisticsCityExport(param);
    if (res?.success && res?.data?.ossUrl) {
      let elink = document.createElement('a');
      elink.style.display = 'none';
      elink.href = httpReplace(res?.data.ossUrl);
      // elink.download = '话术列表';
      document.body.appendChild(elink);
      elink.click();
      setTimeout(() => {
        document.body.removeChild(elink);
      }, 300);
    }
    dest?.();
  }, [callNum, date]);

  const columns = [
    {
      title: '排名',
      dataIndex: 'index',
    },
    {
      title: '省',
      dataIndex: 'province',
    },
    {
      title: '市',
      dataIndex: 'city',
    },
    {
      title: '外呼数',
      dataIndex: 'totalCall',
    },
    {
      title: '占比',
      dataIndex: 'totalCallRate',
      render: (text: number) => {
        if (!text) return 0;
        return `${accMul(text, 100).toFixed(2)}%`;
      },
    },
    {
      title: '接通数',
      dataIndex: 'totalPut',
    },
    {
      title: '接通率',
      dataIndex: 'totalPutRate',
      render: (text: number) => {
        if (!text) return 0;
        return `${accMul(text, 100).toFixed(2)}%`;
      },
    },
  ];

  // 分页
  const onChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      let _num = page;
      let _size = size;
      if (size !== pageSize) {
        setPageIndex(1);
        setPageSize(size);
        _num = 1;
        _size = size;
      } else {
        setPageIndex(page);
        _num = page;
      }
      handleProvince({ num: _num, size: _size });
    },
    [pageIndex, pageSize, callNum, date],
  );

  useEffect(() => {
    if (!callOutChartRef.current) {
      callOutChartRef.current = new Chart({
        container: 'callOutProcess1',
        autoFit: true,
        height: 300,
        padding: [40, 80, 80, 80],
      });
    }
    if (!processChartRef.current) {
      processChartRef.current = new Chart({
        container: 'lineProcess1',
        autoFit: true,
        height: 300,
        padding: [40, 80, 80, 80],
      });
    }
    if (!abnormalChartRef.current) {
      abnormalChartRef.current = new Chart({
        container: 'lineAbnormal1',
        autoFit: true,
        height: 300,
        padding: [40, 80, 80, 80],
      });
    }
    if (!callResultList?.length) handleCallResultList();
  }, []);

  useEffect(() => {
    if (callNum && date?.length) {
      handleProcessPie();
      handleProvince({});
      setPageIndex(1);
    }
  }, [callNum, date]);

  useEffect(() => {
    if (callNum && date?.length) {
      handleCallOut();
    }
  }, [callOurInterval, callNum, date]);

  useEffect(() => {
    if (callNum && date?.length) {
      handleProcess();
    }
  }, [processinterval, processKeys, callNum, date]);

  useEffect(() => {
    if (callNum && date?.length) {
      handleAbnormal();
    }
  }, [abnormalinterval, abnormalKeys, callNum, date]);

  useEffect(() => {
    if (callOutChartRef.current) {
      callOutChartRef.current.clear(); // 清除画布
      callOutChartRef.current.data(callOurData);
      callOutChartRef.current.scale({
        statisticsDate: {
          range: [0, 1],
          type: 'cat',
        },
        totalCall: {
          min: 0,
          nice: true,
        },
      });
      callOutChartRef.current.tooltip({
        showCrosshairs: true,
        shared: true,
        customItems: (items) => {
          const _list = [];
          items?.forEach((i) => {
            _list.push({
              ...i,
              name: `送呼数量`,
            });
          });
          return _list;
        },
      });
      callOutChartRef.current.line().position('statisticsDate*totalCall');
      // .color('calloutResultDesc');
      callOutChartRef.current.point().position('statisticsDate*totalCall');
      // .color('calloutResultDesc');
      callOutChartRef.current.render();
    }
  }, [callOurData]);

  useEffect(() => {
    if (processChartRef.current) {
      processChartRef.current.clear(); // 清除画布
      processChartRef.current.data(processData);
      processChartRef.current.scale({
        statisticsDate: {
          range: [0, 1],
        },
        value: {
          nice: true,
        },
      });
      processChartRef.current.tooltip({
        showCrosshairs: true,
        shared: true,
        title: (title) => `${title}  各占比`,
        customItems: (items) => {
          const _list = [];
          items?.forEach((i) => {
            _list.push({
              ...i,
              value: `${i.value}%  \xa0\xa0\xa0 ${i?.data?.callsCount}`,
            });
          });
          return _list;
        },
      });
      // processChartRef.current.axis('statisticsDate', {
      //   type: 'timeCat',
      //   mask: 'YYYY-MM-DD HH:mm:ss', // 用于解析时间字符串的格式化串
      //   formatter: val => moment(val).format('YYYY-MM-DD HH:mm:ss'),// 将时间戳转换为字符串
      //   // label: {
      //   //   formatter: val => moment(val).format('YYYY-MM-DD HH:mm:ss'),
      //   // },
      // });
      processChartRef.current.axis('value', {
        label: {
          formatter: (val) => {
            if (val === '0' || val === 0 || isIntegerBarringZero(val))
              return val + ' %';
            return Number(val).toFixed(2) + ' %';
          },
        },
      });
      processChartRef.current
        .line()
        .position('statisticsDate*value')
        .color('calloutResultDesc');
      processChartRef.current
        .point()
        .position('statisticsDate*value')
        .color('calloutResultDesc');
      processChartRef.current.render();
    }
  }, [processData]);

  useEffect(() => {
    if (abnormalChartRef.current) {
      abnormalChartRef.current.clear(); // 清除画布
      abnormalChartRef.current.data(abnormalData);
      abnormalChartRef.current.scale({
        statisticsDate: {
          range: [0, 1],
        },
        value: {
          nice: true,
        },
      });
      abnormalChartRef.current.tooltip({
        showCrosshairs: true,
        shared: true,
        title: (title) => `${title}  各占比`,
        customItems: (items) => {
          const _list = [];
          items?.forEach((i) => {
            _list.push({
              ...i,
              value: `${i.value}%  \xa0\xa0\xa0 ${i?.data?.callsCount}`,
            });
          });
          return _list;
        },
      });
      abnormalChartRef.current.axis('value', {
        label: {
          formatter: (val) => {
            if (val === '0' || val === 0 || isIntegerBarringZero(val))
              return val + ' %';
            return Number(val).toFixed(2) + ' %';
          },
        },
      });

      abnormalChartRef.current
        .line()
        .position('statisticsDate*value')
        .color('abnormalTypeDesc');
      abnormalChartRef.current
        .point()
        .position('statisticsDate*value')
        .color('abnormalTypeDesc');
      abnormalChartRef.current.render();
    }
  }, [abnormalData]);

  return (
    <div className={styles.draw}>
      <h2>过程统计</h2>
      <div className={styles.searchWrap}>
        <div>送呼数量</div>
        {isToDay && (
          <div style={{ color: '#000' }}>
            计量单位：
            <Select
              style={{ width: 100 }}
              value={callOurInterval}
              bordered={false}
              options={timeOptions}
              suffixIcon={<CaretDownOutlined style={{ color: '#000' }} />}
              onChange={(val) => setCallOurInterval(val)}
            />
          </div>
        )}
      </div>
      <div id="callOutProcess1" style={{ height: 300 }}></div>
      <div className={styles.searchWrap}>
        <div>
          外呼结果：
          <SelectLimit
            style={{ width: 120 }}
            max={5}
            value={processKeys}
            mode="multiple"
            maxTagCount="responsive"
            bordered={false}
            suffixIcon={<CaretDownOutlined style={{ color: '#000' }} />}
            options={callResultList}
            onChange={(val) => setProcessKeys(val)}
          />
          <CaretDownOutlined style={{ color: '#000' }} />
        </div>
        {isToDay && (
          <div>
            计量单位：
            <Select
              style={{ width: 100 }}
              value={processinterval}
              bordered={false}
              options={timeOptions}
              suffixIcon={<CaretDownOutlined style={{ color: '#000' }} />}
              onChange={(val) => setProcessinterval(val)}
            />
          </div>
        )}
      </div>
      {/* <Space size="large">
        <div className={styles.showTitle}>外呼数：9999</div>
        <div className={styles.showTitle}>接通数：9999</div>
        <div className={styles.showTitle}>接通率：9999</div>
      </Space> */}
      <div id="lineProcess1" style={{ height: 300 }}></div>

      <div className={styles.searchWrap}>
        <div>
          异常指标：
          <SelectLimit
            style={{ width: 120 }}
            max={5}
            value={abnormalKeys}
            mode="multiple"
            maxTagCount="responsive"
            bordered={false}
            suffixIcon={<CaretDownOutlined style={{ color: '#000' }} />}
            options={abnormalOpt}
            onChange={(val) => setAbnormalKeys(val)}
          />
          <CaretDownOutlined style={{ color: '#000' }} />
        </div>
        {isToDay && (
          <div style={{ color: '#000' }}>
            计量单位：
            <Select
              style={{ width: 100 }}
              value={abnormalinterval}
              bordered={false}
              options={timeOptions}
              suffixIcon={<CaretDownOutlined style={{ color: '#000' }} />}
              onChange={(val) => setAbnormalinterval(val)}
            />
          </div>
        )}
      </div>
      {/* <Space size="large">
        <div className={styles.showTitle}>接通数：9999</div>
        <div className={styles.showTitle}>秒挂量：9999</div>
        <div className={styles.showTitle}>秒挂占比：9999</div>
      </Space> */}
      <div id="lineAbnormal1" style={{ height: 300 }}></div>

      <div className={styles.third}>
        <div className={styles.left}>
          <h2>
            外呼结果&nbsp;&nbsp;
            <Button
              type="link"
              icon={<VerticalAlignBottomOutlined />}
              onClick={handleCallResultExport}
            >
              导出
            </Button>
          </h2>
          <div className={styles.ring}>
            <div style={{ width: '100%' }}>
              {!!pieData?.length ? (
                <RingChart
                  data={pieData}
                  total={callNumPie}
                  title="外呼数"
                  container="linePie"
                  height={300}
                />
              ) : (
                <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
              )}
            </div>
          </div>
        </div>
        <div className={styles.right}>
          <h2>
            省市分布&nbsp;&nbsp;
            <Button
              type="link"
              icon={<VerticalAlignBottomOutlined />}
              onClick={handleCityExport}
            >
              导出
            </Button>
          </h2>
          <div className={styles.table}>
            <Table
              columns={columns}
              dataSource={dataTable}
              scroll={{ y: 335, x: 600 }}
              rowKey={(record) => record.city}
              pagination={{
                pageSize: pageSize,
                showSizeChanger: true,
                current: pageIndex,
                total: total,
                showTotal: (total) => `总共 ${total} 条`,
                onChange: onChange,
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
export default memo(SupplierInfo);
