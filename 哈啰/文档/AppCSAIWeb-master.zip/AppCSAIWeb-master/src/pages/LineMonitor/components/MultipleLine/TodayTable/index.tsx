import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Input, Table, Button, Pagination, Form, Select } from 'antd';
import { v1 as uuidv1 } from 'uuid';
import moment from 'moment';
import { getLine, ILineInfo } from '@/api/lineMonitor';
import { multipleTodayColumns } from '../config';
import { useModel } from '@umijs/max';
import { bigCateOptions, smallCateOptions } from '../config';
import styles from './index.less';

const MultipleLineTodayTable: React.FC = () => {
  const { tenantOpts } = useModel('common');
  const queryParams = useRef({
    pageNum: 1,
    pageSize: 100,
    name: undefined,
    statisticsType: 2, // 租户 + 供应商
    startDate: moment().format('YYYY-MM-DD'),
    endDate: moment().format('YYYY-MM-DD'),
    tenantCode: undefined,
    supplierName: undefined,
    sort: undefined,
    sortParam: undefined,
    sortAsc: undefined,
  });
  const ref = useRef();
  const [form] = Form.useForm();
  const [height, setHeight] = useState(null);
  const [dataSource, setDataSource] = useState<ILineInfo[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [pageIndex, setPageIndex] = useState(1);
  const [pageSize, setPageSize] = useState(100);

  /**
   * api
   */
  const handlerGetLists = async () => {
    setTableLoading(true);
    const res = await getLine(queryParams.current);
    if (res.success) {
      setDataSource(res?.data?.list || []);
      setTotal(res?.data?.totalRecord);
    }
    setTableLoading(false);
  };

  // 查询
  const search = async () => {
    const res = await form.validateFields();
    res.pageNum = 1;
    queryParams.current = { ...queryParams.current, ...res };
    setPageIndex(1);
    handlerGetLists();
  };

  // 分页
  const onChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      if (size !== pageSize) {
        queryParams.current.pageNum = 1;
        queryParams.current.pageSize = size;
        setPageIndex(1);
        setPageSize(size);
      } else {
        setPageIndex(page);
        queryParams.current.pageNum = page;
      }
      handlerGetLists();
    },
    [pageSize],
  );

  // 筛选
  const handleTableChange = (pagination, filters, sorter) => {
    console.log(pagination, filters, sorter);
    if (!!sorter?.order) {
      queryParams.current.sort = 1;
      queryParams.current.sortParam = sorter?.field;
      queryParams.current.sortAsc = sorter?.order === 'descend' ? -1 : 1;
    } else {
      queryParams.current.sort = undefined;
      queryParams.current.sortParam = undefined;
      queryParams.current.sortAsc = undefined;
    }
    handlerGetLists();
  };

  useEffect(() => {
    if (ref.current) {
      // @ts-ignore
      setHeight(ref.current.clientHeight);
    }
  }, []);

  useEffect(() => {
    // 获取租户列表后初始化数据
    if (tenantOpts?.length > 0) {
      const curTenant = tenantOpts[0];
      form.setFieldsValue({ tenantCode: curTenant?.value });
      queryParams.current.tenantCode = curTenant?.value;
    }
    handlerGetLists();
  }, [tenantOpts]);

  return (
    <div className={styles.todaytable}>
      <div className={styles.top}>
        <Form form={form} layout="inline">
          <Form.Item name="tenantCode" className={styles.formItem}>
            <Select
              style={{ width: '200px' }}
              placeholder="请选择租户"
              showSearch
              optionFilterProp="label"
              options={tenantOpts}
            />
          </Form.Item>
          <Form.Item name="name" className={styles.formItem}>
            <Input placeholder="线路名称" allowClear />
          </Form.Item>
          <Form.Item name="supplierName" className={styles.formItem}>
            <Input placeholder="供应商名称" allowClear />
          </Form.Item>
          <Form.Item name="lineCategory" className={styles.formItem}>
            <Select
              style={{ width: '200px' }}
              placeholder="线路大类"
              showSearch
              allowClear
              optionFilterProp="label"
              options={bigCateOptions}
            />
          </Form.Item>
          <Form.Item name="lineSubCategory" className={styles.formItem}>
            <Select
              style={{ width: '200px' }}
              placeholder="线路小类"
              showSearch
              allowClear
              optionFilterProp="label"
              options={smallCateOptions}
            />
          </Form.Item>
          <Button className={styles.formItem} type="primary" onClick={search}>
            搜索
          </Button>
        </Form>
      </div>
      <div className={styles.table} ref={ref}>
        <Table
          dataSource={dataSource}
          columns={multipleTodayColumns}
          scroll={{ x: 2700, y: height - 110 }}
          pagination={false}
          loading={tableLoading}
          rowKey={() => uuidv1()}
          onChange={handleTableChange}
          bordered
        />
      </div>
      <div className={styles.pagination}>
        <Pagination
          current={pageIndex}
          showSizeChanger={true}
          pageSize={pageSize}
          total={total}
          showTotal={(total) => `总共 ${total} 条`}
          onChange={onChange}
        />
      </div>
    </div>
  );
};

export default MultipleLineTodayTable;
