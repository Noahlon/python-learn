import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Tabs,
  Button,
  Drawer,
  Form,
  DatePicker,
  Input,
  Space,
  Cascader,
  message,
} from 'antd';
import moment from 'moment';
import styles from './index.less';
import HistoryNumber from './components/HistoryNumber';
import { ILineInfo } from '@/api/lineMonitor';
import { RangePickerProps } from 'antd/es/date-picker';
import SupplierInfo from './components/SupplierInfo';
import { findSimple, findSimpleSupplier } from '@/api/lineSupplier';

const { RangePicker } = DatePicker;
interface PropsType {
  info: ILineInfo;
  open: boolean;
  closeDrawer: () => void;
  type: 'supplierToday' | 'supplierHistory';
  date?: string[];
}

const ChartDrawer: React.FC<PropsType> = ({
  open,
  closeDrawer,
  info,
  date,
}) => {
  const [form] = Form.useForm();
  const [isToDay, setIsToDay] = useState(true);
  const [options, setOptions] = useState([]);
  const [selectDate, setSelectDate] = useState<string[]>();
  const [selectLineId, setSelectLineId] = useState<undefined | string>();
  const [selectCallNum, setSelectCallNum] = useState('');
  const [concurrency, setConcurrency] = useState('');
  const isFirst = useRef(true);

  // 获取供应商
  const getFindSimpleSupplier = async () => {
    const { data } = await findSimpleSupplier({ supplierStatus: 1 });
    let option = [];
    data.forEach((it) => {
      option.push({
        value: it.guid,
        label: it.supplierName,
        isLeaf: false,
      });
    });
    if (info?.supplierGuid) {
      const res = await findSimple({
        supplierGuid: info?.supplierGuid,
        status: 1,
        syncStatus: 1,
      });
      if (res.data) {
        let opt = [];
        res.data.forEach((it) => {
          opt.push({
            value: it.guid,
            label: it.supporterLineName,
            concurrentLimit: it.concurrentLimit,
            callingNumber: it.callingNumber,
          });
        });
        option.forEach((it) => {
          if (it.value === info?.supplierGuid) {
            it.children = opt;
          }
        });
      }
    }
    setOptions(option);
  };

  // 获取供应商下的线路
  const getFindSimple = async (supplierGuid) => {
    const { data } = await findSimple({
      supplierGuid,
      status: 1,
      syncStatus: 1,
    });
    if (data) {
      let opt = [];
      data.forEach((it) => {
        opt.push({
          value: it.guid,
          label: it.supporterLineName,
          concurrentLimit: it.concurrentLimit,
          callingNumber: it.callingNumber,
        });
      });

      const newOption = options.map((it) => {
        if (!it.children) {
          if (it.value === supplierGuid) {
            it.children = opt;
          }
        }
        return it;
      });
      setOptions(newOption);
    }
  };

  const loadData = async (selectedOptions) => {
    const targetOption = selectedOptions[selectedOptions.length - 1];
    targetOption.loading = true;
    if (targetOption.children) return;
    if (selectedOptions.length === 1) {
      targetOption.loading = true;
      getFindSimple(targetOption.value);
    }
  };

  // // 验证
  // const handleValidatorTime = async (rule, value) => {
  //   if (isToDay) return Promise.resolve();
  //   if (!value || !value?.length) return Promise.reject('');
  //   return Promise.resolve();
  // };

  // 验证线路
  const handleValidatorLine = async (rule, value) => {
    if (!value?.length || value?.length < 2) return Promise.reject('');
    return Promise.resolve();
  };

  // 不可用日期
  const disabledDate: RangePickerProps['disabledDate'] = useCallback(
    (current) => {
      return (
        current &&
        (current > moment().subtract(1, 'days') ||
          moment().subtract(30, 'days') > current)
      );
    },
    [],
  );

  // 获取并发
  const handleGetCur = async (curNum, totNum) => {
    setConcurrency(`${curNum || 0}/${totNum || 0}`);
  };

  const lineChange = async (val) => {
    if (val?.length === 2) {
      const _numList = options.find((item) => item.value === val?.[0]);
      if (_numList?.children) {
        const _num = _numList?.children.find((item) => item.value === val?.[1]);
        if (_num) form.setFieldValue('callNum', _num.callingNumber);
      }
    }
  };

  // 搜索
  const search = async (isDay?: boolean) => {
    const res = await form.validateFields();
    let time = [];
    if (isFirst.current) {
      time = [...date];
      const todayDate = moment().format('YYYY-MM-DD');
      const _toDay = time?.[0] === todayDate && time?.[1] === todayDate;
      setIsToDay(_toDay);
      if (_toDay) form.setFieldValue('time', []);
      isFirst.current = false;
    } else {
      if (!isDay && !isToDay && !res?.time?.length)
        return message.error('请先选择时间');
      if (isDay || isToDay) {
        time = [moment().format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')];
      } else {
        if (res?.time?.length)
          time = [
            moment(res.time?.[0]._d).format('YYYY-MM-DD'),
            moment(res.time?.[1]._d).format('YYYY-MM-DD'),
          ];
      }
    }
    setSelectLineId(res.statisticKey?.[1]);
    setSelectCallNum(res.callNum);
    setSelectDate(time);
  };

  useEffect(() => {
    if (info?.lineGuid) {
      form.setFieldValue('statisticKey', [info?.supplierGuid, info?.lineGuid]);
      getFindSimpleSupplier();
      form.setFieldValue('callNum', info?.callingNumber);
      form.setFieldValue('time', [moment(date?.[0]), moment(date?.[1])]);
      search();
    }
  }, [info]);

  return (
    <>
      <Drawer
        title=""
        closable={false}
        placement="right"
        onClose={closeDrawer}
        open={open}
        width="75%"
        height="100vh"
        className={styles.draw}
        destroyOnClose
      >
        <Form form={form}>
          <Space align="start">
            <Form.Item
              name="statisticKey"
              label="线路"
              rules={[{ validator: handleValidatorLine }]}
            >
              <Cascader
                className={styles.searchItem}
                allowClear
                placeholder="请选择"
                loadData={loadData}
                options={options}
                onChange={lineChange}
                style={{ width: '200px' }}
              />
            </Form.Item>
            <Form.Item name="callNum" hidden>
              <Input />
            </Form.Item>
            <Button
              type={isToDay ? 'primary' : 'default'}
              onClick={() => {
                setIsToDay(true);
                form.setFieldValue('time', []);
                setTimeout(() => {
                  search(true);
                }, 0);
              }}
            >
              今日
            </Button>
            <Form.Item name="time">
              <RangePicker
                allowClear
                style={{ width: '260px' }}
                onChange={() => setIsToDay(false)}
                disabledDate={disabledDate}
              />
            </Form.Item>
            {isToDay && (
              <div style={{ margin: '4px' }}>
                实时并发/总并发: &nbsp;&nbsp;{concurrency}
              </div>
            )}
            <Form.Item>
              <Button type="primary" onClick={() => search()}>
                搜索
              </Button>
            </Form.Item>
          </Space>
        </Form>
        <Tabs
          destroyInactiveTabPane
          items={[
            {
              label: `线路监控`,
              key: '1',
              children: (
                <SupplierInfo
                  date={selectDate}
                  lineId={selectLineId}
                  isToDay={isToDay}
                  callNum={selectCallNum}
                  onResult={handleGetCur}
                />
              ),
            },
            {
              label: `号码监控`,
              key: '2',
              children: (
                <HistoryNumber date={selectDate} lineId={selectLineId} />
              ),
            },
          ]}
        />
      </Drawer>
    </>
  );
};
export default ChartDrawer;
