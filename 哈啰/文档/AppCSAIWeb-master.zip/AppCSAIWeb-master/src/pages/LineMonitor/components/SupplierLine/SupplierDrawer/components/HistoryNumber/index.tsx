import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import { Table, Select } from 'antd';
import moment from 'moment';
import { Chart } from '@antv/g2';
import styles from './index.less';
import {
  ICallNumArea,
  ICallNumAreaInfo,
  ICallNumUse,
  IStatisticsInfo,
  statisticsCallNumArea,
  statisticsCallNumAreaInfo,
  statisticsCallNumUse,
  statisticsCallNumUseInfo,
} from '@/api/lineMonitor';
import { accMul, isIntegerBarringZero } from '@/utils';
import { findNumberPage } from '@/api/lineSupplier';
import { CaretDownOutlined } from '@ant-design/icons';

interface PropsType {
  date?: string[];
  lineId?: string;
}

const HistoryNumber: React.FC<PropsType> = ({ date, lineId }) => {
  const line1Ref = useRef(null);
  const line2Ref = useRef(null);
  const line3Ref = useRef(null);
  const line4Ref = useRef(null);
  const [callNumData, setCallNumData] = useState<ICallNumUse[]>([]);
  const [phonePageIndex, setPhonePageIndex] = useState(1);
  const [phonePageSize, setPhonePageSize] = useState(100);
  const [phoneTotal, setPhoneTotal] = useState(0);
  const [callNumAreaData, setCallNumAreaData] = useState<ICallNumArea[]>([]);
  const [areaPageIndex, setAreaPageIndex] = useState(1);
  const [areaPageSize, setAreaPageSize] = useState(100);
  const [areaTotal, setAreaTotal] = useState(0);
  const [lineData1, setLineData1] = useState<IStatisticsInfo[]>([]);
  const [lineData2, setLineData2] = useState<ICallNumAreaInfo[]>([]);
  const [selectCallNumInfo, setSelectCallNumInfo] = useState<ICallNumUse>();
  const [selectCallAreaInfo, setSelectCallAreaInfo] = useState<ICallNumArea>();
  const [lineNumberList, setLineNumberList] = useState([]);
  const [isToDay, setIsToDay] = useState(false);
  const [selectLineNumber, setSelectLineNumber] = useState('');

  const columns: any = [
    {
      title: '外显号码',
      dataIndex: 'callingNumber',
    },
    // isToDay ?
    //   {
    //     title: '总并发',
    //     dataIndex: 'totalConcurrency',
    //   }
    // : null,
    // isToDay ?
    //   {
    //     title: '实际并发',
    //     dataIndex: 'allocatedConcurrency',
    //   }
    // : null,
    // isToDay ?
    //   {
    //     title: '使用率',
    //     dataIndex: 'allocatedConcurrency',
    //     render: (text, record: ICallNumUse) => {
    //       if (!text || !record.totalConcurrency) return 0;
    //       const _rate = (text / record.totalConcurrency);
    //       return `${convertPer(_rate)}%`;
    //     },
    //   }
    // : null,
    {
      title: '外呼数',
      dataIndex: 'totalCall',
    },
    {
      title: '接通数',
      dataIndex: 'totalPut',
    },
    {
      title: '接通率',
      dataIndex: 'totalPutRate',
    },
  ];

  const columns2 = [
    {
      title: '排名',
      dataIndex: 'index',
    },
    {
      title: '省',
      dataIndex: 'province',
    },
    {
      title: '市',
      dataIndex: 'city',
    },
    {
      title: '外呼数',
      dataIndex: 'totalCall',
    },
    {
      title: '接通数',
      dataIndex: 'totalPut',
    },
    {
      title: '接通率',
      dataIndex: 'totalPutRate',
    },
  ];

  // 获取号码适用情况
  const handleCallNumUse = useCallback(
    async ({ pageNum, pageSize }: { pageNum?: number; pageSize?: number }) => {
      const param = {
        lineGuid: lineId,
        startDate: date?.[0] || undefined,
        endDate: date?.[1] || undefined,
        pageNum: pageNum || phonePageIndex,
        pageSize: pageSize || phonePageSize,
      };
      setLineData1([]);
      const res = await statisticsCallNumUse(param);
      if (res?.success) {
        setCallNumData(res.data?.list);
        setPhoneTotal(res.data?.totalRecord);
        setSelectCallNumInfo(res.data?.list?.[0]);
      }
    },
    [phonePageIndex, phonePageSize, date, lineId],
  );

  // 获取号码省市接通
  const handleCallNumArea = useCallback(
    async ({
      pageNum,
      pageSize,
      phone,
    }: {
      pageNum?: number;
      pageSize?: number;
      phone?: string;
    }) => {
      const _phone =
        phone === 'none'
          ? undefined
          : phone
          ? [phone]
          : selectLineNumber
          ? [selectLineNumber]
          : undefined;
      const param = {
        lineGuid: lineId,
        startDate: date?.[0] || undefined,
        endDate: date?.[1] || undefined,
        pageNum: pageNum || areaPageIndex,
        pageSize: pageSize || areaPageSize,
        callingNumberList: _phone,
      };
      setLineData2([]);
      const res = await statisticsCallNumArea(param);
      if (res?.success) {
        res.data?.list?.forEach((item, index) => {
          item.index =
            Number(accMul(Number(areaPageIndex) - 1, Number(areaPageSize))) +
            index +
            1;
        });
        setCallNumAreaData(res.data?.list);
        setAreaTotal(res.data?.totalRecord);
        setSelectCallAreaInfo(res.data?.list?.[0]);
      }
    },
    [areaPageIndex, areaPageSize, date, lineId, selectLineNumber],
  );

  // 获取号码适用折线图
  const handleCallNumUseInfo = useCallback(async () => {
    if (isToDay || !selectCallNumInfo) return;
    const param = {
      callingNumber: selectCallNumInfo?.callingNumber,
      startDate: date?.[0] || undefined,
      endDate: date?.[1] || undefined,
      supplierLineGuid: lineId,
    };
    const res = await statisticsCallNumUseInfo(param);
    if (res?.success) setLineData1(res.data || []);
  }, [date, lineId, selectCallNumInfo, isToDay]);

  // 获取号码省市接通折线图
  const handleCallNumAreaInfo = useCallback(async () => {
    if (isToDay || !selectCallAreaInfo) return;
    const param = {
      callingNumber: selectLineNumber,
      city: selectCallAreaInfo?.city,
      startDate: date?.[0] || undefined,
      endDate: date?.[1] || undefined,
      supplierLineGuid: lineId,
    };
    const res = await statisticsCallNumAreaInfo(param);
    if (res?.success) setLineData2(res.data || []);
  }, [date, lineId, selectCallAreaInfo, isToDay, selectLineNumber]);

  // 分页
  const onPhoneChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      let _num = page;
      let _size = size;
      if (size !== phonePageSize) {
        setPhonePageIndex(1);
        setPhonePageSize(size);
        _num = 1;
        _size = size;
      } else {
        setPhonePageIndex(page);
        _num = page;
      }
      handleCallNumUse({ pageNum: _num, pageSize: _size });
    },
    [phonePageIndex, phonePageSize, date, lineId],
  );

  // 省市分页
  const onAreaChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      let _num = page;
      let _size = size;
      if (size !== areaPageSize) {
        setAreaPageIndex(1);
        setAreaPageSize(size);
        _num = 1;
        _size = size;
      } else {
        setAreaPageIndex(page);
        _num = page;
      }
      handleCallNumArea({ pageNum: _num, pageSize: _size });
    },
    [areaPageIndex, areaPageSize, date, lineId, selectLineNumber],
  );

  // 获取号码列表
  const handleLineNumber = useCallback(async () => {
    const params = {
      lineGuid: lineId,
      pageSize: 5000,
      pageNum: 1,
    };
    const res = await findNumberPage(params);
    if (res?.success) {
      setLineNumberList(res.data?.list || []);
      setSelectLineNumber(res.data?.list?.[0]?.realCallingNumber);
      setAreaPageIndex(1);
      handleCallNumArea({
        pageNum: 1,
        phone: res.data?.list?.[0]?.realCallingNumber,
      });
    }
  }, [areaPageIndex, areaPageSize, date, lineId, selectLineNumber]);

  useEffect(() => {
    if (isToDay) {
      line1Ref.current = null;
      line2Ref.current = null;
      line3Ref.current = null;
      line4Ref.current = null;
      setSelectCallNumInfo(null);
      setSelectCallAreaInfo(null);
      setLineData1([]);
      setLineData2([]);
    } else {
      if (!line1Ref.current) {
        line1Ref.current = new Chart({
          container: 'lineNumber1',
          autoFit: true,
          height: 300,
          padding: [40, 40, 80, 40],
        });
      }
      if (!line2Ref.current) {
        line2Ref.current = new Chart({
          container: 'lineNumber2',
          autoFit: true,
          height: 300,
          padding: [40, 40, 80, 40],
        });
      }
      if (!line3Ref.current) {
        line3Ref.current = new Chart({
          container: 'lineNumber3',
          autoFit: true,
          height: 300,
          padding: [40, 40, 80, 40],
        });
      }
      if (!line4Ref.current) {
        line4Ref.current = new Chart({
          container: 'lineNumber4',
          autoFit: true,
          height: 300,
          padding: [40, 40, 80, 40],
        });
      }
    }
  }, [isToDay]);

  useEffect(() => {}, [lineId]);

  useEffect(() => {
    if (lineId && date?.length) {
      setPhonePageIndex(1);
      handleCallNumUse({ pageNum: 1 });
    }
    const todayDate = moment().format('YYYY-MM-DD');
    setIsToDay(date?.[0] === todayDate && date?.[1] === todayDate);
    handleLineNumber();
  }, [date]);

  useEffect(() => {
    if (line1Ref.current) {
      line1Ref.current.clear(); // 清除画布
      line1Ref.current.data(lineData1);
      line1Ref.current.scale({
        statisticsDate: {
          range: [0, 1],
        },
        callsCount: {
          nice: true,
        },
      });
      line1Ref.current.tooltip({
        showCrosshairs: true,
        shared: true,
      });
      line1Ref.current
        .line()
        .position('statisticsDate*callsCount')
        .color('typeDesc');
      line1Ref.current
        .point()
        .position('statisticsDate*callsCount')
        .color('typeDesc');
      line1Ref.current.render();
    }
    if (line2Ref.current) {
      const _list = [];
      lineData1?.forEach((item) => {
        if (item.typeDesc === '接通数') {
          _list.push({
            ...item,
            callsRate: item.callsRate
              ? Number(accMul(item.callsRate, 100).toFixed(2))
              : 0,
            typeDesc: '接通率',
          });
        }
      });
      line2Ref.current.clear(); // 清除画布
      line2Ref.current.data(_list);
      line2Ref.current.scale({
        statisticsDate: {
          range: [0, 1],
        },
        callsRate: {
          nice: true,
        },
      });
      line2Ref.current.tooltip({
        showCrosshairs: true,
        shared: true,
        customItems: (items) => {
          const _item = [];
          items?.forEach((i) => {
            _item.push({ ...i, value: i.value + '%' });
          });
          return _item;
        },
      });
      line2Ref.current.axis('callsRate', {
        label: {
          formatter: (val) => {
            if (val === '0' || val === 0 || isIntegerBarringZero(val))
              return val + ' %';
            return Number(val).toFixed(2) + ' %';
          },
        },
      });
      line2Ref.current
        .line()
        .position('statisticsDate*callsRate')
        .color('typeDesc');
      line2Ref.current
        .point()
        .position('statisticsDate*callsRate')
        .color('typeDesc');
      line2Ref.current.render();
    }
  }, [lineData1]);

  useEffect(() => {
    if (line3Ref.current) {
      line3Ref.current.clear(); // 清除画布
      line3Ref.current.data(lineData2);
      line3Ref.current.scale({
        statisticsDate: {
          range: [0, 1],
        },
        callsCount: {
          nice: true,
        },
      });
      line3Ref.current.tooltip({
        showCrosshairs: true,
        shared: true,
      });
      line3Ref.current
        .line()
        .position('statisticsDate*callsCount')
        .color('typeDesc');
      line3Ref.current
        .point()
        .position('statisticsDate*callsCount')
        .color('typeDesc');
      line3Ref.current.render();
    }
    if (line4Ref.current) {
      const _list = [];
      lineData2?.forEach((item) => {
        if (item.typeDesc === '接通数') {
          _list.push({
            ...item,
            callsRate: item.callsRate
              ? Number(accMul(item.callsRate, 100).toFixed(2))
              : 0,
            typeDesc: '接通率',
          });
        }
      });
      line4Ref.current.clear(); // 清除画布
      line4Ref.current.data(_list);
      line4Ref.current.scale({
        statisticsDate: {
          range: [0, 1],
        },
        callsRate: {
          nice: true,
        },
      });
      line4Ref.current.tooltip({
        showCrosshairs: true,
        shared: true,
        customItems: (items) => {
          const _item = [];
          items?.forEach((i) => {
            _item.push({ ...i, value: i.value + '%' });
          });
          return _item;
        },
      });
      line4Ref.current.axis('callsRate', {
        label: {
          formatter: (val) => {
            if (val === '0' || val === 0 || isIntegerBarringZero(val))
              return val + ' %';
            return Number(val).toFixed(2) + ' %';
          },
        },
      });
      line4Ref.current
        .line()
        .position('statisticsDate*callsRate')
        .color('typeDesc');
      line4Ref.current
        .point()
        .position('statisticsDate*callsRate')
        .color('typeDesc');
      line4Ref.current.render();
    }
  }, [lineData2]);

  useEffect(() => {
    const todayDate = moment().format('YYYY-MM-DD');
    if (!(date?.[0] === todayDate && date?.[1] === todayDate))
      handleCallNumUseInfo();
  }, [selectCallNumInfo]);

  useEffect(() => {
    const todayDate = moment().format('YYYY-MM-DD');
    if (
      !(date?.[0] === todayDate && date?.[1] === todayDate) &&
      selectCallAreaInfo
    )
      handleCallNumAreaInfo();
  }, [selectCallAreaInfo]);

  return (
    <div className={styles.historynumber}>
      <div className={styles.top}>
        <div className={styles.table} id="table">
          <h2>号码使用情况</h2>
          <Table
            columns={columns}
            dataSource={callNumData}
            scroll={{ y: 600 }}
            rowKey={(record) => record.callingNumber}
            rowClassName={useCallback(
              (record: ICallNumUse) => {
                if (
                  selectCallNumInfo?.callingNumber === record?.callingNumber &&
                  !isToDay
                )
                  return styles.activity;
                return '';
              },
              [selectCallNumInfo, isToDay],
            )}
            onRow={(record) => {
              return {
                onClick: () => {
                  setSelectCallNumInfo(record);
                },
              };
            }}
            pagination={{
              pageSize: phonePageSize,
              showSizeChanger: true,
              current: phonePageIndex,
              total: phoneTotal,
              showTotal: (total) => `总共 ${total} 条`,
              onChange: onPhoneChange,
            }}
          />
        </div>
        {!isToDay && (
          <div className={styles.line}>
            <div className={styles.box}>
              <h3>外呼趋势</h3>
              <div id="lineNumber1"></div>
            </div>
            <div className={styles.box}>
              <h3>接通率趋势</h3>
              <div id="lineNumber2"></div>
            </div>
          </div>
        )}
      </div>
      <div className={styles.down}>
        <div className={styles.table}>
          <h2>号码省市接通情况</h2>
          <div>
            请选择：
            <Select
              bordered={false}
              fieldNames={{
                label: 'realCallingNumber',
                value: 'realCallingNumber',
              }}
              value={selectLineNumber}
              style={{ width: 150 }}
              allowClear
              options={lineNumberList}
              suffixIcon={<CaretDownOutlined style={{ color: '#000' }} />}
              onChange={useCallback(
                (val) => {
                  setSelectLineNumber(val);
                  setSelectCallAreaInfo(null);
                  setLineData2([]);
                  setAreaPageIndex(1);
                  handleCallNumArea({ pageNum: 1, phone: val || 'none' });
                },
                [areaPageIndex, areaPageSize, date, lineId, selectLineNumber],
              )}
            />
          </div>
          <Table
            columns={columns2}
            dataSource={callNumAreaData}
            scroll={{ y: 600 }}
            rowKey={(record) => record.city}
            rowClassName={useCallback(
              (record: ICallNumArea) => {
                if (selectCallAreaInfo?.city === record?.city && !isToDay)
                  return styles.activity;
                return '';
              },
              [selectCallAreaInfo, isToDay],
            )}
            onRow={(record) => {
              return {
                onClick: () => {
                  setSelectCallAreaInfo(record);
                },
              };
            }}
            pagination={{
              pageSize: areaPageSize,
              showSizeChanger: true,
              current: areaPageIndex,
              total: areaTotal,
              showTotal: (total) => `总共 ${total} 条`,
              onChange: onAreaChange,
            }}
          />
        </div>
        {!isToDay && (
          <div className={styles.line}>
            <div className={styles.box}>
              <h3>外呼趋势</h3>
              <div id="lineNumber3"></div>
            </div>
            <div className={styles.box}>
              <h3>接通率趋势</h3>
              <div id="lineNumber4"></div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
export default memo(HistoryNumber);
