import React, { useCallback, useEffect, useState } from 'react';
import styles from './index.less';
import { Table, Select } from 'antd';
import { CaretDownOutlined } from '@ant-design/icons';
import {
  ICallNumArea,
  ICallNumUse,
  statisticsCallNumArea,
  statisticsCallNumUse,
} from '@/api/lineMonitor';
import { accMul } from '@/utils';
import { findNumberPage } from '@/api/lineSupplier';

interface PropsType {
  date?: string[];
  lineId?: string;
}

const TodayNumber: React.FC<PropsType> = ({ date, lineId }) => {
  const [callNumData, setCallNumData] = useState<ICallNumUse[]>([]);
  const [phonePageIndex, setPhonePageIndex] = useState(1);
  const [phonePageSize, setPhonePageSize] = useState(100);
  const [phoneTotal, setPhoneTotal] = useState(0);
  const [callNumAreaData, setCallNumAreaData] = useState<ICallNumArea[]>([]);
  const [areaPageIndex, setAreaPageIndex] = useState(1);
  const [areaPageSize, setAreaPageSize] = useState(100);
  const [areaTotal, setAreaTotal] = useState(0);
  const [lineNumberList, setLineNumberList] = useState([]);
  const [selectLineNumber, setSelectLineNumber] = useState('');

  const columns: any = [
    {
      title: '外显号码',
      dataIndex: 'callingNumber',
    },
    {
      title: '总并发',
      dataIndex: 'totalConcurrency',
    },
    {
      title: '实际并发',
      dataIndex: 'allocatedConcurrency',
    },
    {
      title: '使用率',
      dataIndex: 'allocatedConcurrency',
      render: (text, record: ICallNumUse) => {
        if (!text || !record.totalConcurrency) return 0;
        const _rate = (text / record.totalConcurrency).toFixed(2);
        return _rate + '%';
      },
    },
    {
      title: '外呼数',
      dataIndex: 'totalCall',
    },
    {
      title: '接通数',
      dataIndex: 'totalPut',
    },
    {
      title: '接通率',
      dataIndex: 'totalPutRate',
    },
  ];

  const columns2 = [
    {
      title: '排名',
      dataIndex: 'index',
    },
    {
      title: '省',
      dataIndex: 'province',
    },
    {
      title: '市',
      dataIndex: 'city',
    },
    {
      title: '外呼数',
      dataIndex: 'totalCall',
    },
    {
      title: '接通数',
      dataIndex: 'totalPut',
    },
    {
      title: '接通率',
      dataIndex: 'totalPutRate',
    },
  ];

  // 获取号码适用情况
  const handleCallNumUse = useCallback(async () => {
    const param = {
      lineGuid: lineId,
      startDate: date?.[0] || undefined,
      endDate: date?.[1] || undefined,
      pageNum: phonePageIndex,
      pageSize: phonePageSize,
    };
    const res = await statisticsCallNumUse(param);
    if (res?.success) {
      setCallNumData(res.data?.list);
      setPhoneTotal(res.data?.totalRecord);
    }
  }, [phonePageIndex, phonePageSize, date, lineId]);

  // 获取号码省市接通
  const handleCallNumArea = useCallback(async () => {
    const param = {
      lineGuid: lineId,
      startDate: date?.[0] || undefined,
      endDate: date?.[1] || undefined,
      pageNum: areaPageIndex,
      pageSize: areaPageSize,
      callingNumberList: selectLineNumber ? [selectLineNumber] : undefined,
    };
    const res = await statisticsCallNumArea(param);
    if (res?.success) {
      res.data?.list?.forEach((item, index) => {
        item.index =
          Number(accMul(Number(areaPageIndex) - 1, Number(areaPageSize))) +
          index +
          1;
      });
      setCallNumAreaData(res.data?.list);
      setAreaTotal(res.data?.totalRecord);
    }
  }, [areaPageIndex, areaPageSize, date, lineId, selectLineNumber]);

  // 分页
  const onPhoneChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      if (size !== phonePageSize) {
        setPhonePageIndex(1);
        setPhonePageSize(size);
      } else {
        setPhonePageIndex(page);
      }
    },
    [phonePageSize],
  );

  // 省市分页
  const onAreaChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      if (size !== areaPageSize) {
        setAreaPageIndex(1);
        setAreaPageSize(size);
      } else {
        setAreaPageIndex(page);
      }
    },
    [areaPageSize],
  );

  // 获取号码列表
  const handleLineNumber = useCallback(async () => {
    const params = {
      lineGuid: lineId,
      pageSize: 5000,
      pageNum: 1,
    };
    const res = await findNumberPage(params);
    if (res?.success) {
      setLineNumberList(res.data?.list || []);
    }
  }, [lineId]);

  useEffect(() => {
    handleLineNumber();
  }, [lineId]);

  useEffect(() => {
    if (lineId && date?.length) handleCallNumUse();
  }, [date, lineId, phonePageIndex, phonePageSize]);

  useEffect(() => {
    if (lineId && date?.length) handleCallNumArea();
  }, [date, lineId, areaPageIndex, areaPageSize, selectLineNumber]);

  return (
    <div className={styles.todaynumber}>
      <h2>号码适用情况</h2>
      <div className={styles.tableWrap}>
        <Table
          columns={columns}
          dataSource={callNumData}
          rowKey={(record) => record.callingNumber}
          pagination={{
            pageSize: phonePageSize,
            showSizeChanger: true,
            current: phonePageIndex,
            total: phoneTotal,
            showTotal: (total) => `总共 ${total} 条`,
            onChange: onPhoneChange,
          }}
        />
      </div>
      <h2>号码省市接通情况</h2>
      <div>
        请选择
        <Select
          bordered={false}
          fieldNames={{
            label: 'realCallingNumber',
            value: 'realCallingNumber',
          }}
          style={{ width: 150 }}
          allowClear
          options={lineNumberList}
          suffixIcon={<CaretDownOutlined style={{ color: '#000' }} />}
          onChange={(val) => setSelectLineNumber(val)}
        />
      </div>
      <div className={styles.tableWrap}>
        <Table
          columns={columns2}
          dataSource={callNumAreaData}
          rowKey={(record) => record.city}
          pagination={{
            pageSize: areaPageSize,
            showSizeChanger: true,
            current: areaPageIndex,
            total: areaTotal,
            showTotal: (total) => `总共 ${total} 条`,
            onChange: onAreaChange,
          }}
        />
      </div>
    </div>
  );
};
export default TodayNumber;
