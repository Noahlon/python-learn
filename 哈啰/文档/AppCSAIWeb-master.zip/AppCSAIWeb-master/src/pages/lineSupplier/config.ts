export const supportCarrierOpts = [
  { label: '中国移动', value: 1 },
  { label: '中国联通', value: 2 },
  { label: '中国电信', value: 3 },
  { label: '虚拟', value: 4 },
  { label: '未知', value: 5 },
];

export const supplierSearchTypes = [
  { label: '供应商名称', value: 'supplierName' },
  { label: '主叫号码', value: 'callingNumber' },
  { label: '线路名称', value: 'supporterLineName' },
];
