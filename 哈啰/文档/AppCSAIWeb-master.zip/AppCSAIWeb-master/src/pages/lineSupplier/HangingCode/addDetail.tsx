import React, { FC, useEffect, useState, useMemo } from 'react';
import {
  Drawer,
  Button,
  Space,
  Form,
  message,
  Select,
  Input,
} from 'antd';
import { addSignalling, editSignalling } from '@/api/signalling';

interface DrawerUpdateType {
  openType: number | undefined;
  rowData?: any;
  onClose: () => void;
  loadData?: () => void;
  supplierGuid?: string;
  resultList?: any[]
}

const BasicDrawer: FC<DrawerUpdateType> = ({
  openType,
  onClose,
  rowData,
  loadData,
  supplierGuid,
  resultList,
}) => {
  const [forms] = Form.useForm();
  const [loading, setLoading] = useState(false);

  const drawerTitle = useMemo(() => {
    if (openType === 1) {
      return '新增';
    }
    return '编辑';
  }, [openType]);

  useEffect(() => {
    if (openType === 2 && rowData) {
      const { callResultContrast } = rowData
      forms.setFieldsValue({
        ...rowData,
        callResultContrast: callResultContrast && Number(callResultContrast)
      })
    }
  }, [rowData, openType])

  const handleOk = () => {
    const api = openType === 1 ? addSignalling : editSignalling
    forms.validateFields().then((val: any) => {
      setLoading(true)
      try {
        api({
          ...val,
          interpretation: val?.interpretation?.trim(),
          supplierGuid,
          guid: rowData ? rowData.guid : undefined,
        }).then((res) => {
          if (res.success) {
            message.success(`${openType === 1 ? '新增' : '更新'}成功`);
            onClose();
            loadData?.();
            setLoading(false)
          } else {
            setLoading(false)
          }
        });
      } catch (e) {
        console.log(e)
        setLoading(false)
      }
    });
  };

  return (
    <Drawer
      open={!!open}
      title={drawerTitle}
      maskClosable={false}
      placement="right"
      onClose={() => onClose()}
      width={600}
      destroyOnClose
      footer={
        <div style={{ textAlign: 'right' }}>
          <Space size={36}>
            <Button onClick={() => onClose()}>取消</Button>
            <Button type="primary" onClick={handleOk} loading={loading}>
              确定
            </Button>
          </Space>
        </div>
      }
    >
      <div style={{ paddingRight: 40 }}>
        <Form
          name="basic"
          labelCol={{ span: 8 }}
          wrapperCol={{ span: 16 }}
          autoComplete="off"
          form={forms}
        >
          <Form.Item
            label="信令码"
            name={'signallingCode'}
            rules={[
              { required: true },
              {
                pattern: /^[1-9]\d{0,9}$/,
                message: '请输入10位以内的正整数',
              },
            ]}
          >
            <Input maxLength={10} />
          </Form.Item>
          <Form.Item
            label="释义"
            name={'interpretation'}
            rules={[
              { required: true },
              {
                validator: (_, value: string) => {
                  if (value && !value?.trim()) {
                    return Promise.reject("请输入释义");
                  }
                  return Promise.resolve();
                },
              }
            ]}
          >
            <Input.TextArea
              maxLength={1000}
              showCount
              autoSize={{ minRows: 3, maxRows: 10 }}
            />
          </Form.Item>
          <Form.Item
            label="映射系统外呼结果"
            name="callResultContrast"
            rules={[{ required: true }]}
          >
            <Select
              options={resultList}
              showSearch
              placeholder="请选择映射系统外呼结果"
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
              filterOption={(input, option: any) =>
                (option?.label ?? '').includes(input)
              }
            />
          </Form.Item>
        </Form>
      </div>
    </Drawer>
  );
};
export default BasicDrawer;
