import React, { useState } from 'react';
import {
  UploadOutlined,
  DownloadOutlined
} from '@ant-design/icons';
import moment from 'moment';
import { throttle } from 'lodash';
import { Button, Modal, message, Upload } from 'antd';
import { UploadFile } from 'antd/es/upload';
import { uploadMusic } from '@/api/language';
import { template, importSignalling } from '@/api/signalling';
import { downloadCustomNameFile } from '@/utils';
import styles from './style.less';

interface Prop {
  visible: boolean;
  onCancel: () => void;
  loadData: () => void;
  supplierGuid?: string;
}

const UploadModal: React.FC<Prop> = ({ onCancel, loadData, visible, supplierGuid }) => {
  const [upLoading, setUpLoading] = useState<boolean>(false);
  const [fileList, setFileList] = useState<any[]>([]);
  const [importData, setImportData] = useState(null);

  const handleImportCancel = () => {
    onCancel?.()
  }
  // 下载模板
  const downLoadTemplate = async () => {
    const res = await template();
    if (res?.success) {
      const nowTime = moment().format('YYYYMMDDHHmmss');
      const exportName = `信令码导入模版${nowTime}.xlsx`;
      downloadCustomNameFile(res.data, exportName)
    }
  };

  // 上传
  const handleUpload = async ({ file }: any) => {
    setUpLoading(true);
    const formData = new FormData();
    formData.append('file', file);
    const uid = Date.now()
    setFileList([
      {
        uid: uid,
        name: file.name,
        status: 'uploading',
      },
    ]);
    try {
      const res = (await uploadMusic(formData)) as any;
      const resp = (await importSignalling({
        ossUrl: res?.url,
        supplierGuid,
      })) as any;
      if (resp.success) {
        message.success("上传成功")
        setFileList([
          {
            uid: uid,
            name: file.name,
            status: 'done',
            url: res?.url,
          },
        ]);
        setImportData(resp.data)
        loadData?.()
      } else {
        setFileList([
          {
            uid: uid,
            name: file.name,
            status: 'error',
          },
        ]);
      }
    } catch (e) {
      message.error('上传失败')
      setFileList([
        {
          uid: uid,
          name: file.name,
          status: 'error',
        },
      ]);
    } finally {
      setUpLoading(false);
    }
  };

  const handleBeforeUpload = (file: UploadFile) => {
    const isLtFile = file.size / 1024 / 1024 <= 10;
    const fileName = file.name;
    const fileType = fileName?.split('.').pop();

    if (!isLtFile) {
      message.error('上传文件大小不能超过10M');
      return false;
    }

    if (!['xlsx', 'xls'].includes(fileType)) {
      message.error('文件上传文件格式错误');
      return false;
    }
    return true;
  };
  const removeFiles = (file: UploadFile) => {
    setFileList((pre) => {
      const _fileList = pre.filter((item) => item.uid !== file.uid);
      return _fileList;
    });
  };

  return (
    <Modal
      open={visible}
      title="上传"
      width={600}
      onCancel={handleImportCancel}
      footer={false}
      destroyOnClose={true}
    >
      <div className={styles.importBox}>
        <Upload
          maxCount={1}
          fileList={fileList}
          accept=".xls,.xlsx"
          customRequest={(info) => handleUpload(info)}
          onRemove={(file) => removeFiles(file)}
          beforeUpload={handleBeforeUpload}
          disabled={upLoading}
        >
          <Button loading={upLoading} icon={<UploadOutlined />}>点击上传</Button>
        </Upload>
        <div className={styles.uploadType}>
          请上传xls、xlsx文件，大小在10M以内
        </div>
        <Button type="link" size="small" onClick={throttle(() => downLoadTemplate(), 5000)}>
          <DownloadOutlined />
          下载模版
        </Button>
        {fileList?.length > 0 && (
          <div className={styles.footer}>
            {importData?.failReasonUrl && (
              <Button type="link" size="small" onClick={throttle(() => {
                const nowTime = moment().format('YYYYMMDDHHmmss');
                const exportName = `信令码失败数据文件${nowTime}.xlsx`;
                downloadCustomNameFile(importData?.failReasonUrl, exportName)
              }, 5000)}>
                <DownloadOutlined />
                下载失败数据
              </Button>
            )}
          </div>
        )}
      </div>
    </Modal>
  );
};

export default UploadModal;
