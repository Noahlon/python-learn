import React, { FC, useEffect, useState } from 'react';
import {
  Alert,
  Table,
  Button,
  message,
  Space,
  Tooltip,
  Popconfirm,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { getCallResultList, getSignallingList, deleteSignalling, signallingListType } from '@/api/signalling';
import styles from './style.less';
import AddDetail from './addDetail';
import Import from './Import';

interface LineListTableType {
  activeKey?: string;
  id?: string;
}

const LineListTable: FC<LineListTableType> = ({
  activeKey,
  id,
}) => {
  const [resultList, setResultList] = useState<any[]>([]);
  const [dataSource, setDataSource] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [openImport, setOpenImport] = useState<boolean>(false);
  const [openType, setOpenType] = useState<number | null>();
  const [rowData, setRowData] = useState<any>(null);
  const [params, setParams] = useState<any>({
    pageNum: 1,
    pageSize: 100,
  })
  const onInit = () => {
    getCallResultList().then((res) => {
      if (res.success && res.data) {
        const options = res.data.map((item: any) => ({
          label: item.desc,
          value: item.status
        }))
        setResultList(options)
      } else {
        setResultList([])
      }
    })
  }
  useEffect(() => {
    onInit()
  }, [])

  const loadData = async () => {
    setLoading(true)
    try {
      const res = await getSignallingList({
        ...params,
        supplierGuid: id,
      });
      if (res.data && res.success) {
        setDataSource(res.data);
      }
    } catch (e) {
      console.log(e)
    } finally {
      setLoading(false)
    }
  };
  /** 点击分页查询当前页数据 */
  const handleTableChange = (
    page: number | undefined,
    size: number | undefined,
  ) => {
    if (size !== params.pageSize) {
      setParams({
        ...params,
        pageNum: 1,
        pageSize: size,
      });
    } else {
      setParams({
        ...params,
        pageNum: page,
        pageSize: size,
      });
    }
  };

  useEffect(() => {
    if (activeKey === "hangingCode") {
      setParams({
        pageNum: 1,
        pageSize: 100,
      })
    }
    return (() => {
      setDataSource(null)
    })
  }, [activeKey, id])

  useEffect(() => {
    loadData();
  }, [params])
  // 删除
  const onDelete = (record: any) => {
    deleteSignalling({ guid: record.guid }).then((res) => {
      if (res.success) {
        message.success('删除成功');
        if (dataSource?.list.length === 1 && params.pageNum > 1) {
          setParams({
            ...params,
            pageNum: params.pageNum - 1,
          })
        } else {
          loadData()
        }
      }
    });
  };
  // 新增、编辑
  const onOpenModal = (type: any, record: any) => {
    setOpenType(type);
    if (record) {
      setRowData(record)
    }
  };
  const handleCancel = () => {
    setOpenType(null);
    setRowData(null);
  };
  // 导入
  const onOpenImport = () => {
    setOpenImport(true);
  };
  const importCancel = () => {
    setOpenImport(false);
  };

  const columns: ColumnsType<signallingListType> = [
    {
      title: '信令码',
      dataIndex: 'signallingCode',
      key: 'signallingCode',
      width: 200,
      render: (text: number | string) => text || '-',
    },
    {
      title: '释义',
      dataIndex: 'interpretation',
      key: 'interpretation',
      width: 400,
      render: (text: string) => (
        <Tooltip title={text} overlayStyle={{ maxWidth: '1000px' }}>
          <div className={styles.ellipsis3}>{text || '-'}</div>
        </Tooltip>
      ),
    },
    {
      title: '映射系统外呼结果',
      dataIndex: 'callResultContrastDesc',
      key: 'callResultContrastDesc',
      width: 100,
    },
    {
      title: '操作',
      dataIndex: 'options',
      key: 'options',
      fixed: 'right',
      width: 100,
      render: (_, record: any) => {
        return <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
          <Button
            type="link"
            size="small"
            onClick={() => onOpenModal(2, record)}
          >
            编辑
          </Button>
          <Popconfirm
            title="你确定要删除吗?"
            onConfirm={() => onDelete(record)}
            okText="确定"
            cancelText="取消"
          >
            <Button type="link" size="small">
              删除
            </Button>
          </Popconfirm>
        </div>;
      },
    },
  ];

  return (
    <div className={styles.hangingCodeContainer}>
      <Alert
        type="info"
        showIcon
        message={'挂机码配置说明'}
        description={
          <div>
            1、请配置未接通场景的挂机码，接通信令不需要配置
            <br />
            2、话单的呼叫结果会优先根据挂机码配置的映射结果来赋值，若没有配置统一归到未接通
          </div>
        }
      />
      <div className={styles.content}>
        <div className={styles.headerContent}>
          <Space size={16}>
            <Button type="primary" onClick={() => onOpenModal(1, null)}>
              新增
            </Button>
            <Button type="primary" onClick={onOpenImport}>
              导入
            </Button>
          </Space>
        </div>
        <Table
          rowKey={'guid'}
          columns={columns}
          dataSource={dataSource?.list || []}
          loading={loading}
          scroll={{
            y: 'calc(100vh - 460px)',
          }}
          pagination={{
            showSizeChanger: true,
            total: dataSource?.totalRecord || 0,
            pageSize: params.pageSize,
            current: params.pageNum,
            pageSizeOptions: [10, 20, 50, 100],
            onChange: handleTableChange,
            showTotal: (total) => `共 ${total} 项`,
          }}
        />
      </div>

      {openType && (
        <AddDetail
          openType={openType}
          rowData={rowData}
          loadData={loadData}
          onClose={handleCancel}
          resultList={resultList}
          supplierGuid={id}
        />
      )}
      {openImport && (
        <Import
          visible={openImport}
          onCancel={importCancel}
          loadData={loadData}
          supplierGuid={id}
        />
      )}
    </div>
  );
};
export default LineListTable;
