import React, { FC, useEffect, useRef, useState } from 'react';
import { DatePicker, Button, Table, Pagination } from 'antd';
import { lineStatisticsList, lineListType } from '@/api/lineSupplier';
import { timeRanges } from '@/config';
import styles from './index.less';
import { useAccess } from '@umijs/max';
import moment from 'moment';
interface DataStatisticType {
  tabsKey?: string;
  id?: string;
}

const DataStatistic: FC<DataStatisticType> = ({ tabsKey, id }) => {
  const access = useAccess();
  const [pageNumber, setPageNumber] = useState<number>(1);
  const [total, setTotal] = useState<number>(0);
  const [pageSize, setPageSize] = useState<number>(20);
  const [dataSource, setDataSource] = useState([]);
  const params = useRef<lineListType>({
    supplierGuid: id,
    startDate: undefined,
    endDate: undefined,
    pageSize: pageSize,
    pageNum: pageNumber,
  });
  const { RangePicker } = DatePicker;

  const columns: any = [
    { title: '日期', dataIndex: 'date', width: 150, fixed: 'left' },
    { title: '线路名称', dataIndex: 'lineName' },
    { title: '主叫号码', dataIndex: 'callOutNumber' },
    { title: '外呼数', dataIndex: 'totalCall' },
    { title: '接通数', dataIndex: 'totalPut' },
    {
      title: '接通率',
      dataIndex: 'putCall',
      render: (_, record) => {
        if (record.totalPut && record.totalCall) {
          return <>{(record.totalPut / record.totalCall).toFixed(2)}%</>;
        }
        return '0%';
      },
    },
    { title: '计费单元', dataIndex: 'costUnit' },
    {
      title: '接通时长',
      dataIndex: 'communicateTime',
      render: (_, record) => {
        if (record.communicateTime) {
          return <>{record.communicateTime} 秒</>;
        }
        return '';
      },
    },
    {
      title: '平均接通时长',
      dataIndex: 'averageCommunicateTime',
      render: (_, record) => {
        if (record.totalPut && record.communicateTime) {
          return <>{Math.ceil(record.communicateTime / record.totalPut)} 秒</>;
        }
        return '0%';
      },
    },
    { title: '秒挂数', dataIndex: 'totalSecondsHang' },
    {
      title: '秒挂占比',
      dataIndex: 'secondsHangPut',
      render: (_, record) => {
        if (record.totalPut && record.totalSecondsHang) {
          return <>{(record.totalSecondsHang / record.totalPut).toFixed(2)}%</>;
        }
        return '0%';
      },
    },
    { title: '未说话数', dataIndex: 'totalNoInteraction' },
    {
      title: '未说话占比',
      dataIndex: 'totalNoInteractionPut',
      render: (_, record) => {
        if (record.totalPut && record.totalNoInteraction) {
          return (
            <>{(record.totalNoInteraction / record.totalPut).toFixed(2)}%</>
          );
        }
        return '0%';
      },
    },
  ];

  const initData = async () => {
    let res = await lineStatisticsList(params.current);

    if (res.success && res.data) {
      setDataSource(res.data.list);
      setTotal(res.data.totalRecord);
    } else {
      setDataSource([]);
      setTotal(0);
    }
  };

  // 时间改变
  const handleTimeChange = (dateStrings) => {
    if (dateStrings) {
      params.current.startDate = moment(dateStrings[0] || undefined).format(
        'YYYY-MM-DD HH:mm:ss',
      );
      params.current.endDate = moment(dateStrings[1] || undefined).format(
        'YYYY-MM-DD HH:mm:ss',
      );
    } else {
      params.current.startDate = undefined;
      params.current.endDate = undefined;
    }
    initData();
  };

  const handlePageChange = (pageNum, size) => {
    setPageSize(size);
    setPageNumber(pageNum);
    params.current.pageSize = size;
    params.current.pageNum = pageNum;
    initData();
  };

  useEffect(() => {
    params.current.supplierGuid = id;
    // eslint-disable-next-line @typescript-eslint/no-unused-expressions
    tabsKey === 'dataTabs' && initData();
  }, [tabsKey, id]);

  return (
    <div className={styles.dataS}>
      <div className={styles.dataStatistic}>
        <div>
          <RangePicker
            style={{ width: '100%' }}
            format="YYYY-MM-DD HH:mm:ss"
            ranges={timeRanges}
            onChange={handleTimeChange}
          />
        </div>
        {access?.authCodeList?.includes('Call-Line-Linesupplier-Export') && (
          <div>
            <Button type="primary">导出</Button>
          </div>
        )}
      </div>
      <div className={styles.dataTableBox}>
        <div className={styles.dataTable}>
          <Table
            columns={columns}
            dataSource={dataSource}
            loading={false}
            rowKey={(_, index) => index}
            pagination={false}
            scroll={{ x: 1800 }}
          ></Table>
        </div>
        <div className={styles.dataStatisticPage}>
          <Pagination
            total={total}
            showSizeChanger={true}
            pageSize={20}
            onChange={handlePageChange}
            showTotal={(total) => `${total} 条数据`}
          />
        </div>
      </div>
    </div>
  );
};
export default DataStatistic;
