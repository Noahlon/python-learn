/* eslint-disable @typescript-eslint/no-unused-expressions */
import React, { FC, useEffect, useState } from 'react';
import { Drawer, Button, Space, Form, Spin, message } from 'antd';
import moment from 'moment';
import { lineSync, findNumberPage } from '@/api/lineSupplier';
import { useModel } from '@umijs/max';
import styles from './drawer.less';
interface DrawerUpdateType {
  openType: number | undefined;
  setOpenType: (type) => void;
  loadData?: () => void;
  rowData?: any;
}

// openType 10  获取配置
// openType 1  更新
// openType 3  发布

const BasicDrawer: FC<DrawerUpdateType> = ({
  openType,
  setOpenType,
  rowData,
  loadData,
}) => {
  const { lineSupplierRowHandleId } = useModel('global');
  const [numList, setNumList] = useState([]);
  const [pageNum, setPageNum] = useState(1);
  const [loading, setLoading] = useState(false);
  const [totalPages, setTotalPages] = useState(1);
  const drawerTitle = () => {
    // 静态数据
    // openType 10 获取配置   1 发布  2 更新
    switch (openType) {
      case 3:
        return '发布线路至呼叫中心？';
      case 1:
        return '更新线路至呼叫中心？';
      case 10:
        return '呼叫中心配置信息';
      default:
        return null;
    }
  };

  const handleOk = async () => {
    const res = await lineSync({ guid: lineSupplierRowHandleId });
    if (res.success) {
      message.success(`${openType === 1 ? '更新' : '发布'}成功`);
      loadData?.();
      setOpenType(undefined);
    }
  };

  const rendorFooter = () => {
    return (
      (openType === 3 || openType === 1) && (
        <div style={{ textAlign: 'right' }}>
          <Space>
            <Button onClick={() => setOpenType(undefined)}>取消</Button>
            <Button type="primary" onClick={handleOk}>
              确定
            </Button>
          </Space>
        </div>
      )
    );
  };

  // 下拉加载号码
  const loadMore = async () => {
    setLoading(true);
    //  获取配置 需要筛选 已发布的状态 syncStatus
    //  发布 or 更新 需要筛选 已启用的状态 status
    const params = {
      lineGuid: lineSupplierRowHandleId,
      pageSize: 100,
      pageNum: pageNum,
      syncStatus: openType === 10 ? 1 : null,
      status: openType === 10 ? null : 1,
    };
    const res = await findNumberPage(params);
    if (res.success && res.data.list) {
      setTotalPages(res.data.totalPages);
      setNumList((list) => list.concat(res.data.list));
      // if (openType === 10) {
      //   const arr = res.data.list.filter((item) => item.syncStatus === 1);
      //   setNumList((list) => list.concat(arr));
      // } else {
      //   const arr = res.data.list.filter((item) => item.status === 1);
      //   setNumList((list) => list.concat(arr));
      // }
    }
    setLoading(false);
  };

  const hanldeClose = () => {
    setOpenType(undefined);
    setNumList([]);
  };

  useEffect(() => {
    // 弹框打开才调用接口
    if (openType) {
      loadMore();
    }
    return function () {
      setPageNum(1);
      setNumList([]);
    };
  }, [openType]);

  useEffect(() => {
    // 弹框打开才调用接口
    if (openType) {
      loadMore();
    }
  }, [pageNum]);

  return (
    <>
      <Drawer
        className={styles.drawerDesc}
        open={!!openType}
        title={drawerTitle()}
        closable={false}
        placement="right"
        onClose={hanldeClose}
        width={450}
        footer={rendorFooter()}
        destroyOnClose
      >
        <Form name="basic" labelCol={{ span: 6 }} autoComplete="off">
          {openType === 3 && (
            <Form.Item label="发布时间">
              {moment().format('YYYY.MM.DD HH:mm:ss')}
            </Form.Item>
          )}
          {openType === 1 && (
            <Form.Item label="更新时间">
              {moment().format('YYYY.MM.DD HH:mm:ss')}
            </Form.Item>
          )}
          {openType === 10 && (
            <Form.Item label="最近更新">{rowData?.publishTime}</Form.Item>
          )}
          <Form.Item label="线路ID">{rowData?.guid}</Form.Item>
          <Form.Item label="线路名称">{rowData?.supporterLineName}</Form.Item>
          <Form.Item label="主叫号码">{rowData?.callingNumber}</Form.Item>
          <Form.Item label="对接IP">{rowData?.lineIp}</Form.Item>
          <Form.Item label="端口号">{rowData?.port}</Form.Item>
          {numList.length ? (
            <Form.Item label="号码">
              <Spin spinning={loading}>
                <div
                  style={{
                    maxHeight: '200px',
                    overflow: 'auto',
                    marginTop: '5px',
                  }}
                >
                  {numList?.map((item) => {
                    return <div key={item.guid}>{item?.realCallingNumber}</div>;
                  })}
                  <div style={{ margin: '20px 0' }}>
                    {pageNum < totalPages && (
                      <Button
                        onClick={() => {
                          setPageNum((num) => num + 1);
                        }}
                      >
                        加载更多...
                      </Button>
                    )}
                  </div>
                </div>
              </Spin>
            </Form.Item>
          ) : (
            ''
          )}
        </Form>
      </Drawer>
    </>
  );
};
export default BasicDrawer;
