import React, { useState, useEffect } from 'react';
import {
  Modal,
  message,
  Form,
  Table,
  Button,
  Typography,
  InputNumber,
  Select,
  Popconfirm,
} from 'antd';
import {
  queryAllTenantLinePage,
  addTenantLine,
  unbindTenantLine,
  queryTenantLineBindGroup,
  updateTenantParallel,
} from '@/api/lineSupplier';
import { tenantList } from '@/api/tenantManage';
import { ExclamationCircleOutlined } from '@ant-design/icons';
import { useModel } from '@umijs/max';
import UBT from '@/utils/ubt';

import { v1 as uuidv1 } from 'uuid';

const { Link } = Typography;

interface Props {
  visible: boolean;
  onOk: () => void;
  onCancel: () => void;
  rowData: any;
}

interface IList {
  tenantId: string;
  tenantCode: number;
  lineGroupGuid: string;
  lineGroupName: string;
  parallelNum: number;
  maxUseParallelNum: number;
}

interface EditableCellProps extends React.HTMLAttributes<HTMLElement> {
  editing: boolean;
  creating: boolean;
  dataIndex: string;
  title: any;
  record: IList;
  index: number;
  children: React.ReactNode;
}

const LineLinkModal: React.FC<Props> = (props) => {
  const { visible, onCancel, rowData } = props;
  const [form] = Form.useForm();
  const { userInfo } = useModel('global');
  const [data, setData] = useState([]);
  const [editingKey, setEditingKey] = useState<string | number>(''); //新增时单条数据key
  const [batchEditKeys, setBatchEditKeys] = useState([]); //编辑时所有数据key
  const [loading, setLoading] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);

  const isEditing = (record: IList) => record.lineGroupGuid === editingKey;

  //租户options
  const [tenantOptions, setTenantOptions] = useState([]);
  //线路组options
  const [lineGroupOptions, setLineGroupOptions] = useState([]);

  // 通过租户查询可关联的线路组
  const getTenantLineBindGroup = async (tenantId: string) => {
    const { data } = await queryTenantLineBindGroup({
      tenantCode: tenantId + '',
      lineGuid: rowData.guid,
    });
    if (data) {
      let opt = [];
      data.forEach((it) => {
        opt.push({
          value: it.lineGroupGuid,
          label: it.lineGroupName,
        });
      });
      setLineGroupOptions(opt);
    }
  };

  const EditableCell: React.FC<EditableCellProps> = ({
    editing,
    creating,
    dataIndex,
    record,
    children,
    ...restProps
  }) => {
    if (!creating && !editing) {
      return <td {...restProps}>{children}</td>;
    }
    let inputNode;
    if (['parallelNum', 'maxUseParallelNum'].includes(dataIndex)) {
      inputNode = (
        <Form.Item
          name={dataIndex + '_' + record.lineGroupGuid}
          style={{ margin: 0 }}
          rules={[
            {
              required: true,
              message: ``,
            },
            {
              validator: (_, value) => {
                if (value && value > rowData?.concurrentLimit) {
                  return Promise.reject(
                    `请输入小于等于${rowData?.concurrentLimit}的数字`,
                  );
                }
                return Promise.resolve();
              },
            },
          ]}
        >
          <InputNumber
            placeholder="请输入"
            min={0}
            max={9999999}
            precision={0}
            controls={false}
          />
        </Form.Item>
      );
    }
    if (dataIndex === 'tenantCode') {
      inputNode = creating ? (
        <Form.Item
          name={dataIndex}
          style={{ margin: 0 }}
          rules={[
            {
              required: true,
              message: '',
            },
          ]}
        >
          <Select
            onChange={(e) => {
              setLineGroupOptions([]);
              form.setFieldsValue({ lineGroupGuid: null });
              getTenantLineBindGroup(e);
            }}
            showSearch
            filterOption={(input, option: any) =>
              (option?.label ?? '').includes(input)
            }
            placeholder="请选择"
            style={{ width: '200px' }}
            options={tenantOptions}
          />
        </Form.Item>
      ) : (
        children
      );
    }
    if (dataIndex === 'lineGroupGuid') {
      inputNode = creating ? (
        <Form.Item
          name={dataIndex}
          style={{ margin: 0 }}
          rules={[
            {
              required: true,
              message: '',
            },
          ]}
        >
          <Select
            showSearch
            filterOption={(input, option: any) =>
              (option?.label ?? '').includes(input)
            }
            placeholder="请选择"
            style={{ width: '200px' }}
            options={lineGroupOptions}
          />
        </Form.Item>
      ) : (
        children
      );
    }

    return <td {...restProps}>{inputNode}</td>;
  };

  const cancel = (record) => {
    setEditingKey('');
    setBatchEditKeys([]);
    const newData = data.filter(
      (item) => item.lineGroupGuid !== record.lineGroupGuid,
    );
    setData([...newData]);
  };

  const getDataList = () => {
    setLoading(true);
    queryAllTenantLinePage({ lineGuid: rowData.guid })
      .then((res) => {
        if (res?.success) {
          setData(res?.data);
        }
      })
      .finally(() => {
        setLoading(false);
      });
  };

  const handleAdd = () => {
    if (editingKey) {
      return message.info('存在未编辑完成的记录，请提交后再新增');
    }
    const uuid = uuidv1();
    const newData = {
      lineGroupGuid: uuid,
      tenantCode: '',
      lineGroupName: '',
      parallelNum: '',
      maxUseParallelNum: '',
    };
    const parallelNumKey = 'parallelNum_' + uuid;
    const maxUseParallelNumKey = 'maxUseParallelNum_' + uuid;
    form.setFieldsValue({
      tenantCode: null,
      lineGroupGuid: null,
      [parallelNumKey]: '',
      [maxUseParallelNumKey]: '',
    });
    setEditingKey(uuid);
    setData([newData, ...data]);
  };

  //编辑
  const handleEdit = async () => {
    try {
      UBT.clickButton({
        pageId: 'iot_LineCorrelationStatus',
        buttonName: 'iot_LineCorrelationStatus_EditButton',
        categoryId: 'iot',
        businessInfo: {
          username: userInfo.realName,
        },
      });
    } catch (e) {}
    const editKeys = data.map((item) => item.lineGroupGuid);
    let formKeys = {};
    data.forEach((item) => {
      formKeys[`parallelNum_${item.lineGroupGuid}`] = item.parallelNum;
      formKeys[`maxUseParallelNum_${item.lineGroupGuid}`] =
        item.maxUseParallelNum;
    });
    setBatchEditKeys(editKeys);
    form.setFieldsValue(formKeys);
    //表单赋值后，重新校验表单，判断是否存在大于最大使用上限的情况
    setTimeout(() => {
      form.validateFields();
    }, 0);
  };

  //提交新增
  const save = async () => {
    try {
      const row = (await form.validateFields()) as IList;
      const params = {
        lineGuid: rowData.guid,
        lineGroupGuid: row.lineGroupGuid,
        tenantCode: row.tenantCode,
        parallelNum: row?.['parallelNum_' + editingKey],
        maxUseParallelNum: row?.['maxUseParallelNum_' + editingKey],
      };
      addTenantLine(params).then((res) => {
        if (res.success) {
          message.success('保存成功');
          getDataList();
          setEditingKey('');
        }
      });
    } catch (errInfo) {
      console.log('Validate Failed:', errInfo);
    }
  };

  //编辑提交
  const handleBatchSave = async () => {
    const row = (await form.validateFields()) as IList;
    let updateList = [];
    //遍历表格keys
    batchEditKeys.forEach((key) => {
      updateList.push({
        lineGroupGuid: key,
        parallelNum: row[`parallelNum_${key}`],
        maxUseParallelNum: row[`maxUseParallelNum_${key}`],
        lineGuid: rowData.guid,
      });
    });
    setSubmitLoading(true);
    updateTenantParallel({
      updateList,
    })
      .then((res) => {
        if (res.code === '0') {
          message.success('保存成功');
          setBatchEditKeys([]);
          getDataList();
          form.resetFields();
        }
      })
      .finally(() => {
        setSubmitLoading(false);
      });
  };

  const handleBatchCancel = () => {
    setBatchEditKeys([]);
    form.resetFields();
  };

  const handleOpenChange = async (newOpen: boolean) => {
    if (!newOpen) {
      setConfirmOpen(newOpen);
      return;
    }
    try {
      const row = (await form.validateFields()) as IList;
      if (row) {
        setConfirmOpen(newOpen);
      }
    } catch (errInfo) {
      console.log('Validate Failed:', errInfo);
    }
  };

  const handleUnbind = (record) => {
    //线路禁用状态/未发布状态  解除关联不需要二次确认，直接解除成功
    //该状态下不支持编辑
    if (rowData.status !== 1 || rowData.syncStatus !== 1) {
      unbindTenantLine({
        lineGuid: rowData.guid,
        lineGroupGuid: record.lineGroupGuid,
        forceUnBind: true,
      }).then((res) => {
        if (res.success) {
          message.success('解除关联成功');
          getDataList();
        }
      });
    } else {
      //forceUnBind false-非强制解绑，触发校验逻辑 true-强制解绑
      unbindTenantLine({
        lineGuid: rowData.guid,
        lineGroupGuid: record.lineGroupGuid,
        forceUnBind: false,
      }).then((res) => {
        if (res.success) {
          //withoutCallLine - true 触发校验，当前为最后一根线路组
          Modal.confirm({
            title: res?.data?.withoutCallLine
              ? '解除关联后，线路组下的关联线路数为0，是否继续解除关联？'
              : '解除线路后线路组并发会减少，正在执行调度的任务会受到影响，是否继续解除关联',
            icon: <ExclamationCircleOutlined />,
            onOk() {
              unbindTenantLine({
                lineGuid: rowData.guid,
                lineGroupGuid: record.lineGroupGuid,
                forceUnBind: true,
              }).then((res) => {
                if (res?.success) {
                  message.success('解除关联成功');
                  //如果当前是编辑状态，则更新编辑的keys
                  if (batchEditKeys?.length) {
                    setBatchEditKeys(
                      batchEditKeys.filter(
                        (key) => key !== record.lineGroupGuid,
                      ),
                    );
                  }
                  //如果是新增场景下，清空editkey，重置为查看模式
                  if (editingKey) {
                    setEditingKey('');
                  }
                  getDataList();
                }
              });
            },
            onCancel() {},
          });
        }
      });
    }
  };

  const columns = [
    {
      title: '租户',
      dataIndex: 'tenantCode',
      editable: true,
      with: 250,
      render: (_, row) => {
        return row?.tenantName;
      },
    },
    {
      title: '线路组名称',
      dataIndex: 'lineGroupGuid',
      editable: true,
      with: 300,
      render: (_, row) => {
        return row.lineGroupName;
      },
    },
    {
      title: '使用并发',
      dataIndex: 'parallelNum',
      editable: true,
      render: (_, row) => {
        return (
          <span
            style={{
              color:
                rowData?.concurrentLimit < _
                  ? '#ff4d4f'
                  : 'rgba(0, 0, 0, 0.85)',
            }}
          >
            {row.parallelNum}
          </span>
        );
      },
    },
    {
      title: '最大使用上限',
      dataIndex: 'maxUseParallelNum',
      editable: true,
      render: (_, row) => {
        return (
          <span
            style={{
              color:
                rowData?.concurrentLimit < _
                  ? '#ff4d4f'
                  : 'rgba(0, 0, 0, 0.85)',
            }}
          >
            {row.maxUseParallelNum}
          </span>
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'operation',
      with: 160,
      render: (_: any, record: IList) => {
        const editable = isEditing(record);
        return editable ? (
          <span style={{ minWidth: 90, display: 'flex', alignItems: 'center' }}>
            <Link onClick={() => save()}>确定</Link>
            <Button type="link" danger onClick={() => cancel(record)}>
              取消
            </Button>
          </span>
        ) : (
          <Link onClick={() => handleUnbind(record)}>解除关联</Link>
        );
      },
    },
  ];

  const mergedColumns = columns.map((col) => {
    if (!col.editable) {
      return col;
    }
    return {
      ...col,
      onCell: (record: IList) => ({
        record,
        dataIndex: col.dataIndex,
        title: col.title,
        creating: isEditing(record),
        editing: batchEditKeys.includes(record.lineGroupGuid),
        colSpan: 1,
      }),
    };
  });

  // 获取租户列表
  const getTenantList = async () => {
    const { data } = await tenantList({ pageNum: 1, pageSize: 999 });
    let option = [];
    data.forEach((it) => {
      option.push({
        value: it.tenant,
        label: it.name,
      });
    });
    setTenantOptions(option);
  };

  useEffect(() => {
    if (visible) {
      try {
        UBT.pageView({
          pageId: 'iot_LineCorrelationStatus',
          categoryId: 'iot',
          businessInfo: {},
        });
      } catch (e) {}
      getDataList();
      getTenantList();
    }
    return () => {
      setEditingKey('');
      setBatchEditKeys([]);
      try {
        UBT.pageViewOut({
          pageId: 'iot_LineCorrelationStatus',
          categoryId: 'iot',
          businessInfo: {},
        });
      } catch (e) {}
    };
  }, [visible]);

  return (
    <Modal
      title="关联情况"
      visible={visible}
      footer={''}
      onCancel={onCancel}
      width="900px"
      maskClosable={false}
      destroyOnClose
    >
      <div
        style={{
          display: 'flex',
          width: '100%',
          alignItems: 'center',
          marginBottom: '16px',
        }}
      >
        {/* 1.只有线路处于启用且已发布状态，才支持新增 2.编辑状态不展示该按钮*/}
        {!batchEditKeys?.length && (
          <Button
            onClick={handleAdd}
            type="primary"
            style={{ marginRight: 16 }}
            disabled={rowData.status !== 1 || rowData.syncStatus !== 1}
          >
            新增
          </Button>
        )}

        {/* 1.只有线路处于启用且已发布状态，才支持编辑 2.新增状态不展示该按钮*/}
        {!editingKey ? (
          !!batchEditKeys?.length ? (
            <>
              <Popconfirm
                title="确认保存修改内容吗？"
                open={confirmOpen}
                onOpenChange={handleOpenChange}
                disabled={data.length === 0}
                onConfirm={handleBatchSave}
              >
                <Button
                  disabled={data.length === 0}
                  type="primary"
                  style={{ marginRight: 16 }}
                  loading={submitLoading}
                >
                  确定
                </Button>
              </Popconfirm>
              <Button onClick={handleBatchCancel}>取消</Button>
            </>
          ) : (
            <Button
              onClick={handleEdit}
              type="primary"
              disabled={
                rowData.status !== 1 ||
                rowData.syncStatus !== 1 ||
                data.length === 0
              }
            >
              编辑
            </Button>
          )
        ) : null}
      </div>

      <Form form={form} component={false}>
        <Table
          components={{
            body: {
              cell: EditableCell,
            },
          }}
          loading={loading}
          bordered
          dataSource={data}
          columns={mergedColumns}
          rowClassName="editable-row"
          pagination={false}
          rowKey={'lineGroupGuid'}
        />
      </Form>
    </Modal>
  );
};

export default LineLinkModal;
