/* eslint-disable @typescript-eslint/no-unused-expressions */
import React, { FC, useEffect, useState } from 'react';
import { Alert, Table, Button, Popover, Modal } from 'antd';
import styles from './style.less';
import BasicDrawer from './basicDrawer';
import { findPage, changeStatus, getLinkTenant } from '@/api/lineSupplier';
import { useAccess, useModel } from '@umijs/max';
import moment from 'moment';
import { ExclamationCircleOutlined } from '@ant-design/icons';
import { keySingleRender } from '@/utils';
import LineLinkModal from './lineLinkModal';

interface LineListTableType {
  tableKey?: string; // 1 启用中  2 已禁用
  id?: string;
  modalRouter: any;
  getTableId: any;
  toTableEdit: any;
  isModalOpen2: any;
  supplierSearchValue: string;
  supplierSearchType: string;
  setShowEditText?: (bool) => void;
}

const LineListTable: FC<LineListTableType> = ({
  tableKey,
  id,
  modalRouter,
  getTableId,
  toTableEdit,
  isModalOpen2,
  supplierSearchValue,
  supplierSearchType,
  setShowEditText,
}) => {
  const [dataSource, setDataSource] = useState([]);
  const [openType, setOpenType] = useState(undefined);
  const [rowData, setRowData] = useState(null);
  const [tableHeight, setTableHeight] = useState('auto');
  const [linkOpen, setLinkOpen] = useState(false);

  const access = useAccess();
  const { setLineSupplierRowHandleId, setCallingNumber, loadDataListTab } =
    useModel('global');

  // 显示省市
  const viewContent = (record, type) => {
    return record[`${type}`]?.map((item, index) => {
      return (
        <div key={index} className={styles.viewContentStyle}>
          <div>
            {item.province}({item.cities.length})
          </div>
          <div className={styles.viewContentItemCity}>
            {item.cities?.map((cityItem, i) => {
              return (
                <span key={i}>
                  <span>{cityItem} </span>
                </span>
              );
            })}
          </div>
        </div>
      );
    });
  };

  const loadData = async () => {
    const res = await findPage({
      supplierGuid: id,
      status: Number(tableKey),
      pageSize: 100,
      pageNum: 1,
    });
    if (res?.data && res?.success) {
      setDataSource(res.data.list);
    }
  };

  const onCancel = () => {
    setLinkOpen(false);
    setRowData(null);
  };

  useEffect(() => {
    !isModalOpen2 && id && loadData();
  }, [isModalOpen2]);

  // // 编辑
  const editClick = (record) => {
    setCallingNumber(record.callingNumber);
    setLineSupplierRowHandleId(record.guid);
    modalRouter();
    getTableId(record.guid);
    toTableEdit();
    setShowEditText(true);
  };

  //打开关联情况抽屉
  const hanldeLineLink = (record) => {
    setRowData(record);
    setLinkOpen(true);
  };

  // 禁用 启用弹框
  const confirm = async (_, record) => {
    const resLink = await getLinkTenant({ guid: record.guid });
    const onOk = async () => {
      if (record.status === 1) {
        const res = await changeStatus({ guid: record.guid, status: 2 });

        res.success && loadData();
      } else if (record.status === 2) {
        const res = await changeStatus({ guid: record.guid, status: 1 });
        res.success && loadData();
      }
    };

    const onCancel = () => {
      console.log('onCancel');
    };

    Modal.confirm({
      title: `${record.status === 2 ? '启用' : '禁用'}该供应商线路${
        !!resLink?.data?.length ? ',以下关联租户会受到影响' : ''
      }`,
      content: (
        <div style={{ maxHeight: '145px', overflow: 'auto' }}>
          {!!resLink?.data?.length
            ? resLink?.data?.map((item) => (
                <div
                  key={`line1_${item.id}`}
                  style={{ color: '#959ca2', marginBottom: '5px' }}
                >
                  {item.name}
                </div>
              ))
            : null}
        </div>
      ),
      icon: <ExclamationCircleOutlined />,
      okText: '确认',
      cancelText: '取消',
      onOk: onOk,
      onCancel: onCancel,
    });
  };

  const columns = [
    {
      title: '线路名称',
      dataIndex: 'supporterLineName',
      key: 'supporterLineName',
      fixed: 'left',
      // width: '12%',
      render: (text: number) => (
        <div
          className={styles.text}
          dangerouslySetInnerHTML={{
            __html:
              supplierSearchType === 'supporterLineName'
                ? keySingleRender(text, supplierSearchValue)
                : text,
          }}
        />
      ),
    },
    {
      title: '主叫号码',
      dataIndex: 'callingNumber',
      key: 'callingNumber',
      fixed: 'left',
      width: 150,
      render: (text: number) => (
        <div
          className={styles.text}
          dangerouslySetInnerHTML={{
            __html:
              supplierSearchType === 'callingNumber'
                ? keySingleRender(text, supplierSearchValue)
                : text,
          }}
        />
      ),
    },
    {
      title: '类型',
      dataIndex: 'numberType',
      key: 'numberType',
      width: 100,
      render: (text: number) => {
        switch (text) {
          case 0:
            return '手机号';
          case 1:
            return '固话';
          case 2:
            return '95号';
          case 3:
            return '400';
          case 4:
            return '其他';
          default:
            return '-';
        }
      },
    },
    {
      title: '资费',
      dataIndex: 'price',
      key: 'price',
      width: 120,
      render: (text: number) => {
        if (text || text === 0) return `${text}元`;
        return '';
      },
    },
    {
      title: '月租费',
      dataIndex: 'monthlyRent',
      key: 'monthlyRent',
      width: 120,
      render: (text: number) => {
        return text ? `${text}元` : '无';
      },
    },
    {
      title: '覆盖省市',
      dataIndex: 'attribution',
      key: 'coverCity',
      width: 150,
      render: (_, record: any) => {
        if (!record.provinceCount) {
          return '';
        } else {
          return (
            record.provinceCount && (
              <Popover
                content={viewContent(record, 'attributionDisplay')}
                trigger="click"
              >
                <Button>
                  {record.provinceCount}省{record.cityCount}市
                </Button>
              </Popover>
            )
          );
        }
      },
    },
    {
      title: '已覆盖省市',
      dataIndex: 'normalAttributionDisplay',
      key: 'normalAttributionDisplay',
      width: 150,
      render: (_, record: any) => {
        if (!record.normalProvinceCount || record?.status === 2) {
          return '';
        } else {
          return (
            record.normalProvinceCount && (
              <Popover
                content={viewContent(record, 'normalAttributionDisplay')}
                trigger="click"
              >
                <Button>
                  {record.normalProvinceCount}省{record.normalCityCount}市
                </Button>
              </Popover>
            )
          );
        }
      },
    },
    {
      title: '并发上限',
      dataIndex: 'concurrentLimit',
      key: 'concurrentLimit',
      width: 100,
    },
    {
      title: '外呼限频',
      dataIndex: 'frequency',
      key: 'frequency',
      width: 320,
      render: (_, record) => {
        return (
          <>
            {record.callFrequencyList?.map((it, index) => (
              <span key={index} style={{ marginRight: '10px' }}>
                呼叫限频：{it.frequencyCount}次/{it.timePeriod}
                {it.timeUnit}
              </span>
            ))}
            {record.callThroughFrequencyList?.map((it, index) => (
              <span key={index} style={{ marginRight: '10px' }}>
                接通限频：{it.frequencyCount}次/{it.timePeriod}
                {it.timeUnit}
              </span>
            ))}
          </>
        );
      },
    },
    {
      title: '启用号码数量',
      dataIndex: 'usingNumberCount',
      key: 'usingNumberCount',
      width: 130,
    },
    {
      title: '发布状态',
      dataIndex: 'syncStatus',
      width: 130,
      render: (text) => {
        return text === 1 ? '已发布' : '未发布';
      },
    },
    {
      title: '状态',
      width: 100,
      dataIndex: 'status',
      key: 'status',
      render: (text) => {
        return text === 1 ? '启用' : '禁用';
      },
    },
    {
      title: '创建人',
      dataIndex: 'author',
      key: 'author',
      width: 100,
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      key: 'createTime',
      width: 190,
      render: (text) => {
        return moment(text).format('YYYY.MM.DD HH:mm:ss');
      },
    },
    {
      title: '操作',
      dataIndex: 'status',
      key: 'status',
      fixed: 'right',
      width: 300,
      render: (status, record) => {
        return access?.authCodeList?.includes(
          'Call-Line-Linesupplier-EditLine',
        ) ? (
          <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
            <Button
              disabled={!(record.syncStatus === 1)}
              type="link"
              size="small"
              onClick={() => {
                setLineSupplierRowHandleId(record.guid);
                setTimeout(() => {
                  setRowData(record);
                  setOpenType(10);
                }, 0);
              }}
            >
              获取配置
            </Button>
            <Button
              type="link"
              size="small"
              onClick={() => {
                setLineSupplierRowHandleId(record.guid);
                setTimeout(() => {
                  setRowData(record);
                  if (!record.syncStatus) {
                    setOpenType(3);
                  } else {
                    setOpenType(record.syncStatus);
                  }
                }, 0);
              }}
            >
              {record.syncStatus === 1 ? '更新' : '发布'}
            </Button>
            <Button type="link" size="small" onClick={() => editClick(record)}>
              编辑
            </Button>
            <Button
              type="link"
              size="small"
              onClick={() => hanldeLineLink(record)}
            >
              关联情况
            </Button>
            <Button
              type="link"
              size="small"
              onClick={() => confirm(status, record)}
            >
              {status === 2 ? '启用' : '禁用'}
            </Button>
          </div>
        ) : (
          ''
        );
      },
    },
  ];

  useEffect(() => {
    setTimeout(() => {
      id && loadData();
    }, 300);
  }, [loadDataListTab]);

  useEffect(() => {
    id && loadData();
    setTableHeight(
      tableKey === '1' ? 'calc(100vh - 330px)' : 'calc(100vh - 275px)',
    );
  }, [tableKey, id]);

  return (
    <div className={styles.lineListTable}>
      {tableKey === '1' && (
        <Alert
          style={{ width: '98%', margin: '10px auto' }}
          message="线路及号码在呼叫中心发布后才可以生效"
          type="info"
          showIcon
        />
      )}
      <div>
        <Table
          // @ts-ignore
          columns={columns}
          dataSource={dataSource}
          scroll={{
            x: 2350,
            y: tableHeight,
          }}
          rowKey={(record) => record.guid}
          pagination={false}
        />
      </div>

      <BasicDrawer
        openType={openType}
        setOpenType={setOpenType}
        rowData={rowData}
        loadData={loadData}
      />

      {linkOpen && (
        <LineLinkModal
          rowData={rowData}
          visible={linkOpen}
          onOk={loadData}
          onCancel={onCancel}
        />
      )}
    </div>
  );
};
export default LineListTable;
