import React, { FC, useState } from 'react';
import { Tabs, Button } from 'antd';
import { TabsProps } from 'antd';
import LineListTable from './lineListTable';

interface LineListType {
  id?: string;
  modalRouter: any;
  getTableId: any;
  toTableEdit: any;
  isModalOpen2: any;
  supplierSearchValue: string;
  supplierSearchType: string;
  setShowEditText?: (bool) => void;
}
const LineList: FC<LineListType> = ({
  id,
  modalRouter,
  getTableId,
  toTableEdit,
  isModalOpen2,
  supplierSearchValue,
  supplierSearchType,
  setShowEditText,
}) => {
  const [tableKey, setTableKey] = useState('1');
  const operations = (
    <div style={{ marginRight: '15px' }}>
      <Button type="primary" onClick={modalRouter}>
        新增线路
      </Button>
    </div>
  );
  const items: TabsProps['items'] = [
    {
      key: '1',
      label: `启用中`,
      children: (
        <LineListTable
          tableKey={tableKey}
          id={id}
          modalRouter={modalRouter}
          getTableId={getTableId}
          toTableEdit={toTableEdit}
          isModalOpen2={isModalOpen2}
          setShowEditText={setShowEditText}
          supplierSearchValue={supplierSearchValue}
          supplierSearchType={supplierSearchType}
        />
      ),
    },
    {
      key: '2',
      label: `已禁用`,
      children: (
        <LineListTable
          tableKey={tableKey}
          id={id}
          modalRouter={modalRouter}
          getTableId={getTableId}
          isModalOpen2={isModalOpen2}
          toTableEdit={toTableEdit}
          setShowEditText={setShowEditText}
          supplierSearchValue={supplierSearchValue}
          supplierSearchType={supplierSearchType}
        />
      ),
    },
  ];

  return (
    <>
      <div>
        <Tabs
          tabBarExtraContent={operations}
          activeKey={tableKey}
          items={items}
          onChange={(key) => setTableKey(key)}
        ></Tabs>
      </div>
    </>
  );
};
export default LineList;
