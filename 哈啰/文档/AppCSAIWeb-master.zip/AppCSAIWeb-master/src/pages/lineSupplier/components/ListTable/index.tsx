import React, { useEffect, useState, useRef } from 'react';
import { ExclamationCircleOutlined } from '@ant-design/icons';
import { Table, Modal, Pagination, Popover, Button } from 'antd';
import { findPage, findPageType, changeStatus } from '@/api/lineSupplier';
// import { debounce } from 'lodash';
import styles from './style.less';
import { useModel, useAccess } from '@umijs/max';

interface PropsType {
  id: string;
  tableChange: any;
  tableUpdate: boolean;
  modalRouter: any;
  getTableId: any;
  toTableEdit: any;
  tableHeight?: number;
  setShowEditText?: (bool) => void;
  refreshTable?: boolean;
}

const ListTable: React.FC<PropsType> = (props) => {
  const {
    id,
    tableChange,
    tableUpdate,
    modalRouter,
    getTableId,
    toTableEdit,
    tableHeight,
    refreshTable,
    setShowEditText,
  } = props;
  const access = useAccess();
  const [list, setList] = useState([]);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const tableRef = useRef();
  const { setLineSupplierRowHandleId } = useModel('global');

  // 获取高度变化
  // const handleHeightEvent = debounce(async () => {
  //   const ele = document.getElementById('klTableWrap');
  //   const _height = (ele?.clientHeight || 300) - 55;
  //   setTableHeight(_height < 101 ? 500 : _height);
  //   console.log(tableRef);

  // }, 200);

  // 禁用 开启
  const changeStatusData = async (obj) => {
    await changeStatus(obj);
  };
  // 分页查询线路
  const findPageData = async (obj: findPageType) => {
    const {
      data: { list, totalRecord, totalPages },
    } = await findPage(obj);
    list.forEach((it) => {
      it.createTime = it.createTime.replace('T', ' ');
    });
    setList(list);
    setTotal(totalRecord);
    tableChange(false);
    setTotalPages(totalPages);
    // handleHeightEvent()
  };

  // 禁用 启用弹框
  const confirm = (_, record) => {
    const onOk = async () => {
      if (record.status === 1) {
        await changeStatusData({ guid: record.guid, status: 2 });
        findPageData({
          supplierGuid: id,
          pageSize: 100,
          pageNum: 1,
        });
      } else if (record.status === 2) {
        await changeStatusData({ guid: record.guid, status: 1 });
        findPageData({
          supplierGuid: id,
          pageSize: 100,
          pageNum: 1,
        });
      }
    };

    const onCancel = () => {
      console.log('onCancel');
    };

    Modal.confirm({
      title: `${record.status === 2 ? '启用' : '禁用'}该供应商线路`,
      icon: <ExclamationCircleOutlined />,
      okText: '确认',
      cancelText: '取消',
      onOk: onOk,
      onCancel: onCancel,
    });
  };

  const editClick = (guid) => {
    setLineSupplierRowHandleId(guid);
    // updateRouterData(guid)
    modalRouter();
    getTableId(guid);
    // console.log('guid', guid);
    toTableEdit();
    setShowEditText(true);
  };

  const paginationChange = (val) => {
    findPageData({
      supplierGuid: id,
      pageSize: 100,
      pageNum: val,
    });
  };

  // 显示省市
  const viewContent = (record) => {
    return record.attributionDisplay?.map((item, index) => {
      return (
        <div key={index} className={styles.viewContentStyle}>
          <div>
            {item.province}({item.cities.length})
          </div>
          <div className={styles.viewContentItemCity}>
            {item.cities?.map((cityItem, i) => {
              return (
                <span key={i}>
                  <span>{cityItem} </span>
                </span>
              );
            })}
          </div>
        </div>
      );
    });
  };

  const columns = [
    {
      title: '线路名称',
      dataIndex: 'supporterLineName',
      key: 'supporterLineName',
      fixed: 'left',
      width: '12%',
    },
    {
      title: '主叫号码',
      dataIndex: 'callingNumber',
      key: 'callingNumber',
      fixed: 'left',
      width: '8%',
    },
    // {
    //   title: '外显号码',
    //   dataIndex: 'realCallingNumber',
    //   key: 'realCallingNumber',
    // },
    {
      title: '类型',
      dataIndex: 'numberType',
      key: 'numberType',
      width: 80,
      render: (text: number) => {
        switch (text) {
          case 0:
            return '手机号';
          case 1:
            return '固话';
          case 2:
            return '95号';
          case 3:
            return '400';
          case 4:
            return '其他';
          default:
            return '-';
        }
      },
    },
    {
      title: '覆盖省市',
      dataIndex: 'attribution',
      key: 'coverCity',
      width: '12%',
      render: (_, record: any) => {
        if (!record.provinceCount) {
          return '';
        } else {
          return (
            record.provinceCount && (
              <Popover content={viewContent(record)} trigger="click">
                <Button>
                  {record.provinceCount}省{record.cityCount}市
                </Button>
              </Popover>
            )
          );
        }
      },
    },
    {
      title: '并发上限',
      dataIndex: 'concurrentLimit',
      key: 'concurrentLimit',
      width: '10%',
    },
    {
      title: '外呼限频',
      dataIndex: 'frequency',
      key: 'frequency',
      width: '20%',
      render: (_, record) => {
        return (
          <>
            {record.callFrequencyList?.map((it, index) => (
              <span key={index} style={{ marginRight: '10px' }}>
                呼叫限频：{it.frequencyCount}次/{it.timePeriod}
                {it.timeUnit}
              </span>
            ))}
            {record.callThroughFrequencyList?.map((it, index) => (
              <span key={index} style={{ marginRight: '10px' }}>
                接通限频：{it.frequencyCount}次/{it.timePeriod}
                {it.timeUnit}
              </span>
            ))}
          </>
        );
      },
    },
    {
      title: '启用号码数量',
      dataIndex: 'usingNumberCount',
      key: 'usingNumberCount',
      width: '10%',
    },
    {
      title: '状态',
      width: '8%',
      dataIndex: 'status',
      key: 'status',
      render: (text) => {
        return text === 1 ? '启用' : '禁用';
      },
    },
    {
      title: '创建人',
      dataIndex: 'author',
      key: 'author',
      width: '7%',
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      key: 'createTime',
      width: '13%',
    },
    {
      title: '操作',
      dataIndex: 'status',
      key: 'status',
      fixed: 'right',
      width: '9%',
      render: (status, record) => {
        return access?.authCodeList?.includes(
          'Call-Line-Linesupplier-EditLine',
        ) ? (
          <>
            <a href="#" onClick={() => editClick(record.guid)}>
              编辑
            </a>
            <span
              style={{
                marginLeft: '10px',
                color: '#ab661e',
                cursor: 'pointer',
              }}
              onClick={() => confirm(status, record)}
            >
              {status === 2 ? '启用' : '禁用'}
            </span>
          </>
        ) : (
          ''
        );
      },
    },
  ];

  // useEffect(()=>{
  //   console.log('初始ref', tableRef.current.clientHeight);

  // }, [tableRef.current.clientHeight])

  useEffect(() => {
    findPageData({
      supplierGuid: id,
      pageSize: 100,
      pageNum: 1,
    });
  }, [id]);

  useEffect(() => {
    findPageData({
      supplierGuid: id,
      pageSize: 100,
      pageNum: 1,
    });
  }, [tableUpdate]);

  useEffect(() => {
    findPageData({
      supplierGuid: id,
      pageSize: 100,
      pageNum: 1,
    });
  }, [refreshTable]);

  return (
    <div className={styles.listtable}>
      <div className={styles.table}>
        <Table
          ref={tableRef}
          // @ts-ignore
          columns={columns}
          dataSource={list}
          scroll={{
            x: 1650,
            y: totalPages > 1 ? tableHeight - 109 : tableHeight,
          }}
          rowKey={(record) => record.guid}
          pagination={false}
        />
      </div>
      {totalPages > 1 && (
        <div className={styles.pagination}>
          <Pagination
            total={total}
            pageSize={100}
            onChange={paginationChange}
            showTotal={(total) => `${total} 条数据`}
            hideOnSinglePage={true}
          />
        </div>
      )}
    </div>
  );
};

export default ListTable;
