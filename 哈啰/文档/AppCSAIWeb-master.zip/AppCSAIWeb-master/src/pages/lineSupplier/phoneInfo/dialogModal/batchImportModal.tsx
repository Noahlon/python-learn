import React, { FC, useState, useRef } from 'react';
import { InboxOutlined, VerticalAlignBottomOutlined } from '@ant-design/icons';
import { Modal, Button, message } from 'antd';
import FileUploadShowList from '@/components/FileUploadShowList';
import styles from './index.less';
import { httpReplace } from '@/utils';
import { useModel } from '@umijs/max';
import { uploadNumbers } from '@/api/lineSupplier';

const BatchImportModal: FC<any> = ({}) => {
  const [fileList, setFileList] = useState([]);
  const [fileUploadFailUrl, setFileUploadFailUrl] = useState('');
  const [confirmLoading] = useState(false);
  const ref = useRef();
  const { importModalOpen, lineSupplierRowHandleId, setImportModalOpen } =
    useModel('global');

  //取消
  const handleImportCancel = () => {
    setImportModalOpen(false);
    // @ts-ignore
    if (ref.current) ref.current?.clearData();
    setFileUploadFailUrl('');
    setFileList([]);
  };

  // 确认
  const handleImportOk = async () => {
    const list = fileList?.filter((item) => item.status === 'done');
    if (!list?.length) return message.error('请先上传文件');
    const dest = message.loading('正在导入');

    const res = await uploadNumbers({
      lineGuid: lineSupplierRowHandleId,
      aliOssUrl: list[0].url,
    });
    if (res.success && res.data) {
      if (res?.data?.success) {
        message.success('导入成功');
      } else if (res?.data?.aliOssUrl) {
        // @ts-ignore
        // if (ref.current) ref.current?.clearData();
        // setFileUploadFailUrl('');
        // setFileList([]);
        message.error('导入失败');
        setFileUploadFailUrl(httpReplace(res?.data?.aliOssUrl));
        return;
      }
    }
    dest?.();
    setImportModalOpen(false);
  };

  return (
    <div className={styles.importModal}>
      <Modal
        title="批量编辑"
        open={importModalOpen}
        onOk={handleImportOk}
        onCancel={handleImportCancel}
        confirmLoading={confirmLoading}
        getContainer={false}
        destroyOnClose
      >
        <FileUploadShowList
          // @ts-ignore
          ref={ref}
          showUploadList={true}
          uploadType=".xlsx,.xls"
          onChange={(list) => setFileList(list)}
        >
          <div className={styles.uploadIcon}>
            <InboxOutlined />
          </div>
          <div className={styles.notice}>点击或将文件拖拽到这里上传</div>
          <div className={styles.uploadType}>支持扩展名：&nbsp;.xlsx</div>
        </FileUploadShowList>
        <div style={{ textAlign: 'right' }}>
          <Button
            type="link"
            size="small"
            href="https://m.hellobike.com/resource/helloyun/wb24034/%E5%8F%B7%E7%A0%81%E5%AF%BC%E5%85%A5%E6%A8%A1%E6%9D%BF01.xlsx"
          >
            下载模版
          </Button>
        </div>
        {fileUploadFailUrl && !!fileList?.length && (
          <div className={styles.errorUploadWrap}>
            <VerticalAlignBottomOutlined className={styles.errorUploadIcon} />
            <a
              rel="noreferrer"
              target="_blank"
              href={fileUploadFailUrl}
              className={styles.errorUploadText}
            >
              下载导入失败数据
            </a>
          </div>
        )}
      </Modal>
    </div>
  );
};
export default BatchImportModal;
