/* eslint-disable @typescript-eslint/no-unused-expressions */
import React, { FC, useEffect, useState, useCallback } from 'react';
import { Modal, Form, Input, Select, Cascader, message } from 'antd';
import { lineAddNumber, lineUpdateNumber } from '@/api/lineSupplier';
import { getPhoneNumber } from '@/utils';
import { useModel } from '@umijs/max';
import { getProvinceCityList } from '@/api/common';

interface AddModalType {
  currentRowData?: any;
  initData?: () => void;
  type?: string;
}

const AddModal: FC<AddModalType> = ({ currentRowData, initData }) => {
  const {
    lineSupplierRowHandleId,
    addModalOpen,
    setAddModalOpen,
    numberModalType,
    setLineSupplierPhoneStart,
  } = useModel('global'); //lineguid
  const [guid, setGuid] = useState(null);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const { Option } = Select;
  const { SHOW_CHILD } = Cascader;
  const [form] = Form.useForm();
  const [residences, setresidences] = useState([]);

  const city = async () => {
    const opt = [];
    // todo  异步获取省市数据
    const DISTRICTS: any = await getProvinceCityList();
    DISTRICTS.forEach((item) => {
      if (item['level'] === 1) {
        const citys = [];
        DISTRICTS.forEach((i) => {
          if (item.area_code === i.parent_code)
            citys.push({ value: i.area_name, label: i.area_name });
        });
        opt.push({
          value: item.area_name,
          label: item.area_name,
          children: citys,
        });
      }
    });
    setresidences(opt || []);
  };

  //   保存 && 提交
  const handleSave = async () => {
    const api = numberModalType === 'edit' ? lineUpdateNumber : lineAddNumber;

    const sendParams =
      numberModalType === 'edit'
        ? {
            lineGuid: lineSupplierRowHandleId,
            guid: guid.toString(),
          }
        : { lineGuid: lineSupplierRowHandleId };

    const param = await form.validateFields();
    setConfirmLoading(true);

    if (param.attributions) {
      const result = [];
      param.attributions.map((item) => {
        return result.push({
          province: item[0],
          city: item[1],
        });
      });
      param.attributions = result;
    }

    const res = await api({
      ...param,
      ...sendParams,
    });
    if (res.success) {
      message.success('操作成功');
      setAddModalOpen(false);
      if (numberModalType !== 'edit') {
        setLineSupplierPhoneStart([param]);
      }
      initData?.();
    } else {
      message.error('操作失败');
    }
    setConfirmLoading(false);
  };

  //  编辑时候 获取当前行数据
  const getFromData = () => {
    const cloneRow = { ...currentRowData };
    setGuid(cloneRow.guid);
    if (cloneRow.attributions) {
      const result = [];
      cloneRow.attributions.map((item) => {
        return result.push([item.province, item.city]);
      });
      cloneRow.attributions = result;
    }

    form.setFieldsValue({
      ...cloneRow,
    });
  };

  const validDayCallLimit = (_, val) => {
    if (val > 100000000)
      return Promise.reject('单日送呼上限应在1-100,000,000之间');
    return Promise.resolve();
  };
  const validConcurrentLimit = (_, val) => {
    if (val > 1000000) return Promise.reject('并发上限应在1-1,000,000之间');
    return Promise.resolve();
  };

  const handleInputNumber = useCallback((type, value) => {
    getPhoneNumber(value).then((value) =>
      form.setFieldsValue({
        [type]: value,
      }),
    );
  }, []);

  useEffect(() => {
    form.resetFields();
    if (addModalOpen && numberModalType === 'edit') {
      getFromData();
    }
    if (addModalOpen) {
      city();
    }
  }, [addModalOpen]);
  return (
    <>
      <Modal
        title={numberModalType === 'edit' ? '编辑' : '添加'}
        width={550}
        open={addModalOpen}
        destroyOnClose
        onOk={handleSave}
        confirmLoading={confirmLoading}
        onCancel={() => {
          setAddModalOpen(false);
        }}
      >
        <Form
          form={form}
          labelAlign="right"
          labelCol={{ span: 6 }}
          wrapperCol={{ span: 16 }}
          name="basic"
          autoComplete="off"
        >
          <Form.Item
            label="外显号码"
            name="realCallingNumber"
            rules={[{ required: true, message: '请输入外显号码!' }]}
          >
            <Input
              disabled={numberModalType === 'edit' ? true : false}
              onChange={(e) =>
                handleInputNumber('realCallingNumber', e.target.value)
              }
            />
          </Form.Item>
          <Form.Item label="归属省市" name="attributions">
            <Cascader
              options={residences}
              showCheckedStrategy={SHOW_CHILD}
              multiple
            />
          </Form.Item>
          <Form.Item label="落地运营商" name="carrier">
            <Select placeholder="请选择" allowClear>
              <Option value={1}>中国移动</Option>
              <Option value={2}>中国联通</Option>
              <Option value={3}>中国电信</Option>
              <Option value={4}>其他</Option>
            </Select>
          </Form.Item>
          <Form.Item
            label="并发上限"
            name="concurrentLimit"
            rules={[
              { required: true, message: '请输入', pattern: /^[0-9]*$/ },
              { validator: validConcurrentLimit },
            ]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="单日呼送上限"
            name="dayCallLimit"
            rules={[
              { message: '请输入单日送呼上限', pattern: /^[0-9]*$/ },
              { validator: validDayCallLimit },
            ]}
          >
            <Input />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};
export default AddModal;
