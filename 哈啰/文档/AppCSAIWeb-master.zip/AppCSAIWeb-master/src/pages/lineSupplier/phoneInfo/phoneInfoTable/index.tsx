/* eslint-disable @typescript-eslint/no-unused-expressions */
import React, { FC, useEffect, useRef, useState } from 'react';
import {
  Table,
  Pagination,
  Typography,
  message,
  Tabs,
  Modal,
  Form,
  Input,
  Select,
  Popconfirm,
  notification,
} from 'antd';
import { debounce } from 'lodash';
import AddModal from '../dialogModal/addModal';
import BatchEditModal from '../dialogModal/batchEditModal';
import { getSimpleList } from '@/api/language';
import styles from './index.less';
import type { PhoneInfoTableType } from '../index';
import {
  findNumberPage,
  lineUpdateNumberStatus,
  initiate,
} from '@/api/lineSupplier';

import { useModel } from '@umijs/max';
import { ccServerOptions } from '@/constants';
const PhoneInfoTable: FC<PhoneInfoTableType> = ({
  tableId,
  setSelectKeys,
  selectKeys,
}) => {
  const {
    batchEditNumberOpen,
    importModalOpen,
    setAddModalOpen,
    setNumberModalType,
    callingNumber,
    lineSupplierRowHandleId,
    lineSupplierPhoneStart,
    setLineSupplierPhoneStart,
    lineSupplierPhoneStop,
    setLineSupplierPhoneStop,
  } = useModel('global');
  const [total, setTotal] = useState(0);
  const [currentRowData, setCurrentRowData] = useState(undefined);
  const [currentNum, setCurrentNum] = useState(1);
  const [tableKey, setTableKey] = useState<string>('1');
  const [isOpenModal, setIsOpenModal] = useState(false);
  const [faqGuidList, setFaqGuidList] = useState([]);
  const [selectGroupId, setSelectGroupId] = useState(undefined);
  const [rowData, setRowData] = useState(undefined);
  const [tableHeight, setTableHeight] = useState<string | number>('auto');

  const params = useRef({
    lineGuid: lineSupplierRowHandleId,
    status: Number(tableKey),
    pageSize: 100,
    pageNum: 1,
  });

  const [form] = Form.useForm();
  // const { Option } = Select;

  const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };

  const edit = (record: any) => {
    setCurrentRowData(record);
    setNumberModalType('edit');
    setAddModalOpen(true);
  };

  // 通过线路id 获取号码分页数据
  const initData = async () => {
    if (!tableId) return;
    try {
      const res = await findNumberPage(params.current);
      if (res.success) {
        if (params.current.status === 2) {
          setLineSupplierPhoneStop(res.data.list || []);
        } else {
          setLineSupplierPhoneStart(res.data.list || []);
        }
      }

      setTotal(res.data.totalRecord || 0);
    } catch (error) {
      message.error(error);
    }
  };

  // 切换tab 重新拉数据
  const handleChangeTabs = (key) => {
    params.current.pageNum = 1;
    setCurrentNum(1);
    setTableKey(key);
    params.current.status = Number(key);
    initData();
  };

  //  修改号码状态
  const handleChangeStatus = async (record) => {
    const status = record.status === 1 ? 2 : 1;
    const res = await lineUpdateNumberStatus({
      guid: record.guid,
      status,
    });
    res.success && message.success('操作成功');
    initData();
    // 如果是启用的话，把当前行数据添加到启用的数组中
    if (status === 1) {
      const newList = lineSupplierPhoneStart.concat(record);
      setLineSupplierPhoneStart(newList);
    }
  };

  const columns: any = [
    {
      title: '外显号码',
      dataIndex: 'realCallingNumber',
      fixed: 'left',
      width: 150,
    },
    {
      title: '归属省市',
      dataIndex: 'attributions',
      fixed: 'left',
      width: 150,
      render: (_: any, record: any) => {
        if (record.attributions) {
          return (
            <div>
              {record.attributions.map((item, index) => (
                <span key={index} style={{ marginRight: '10px' }}>
                  {item.province}
                  {item.city};
                </span>
              ))}
            </div>
          );
        }
        return '-';
      },
    },
    {
      title: '归属运营商',
      width: 150,
      dataIndex: 'carrier',
      render: (text: any) => {
        switch (text) {
          case 1:
            return '中国移动';
          case 2:
            return '中国联通';
          case 3:
            return '中国电信';
          case 4:
            return '其他';
        }
      },
    },
    {
      title: '并发上限',
      dataIndex: 'concurrentLimit',
    },
    {
      title: '发布状态',
      dataIndex: 'syncStatus',
      render: (text) => {
        return text === 1 ? '已发布' : '未发布';
      },
    },
    {
      title: '单日呼送上限',
      dataIndex: 'dayCallLimit',
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (text) => {
        return text === 1 ? '启用' : '禁用';
      },
    },
    {
      title: '操作',
      dataIndex: 'operation',
      fixed: 'right',
      width: 150,
      render: (_: any, record: any) => {
        return (
          <>
            <Typography.Link
              style={{ marginRight: '5px' }}
              onClick={() => {
                setIsOpenModal(true);
                setRowData(record);
              }}
              disabled={!record.syncStatus}
            >
              测试
            </Typography.Link>
            <Typography.Link
              style={{ marginRight: '5px' }}
              onClick={() => edit(record)}
            >
              编辑
            </Typography.Link>
            <Popconfirm
              title={record.status === 1 ? '确定禁用吗？' : '确定启用吗？'}
              onConfirm={() => handleChangeStatus(record)}
              okText="确定"
              cancelText="取消"
            >
              <Typography.Link>
                {record.status === 1 ? '禁用' : '启用'}
              </Typography.Link>
            </Popconfirm>
          </>
        );
      },
    },
  ];

  const rowSelection = {
    selectedRowKeys: selectKeys,
    onChange: (selectedRowKeys: React.Key[]) => {
      setSelectKeys(selectedRowKeys);
    },
  };

  // 分页
  const onPaginationChange = (page: number) => {
    params.current.pageNum = page;
    setCurrentNum(page);
    setSelectKeys([]);
    initData();
  };

  // 获取高度变化
  const handleHeightEvent = debounce(async () => {
    const ele = document.getElementById('phoneTableWrap');
    const _height = (ele?.clientHeight || 300) - 55;
    console.log('_height', _height);
    setTableHeight(_height);
  }, 200);

  useEffect(() => {
    window.addEventListener('resize', handleHeightEvent);
    handleHeightEvent();

    return () => window.removeEventListener('resize', handleHeightEvent);
  }, []);

  useEffect(() => {
    params.current.lineGuid = tableId;
    initData();
  }, [tableId]);

  useEffect(() => {
    initData();
  }, [batchEditNumberOpen, importModalOpen]);

  const tableEle = (
    <div className={styles.phoneWrap}>
      <div className={styles.tableContent} id="phoneTableWrap">
        <Table
          rowSelection={rowSelection}
          rowKey={(record) => record.guid}
          dataSource={
            tableKey === '1' ? lineSupplierPhoneStart : lineSupplierPhoneStop
          }
          columns={columns}
          rowClassName="editable-row"
          scroll={{ x: 1300, y: tableHeight }}
          pagination={false}
        />
      </div>
      <div className={styles.subPagination}>
        <Pagination
          current={currentNum}
          onChange={onPaginationChange}
          pageSize={100}
          showSizeChanger={false}
          total={total}
          showTotal={(total) => `共 ${total} 条`}
        />
      </div>
    </div>
  );

  const items = [
    {
      key: '1',
      label: `启用中`,
      children: tableEle,
    },
    {
      key: '2',
      label: `已禁用`,
      children: tableEle,
    },
  ];

  // 验证执话术是否存在
  const handleValidatorFaqGuid = async (rule, value) => {
    if (!value) return Promise.reject('请选择话术');
    const zIndex = faqGuidList.findIndex((item) => item.groupId === value);
    if (zIndex === -1) return Promise.reject('当前执行话术找不到，请重新选择');
    return Promise.resolve();
  };

  // 发起呼叫
  const handleOk = async () => {
    const formData = await form.validateFields();
    const { tenant, bizScene, groupId } = faqGuidList.find(
      (item) => item.groupId === selectGroupId,
    );
    const params = {
      userPhone: formData.userPhone,
      realCallingNumber: formData.realCallingNumber,
      speechGroupId: groupId,
      tenant: tenant,
      bizScene: bizScene,
      callingNumber: callingNumber,
      ccServer: formData.ccServer,
      lineGuid: rowData.lineGuid,
    };
    const res = (await initiate(params)) as unknown as string;
    // 与后端对齐，后端返回一串string，如果包含ErrorMsg则表示失败
    if (res?.indexOf('ErrorMsg') > -1) {
      notification.error({
        message: '呼叫失败',
        description: res,
      });
    } else {
      message.success('已发起呼叫测试');
      setIsOpenModal(false);
      initData();
    }
  };

  // 获取话术列表
  const getOptions = async () => {
    const res = await getSimpleList({
      pageSize: 999,
      pageNum: 1,
      tenant: null,
      status: 1,
    });

    if (res?.list.length) {
      setFaqGuidList(res?.list);
    } else {
      setFaqGuidList([]);
    }
  };

  useEffect(() => {
    if (isOpenModal) {
      getOptions();
      form.setFieldValue('realCallingNumber', rowData.realCallingNumber);
    } else {
      form.resetFields();
    }
  }, [isOpenModal]);

  return (
    <>
      <Tabs
        activeKey={tableKey}
        items={items}
        onChange={handleChangeTabs}
      ></Tabs>
      <AddModal currentRowData={currentRowData} initData={initData} />

      <BatchEditModal selectKeys={selectKeys} />

      <Modal
        open={isOpenModal}
        title={'外呼测试'}
        forceRender={true}
        width={'540px'}
        onOk={handleOk}
        onCancel={() => setIsOpenModal(false)}
        getContainer={false}
      >
        <Form form={form} {...layout}>
          <Form.Item label="外显号码" name="realCallingNumber">
            <Input maxLength={50} disabled />
          </Form.Item>
          <Form.Item
            label="执行话术"
            name="groupId"
            rules={[{ validator: handleValidatorFaqGuid }]}
          >
            <Select
              showSearch
              onChange={(val) => {
                setSelectGroupId(val);
              }}
              placeholder="请选择执行话术"
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
              fieldNames={{ label: 'speechName', value: 'groupId' }}
              options={faqGuidList}
            />
          </Form.Item>
          <Form.Item
            label="被叫号码"
            name="userPhone"
            rules={[
              {
                required: true,
                max: 15,
                pattern: /^[0-9]\d{7,14}$/, // 手机号码正则表达式
                message: '请输入正确的手机号',
              },
            ]}
          >
            <Input maxLength={15} placeholder="请输入被叫" />
          </Form.Item>
          <Form.Item
            label="呼叫中心"
            name="ccServer"
            rules={[{ required: true }]}
          >
            <Select
              showSearch
              optionFilterProp="label"
              placeholder="请选择呼叫中心"
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
              options={ccServerOptions}
            />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};
export default PhoneInfoTable;
