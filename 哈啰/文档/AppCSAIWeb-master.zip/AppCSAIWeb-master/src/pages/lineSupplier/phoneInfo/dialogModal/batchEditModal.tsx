/* eslint-disable @typescript-eslint/no-unused-expressions */
import React, { FC, useEffect, useState } from 'react';
import { Modal, Form, Input, Select, Cascader, message } from 'antd';
import { batchUpdateNumber } from '@/api/lineSupplier';
import { useModel } from '@umijs/max';
import { getProvinceCityList } from '@/api/common';

interface BatchEditModalType {
  selectKeys?: any;
}

const BatchEditModal: FC<BatchEditModalType> = ({ selectKeys }) => {
  const { batchEditNumberOpen, setBatchEditNumberOpen } = useModel('global');

  const [selectVal, setSelectVal] = useState('concurrentLimit');
  const { Option } = Select;
  const { SHOW_CHILD } = Cascader;
  const [form] = Form.useForm();
  const [residences, setresidences] = useState([]);
  const city = async () => {
    const opt = [];
    // todo  异步获取省市数据
    const DISTRICTS: any = await getProvinceCityList();
    DISTRICTS.forEach((item) => {
      if (item['level'] === 1) {
        const citys = [];
        DISTRICTS.forEach((i) => {
          if (item.area_code === i.parent_code)
            citys.push({ value: i.area_name, label: i.area_name });
        });
        opt.push({
          value: item.area_name,
          label: item.area_name,
          children: citys,
        });
      }
    });
    setresidences(opt || []);
  };

  const rendorInputType = () => {
    switch (selectVal) {
      case 'concurrentLimit':
        return <Input />;
      case 'carrier':
        return (
          <Select placeholder="请选择">
            <Option value={1}>中国移动</Option>
            <Option value={2}>中国联通</Option>
            <Option value={3}>中国电信</Option>
            <Option value={4}>其他</Option>
          </Select>
        );
      case 'attribution':
        return (
          <Cascader
            options={residences}
            showCheckedStrategy={SHOW_CHILD}
            multiple
          />
        );
      case 'dayCallLimit':
        return <Input />;
      case 'status':
        return (
          <Select placeholder="请选择">
            <Option value={1}>启用</Option>
            <Option value={2}>禁用</Option>
          </Select>
        );
    }
  };

  const handleOk = async () => {
    // 提交
    const params = await form.validateFields();
    if (params.labelName === 'attribution') {
      const result = [];
      params.value.map((item) => {
        return result.push({
          province: item[0],
          city: item[1],
        });
      });
      params.value = result;
    }

    const result = await batchUpdateNumber({
      guids: selectKeys,
      key: params.labelName,
      value:
        params.labelName === 'attribution'
          ? JSON.stringify(params.value)
          : params.value,
    });
    message.success('修改成功');
    result.success && setBatchEditNumberOpen(false);
    form.resetFields();
    setSelectVal('concurrentLimit');
    setBatchEditNumberOpen(false);
  };

  // const validConcurrentLimit = (_, val) => {
  //   if (selectVal === 'concurrentLimit') {
  //     if (val > 1000000) return Promise.reject('并发上限应在1-1,000,000之间');
  //     return Promise.resolve();
  //   }
  // };
  useEffect(() => {
    city();
  }, []);

  return (
    <>
      <Modal
        title="批量编辑"
        width={450}
        open={batchEditNumberOpen}
        onOk={handleOk}
        onCancel={() => {
          form.resetFields();
          setSelectVal('concurrentLimit');
          setBatchEditNumberOpen(false);
        }}
      >
        <Form
          form={form}
          labelAlign="right"
          labelCol={{ span: 6 }}
          wrapperCol={{ span: 16 }}
          name="basic"
          initialValues={{ labelName: 'concurrentLimit' }}
          autoComplete="off"
        >
          <Form.Item
            label="编辑字段"
            name="labelName"
            rules={[{ required: true, message: '请选择编辑字段' }]}
          >
            <Select
              placeholder="请选择"
              allowClear
              onChange={(val) => {
                setSelectVal(val);
                form.setFieldValue('value', undefined);
              }}
            >
              <Option value={'concurrentLimit'}>并发上限</Option>
              <Option value={'attribution'}>归属省市</Option>
              <Option value={'carrier'}>落地运营商</Option>
              <Option value={'dayCallLimit'}>单日呼送上限</Option>
              <Option value={'status'}>状态</Option>
            </Select>
          </Form.Item>
          <Form.Item
            label="字段值"
            name="value"
            rules={[
              { required: true, message: '请输入' },
              // { validator: validConcurrentLimit },
            ]}
          >
            {rendorInputType()}
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};
export default BatchEditModal;
