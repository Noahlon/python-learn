/* eslint-disable @typescript-eslint/no-unused-expressions */
import React, { FC, useState } from 'react';
import { Button, message, Space } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import styles from './index.less';
import PhoneInfoTable from './phoneInfoTable';
import BatchImportModal from './dialogModal/batchImportModal';
import { useModel } from '@umijs/max';

export interface PhoneInfoTableType {
  tableId?: string;
  addModalOpen?: boolean;
  add?: boolean;
  setAddModalOpen?: (boolean) => void;
  setSelectKeys?: (arr) => void;
  selectKeys?: any;
}

const PhoneInfoModal: FC<PhoneInfoTableType> = ({ tableId }) => {
  const {
    setBatchEditNumberOpen,
    setImportModalOpen,
    setAddModalOpen,
    setNumberModalType,
  } = useModel('global');

  const [selectKeys, setSelectKeys] = useState([]);

  return (
    <>
      <div className={styles.wrapper}>
        <Space style={{ marginBottom: '20px' }}>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => {
              setAddModalOpen(true);
              setNumberModalType('add');
            }}
          >
            添加
          </Button>
          <Button
            onClick={() => {
              if (!selectKeys.length) {
                message.error('至少选择一项');
                return;
              }
              setBatchEditNumberOpen(true);
            }}
          >
            批量编辑
          </Button>
          <Button
            onClick={() => {
              setImportModalOpen(true);
            }}
          >
            批量导入
          </Button>
        </Space>
        <div className={styles.phoneTableWrap}>
          <PhoneInfoTable
            tableId={tableId}
            setSelectKeys={setSelectKeys}
            selectKeys={selectKeys}
          />
        </div>

        <BatchImportModal />
      </div>
    </>
  );
};
export default PhoneInfoModal;
