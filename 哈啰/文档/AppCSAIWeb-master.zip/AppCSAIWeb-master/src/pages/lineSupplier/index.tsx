import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  InboxOutlined,
  MinusCircleFilled,
  PlusOutlined,
  VerticalAlignBottomOutlined,
} from '@ant-design/icons';
import {
  Cascader,
  Empty,
  Radio,
  Space,
  TabsProps,
  Tag,
  Typography,
} from 'antd';
import { useAccess, useModel } from '@umijs/max';

import {
  Button,
  Tabs,
  Modal,
  Form,
  Input,
  Select,
  Spin,
  Drawer,
  // Cascader,
  message,
} from 'antd';
import AddCard from '@/components/AddCard';
// import ListTable from './components/ListTable';
import {
  getLineSupplier,
  addSupplier,
  editSupplier,
  addRouter,
  updateRouter,
  upload,
  getRouter,
  addSupplierType,
  editSupplierType,
  addRouterType,
  findNumberPage,
} from '@/api/lineSupplier';
import { getProvinceCityList } from '@/api/common';
import FileUploadShowList from '@/components/FileUploadShowList';
import { httpReplace } from '@/utils';
import PhoneInfoModal from './phoneInfo';
import LineList from './lineList';
import HangingCode from './HangingCode';
import { supplierSearchTypes, supportCarrierOpts } from './config';
import { debounce } from 'lodash';
import styles from './index.less';

const { Text } = Typography;
const { TextArea } = Input;
const { Option } = Select;

export const lineTypeOption = [
  { label: '手机号', value: 0 },
  { label: '固话', value: 1 },
  { label: '95号', value: 2 },
  { label: '400', value: 3 },
  { label: '其他', value: 4 },
];

export const feeOptions = [
  { label: '无', value: 1 },
  { label: '有', value: 2 },
];

const LineSupplier: React.FC = () => {
  const [form] = Form.useForm();
  const access = useAccess();
  const ref = useRef();
  const spinRef = useRef();
  const [form2] = Form.useForm();
  // const selectCityLimit = Form.useWatch('areaLimit', form2);
  // 商户搜索
  const queryForm = useRef(undefined);
  const [supplierSearchValue, setSupplierSearchValue] = useState('');
  const [supplierSearchType, setSupplierSearchType] = useState('supplierName');
  // 第一个card阴影 guid
  const [flag, setFlag] = useState('');
  // cardData
  const [cardData, setCardData] = useState([]);
  // 商户弹窗
  const [isModalOpen, SetIsModalOpen] = useState(false);
  // 路线弹窗
  const [isModalOpen2, SetIsModalOpen2] = useState(false);
  // 商户编辑/新增
  const [isAdd, setIsAdd] = useState(false);
  const [isLoadingCard, setIsLoadingCard] = useState(true);
  // 新增/编辑路线
  const [isEdit, setIsEdit] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [fileUploadFailUrl, setFileUploadFailUrl] = useState('');
  // const [tableUpdate, setTableUpdate] = useState(false);
  const [tableId, setTableId] = useState();
  const [formData, setFormData] = useState<addRouterType>();
  const [editGuid, setEditGuid] = useState();
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [editLoading, setEditLoading] = useState(false);
  const [formLoading, setFormLoading] = useState(false);
  const [fileList, setFileList] = useState([]);
  // const [tableHeight, setTableHeight] = useState(null);
  const [tableKey, setTableKey] = useState('lineConfig');
  const [initTabsKey, setInitTabsKey] = useState('lineTabs');
  const [refreshTable, setreFreshTable] = useState(false);
  const [showEditText, setShowEditText] = useState(false);
  const [cityOpt, setCityOpt] = useState([]);
  const [selectCityTags, setSelectCityTags] = useState([]);
  const {
    setAddFlag,
    setLineSupplierRowHandleId,
    loadDataListTab,
    setLoadDataListTab,
    lineSupplierPhoneStart,
    setLineSupplierPhoneStart,
    setCallingNumber,
  } = useModel('global');

  // 高亮
  const heightLight = (id) => {
    setFlag(id);
  };
  // tab
  // const onChange = (key: string) => {
  //   console.log(key);
  // };
  // table id
  const getTableId = async (guid) => {
    setTableId(guid);
    // 编辑时 加载数据
    try {
      const res = await findNumberPage({
        lineGuid: guid,
        pageNum: 1,
        pageSize: 100,
        status: 1,
      });
      if (res.success) {
        setLineSupplierPhoneStart(res.data.list || []);
      }
    } catch (error) {
      message.error(error);
    }
    setLineSupplierRowHandleId(guid);
  };

  // 显示左侧弹窗
  const isShow = () => {
    SetIsModalOpen(!isModalOpen);
    setIsAdd(false);
  };

  // const tableChange = () => {
  //   setTableUpdate(false);
  // };

  // 是否编辑
  const toTableEdit = async (type?: string) => {
    if (type === 'add') {
      setTableKey('phoneInfo');
    } else {
      setTableKey('lineConfig');
    }
    setIsEdit(!isEdit);
  };

  // 新增用户
  const addUser = () => {
    // form.resetFields()
    isShow();
    setIsAdd(!isAdd);
  };

  // api
  // 编辑 新增线路
  const modalRouter = () => {
    setLineSupplierRowHandleId(null);
    setTableId(null);
    // setAddFlag(true)
    setShowEditText(false);
    SetIsModalOpen2(!isModalOpen2);
  };
  const getRouters = async (guid) => {
    const { data } = await getRouter({ guid });
    setFormData(data);
  };
  // 新增线路
  const addRouters = async (obj) => {
    const res = await addRouter(obj);
    if (res?.code === '0') {
      setCallingNumber(obj?.callingNumber);
      setLineSupplierRowHandleId(res?.data?.guid);
      // modalRouter();
      getTableId(res?.data?.guid);
      toTableEdit('add');
      getRouters(res?.data?.guid);
      setShowEditText(true);
    }
  };

  const hiddenmodal2 = () => {
    SetIsModalOpen2(false);
    form2.resetFields();
    setSelectCityTags([]);
    toTableEdit();
    setIsEdit(false);
  };
  const cancelHandel = () => {
    setAddFlag(false);
    // setBlind(null);
    form2.resetFields();
    setSelectCityTags([]);
    modalRouter();
    hiddenmodal2();
    setreFreshTable(!refreshTable);
  };
  const updateRouters = async (obj: addRouterType) => {
    if (!lineSupplierPhoneStart.length) {
      Modal.confirm({
        title: '请至少添加一条启用的号码数据',
        okText: '继续退出',
        async onOk() {
          await updateRouter(obj);
          hiddenmodal2();
        },
      });
    } else {
      await updateRouter(obj);
      hiddenmodal2();
    }

    // console.log(res);
  };

  const handleCancel2 = () => {
    if (showEditText && !lineSupplierPhoneStart.length) {
      Modal.confirm({
        title: '请至少添加一条启用的号码数据',
        okText: '继续退出',
        onOk() {
          cancelHandel();
        },
      });
    } else {
      cancelHandel();
    }
  };

  // 线路新增 编辑弹窗
  const handleOk2 = () => {
    if (tableKey === 'lineConfig') {
      form2.validateFields().then(async (res) => {
        let data;
        setFormLoading(true);
        const callFrequencyList = res.callPlaceist
          ?.filter((item) => item.type === 'call')
          ?.map((item) => ({
            frequencyCount: item.frequencyCount,
            timePeriod: item.timePeriod,
            timeUnit: item.timeUnit,
          }));
        const callThroughFrequencyList = res.callPlaceist
          ?.filter((item) => item.type === 'put')
          ?.map((item) => ({
            frequencyCount: item.frequencyCount,
            timePeriod: item.timePeriod,
            timeUnit: item.timeUnit,
          }));

        if (callFrequencyList?.length) {
          data = Object.assign({
            ...data,
            callFrequencyList,
          });
        }
        if (callThroughFrequencyList?.length) {
          data = Object.assign({
            ...data,
            callThroughFrequencyList,
          });
        }

        data = Object.assign({
          ...res,
          callFrequencyList,
          callThroughFrequencyList,
          supplierGuid: flag,
        });
        if (selectCityTags?.length) data.areaLimit = selectCityTags;
        // if (res.areaLimit instanceof Array) {
        //   data = Object.assign({
        //     ...data,
        //     areaLimit: res.areaLimit.toString(),
        //     supplierGuid: flag,
        //   });
        // }

        if (Array.isArray(res.attributions)) {
          if (res.attributions.length > 0) {
            let arr: any = [];
            res.attributions.forEach((it) => {
              if (it.length === 2) {
                arr.push({
                  province: it[0],
                  city: it[1],
                });
              } else if (it.length === 1) {
                arr.push({
                  province: it[0],
                  city: it[0],
                });
              }
            });
            data = {
              ...data,
              attributions: arr,
            };
          }
        }

        if (typeof data.price === 'undefined' || data.price === '') {
          data.price = null;
        }
        if (typeof data.carrier === 'undefined') {
          data.carrier = null;
        }
        if (typeof data.calcPriceUnit === 'undefined') {
          data.calcPriceUnit = null;
        }
        if (
          typeof data.dayCallLimit === 'undefined' ||
          data.dayCallLimit === ''
        ) {
          data.dayCallLimit = null;
        }
        data.monthlyRent = data.monthlyFee === 2 ? data.monthlyRent : 0;
        delete data.monthlyFee;
        if (isEdit) {
          await updateRouters({ ...data, guid: editGuid });
        } else {
          await addRouters(data);
        }
        setFormLoading(false);
        // 清空数据
        // hiddenmodal2();
      });
    } else {
      handleCancel2();
    }
    setFormLoading(false);
    // setTableUpdate(true);
    setLoadDataListTab(!loadDataListTab);
  };

  // 网络请求
  // 获取卡片数据
  const getLineSupplierData = async () => {
    setIsLoadingCard(true);
    const { data } = (await getLineSupplier(queryForm.current)) || {};
    // const index = data.length - 1;
    if (data?.length > 0) {
      data?.forEach((it) => {
        it.createTime = it.createTime.replace('T', ' ');
      });
      setCardData(data);
      const zIndex = data.findIndex((item) => item?.guid === flag);
      setLineSupplierRowHandleId(data?.[0]?.guid);
      if (zIndex > -1) {
        setFlag(data[zIndex]?.guid);
      } else {
        setFlag(data[0]?.guid);
      }
      setIsLoadingCard(false);
    } else {
      setCardData([]);
      setIsLoadingCard(false);
    }
  };
  // 添加card
  const addSupplierData = async (obj: addSupplierType) => {
    await addSupplier(obj);
  };
  // 编辑card
  const editSupplierData = async (obj: editSupplierType) => {
    await editSupplier(obj);
  };
  // const uploadFields = async(supplierGuid: string, aliOssUrl: string) => {
  //   const res = await upload({supplierGuid, aliOssUrl})
  //   console.log(res);
  // }

  // 获取省市数据
  const getCityOpt = useCallback(async () => {
    const opt = [];
    // todo  异步获取省市数据
    const DISTRICTS: any = await getProvinceCityList();
    DISTRICTS.forEach((item) => {
      if (item['level'] === 1) {
        const citys = [];
        DISTRICTS.forEach((i) => {
          if (item.area_code === i.parent_code)
            citys.push({ value: i.area_code, label: i.area_name });
        });
        opt.push({
          value: item.area_code,
          label: item.area_name,
          children: citys,
        });
      }
    });
    setCityOpt(opt);
  }, []);

  useEffect(() => {
    getCityOpt();
    getLineSupplierData();
  }, []);

  useEffect(() => {
    let obj = {};
    if (isAdd === false) {
      if (isModalOpen) {
        obj = cardData.filter((it) => it.guid === flag)[0];
        form.setFieldsValue(obj);
      }
    }
  }, [isModalOpen]);

  // useEffect(() => {
  //   console.log('selectCityLimit', selectCityLimit)
  // }, [selectCityLimit]);

  useEffect(() => {
    if (isEdit && isModalOpen2) {
      getRouters(tableId);
    }
  }, [isModalOpen2]);

  useEffect(() => {
    if (formData) {
      const initialValue: any = JSON.parse(JSON.stringify(formData));
      const callPlaceist = [];
      setEditGuid(initialValue.guid);
      if (initialValue?.areaLimit) {
        const _areaLimit = JSON.parse(initialValue?.areaLimit);
        setSelectCityTags(_areaLimit);
        const areaLimit = [];
        _areaLimit?.forEach((item) => {
          if (!item.child) {
            areaLimit.push([item.value]);
          } else {
            item.child?.forEach((i) => {
              areaLimit.push([item.value, i.value]);
            });
          }
        });
        initialValue.areaLimit = areaLimit;
      } else {
        setSelectCityTags([]);
        initialValue.areaLimit = [];
      }
      if (Array.isArray(initialValue.callFrequencyList)) {
        initialValue.callFrequencyList.forEach((item) => {
          callPlaceist.push({
            type: 'call',
            frequencyCount: item.frequencyCount,
            timePeriod: item.timePeriod,
            timeUnit: item.timeUnit,
          });
        });
      }
      if (Array.isArray(initialValue.callThroughFrequencyList)) {
        initialValue.callThroughFrequencyList.forEach((item) => {
          callPlaceist.push({
            type: 'put',
            frequencyCount: item.frequencyCount,
            timePeriod: item.timePeriod,
            timeUnit: item.timeUnit,
          });
        });
      }
      initialValue.callPlaceist = callPlaceist;
      let attributions: any = [];
      if (initialValue.attributions) {
        initialValue.attributions.forEach((it) => {
          attributions.push([it.province, it.city]);
        });
      }
      if (isModalOpen2) {
        form2.setFieldsValue({
          ...initialValue,
          attributions,
          monthlyFee: initialValue?.monthlyRent ? 2 : 1,
          monthlyRent: initialValue?.monthlyRent
            ? initialValue?.monthlyRent
            : undefined,
        });
      }
    }
  }, [formData]);

  useEffect(() => {
    // setInitTabsKey('lineTabs');
    if (spinRef.current) {
      // @ts-ignore
      setTableHeight(spinRef.current.clientHeight);
    }
  }, [flag]);

  // 租户编辑 新增弹窗
  const handleOk = () => {
    // let editId: string = ''
    form.validateFields().then(async (res) => {
      setEditLoading(true);
      setTimeout(() => {
        if (editLoading) setEditLoading(false);
      }, 5000);
      if (!(res?.supplierName & res?.contacts & res.remark)) {
        if (isAdd) {
          await addSupplierData(res);
        } else {
          // editId = flag
          await editSupplierData({ ...res, guid: flag });
        }
        await getLineSupplierData();
        form.resetFields();
        isShow();
      }
      setEditLoading(false);
    });
    // setFlag(editId)
  };
  const handleCancel = () => {
    isShow();
    setEditLoading(false);
    form.resetFields();
  };

  // // 导入
  // const handleImport = () => {
  //   setShowImportModal(true);
  // };

  // 导入取消
  const handleImportCancel = () => {
    setShowImportModal(false);
    // @ts-ignore
    if (ref.current) ref.current?.clearData();
    setFileUploadFailUrl('');
    setFileList([]);
  };

  // 导入提交
  const handleImportOk = async () => {
    const list = fileList?.filter((item) => item.status === 'done');
    if (!list?.length) return message.error('请先上传文件');
    setConfirmLoading(true);
    const dest = message.loading('正在导入');
    const res = await upload({
      supplierGuid: flag,
      aliOssUrl: list[0].url,
    });
    if (res.success && res.data) {
      if (res?.data?.success) {
        handleImportCancel();
        // setTableUpdate(true);
      } else if (res?.data?.aliOssUrl) {
        message.error('导入失败');
        setFileUploadFailUrl(httpReplace(res?.data?.aliOssUrl));
      }
    }
    dest?.();
    setConfirmLoading(false);
  };

  const validSupplierName = (_, val) => {
    if (val.length > 30) return Promise.reject('供应商名称应小于等于30字');
    return Promise.resolve();
  };
  const validContacts = (_, val) => {
    if (val.length > 20) return Promise.reject('联系人应小于等于30字');
    return Promise.resolve();
  };
  // const validDayCallLimit = (_, val) => {
  //   if (val > 100000000)
  //     return Promise.reject('单日送呼上限应在1-100,000,000之间');
  //   return Promise.resolve();
  // };
  const validConcurrentLimit = (_, val) => {
    if (val > 1000000) return Promise.reject('并发上限应在1-1,000,000之间');
    return Promise.resolve();
  };

  // 商户搜索change
  const handleSearchDebounce = useCallback(
    debounce(() => {
      getLineSupplierData();
    }, 800),
    [supplierSearchType],
  );

  // 商户搜索change
  const handleSearchSupplierChange = useCallback(
    (value: string) => {
      queryForm.current = { [supplierSearchType]: value };
      setSupplierSearchValue(value);
      handleSearchDebounce();
    },
    [supplierSearchType],
  );

  // 盲区级联变化
  const handleCityChange = (arr: any) => {
    // const aa = uniqBy(_arr, 'value')
    const map = {},
      tagData = [];
    for (let i = 0; i < arr.length; i++) {
      const tagItem = arr[i];
      if (!map[tagItem[0].value]) {
        tagData.push({
          value: tagItem[0].value,
          label: tagItem[0].label,
          child: tagItem[1] ? [tagItem[1]] : undefined,
        });
        map[tagItem[0].value] = tagItem[0].value;
      } else {
        const dj = tagData.find((item) => item.value === map[tagItem[0].value]);
        if (dj) {
          if (!dj.child?.length) {
            dj.child = tagItem[1];
          } else {
            dj.child?.push(tagItem[1]);
          }
        }
      }
    }
    console.log('tagData', tagData);
    setSelectCityTags(tagData);
  };

  // tag删除盲区
  const handleDelete = (tag: any) => {
    // 删除级联选项
    const selectCityIds = form2.getFieldValue('areaLimit');
    const zIndex = selectCityIds?.findIndex(
      (item) => item[item.length - 1] === tag,
    );
    if (zIndex > -1) selectCityIds.splice(zIndex, 1);
    form2.setFieldValue('areaLimit', [...selectCityIds]);
    // 删除tag state
    try {
      selectCityTags?.forEach((item, index) => {
        if (item.value === tag) {
          selectCityTags.splice(index, 1);
          setSelectCityTags([...selectCityTags]);
          throw new Error();
        } else {
          const _index = item?.child?.findIndex((i) => i.value === tag);
          if (_index > -1) {
            item?.child.splice(_index, 1);
            if (!item?.child?.length) selectCityTags.splice(index, 1);
            setSelectCityTags([...selectCityTags]);
            throw new Error();
          }
        }
      });
    } catch (e) {}
  };

  const items: TabsProps['items'] = [
    {
      key: 'lineConfig',
      label: `线路配置`,
      children: (
        <div className={styles.lineFormWrap}>
          <Form form={form2} labelCol={{ span: 5 }} wrapperCol={{ span: 14 }}>
            <Form.Item
              label="供应商线路名称"
              name="supporterLineName"
              rules={[{ required: true, message: '请输入' }]}
            >
              <Input placeholder="请输入" maxLength={30} />
            </Form.Item>
            <Form.Item
              label="类型"
              name="numberType"
              rules={[{ required: true, message: '请选择' }]}
            >
              <Select
                placeholder="请选择"
                options={lineTypeOption}
                allowClear
              />
            </Form.Item>
            <Form.Item
              label="对接IP"
              name="lineIp"
              rules={[
                {
                  required: true,
                  message: '请输入正确的ip',
                  pattern: /^\d+\.\d+\.\d+\.\d+$/,
                },
              ]}
            >
              <Input placeholder="请输入" />
            </Form.Item>
            <Form.Item
              label="端口号"
              name="port"
              rules={[
                {
                  required: true,
                  message: '请输入正确的端口号',
                  pattern: /^[0-9]*$/,
                },
              ]}
            >
              <Input placeholder="请输入" />
            </Form.Item>
            <Form.Item
              label="主叫号码"
              name="callingNumber"
              rules={[
                {
                  required: true,
                  message: '请输入主叫号码',
                  pattern: /^[0-9]*$/,
                },
              ]}
            >
              <Input
                placeholder="请输入"
                maxLength={20}
                disabled={showEditText}
              />
            </Form.Item>
            <Form.Item label="被叫前缀" name="prefixCalled">
              <Input placeholder="请输入" maxLength={20} />
            </Form.Item>
            {/* <Form.Item label="外显号码" name="realCallingNumber">
              <Input placeholder="请输入" maxLength={20} />
            </Form.Item> */}
            {/* ？？？ */}
            {/* <Form.Item label="归属省市" name="attributions">
              <Cascader
                options={residences}
                multiple
                showCheckedStrategy={SHOW_CHILD}
              />
            </Form.Item> */}
            {/* <Form.Item label="归属省市" name="province">
        <Cascader options={residences} multiple />
      </Form.Item> */}
            <Form.Item label={<span className="notice">资费</span>}>
              <Space>
                <Form.Item
                  name="price"
                  // extra="元/计费单元"
                  noStyle
                  rules={[
                    { required: true, message: '请输入' },
                    {
                      pattern: /^[0-9]+(\.[0-9]{0,4})?$/,
                      message: '请输入正确的资费',
                    },
                  ]}
                >
                  <Input style={{ width: '200px' }} placeholder="请输入" />
                </Form.Item>
                <Text type="secondary" style={{ marginLeft: '10px' }}>
                  元/计费单元
                </Text>
              </Space>
            </Form.Item>

            <Form.Item
              label="月租费"
              name="monthlyFee"
              rules={[{ required: true, message: '请选择' }]}
            >
              <Radio.Group options={feeOptions} optionType="button" />
            </Form.Item>
            <Form.Item
              noStyle
              shouldUpdate={(prev, cur) => prev.monthlyFee !== cur.monthlyFee}
            >
              {({ getFieldValue }) => {
                const monthlyFee = getFieldValue('monthlyFee');
                return monthlyFee === 2 ? (
                  <Form.Item label=" " colon={false}>
                    <Space>
                      <Form.Item
                        noStyle
                        name="monthlyRent"
                        rules={[
                          { required: true, message: '请输入' },
                          {
                            pattern:
                              /^([1-9]\d*(\.\d{1,2})?|([0](\.([0][1-9]|[1-9]\d{0,1}))))$/,
                            message: '请输入大于0数字，最多保留两位小数',
                          },
                        ]}
                      >
                        <Input placeholder="请输入" />
                      </Form.Item>
                      <Text type="secondary" style={{ marginLeft: '10px' }}>
                        元/月
                      </Text>
                    </Space>
                  </Form.Item>
                ) : null;
              }}
            </Form.Item>

            <Form.Item
              label="计费方式"
              name="calcPriceUnit"
              rules={[{ required: true, message: '请选择' }]}
            >
              <Select placeholder="请选择" allowClear>
                <Option value={6}>6秒</Option>
                <Option value={60}>60秒</Option>
              </Select>
            </Form.Item>
            {/* <Form.Item
              label="单日送呼上限"
              name="dayCallLimit"
              rules={[
                { message: '请输入单日送呼上限', pattern: /^[0-9]*$/ },
                { validator: validDayCallLimit },
              ]}
            >
              <Input placeholder="请输入" />
            </Form.Item> */}
            <Form.Item
              label="并发上限"
              name="concurrentLimit"
              rules={[
                { required: true, message: '请输入', pattern: /^[0-9]*$/ },
                { validator: validConcurrentLimit },
              ]}
            >
              <Input placeholder="请输入" />
            </Form.Item>
            <Form.Item label="外呼限频">
              <Form.List
                name="callPlaceist"
                // initialValue={}
              >
                {(fields, { add, remove }) => (
                  <>
                    <Form.Item
                      noStyle
                      shouldUpdate={(prev, cur) =>
                        prev.callPlaceist !== cur.callPlaceist
                      }
                    >
                      {({ getFieldValue }) => {
                        const list = getFieldValue('callPlaceist');
                        return (
                          <div style={{ marginBottom: '15px' }}>
                            <Button
                              onClick={() =>
                                add({
                                  type: 'call',
                                  frequencyCount: null,
                                  timePeriod: null,
                                  timeUnit: null,
                                })
                              }
                              disabled={list?.length > 5}
                              icon={<PlusOutlined />}
                              type="primary"
                              style={{ marginRight: '10px' }}
                              size="small"
                            >
                              添加呼叫限频
                            </Button>
                            <Button
                              onClick={() =>
                                add({
                                  type: 'put',
                                  frequencyCount: null,
                                  timePeriod: null,
                                  timeUnit: null,
                                })
                              }
                              disabled={list?.length > 5}
                              icon={<PlusOutlined />}
                              type="primary"
                              style={{ marginRight: '10px' }}
                              size="small"
                            >
                              添加接通限频
                            </Button>
                          </div>
                        );
                      }}
                    </Form.Item>

                    {fields.map(({ key, name }) => (
                      <div key={key} style={{ display: 'flex' }}>
                        <MinusCircleFilled
                          style={{ fontSize: '20px', margin: '6px 10px 0 0' }}
                          onClick={() => remove(name)}
                        />
                        <Form.Item
                          noStyle
                          shouldUpdate={(prev, cur) =>
                            prev.callPlaceist !== cur.callPlaceist
                          }
                        >
                          {({ getFieldValue }) => {
                            return (
                              <Form.Item
                                label={
                                  getFieldValue('callPlaceist')[name].type ===
                                  'call'
                                    ? '呼叫'
                                    : '接通'
                                }
                                name={[name, 'frequencyCount']}
                                rules={[{ required: true, message: '请输入' }]}
                              >
                                <Input style={{ width: '70px' }} />
                              </Form.Item>
                            );
                          }}
                        </Form.Item>
                        <div style={{ margin: '5px 10px 0' }}>次/</div>
                        <Form.Item
                          style={{ marginRight: '10px' }}
                          name={[name, 'timePeriod']}
                          rules={[{ required: true, message: '请输入' }]}
                        >
                          <Input style={{ width: '70px' }} />
                        </Form.Item>
                        <Form.Item
                          name={[name, 'timeUnit']}
                          rules={[{ required: true, message: '请选择' }]}
                        >
                          <Select allowClear style={{ width: '70px' }}>
                            <Select.Option value="分钟">分钟</Select.Option>
                            <Select.Option value="小时">小时</Select.Option>
                            <Select.Option value="天">天</Select.Option>
                          </Select>
                        </Form.Item>
                      </div>
                    ))}
                  </>
                )}
              </Form.List>
            </Form.Item>

            <Form.Item
              label="支持呼叫运营商"
              name="supportCarrierTypes"
              rules={[{ required: true, message: '请选择' }]}
            >
              <Select
                placeholder="请选择"
                allowClear
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                mode="multiple"
                options={supportCarrierOpts}
              />
            </Form.Item>

            <Form.Item label="盲区设置" name="areaLimit">
              <Cascader
                options={cityOpt}
                placeholder="请选择省市"
                multiple
                maxTagCount="responsive"
                // showCheckedStrategy={SHOW_CHILD}
                // fieldNames={{ label: 'classifyName', value: 'classifyId' }}
                getPopupContainer={(triggerNode) =>
                  triggerNode.parentElement || document.body
                }
                onChange={(a, b) => {
                  console.log('---', a);
                  handleCityChange(b);
                }}
              />
            </Form.Item>
            <Form.Item label=" " colon={false}>
              <div className={styles.selectTagWrap}>
                {!!selectCityTags?.length &&
                  selectCityTags?.map((item) => (
                    <div className={styles.tagItem} key={item.value}>
                      <div className={styles.tagLeft}>
                        <Tag color="cyan" className={styles.proTag}>
                          <div className={styles.tagName}>{item.label}</div>
                          <div className={styles.tagCount}>
                            (
                            {!item?.child?.length
                              ? '全部'
                              : item?.child?.length}
                            )
                          </div>
                        </Tag>
                      </div>
                      <div className={styles.tagRight}>
                        {!item?.child?.length ? (
                          <Tag
                            closable
                            onClose={(e) => {
                              e.preventDefault();
                              handleDelete(item?.value);
                            }}
                          >
                            全部
                          </Tag>
                        ) : (
                          item?.child?.map((i) => (
                            <Tag
                              key={i.value}
                              className={styles.cityTag}
                              closable
                              onClose={(e) => {
                                e.preventDefault();
                                handleDelete(i?.value);
                              }}
                            >
                              {i.label}
                            </Tag>
                          ))
                        )}
                      </div>
                    </div>
                  ))}
              </div>
            </Form.Item>

            <Form.Item label="备注" name="remark">
              <TextArea rows={5} maxLength={300} />
            </Form.Item>
          </Form>
          <div className={styles.btnWrap}>
            <Button onClick={handleCancel2}>取消</Button>
            <Button
              type="primary"
              className={styles.rightBtn}
              loading={formLoading}
              onClick={handleOk2}
            >
              确定
            </Button>
          </div>
        </div>
      ),
    },
    showEditText
      ? {
          key: 'phoneInfo',
          label: `号码信息`,
          children: <PhoneInfoModal tableId={tableId} />,
        }
      : null,
  ];

  // const rendorFooter = () => {
  //   if (tableKey === 'lineConfig') {
  //     return (
  //       <>
  //         <Space>
  //           <Button onClick={handleCancel2}>取消</Button>
  //           <Button type="primary" onClick={handleOk2}>
  //             确定
  //           </Button>
  //         </Space>
  //       </>
  //     );
  //   } else {
  //     return '';
  //   }
  // };

  return (
    <>
      <div className={styles.linesupplier}>
        <div className={styles.left}>
          {access?.authCodeList?.includes('Call-Line-Linesupplier-AddPOS') && (
            <div className={styles.btn}>
              <Button type="primary" size="large" block onClick={addUser}>
                新增供应商
              </Button>
            </div>
          )}
          <div className={styles.search}>
            <Input.Search
              allowClear
              onSearch={handleSearchSupplierChange}
              addonBefore={
                <Select
                  style={{ width: 115 }}
                  options={supplierSearchTypes}
                  value={supplierSearchType}
                  onChange={setSupplierSearchType}
                />
              }
            />
          </div>

          <div className={styles.cardlist}>
            <Spin spinning={isLoadingCard}>
              {cardData.length > 0 ? (
                cardData.map((it) => (
                  <AddCard
                    key={it.guid}
                    title={it.supplierName}
                    goodsCode={it.supplierNumber}
                    contacts={it.contacts}
                    time={it.createTime}
                    id={it.guid}
                    heightLight={heightLight}
                    flag={flag}
                    codeType={2}
                    tag={true}
                    status={it.supplierStatus}
                    isShow={isShow}
                    editAuth={access?.authCodeList?.includes(
                      'Call-Line-Linesupplier-EditPOS',
                    )}
                  />
                ))
              ) : (
                <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
              )}
            </Spin>
          </div>
        </div>
        <div className={styles.right}>
          <Tabs
            destroyInactiveTabPane
            // defaultActiveKey={'lineConfig'}
            activeKey={initTabsKey}
            onChange={(key: string) => setInitTabsKey(key)}
            items={[
              {
                label: `线路列表`,
                key: 'lineTabs',
                children: (
                  <LineList
                    id={flag}
                    modalRouter={modalRouter}
                    getTableId={getTableId}
                    isModalOpen2={isModalOpen2}
                    toTableEdit={toTableEdit}
                    setShowEditText={setShowEditText}
                    supplierSearchValue={supplierSearchValue}
                    supplierSearchType={supplierSearchType}
                  />
                ),
              },
              {
                label: '挂机码配置',
                key: 'hangingCode',
                children: <HangingCode id={flag} activeKey={initTabsKey} />,
              },
              // {
              //   label: `数据统计`,
              //   key: 'dataTabs',
              //   children: <DataStatistic tabsKey={tabsKey} id={flag} />,
              // },
            ]}
          />
        </div>
      </div>
      {/* 左侧商户编辑框 */}
      <Modal
        title="编辑"
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        getContainer={false}
        confirmLoading={editLoading}
        okText="提交"
        forceRender
      >
        <Form form={form} labelCol={{ span: 6 }} wrapperCol={{ span: 14 }}>
          <Form.Item
            label="供应商名称"
            name="supplierName"
            rules={[
              { required: true, message: '请输入' },
              { validator: validSupplierName },
            ]}
          >
            <Input placeholder="请输入" />
          </Form.Item>
          <Form.Item
            label="联系人"
            name="contacts"
            rules={[
              { required: true, message: '请输入' },
              { validator: validContacts },
            ]}
          >
            <Input placeholder="请输入" />
          </Form.Item>
          <Form.Item
            label="合作状态"
            name="supplierStatus"
            rules={[{ required: true, message: '请输入' }]}
            initialValue={1}
          >
            <Select
              placeholder="请选择"
              allowClear
              disabled={isAdd ? true : false}
            >
              <Option value={1}>合作中</Option>
              <Option value={2}>已停止</Option>
            </Select>
          </Form.Item>
          <Form.Item
            label="备注"
            name="remark"
            // rules={[{ validator: validRemark }]}
          >
            <TextArea rows={3} maxLength={120} />
          </Form.Item>
        </Form>
      </Modal>

      {/* table线路弹窗 */}
      <Drawer
        title={showEditText ? '编辑' : '新增'}
        placement="right"
        onClose={handleCancel2}
        width={1000}
        className={styles.modalright}
        open={isModalOpen2}
        // footer={rendorFooter()}
        destroyOnClose
      >
        <Tabs
          // defaultActiveKey={tableKey}
          activeKey={tableKey}
          items={items}
          onChange={(key) => setTableKey(key)}
        ></Tabs>
      </Drawer>
      {/* <Modal
          title={showEditText ? '编辑' : '新增'}
          open={isModalOpen2}
          onOk={handleOk2}
          onCancel={handleCancel2}
          getContainer={false}
          footer={rendorFooter()}
          destroyOnClose
          width={1250}
        >
          <Tabs
            defaultActiveKey={tableKey}
            items={items}
            onChange={(key) => setTableKey(key)}
          ></Tabs>
        </Modal> */}

      {/* 批量导入 */}
      <Modal
        open={showImportModal}
        title="批量导入"
        forceRender={true}
        width={'540px'}
        onOk={handleImportOk}
        onCancel={handleImportCancel}
        confirmLoading={confirmLoading}
        getContainer={false}
        destroyOnClose={true}
      >
        <FileUploadShowList
          // @ts-ignore
          ref={ref}
          showUploadList={true}
          uploadType=".xlsx,.xls"
          onChange={(list) => setFileList(list)}
        >
          <div className={styles.uploadIcon}>
            <InboxOutlined />
          </div>
          <div className={styles.notice}>点击或将文件拖拽到这里上传</div>
          <div className={styles.uploadType}>支持扩展名：&nbsp;.xlsx</div>
        </FileUploadShowList>
        <div style={{ textAlign: 'right' }}>
          <Button
            type="link"
            size="small"
            href="https://m.hellobike.com/resource/helloyun/wb23958/%E4%BE%9B%E5%BA%94%E5%95%86%E7%BA%BF%E8%B7%AF%E5%AF%BC%E5%85%A5%E6%A8%A1%E7%89%88.xlsx"
          >
            下载模版
          </Button>
        </div>
        {fileUploadFailUrl && !!fileList?.length && (
          <div className={styles.errorUploadWrap}>
            <VerticalAlignBottomOutlined className={styles.errorUploadIcon} />
            <a
              rel="noreferrer"
              target="_blank"
              href={fileUploadFailUrl}
              className={styles.errorUploadText}
            >
              下载导入失败数据
            </a>
          </div>
        )}
      </Modal>
    </>
  );
};

export default LineSupplier;
