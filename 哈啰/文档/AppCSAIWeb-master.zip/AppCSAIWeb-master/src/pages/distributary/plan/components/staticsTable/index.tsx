//分流渠道统计
import React, { useState, useEffect } from 'react';
import { Table, Tooltip, Typography } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { toThousands } from '@/utils';
import { channelTaskStat, IStatData, IStatList } from '@/api/distributary';
import ChartModal from '../chartModal';
import { transformNum } from '../../../config';
import styles from './index.less';
interface PropsType {
  planId?: string;
}

const StaticsTable: React.FC<PropsType> = ({ planId }) => {
  const [listInfo, setListInfo] = useState<IStatData>({});
  const [tableLoading, setTableLoading] = useState(false);
  const [open, setOpen] = useState(false); //图表弹窗
  const [chartData, setChartData] = useState({}); //图表数据
  /**
   * api
   */
  // table数据
  const getList = async () => {
    setTableLoading(true);
    try {
      const res = await channelTaskStat({ planId });
      if (res.code === 0) {
        setListInfo(res.data || {});
      }
      setTableLoading(false);
    } catch (error) {
      setTableLoading(false);
    }
  };

  const chartFunc = (intentClassifyList, conversionFunnel) => {
    setChartData({
      intentClassifyList,
      conversionFunnel,
    });
    setOpen(true);
  };

  const columns: ColumnsType = [
    {
      title: '渠道名称',
      dataIndex: 'channelName',
      key: 'channelName',
      fixed: 'left',
      width: 150,
    },
    {
      title: '任务名称',
      dataIndex: 'supplierTaskName',
      key: 'supplierTaskName',
      fixed: 'left',
      width: 200,
      render: (text) => {
        return (
          <Tooltip placement="topLeft" title={text}>
            <Typography.Paragraph className={styles.mb0} ellipsis={{ rows: 1 }}>
              {text}
            </Typography.Paragraph>
          </Tooltip>
        );
      },
    },
    {
      title: '任务ID',
      dataIndex: 'supplierTaskId',
      key: 'supplierTaskId',
      width: 200,
      render: (text) => {
        return (
          <Tooltip placement="topLeft" title={text}>
            <Typography.Paragraph className={styles.mb0} ellipsis={{ rows: 1 }}>
              {text}
            </Typography.Paragraph>
          </Tooltip>
        );
      },
    },
    {
      title: '下发总量',
      dataIndex: 'sentTotalNum',
      key: 'sentTotalNum',
      width: 140,
      align: 'right',
      render: (text: number) => {
        return toThousands(text, true);
      },
    },
    {
      title: '占比',
      dataIndex: 'sentTotalNumPercentage',
      key: 'sentTotalNumPercentage',
      width: 100,
      align: 'center',
      render: (text: string) => {
        return text || '-';
      },
    },
    {
      title: '下发成功量',
      dataIndex: 'sentSuccessNum',
      key: 'sentSuccessNum',
      width: 140,
      align: 'right',
      render: (text: number) => {
        return toThousands(text, true);
      },
    },
    {
      title: '话单量',
      dataIndex: 'callDialogueNum',
      key: 'callDialogueNum',
      width: 140,
      align: 'right',
      render: (text: number) => {
        return toThousands(text, true);
      },
    },
    {
      title: '接通话单量',
      dataIndex: 'throughCallDialogueNum',
      key: 'throughCallDialogueNum',
      width: 140,
      align: 'right',
      render: (text: number) => {
        return toThousands(text, true);
      },
    },
    {
      title: '语音计费数',
      dataIndex: 'costUnit',
      key: 'costUnit',
      width: 140,
      align: 'right',
      render: (text: number) => {
        return toThousands(text, true);
      },
    },
    {
      title: '接通名单数',
      dataIndex: 'throughRosterNum',
      key: 'throughRosterNum',
      width: 140,
      align: 'right',
      render: (text: number) => {
        return toThousands(text, true);
      },
    },
    {
      title: '名单接通率',
      dataIndex: 'throughRosterPercentage',
      key: 'throughRosterPercentage',
      width: 120,
      align: 'center',
      render: (text: string) => {
        return text || '-';
      },
    },
    {
      title: '发送短信名单数',
      dataIndex: 'sendSmsSum',
      key: 'sendSmsSum',
      width: 140,
      align: 'right',
      render: (text: number) => {
        return toThousands(text, true);
      },
    },
    {
      title: '短信成功名单数',
      dataIndex: 'smsSuccSum',
      key: 'smsSuccSum',
      width: 140,
      align: 'right',
      render: (text: number) => {
        return toThousands(text, true);
      },
    },
    {
      title: '名单短信成功率',
      dataIndex: 'smsSuccRate',
      key: 'smsSuccRate',
      width: 140,
      align: 'center',
      render: (text: string) => {
        return text || '-';
      },
    },
    {
      title: '短信计费数',
      dataIndex: 'smsUnit',
      key: 'smsUnit',
      width: 140,
      align: 'right',
      render: (text: number) => {
        return toThousands(text, true);
      },
    },
    {
      title: '最新下发时间',
      dataIndex: 'latestSentTime',
      key: 'latestSentTime',
      width: 200,
      render: (text: string) => {
        return text || '-';
      },
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      key: 'createTime',
      width: 200,
    },
    {
      title: 'A',
      dataIndex: 'A',
      key: 'A',
      width: 140,
      align: 'right',
      render: (_, record: IStatList) => {
        return transformNum('A', record?.intentClassifyList);
      },
    },
    {
      title: 'B',
      dataIndex: 'B',
      key: 'B',
      width: 140,
      align: 'right',
      render: (_, record: IStatList) => {
        return transformNum('B', record?.intentClassifyList);
      },
    },
    {
      title: 'C',
      dataIndex: 'C',
      key: 'C',
      width: 140,
      align: 'right',
      render: (_, record: IStatList) => {
        return transformNum('C', record?.intentClassifyList);
      },
    },
    {
      title: 'D',
      dataIndex: 'D',
      key: 'D',
      width: 140,
      align: 'right',
      render: (_, record: IStatList) => {
        return transformNum('D', record?.intentClassifyList);
      },
    },
    {
      title: 'E',
      dataIndex: 'E',
      key: 'E',
      width: 140,
      align: 'right',
      render: (_, record: IStatList) => {
        return transformNum('E', record?.intentClassifyList);
      },
    },
    {
      title: 'G',
      dataIndex: 'G',
      key: 'G',
      width: 140,
      align: 'right',
      render: (_, record: IStatList) => {
        return transformNum('G', record?.intentClassifyList);
      },
    },
    {
      title: 'H',
      dataIndex: 'H',
      key: 'H',
      width: 140,
      align: 'right',
      render: (_, record: IStatList) => {
        return transformNum('H', record?.intentClassifyList);
      },
    },
    {
      title: '操作',
      dataIndex: 'action',
      key: 'action',
      width: 100,
      fixed: 'right',
      render: (_, record: IStatList) => (
        <>
          <Typography.Link
            onClick={() =>
              chartFunc(record.intentClassifyList, record?.conversionFunnel)
            }
          >
            图表
          </Typography.Link>
        </>
      ),
    },
  ];

  useEffect(() => {
    if (planId) {
      getList();
    }
  }, [planId]);

  const TableSummary: React.FC = () => {
    return (
      <Table.Summary fixed>
        <Table.Summary.Row>
          <Table.Summary.Cell index={0} colSpan={2}>
            总数
          </Table.Summary.Cell>
          <Table.Summary.Cell index={2}></Table.Summary.Cell>
          <Table.Summary.Cell index={3}>
            <div className={styles.textRight}>
              {toThousands(listInfo?.sentTotalSum, true)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={4}></Table.Summary.Cell>
          <Table.Summary.Cell index={5}>
            <div className={styles.textRight}>
              {toThousands(listInfo?.sentSuccessSum, true)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={6}>
            <div className={styles.textRight}>
              {toThousands(listInfo?.callDialogueNumSum, true)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={7}>
            <div className={styles.textRight}>
              {toThousands(listInfo?.throughCallDialogueNumSum, true)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={8}>
            <div className={styles.textRight}>
              {toThousands(listInfo?.costUnitSum, true)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={9}>
            <div className={styles.textRight}>
              {toThousands(listInfo?.throughRosterNumSum, true)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={10}>
            <div className={styles.textCenter}>
              {listInfo?.throughRosterPercentage || '-'}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={11}>
            <div className={styles.textRight}>
              {toThousands(listInfo?.totalSendSmsSum, true)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={12}>
            <div className={styles.textRight}>
              {toThousands(listInfo?.totalSmsSuccSum, true)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={13}>
            <div className={styles.textCenter}>
              {listInfo?.totalSmsSuccRate || '-'}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={14}>
            <div className={styles.textRight}>
              {toThousands(listInfo?.totalSmsUnit, true)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={15}></Table.Summary.Cell>
          <Table.Summary.Cell index={16}></Table.Summary.Cell>
          <Table.Summary.Cell index={17}>
            <div className={styles.textRight}>
              {transformNum('A', listInfo?.totalIntentClassifyList)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={18}>
            <div className={styles.textRight}>
              {transformNum('B', listInfo?.totalIntentClassifyList)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={19}>
            <div className={styles.textRight}>
              {transformNum('C', listInfo?.totalIntentClassifyList)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={20}>
            <div className={styles.textRight}>
              {transformNum('D', listInfo?.totalIntentClassifyList)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={21}>
            <div className={styles.textRight}>
              {transformNum('E', listInfo?.totalIntentClassifyList)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={22}>
            <div className={styles.textRight}>
              {transformNum('G', listInfo?.totalIntentClassifyList)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={23}>
            <div className={styles.textRight}>
              {transformNum('H', listInfo?.totalIntentClassifyList)}
            </div>
          </Table.Summary.Cell>
          <Table.Summary.Cell index={24}>
            <Typography.Link
              onClick={() =>
                chartFunc(
                  listInfo.totalIntentClassifyList,
                  listInfo?.totalConversionFunnel,
                )
              }
            >
              图表
            </Typography.Link>
          </Table.Summary.Cell>
        </Table.Summary.Row>
      </Table.Summary>
    );
  };

  return (
    <>
      <Table
        pagination={false}
        dataSource={listInfo.channelTaskStatList}
        columns={columns}
        loading={tableLoading}
        scroll={{ x: '1240' }}
        rowKey={'supplierTaskId'}
        summary={(currentData) => currentData.length > 0 && <TableSummary />}
      />
      <ChartModal
        open={open}
        chartData={chartData}
        onCancel={() => setOpen(false)}
      ></ChartModal>
    </>
  );
};

export default StaticsTable;
