// 上传记录
import React, { useState, useEffect, useRef } from 'react';
import {
  Button,
  message,
  Radio,
  Select,
  Space,
  Tooltip,
  Typography,
} from 'antd';
import { PlusOutlined, RedoOutlined } from '@ant-design/icons';
import ResizeTable from '@/components/ResizeTable';
import type { ColumnsType } from 'antd/es/table';
import { debounce } from 'lodash';
import {
  queryUploadList,
  IDqueryUploadParams,
  rosterRetryDistribute,
} from '@/api/distributary';
import { toThousands } from '@/utils';
import UploadModal from '../uploadModal';
import { distributeTypeList, uploadOptions } from '../../../config';
import styles from './index.less';

interface PropsType {
  planId: string;
}

const UploadLog: React.FC<PropsType> = ({ planId }) => {
  const [dataSource, setDataSource] = useState([]);
  const [tableLoading, setTableLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [open, setOpen] = useState(false); //上传数据弹窗
  const [loadingCurrent, setLoadingCurrent] = useState({});
  // 搜索params
  const queryParams = useRef<IDqueryUploadParams>({
    pageNum: 1,
    pageSize: 100,
  });
  /**
   * api
   */
  // table数据
  const getList = async (data: IDqueryUploadParams) => {
    queryParams.current = { ...queryParams.current, ...data };
    try {
      setTableLoading(true);
      const res = await queryUploadList(queryParams.current);
      setTotal(res.totalRecord || 0);
      setDataSource(res?.list || []);
      setTableLoading(false);
    } catch (error) {
      setTableLoading(false);
    }
  };
  // 重试下发
  const handleRetry = debounce(async (data: any) => {
    setLoadingCurrent((prev) => ({
      ...prev,
      [`${data.id}-loading`]: true,
    }));
    // 下发失败提示：渠道任务尚未创建完成，暂不支持下发
    try {
      const res = await rosterRetryDistribute({
        uploadRecordId: data.id,
        distributePlanId: planId,
      });
      if (res.code === 0) {
        message.success('重试下发成功');
        getList({});
      }
      setLoadingCurrent((prev) => ({
        ...prev,
        [`${data.id}-loading`]: false,
      }));
    } catch (error) {}
  }, 200);

  //下发状态
  const renderDistributeStatus = (status) => {
    const statusItem = distributeTypeList.find((item) => item.value === status);
    return statusItem?.label || '-';
  };

  //上传状态
  const renderUploadStatus = (status) => {
    switch (status) {
      case 0:
        return '待解析';
      case 1:
        return '上传失败';
      case 2:
        return '上传中';
      case 3:
        return '上传完成';
      default:
        return '-';
    }
  };

  const columns: ColumnsType = [
    {
      title: 'ID',
      dataIndex: 'id',
      key: 'id',
      fixed: 'left',
      width: 200,
      render: (text) => {
        return (
          <Tooltip placement="topLeft" title={text}>
            <Typography.Paragraph className={styles.mb0} ellipsis={{ rows: 1 }}>
              {text}
            </Typography.Paragraph>
          </Tooltip>
        );
      },
    },
    {
      title: '上传方式',
      dataIndex: 'uploadType',
      key: 'uploadType',
      fixed: 'left',
      width: 120,
      render: (text: number) => (text === 2 ? '手动上传' : '接口上传'),
    },
    {
      title: '上传类型',
      dataIndex: 'rosterTypeDesc',
      key: 'rosterTypeDesc',
      width: 120,
    },
    {
      title: '上传状态',
      dataIndex: 'uploadStatus',
      key: 'uploadStatus',
      width: 120,
      render: (text: number) => {
        return renderUploadStatus(text);
      },
    },
    {
      title: '上传失败原因',
      dataIndex: 'uploadFailReason',
      key: 'uploadFailReason',
      width: 160,
      render: (text) => {
        return (
          <Tooltip placement="topLeft" title={text}>
            <Typography.Paragraph className={styles.mb0} ellipsis={{ rows: 1 }}>
              {text || '-'}
            </Typography.Paragraph>
          </Tooltip>
        );
      },
    },
    {
      title: '上传数量',
      dataIndex: 'uploadCount',
      key: 'uploadCount',
      width: 140,
      align: 'right',
      render: (text: number) => {
        return toThousands(text);
      },
    },
    {
      title: '下发状态',
      dataIndex: 'distributeStatus',
      key: 'distributeStatus',
      width: 100,
      render: (text: number) => {
        return renderDistributeStatus(text);
      },
    },
    {
      title: '下发数量',
      dataIndex: 'distributeCount',
      key: 'distributeCount',
      align: 'right',
      width: 140,
      render: (text: number) => {
        return toThousands(text);
      },
    },
    {
      title: '操作账号',
      dataIndex: 'operator',
      width: 240,
      key: 'operator',
    },
    {
      title: '上传时间',
      dataIndex: 'uploadTime',
      width: 180,
      key: 'uploadTime',
    },
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 120,
      render: (_, record: any) => (
        <>
          {/* 针对下发状态为【下发失败】，增加重试下发的按钮 */}
          {record.distributeStatus === 4 ? (
            <Button
              onClick={() => handleRetry(record)}
              type="link"
              icon={<RedoOutlined />}
              loading={loadingCurrent?.[`${record.id}-loading`] ? true : false}
            >
              重试下发
            </Button>
          ) : (
            ''
          )}
        </>
      ),
    },
  ];
  // 分页change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum: pageSize === queryParams.current.pageSize ? pageNum : 1,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    getList(paginationObj);
  };
  useEffect(() => {
    if (planId) {
      getList({ distributePlanId: planId });
    }
  }, [planId]);

  return (
    <div className={styles.uploadLog}>
      <div className={styles.searchBar}>
        <Space>
          <Radio.Group
            buttonStyle="solid"
            defaultValue={undefined}
            onChange={(e) =>
              getList({ uploadType: e.target.value, pageNum: 1 })
            }
          >
            <Radio.Button value={undefined}>全部</Radio.Button>
            {uploadOptions.map((item) => (
              <Radio.Button key={item.value} value={item.value}>
                {item.label}
              </Radio.Button>
            ))}
          </Radio.Group>
          <Select
            placeholder="下发状态"
            allowClear
            style={{ width: 150, marginLeft: 16 }}
            options={distributeTypeList}
            getPopupContainer={(triggerNode) =>
              triggerNode.parentElement || document.body
            }
            onChange={(distributeStatus) =>
              getList({ distributeStatus, pageNum: 1 })
            }
          ></Select>
        </Space>

        <Button
          onClick={() => setOpen(true)}
          type="primary"
          icon={<PlusOutlined />}
        >
          上传数据
        </Button>
      </div>

      <ResizeTable
        columns={columns}
        dataSource={dataSource}
        loading={tableLoading}
        rowKey={'id'}
        scroll={{ x: '1240' }}
        pagination={{
          onChange: handlePageChange,
          current: queryParams?.current?.pageNum || 1,
          pageSize: queryParams?.current?.pageSize || 100,
          pageSizeOptions: [25, 50, 100],
          total,
        }}
      />
      {open && (
        <UploadModal
          open={open}
          onCancel={() => setOpen(false)}
          onOk={() => {
            setOpen(false);
            getList({});
          }}
          distributePlanId={planId}
        />
      )}
    </div>
  );
};

export default UploadLog;
