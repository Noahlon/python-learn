import React, { useEffect, useState } from 'react';
import { Button, Modal, Input, message, Select, Pagination, Empty } from 'antd';
import { cloneDeep } from 'lodash';
import moment from 'moment';
import { templateList, IDtemplateList } from '@/api/distributary';
import { tenantList } from '@/api/tenantManage';
import TemplateCard from '../templateCard';
import styles from './index.less';

interface EditModalType {
  open?: boolean;
  onOk: (record?) => void;
  onCancel: () => void;
}

const { Search } = Input;

const CreatePlanModal: React.FC<EditModalType> = ({ open, onOk, onCancel }) => {
  const [params, setParams] = useState<any>({
    pageNum: 1,
    pageSize: 10,
  });
  const [data, setData] = useState<IDtemplateList>();
  const [activeItem, setActiveItem] = useState(null); //当前选中的模版id
  const [tenant, setTenant] = useState([]);

  //通过模版创建计划
  const handleOk = async () => {
    if (!activeItem?.templateId) {
      message.warning('请选择一个模版');
      return;
    }
    const currentTime = moment(new Date()).format('YYYYMMDDHHmmss');
    //需要将模版数据转化成创建计划所需要的表单数据
    const record = cloneDeep(activeItem);
    record.distributePlanName = `${record.templateName}-${currentTime}`;
    // delete record.templateId;
    delete record.templateName;
    onOk(record);
  };

  //创建自定义计划
  const handleCreate = () => {
    onOk();
  };

  //输入搜索框
  const onSearch = (val) => {
    setParams({ ...params, templateName: val, pageNum: 1 });
  };

  //租户搜索
  const handleTenantChange = (val) => {
    setParams({ ...params, tenantCodeList: val, pageNum: 1 });
  };

  //模版点击
  const handleTemplateClick = (item) => {
    setActiveItem(item);
  };

  // 获取租户下拉列表
  const getTenantList = async () => {
    const { data } = await tenantList({
      pageNum: 1,
      pageSize: 999,
    });
    setTenant(data);
  };

  const handlePageChange = (page: number) => {
    setParams({ ...params, pageNum: page });
  };

  //请求参数变化，请求列表数据
  useEffect(() => {
    //触发接口请求的时候，清空activeItem
    templateList(params).then((res) => {
      if (res?.code === 0) {
        setData(res?.data || {});
        setActiveItem({});
      }
    });
  }, [params]);

  useEffect(() => {
    if (open) {
      getTenantList();
    }
  }, [open]);

  return (
    <Modal
      open={open}
      title="创建自定义计划"
      width={'800px'}
      onOk={handleOk}
      onCancel={onCancel}
      getContainer={false}
      destroyOnClose={true}
      className={styles['createModal']}
    >
      <div className={styles['create-plan-modal']}>
        <div className={styles['searchBar']}>
          <Button type="primary" onClick={handleCreate}>
            创建自定义计划
          </Button>
          <div className={styles['searchNode']}>
            <Search
              style={{ width: '200px' }}
              placeholder="模版名称"
              onSearch={onSearch}
              allowClear
            />
            <Select
              allowClear
              className={styles.tenantSelect}
              mode="multiple"
              maxTagCount="responsive"
              filterOption={(input, option) =>
                (option?.name as string)
                  .toLowerCase()
                  .includes(input.toLowerCase())
              }
              fieldNames={{ label: 'name', value: 'code' }}
              options={tenant}
              placeholder="请选择租户"
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
              onChange={(val) => handleTenantChange(val)}
            />
          </div>
        </div>
        <div className={styles.templateList}>
          <div className={styles['templateContent']}>
            {!!data?.list?.length ? (
              <>
                {data?.list?.map((item) => {
                  return (
                    <div
                      onClick={() => handleTemplateClick(item)}
                      key={item.templateId}
                      className={`${styles.templateItem} ${
                        activeItem?.templateId === item.templateId
                          ? styles.active
                          : ''
                      }`}
                    >
                      <TemplateCard data={item} />
                    </div>
                  );
                })}
                {/* css样式兼容 */}
                <div style={{ height: '1px', width: '100%' }}></div>
              </>
            ) : (
              <div className={styles['empty-space']}>
                <Empty description="暂无数据" />
              </div>
            )}
          </div>
        </div>
        {!!data?.totalRecord && (
          <div className={styles['pagination-bar']}>
            <Pagination
              current={params.pageNum}
              size="small"
              onChange={handlePageChange}
              total={data?.totalRecord}
              showSizeChanger={false} // 超出 50条不显示分页器
            />
          </div>
        )}
      </div>
    </Modal>
  );
};

export default CreatePlanModal;
