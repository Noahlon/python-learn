/* 模版/计划 新增/编辑弹窗 */
import React, { useEffect, useState } from 'react';
import {
  Button,
  Modal,
  Form,
  Input,
  message,
  Select,
  InputNumber,
  Tooltip,
  Popconfirm,
} from 'antd';
import { isEmpty, cloneDeep } from 'lodash';
import {
  DeleteOutlined,
  PlusOutlined,
  InfoCircleOutlined,
} from '@ant-design/icons';
import {
  IDtemplateListColumn,
  channelList,
  channelTemplateList,
  IDplanDetail,
  templateCreate,
  templateEdit,
  planEdit,
  planCreate,
} from '@/api/distributary';
import { tenantList } from '@/api/tenantManage';
import { typeList } from '../../../config';
import styles from './index.less';

interface EditModalType {
  open?: boolean;
  modalType: number; //1-模版 2-计划
  details?: IDtemplateListColumn | IDplanDetail;
  onOk: () => void;
  onCancel?: () => void;
}

const EditModal: React.FC<EditModalType> = ({
  open,
  onOk,
  details,
  onCancel,
  modalType,
}) => {
  const [form] = Form.useForm();
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [tenant, setTenant] = useState([]);
  const tenantCode = Form.useWatch('tenantCode', form);
  const isEdit =
    (modalType === 1 && details?.templateId) ||
    (modalType === 2 && details?.id);

  // 渠道列表
  const [channeldropDown, setChanneldropDown] = useState([]);
  const [channelTemplateOptions, updateChannelTemplateOptions] = useState([]);
  const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };

  // 提交上传
  const handleOk = async () => {
    let values = await form.validateFields();
    const { tenantCode, distributeType, distributeRuleList } = values;
    if (Number(distributeRuleList?.length) === 0) {
      message.error('请添加规则');
      return;
    }
    let rules = [];
    distributeRuleList?.forEach((item: any) => {
      const { channelId, percentage, taskTemplateId } = item;
      rules.push({
        channelId: channelId?.value,
        channelName: channelId?.label,
        percentage: percentage,
        taskTemplateId: taskTemplateId?.value,
        taskTemplateName: taskTemplateId?.label,
      });
    });
    const params = {
      tenantCode: tenantCode?.value,
      tenantName: tenantCode?.label,
      distributeType,
      distributeRuleList: rules,
    };
    //规则校验
    const totalPercent = rules.reduce((accumulator, currentValue) => {
      return accumulator + Number(currentValue.percentage);
    }, 0);
    if (Number(totalPercent) !== 100) {
      message.error('分流比加和不等于100，请重新编辑提交');
      return;
    }
    setConfirmLoading(true);

    //区分计划/模版，区分新增/编辑
    let res;
    //编辑模版
    if (modalType === 1 && details?.templateId) {
      res = await templateEdit({
        ...params,
        templateName: values?.templateName,
        templateId: details?.templateId,
      });
    }
    //新增模版
    if (modalType === 1 && !details?.templateId) {
      res = await templateCreate({
        ...params,
        templateName: values?.templateName,
      });
    }
    //编辑计划
    if (modalType === 2 && details?.id) {
      res = await planEdit({
        ...params,
        distributePlanName: values.distributePlanName,
        id: details?.id,
      });
    }
    //新增计划
    if (modalType === 2 && !details?.id) {
      const para = {
        ...params,
        distributePlanName: values.distributePlanName,
      };
      if (details?.templateId) {
        Object.assign(para, {
          distributePlanTemplateId: details?.templateId,
        });
      }
      res = await planCreate(para);
    }
    setConfirmLoading(false);

    if (res.code === 0) {
      onOk();
    }
  };

  // 获取租户下拉列表
  const getTenantList = async () => {
    const { data } = await tenantList({
      pageNum: 1,
      pageSize: 999,
    });
    setTenant(data);
  };

  //获取渠道商下拉列表
  const getChannelList = async () => {
    try {
      const data = await channelList();
      setChanneldropDown(data);
    } catch (error) {}
  };

  //根据渠道商和租户id获取对应任务模版列表
  // todo 哈啰ai外呼判断逻辑待优化
  const getChannelTemplateList = async (channelId, index) => {
    const options = [...channelTemplateOptions];

    if (!channelId) {
      options[index] = [];
      updateChannelTemplateOptions(options);
      return;
    }

    //选择ai外呼，但未选择租户，前端提示,并清空当前任务模版列表
    if (channelId === 1 && !tenantCode?.value) {
      options[index] = [];
      updateChannelTemplateOptions(options);
      return message.info('请选择租户');
    }

    try {
      if ((channelId === 1 && tenantCode?.value) || channelId !== 1) {
        const data = await channelTemplateList({
          channelIdList: [channelId],
          tenantCode: channelId === 1 ? tenantCode?.value : '',
        });
        options[index] = data?.[0]?.templateList;
        updateChannelTemplateOptions(options);
      }
    } catch (error) {}
  };

  //租户切换事件，当选择哈啰ai外呼的渠道商时，需要重新请求任务模板列表
  // todo 哈啰ai外呼判断逻辑待优化
  const handleTenantChange = async (val) => {
    const tenant = val.value;
    const distributeRuleList = form.getFieldValue('distributeRuleList');
    const values = distributeRuleList?.map((_, index) => [
      'distributeRuleList',
      index,
      'taskTemplateId',
    ]);
    const channelIds = distributeRuleList?.map(
      (item) => item?.channelId?.value,
    );
    const haluoAI = channelIds?.filter((item) => item === 1);
    if (haluoAI?.length) {
      const data = await channelTemplateList({
        channelIdList: [1],
        tenantCode: tenant,
      });
      const options = [...channelTemplateOptions];
      distributeRuleList?.forEach((item, index) => {
        //如果当前为哈啰ai外呼，则更新对应的下拉数据选项
        if (item?.channelId?.value === 1) {
          options[index] = data?.[0]?.templateList;
          form.resetFields([values?.[index]]);
        }
      });
      updateChannelTemplateOptions(options);
    }
  };

  //渠道切换操作,清空对应渠道下的选中的任务模版
  //同时根据选中的渠道，请求对应的任务模板列表
  //value 选中值 / indexNumber当前切换的index
  const handleChannelChange = (value, indexNumber) => {
    const _distributeRuleList = form.getFieldValue('distributeRuleList');
    const values = _distributeRuleList?.map((_, index) => [
      'distributeRuleList',
      index,
      'taskTemplateId',
    ]);
    form.resetFields([values?.[indexNumber]]);
    getChannelTemplateList(value?.value, indexNumber);
  };

  const validateTemplate = () => {
    const distributeRuleList = form.getFieldValue('distributeRuleList');
    const value = distributeRuleList?.map((_, index) => [
      'distributeRuleList',
      index,
      'taskTemplateId',
    ]);
    if (!!value?.length) form.validateFields(value);
  };

  //根据details是否为空，判断表单回显逻辑
  //如果details中含有id，即为计划的编辑
  //如果details中含有templateId,即为模版的编辑
  useEffect(() => {
    getTenantList();
    getChannelList();
    //数据回显
    if (!isEmpty(details)) {
      const { tenantCode, tenantName, distributeType, distributeRuleList } =
        details;
      let formData = {
        tenantCode: {
          value: Number(tenantCode),
          label: tenantName,
        },
        distributeType,
      };
      if (modalType === 1 && details.templateName) {
        Object.assign(formData, {
          templateName: details.templateName,
        });
      } else {
        Object.assign(formData, {
          distributePlanName: details.distributePlanName,
        });
      }
      // 分流规则列表数量不为0
      if(distributeRuleList?.length>0){
        const _distributeRuleList = distributeRuleList.map((item) => {
          return {
            channelId: {
              value: item.channelId,
              label: item.channelName,
            },
            percentage: item.percentage,
            taskTemplateId: {
              value: item.taskTemplateId,
              label: item.taskTemplateName,
            },
          };
        });
        const channelIdList = distributeRuleList?.map((item) => item.channelId);
        channelTemplateList({
          tenantCode,
          channelIdList,
        }).then((res) => {
          let options = [];
          res?.forEach((item, index) => {
            const key = index;
            options[key] = item.templateList;
          });
          updateChannelTemplateOptions(options);
          Object.assign(formData, {
            distributeRuleList: _distributeRuleList,
          });
          form.setFieldsValue(formData);
        });
      }else{
        form.setFieldsValue(formData);
      }
    } else {
      form.setFieldsValue({
        distributeRuleList: [
          {
            channelId: null,
            percentage: null,
            taskTemplateId: null,
          },
        ],
      });
    }
  }, [open]);

  return (
    <Modal
      open={open}
      title={`分流${modalType === 1 ? '模版' : '计划'}`}
      width={'600px'}
      onOk={handleOk}
      onCancel={onCancel}
      confirmLoading={confirmLoading}
      getContainer={false}
      className={styles.ruleEditModal}
      destroyOnClose={true}
    >
      <Form {...layout} form={form} className={styles.formBox}>
        <Form.Item label="租户" name="tenantCode" rules={[{ required: true }]}>
          <Select
            placeholder="请选择"
            showSearch
            getPopupContainer={(triggerNode) =>
              triggerNode.parentElement || document.body
            }
            disabled={!!isEdit}
            labelInValue
            onChange={handleTenantChange}
            optionFilterProp="name"
            options={tenant}
            fieldNames={{ label: 'name', value: 'code' }}
          ></Select>
        </Form.Item>
        <Form.Item
          label={modalType === 1 ? '模版名称' : '计划名称'}
          name={modalType === 1 ? 'templateName' : 'distributePlanName'}
          rules={[{ required: true }]}
        >
          <Input
            disabled={!!isEdit && modalType === 2}
            maxLength={200}
            placeholder={
              modalType === 1
                ? '请输入模版名称，名称长度限制200'
                : '请输入计划名称，名称长度限制200'
            }
          />
        </Form.Item>
        <Form.Item
          label={
            <Tooltip
              title={
                <div>
                  <div>实时分流：名单上传成功后实时分发到渠道商</div>
                  <div>
                    离线分流：名单上传成功后按照时间间隔集合名单再进行分发操作
                  </div>
                </div>
              }
            >
              <span>
                <InfoCircleOutlined />
                &nbsp; 类型
              </span>
            </Tooltip>
          }
          name="distributeType"
          rules={[{ required: true, message: '请选择类型' }]}
        >
          <Select
            placeholder="请选择"
            getPopupContainer={(triggerNode) =>
              triggerNode.parentElement || document.body
            }
            disabled={!!isEdit}
            allowClear
            options={typeList}
          ></Select>
        </Form.Item>
        <span className={styles.tips}>
          分流规则：名单数据会按照下述流量比例分发
        </span>
        <Form.List name="distributeRuleList">
          {(fields, { add, remove }) => (
            <>
              {fields.map(({ key, name, ...restField }, index) => (
                <div key={index} className={styles.ruleContent}>
                  <div className={styles.ruleItem}>
                    <div className={styles.ruleItemTop}>
                      <Form.Item
                        {...restField}
                        name={[name, 'channelId']}
                        style={{ marginRight: 8 }}
                        rules={[{ required: true, message: '' }]}
                      >
                        <Select
                          placeholder="渠道名称"
                          showSearch
                          disabled={
                            details?.distributeRuleList?.length > key &&
                            !!isEdit &&
                            modalType === 2
                          }
                          getPopupContainer={(triggerNode) =>
                            triggerNode.parentElement || document.body
                          }
                          style={{ width: 180 }}
                          allowClear
                          labelInValue
                          options={channeldropDown}
                          optionFilterProp="channelName"
                          fieldNames={{
                            label: 'channelName',
                            value: 'channelId',
                          }}
                          onChange={(val) => handleChannelChange(val, index)}
                        ></Select>
                      </Form.Item>
                      <Form.Item
                        {...restField}
                        name={[name, 'percentage']}
                        label="分流比例"
                        labelCol={{ span: 10 }}
                        rules={[{ required: true, message: '' }]}
                      >
                        <InputNumber
                          addonAfter="%"
                          placeholder="请输入"
                          controls={false}
                          precision={2}
                          max={100}
                          min={0}
                          maxLength={6}
                        />
                      </Form.Item>
                    </div>
                    <Form.Item
                      {...restField}
                      name={[name, 'taskTemplateId']}
                      rules={[
                        { required: true, message: '' },
                        {
                          validator: (_, value) => {
                            if (!value?.value) {
                              return Promise.reject(new Error(''));
                            }
                            const distributeRuleList = cloneDeep(
                              form.getFieldValue('distributeRuleList'),
                            );
                            const current = distributeRuleList[index];
                            distributeRuleList.splice(index, 1);
                            if (
                              !!distributeRuleList?.length &&
                              distributeRuleList?.some((item) => {
                                return (
                                  item?.taskTemplateId?.value ===
                                    current?.taskTemplateId?.value &&
                                  item?.channelId?.value ===
                                    current?.channelId?.value
                                );
                              }) &&
                              current?.taskTemplateId &&
                              current?.channelId
                            ) {
                              return Promise.reject(
                                new Error('该任务模版已经存在，请重新选择'),
                              );
                            }
                            return Promise.resolve();
                          },
                        },
                      ]}
                      wrapperCol={{ span: 24 }}
                    >
                      <Select
                        placeholder="任务模版"
                        showSearch
                        getPopupContainer={(triggerNode) =>
                          triggerNode.parentElement || document.body
                        }
                        disabled={
                          details?.distributeRuleList?.length > key &&
                          !!isEdit &&
                          modalType === 2
                        }
                        style={{ width: '100%', maxWidth: 396 }}
                        allowClear
                        options={channelTemplateOptions?.[index]}
                        labelInValue
                        optionFilterProp="templateName"
                        fieldNames={{
                          label: 'templateName',
                          value: 'templateId',
                        }}
                        onChange={validateTemplate}
                      ></Select>
                    </Form.Item>
                  </div>
                  <Popconfirm
                    disabled={
                      details?.distributeRuleList?.length > key &&
                      !!isEdit &&
                      modalType === 2
                    }
                    title="确定删除该条规则吗？"
                    onConfirm={() => {
                      const options = [...channelTemplateOptions];
                      options.splice(index, 1);
                      updateChannelTemplateOptions(options);
                      remove(name);
                      validateTemplate();
                    }}
                  >
                    <Button
                      disabled={
                        details?.distributeRuleList?.length > index &&
                        !!isEdit &&
                        modalType === 2
                      }
                      style={{ marginBottom: 24 }}
                      type="text"
                      icon={<DeleteOutlined />}
                    ></Button>
                  </Popconfirm>
                </div>
              ))}
              {/* 规则不超过20 */}
              {fields.length < 20 && (
                <Form.Item>
                  <Button
                    style={{ marginLeft: 48 }}
                    type="link"
                    onClick={() => add()}
                    icon={<PlusOutlined />}
                  >
                    添加
                  </Button>
                </Form.Item>
              )}
            </>
          )}
        </Form.List>
      </Form>
    </Modal>
  );
};

export default EditModal;
