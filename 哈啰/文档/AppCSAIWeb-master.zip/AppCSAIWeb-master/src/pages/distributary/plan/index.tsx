import React, { useEffect, useState, useRef } from 'react';
import ResizeTable from '@/components/ResizeTable';
import { useAccess } from '@umijs/max';
import {
  Form,
  Row,
  Col,
  Input,
  Select,
  DatePicker,
  Space,
  Button,
  Tooltip,
  Typography,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { timeRanges } from '@/config';
import moment from 'moment';
import { throttle } from 'lodash';
import { tenantList } from '@/api/tenantManage';
import {
  planPageQuery,
  IDplanParams,
  IDplanPageQuery,
  channelList,
  planDetail,
  IDplanDetail,
  IDplanPageResponse,
} from '@/api/distributary';
import { toThousands } from '@/utils';
import { typeList } from '../config';
import Details from './components/details';
import EditModal from './components/editModal';
import CreatePlanModal from './components/createPlanModal';
import styles from './index.less';

const { RangePicker } = DatePicker;
const PlanPage: React.FC = () => {
  const [tenant, setTenant] = useState([]);
  const access = useAccess();
  const [form] = Form.useForm();
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [planId, setPlanId] = useState('');
  const [detailsOpen, setDetailsOpen] = useState(false); //查看详情抽屉
  const [editOpen, setEditOpen] = useState(false); //编辑弹窗
  const [createOpen, setCreateOpen] = useState(false); //新增弹窗
  const [details, setDetail] = useState<IDplanDetail>({}); //分流计划详情数据
  // 渠道列表
  const [channeldropDown, setChanneldropDown] = useState([]);
  // 搜索params
  const queryParams = useRef<IDplanParams>({ pageNum: 1, pageSize: 100 });
  const layout = {
    labelCol: { span: 1 },
    wrapperCol: { span: 23 },
  };
  // 获取租户下拉列表
  const getTenantList = async () => {
    try {
      const { data } = await tenantList({
        pageNum: 1,
        pageSize: 999,
      });
      setTenant(data || []);
    } catch (error) {}
  };
  // 获取渠道商列表
  const getChannelList = async () => {
    try {
      const data = await channelList();
      setChanneldropDown(data || []);
    } catch (e) {}
  };
  // 获取列表数据
  const getList = async (data: IDplanParams) => {
    queryParams.current = { ...queryParams.current, ...data };
    setLoading(true);
    try {
      const res: IDplanPageResponse = await planPageQuery(queryParams.current);
      if (res?.code === 0) {
        setTotal(res?.data?.totalRecord || 0);
        setData(res?.data?.list || []);
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
    }
  };
  //查看详情
  const handleDetails = (record: any) => {
    setPlanId(record.id);
    setDetailsOpen(true);
  };

  //编辑计划
  const handleEdit = async (record) => {
    const data = await planDetail({ planId: record.id });
    setDetail(data);
    setEditOpen(true);
  };

  //新增计划
  const handleCreate = () => {
    setDetail({});
    setCreateOpen(true);
  };

  //分流计划新增/编辑成功回调函数
  const handleEditOk = () => {
    setEditOpen(false);
    if (details?.id) {
      getList({});
    } else {
      getList({ pageNum: 1 });
    }
  };

  const column: ColumnsType<IDplanPageQuery> = [
    {
      title: '计划ID',
      dataIndex: 'id',
      key: 'id',
      width: 200,
    },
    {
      title: '分流计划名称',
      dataIndex: 'distributePlanName',
      key: 'distributePlanName',
      width: 200,
      render: (text) => {
        return (
          <Tooltip placement="topLeft" title={text}>
            <Typography.Paragraph className={styles.mb0} ellipsis={{ rows: 2 }}>
              {text}
            </Typography.Paragraph>
          </Tooltip>
        );
      },
    },
    {
      title: '租户名称',
      dataIndex: 'tenantName',
      key: 'tenantName',
      width: 200,
      render: (text) => {
        return (
          <Tooltip placement="topLeft" title={text}>
            <Typography.Paragraph
              className={styles.mbText0}
              ellipsis={{ rows: 1 }}
            >
              {text}
            </Typography.Paragraph>
          </Tooltip>
        );
      },
    },
    {
      title: '类型',
      dataIndex: 'distributeTypeDesc',
      key: 'distributeTypeDesc',
      width: 100,
    },
    {
      title: '数据量',
      dataIndex: 'uploadDataNum',
      key: 'uploadDataNum',
      width: 180,
      align: 'center',
      render: (text) => {
        return text ? toThousands(text) : 0;
      },
    },
    {
      title: '分流情况',
      dataIndex: 'distributeRuleList',
      key: 'distributeRuleList',
      width: 300,
      render: (text) => {
        return (
          <>
            {text?.length > 0 ? (
              <Tooltip
                placement="topLeft"
                overlayClassName={styles.tooltipBox}
                title={
                  <div>
                    {text.map((item, index) => {
                      return (
                        <div key={index}>
                          {item.channelName}：
                          {(item.sendPercentage && `${item.sendPercentage}%`) ||
                            '0.00%'}
                          &nbsp;|&nbsp;
                          {item.supplierTaskName}&nbsp;|&nbsp;数量：
                          {(item.quantity && toThousands(item.quantity)) || 0};
                        </div>
                      );
                    })}
                  </div>
                }
              >
                <Typography.Paragraph
                  className={styles.mb0}
                  ellipsis={{ rows: 2 }}
                >
                  {text.map((item, index) => {
                    return (
                      <div key={index}>
                        {item.channelName}：
                        {(item.sendPercentage && `${item.sendPercentage}%`) ||
                          '0.00%'}
                        &nbsp;|&nbsp;
                        {item.supplierTaskName}&nbsp;|&nbsp;数量：
                        {(item.quantity && toThousands(item.quantity)) || 0};
                      </div>
                    );
                  })}
                </Typography.Paragraph>
              </Tooltip>
            ) : (
              '-'
            )}
          </>
        );
      },
    },
    {
      title: '创建人',
      dataIndex: 'creator',
      key: 'creator',
      width: 180,
    },
    {
      title: '分流计划模版ID',
      dataIndex: 'distributePlanTemplateId',
      key: 'distributePlanTemplateId',
      width: 200,
      render: (text: string) => text || '-',
    },
    {
      title: '分流计划模版名称',
      dataIndex: 'distributePlanTemplateName',
      key: 'distributePlanTemplateName',
      width: 200,
      render: (text) => {
        return text ? (
          <Tooltip placement="topLeft" title={text}>
            <Typography.Paragraph className={styles.mb0} ellipsis={{ rows: 2 }}>
              {text}
            </Typography.Paragraph>
          </Tooltip>
        ) : (
          '-'
        );
      },
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      key: 'createTime',
      width: 200,
    },
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 100,
      render: (_, record) => (
        <Space>
          {access?.authCodeList?.includes('Distributary-Manage-plan-edit') && (
            <Typography.Link onClick={() => handleEdit(record)}>
              编辑
            </Typography.Link>
          )}
          {access?.authCodeList?.includes(
            'Distributary-Manage-plan-detail',
          ) && (
            <Typography.Link onClick={() => handleDetails(record)}>
              详情
            </Typography.Link>
          )}
        </Space>
      ),
    },
  ];

  // 分页change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum: pageSize === queryParams.current.pageSize ? pageNum : 1,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    getList({ ...paginationObj });
  };
  // 搜索
  const handleSearch = throttle((values) => {
    if (values.createTime && values.createTime.length === 2) {
      values.createStartTime = moment(values.createTime[0]).format(
        'YYYY-MM-DD HH:mm:ss',
      );
      values.createEndTime = moment(values.createTime[1]).format(
        'YYYY-MM-DD HH:mm:ss',
      );
    } else {
      values.createStartTime = undefined;
      values.createEndTime = undefined;
    }
    delete values.createTime;
    const args = {
      ...values,
      planName: values?.planName?.trim() || undefined,
      planId: values?.planId?.trim() || undefined,
      pageNum: 1,
    };
    getList(args);
  }, 500);
  // 重置
  const handleReset = throttle(() => {
    form.resetFields();
    const values = form.getFieldsValue();
    queryParams.current = {};
    const args = {
      ...values,
      pageNum: 1,
      pageSize: 100,
    };
    getList(args);
  }, 500);
  //创建计划的回调函数
  const handleCreateOk = (record?: any) => {
    setCreateOpen(false);
    setEditOpen(true);
    setDetail(record ? record : {});
  };

  useEffect(() => {
    getTenantList();
    getChannelList();
    getList(queryParams.current);
  }, []);

  return (
    <>
      <div className={styles['distributary-plan-list']}>
        <Form
          className={styles.search}
          form={form}
          {...layout}
          onFinish={handleSearch}
        >
          <Row wrap={false}>
            <Col flex="auto">
              <div className={styles.formItem}>
                <Form.Item name="planName">
                  <Input placeholder="计划名称" allowClear />
                </Form.Item>
              </div>
              <div className={styles.formItem}>
                <Form.Item name="planId">
                  <Input placeholder="计划ID" allowClear />
                </Form.Item>
              </div>
              <div className={styles.formItem}>
                <Form.Item name="tenantCodeList">
                  <Select
                    placeholder="租户"
                    showSearch
                    getPopupContainer={(triggerNode) =>
                      triggerNode.parentElement || document.body
                    }
                    allowClear
                    mode="multiple"
                    maxTagCount="responsive"
                    optionFilterProp="name"
                    options={tenant}
                    fieldNames={{ label: 'name', value: 'code' }}
                  ></Select>
                </Form.Item>
              </div>
              <div className={styles.formItem}>
                <Form.Item name="distributeType">
                  <Select
                    placeholder="类型"
                    allowClear
                    options={typeList}
                    getPopupContainer={(triggerNode) =>
                      triggerNode.parentElement || document.body
                    }
                  ></Select>
                </Form.Item>
              </div>
              <div className={styles.formItem}>
                <Form.Item name="channelId">
                  <Select
                    placeholder="渠道名称"
                    allowClear
                    showSearch
                    options={channeldropDown}
                    optionFilterProp="channelName"
                    getPopupContainer={(triggerNode) =>
                      triggerNode.parentElement || document.body
                    }
                    fieldNames={{ label: 'channelName', value: 'channelId' }}
                  ></Select>
                </Form.Item>
              </div>
              <div className={styles.formItem}>
                <Form.Item name="createTime">
                  <RangePicker
                    placeholder={['开始', '结束']}
                    showTime={{
                        hideDisabledOptions: true,
                        defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                    }}
                    ranges={timeRanges}
                  />
                </Form.Item>
              </div>
              {/* todo 待联调 对字段*/}
              <div className={styles.formItem}>
                <Form.Item name="supplierTemplateName">
                  <Input placeholder="下游模版名称" allowClear />
                </Form.Item>
              </div>
              <div className={styles.formItem}>
                <Form.Item name="supplierTemplateId">
                  <Input placeholder="下游模版ID" allowClear />
                </Form.Item>
              </div>
              <div className={styles.formItem}>
                <Form.Item name="planTemplateName">
                  <Input placeholder="计划模版" allowClear />
                </Form.Item>
              </div>
              <div className={styles.formItem}>
                <Form.Item name="planTemplateId">
                  <Input placeholder="计划模版ID" allowClear />
                </Form.Item>
              </div>
               {/* todo 待联调 对字段*/}
            </Col>
            <Col flex="none" className={styles.searchBox}>
              <Space className={styles.searchBoxSpace}>
                <Button type="primary" htmlType="submit">
                  搜索
                </Button>
                <Button onClick={handleReset}>重置</Button>
              </Space>
            </Col>
          </Row>
        </Form>
        {access?.authCodeList?.includes('Distributary-Manage-plan-create') && (
          <div className={styles.addButton}>
            <Button type="primary" onClick={handleCreate}>
              创建
            </Button>
          </div>
        )}
        {/* <div className={styles.tableWrap} ref={tableRef} id="planeWrap"> */}
        <ResizeTable
          columns={column}
          dataSource={data}
          loading={loading}
          scroll={{ x: 2200 }}
          rowKey={'id'}
          pagination={{
            onChange: handlePageChange,
            current: queryParams.current.pageNum,
            pageSize: queryParams.current.pageSize,
            pageSizeOptions: [25, 50, 100],
            total,
          }}
        />
        {detailsOpen && (
          <Details
            open={detailsOpen}
            planId={planId}
            onCancel={() => setDetailsOpen(false)}
          />
        )}
        {/* 分流计划新增/编辑弹窗 */}
        {editOpen && (
          <EditModal
            open={editOpen}
            onCancel={() => setEditOpen(false)}
            details={details}
            modalType={2}
            onOk={handleEditOk}
          />
        )}
        {/* 新建计划弹窗 */}
        {createOpen && (
          <CreatePlanModal
            open={createOpen}
            onOk={handleCreateOk}
            onCancel={() => setCreateOpen(false)}
          />
        )}
      </div>
    </>
  );
};
export default PlanPage;
