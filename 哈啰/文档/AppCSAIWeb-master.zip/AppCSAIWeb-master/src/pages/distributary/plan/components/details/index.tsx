//分流详情
import React, { useEffect, useState } from 'react';
import {
  Button,
  Drawer,
  Input,
  Tabs,
  message,
  Descriptions,
  Divider,
  Alert,
  Tooltip,
} from 'antd';
import { EditOutlined, RedoOutlined } from '@ant-design/icons';
import { useAccess } from '@umijs/max';
import { debounce } from 'lodash';
import {
  planDetail,
  channelTaskRetry,
  IDplanDetail,
  IDplanDetailRuleList,
} from '@/api/distributary';
import StaticsTable from '../staticsTable';
import UploadLog from '../uploadLog';
import IssueRecord from '../issueRecord';
import EditModal from '../editModal';
import styles from './index.less';

interface PropsType {
  planId: string;
  open: boolean;
  onCancel: () => void;
}

const Details: React.FC<PropsType> = ({ planId, open, onCancel }) => {
  // 类型
  const access = useAccess();
  const [editOpen, setEditOpen] = useState(false); //编辑弹窗
  const [tabKey, setTabKey] = useState('1');
  const [info, setInfo] = useState<IDplanDetail>({});
  const [loadingCurrent, setLoadingCurrent] = useState({});
  const [currentId, setCurrentId] = useState('');

  /**
   * 获取租户配置
   */
  const getDetail = async () => {
    try {
      setCurrentId('');
      const data = await planDetail({ planId });
      setInfo(data || {});
      setCurrentId(data?.id);
    } catch (error) {}
  };

  const handleCancel = () => {
    onCancel();
  };

  //任务重试
  const retry = debounce(async (item: IDplanDetailRuleList) => {
    setLoadingCurrent((prev) => ({
      ...prev,
      [`${item.planChannelTaskId}-loading`]: true,
    }));
    const res = await channelTaskRetry({
      planChannelTaskId: item.planChannelTaskId,
    });
    if (res.code === 0) {
      message.success('任务重试成功');
      getDetail();
    }
    setLoadingCurrent((prev) => ({
      ...prev,
      [`${item.planChannelTaskId}-loading`]: false,
    }));
  }, 200);

  //规则状态
  const renderStatus = (record) => {
    switch (record.planChannelTaskStatus) {
      case 1:
        return <Alert message="任务创建成功" type="success" showIcon></Alert>;
      case 2:
        return <Alert message="任务未创建" type="info" showIcon></Alert>;
      case 0:
        return <Alert message="任务创建失败" type="error" showIcon></Alert>;
      default:
        return null;
    }
  };
  //分流计划新增/编辑成功回调函数
  const handleEditOk = () => {
    setEditOpen(false);
    getDetail();
  };

  useEffect(() => {
    if (open && planId) {
      getDetail();
    }
  }, [open]);

  return (
    <Drawer
      open={open}
      width={900}
      onClose={handleCancel}
      title={'分流计划'}
      getContainer={false}
    >
      <Descriptions title="基础信息">
        <Descriptions.Item label="分流计划名称">
          <Tooltip placement="topLeft" title={info?.distributePlanName}>
            <div className={styles.textEllipsis}>
              {info?.distributePlanName || '-'}
            </div>
          </Tooltip>
        </Descriptions.Item>
        <Descriptions.Item label="计划ID">{info?.id || '-'}</Descriptions.Item>
        <Descriptions.Item label="创建人">
          {info?.creator || '-'}
        </Descriptions.Item>
        <Descriptions.Item label="租户名称">
          {info?.tenantName || '-'}
        </Descriptions.Item>
        <Descriptions.Item label="租户编号">
          {info?.tenantCode || '-'}
        </Descriptions.Item>
        <Descriptions.Item label="创建时间">
          {info?.createTime || '-'}
        </Descriptions.Item>
        <Descriptions.Item label="类型">
          {info?.distributeTypeDesc || '-'}
        </Descriptions.Item>
      </Descriptions>
      <Divider />
      <div className={styles.addLine}>
        <h3>分流信息</h3>
        {access?.authCodeList?.includes('Distributary-Manage-plan-edit') && (
          <EditOutlined
            style={{
              marginBottom: 8,
              marginLeft: 16,
              fontSize: 18,
              color: '#1890ff',
            }}
            onClick={() => setEditOpen(true)}
          />
        )}
      </div>
      <div className={styles.ruleContent}>
        <div className={styles.title}>配置信息：</div>
        <div className={styles.ruleItems}>
          {info?.distributeRuleList?.map((item: IDplanDetailRuleList) => {
            return (
              <div key={item.planChannelTaskId} className={styles.ruleItem}>
                <Descriptions column={8} className={styles.ruleWrap}>
                  <Descriptions.Item span={2}>
                    <Input readOnly value={item.channelName} />
                  </Descriptions.Item>
                  <Descriptions.Item label="分流比例" span={3}>
                    <Input readOnly value={item.percentage} addonAfter="%" />
                  </Descriptions.Item>
                  <Descriptions.Item span={3}>
                    <Input readOnly value={item.taskTemplateName} />
                  </Descriptions.Item>
                </Descriptions>
                <div className={styles.ruleStatus}>
                  {renderStatus(item)}
                  {/* 任务创建失败情况下，可以重试 */}
                  {item?.planChannelTaskStatus === 0 && (
                    <Button
                      loading={
                        loadingCurrent?.[`${item.planChannelTaskId}-loading`]
                      }
                      onClick={() => retry(item)}
                      type="link"
                      icon={<RedoOutlined />}
                    >
                      重试
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {/* 线路状态tabs */}
      <Tabs
        destroyInactiveTabPane
        activeKey={tabKey}
        items={[
          {
            key: '1',
            label: `分流渠道统计`,
            children: <StaticsTable planId={currentId} />,
          },
          {
            key: '2',
            label: `上传记录`,
            children: <UploadLog planId={currentId} />,
          },
          {
            key: '3',
            label: `下发记录`,
            children: <IssueRecord planId={currentId} />,
          },
        ]}
        onChange={(key) => setTabKey(key)}
      />
      {/* 分流计划新增/编辑弹窗 */}
      {editOpen && (
        <EditModal
          open={editOpen}
          onCancel={() => setEditOpen(false)}
          details={info}
          modalType={2}
          onOk={handleEditOk}
        />
      )}
    </Drawer>
  );
};
export default Details;
