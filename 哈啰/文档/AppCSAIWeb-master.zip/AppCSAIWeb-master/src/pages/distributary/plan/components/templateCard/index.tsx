//计划模版卡片，新建计划弹窗中展示
import React from 'react';
import { Tooltip, Card } from 'antd';
import { IDtemplateListColumn } from '@/api/distributary';
import { typeList } from '../../../config';
import styles from './index.less';

interface Props {
  data: IDtemplateListColumn;
}

const TemplateCard: React.FC<Props> = ({ data }) => {
  const renderType = (type) => {
    return typeList.find((item) => item.value === type)?.label;
  };

  return (
    <Card className={styles['templateCard']}>
      <h3 className={styles.templateName}>{data.templateName}</h3>
      <div className={styles.templateItem}>
        <span className={styles.label}>ID：</span>
        <span className={styles.content}>{data.templateId}</span>
      </div>
      <div className={styles.templateItem}>
        <span className={styles.label}>租户：</span>
        <span className={styles.content}>{data.tenantName}</span>
      </div>
      <div className={styles.templateItem}>
        <span className={styles.label}>类型：</span>
        <span className={styles.content}>
          {renderType(data.distributeType)}
        </span>
      </div>
      <div className={styles.templateRules}>
        <span className={styles.label}>分流规则：</span>
        <div className={styles['rules']}>
          {data?.distributeRuleList?.length > 2 ? (
            <Tooltip
              getPopupContainer={(triggerNode) => {
                return triggerNode || document.body;
              }}
              title={data?.distributeRuleList?.map((item) => (
                <div key={item.taskTemplateId} className={styles.templateItem}>
                  {item.taskTemplateName}：{item.percentage}% |{' '}
                  {item.channelName}
                </div>
              ))}
            >
              {data?.distributeRuleList?.slice(0, 2)?.map((item) => (
                <div key={item.taskTemplateId} className={styles.templateItem}>
                  {item.taskTemplateName}：{item.percentage}% |{' '}
                  {item.channelName}
                </div>
              ))}
              <span style={{ fontWeight: 'bold' }}>· · ·</span>
            </Tooltip>
          ) : (
            data?.distributeRuleList?.map((item) => (
              <div key={item.taskTemplateId} className={styles.templateItem}>
                {item.taskTemplateName}：{item.percentage}% | {item.channelName}
              </div>
            ))
          )}
        </div>
      </div>
    </Card>
  );
};
export default TemplateCard;
