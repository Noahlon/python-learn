import React, { memo, useEffect, useState } from 'react';
import { Modal, Row, Col, Empty } from 'antd';
import { Pie, Funnel, FUNNEL_CONVERSATION_FIELD } from '@ant-design/plots';
import { IConversionFunnel, IIntentClassifyList } from '@/api/distributary';

import styles from './index.less';
interface ChartPropsType {
  open?: boolean;
  chartData?: {
    intentClassifyList?: IIntentClassifyList[];
    conversionFunnel?: IConversionFunnel[];
  };
  onCancel: () => void;
}
const ChartModal: React.FC<ChartPropsType> = memo(
  ({ open, onCancel, chartData }) => {
    const [statisticsInfo, setStatisticsInfo] = useState<any>({});
    const [processInfo, setProcessInfo] = useState<any>({});

    // 漏斗
    const getFunnelInfo = () => {
      setStatisticsInfo({});
      if (chartData?.conversionFunnel?.length > 0) {
        const option = {
          xField: 'name',
          yField: 'value',
          legend: false,
          color: [
            '#98f108',
            '#1790FF',
            '#8181FF',
            '#70B605',
            '#BFBF00',
            '#D98201',
          ],
          data: chartData?.conversionFunnel,
          maxSize: 0.9,
          appendPadding: [0, 220, 0, 0],
          label: {
            style: {
              fill: '#333',
            },
          },
          conversionTag: {
            formatter: (item: any) => {
              const [total, current] = item[FUNNEL_CONVERSATION_FIELD];
              let percentage: number | string = '0.00';
              if (total !== 0) {
                percentage = ((current / total) * 100).toFixed(2);
              }
              console.log(item, '1');
              switch (item.code) {
                case 'sentTotalNum':
                  return `下发率=下发总量/数据量\n${percentage}%`;
                case 'sentSuccessNum':
                  return `下发成功率=下发成功量/下发总量\n${percentage}%`;
                case 'throughRosterNum':
                  return `接通率=名单接通量/下发成功量\n${percentage}%`;
                case 'sendSmsSum':
                  return `短信触发率=发送短信名单数/名单接通量\n${percentage}%`;
                case 'smsSuccSum':
                  return `短信成功率=短信成功名单数/发送短信名单数\n${percentage}%`;
                default:
                  return null;
              }
            },
          },
        };
        setStatisticsInfo(option);
      }
    };
    //环形图
    const circularFunc = () => {
      setProcessInfo({});
      if (chartData?.intentClassifyList?.length) {
        let total = chartData.intentClassifyList.reduce(
          (acc: any, cur: any) => {
            return acc + cur.value;
          },
          0,
        );
        const option = {
          appendPadding: [0, 60, 0, 0],
          legend: {
            position: 'right',
            offsetX: -55,
            itemValue: {
              formatter: (text, item, index) => {
                try {
                  let itemData = chartData?.intentClassifyList[index] || {};
                  return `${itemData.value || 0}  ${itemData.percentage || 0}`;
                } catch (error) {}
              },
              style: {
                opacity: 0.65,
              },
            },
          },
          data: chartData.intentClassifyList,
          angleField: 'value',
          colorField: 'name',
          label: false,
          radius: 1,
          innerRadius: 0.7,
          interactions: [
            {
              type: 'element-selected',
            },
            {
              type: 'element-active',
            },
          ],
          tooltip: {
            customItems: (items) => {
              return items.map((d) => ({
                ...d,
                value: `${d.data.value}，${d.data.percentage}`,
              }));
            },
          },
          statistic: {
            title: false,
            content: {
              style: {
                whiteSpace: 'pre-wrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                fontSize: '14',
                fontWeight: 400,
              },
              customHtml: (
                <>
                  <div>接通话单量</div>
                  <div className={styles.mt8}>{total}</div>
                </>
              ),
            },
          },
        };
        setProcessInfo(option);
      }
    };
    useEffect(() => {
      if (open) {
        getFunnelInfo();
        circularFunc();
      }
    }, [open]);
    return (
      <div className={styles.chartModal}>
        <Modal
          open={open}
          title="图表"
          width={'960px'}
          onCancel={onCancel}
          getContainer={false}
          destroyOnClose={true}
          footer={null}
        >
          <Row gutter={16}>
            <Col span={14} className={styles.chartBox}>
              <div className={styles.chartTitle}>转化漏斗</div>
              <div className={styles.transformCon}>
                {(statisticsInfo?.data?.length > 0 &&
                  statisticsInfo?.data.some(
                    (item: IConversionFunnel) => item?.value > 0,
                  ) && <Funnel {...statisticsInfo} />) || (
                  <Empty
                    image={Empty.PRESENTED_IMAGE_SIMPLE}
                    className={styles.mt200}
                  />
                )}
              </div>
              <div className={styles.border}></div>
            </Col>
            <Col span={10}>
              <div className={styles.chartTitle}>意向分布</div>
              {(processInfo?.data?.length > 0 && <Pie {...processInfo} />) || (
                <Empty
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                  className={styles.mt200}
                />
              )}
            </Col>
          </Row>
        </Modal>
      </div>
    );
  },
);

export default ChartModal;
