import React, { memo, useEffect, useState } from 'react';
import { Modal, Form, Upload, message, Typography, Button, Radio } from 'antd';
import { RcFile } from 'antd/es/upload';
import OSS from 'ali-oss';
import { rosterUploadFile, rosterDownload } from '@/api/distributary';
import { handleDownload } from '@/utils/index';
import { getOSSToken, authorize } from '@/api/common';
import { uploadTypeOptions } from '../../../config';
import { CloudUploadOutlined } from '@ant-design/icons';
interface UploadPropsType {
  open?: boolean;
  distributePlanId?: string;
  onOk: () => void;
  onCancel: () => void;
}

const UploadModal: React.FC<UploadPropsType> = memo(
  ({ open, onOk, distributePlanId, onCancel }) => {
    const [confirmLoading, setConfirmLoading] = useState(false);
    const [fileList, setFileList] = useState<any[]>([]);
    const [uploading, setUploading] = useState(false);
    const [rosterType, setRosterType] = useState(1);

    const layout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 18 },
    };

    const beforeUpload = (file: RcFile) => {
      const isLt1M = file.size / 1024 / 1024 < 100;
      if (!isLt1M) {
        message.error('文件不能超过100M');
      }
      return isLt1M;
    };

    const getOSSData = async (fileData: any) => {
      const ossResult = await getOSSToken();
      const data = ossResult?.data;
      if (data) {
        const client = new OSS({
          // 将<your_bucket>设置为OSS Bucket名称。
          bucket: data.bucket,
          // 将<your_region>设置为OSS Bucket所在地域，例如region: 'oss-cn-hangzhou'。
          region: data.region,
          accessKeyId: data.accessKeyId,
          accessKeySecret: data.accessKeySecret,
          stsToken: data.securityToken,
        });
        const options = {
          parallel: 100,
          partSize: 1024 * 1024 * 1, // 1M
          timeout: 120000, // 设置超时时间
        };
        const regionfileName = fileData.file.name;
        // eslint-disable-next-line @typescript-eslint/restrict-template-expressions
        const fileName = `${new Date().getTime()}.${regionfileName
          .split('.')
          .at(-1)}`;
        try {
          const result: any = await client.multipartUpload(
            `${data?.baseDir}${fileName}`,
            fileData.file,
            { ...options },
          );
          message.success('文件上传成功');
          setUploading(false);
          return `https://aiot-businessprotal.oss-cn-hangzhou.aliyuncs.com${result.name}`;
        } catch (err) {
          message.error('上传失败，请重新上传', 3);
          setUploading(false);
          return false;
        }
      }
    };

    const handleUpload = async (fileData) => {
      setFileList([
        {
          uid: '-1',
          name: fileData?.file?.name,
          status: 'uploading',
        },
      ]);
      try {
        const result: any = await getOSSData(fileData);
        if (result) {
          // const fileName = result.substring(result.lastIndexOf('/') + 1);
          const res = await authorize({ ossUrl: result });
          console.log(res);

          if (res?.data.authorizedUrl) {
            setFileList([
              {
                status: 'done',
                name: fileData?.file?.name,
                url: res?.data.authorizedUrl,
              },
            ]);
          } else {
            setUploading(false);
            message.warn('上传失败');
          }
        }
      } catch (e) {
        console.log(e);
      }
    };

    // 提交上传
    const handleOk = async () => {
      if (!fileList?.length) return message.error('请先上传文件');
      setConfirmLoading(true);
      const params = {
        distributePlanId: distributePlanId,
        fileUrl: fileList?.[0]?.url,
        fileName: fileList?.[0]?.name,
        rosterType,
      };
      const res = await rosterUploadFile(params);
      if (res.code === 0) {
        message.success('上传成功');
        onOk?.();
      }
      setConfirmLoading(false);
    };

    // 下载模版
    const download = async (type: number) => {
      const res = await rosterDownload({
        type,
      });
      if (res?.data) {
        handleDownload(res?.data, '上传数据模版');
      }
    };
    // 类型选择
    const onRadioChange = (key) => {
      setRosterType(key);
    };
    useEffect(() => {
      setFileList([]);
      setConfirmLoading(false);
    }, [open]);
    return (
      <Modal
        open={open}
        title="上传数据"
        width={'540px'}
        onOk={handleOk}
        onCancel={onCancel}
        confirmLoading={confirmLoading}
        getContainer={false}
        destroyOnClose={true}
      >
        <Form {...layout}>
          <Form.Item label="上传类型">
            <Radio.Group
              options={uploadTypeOptions}
              onChange={(e) => onRadioChange(e.target.value)}
              value={rosterType}
              optionType="button"
            />
          </Form.Item>
          <Form.Item
            label="文件"
            extra={
              <div>
                <div style={{ margin: '10px 5px 5px 0', fontSize: '14px' }}>
                  请上传CSV、xlsx文件，大小不超过100M
                </div>
                <Typography.Link
                  onClick={() => download(1)}
                  style={{ marginRight: '10px' }}
                >
                  下载CSV模版
                </Typography.Link>
                <Typography.Link onClick={() => download(2)}>
                  下载XLSX模版
                </Typography.Link>
              </div>
            }
          >
            <Upload
              maxCount={1}
              accept=".csv, .xlsx,"
              beforeUpload={beforeUpload}
              customRequest={(info) => handleUpload(info)}
              fileList={fileList}
              showUploadList={true}
              onRemove={() => setFileList([])}
              disabled={uploading}
            >
              {/* 上传文件 */}
              <Button icon={<CloudUploadOutlined />}>上传文件</Button>
            </Upload>
          </Form.Item>
        </Form>
      </Modal>
    );
  },
);

export default UploadModal;
