// 上传记录
import React, { useState, useEffect, useRef } from 'react';
import { Input, Select, Tooltip, Typography } from 'antd';
import ResizeTable from '@/components/ResizeTable';
import type { ColumnsType } from 'antd/es/table';
import {
  queryDistributeList,
  channelList,
  IDqueryDistributeParams,
} from '@/api/distributary';
import { toThousands } from '@/utils';
import { throttle } from 'lodash';
import styles from './index.less';

const { Search } = Input;

interface PropsType {
  planId: string;
}

const IssueRecord: React.FC<PropsType> = ({ planId }) => {
  const [dataSource, setDataSource] = useState([]);
  const [tableLoading, setTableLoading] = useState(false);
  const [total, setTotal] = useState(0);
  // 渠道列表
  const [channeldropDown, setChanneldropDown] = useState([]);
  // 搜索params
  const queryParams = useRef<IDqueryDistributeParams>({
    pageNum: 1,
    pageSize: 100,
  });
  /**
   * api
   */
  // table数据
  const getList = async (data: IDqueryDistributeParams) => {
    queryParams.current = { ...queryParams.current, ...data };
    try {
      setTableLoading(true);
      const res = await queryDistributeList(queryParams.current);
      setTotal(res.totalRecord || 0);
      setDataSource(res?.list || []);
      setTableLoading(false);
    } catch (error) {
      setTableLoading(false);
    }
  };
  // 获取渠道商列表
  async function getChannelList() {
    try {
      const data = await channelList();
      setChanneldropDown(data || []);
    } catch (e) {}
  }
  const onSearch = throttle((taskName) => {
    getList({ taskName, pageNum: 1 });
  }, 500);

  const columns: ColumnsType = [
    {
      title: 'ID',
      dataIndex: 'id',
      key: 'id',
      width: 200,
      render: (text) => {
        return (
          <Tooltip placement="topLeft" title={text}>
            <Typography.Paragraph className={styles.mb0} ellipsis={{ rows: 1 }}>
              {text}
            </Typography.Paragraph>
          </Tooltip>
        );
      },
    },
    {
      title: '渠道名称',
      dataIndex: 'channelName',
      key: 'channelName',
      width: 200,
      render: (text) => {
        return (
          <Tooltip placement="topLeft" title={text}>
            <Typography.Paragraph className={styles.mb0} ellipsis={{ rows: 1 }}>
              {text || '-'}
            </Typography.Paragraph>
          </Tooltip>
        );
      },
    },
    {
      title: '任务名称',
      dataIndex: 'taskName',
      key: 'taskName',
      width: 200,
      render: (text) => {
        return (
          <Tooltip placement="topLeft" title={text}>
            <Typography.Paragraph className={styles.mb0} ellipsis={{ rows: 1 }}>
              {text}
            </Typography.Paragraph>
          </Tooltip>
        );
      },
    },
    {
      title: '任务ID',
      dataIndex: 'taskId',
      key: 'taskId',
      width: 200,
      render: (text) => {
        return (
          <Tooltip placement="topLeft" title={text}>
            <Typography.Paragraph className={styles.mb0} ellipsis={{ rows: 1 }}>
              {text}
            </Typography.Paragraph>
          </Tooltip>
        );
      },
    },
    {
      title: '下发数量',
      dataIndex: 'distributeCount',
      key: 'distributeCount',
      width: 120,
      render: (text) => toThousands(text),
    },
    {
      title: '成功数量',
      dataIndex: 'successCount',
      key: 'successCount',
      width: 120,
      render: (text) => toThousands(text),
    },
    {
      title: '下发时间',
      dataIndex: 'distributeTime',
      key: 'distributeTime',
      width: 200,
    },
  ];
  // 分页change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum: pageSize === queryParams.current.pageSize ? pageNum : 1,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    getList(paginationObj);
  };
  useEffect(() => {
    if (planId) {
      getList({
        ...queryParams.current,
        distributePlanId: planId,
      });
    }
    getChannelList();
  }, [planId]);

  return (
    <div className={styles.issueRecord}>
      <div className={styles.searchBar}>
        <Select
          placeholder="渠道名称"
          allowClear
          showSearch
          optionFilterProp="channelName"
          options={channeldropDown}
          style={{ width: 200, marginRight: 16 }}
          getPopupContainer={(triggerNode) =>
            triggerNode.parentElement || document.body
          }
          fieldNames={{ label: 'channelName', value: 'channelId' }}
          onChange={(channelId) => getList({ channelId, pageNum: 1 })}
        ></Select>
        <Search
          allowClear
          placeholder="任务名称"
          onSearch={onSearch}
          enterButton
          style={{ width: 300 }}
        />
      </div>

      <ResizeTable
        columns={columns}
        dataSource={dataSource}
        loading={tableLoading}
        rowKey={'id'}
        scroll={{ x: '1240' }}
        pagination={{
          onChange: handlePageChange,
          current: queryParams?.current?.pageNum || 1,
          pageSize: queryParams?.current?.pageSize || 100,
          pageSizeOptions: [25, 50, 100],
          total,
        }}
      />
    </div>
  );
};

export default IssueRecord;
