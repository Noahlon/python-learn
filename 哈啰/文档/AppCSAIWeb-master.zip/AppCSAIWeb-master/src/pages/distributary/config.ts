import { toThousands } from '@/utils';
import { IIntentClassifyList } from '@/api/distributary';

// 渠道通话记录列表新增字段时需要更新版本号，
export const COLUMN_STATE_VERSION = '1.2.0'; // 版本号修改时需要十进制递增示例：1.0.0 -> 1.0.1
// 分流类型列表
export const typeList = [
  { label: '实时分流', value: 1 },
  { label: '离线分流', value: 2 },
];

export const distributeTypeList = [
  { label: '无需下发 ', value: 0 },
  { label: '未下发', value: 1 },
  { label: '下发中 ', value: 2 },
  { label: '下发完成', value: 3 },
  { label: '下发失败', value: 4 },
];

export const uploadOptions = [
  {
    label: '手动上传',
    value: 2,
  },
  {
    label: '接口上传',
    value: 1,
  },
];

// 处理意向分类数量方法
export const transformNum = (name: string, list: IIntentClassifyList[]) => {
  try {
    if (!list || (Array.isArray(list) && list.length === 0)) return '-';
    const dataItem = list.find((item) => item.code === name);
    return toThousands(dataItem?.value, true);
  } catch (error) {
    console.log(error, 'error');
  }
};
export const uploadTypeOptions = [
  {
    label: '明文',
    value: 1,
  },
  {
    label: '32位MD5',
    value: 2,
  },
];
// 挂断方
export const releaseInitiatorOption = [
  { label: '未知', value: 0 },
  { label: '呼叫方', value: 1 },
  { label: '被叫方', value: 2 },
];

// 是否触发短信，
export const hitSmsOption = [
  { label: '未触发', value: 0 },
  { label: '触发', value: 1 },
];

// 命中意图
export const intentListOption = [
  { label: '包含', value: 'hitIntentions' },
  { label: '不包含', value: 'excludeIntentions' },
];
// 通话类型
export const typeOption = [
  { label: 'AI外呼', value: 1 },
  { label: '人工坐席', value: 2 },
];

// 性别检测结果
export const genderOption = [
  { label: '男', value: 1 },
  { label: '女', value: 2 },
  { label: '未知', value: 3 },
];
