import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Table, Pagination, message } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { debounce } from 'lodash';
import moment from 'moment';
import { v1 as uuidv1 } from 'uuid';
import { formatType } from '@/config';
import {
  getSmsRecordList,
  ISmsRecordList,
  ISmsRecordListParams,
  smsRecordExport,
} from '@/api/distributary';
import { text1Tooltip } from '@/utils/format';
import MessageSearch from './components/MessageSearch';
import { DEFAULT_MESSAGE_PARAMS } from './config';
import styles from './index.less';

const SmsRecordList: React.FC = () => {
  const queryParams = useRef(DEFAULT_MESSAGE_PARAMS);
  const [tableData, setTableData] = useState<ISmsRecordList[]>([]);
  const [isLoading, setLoading] = useState(false);
  const [pageSize, setPageSize] = useState(100);
  const [tableHeight, setTableHeight] = useState<number | string>();
  const [total, setTotal] = useState(0);
  const [pageIndex, setPageIndex] = useState(1);
  const [isOverflow, setOverflow] = useState(false);
  // 导出
  const [exportLoading, setExportLoading] = useState(false);
  // 获取高度
  const messageWrapRef = useRef<HTMLInputElement>(null);
  const messageSearchWrapRef = useRef<HTMLInputElement>(null);
  const messagePaginationWrapRef = useRef<HTMLInputElement>(null);
  const formatApiParams = (paramsObj) => {
    // 创建时间
    if (
      Array.isArray(paramsObj?.createTime) &&
      paramsObj?.createTime?.length === 2
    ) {
      paramsObj.createBeginTime = moment(paramsObj.createTime[0]).format(
        formatType,
      );
      paramsObj.createEndTime = moment(paramsObj.createTime[1]).format(
        formatType,
      );
    }
    // 发送时间
    if (
      Array.isArray(paramsObj?.sendTime) &&
      paramsObj?.sendTime?.length === 2
    ) {
      paramsObj.sendBeginTime = moment(paramsObj.sendTime[0]).format(
        formatType,
      );
      paramsObj.sendEndTime = moment(paramsObj.sendTime[1]).format(formatType);
    }
    // 收到回执时间
    if (
      Array.isArray(paramsObj?.receiveResultTime) &&
      paramsObj?.receiveResultTime?.length === 2
    ) {
      paramsObj.receiveResultBeginTime = moment(
        paramsObj.receiveResultTime[0],
      ).format(formatType);
      paramsObj.receiveResultEndTime = moment(
        paramsObj.receiveResultTime[1],
      ).format(formatType);
    }
    delete paramsObj.createTime;
    delete paramsObj.sendTime;
    delete paramsObj.receiveResultTime;
    // 城市
    if (paramsObj?.cityList?.length) {
      paramsObj.cityList = paramsObj.cityList.map((item) => item[1]);
    }
    return paramsObj;
  };

  // fetch列表数据
  const fetchList = useCallback(
    async (params: ISmsRecordListParams) => {
      setLoading(true);
      try {
        const paramsObj: ISmsRecordListParams = formatApiParams({
          pageNum: params.pageNum || pageIndex,
          pageSize: params.pageSize || pageSize,
          ...queryParams.current,
        });
        const res = await getSmsRecordList(paramsObj);
        if (res?.code === 0) {
          setTableData(res.data?.list || []);
          setTotal(Number(res.data?.totalRecord) || 0);
        } else {
          setTableData([]);
        }
        setLoading(false);
      } catch (error) {
        setLoading(false);
      }
    },
    [pageSize, pageIndex],
  );
  // 导出
  const handleExport = async () => {
    try {
      const params = formatApiParams(queryParams.current);
      setExportLoading(true);
      const res = await smsRecordExport(params);
      if (res?.code === 0) {
        message.success('导出成功，请前往【文件导出管理】页面进行下载');
      }
      setExportLoading(false);
    } catch (error) {}
  };

  const column: ColumnsType<ISmsRecordList> = [
    {
      title: '渠道商名称',
      dataIndex: 'channelName',
      key: 'channelName',
      width: 160,
      fixed: 'left',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '客户数据标识',
      width: 180,
      dataIndex: 'externalId',
      key: 'externalId',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '平台数据标识',
      width: 180,
      dataIndex: 'platformId',
      key: 'platformId',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '被叫号码',
      width: 150,
      dataIndex: 'phoneNumber',
      key: 'phoneNumber',
      render: (text) => {
        return text || '-';
      },
    },
    {
      title: 'MD5',
      width: 180,
      dataIndex: 'phoneNumberMd5',
      key: 'phoneNumberMd5',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '分流计划名称',
      width: 240,
      dataIndex: 'distributePlanName',
      key: 'distributePlanName',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '分流计划ID',
      width: 200,
      dataIndex: 'distributePlanId',
      key: 'distributePlanId',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '任务ID',
      width: 200,
      dataIndex: 'supplierTaskId',
      key: 'supplierTaskId',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '任务名称',
      width: 240,
      dataIndex: 'supplierTaskName',
      key: 'supplierTaskName',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '话术名称',
      dataIndex: 'speechName',
      width: 200,
      key: 'speechName',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '企业ID',
      dataIndex: 'enterpriseId',
      width: 180,
      key: 'enterpriseId',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '租户code',
      dataIndex: 'tenantCode',
      width: 180,
      key: 'tenantCode',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '发送结果',
      dataIndex: 'sendResultDesc',
      key: 'sendResultDesc',
      width: 120,
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '短信签名',
      dataIndex: 'signature',
      width: 160,
      key: 'signature',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '短信内容',
      dataIndex: 'content',
      key: 'content',
      width: 200,
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      width: 180,
      key: 'createTime',
    },
    {
      title: '短信发送时间',
      dataIndex: 'sendTime',
      width: 180,
      key: 'sendTime',
      render: (text) => {
        return text || '-';
      },
    },
    {
      title: '回执返回时间',
      dataIndex: 'receiveResultTime',
      width: 180,
      key: 'receiveResultTime',
      render: (text) => {
        return text || '-';
      },
    },
    {
      title: '座席姓名',
      dataIndex: 'seatsName',
      width: 160,
      key: 'seatsName',
      render: (text) => {
        return text || '-';
      },
    },
    {
      title: '计费条数',
      dataIndex: 'billingNum',
      width: 140,
      key: 'billingNum',
    },
    {
      title: '客户姓名',
      dataIndex: 'customName',
      width: 140,
      key: 'customName',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '通话唯一ID',
      dataIndex: 'callGuid',
      width: 200,
      key: 'callGuid',
      render: (text) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '号码归属地',
      dataIndex: 'province',
      width: 180,
      key: 'province',
      render: (text: string, record: ISmsRecordList) => {
        if (text && record.city) {
          return text1Tooltip(`${text}/${record.city}`);
        } else if (text) {
          return text1Tooltip(text);
        } else if (record.city) {
          return text1Tooltip(record.city);
        }
        return '-';
      },
    },
    {
      title: '运营商',
      dataIndex: 'carrier',
      width: 120,
      key: 'carrier',
      render: (text: number) => {
        switch (text) {
          //  1-中国移动 2-中国联通 3-中国电信 4-虚拟 5-未知
          case 1:
            return '中国移动';
          case 2:
            return '中国联通';
          case 3:
            return '中国电信';
          case 4:
            return '虚拟';
          case 5:
            return '未知';
          default:
            return '-';
        }
      },
    },
  ];

  // 获取高度变化
  const handleHeightEvent = debounce(async () => {
    try {
      const _wrapHeight = messageWrapRef?.current?.clientHeight || 700;
      const _searchHeight = messageSearchWrapRef?.current?.clientHeight || 67;
      const paginationHeight =
        messagePaginationWrapRef?.current?.clientHeight || 52;
      const _height = _wrapHeight - _searchHeight - paginationHeight - 55;
      setTableHeight(_height < 301 ? 500 : _height);
      if (_height < 301) {
        setOverflow(true);
      } else {
        setOverflow(false);
      }
    } catch (e) {}
  }, 200);

  // 分页
  const onChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      const params = { pageSize: size, pageNum: 1 };
      if (size !== pageSize) {
        setPageIndex(1);
        setPageSize(size);
      } else {
        setPageIndex(page);
        params.pageNum = page;
      }
      fetchList(params);
    },
    [pageSize],
  );

  // 请求第一页数据
  const fetchListOfPageOne = (data?: ISmsRecordListParams) => {
    setPageIndex(1);
    queryParams.current = !!data ? data : DEFAULT_MESSAGE_PARAMS;
    fetchList({ pageNum: 1 });
  };

  // 搜索
  const handleSearch = useCallback(
    (data: ISmsRecordListParams) => fetchListOfPageOne(data),
    [pageSize, pageIndex],
  );

  // 重置
  const handleReset = useCallback(fetchListOfPageOne, [pageSize, pageIndex]);

  useEffect(() => {
    fetchListOfPageOne();
    handleHeightEvent();
    window.addEventListener('resize', handleHeightEvent);
    return () => window.removeEventListener('resize', handleHeightEvent);
  }, []);

  return (
    <>
      <div className={styles.messageWrapper} ref={messageWrapRef}>
        <div className={styles.search} ref={messageSearchWrapRef}>
          <MessageSearch
            onSearch={handleSearch}
            onReset={handleReset}
            onOpen={useCallback(handleHeightEvent, [])}
            onExport={handleExport}
            exportLoading={exportLoading}
          />
        </div>
        <div
          className={
            isOverflow
              ? styles.tableContent
              : `${styles.tableContent} ${styles.hidden}`
          }
        >
          <Table
            columns={column}
            dataSource={tableData}
            loading={isLoading}
            rowKey={() => uuidv1()}
            scroll={{ y: tableHeight, x: 2000 }}
            pagination={false}
          />
        </div>
        <div className={styles.subPagination} ref={messagePaginationWrapRef}>
          <Pagination
            current={pageIndex}
            showSizeChanger={true}
            pageSize={pageSize}
            total={total}
            showTotal={(total) => `总共 ${total} 条`}
            onChange={onChange}
            pageSizeOptions={[25, 50, 100]}
          />
        </div>
      </div>
    </>
  );
};
export default SmsRecordList;
