import React, { memo, useCallback, useEffect, useState } from 'react';
import {
  Form,
  Input,
  Cascader,
  Select,
  Button,
  Row,
  Col,
  DatePicker,
  Space,
} from 'antd';
import { timeRanges } from '@/config';
import { getProvinceCityList } from '@/api/common';
import moment from 'moment';
import { getEnumListByType } from '@/api/common';
import { ISmsRecordListParams } from '@/api/messageList';
import { channelList } from '@/api/distributary';
import { DownloadOutlined } from '@ant-design/icons';
import { useAccess } from '@umijs/max';
import { supportCarrierOpts } from '@/pages/lineSupplier/config';
import styles from '../../index.less';

const { RangePicker } = DatePicker;
const { SHOW_CHILD } = Cascader;

interface IProps {
  onSearch?: (data: ISmsRecordListParams) => void;
  onReset?: () => void;
  onOpen?: () => void;
  exportLoading: boolean;
  onExport: (data) => void;
}

const colLayout = { xl: 8, sm: 12, xs: 24 };

const MessageSearch: React.FC<IProps> = ({
  onSearch,
  onReset,
  onOpen,
  onExport,
  exportLoading,
}) => {
  const access = useAccess();
  const [form] = Form.useForm();
  const [openForm, setFormOpen] = useState(false); //展和收起
  const [cityOpts, setCityOpts] = useState([]); // 城市options
  const [sendOpts, setSendOpts] = useState([]); // 发送结果options
  // 渠道列表
  const [channeldropDown, setChanneldropDown] = useState([]);
  // fetch省市数据(本地)
  const fetchCityOpt = useCallback(async () => {
    const opt = [];
    // todo 异步获取行政区数据
    const DISTRICTS: any = await getProvinceCityList();
    DISTRICTS.forEach((item) => {
      if (item['level'] === 1) {
        const citys = [];
        DISTRICTS.forEach((i) => {
          if (item.area_code === i.parent_code)
            citys.push({ value: i.area_name, label: i.area_name });
        });
        opt.push({
          value: item.area_code,
          label: item.area_name,
          children: citys,
        });
      }
    });
    setCityOpts(opt || []);
  }, []);
  // 获取渠道商列表
  const getChannelList = async () => {
    try {
      const data = await channelList();
      setChanneldropDown(data || []);
    } catch (e) {}
  };

  // fetch枚举列表数据
  const fetchEnumList = async () => {
    // 1-提交结果 2-发送结果 3-路由结果 4-触发类型  6-短信来源 7-任务类型
    const params = {
      typeList: [2],
    };
    const res = await getEnumListByType(params);
    if (res?.data?.length) {
      res.data.forEach((item) => {
        if (item?.type === 2) {
          setSendOpts(item.enumConstantDTOList || []);
        }
      });
    }
  };

  // 重置
  const handleReset = () => {
    form.resetFields();
    form.setFieldValue('createTime', [
      moment().startOf('day'),
      moment().endOf('day'),
    ]);
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    onSearch?.(res);
  };

  useEffect(() => {
    fetchCityOpt();
    fetchEnumList();
    getChannelList();
  }, []);
  return (
    <Form
      form={form}
      initialValues={{
        createTime: [moment().startOf('day'), moment().endOf('day')],
      }}
    >
      <Row wrap={false}>
        <Col
          flex="auto"
          className={styles.leftSearch + ' ' + (openForm ? '' : styles.isHide)}
        >
          <Row gutter={16}>
            <Col {...colLayout}>
              <Form.Item name="channelId">
                <Select
                  placeholder="请选择渠道商名称"
                  showSearch
                  allowClear
                  options={channeldropDown}
                  optionFilterProp="channelName"
                  // getPopupContainer={(triggerNode) =>
                  //   triggerNode.parentElement || document.body
                  // }
                  fieldNames={{ label: 'channelName', value: 'channelId' }}
                ></Select>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="platformId">
                <Input placeholder="请输入平台数据标识" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="phoneNumber">
                <Input placeholder="请输入被叫号码" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="phoneNumberMd5">
                <Input placeholder="请输入32位MD5" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="distributePlanName">
                <Input placeholder="请输入分流计划名称" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="distributePlanId">
                <Input placeholder="请输入分流计划ID" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="supplierTaskId">
                <Input placeholder="请输入任务ID" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="supplierTaskName">
                <Input placeholder="请输入任务名称" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="sendResultList">
                <Select
                  placeholder="请选择发送结果"
                  allowClear
                  mode="multiple"
                  maxTagCount="responsive"
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                >
                  {sendOpts.map((item) => (
                    <Select.Option key={item.code} value={item.code}>
                      {item.value}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="signature">
                <Input placeholder="请输入短信签名" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="content">
                <Input placeholder="请输入短信内容" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="createTime">
                <RangePicker
                  style={{ width: '100%' }}
                  placeholder={['创建开始', '创建结束']}
                  showTime
                  ranges={timeRanges}
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  allowClear={false}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="sendTime">
                <RangePicker
                  style={{ width: '100%' }}
                  placeholder={['短信发送时间开始', '短信发送时间结束']}
                  showTime
                  ranges={timeRanges}
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  allowClear={true}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="receiveResultTime">
                <RangePicker
                  style={{ width: '100%' }}
                  placeholder={['回执返回时间开始', '回执返回时间结束']}
                  showTime
                  ranges={timeRanges}
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  allowClear={true}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="seatsName">
                <Input placeholder="请输入座席姓名" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="callGuid">
                <Input placeholder="请输入通话唯一ID " allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="cityList">
                <Cascader
                  showSearch
                  options={cityOpts}
                  placeholder="请选择号码归属地"
                  multiple
                  maxTagCount="responsive"
                  showCheckedStrategy={SHOW_CHILD}
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                />
              </Form.Item>
            </Col>

            <Col {...colLayout}>
              <Form.Item name="carrierList">
                <Select
                  placeholder="请选择运营商"
                  allowClear
                  mode="multiple"
                  maxTagCount="responsive"
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                >
                  {supportCarrierOpts.map((item) => (
                    <Select.Option key={item.value} value={item.value}>
                      {item.label}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none">
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            {access?.authCodeList?.includes(
              'Distributary-Manage-textMessage-export',
            ) && (
              <Button
                icon={<DownloadOutlined />}
                onClick={onExport}
                loading={exportLoading}
              >
                导出
              </Button>
            )}
            <Button onClick={handleReset}>重置</Button>
            <Button
              type="link"
              size="small"
              onClick={() => {
                setFormOpen(!openForm);
                onOpen?.();
              }}
            >
              {openForm ? '收起' : '展开'}
            </Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default memo(MessageSearch);
