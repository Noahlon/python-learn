import moment from 'moment';

export const DEFAULT_MESSAGE_PARAMS: Partial<any> = {
  createTime: [
    moment().startOf('day').format('YYYY-MM-DD HH:mm:ss'),
    moment().endOf('day').format('YYYY-MM-DD HH:mm:ss'),
  ],
};
