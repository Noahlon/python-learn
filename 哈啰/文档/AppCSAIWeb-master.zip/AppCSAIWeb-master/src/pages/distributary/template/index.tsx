import React, { useEffect, useState, useRef } from 'react';
import ResizeTable from '@/components/ResizeTable';
import { useAccess } from '@umijs/max';
import {
  Form,
  Row,
  Col,
  Input,
  Select,
  message,
  Space,
  Button,
  Tooltip,
  Typography,
  Popconfirm,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { tenantList } from '@/api/tenantManage';
import EditModal from '../plan/components/editModal';
import { throttle } from 'lodash';
import { typeList } from '../config';
import {
  templateDelete,
  templateList,
  channelList,
  IDtemplateListColumn,
  IDtemplateParams,
  IDtemplateListResponse,
  templateCopy,
  IStemplateCopyRes,
} from '@/api/distributary';
import styles from './index.less';

const TemplatePage: React.FC = () => {
  const [tenant, setTenant] = useState([]);
  const access = useAccess();
  const [form] = Form.useForm();
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [editOpen, setEditOpen] = useState(false); //编辑/创建弹窗
  const [details, setDetail] = useState<IDtemplateListColumn>({}); //模版详情
  // 渠道列表
  const [channeldropDown, setChanneldropDown] = useState([]);
  // 搜索params
  const queryParams = useRef<IDtemplateParams>({ pageNum: 1, pageSize: 100 });
  const layout = {
    labelCol: { span: 1 },
    wrapperCol: { span: 23 },
  };

  // 获取列表数据
  const getList = async (data: IDtemplateParams) => {
    try {
      queryParams.current = { ...queryParams.current, ...data };
      setLoading(true);
      const res: IDtemplateListResponse = await templateList(
        queryParams.current,
      );
      if (res?.code === 0) {
        setTotal(res?.data?.totalRecord || 0);
        setData(res?.data?.list || []);
      }
      setLoading(false);
    } catch (e) {
      setLoading(false);
    }
  };
  // 获取渠道商列表
  const getChannelList = async () => {
    try {
      const data = await channelList();
      setChanneldropDown(data || []);
    } catch (e) {}
  };
  // 获取租户下拉列表
  const getTenantList = async () => {
    try {
      const { data } = await tenantList({
        pageNum: 1,
        pageSize: 999,
      });
      setTenant(data || []);
    } catch (error) {}
  };
  //删除模板
  const handleDelete = throttle(async (record) => {
    try {
      await templateDelete({ templateId: record.templateId });
      message.success('删除成功');
      getList({ pageNum: 1 });
    } catch (error) {}
  }, 500);

  //编辑模版
  const handleEdit = (record) => {
    setEditOpen(true);
    setDetail(record);
  };

  //创建模版
  const handleCreate = () => {
    setEditOpen(true);
    setDetail({});
  };

  // 复制模版
  const handleCopy = async (templateId: string) => {
    try {
      const res: IStemplateCopyRes = await templateCopy({ templateId });
      if (res.code === 0) {
        setDetail(res?.data || {});
        setEditOpen(true);
      }
    } catch (error) {}
  };

  const column: ColumnsType<IDtemplateListColumn> = [
    {
      title: '模版ID',
      dataIndex: 'templateId',
      key: 'templateId',
    },
    {
      title: '模版名称',
      dataIndex: 'templateName',
      key: 'templateName',
      width: 200,
      render: (text) => {
        return (
          <Tooltip placement="topLeft" title={text}>
            <Typography.Paragraph className={styles.mb0} ellipsis={{ rows: 2 }}>
              {text}
            </Typography.Paragraph>
          </Tooltip>
        );
      },
    },
    {
      title: '租户',
      dataIndex: 'tenantName',
      key: 'tenantName',
      width: 200,
      render: (text) => {
        return (
          <Tooltip placement="topLeft" title={text}>
            <Typography.Paragraph
              className={styles.mbText0}
              ellipsis={{ rows: 1 }}
            >
              {text}
            </Typography.Paragraph>
          </Tooltip>
        );
      },
    },
    {
      title: '类型',
      dataIndex: 'distributeType',
      key: 'distributeType',
      width: 100,
      render(text) {
        return text === 1 ? '实时分流' : '离线分流';
      },
    },
    {
      title: '分流规则',
      dataIndex: 'distributeRuleList',
      key: 'distributeRuleList',
      width: 300,
      render: (text) => {
        return (
          <Tooltip
            placement="topLeft"
            overlayClassName={styles.tooltipBox}
            title={
              <>
                {text?.length > 0 &&
                  text.map((item, index) => {
                    return (
                      <div key={index}>
                        {item.channelName}：
                        {(item.percentage && `${item.percentage}%`) || '0.00%'}
                        &nbsp;|&nbsp;
                        {item.taskTemplateName};
                      </div>
                    );
                  })}
              </>
            }
          >
            <Typography.Paragraph className={styles.mb0} ellipsis={{ rows: 2 }}>
              {text?.length > 0 &&
                text.map((item, index) => {
                  return (
                    <div key={index}>
                      {item.channelName}：
                      {(item.percentage && `${item.percentage}%`) || '0.00%'}
                      &nbsp;|&nbsp;
                      {item.taskTemplateName}
                    </div>
                  );
                })}
            </Typography.Paragraph>
          </Tooltip>
        );
      },
    },
    {
      title: '最近使用',
      dataIndex: 'latestUseTime',
      key: 'latestUseTime',
      sorter: true,
      sortDirections: ['descend', 'ascend'],
      width: 200,
      render(text) {
        return text ? text : '-';
      },
    },
    {
      title: '创建人',
      dataIndex: 'creator',
      key: 'creator',
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      key: 'createTime',
      sorter: true,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '操作',
      dataIndex: 'action',
      fixed: 'right',
      width: 140,
      render: (_, record) => (
        <Space>
          {access?.authCodeList?.includes(
            'Distributary-Manage-template-copy',
          ) && (
            <Typography.Link
              onClick={() => {
                handleCopy(record.templateId);
              }}
            >
              复制
            </Typography.Link>
          )}
          {access?.authCodeList?.includes(
            'Distributary-Manage-template-edit',
          ) && (
            <Typography.Link
              onClick={() => {
                handleEdit(record);
              }}
            >
              编辑
            </Typography.Link>
          )}
          {access?.authCodeList?.includes(
            'Distributary-Manage-template-delete',
          ) && (
            <Popconfirm
              title="是否确认删除该计划模版？"
              onConfirm={() => handleDelete(record)}
            >
              <Typography.Link>删除</Typography.Link>
            </Popconfirm>
          )}
        </Space>
      ),
    },
  ];

  // 搜索
  const handleSearch = throttle((values) => {
    const args = {
      ...values,
      templateName: values?.templateName?.trim() || undefined,
      templateId: values?.templateId?.trim() || undefined,
      pageNum: 1,
    };
    getList(args);
  }, 500);
  // 重置
  const handleReset = throttle(() => {
    form.resetFields();
    const values = form.getFieldsValue();
    queryParams.current = {};
    const args = {
      ...values,
      pageNum: 1,
      pageSize: 100,
    };
    getList(args);
  }, 500);
  const handleTableChange = (pagination, _, sorter) => {
    if (!!sorter?.order) {
      queryParams.current.sortColumn =
        sorter?.field === 'createTime' ? 'createTime' : 'latestUsingTime';
      queryParams.current.sortType =
        sorter?.order === 'ascend' ? 'asc' : 'desc';
    } else {
      queryParams.current.sortColumn = undefined;
      queryParams.current.sortType = undefined;
    }
    const paginationObj = {
      pageNum:
        pagination.pageSize === queryParams.current.pageSize
          ? pagination.current
          : 1,
      pageSize: pagination.pageSize ?? queryParams.current.pageSize,
    };
    getList({ ...paginationObj });
  };
  const modalOk = () => {
    setEditOpen(false);
    if (details?.templateId) {
      getList({});
    } else {
      getList({ pageNum: 1 });
    }
  };
  useEffect(() => {
    getTenantList();
    getChannelList();
    getList({});
  }, []);
  return (
    <>
      <div className={styles['distributary-template-list']}>
        <Form
          className={styles.search}
          form={form}
          {...layout}
          onFinish={handleSearch}
        >
          <Row wrap={false}>
            <Col flex="auto">
              <div className={styles.formItem}>
                <Form.Item name="templateName">
                  <Input placeholder="模板名称" allowClear />
                </Form.Item>
              </div>
              <div className={styles.formItem}>
                <Form.Item name="templateId">
                  <Input placeholder="模板ID" allowClear />
                </Form.Item>
              </div>
              <div className={styles.formItem}>
                <Form.Item name="tenantCodeList">
                  <Select
                    placeholder="租户"
                    showSearch
                    maxTagCount="responsive"
                    getPopupContainer={(triggerNode) =>
                      triggerNode.parentElement || document.body
                    }
                    mode="multiple"
                    allowClear
                    optionFilterProp="name"
                    options={tenant}
                    fieldNames={{ label: 'name', value: 'code' }}
                  ></Select>
                </Form.Item>
              </div>
              <div className={styles.formItem}>
                <Form.Item name="channelId">
                  <Select
                    placeholder="渠道名称"
                    showSearch
                    allowClear
                    options={channeldropDown}
                    optionFilterProp="channelName"
                    getPopupContainer={(triggerNode) =>
                      triggerNode.parentElement || document.body
                    }
                    fieldNames={{ label: 'channelName', value: 'channelId' }}
                  ></Select>
                </Form.Item>
              </div>
              <div className={styles.formItem}>
                <Form.Item name="distributeType">
                  <Select
                    placeholder="类型"
                    allowClear
                    options={typeList}
                    getPopupContainer={(triggerNode) =>
                      triggerNode.parentElement || document.body
                    }
                  ></Select>
                </Form.Item>
              </div>
            </Col>
            <Col flex="none" className={styles.searchBox}>
              <Space className={styles.searchBoxSpace}>
                <Button type="primary" htmlType="submit">
                  搜索
                </Button>
                <Button onClick={handleReset}>重置</Button>
              </Space>
            </Col>
          </Row>
        </Form>
        {access?.authCodeList?.includes(
          'Distributary-Manage-template-create',
        ) && (
          <div className={styles.addButton}>
            <Button type="primary" onClick={handleCreate}>
              创建
            </Button>
          </div>
        )}
        <ResizeTable
          columns={column}
          dataSource={data}
          loading={loading}
          rowKey={'templateId'}
          scroll={{ x: 1800 }}
          pagination={{
            // onChange: handlePageChange,
            current: queryParams.current.pageNum,
            pageSize: queryParams.current.pageSize,
            pageSizeOptions: [25, 50, 100],
            total,
          }}
          onChange={handleTableChange}
        />
      </div>
      {editOpen && (
        <EditModal
          open={editOpen}
          onOk={modalOk}
          onCancel={() => setEditOpen(false)}
          details={details}
          modalType={1}
        />
      )}
    </>
  );
};
export default TemplatePage;
