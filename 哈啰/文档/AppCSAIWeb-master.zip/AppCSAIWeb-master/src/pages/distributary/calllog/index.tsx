import React, {
  FC,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { Space, Typography, Pagination, message, Popover } from 'antd';
import { debounce } from 'lodash';
import moment from 'moment';
import { v1 as uuidv1 } from 'uuid';

import {
  dialogueExport,
  dialogueList,
  IDdialogueListItem,
  IDdialogueListParams,
} from '@/api/distributary';
import { text1Tooltip } from '@/utils/format';
import { ProTable, ProColumns } from '@ant-design/pro-components';
import PlayAudio from '@/components/PlayAudio';
import CallDetail from './components/CallDetail';
import CallSearch from './components/CallSearch';
import { COLUMN_STATE_VERSION } from '../config';

import { VList } from 'virtuallist-antd';
import styles from './index.less';

const labelWrapStyle = {
  width: '100%',
  overflow: 'hidden',
};

const labelTableWrapStyle = {
  ...labelWrapStyle,
  display: 'flex',
};

const labelItemStyle = {
  padding: '3px 10px',
  color: '#999',
  background: 'rgba(214, 214, 215, 0.6)',
  fontSize: '12px',
  borderRadius: '3px',
  margin: '2px 5px 2px 0',
  display: 'inline-block',
};

const labelTableItemStyle = {
  ...labelItemStyle,
  flexShrink: 0,
};

const formatType = 'YYYY-MM-DD HH:mm:ss';

const DEFAULT_CALL_PARAMS = {
  createTime: [
    moment(moment('00:00:00', 'HH:mm:ss')).format(formatType),
    moment(moment('23:59:59', 'HH:mm:ss')).format(formatType),
  ],
};

const CallList: FC = () => {
  const queryParams = useRef(DEFAULT_CALL_PARAMS);
  const [tableData, setTableData] = useState<IDdialogueListItem[]>([]);
  const [isLoading, setLoading] = useState(false);
  const [pageSize, setPageSize] = useState(100);
  const [tableHeight, setTableHeight] = useState<number>();
  const [total, setTotal] = useState(0);
  const [pageIndex, setPageIndex] = useState(1);
  // 导出
  const [exportLoading, setExportLoading] = useState(false);
  // 播放
  const [showPlayModel, setShowPlayModel] = useState(false);
  // 文本
  const [showTextModel, setShowTextModel] = useState(false);
  const [curInfo, setCurInfo] = useState<IDdialogueListItem | undefined>(
    undefined,
  );
  const [curTextInfo, setCurTextInfo] = useState<
    IDdialogueListItem | undefined
  >(undefined);
  const [isOverflow, setOverflow] = useState(false);
  // 获取高度
  const callWrapRef = useRef<HTMLInputElement>(null);
  const callSearchWrapRef = useRef<HTMLInputElement>(null);
  const callPaginationWrapRef = useRef<HTMLInputElement>(null);
  // 播放
  const handlerGetDetail = useCallback((info: IDdialogueListItem) => {
    setCurInfo(info);
    setShowPlayModel(true);
  }, []);

  // 查看文本
  const handlerShowText = useCallback((info: IDdialogueListItem) => {
    setCurTextInfo(info);
    setShowTextModel(true);
  }, []);

  const formatApiParams = (param) => {
    // 创建时间
    if (Array.isArray(param.createTime) && param.createTime.length) {
      param.createTimeStart = moment(param.createTime[0]).format(formatType);
      param.createTimeEnd = moment(param.createTime[1]).format(formatType);
    }
    // 拨号时间
    if (Array.isArray(param.dialTime) && param.dialTime.length) {
      param.dialTimeStart = moment(param.dialTime[0]).format(formatType);
      param.dialTimeEnd = moment(param.dialTime[1]).format(formatType);
    }
    // 挂断时间
    if (Array.isArray(param.hangupTime) && param.hangupTime.length) {
      param.hangupTimeStart = moment(param.hangupTime[0]).format(formatType);
      param.hangupTimeEnd = moment(param.hangupTime[1]).format(formatType);
    }
    if (Array.isArray(param.citys) && param.citys.length) {
      const _citys = [];
      param.citys.forEach((item) => {
        if (Array.isArray(item) && item.length) {
          _citys.push(item[item.length - 1]);
        }
      });
      param.citys = _citys;
    }
    // 命中意图包含/不包含
    if (param.intentListData) {
      param[param.intentListType] = param.intentListData;
      delete param.intentListData;
    }
    delete param.createTime;
    delete param.hangupTime;
    delete param.dialTime;
    delete param.intentListType;
    return param;
  };

  const handlerGetLists = useCallback(
    async (params) => {
      setLoading(true);
      try {
        const param: IDdialogueListParams = formatApiParams({
          pageNum: params.pageNum || pageIndex,
          pageSize: params.pageSize || pageSize,
          ...queryParams.current,
        });
        const callListRes = await dialogueList(param);
        if (callListRes?.code === 0) {
          setTableData(callListRes.data?.list as IDdialogueListItem[]);
          setTotal(Number(callListRes.data?.totalRecord) || 0);
        } else {
          setTableData([]);
        }
        setLoading(false);
      } catch (error) {
        setLoading(false);
      }
    },
    [pageSize, pageIndex],
  );
  const column: ProColumns<IDdialogueListItem>[] = [
    {
      title: '渠道商名称',
      dataIndex: 'channelName',
      width: 120,
      key: 'channelName',
      fixed: 'left',
      renderText: (text: string) => {
        return text1Tooltip(text);
      },
    },
    {
      title: '分流计划名称',
      dataIndex: 'distributePlanName',
      width: 150,
      key: 'distributePlanName',
      fixed: 'left',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '分流计划ID',
      dataIndex: 'distributePlanId',
      width: 150,
      key: 'distributePlanId',
      fixed: 'left',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '被叫号码',
      dataIndex: 'calledNumber',
      key: 'calledNumber',
      width: 150,
      fixed: 'left',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '挂断时间',
      dataIndex: 'hangupTime',
      width: 180,
      key: 'hangupTime',
      fixed: 'left'
    },
   
    {
      title: '客户数据标识',
      dataIndex: 'externalId',
      width: 180,
      key: 'externalId',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '平台数据标识',
      dataIndex: 'platformId',
      width: 180,
      key: 'platformId',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: 'MD5',
      dataIndex: 'md5',
      width: 180,
      key: 'md5',
      renderText: (text: string) => text1Tooltip(text),
    },
   
   
    {
      title: '任务ID',
      dataIndex: 'supplierTaskId',
      width: 240,
      key: 'supplierTaskId',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '任务名称',
      dataIndex: 'supplierTaskName',
      width: 200,
      key: 'supplierTaskName',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '话术模板ID',
      dataIndex: 'speechTemplateId',
      width: 160,
      key: 'speechTemplateId',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '企业ID',
      dataIndex: 'enterpriseId',
      width: 160,
      key: 'enterpriseId',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '租户code',
      dataIndex: 'tenantId',
      width: 200,
      key: 'tenantId',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '租户名称',
      dataIndex: 'tenantName', // todo 联调确认字段
      width: 200,
      key: 'tenantName',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '呼叫结果',
      dataIndex: 'callResultDesc',
      key: 'callResultDesc',
      width: 140,
    },
    {
      title: '意向分类Code',
      dataIndex: 'intentClassify',
      key: 'intentClassify',
      width: 120,
      renderText: (text: string) => {
        return text || '-';
      },
    },
    {
      title: '意向分类名称',
      dataIndex: 'intentClassifyName',
      key: 'intentClassifyName',
      width: 140,
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '命中意图',
      dataIndex: 'hitIntentions',
      key: 'hitIntentions',
      width: 200,
      renderText: (text: string) => {
        try {
          if (text && Array.isArray(text) && text?.length) {
            const getContent = (type?: string) => (
              <div
                style={type === 'table' ? labelTableWrapStyle : labelWrapStyle}
              >
                {text.map((item) => (
                  <span
                    key={`${uuidv1()}${item}`}
                    style={
                      type === 'table' ? labelTableItemStyle : labelItemStyle
                    }
                  >
                    {item}
                  </span>
                ))}
              </div>
            );
            return (
              <Popover
                content={getContent()}
                trigger="hover"
                placement="topLeft"
                overlayStyle={{ maxWidth: '500px' }}
                // getPopupContainer={(triggerNode) =>
                //   triggerNode.parentElement || document.body
                // }
              >
                {getContent('table')}
              </Popover>
            );
          } else {
            return '-';
          }
        } catch (error) {}
      },
    },
    {
      title: '触发短信',
      dataIndex: 'isHitSms',
      width: 100,
      key: 'isHitSms',
      renderText: (text: number) => {
        switch (text) {
          //  0-未触发 1-触发
          case 0:
            return '未触发';
          case 1:
            return '触发';
          default:
            return '-';
        }
      },
    },
    {
      title: '坐席姓名',
      dataIndex: 'seatName',
      width: 120,
      key: 'seatName',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: 'AI通话时长',
      dataIndex: 'durationCallAi',
      width: 120,
      key: 'durationCallAi',
    },
    {
      title: '人工通话时长',
      dataIndex: 'durationCallManual',
      width: 120,
      key: 'durationCallManual',
    },
    {
      title: '中继外显号',
      dataIndex: 'realCallingNumber',
      width: 140,
      key: 'realCallingNumber',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '通话时长',
      dataIndex: 'totalTime',
      width: 120,
      key: 'totalTime',
    },
    {
      title: '振铃时长',
      dataIndex: 'ringTime',
      width: 120,
      key: 'ringTime',
    },
    {
      title: '拨号时间',
      dataIndex: 'dialTime',
      width: 180,
      key: 'dialTime',
    },
   
    {
      title: '通话类型',
      dataIndex: 'callType',
      width: 100,
      key: 'callType',
      renderText: (text: number) =>
        (!text && '-') || (text === 1 ? 'AI外呼' : '人工座席'),
    },
    {
      title: '主叫号码',
      dataIndex: 'callingNumber',
      width: 140,
      key: 'callingNumber',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '计费单元数',
      dataIndex: 'costUnit',
      width: 120,
      key: 'costUnit',
      renderText: (text: number) => text ?? '-',
    },
    {
      title: '客户姓名',
      dataIndex: 'customName',
      width: 150,
      key: 'customName',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '通话唯一ID',
      dataIndex: 'dialogueGuid',
      width: 180,
      key: 'dialogueGuid',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '通话完整录音地址',
      dataIndex: 'recordUrl',
      width: 220,
      key: 'recordUrl',
      renderText: (text: string) => text1Tooltip(text),
    },
    {
      title: '线路ID',
      dataIndex: 'lineId',
      width: 200,
      key: 'lineId',
    },
    {
      title: '号码归属地',
      dataIndex: 'province',
      width: 180,
      key: 'province',
      renderText: (text: string, record: IDdialogueListItem) => {
        if (text && record.city) {
          return text1Tooltip(`${text}/${record.city}`);
        } else if (text) {
          return text1Tooltip(text);
        } else if (record.city) {
          return text1Tooltip(record.city);
        }
        return '-';
      },
    },
    {
      title: '运营商',
      dataIndex: 'carrier',
      width: 120,
      key: 'carrier',
      renderText: (text: number) => {
        switch (text) {
          //  1-中国移动 2-中国联通 3-中国电信 4-虚拟 5-未知
          case 1:
            return '中国移动';
          case 2:
            return '中国联通';
          case 3:
            return '中国电信';
          case 4:
            return '虚拟';
          case 5:
            return '未知';
          default:
            return '-';
        }
      },
    },
    {
      title: '对话轮次',
      dataIndex: 'speechCount',
      width: 120,
      key: 'speechCount',
    },
    {
      title: '性别检测结果',
      dataIndex: 'sex',
      width: 100,
      key: 'sex',
      renderText: (text: number) => {
        switch (text) {
          case 1:
            return '男';
          case 2:
            return '女';
          case 3:
            return '未知';
          default:
            return '-';
        }
      },
    },
    {
      title: '挂断方',
      dataIndex: 'releaseInitiator',
      width: 100,
      key: 'releaseInitiator',
      renderText: (text: number) => {
        switch (text) {
          case 0:
            return '未知';
          case 1:
            return '呼叫方';
          case 2:
            return '被叫方';
          default:
            return '-';
        }
      },
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      width: 180,
      key: 'createTime',
    },
    {
      title: '操作',
      dataIndex: 'handle',
      key: 'handle',
      width: 100,
      fixed: 'right',
      render: function operation(text: string, record: IDdialogueListItem) {
        return (
          <Space>
            <Typography.Link
              disabled={!record.totalTime}
              onClick={() => handlerGetDetail(record)}
            >
              播放
            </Typography.Link>
            <Typography.Link
              disabled={!record.totalTime}
              onClick={() => handlerShowText(record)}
            >
              查看
            </Typography.Link>
          </Space>
        );
      },
    },
  ];

  // 获取高度变化
  const handleHeightEvent = debounce(async () => {
    try {
      const _wrapHeight = callWrapRef?.current?.clientHeight || 700;
      const _searchHeight = callSearchWrapRef?.current?.clientHeight || 67;
      const paginationHeight =
        callPaginationWrapRef?.current?.clientHeight || 52;
      const _height = _wrapHeight - _searchHeight - paginationHeight - 55 - 50;
      setTableHeight(_height < 301 ? 500 : _height);
      if (_height < 301) {
        setOverflow(true);
      } else {
        setOverflow(false);
      }
    } catch (e) {}
    // }, 0);
  }, 200);

  // 分页
  const onChange = useCallback(
    (page: number | undefined, size: number | undefined) => {
      const params = { pageSize: size, pageNum: 1 };
      if (size !== pageSize) {
        setPageIndex(1);
        setPageSize(size);
      } else {
        setPageIndex(page);
        params.pageNum = page;
      }
      handlerGetLists(params);
    },
    [pageSize],
  );

  // 搜索
  const handleSearchClick = useCallback(
    debounce(
      (data) => {
        setPageIndex(1);
        queryParams.current = data;
        handlerGetLists({
          pageNum: 1,
        });
      },
      1000,
      { leading: true },
    ),
    [pageSize, pageIndex],
  );

  // 重置
  const handleReset = useCallback(() => {
    setPageIndex(1);
    queryParams.current = DEFAULT_CALL_PARAMS;
    handlerGetLists({
      pageNum: 1,
    });
  }, [pageSize, pageIndex]);

  // 导出
  const handleExport = async () => {
    const exportFieldList = JSON.parse(
      localStorage.getItem('distributaryCallLog') || '{}',
    );

    //根据order属性对过滤后的数组进行排序
    function sort(arr) {
      return arr.sort(([, a], [, b]) => {
        return a?.order - b?.order;
      });
    }
    function getSortedKeysByShowAndOrder(obj) {
      // 将对象转换为键值对数组
      const entries = Object.entries(obj);

      // 过滤掉show为false的键值对
      const filteredEntries = entries.filter(
        ([, value]: any) => value?.show !== false,
      );

      const left = filteredEntries.filter(
        ([, value]: any) => value?.fixed === 'left',
      );
      const right = filteredEntries.filter(
        ([, value]: any) => value?.fixed === 'right',
      );
      const middle = filteredEntries.filter(([, value]: any) => !value?.fixed);

      const sortedEntries = [...sort(left), ...sort(middle), ...sort(right)];

      // 从排序后的键值对数组中提取键
      return sortedEntries.map(([key]) => key);
    }

    const sortedKeys = getSortedKeysByShowAndOrder(exportFieldList).filter(
      (key) => key !== 'handle',
    );

    let index = sortedKeys.indexOf('province');
    if (index !== -1) {
      sortedKeys[index] = 'provinceCity';
    }

    const _params = {
      pageNum: pageIndex,
      pageSize: pageSize,
      ...queryParams.current,
      exportFieldList: JSON.stringify(sortedKeys),
    };
    const params = formatApiParams(_params);
    setExportLoading(true);
    const res = await dialogueExport(params);
    if (res?.code === 0) {
      message.success('导出成功，请前往【文件导出管理】页面进行下载');
    }
    setExportLoading(false);
  };

  // 展开
  const handleOpen = useCallback(() => {
    handleHeightEvent();
  }, []);
  // 初始化设置列表右侧可编辑排序配置的localStorage缓存
  const setColumnsStateFunc = () => {
    try {
      // 获取缓存中的版本号
      const storedVersion = localStorage.getItem('distributaryCallLogVersion');
      // 没有版本号，默认不需要更新,设置当前版本号
      if (!storedVersion) {
        localStorage.setItem(
          'distributaryCallLogVersion',
          COLUMN_STATE_VERSION,
        );
        return false;
      }
      // 本地设置的版本号和缓存中的版本号不匹配，更新版本号，并设置当前版本号，设置列表排序配置
      if (storedVersion !== COLUMN_STATE_VERSION) {
        localStorage.setItem(
          'distributaryCallLogVersion',
          COLUMN_STATE_VERSION,
        );
        // 获取当前缓存中列表排序配置
        const storedColumnsState = JSON.parse(
          localStorage.getItem('distributaryCallLog') || '{}',
        );
        let data = {};
        column.forEach((item, index) => {
          let info = storedColumnsState[item.key];
          data[item.key] = (info && {
            ...info,
            order: info.order ?? index,
            fixed: item.fixed || '',
          }) || {
            show: true,
            order: index,
            fixed: item.fixed || '',
          };
        });
        // 版本不匹配，重置 缓存中的数据
        localStorage.setItem('distributaryCallLog', JSON.stringify(data));
      }
    } catch (error) {}
  };
  useEffect(() => {
    handleHeightEvent();
    setPageIndex(1);
    handlerGetLists({
      pageNum: 1,
    });
    setColumnsStateFunc();
    window.addEventListener('resize', handleHeightEvent);
    return () => window.removeEventListener('resize', handleHeightEvent);
  }, []);

  // 虚拟列表（防止多次render）
  const vComponents = useMemo(
    () =>
      VList({
        height: tableHeight,
        resetTopWhenDataChange: false,
      }),
    [tableHeight],
  );
  const virtualTable = useMemo(() => {
    return (
      <ProTable
        columns={column}
        dataSource={tableData}
        ErrorBoundary={false}
        rowKey={() => uuidv1()}
        search={false}
        components={vComponents}
        pagination={false}
        loading={isLoading}
        scroll={{ y: tableHeight, x: 1500 }}
        options={{
          fullScreen: false,
          reload: false,
          density: false,
          setting: true,
        }}
        columnsState={{
          persistenceKey: 'distributaryCallLog',
          persistenceType: 'localStorage',
        }}
      />
    );
  }, [tableData, isLoading, tableHeight, column]);

  return (
    <>
      <div className={styles.callContent} ref={callWrapRef}>
        <div className={styles.search} ref={callSearchWrapRef}>
          <CallSearch
            onSearch={handleSearchClick}
            onReset={handleReset}
            onOpen={handleOpen}
            onExport={handleExport}
            exportLoading={exportLoading}
          />
        </div>
        <div
          // style={{ minWidth: 1200 }}
          className={
            isOverflow
              ? styles.tableContent
              : `${styles.tableContent} ${styles.hidden}`
          }
          id="callTableWrap"
        >
          {virtualTable}
        </div>
        <div className={styles.subPagination} ref={callPaginationWrapRef}>
          <Pagination
            current={pageIndex}
            showSizeChanger={true}
            pageSize={pageSize}
            total={total}
            showTotal={(total) => `总共 ${total} 条`}
            onChange={onChange}
            pageSizeOptions={[25, 50, 100]}
          />
        </div>
      </div>
      {/* 语音播放器Modal */}
      <PlayAudio
        visible={showPlayModel}
        url={curInfo?.recordUrl}
        cancel={useCallback(() => {
          setShowPlayModel(false);
          setCurInfo(undefined);
        }, [])}
        downloadPermission={'Distributary-Manage-calllog-download'}
      />
      {/* 通话详情Drawer */}
      <CallDetail
        open={showTextModel}
        curInfo={curTextInfo}
        callData={useMemo(
          () => tableData.filter((item) => item.totalTime),
          [tableData],
        )}
        onCancel={useCallback(() => {
          setCurTextInfo(undefined);
          setShowTextModel(false);
        }, [tableData, showTextModel, curTextInfo])}
      />
    </>
  );
};
export default CallList;
