import React, { memo, useEffect, useRef, useState } from 'react';
import { Button, Drawer, Radio, Space, Spin } from 'antd';
import AudioPlayer from 'react-h5-audio-player';
import 'react-h5-audio-player/lib/styles.css';
import { VerticalLeftOutlined, VerticalRightOutlined } from '@ant-design/icons';
import ChatDetail from '@/components/ChatDetail';
import { dialogueQueryDetail, IDdialogueListItem } from '@/api/distributary';
import { httpReplace } from '@/utils';
import { useAccess } from '@umijs/max';
import WaveSurferComponent from './components/WaveSurferComponent';
import { downloadCustomNameFile } from '@/utils';
import styles from './index.less';

interface IProps {
  open: boolean;
  onCancel?: () => void;
  curInfo?: IDdialogueListItem;
  callData: IDdialogueListItem[];
}
const CallDetail: React.FC<IProps> = ({
  open,
  onCancel,
  curInfo,
  callData,
}) => {
  const access = useAccess();
  const refWrap = useRef<any>(null);
  const ref = useRef<any>(null);
  const [rate, setRate] = useState(1);

  // 聊天列表
  const [info, setInfo] = useState({});
  const [callDetail, setCallDetail] = useState(null);
  const [loading, setLoading] = useState(false);
  const [callIndex, setCallIndex] = useState(1);
  const [recordFile, setRecordFile] = useState('');

  // 播放速度
  const handlePlay = (e) => {
    e.target.playbackRate = rate;
  };

  // 获取通话详情
  const handleCallDetail = async () => {
    if (!callDetail) return;
    setLoading(true);
    const res = await dialogueQueryDetail({
      id: callDetail.id,
      calledNumber: callDetail.calledNumber,
    });
    if (res.code === 0) {
      setInfo({
        callDialogueResDTO: {
          answerTime: res?.data?.answerTime,
          hangupTime: res?.data?.hangupTime,
        },
        speakContents: res?.data?.speakList,
      });
      const url = httpReplace(res?.data?.recordUrl);
      setRecordFile(url);
    }

    setLoading(false);
  };

  // 上一个
  const handlePre = () => {
    if (loading) return;
    const zIndex = callIndex - 1;
    const callItem = callData[zIndex];
    if (callItem) {
      setCallDetail(callItem);
      setCallIndex(zIndex);
    }
  };

  // 下一个
  const handleNext = () => {
    if (loading) return;
    const zIndex = callIndex + 1;
    const callItem = callData[zIndex];
    if (callItem) {
      setCallDetail(callItem);
      setCallIndex(zIndex);
    }
  };

  useEffect(() => {
    handleCallDetail();
  }, [callDetail]);

  const handleHeightEvent = (e) => {
    switch (e.keyCode) {
      case 39:
        handleNext();
        break;
      case 37:
        handlePre();
        break;
    }
  };

  useEffect(() => {
    if (curInfo) {
      const position = callData.findIndex((item) => item.id === curInfo?.id);
      if (position > -1) {
        setCallDetail(curInfo);
        setCallIndex(position);
      } else {
        setCallDetail(callData[0]);
        setCallIndex(0);
      }
    }
    return () => {
      setCallDetail(null);
    };
  }, [curInfo]);

  useEffect(() => {
    window.addEventListener('keyup', handleHeightEvent);
    return () => window.removeEventListener('keyup', handleHeightEvent);
  }, [curInfo, callIndex, loading]);

  const audioDownLoad = (url) => {
    try {
      const name = new Date().getTime().toString();
      let filename = url.split('?')[0];
      let parts = filename.split('.').pop();
      const filenames = name + '.' + parts;
      downloadCustomNameFile(url, filenames);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <Drawer
      title="对话详情"
      width={640}
      open={open}
      destroyOnClose
      bodyStyle={{ padding: '0 14px' }}
      onClose={() => {
        onCancel?.();
      }}
      extra={
        <Space>
          <span className={styles.count}>
            {callIndex + 1}/{callData.length}
          </span>
          <Button
            type="primary"
            icon={<VerticalRightOutlined />}
            disabled={!callIndex || loading}
            onClick={handlePre}
          >
            上一个
          </Button>
          <Button
            type="primary"
            icon={<VerticalLeftOutlined />}
            disabled={callIndex === callData.length - 1 || loading}
            onClick={handleNext}
          >
            下一个
          </Button>
        </Space>
      }
    >
      <Spin spinning={loading} wrapperClassName={styles.spinContent}>
        <div className={styles.callDetail}>
          <div className={styles.right}>
            <div className={styles.chatWrap}>
              <ChatDetail info={info} isCalllist={true} />
            </div>
            <div className={styles.bottom}>
              <Space className={styles.rate}>
                <Radio.Group
                  value={rate}
                  onChange={(e) => {
                    setRate(e.target.value);
                    const _audio = refWrap.current.querySelectorAll('audio');
                    _audio[0].playbackRate = e.target.value;
                  }}
                >
                  <Radio value={0.5}>0.5</Radio>
                  <Radio value={1}>1</Radio>
                  <Radio value={1.5}>1.5</Radio>
                  <Radio value={2}>2</Radio>
                  <Radio value={2.5}>2.5</Radio>
                </Radio.Group>
                {access?.authCodeList?.includes(
                  'Distributary-Manage-calllog-download',
                ) && (
                  <Button
                    onClick={() => audioDownLoad(recordFile)}
                    disabled={!recordFile}
                    type="link"
                  >
                    下载
                  </Button>
                )}
              </Space>
              <div ref={refWrap}>
                <AudioPlayer
                  ref={ref}
                  src={recordFile}
                  autoPlay={false}
                  autoPlayAfterSrcChange={false}
                  onPlay={(e) => handlePlay(e)}
                  progressJumpStep={12 * 1000}
                  customAdditionalControls={[]}
                />
              </div>
              <div
                style={{
                  marginTop: '20px',
                  boxShadow: ' 0 0 3px 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <WaveSurferComponent audioUrl={recordFile} />
              </div>
              {/* <div
                style={{ height: '100px' }}
                id="wave-content"
                ref={containerRef}
              ></div> */}
            </div>
          </div>
        </div>
      </Spin>
    </Drawer>
  );
};

export default memo(CallDetail);
