import React, { FC, memo, useCallback, useEffect, useState } from 'react';
import {
  Form,
  Input,
  Cascader,
  Select,
  Button,
  Row,
  Col,
  DatePicker,
  Space,
} from 'antd';
import { useAccess } from '@umijs/max';
import { getZeroOrPositiveInt } from '@/utils';
import { timeRanges } from '@/config';
import {
  releaseInitiatorOption,
  hitSmsOption,
  intentListOption,
  typeOption,
  genderOption,
} from '../../../config';
import moment from 'moment';
import { getIntentionListAll } from '@/api/language';
import { DownloadOutlined } from '@ant-design/icons';
import { getProvinceCityList } from '@/api/common';
import { channelList, getRosterEnumList } from '@/api/distributary';
import { supportCarrierOpts } from '@/pages/lineSupplier/config';
import styles from '../../index.less';

const { RangePicker } = DatePicker;
const { SHOW_CHILD } = Cascader;
const colLayout = { xl: 8, sm: 12, xs: 24 };

interface IProps {
  onSearch?: (data: any) => void;
  onExport: (res) => void;
  exportLoading: boolean;
  onReset?: () => void;
  onOpen?: () => void;
}

const CallSearch: FC<IProps> = ({
  onSearch,
  onReset,
  onOpen,
  onExport,
  exportLoading,
}) => {
  const access = useAccess();
  const [form] = Form.useForm();
  const [open, setOpen] = useState(false);
  const [cityOpt, setCityOpt] = useState([]);
  const [intentionList, setIntentionList] = useState([]);
  const [rosterEnumList, setRosterEnumList] = useState([]);

  const handleInputNumber = useCallback((type, value) => {
    getZeroOrPositiveInt(value).then((value) =>
      form.setFieldsValue({
        [type]: value,
      }),
    );
  }, []);
  // 渠道列表
  const [channeldropDown, setChanneldropDown] = useState([]);
  // 获取省市数据
  const getCityOpt = useCallback(async () => {
    const opt = [];
    // todo 异步获取行政区数据
    const DISTRICTS: any = await getProvinceCityList();
    DISTRICTS.forEach((item) => {
      if (item['level'] === 1) {
        const citys = [];
        DISTRICTS.forEach((i) => {
          if (item.area_code === i.parent_code)
            citys.push({ value: i.area_name, label: i.area_name });
        });
        opt.push({
          value: item.area_code,
          label: item.area_name,
          children: citys,
        });
      }
    });
    setCityOpt(opt);
  }, []);

  // 获取渠道商列表
  const getChannelList = async () => {
    try {
      const data = await channelList();
      setChanneldropDown(data || []);
    } catch (e) {}
  };
  // 获取渠道商列表
  const getRosterEnumListFunc = async () => {
    try {
      const res = await getRosterEnumList({ type: 1 });
      if (res.success) {
        setRosterEnumList(res?.data?.enumConstantDTOList || []);
      }
    } catch (e) {}
  };

  // 获取意向分类
  const getIntentionOpt = useCallback(async () => {
    const res = await getIntentionListAll({
      pageSize: 200,
      pageNum: 1,
    });
    if (res) {
      setIntentionList(res);
    }
  }, []);

  // 重置
  const handleReset = () => {
    form.resetFields();
    form.setFieldsValue({
      intentListType: 'hitIntentions',
      createTime: [
        moment('00:00:00', 'HH:mm:ss'),
        moment('23:59:59', 'HH:mm:ss'),
      ],
    });
    onReset?.();
  };

  // 搜索
  const handleSearch = async () => {
    const res = await form.validateFields();
    onSearch?.(res);
  };

  useEffect(() => {
    getCityOpt();
    getIntentionOpt();
    getRosterEnumListFunc();
    form.setFieldsValue({
      createTime: [
        moment('00:00:00', 'HH:mm:ss'),
        moment('23:59:59', 'HH:mm:ss'),
      ],
    });
    getChannelList();
  }, []);
  return (
    <Form form={form}>
      <Row wrap={false}>
        <Col
          flex="auto"
          className={styles.leftSearch + ' ' + (open ? null : styles.isHide)}
        >
          <Row gutter={[16, 16]}>
            <Col {...colLayout}>
              <Form.Item name="channelId">
                <Select
                  placeholder="请选择渠道商名称"
                  showSearch
                  allowClear
                  options={channeldropDown}
                  optionFilterProp="channelName"
                  // getPopupContainer={(triggerNode) =>
                  //   triggerNode.parentElement || document.body
                  // }
                  fieldNames={{ label: 'channelName', value: 'channelId' }}
                ></Select>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="platformId">
                <Input placeholder="请输入平台数据标识" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="md5">
                <Input placeholder="请输入32位MD5" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="calledNumber">
                <Input placeholder="请输入被叫号码" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="distributePlanName">
                <Input placeholder="请输入分流计划名称" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="distributePlanId">
                <Input placeholder="请输入分流计划ID" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="supplierTaskId">
                <Input placeholder="请输入任务ID" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="supplierTaskName">
                <Input placeholder="请输入任务名称" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="callResultList">
                <Select
                  placeholder="请选择呼叫结果"
                  showSearch
                  allowClear
                  mode="multiple"
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  options={rosterEnumList}
                  maxTagCount="responsive"
                  optionFilterProp="value"
                  fieldNames={{ label: 'value', value: 'code' }}
                />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="intentClassifyList">
                <Select
                  placeholder="请选择意向分类Code"
                  allowClear
                  mode="multiple"
                  maxTagCount="responsive"
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                >
                  {intentionList.map((item, index) => (
                    <Select.Option
                      key={`${item.classification}_${index}`}
                      value={item.classification}
                    >
                      {item.classification}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="intentClassifyName">
                <Input placeholder="请输入意向分类名称" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item noStyle>
                <Space.Compact block>
                  <Form.Item
                    name="intentListType"
                    initialValue={'hitIntentions'}
                    className={styles.formItemSelect}
                  >
                    <Select
                      options={intentListOption}
                      getPopupContainer={(triggerNode) =>
                        triggerNode.parentElement || document.body
                      }
                    ></Select>
                  </Form.Item>
                  <Form.Item
                    name="intentListData"
                    className={styles.formItemSelect1}
                  >
                    <Select
                      placeholder="请输入命中意图"
                      mode="tags"
                      maxTagCount="responsive"
                      allowClear
                      getPopupContainer={(triggerNode) =>
                        triggerNode.parentElement || document.body
                      }
                    />
                  </Form.Item>
                </Space.Compact>
              </Form.Item>
            </Col>

            <Col {...colLayout}>
              <Form.Item name="isHitSms">
                <Select
                  placeholder="请选择是否触发短信"
                  allowClear
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                >
                  {hitSmsOption.map((item) => (
                    <Select.Option key={item.label} value={item.value}>
                      {item.label}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="seatName">
                <Input placeholder="请输入坐席姓名" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item noStyle>
                <Space align="start">
                  <Form.Item name="durationCallAiStart">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('durationCallAiStart', e.target.value)
                      }
                      allowClear
                      placeholder="AI通话时长开始(秒)"
                    />
                  </Form.Item>
                  <span className={styles.lineHeight32}>-</span>
                  <Form.Item name="durationCallAiEnd">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('durationCallAiEnd', e.target.value)
                      }
                      allowClear
                      placeholder="AI通话时长结束(秒)"
                    />
                  </Form.Item>
                </Space>
              </Form.Item>
            </Col>

            <Col {...colLayout}>
              <Form.Item noStyle>
                <Space align="start">
                  <Form.Item name="durationCallManualStart">
                    <Input
                      onChange={(e) =>
                        handleInputNumber(
                          'durationCallManualStart',
                          e.target.value,
                        )
                      }
                      allowClear
                      placeholder="人工通话时长开始(秒)"
                    />
                  </Form.Item>
                  <span className={styles.lineHeight32}>-</span>
                  <Form.Item name="durationCallManualEnd">
                    <Input
                      onChange={(e) =>
                        handleInputNumber(
                          'durationCallManualEnd',
                          e.target.value,
                        )
                      }
                      allowClear
                      placeholder="人工通话时长结束(秒)"
                    />
                  </Form.Item>
                </Space>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item name="realCallingNumber">
                <Input placeholder="请输入中继外显号" allowClear />
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item noStyle>
                <Space align="start">
                  <Form.Item name="totalTimeStart">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('totalTimeStart', e.target.value)
                      }
                      allowClear
                      placeholder="通话时长开始(秒)"
                    />
                  </Form.Item>
                  <span className={styles.lineHeight32}>-</span>
                  <Form.Item name="totalTimeEnd">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('totalTimeEnd', e.target.value)
                      }
                      allowClear
                      placeholder="通话时长结束(秒)"
                    />
                  </Form.Item>
                </Space>
              </Form.Item>
            </Col>
            <Col {...colLayout}>
              <Form.Item noStyle>
                <Space align="start">
                  <Form.Item name="ringTimeStart">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('ringTimeStart', e.target.value)
                      }
                      allowClear
                      placeholder="振铃时长开始(秒)"
                    />
                  </Form.Item>
                  <span className={styles.lineHeight32}>-</span>
                  <Form.Item name="ringTimeEnd">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('ringTimeEnd', e.target.value)
                      }
                      allowClear
                      placeholder="振铃时长结束(秒)"
                    />
                  </Form.Item>
                </Space>
              </Form.Item>
            </Col>
            {/* 拨号时间  */}
            <Col {...colLayout}>
              <Form.Item name="dialTime">
                <RangePicker
                  style={{ width: '100%' }}
                  placeholder={['拨号时间开始', '拨号时间结束']}
                  showTime={{
                      hideDisabledOptions: true,
                      defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                  }}
                  ranges={timeRanges}
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  allowClear={true}
                />
              </Form.Item>
            </Col>
            {/* 挂断时间  */}
            <Col {...colLayout}>
              <Form.Item name="hangupTime">
                <RangePicker
                  style={{ width: '100%' }}
                  placeholder={['挂断时间开始', '挂断时间结束']}
                  showTime={{
                    hideDisabledOptions: true,
                    defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                  }}
                  ranges={timeRanges}
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  allowClear={true}
                />
              </Form.Item>
            </Col>
            {/* 通话类型  */}
            <Col {...colLayout}>
              <Form.Item name="callType">
                <Select
                  options={typeOption}
                  allowClear
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  placeholder="请选择通话类型"
                />
              </Form.Item>
            </Col>
            {/* 主叫号码 */}
            <Col {...colLayout}>
              <Form.Item name="callingNumber">
                <Input placeholder="请输入主叫号码" allowClear />
              </Form.Item>
            </Col>
            {/* 计费单元数 */}
            <Col {...colLayout}>
              <Form.Item noStyle>
                <Space align="start">
                  <Form.Item name="costUnitStart">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('costUnitStart', e.target.value)
                      }
                      allowClear
                      placeholder="计费单元数开始"
                    />
                  </Form.Item>
                  <span className={styles.lineHeight32}>-</span>
                  <Form.Item name="costUnitEnd">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('costUnitEnd', e.target.value)
                      }
                      allowClear
                      placeholder="计费单元数结束"
                    />
                  </Form.Item>
                </Space>
              </Form.Item>
            </Col>
            {/* 通话唯一ID  */}
            <Col {...colLayout}>
              <Form.Item name="dialogueGuid">
                <Input placeholder="请输入通话唯一ID " allowClear />
              </Form.Item>
            </Col>
            {/* 号码归属地 */}
            <Col {...colLayout}>
              <Form.Item name="citys">
                <Cascader
                  showSearch
                  options={cityOpt}
                  placeholder="请选择号码归属地"
                  multiple
                  maxTagCount="responsive"
                  showCheckedStrategy={SHOW_CHILD}
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                />
              </Form.Item>
            </Col>
            {/* 运营商  */}
            <Col {...colLayout}>
              <Form.Item name="carrierList">
                <Select
                  placeholder="请选择运营商"
                  allowClear
                  mode="multiple"
                  maxTagCount="responsive"
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                >
                  {supportCarrierOpts.map((item) => (
                    <Select.Option key={item.value} value={item.value}>
                      {item.label}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            {/* 对话轮次  */}
            <Col {...colLayout}>
              <Form.Item noStyle>
                <Space align="start">
                  <Form.Item name="speechCountStart">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('speechCountStart', e.target.value)
                      }
                      allowClear
                      placeholder="对话轮次开始(秒)"
                    />
                  </Form.Item>
                  <span className={styles.lineHeight32}>-</span>
                  <Form.Item name="speechCountEnd">
                    <Input
                      onChange={(e) =>
                        handleInputNumber('speechCountEnd', e.target.value)
                      }
                      allowClear
                      placeholder="对话轮次结束(秒)"
                    />
                  </Form.Item>
                </Space>
              </Form.Item>
            </Col>
            {/* 性别检测结果  */}
            <Col {...colLayout}>
              <Form.Item name="sex">
                <Select
                  options={genderOption}
                  allowClear
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                  placeholder="请选择性别检测结果"
                />
              </Form.Item>
            </Col>
            {/* 挂断方  */}
            <Col {...colLayout}>
              <Form.Item name="releaseInitiator">
                <Select
                  placeholder="请选择挂断方"
                  allowClear
                  getPopupContainer={(triggerNode) =>
                    triggerNode.parentElement || document.body
                  }
                >
                  {releaseInitiatorOption.map((item) => (
                    <Select.Option key={item.label} value={item.value}>
                      {item.label}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            {/* 创建时间  */}
            <Col {...colLayout}>
              <Form.Item name="createTime">
                <RangePicker
                  style={{ width: '100%' }}
                  placeholder={['创建时间开始', '创建时间结束']}
                  showTime={{
                    hideDisabledOptions: true,
                    defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                  }}
                  ranges={timeRanges}
                  allowClear={true}
                />
              </Form.Item>
            </Col>
          </Row>
        </Col>
        <Col flex="none">
          <Space>
            <Button type="primary" htmlType="submit" onClick={handleSearch}>
              搜索
            </Button>
            {access?.authCodeList?.includes(
              'Distributary-Manage-calllog-export',
            ) && (
              <Button
                icon={<DownloadOutlined />}
                onClick={onExport}
                loading={exportLoading}
              >
                导出
              </Button>
            )}
            <Button onClick={handleReset}>重置</Button>
            <Button
              type="link"
              size="small"
              onClick={() => {
                setOpen(!open);
                onOpen?.();
              }}
            >
              {open ? '收起' : '展开'}
            </Button>
          </Space>
        </Col>
      </Row>
    </Form>
  );
};
export default memo(CallSearch);
