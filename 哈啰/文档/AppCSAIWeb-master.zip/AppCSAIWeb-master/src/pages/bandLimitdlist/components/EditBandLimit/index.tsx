import React, { FC, useEffect, useMemo, useState } from 'react';
import { Form, Modal, Input, Cascader, Select, Button, message } from 'antd';
import { useModel } from '@umijs/max';
import {
  MinusCircleFilled,
  PlusOutlined,
  PlusSquareTwoTone,
  MinusSquareTwoTone,
} from '@ant-design/icons';
import styles from './index.less';
import {
  addBandRule,
  editBandRule,
  IRuleInfo,
  queryRangeIdentifier,
  queryRangeIdentifierEnum,
} from '@/api/bandLimit';
import { isIntegerBarringZero } from '@/utils';

const { TextArea } = Input;
const layout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 16 },
};

export interface Prop {
  type?: number;
  info?: IRuleInfo;
  onOk?: () => void;
  onCancel?: () => void;
}

const EditBandLimit: FC<Prop> = ({ type, onCancel, info, onOk }) => {
  const { tenantOpts, fetchTenantOpts } = useModel('common');
  const { bizList, handleGetBizList } = useModel('speech');
  const [form] = Form.useForm();
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [isError, setIsError] = useState(false);
  const [options, setOptions] = useState<queryRangeIdentifierEnum[]>([]);
  // 验证
  const validBizId = (_, val) => {
    if (val?.length === 1) return Promise.reject('不能选一级');
    return Promise.resolve();
  };

  // 验证
  const handleValidatorInt = async (rule, value) => {
    if (!value) return Promise.reject('请输入');
    if (!isIntegerBarringZero(value)) return Promise.reject('大于0正整数');
    return Promise.resolve();
  };

  // 验证外呼限频
  const validCallPlaceist = (_, val) => {
    console.log('验证', val);
    if (!val?.length) {
      setIsError(true);
      return Promise.reject('请添加外呼限频');
    }
    setIsError(false);
    return Promise.resolve();
  };

  // 取消
  const handleCancel = () => {
    form.resetFields();
    setConfirmLoading(false);
    onCancel?.();
  };

  const handleValidator = (param: any) => {
    const { faqFilter, taskFilter, bizId, tenantList } = param;
    const isTalkNone =
      faqFilter[0]?.faqName === '' && !faqFilter[0]?.faqRangeCode;
    const isTaskNone =
      taskFilter[0]?.taskName === '' && !taskFilter[0]?.taskRangeCode;
    const isRuleNone = !!!bizId;
    const isTenantNone = !tenantList?.length;
    if (isTalkNone && isTaskNone && isRuleNone && isTenantNone) {
      message.error('请至少补充一条规则');
      return;
    }
    if (faqFilter[0]?.faqName === '' && faqFilter[0]?.faqRangeCode) {
      message.info('请补充适用话术名称');
      return;
    }
    if (faqFilter[0]?.faqName && faqFilter[0]?.faqRangeCode === undefined) {
      message.info('请补充适用话术范围');
      return;
    }
    return true;
  };

  // 提交
  const handleOk = async () => {
    let param = await form.validateFields();
    if (type === 2) param.id = info?.id;
    if (param?.industry) {
      param.bizId = param?.industry[1];
    }
    if (param?.industry?.length === 3) {
      param.bizSceneId = param.industry[param.industry.length - 1];
    }
    // 没有租户默认传空
    param.tenantList = param?.tenantList || [];
    delete param?.industry;
    // bizId 代替industry字段
    // 错误或警告提示
    if (!handleValidator(param)) {
      return;
    }
    const api = type === 1 ? addBandRule : editBandRule;
    const { faqFilter, taskFilter } = param;
    const isTalkNone =
      faqFilter[0]?.faqName === '' && !faqFilter[0]?.faqRangeCode;
    const isTaskNone =
      taskFilter[0]?.taskName === '' && !taskFilter[0]?.taskRangeCode;
    if (isTalkNone) {
      delete param.faqFilter;
    }
    if (isTaskNone) {
      delete param.taskFilter;
    }
    setConfirmLoading(true);
    const res = await api(param);
    if (res.success) {
      message.success('操作成功');
      handleCancel();
      onOk?.();
    }
    setConfirmLoading(false);
  };

  // 选中行业
  useMemo(async () => {
    if (type && (info?.bizId || info?.bizSceneId) && bizList?.length) {
      try {
        bizList.forEach((item) => {
          item.children?.forEach((i) => {
            if (i.value === info?.bizId && !info?.bizSceneId) {
              setTimeout(() => {
                form.setFieldValue('industry', [item.value, info?.bizId]);
              }, 0);
              throw new Error();
            } else if (
              i?.children?.findIndex((j) => j.value === info?.bizSceneId) > -1
            ) {
              setTimeout(() => {
                form.setFieldValue('industry', [
                  item.value,
                  i.value,
                  info?.bizSceneId,
                ]);
              }, 0);
              throw new Error();
            }
          });
        });
      } catch (e) {}
    }
  }, [info, bizList, type]);

  const getOptsFiledNames = () => {
    queryRangeIdentifier().then((res) => {
      const { code, data } = res;
      if (code === '0') {
        setOptions(data);
      }
    });
  };

  const rulesTaskCode = async () => {
    const list = form.getFieldValue('taskFilter');
    if (
      (list[0]?.taskName && list[0]?.taskRangeCode === undefined) ||
      (list.length > 1 && list[0]?.taskRangeCode === undefined)
    ) {
      return Promise.reject('请选择');
    }
    return Promise.resolve();
  };
  const rulesTaskName = async () => {
    const list = form.getFieldValue('taskFilter');
    if (
      (list[0]?.taskName === '' && list[0]?.taskRangeCode) ||
      (list.length > 1 && list[0]?.taskName === '')
    ) {
      return Promise.reject('请输入');
    }
    return Promise.resolve();
  };

  const rulesFaqCode = async () => {
    const list = form.getFieldValue('faqFilter');
    if (
      (list[0]?.faqName && list[0]?.faqRangeCode === undefined) ||
      (list.length > 1 && list[0]?.faqRangeCode === undefined)
    ) {
      return Promise.reject('请选择');
    }
    return Promise.resolve();
  };
  const rulesFaqName = async () => {
    const list = form.getFieldValue('faqFilter');
    if (
      (list[0]?.faqName === '' && list[0]?.faqRangeCode) ||
      (list.length > 1 && list[0]?.faqName === '')
    ) {
      return Promise.reject('请输入');
    }
    return Promise.resolve();
  };

  useEffect(() => {
    if (info && type) {
      info.tenantList = info?.tenantInfoList?.map((item) => item?.tenantCode);
      form.setFieldsValue(info);
    } else {
      form.resetFields();
    }
    if (type && !bizList?.length) handleGetBizList();
    if (type) {
      fetchTenantOpts();
      getOptsFiledNames();
    }
  }, [type]);

  return (
    <>
      <Modal
        open={!!type}
        title={
          type === 1
            ? '新建'
            : type === 2
            ? '编辑'
            : type === 3
            ? '复制'
            : '查看'
        }
        forceRender={true}
        width={'580px'}
        onOk={handleOk}
        onCancel={handleCancel}
        confirmLoading={confirmLoading}
        getContainer={false}
      >
        <Form form={form} {...layout}>
          <Form.Item label="规则名称" name="name" rules={[{ required: true }]}>
            <Input maxLength={30} placeholder="请输入规则名称，限制30字" />
          </Form.Item>
          <Form.Item
            label="适用租户"
            name="tenantList"
            rules={[
              {
                validator: (_, value) => {
                  if (value?.length > 6) {
                    return Promise.reject(new Error('最多选6个租户'));
                  }
                  return Promise.resolve();
                },
              },
            ]}
          >
            <Select
              showSearch
              optionFilterProp="label"
              placeholder="请选择"
              mode="multiple"
              options={tenantOpts}
            />
          </Form.Item>
          <Form.Item
            label="适用场景"
            name="industry"
            rules={[{ validator: validBizId }]}
          >
            <Cascader
              placeholder="请选择"
              options={bizList}
              changeOnSelect
              // disabled={type === 2}
            />
          </Form.Item>
          <Form.Item label="适用任务" style={{ margin: '0px' }}>
            <Form.List
              name="taskFilter"
              initialValue={[{ taskName: '', taskRangeCode: undefined }]}
            >
              {(fields, { add, remove }) => (
                <>
                  {fields.map(({ key, name }, index) => {
                    const list = form.getFieldValue('taskFilter');
                    const rulesCode =
                      index > 0
                        ? [{ required: true, message: '请选择' }]
                        : [{ validator: rulesTaskCode }];
                    const rulesName =
                      index > 0
                        ? [{ required: true, message: '请输入' }]
                        : [{ validator: rulesTaskName }];
                    return (
                      <div
                        key={key}
                        style={{ display: 'flex', position: 'relative' }}
                      >
                        <Form.Item
                          noStyle
                          shouldUpdate={(prev, cur) =>
                            prev.taskFilter !== cur.taskFilter
                          }
                        >
                          <div
                            style={{
                              display: 'flex',
                              position: 'relative',
                            }}
                          >
                            <Form.Item
                              style={{ marginRight: '10px' }}
                              name={[name, 'taskRangeCode']}
                              rules={rulesCode}
                              trigger="onChange"
                            >
                              <Select
                                placeholder="请选择"
                                style={{ width: '100px' }}
                                options={options}
                                fieldNames={{ label: 'desc', value: 'code' }}
                                allowClear
                              ></Select>
                            </Form.Item>
                            <Form.Item
                              style={{ width: '244px' }}
                              name={[name, 'taskName']}
                              rules={rulesName}
                              trigger="onChange"
                            >
                              <Input placeholder="请输入"></Input>
                            </Form.Item>

                            <div
                              style={{ position: 'absolute', right: '-45px' }}
                            ></div>
                            {index > 0 && (
                              <div
                                style={{ position: 'absolute', right: '-45px' }}
                              >
                                <MinusSquareTwoTone
                                  onClick={() => remove(name)}
                                  style={{
                                    fontSize: '20px',
                                    margin: '6px 10px 0 0',
                                  }}
                                />
                              </div>
                            )}
                            {index === 0 && (
                              <div
                                style={{ position: 'absolute', right: '-45px' }}
                              >
                                <PlusSquareTwoTone
                                  onClick={() =>
                                    list?.length >= 10 ? null : add({})
                                  }
                                  style={{
                                    fontSize: '20px',
                                    margin: '6px 10px 0 0',
                                  }}
                                  className={
                                    list?.length >= 10
                                      ? styles.disabledIcon
                                      : ''
                                  }
                                />
                              </div>
                            )}
                          </div>
                        </Form.Item>
                      </div>
                    );
                  })}
                </>
              )}
            </Form.List>
          </Form.Item>
          <Form.Item label="适用话术" style={{ margin: '0px' }}>
            <Form.List
              name="faqFilter"
              initialValue={[{ faqName: '', faqRangeCode: undefined }]}
            >
              {(fields, { add, remove }) => (
                <>
                  {fields.map(({ key, name }, index) => {
                    const list = form.getFieldValue('faqFilter');
                    const rulesCode =
                      index > 0
                        ? [{ required: true, message: '请选择' }]
                        : [{ validator: rulesFaqCode }];
                    const rulesName =
                      index > 0
                        ? [{ required: true, message: '请输入' }]
                        : [{ validator: rulesFaqName }];
                    return (
                      <div
                        key={key}
                        style={{ display: 'flex', position: 'relative' }}
                      >
                        <Form.Item
                          noStyle
                          shouldUpdate={(prev, cur) =>
                            prev.faqFilter !== cur.faqFilter
                          }
                        >
                          <div
                            style={{
                              display: 'flex',
                              position: 'relative',
                            }}
                          >
                            <Form.Item
                              style={{ marginRight: '10px' }}
                              name={[name, 'faqRangeCode']}
                              rules={rulesCode}
                            >
                              <Select
                                placeholder="请选择"
                                style={{ width: '100px' }}
                                options={options}
                                fieldNames={{ label: 'desc', value: 'code' }}
                                allowClear
                              ></Select>
                            </Form.Item>
                            <Form.Item
                              style={{ width: '244px' }}
                              name={[name, 'faqName']}
                              rules={rulesName}
                              trigger="onChange"
                            >
                              <Input placeholder="请输入"></Input>
                            </Form.Item>

                            <div
                              style={{ position: 'absolute', right: '-45px' }}
                            ></div>
                            {index > 0 && (
                              <div
                                style={{ position: 'absolute', right: '-45px' }}
                              >
                                <MinusSquareTwoTone
                                  onClick={() => remove(name)}
                                  style={{
                                    fontSize: '20px',
                                    margin: '6px 10px 0 0',
                                  }}
                                />
                              </div>
                            )}
                            {index === 0 && (
                              <div
                                style={{ position: 'absolute', right: '-45px' }}
                              >
                                <PlusSquareTwoTone
                                  onClick={() =>
                                    list?.length >= 10 ? null : add({})
                                  }
                                  style={{
                                    fontSize: '20px',
                                    margin: '6px 10px 0 0',
                                  }}
                                  className={
                                    list?.length >= 10
                                      ? styles.disabledIcon
                                      : ''
                                  }
                                />
                              </div>
                            )}
                          </div>
                        </Form.Item>
                      </div>
                    );
                  })}
                </>
              )}
            </Form.List>
          </Form.Item>
          <Form.Item label={<span className={styles.notice}>外呼限频</span>}>
            <Form.List
              name="rule"
              rules={[{ validator: validCallPlaceist }]}
              // initialValue={}
            >
              {(fields, { add, remove }) => (
                <>
                  <Form.Item
                    noStyle
                    shouldUpdate={(prev, cur) => prev.rule !== cur.rule}
                  >
                    {({ getFieldValue }) => {
                      const list = getFieldValue('rule');
                      return (
                        <div style={{ margin: '6px 0 15px 0' }}>
                          <Button
                            onClick={() => {
                              add({
                                type: 1,
                                frequencyCount: null,
                                timePeriod: null,
                                timeUnit: null,
                              });
                            }}
                            disabled={list?.length > 5}
                            icon={<PlusOutlined />}
                            type="primary"
                            style={{ marginRight: '10px' }}
                            size="small"
                          >
                            添加呼叫限频
                          </Button>
                          <Button
                            onClick={() => {
                              setIsError(false);
                              add({
                                type: 2,
                                frequencyCount: null,
                                timePeriod: null,
                                timeUnit: null,
                              });
                            }}
                            disabled={list?.length > 5}
                            icon={<PlusOutlined />}
                            type="primary"
                            style={{ marginRight: '10px' }}
                            size="small"
                          >
                            添加接通限频
                          </Button>
                        </div>
                      );
                    }}
                  </Form.Item>

                  {fields.map(({ key, name }) => (
                    <div key={key} style={{ display: 'flex' }}>
                      <MinusCircleFilled
                        style={{ fontSize: '20px', margin: '6px 10px 0 0' }}
                        onClick={() => remove(name)}
                      />
                      <Form.Item
                        noStyle
                        shouldUpdate={(prev, cur) => prev.rule !== cur.rule}
                      >
                        {({ getFieldValue }) => {
                          return (
                            <Form.Item
                              label={
                                getFieldValue('rule')[name].type === 1
                                  ? '呼叫'
                                  : '接通'
                              }
                              name={[name, 'frequencyCount']}
                              rules={[{ validator: handleValidatorInt }]}
                            >
                              <Input style={{ width: '80px' }} />
                            </Form.Item>
                          );
                        }}
                      </Form.Item>
                      <div style={{ margin: '5px 10px 0' }}>次/</div>
                      <Form.Item
                        style={{ marginRight: '10px' }}
                        name={[name, 'timePeriod']}
                        rules={[{ validator: handleValidatorInt }]}
                      >
                        <Input style={{ width: '80px' }} />
                      </Form.Item>
                      <Form.Item
                        name={[name, 'timeUnit']}
                        rules={[{ required: true, message: '请选择' }]}
                      >
                        <Select allowClear style={{ width: '80px' }}>
                          <Select.Option value="分钟">分钟</Select.Option>
                          <Select.Option value="小时">小时</Select.Option>
                          <Select.Option value="天">天</Select.Option>
                        </Select>
                      </Form.Item>
                    </div>
                  ))}
                </>
              )}
            </Form.List>
            {isError ? (
              <div className="ant-form-item-explain-error">请添加外呼限频</div>
            ) : null}
          </Form.Item>
          <Form.Item label="备注" name="remark">
            <TextArea
              rows={4}
              maxLength={120}
              placeholder="请输入，限制120字"
              showCount
            ></TextArea>
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};
export default EditBandLimit;
