import React, { useEffect, useState } from 'react';
import {
  Space,
  Table,
  Typography,
  Button,
  Popover,
  message,
  Popconfirm,
} from 'antd';
import { useModel, useAccess } from '@umijs/max';
import { debounce } from 'lodash';
import EditBandLimit from './components/EditBandLimit';
import { deleteBandRule, getRuleList, IRuleInfo } from '@/api/bandLimit';
import { text1Tooltip } from '@/utils/format';
import styles from './index.less';

const BandLimit: React.FC = () => {
  // const queryParams = useRef({
  //   pageNum: 1,
  //   pageSize: 100,
  //   status: undefined,
  //   speechName: undefined,
  // });
  const access = useAccess();
  const { bizList, handleGetBizList } = useModel('speech');
  const [tableData, setTableData] = useState<IRuleInfo[]>([]);
  const [isLoading, setLoading] = useState(false);
  // const [total, setTotal] = useState(0);
  // const [pageIndex, setPageIndex] = useState(1);
  // const [pageSize, setPageSize] = useState(100);
  const [tableHeight, setTableHeight] = useState<string | number>('auto');
  // 1--新增 2--编辑  3--复制 4--查看
  const [type, setType] = useState(undefined);
  const [curInfo, setCurInfo] = useState<IRuleInfo>(undefined);

  // 获取高度变化
  const handleHeightEvent = debounce(async () => {
    const ele = document.getElementById('bandLimitTableWrap');
    const _height = (ele?.clientHeight || 300) - 55;
    setTableHeight(_height < 101 ? 500 : _height);
  }, 200);

  const handlerGetLists = async () => {
    setLoading(true);
    const res = await getRuleList();
    if (res.success && res?.data) {
      setTableData(res?.data);
      // setTotal(Number(res?.data?.totalRecord) || 0);
      setTimeout(() => {
        handleHeightEvent();
      }, 0);
    } else {
      setTableData([]);
    }
    setLoading(false);
  };

  // 分页
  // const onChange = (page: number | undefined, size: number | undefined) => {
  //   if (size !== pageSize) {
  //     queryParams.current.pageNum = 1;
  //     queryParams.current.pageSize = size;
  //     setPageIndex(1);
  //     setPageSize(size);
  //   } else {
  //     setPageIndex(page);
  //     queryParams.current.pageNum = page;
  //   }
  //   handlerGetLists();
  // };

  // 编辑
  const handleEdit = (info: IRuleInfo) => {
    setType(2);
    setCurInfo(info);
  };

  // 编辑取消
  const handleEditCancel = () => {
    setType(undefined);
    setCurInfo(undefined);
  };

  // 编辑提交
  const handleEditOk = () => {
    handleEditCancel();
    handlerGetLists();
  };

  // 删除
  const handlerDelete = async (id: string) => {
    const res = await deleteBandRule({ id });
    if (res.success) {
      message.success('删除成功');
      handlerGetLists();
    }
  };

  const column: any = [
    {
      title: '规则名称',
      fixed: 'left',
      dataIndex: 'name',
      key: 'name',
      ellipsis: true,
    },
    {
      title: '适用租户',
      dataIndex: 'tenantInfoList',
      key: 'tenantInfoList',
      render: (content: IRuleInfo['tenantInfoList']) => {
        if (content?.length > 0) {
          const _content = content
            ?.map((item) => {
              return item?.tenantName;
            })
            ?.join('、');
          return text1Tooltip(_content);
        } else {
          return '全部';
        }
      },
    },
    {
      title: '适用场景',
      dataIndex: 'showScene',
      key: 'showScene',
      ellipsis: true,
      align: 'center',
      render: (_, record) => {
        return record?.showScene || '-';
      },
    },
    {
      title: '适用任务',
      dataIndex: 'taskFilter',
      key: 'taskFilter',
      ellipsis: true,
      align: 'center',
      render: (_, record) => {
        const names = record?.taskFilter?.map((item) => {
          return item?.taskName;
        });
        const txt = names?.join('&') || '-';
        return (
          <Popover content={txt} trigger="hover">
            {txt}
          </Popover>
        );
      },
    },
    {
      title: '适用话术',
      dataIndex: 'faqFilter',
      key: 'faqFilter',
      ellipsis: true,
      align: 'center',
      render: (_, record) => {
        const names = record?.faqFilter?.map((item) => {
          return item?.faqName;
        });
        const txt = names?.join('&') || '-';
        return (
          <Popover content={txt} trigger="hover">
            {txt}
          </Popover>
        );
      },
    },
    {
      title: '限频规则',
      dataIndex: 'rule',
      key: 'rule',
      width: 300,
      render: (rule: IRuleInfo['rule'], record: IRuleInfo) => {
        const rules = rule?.map((it, index) => (
          <span key={`${record.id}_${index}`}>
            {index % 2 === 0 && index !== 0 && <br />}
            <span style={{ marginRight: '10px' }}>
              {it?.type === 1 ? '呼叫限频：' : '接通限频：'}
              {it.frequencyCount}次/{it.timePeriod}
              {it.timeUnit}；
            </span>
          </span>
        ));
        return (
          <Popover
            content={rules}
            trigger="hover"
            getPopupContainer={(triggerNode) =>
              triggerNode.parentElement || document.body
            }
          >
            {rules}
          </Popover>
        );
      },
    },
    {
      title: '更新人',
      dataIndex: 'updateUser',
      key: 'updateUser',
    },
    {
      title: '更新时间',
      dataIndex: 'updateTime',
      key: 'updateTime',
    },
    {
      title: '操作',
      dataIndex: 'guid',
      key: 'guid',
      fixed: 'right',
      width: 130,
      render: function operation(text: string, record: IRuleInfo) {
        return access?.authCodeList?.includes(
          'Call-Limit-BandLimitdlist-Edit',
        ) ? (
          <Space direction="horizontal">
            <Popconfirm
              title="是否确认删除？"
              // eslint-disable-next-line @typescript-eslint/no-use-before-define
              onConfirm={() => handlerDelete(record?.id)}
            >
              <Typography.Link>删除</Typography.Link>
            </Popconfirm>
            <Typography.Link onClick={() => handleEdit(record)}>
              编辑
            </Typography.Link>
          </Space>
        ) : (
          ''
        );
      },
    },
  ];

  useEffect(() => {
    if (!bizList?.length) handleGetBizList();
    handlerGetLists();
    window.addEventListener('resize', handleHeightEvent);
    return () => window.removeEventListener('resize', handleHeightEvent);
  }, []);
  return (
    <>
      <div className={styles.wrap}>
        <div className={styles.search}>
          {access?.authCodeList?.includes('Call-Limit-BandLimitdlist-Add') && (
            <Button type="primary" onClick={() => setType(1)}>
              新增
            </Button>
          )}
        </div>
        <div className={styles.tableContent} id="bandLimitTableWrap">
          <Table
            columns={column}
            dataSource={tableData}
            loading={isLoading}
            rowKey={(record) => record.id}
            scroll={{ x: '2000px', y: tableHeight }}
            pagination={false}
          ></Table>
        </div>
        {/* <div className={styles.subPagination}>
          <Pagination
            current={pageIndex}
            showSizeChanger={true}
            pageSize={pageSize}
            total={total}
            showTotal={(total) => `总共 ${total} 条`}
            onChange={onChange}
          />
        </div> */}
      </div>
      <EditBandLimit
        type={type}
        info={curInfo}
        onOk={handleEditOk}
        onCancel={handleEditCancel}
      />
    </>
  );
};

export default BandLimit;
