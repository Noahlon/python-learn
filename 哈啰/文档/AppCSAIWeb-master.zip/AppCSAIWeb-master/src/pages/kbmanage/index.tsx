import React, { FC, useEffect, useState } from 'react';
import {
  Button,
  Modal,
  Space,
  Table,
  Typography,
  Form,
  Input,
  Popconfirm,
  // message,
  Select,
} from 'antd';
// import { Link } from 'umi';z
import moment from 'moment';
import styles from './index.less';

const { Option } = Select;

interface IKBs {
  kbGuid: string;
  author: string;
  kbName: string;
  updateTime: string;
  businessType: number;
  description: string;
}
const KBManage: FC = () => {
  const [form] = Form.useForm();
  const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  };
  const { TextArea } = Input;
  const column = [
    {
      title: '知识库名称',
      dataIndex: 'kbName',
      key: 'kbName',
      // render: function kbName(text: string, record: IKBs) {
      //   return (
      //     <Link
      //       to={{
      //         pathname: `/kbconfig/${record?.kbGuid}`,
      //         search: `?title=${record?.kbName}&businessType=${record?.businessType}`,
      //       }}
      //     >
      //       {text}
      //     </Link>
      //   );
      // },
    },
    {
      title: '更新者',
      dataIndex: 'author',
      key: 'author',
    },
    {
      title: '最近更新时间',
      dataIndex: 'updateTime',
      key: 'updateTime',
      render: (text: string) => moment(text).format('YYYY.MM.DD HH:mm:ss'),
    },
    {
      title: '操作',
      dataIndex: 'guid',
      key: 'guid',
      render: function operation(text: string, record: IKBs) {
        return (
          <Space direction="horizontal">
            {
              <Typography.Link
                onClick={() =>
                  // eslint-disable-next-line @typescript-eslint/no-use-before-define
                  handlerGetDetail(
                    record?.kbGuid,
                    record?.kbName,
                    record?.businessType,
                    record?.description,
                    1,
                  )
                }
              >
                编辑
              </Typography.Link>
            }
            {
              <Popconfirm
                title="是否确认删除该知识库？"
                // eslint-disable-next-line @typescript-eslint/no-use-before-define
                onConfirm={() => handlerDelete(record?.kbGuid)}
              >
                <Typography.Link>删除</Typography.Link>
              </Popconfirm>
            }
          </Space>
        );
      },
    },
  ];
  const [tableData, setTableData] = useState<IKBs[]>([]);
  const [isLoading, setLoading] = useState<boolean>(false);
  const [isModalOpen, setModalOpen] = useState<boolean>(false);
  // 0查看 1编辑 2新增
  const [modalType, setModalType] = useState<number>(0);
  // const [kbId, setKbId] = useState<string>('');
  const [busType, setBusType] = useState<number>();
  const [businessTypeList, setBusinessTypeList] = useState<any[]>([]);

  const handlerUpdate = () => {
    form.validateFields().then(() => {
      // const param = {
      //   kbName: val?.name,
      //   businessType: val?.businessType,
      //   description: val?.description,
      // };
      // const action = modalType === 2 ? addKB : editKB;
      // if (modalType === 1) {
      //   param.kbGuid = kbId;
      // }
      //   action(param)
      //     .then((data: IBooleanRes) => {
      //       if (data?.data) {
      //         message.success('操作成功');
      //         handlerGetLists();
      //         setModalOpen(false);
      //         form.setFieldsValue({ name: '', businessType: undefined, description: '' });
      //       } else {
      //         // message.error(data?.info ? data?.info : '操作失败');
      //       }
      //     })
      //     .catch((e) => e);
    });
  };
  const handlerGetDetail = (
    guid: string,
    kbName: string,
    businessType: number,
    description: string,
    type: number,
  ) => {
    setModalType(type);
    // setKbId(guid);
    setBusType(businessType);
    form.setFieldsValue({ name: kbName, businessType, description });
    setModalOpen(true);
  };
  const handlerDelete = async (guid: string) => {
    // const data = await deleteKB({ kbGuid: guid });
    console.log(guid);
  };
  const handlerGetLists = async () => {
    setLoading(true);
    const data = [
      {
        author: '李东明',
        authorId: 'lidongming999@hellobike.com',
        businessType: 6,
        description: '人工服务-顺风车',
        kbGuid: '909372364279828480',
        kbName: '人工服务-顺风车',
        updateTime: '2022-11-14T17:21:06.966931000',
      },
      {
        author: '刘雄锋',
        authorId: 'liuxiongfeng09129@hellobike.com',
        businessType: 301,
        description: '臻有钱',
        kbGuid: '907915371476209664',
        kbName: 'w-臻有钱',
        updateTime: '2022-11-10T16:51:32.812769000',
      },
      {
        author: '王超',
        authorId: 'wangchao149@hellobike.com',
        businessType: 40,
        description: '租车售前知识库',
        kbGuid: '905720239369134080',
        kbName: '租车售前知识库',
        updateTime: '2022-11-04T15:28:52.537311000',
      },
      {
        author: '张天基',
        authorId: 'zhangtianji621@hellobike.com',
        businessType: 201,
        description: '智能服务-政委',
        kbGuid: '905389089127452672',
        kbName: '智能服务-政委',
        updateTime: '2022-11-03T17:33:00.169234000',
      },
      {
        author: '许良妍',
        authorId: 'xuliangyan11262@hellobike.com',
        businessType: -99,
        description: '11',
        kbGuid: '897827655338217472',
        kbName: '测试111',
        updateTime: '2022-10-13T20:46:33.864349000',
      },
      {
        author: '陈世林',
        authorId: 'lianfengbinwb326@hellobike.com',
        businessType: 1,
        description: '测试',
        kbGuid: '831362584179224576',
        kbName: '测试test',
        updateTime: '2022-09-29T06:48:49.558013000',
      },
      {
        author: '张天基',
        authorId: 'zhangtianji621@hellobike.com',
        businessType: 1001,
        description: '智能服务-小品牌',
        kbGuid: '884366931156467712',
        kbName: '智能服务-小品牌',
        updateTime: '2022-09-06T17:36:28.534285000',
      },
      {
        author: '金会娟',
        authorId: 'zhangtianji621@hellobike.com',
        businessType: 20,
        description: '智能服务-电动车-售前',
        kbGuid: '875633278007164928',
        kbName: '智能服务-电动车-售前',
        updateTime: '2022-09-05T14:13:31.970325000',
      },
      {
        author: '张天基',
        authorId: 'fangyingying165@hellobike.com',
        businessType: -99,
        description: '客服系统消息触达用户',
        kbGuid: '856365968179666944',
        kbName: '测试1',
        updateTime: '2022-09-02T10:26:46.866954000',
      },
      {
        author: '张天基',
        authorId: 'zhangtianji621@hellobike.com',
        businessType: 60,
        description: '智能服务-婚恋',
        kbGuid: '871639762121834496',
        kbName: '智能服务-婚恋',
        updateTime: '2022-08-02T14:34:07.729292000',
      },
      {
        author: '李伟',
        authorId: 'liwei268@hellobike.com',
        businessType: 14,
        description: 'xxx',
        kbGuid: '869854869030490112',
        kbName: '真有钱服务引导',
        updateTime: '2022-07-29T13:55:45.354090000',
      },
      {
        author: '李伟',
        authorId: 'liwei268@hellobike.com',
        businessType: 18,
        description: 'ss',
        kbGuid: '869856041857617920',
        kbName: '火车票服务引导',
        updateTime: '2022-07-28T16:17:21.527980000',
      },
      {
        author: '李伟',
        authorId: 'liwei268@hellobike.com',
        businessType: 23,
        description: '休息休息',
        kbGuid: '869851826863116288',
        kbName: '酒店服务引导',
        updateTime: '2022-07-28T16:00:36.596825000',
      },
      {
        author: '李伟',
        authorId: 'zhangtianji621@hellobike.com',
        businessType: 58,
        description: '充值服务引导',
        kbGuid: '856430972213338112',
        kbName: '充值服务引导',
        updateTime: '2022-07-28T15:56:52.773552000',
      },
      {
        author: '奚小虎',
        authorId: 'xixiaohu086@hellobike.com',
        businessType: 4,
        description: '数据库测试',
        kbGuid: '843731735963213824',
        kbName: '测试23732477',
        updateTime: '2022-05-17T14:08:41.636470000',
      },
      {
        author: '李世杰',
        authorId: 'lishijie070@hellobike.com',
        businessType: 1,
        description: '测试',
        kbGuid: '842282396078157824',
        kbName: '测试知识库070',
        updateTime: '2022-05-13T14:09:32.076827000',
      },
      {
        author: '张天基',
        authorId: 'zhangtianji621@hellobike.com',
        businessType: 27,
        description: '哈啰好物知识库',
        kbGuid: '811837297363771392',
        kbName: '哈啰好物',
        updateTime: '2022-05-10T11:22:39.436814000',
      },
      {
        author: '徐福洲',
        authorId: 'xufuzhou706@hellobike.com',
        businessType: 6,
        description: '顺风车服务引导判责流程',
        kbGuid: '833691777955328000',
        kbName: '顺风车服务引导',
        updateTime: '2022-04-19T21:13:29.110677000',
      },
      {
        author: '徐福洲',
        authorId: 'xufuzhou706@hellobike.com',
        businessType: 1,
        description: '通用服务引导判责流程',
        kbGuid: '833690547560443904',
        kbName: '通用服务引导',
        updateTime: '2022-04-19T21:08:35.761283000',
      },
      {
        author: '徐福洲',
        authorId: 'xufuzhou706@hellobike.com',
        businessType: 4,
        description: '助力车服务引导判责流程',
        kbGuid: '833690342383480832',
        kbName: '助力车服务引导',
        updateTime: '2022-04-19T21:07:46.843063000',
      },
      {
        author: '徐福洲',
        authorId: 'xufuzhou706@hellobike.com',
        businessType: 1,
        description: '单车服务引导判责流程',
        kbGuid: '833689989002670080',
        kbName: '单车服务引导',
        updateTime: '2022-04-19T21:06:22.591249000',
      },
      {
        author: '张天基',
        authorId: 'zhangtianji621@hellobike.com',
        businessType: 43,
        description: '小哈能量站知识库',
        kbGuid: '830712828908462080',
        kbName: '小哈能量站',
        updateTime: '2022-04-19T20:26:00.936301000',
      },
      {
        author: '张天基',
        authorId: 'zhangtianji621@hellobike.com',
        businessType: 1,
        description: '电池知识库-测试阶段',
        kbGuid: '832149313656041472',
        kbName: '电池知识库',
        updateTime: '2022-04-15T15:04:16.965174000',
      },
      {
        author: '张天基',
        authorId: 'zhangtianji621@hellobike.com',
        businessType: 4,
        description: '用于人工服务引导的知识库',
        kbGuid: '831826498050437120',
        kbName: '人工服务引导知识库-勿动',
        updateTime: '2022-04-14T17:41:31.726317000',
      },
      {
        author: '张天基',
        authorId: 'zhangtianji621@hellobike.com',
        businessType: 40,
        description: '租车对应的知识库',
        kbGuid: '736827389341990912',
        kbName: '租车机器人-知识库',
        updateTime: '2022-04-11T17:45:32.635084000',
      },
      {
        author: '郑琳琳',
        authorId: 'yuanjiasi04767@hellobike.com',
        businessType: 1,
        description: '测试1648868541469',
        kbGuid: '827377389334347776',
        kbName: '测试1648868541469',
        updateTime: '2022-04-06T19:40:48.316556000',
      },
      {
        author: '刘鼎亮',
        authorId: 'liudingliang821@hellobike.com',
        businessType: 6,
        description: '语音机器人2.0回归',
        kbGuid: '823850907858362368',
        kbName: '语音知识库-顺风车乘客',
        updateTime: '2022-03-23T17:29:22.843143000',
      },
      {
        author: '刘鼎亮',
        authorId: 'liudingliang821@hellobike.com',
        businessType: 6,
        description: '语音机器人2.0回归',
        kbGuid: '823849911222185984',
        kbName: '语音知识库-顺风车车主',
        updateTime: '2022-03-23T17:26:57.237567000',
      },
      {
        author: '刘鼎亮',
        authorId: 'zhuxianlu288@hellobike.com',
        businessType: 1,
        description: '语音知识库回归-单车',
        kbGuid: '803091481631764480',
        kbName: '语音知识库-单车',
        updateTime: '2022-03-22T12:06:22.478032000',
      },
      {
        author: '刘鼎亮',
        authorId: 'liudingliang821@hellobike.com',
        businessType: 4,
        description: '语音机器人2.0回归',
        kbGuid: '823401864350916608',
        kbName: '语音知识库-助力车',
        updateTime: '2022-03-22T11:45:02.530392000',
      },
      {
        author: '王振乐',
        authorId: 'wangzhenlewb189@hellobike.com',
        businessType: 4,
        description: '23',
        kbGuid: '821673692181815296',
        kbName: '测试',
        updateTime: '2022-03-17T17:17:54.178169000',
      },
      {
        author: '张双福',
        authorId: 'zhangshuangfu06858@hellobike.com',
        description: '人事机器人导入',
        kbGuid: '794091814425890816',
        kbName: '人事机器人导入',
        updateTime: '2021-12-31T10:36:15.048871000',
      },
      {
        author: '王振乐',
        authorId: 'system-init',
        businessType: 1,
        description: '单车训练1.0',
        kbGuid: '5e6f4b41ce6853000962b20c',
        kbName: '单车训练1.0-知识库',
        updateTime: '2021-12-28T17:19:22.891583000',
      },
      {
        author: '系统初始化',
        kbGuid: '60b591b90694e100082fcedb',
        kbName: '哈啰打车-乘客1.1',
        updateTime: '2021-06-18T10:59:17.272468000',
      },
      {
        author: '系统初始化',
        kbGuid: '60b587f8ce68530008461bd8',
        kbName: '哈啰打车-车主1.1',
        updateTime: '2021-06-18T10:54:59.329965000',
      },
      {
        author: '郑梦萍',
        authorId: 'a67493343352471781f5f8c01f4cd7d8',
        description: '哈啰打车-乘客1.0',
        kbGuid: '5f8d4e49ce68530008bd3869',
        kbName: '哈啰打车-乘客1.0-知识库',
        updateTime: '2021-06-02T15:07:19.320386000',
      },
      {
        author: '系统初始化',
        authorId: 'system-init',
        description: '哈啰快送1.0',
        kbGuid: '5ea15d9f0694e10008a76ecf',
        kbName: '哈啰快送1.0-知识库',
        updateTime: '2021-05-30T16:08:29.753091000',
      },
      {
        author: '系统初始化',
        authorId: 'system-init',
        description: '电动车机器人1.0',
        kbGuid: '5e69a718ce68530009567961',
        kbName: '电动车机器人1.0-知识库',
        updateTime: '2021-05-30T16:08:29.730382000',
      },
      {
        author: '系统初始化',
        authorId: 'system-init',
        description: '生活馆训练',
        kbGuid: '5cda6a570694e10009239b2f',
        kbName: '生活馆训练-知识库',
        updateTime: '2021-05-30T16:08:29.708337000',
      },
      {
        author: '系统初始化',
        authorId: 'system-init',
        description: '换电训练',
        kbGuid: '5d5b840cce6853000819f063',
        kbName: '换电训练-知识库',
        updateTime: '2021-05-30T16:08:29.685138000',
      },
      {
        author: '系统初始化',
        authorId: 'system-init',
        description: '乘客的顺风车1.0',
        kbGuid: '5e201a100694e10008b6096d',
        kbName: '乘客的顺风车1.0-知识库',
        updateTime: '2021-05-30T16:08:29.660549000',
      },
      {
        author: '系统初始化',
        authorId: 'system-init',
        description: '车主的顺风车1.0',
        kbGuid: '5e212dcace685300083b0829',
        kbName: '车主的顺风车1.0-知识库',
        updateTime: '2021-05-30T16:08:29.640345000',
      },
      {
        author: '系统初始化',
        authorId: 'system-init',
        description: '景区机器人',
        kbGuid: '5f912617ce68530008ca7b7f',
        kbName: '景区机器人-知识库',
        updateTime: '2021-05-30T16:08:29.617350000',
      },
      {
        author: '系统初始化',
        authorId: 'system-init',
        description: '哈啰打车-车主1.0',
        kbGuid: '5f8d4e64ce68530008bd3911',
        kbName: '哈啰打车-车主1.0-知识库',
        updateTime: '2021-05-30T16:08:29.592911000',
      },
      {
        author: '系统初始化',
        authorId: 'system-init',
        description: '助力车机器人1.0',
        kbGuid: '5e57824fce6853000934ac4e',
        kbName: '助力车机器人1.0-知识库',
        updateTime: '2021-05-30T16:08:29.570903000',
      },
      {
        author: '系统初始化',
        authorId: 'system-init',
        description: '智巡机器人',
        kbGuid: '5f812c9d0694e10008517afc',
        kbName: '智巡机器人-知识库',
        updateTime: '2021-05-30T16:08:29.548988000',
      },
    ];
    if (data && data.length) {
      setTableData(data as IKBs[]);
    } else {
      setTableData([]);
    }
    setLoading(false);
  };

  const handlerBusinessList = async () => {
    // const res = {};
    setBusinessTypeList([]);
    // if (res.data && res.data.length) {
    //   setBusinessTypeList(res.data)
    // } else {
    //   setTableData([])
    // }
    // Array.isArray(res.data) ? setBusinessTypeList(res.data) : setTableData([]);
  };

  useEffect(() => {
    handlerGetLists();
    handlerBusinessList();
  }, []);
  return (
    <>
      <div className={styles.header}>
        <span className={styles.title}>知识库管理</span>
        <Button
          type="primary"
          className={styles.btn}
          onClick={() => {
            setModalType(2);
            setModalOpen(true);
          }}
        >
          新建知识库
        </Button>
      </div>
      <Table
        columns={column}
        dataSource={tableData}
        loading={isLoading}
        rowKey={(record) => record.kbGuid}
        pagination={false}
      ></Table>
      <Modal
        title={
          modalType === 2
            ? '新增知识库'
            : modalType === 1
            ? '编辑知识库'
            : '查看知识库'
        }
        open={isModalOpen}
        footer={modalType === 0 ? null : undefined}
        onOk={handlerUpdate}
        onCancel={() => {
          setModalOpen(false);
          // setKbId('');
          form.setFieldsValue({
            name: '',
            businessType: undefined,
            description: '',
          });
        }}
        width={'540px'}
        getContainer={false}
      >
        <Form form={form} {...layout}>
          <Form.Item
            label="知识库名称"
            name="name"
            rules={[{ required: true }]}
          >
            <Input maxLength={20} placeholder="请输入知识库名称，限制20字" />
          </Form.Item>
          <Form.Item
            label="所属租户"
            name="businessType"
            rules={[{ required: true }]}
          >
            <Select
              showSearch
              placeholder="请选择业务线"
              disabled={modalType === 1 && !!busType}
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
            >
              {businessTypeList?.map((data) => (
                <Option value={data.businessType} key={data.classifyId}>
                  {data.classifyName}
                </Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item
            label="业务线"
            name="businessType"
            rules={[{ required: true }]}
          >
            <Select
              showSearch
              placeholder="请选择业务线"
              disabled={modalType === 1 && !!busType}
              getPopupContainer={(triggerNode) =>
                triggerNode.parentElement || document.body
              }
            >
              {businessTypeList?.map((data) => (
                <Option value={data.businessType} key={data.classifyId}>
                  {data.classifyName}
                </Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item
            label="知识库描述"
            name="description"
            rules={[{ required: true }]}
          >
            <TextArea
              rows={4}
              maxLength={200}
              placeholder="请输入知识库说明，限制200字"
              showCount
            ></TextArea>
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};
export default KBManage;
