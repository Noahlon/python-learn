import React from 'react';
import { Tabs } from 'antd';

import styles from './index.less';
import FollowForm from './component/FollowForm';
import FollowNode from './component/FollowNode';

const FollowConfiguration: React.FC = () => {
  return (
    <>
      <div className={styles.outWrapFollowConfiguration}>
        <Tabs
          defaultActiveKey="1"
          destroyInactiveTabPane
          items={[
            {
              label: '跟进表单',
              key: '1',
              children: <FollowForm></FollowForm>,
            },
            {
              label: '跟进节点',
              key: '2',
              children: <FollowNode></FollowNode>,
            },
          ]}
        />
      </div>
    </>
  );
};

export default FollowConfiguration;
