import { notification } from 'antd';
import React from 'react';
import { SortableHandle } from 'react-sortable-hoc';
import { MenuOutlined } from '@ant-design/icons';

const DragHandle = SortableHandle(() => (
  <MenuOutlined style={{ cursor: 'grab', color: '#999' }} />
));

export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 100,
};

export const openNotificationWithIcon = (successMsg: string) => {
  notification['success']({
    message: '操作成功',
    description: successMsg,
  });
};

export const column: any = [
  {
    title: null,
    dataIndex: 'sort',
    fixed: 'left',
    className: 'drag-visible',
    width: '20%',
    render: () => <DragHandle />,
  },
  {
    title: null,
    fixed: 'left',
    dataIndex: 'nodeName',
    key: 'nodeName',
    ellipsis: true,
  },
  {
    title: null,
    dataIndex: 'operation',
    key: 'operation',
    align: 'center',
    width: '20%',
  },
];
