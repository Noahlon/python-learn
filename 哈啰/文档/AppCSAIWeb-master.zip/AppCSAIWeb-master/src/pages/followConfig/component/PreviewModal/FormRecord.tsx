import { Form } from 'antd';
import React, { useEffect, useState } from 'react';
import { useForm } from 'antd/lib/form/Form';
import { v1 as uuidv1 } from 'uuid';
import { PREVIEWFORMTYPE, renderItems } from './config';
import { FollowRecordRes } from '@/api/project/nameInfo';

interface IProps {
  currentFormData?: FollowRecordRes['data'][0]['formFields'];
}

const FormRecord: React.FC<IProps> = (props) => {
  const { currentFormData } = props;
  const [form] = useForm();
  const [formData, setFormData] = useState<
    FollowRecordRes['data'][0]['formFields']
  >([]);

  // fieldOptionList转化为options
  const formatOptions = (formData) => {
    formData?.forEach((item: any) => {
      const isFlag = [PREVIEWFORMTYPE.RADIO, PREVIEWFORMTYPE.CHECKBOX].includes(
        item.fieldType,
      );
      if (isFlag) {
        const list: string[] = [];
        item?.fieldOptionList?.forEach((subItem) => {
          const data: any = {
            label: subItem,
            value: subItem,
          };
          list.push(data);
        });
        item.options = list;
      }
    });
  };

  useEffect(() => {
    if (currentFormData?.length) {
      formatOptions(currentFormData);
      setFormData(currentFormData);
    }
  }, [currentFormData]);

  return (
    <Form colon={true} form={form} layout="vertical">
      {formData.map((item, index) => {
        return (
          <div key={uuidv1()}>
            {/* {item.fieldName} */}
            {renderItems(
              item.fieldType,
              item.fieldName,
              item.fieldName,
              item?.options,
              item?.fieldValues,
              item?.fieldValue,
              index + 1,
            )}
          </div>
        );
      })}
    </Form>
  );
};

export default FormRecord;
