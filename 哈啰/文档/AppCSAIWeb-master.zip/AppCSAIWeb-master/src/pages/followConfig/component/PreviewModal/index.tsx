import { Form, Modal } from 'antd';
import React, { useEffect, useState } from 'react';
import { useForm } from 'antd/lib/form/Form';
import { v1 as uuidv1 } from 'uuid';
import { PREVIEWFORMTYPE, renderItems } from './config';
import { followFormPreview } from '@/api/followForm';
import styles from './index.less';
interface IProps {
  onClose?: () => void;
  formGuid?: string;
  currentFormData?: any;
  source?: number; //  来源1-项目1.0  2-2.0
}

const PreviewModal: React.FC<IProps> = (props) => {
  const { onClose, formGuid, currentFormData, source = 1 } = props;
  const [form] = useForm();
  const [formData, setFormData] = useState<any[]>([]);

  // fieldOptionList转化为options
  const formatOptions = (formData) => {
    formData?.forEach((item: any) => {
      const isFlag = [PREVIEWFORMTYPE.RADIO, PREVIEWFORMTYPE.CHECKBOX].includes(
        item.fieldType,
      );
      if (isFlag) {
        const list: string[] = [];
        item?.fieldOptionList?.forEach((subItem) => {
          const data: any = {
            label: subItem,
            value: subItem,
          };
          list.push(data);
        });
        item.options = list;
      }
    });
  };

  // 获取数据
  const getData = async () => {
    const args = { formGuid };
    if (source === 2) {
      Object.assign(args, {
        bpoVersion: 2,
      });
    }
    const res = await followFormPreview(args);
    if (res?.code === 0) {
      const formData = res?.data?.fieldList || [];
      formatOptions(formData);
      setFormData(formData);
    }
  };

  useEffect(() => {
    if (formGuid) {
      getData();
    }
  }, [formGuid]);

  useEffect(() => {
    if (currentFormData?.length) {
      formatOptions(currentFormData);
      setFormData(currentFormData);
    }
  }, [currentFormData]);

  return (
    <Modal
      open={!!formGuid || !!currentFormData}
      title={'预览'}
      forceRender={true}
      width={'550px'}
      getContainer={false}
      footer={null}
      onCancel={() => {
        onClose?.();
      }}
    >
      <Form
        colon={true}
        form={form}
        layout="vertical"
        className={styles.preView}
      >
        {formData.map((item, index) => {
          return (
            <div key={uuidv1()}>
              {/* {item.fieldName} */}
              {renderItems(
                item.fieldType,
                item.fieldName,
                item.fieldName,
                item?.options,
                item?.fieldValues,
                item?.fieldValue,
                index + 1,
              )}
            </div>
          );
        })}
      </Form>
    </Modal>
  );
};

export default PreviewModal;
