import React, { useEffect, useState, memo, useRef, useCallback } from 'react';
import { Card, Alert, Modal, Popover, Pagination, Spin, message } from 'antd';
import EditFormModal from '../EditFormModal';
import PreviewModal from '../PreviewModal';
import { useAccess } from '@umijs/max';
import styles from './index.less';
import { DEFAULT_QUERY_PARAMS } from '../EditFormModal/config';
import { formList, followFormDelete, formListPage } from '@/api/followForm';

const FollowForm: React.FC = () => {
  const access = useAccess();
  const [curModalInfo, setCurModalInfo] = useState<any>(undefined);
  const [curPreviewModalInfo, setPreviewCurModalInfo] =
    useState<any>(undefined);
  const [curModalType, setCurModalType] = useState<number>(undefined);
  const [tableData, setTableData] = useState<formList[]>([]);
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  const [tableLoading, setTableLoading] = useState(false);
  const [tableTotal, setTableTotal] = useState<number>();
  // 搜索params
  const queryParams = useRef(DEFAULT_QUERY_PARAMS);

  // fetch跟进表单列表
  const fetchFollowFormList = async () => {
    const params = {
      ...queryParams.current,
    };
    setTableLoading(true);
    try {
      const res = await formListPage(params);
      const { pageSize, pageNum, totalRecord, list } = res?.data;
      if (res?.code === 0) {
        setTableData(list);
        setTableTotal(totalRecord);
        queryParams.current = { ...queryParams.current, pageNum, pageSize };
        setPagination(queryParams.current);
      }
    } catch (error) {
      console.log('接口出错');
    }
    setTableLoading(false);
  };
  const editHanlder = (id: string) => {
    setCurModalType(1);
    setCurModalInfo(id);
  };
  const previewHanlder = (id: string) => {
    setPreviewCurModalInfo(id);
  };
  const createHandler = () => {
    setCurModalType(2);
  };
  const deleteHanlder = (id: string) => {
    Modal.confirm({
      title: '删除该跟进表单？',
      content: '删除后，数据无法恢复',
      okText: '确定',
      cancelText: '取消',
      async onOk() {
        const res = await followFormDelete({ formGuid: id });
        if (res?.success) {
          message.success('删除成功');
          fetchFollowFormList();
        }
      },
    });
  };

  const getClickBtn = (code: number, id: string) => {
    switch (code) {
      case 1:
        return (
          <div onClick={() => editHanlder(id)} className={styles.textBtn}>
            {'编辑'}
          </div>
        );
      case 2:
        return (
          <div onClick={() => previewHanlder(id)} className={styles.textBtn}>
            {'预览'}
          </div>
        );
      case 3:
        return (
          <div onClick={() => deleteHanlder(id)} className={styles.textBtn}>
            {'删除'}
          </div>
        );
    }
  };

  const getCardRender = useCallback(
    (id: string) => {
      const cardPoivthList = [];
      if (access?.authCodeList?.includes('Call-System-Follow-Form-Edit')) {
        cardPoivthList.push(getClickBtn(1, id));
      }
      cardPoivthList.push(getClickBtn(2, id));
      if (access?.authCodeList?.includes('Call-System-Follow-Form-Delete')) {
        cardPoivthList.push(getClickBtn(3, id));
      }
      return cardPoivthList;
    },
    [access?.authCodeList],
  );

  // 页面页数change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchFollowFormList();
  };
  //表单清空
  const onClose = () => {
    setCurModalType(undefined);
    setCurModalInfo(undefined);
    setPreviewCurModalInfo(undefined);
    // fetchFollowFormList();
  };
  const onOkEdit = () => {
    onClose();
    fetchFollowFormList();
  };
  useEffect(() => {
    fetchFollowFormList();
  }, []);
  return (
    <div className={styles.followFormOutWrap}>
      <Alert
        style={{ width: '98%', margin: '10px auto' }}
        message="配置提示"
        description="结合具体的业务场景，定义座席在外呼中需要记录的跟进信息，包括不限于用户基础信息、用户意愿等。"
        type="info"
        showIcon
      />
      <Spin spinning={tableLoading}>
        <div className={styles.followConfiguration}>
          {access?.authCodeList?.includes('Call-System-Follow-Form-Add') && (
            <Card hoverable className={styles.emptyBox} onClick={createHandler}>
              <span className={styles.txt}>+新增</span>
            </Card>
          )}

          {tableData?.map((item) => {
            return (
              <Card
                className={styles.contentCard}
                actions={getCardRender(item?.formGuid)}
                key={item.formGuid}
              >
                <div
                  className={`${styles.titleStatus} ${
                    item.status === 1 ? styles.on : styles.off
                  }`}
                >
                  {item.status === 1 ? '已启用' : '已禁用'}
                </div>
                <Popover
                  content={
                    <div className={styles.titleContent}>{item.formName}</div>
                  }
                  trigger="hover"
                  placement="top"
                >
                  <div className={`${styles.title} ellipsis2`}>
                    {item.formName}
                  </div>
                </Popover>
                <div className={styles.text}>
                  关联项目数：{item.projectCount}
                </div>
                <div className={styles.text}>字段信息：{item.fieldCount}个</div>
              </Card>
            );
          })}
        </div>
      </Spin>
      {tableData?.length > 0 && (
        <Pagination
          current={pagination.pageNum}
          showSizeChanger={true}
          pageSize={pagination.pageSize || 100}
          total={tableTotal}
          showTotal={(total) => `总共 ${total} 条`}
          onChange={handlePageChange}
          className={styles.paginationBox}
        />
      )}
      {curModalType && (
        <EditFormModal
          onClose={onClose}
          onOk={onOkEdit}
          info={curModalInfo}
          type={curModalType}
        ></EditFormModal>
      )}
      {curPreviewModalInfo && (
        <PreviewModal
          onClose={onClose}
          formGuid={curPreviewModalInfo}
        ></PreviewModal>
      )}
    </div>
  );
};

export default memo(FollowForm);
