import { Checkbox, DatePicker, Form, Input, Radio } from 'antd';
import { v1 as uuidv1 } from 'uuid';
const { RangePicker } = DatePicker;
const { TextArea } = Input;
import React from 'react';
import moment from 'moment';

/**
 *
 * 预览表单显示类型
 *
 * @enum {string}
 */
export enum PREVIEWFORMTYPE {
  /**单行文本 */
  INPUT = 'input',
  /**单选框 */
  RADIO = 'radio',
  /**多选框 */
  CHECKBOX = 'checkBox',
  /** 时间选择器 */
  TIMESELECT = 'timeSelect',
  /**多行文本 */
  TEXTAREA = 'textArea',
}

export interface previewFormData {
  type: string;
  label: string;
  name: string;
  value: string | number[];
  length?: number;
  options?: any;
  status: boolean;
}

export const renderItems = (
  type: string,
  label: string,
  name: string,
  options?: any,
  fieldValues?: any,
  fieldValue?: any,
  number?: number,
) => {
  switch (type) {
    case PREVIEWFORMTYPE.INPUT:
      return (
        <Form.Item
          label={`${number}、${label}:`}
          name={name}
          key={uuidv1()}
          initialValue={fieldValue}
        >
          <Input maxLength={80} />
        </Form.Item>
      );
    case PREVIEWFORMTYPE.RADIO:
      return (
        <Form.Item
          initialValue={fieldValue}
          label={`${number}、${label}:`}
          name={name}
          key={uuidv1()}
        >
          <Radio.Group options={options} optionType="button" />
        </Form.Item>
      );
    case PREVIEWFORMTYPE.CHECKBOX:
      return (
        <Form.Item
          initialValue={fieldValues}
          label={`${number}、${label}:`}
          name={name}
          key={uuidv1()}
        >
          <Checkbox.Group options={options} />
        </Form.Item>
      );
    case PREVIEWFORMTYPE.TIMESELECT:
      return (
        <Form.Item
          label={`${number}、${label}:`}
          name={name}
          key={uuidv1()}
          initialValue={
            fieldValues?.length === 2
              ? [moment(fieldValues[0]), moment(fieldValues[1])]
              : []
          }
        >
          <RangePicker
            style={{ width: '100%' }}
            placeholder={['开始', '结束']}
            showTime
          />
        </Form.Item>
      );
    case PREVIEWFORMTYPE.TEXTAREA:
      return (
        <Form.Item
          label={`${number}、${label}:`}
          name={name}
          key={uuidv1()}
          initialValue={fieldValue}
        >
          <TextArea rows={4} placeholder="请输入" maxLength={500} />
        </Form.Item>
      );
  }
};
