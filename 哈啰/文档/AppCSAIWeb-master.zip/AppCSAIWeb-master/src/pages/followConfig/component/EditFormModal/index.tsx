import {
  Button,
  Col,
  Drawer,
  Form,
  Input,
  Modal,
  Radio,
  Row,
  Space,
  Switch,
  Table,
  Typography,
  message,
  notification,
  Select,
} from 'antd';
import React, { useEffect, useState } from 'react';
import {
  column as baseColumn,
  selectShowSceneOpts,
  taskTransferOpts,
} from './config';
import styles from './index.less';
import useTableSort from '../../useTableSort';
import { debounce } from 'lodash';
import { v1 as uuidv1 } from 'uuid';
import { PREVIEWFORMTYPE } from '../PreviewModal/config';
import { SortableContainer, SortableElement } from 'react-sortable-hoc';
import {
  IFieldList,
  followFormDetails,
  followFormModify,
  projectsData,
} from '@/api/followForm';

interface IProps {
  onOk?: () => void;
  onClose?: () => void;
  info?: string;
  type: number;
}

const { Text } = Typography;
// type:number 1 编辑 2 新增
const EditFormModal: React.FC<IProps> = (props) => {
  const { onOk, onClose, info, type } = props;
  const [tableData, setTableData] = useState<IFieldList[]>([]);
  // 关联项目
  const [projects, setProjects] = useState<projectsData[]>([]);
  const [tableLoading, setTableLoading] = useState(false);
  const [tableType, setTableType] = useState<number>();
  const [mainEditForm] = Form.useForm();
  const [tableEditForm] = Form.useForm();
  const [phraseValue, setPhraseValue] = useState('');
  const [tagList, setTagList] = useState<string[]>([]);
  const [editModalLoading, setEditModalLoading] = useState<boolean>();
  const [curEditUnit, setCurEditUnit] = useState<IFieldList>();

  // 删除tag
  const handleEditClose = (removedTag: string) => {
    const newTags = tagList?.filter((tag) => tag !== removedTag);
    setTagList(newTags);
  };
  // 获取详情
  const getDetail = async () => {
    setTableLoading(true);
    const res = await followFormDetails({ formGuid: info });
    if (res?.code === 0) {
      setTableLoading(false);
      mainEditForm.setFieldsValue(res?.data);
      setTableData(res?.data?.fieldList);
      setProjects(res?.data?.projects);
    }
  };

  useEffect(() => {
    // 获取详情
    if (type === 1) {
      // 编辑
      getDetail();
    } else if (type === 2) {
      // 新增
      mainEditForm.setFieldValue('status', '1');
    }
  }, []);

  const columns = baseColumn.map((col) => {
    if (col.key === 'operation') {
      return {
        ...col,
        render: (_: any, record: IFieldList) => (
          <Button
            onClick={() => {
              setTagList(record?.fieldOptionList);
              tableEditForm.setFieldsValue(record);
              setTableType(1);
              setCurEditUnit(record);
            }}
            type="link"
          >
            编辑
          </Button>
        ),
      };
    } else if (col.key === 'status') {
      return {
        ...col,
        render: (_: any, record: IFieldList) => (
          <Switch
            checked={record.status === '1' ? true : false}
            onChange={() => {
              const newData = tableData?.map((item) => {
                if (item.fieldGuid === record.fieldGuid) {
                  if (item.status === '1') {
                    notification.success({
                      message: `操作成功`,
                      description: '已禁用字段在后续表单中将不再展示',
                      placement: 'topRight',
                    });
                  } else {
                    notification.success({
                      message: `操作成功`,
                      description: '已启用字段在后续表单中展示',
                      placement: 'topRight',
                    });
                  }
                  return { ...item, status: item.status === '0' ? '1' : '0' };
                }
                return item;
              });
              setTableData(newData);
            }}
          ></Switch>
        ),
      };
    }
    return col;
  });

  // 新增按钮
  const handleNewData = () => {
    setCurEditUnit({});
    setTableType(2);
  };

  // sort通道位置
  const sortEndCallback = async (arr) => {
    setTableData(arr);
  };
  // sort通道table component
  const getTableComponent = useTableSort(
    tableData,
    setTableData,
    sortEndCallback,
  );
  // 拖动
  const SortableItem = SortableElement(({ value }) => (
    <div className="formSortItem">
      <span className="formSortName">{value}</span>
      <span
        className="formSortItemclose"
        onClick={() => handleEditClose(value)}
      >
        x
      </span>
    </div>
  ));

  // 定义可拖动列表的容器组件
  const SortableList = SortableContainer(({ items }) => {
    return (
      <div className="formSort">
        {items.map((value, index) => (
          <SortableItem key={`item-${value}`} index={index} value={value} />
        ))}
      </div>
    );
  });
  const onSortEnd = ({ oldIndex, newIndex }) => {
    // eslint-disable-next-line prefer-destructuring, no-shadow
    const tagListData = JSON.parse(JSON.stringify(tagList));
    // eslint-disable-next-line prefer-destructuring
    tagListData[oldIndex] = tagListData.splice(
      newIndex,
      1,
      tagListData[oldIndex],
    )[0];
    setTagList(tagListData);
  };

  const handleEditTableOk = async () => {
    const param = await tableEditForm.validateFields();
    const _tableData =
      Object.prototype.toString.call(tableData) === '[object Array]'
        ? JSON.parse(JSON.stringify(tableData))
        : [];
    // 编辑
    const { fieldName, fieldType } = tableEditForm.getFieldsValue();
    if (tableType === 1) {
      const editData = _tableData?.map((item) => {
        if (item.fieldGuid === curEditUnit.fieldGuid) {
          const _label = selectShowSceneOpts.filter(
            (item) => item.value === fieldType || item.label === fieldType,
          )?.[0]?.label;
          return {
            ...item,
            fieldTypeDesc: _label,
            fieldName,
            fieldType,
            fieldOptionList: tagList,
          };
        }
        return item;
      });
      setTableData(editData);
      message.success('编辑成功');
    }
    // 新增
    else if (tableType === 2) {
      const isExist = _tableData.filter((item) => {
        return item.fieldName === fieldName;
      });
      if (isExist?.length) {
        message.error('表单下字段名称不允许重复');
        return false;
      }
      if (tableData?.length >= 200) {
        message.error('表单下最多添加200个字段');
        return;
      }
      const _label = selectShowSceneOpts.filter(
        (item) =>
          item.value === param.fieldType || item.label === param.fieldType,
      )?.[0]?.label;
      _tableData.push({
        fieldGuid: uuidv1(),
        ...param,
        status: '1',
        fieldOptionList: tagList,
        fieldTypeDesc: _label,
      });
      setTableData(_tableData);
      message.success('添加成功');
    }
    setCurEditUnit({});
    setTagList([]);
    setTableType(undefined);
    tableEditForm.resetFields();
  };

  // 创建选项值
  const createSelectItems = () => {
    if (!phraseValue) return;
    const _list = phraseValue?.split(/,|，/);
    const isExit = tagList.some((item: string) => item === phraseValue);
    if (isExit) {
      message.error('字段下选项值名称不允许重复');
      return;
    }
    if (tagList?.length >= 30) {
      message.error('添加失败，选项数量限制30个');
      return;
    }
    setTagList(
      Array.from(new Set([...tagList, ..._list?.filter((item) => !!item)])),
    );
    setTimeout(() => {
      setPhraseValue('');
    }, 50);
  };

  const tableComponent = getTableComponent();
  const getCurTypeTitle = (type: number) => {
    switch (type) {
      case 1:
        return '编辑';
      case 2:
        return '新增';
    }
  };
  const getDrawerClose = () => {
    mainEditForm?.resetFields();
    tableEditForm?.resetFields();
    setTableData([]);
    onClose?.();
  };

  const getSubmit = debounce(async () => {
    const paramForm = await mainEditForm.validateFields();
    if (!tableData.some((item) => item.status === '1')) {
      message.info('至少启用一个字段');
      return;
    }
    setEditModalLoading(true);
    let params = {
      ...paramForm,
      fieldList: tableData,
    };
    if (type === 1) {
      params.formGuid = info || '';
    }
    const res = await followFormModify(params);
    if (res?.code === 0) {
      notification.success({
        message: `操作成功`,
        description: '已同步更新项目的跟进表单',
        placement: 'topRight',
      });
      onOk?.();
    } else {
      setEditModalLoading(false);
    }
  }, 500);

  // 修改字段类型
  const setFieldType = (val: string) => {
    const data = { ...curEditUnit, fieldType: val };
    setTagList([]);
    setCurEditUnit(data);
  };

  return (
    <div className={styles.drawerWrap}>
      <Drawer
        title={getCurTypeTitle(type)}
        open={!!type}
        onClose={getDrawerClose}
        width={'40%'}
        footer={
          <Space>
            <Button onClick={getDrawerClose}>取消</Button>
            <Button
              onClick={getSubmit}
              loading={editModalLoading}
              type="primary"
            >
              确定
            </Button>
          </Space>
        }
        footerStyle={{ textAlign: 'right' }}
      >
        <Form
          form={mainEditForm}
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 14 }}
        >
          <Form.Item
            label="表单名称"
            name={'formName'}
            rules={[{ required: true }]}
          >
            <Input maxLength={30}></Input>
          </Form.Item>
          <Form.Item label="状态" name={'status'} rules={[{ required: true }]}>
            <Radio.Group options={taskTransferOpts} optionType="button" />
          </Form.Item>
          {type === 1 && (
            <Form.Item label="关联项目">
              <Space direction="vertical">
                {projects?.map((item) => {
                  return (
                    <Text strong key={item.projectGuid}>
                      {item.projectName}
                    </Text>
                  );
                })}
              </Space>
            </Form.Item>
          )}
        </Form>
        <div className={styles.line}></div>
        <Row justify={'space-between'} style={{ paddingTop: '12px' }}>
          <Col>字段信息({tableData?.length || 0})</Col>
          <Col>
            <Button onClick={handleNewData} type="primary">
              新增
            </Button>
          </Col>
        </Row>
        <div className={styles.tableContent} id="tableWrap">
          <Table
            columns={columns}
            dataSource={tableData}
            rowKey="fieldGuid"
            scroll={{ x: 'max-content', y: 520 }}
            loading={tableLoading}
            pagination={false}
            components={tableComponent}
            style={{ marginTop: '20px', height: '600px', overflowY: 'auto' }}
            size="small"
          />
        </div>
        <Modal
          open={!!tableType}
          title={getCurTypeTitle(tableType)}
          forceRender={true}
          width={'700px'}
          onOk={handleEditTableOk}
          onCancel={() => {
            tableEditForm.resetFields();
            setTableType(undefined);
            setTagList([]);
          }}
          getContainer={false}
        >
          <Form
            form={tableEditForm}
            labelCol={{ span: 4 }}
            wrapperCol={{ span: 14 }}
          >
            <Form.Item
              label="字段类型"
              rules={[{ required: true }]}
              name={'fieldType'}
            >
              <Select
                disabled={tableType === 1}
                onChange={(e) => setFieldType(e)}
                placeholder="请输入"
                options={selectShowSceneOpts}
              ></Select>
            </Form.Item>
            <Form.Item
              label="字段名称"
              rules={[{ required: true }]}
              name={'fieldName'}
            >
              <Input placeholder="请输入"></Input>
            </Form.Item>
            {((tableType && curEditUnit?.fieldType === PREVIEWFORMTYPE.RADIO) ||
              curEditUnit?.fieldType === PREVIEWFORMTYPE.CHECKBOX) && (
              <Form.Item label="选项值">
                <Row justify="space-around">
                  <Col span={21}>
                    <Input
                      placeholder="请输入"
                      value={phraseValue}
                      onChange={(e) => setPhraseValue(e.target.value.trim())}
                      onPressEnter={createSelectItems}
                      maxLength={30}
                    />
                  </Col>
                  <Col span={2} offset={1}>
                    <Button onClick={createSelectItems} type="primary">
                      添加
                    </Button>
                  </Col>
                </Row>
              </Form.Item>
            )}
            {!!tagList?.length && Array.isArray(tagList) && (
              <Form.Item
                label="选项值"
                labelCol={{ span: 0, offset: 0 }}
                wrapperCol={{ span: 18, offset: 4 }}
              >
                {/* {tagList?.map((item) => (
                  <Tag
                    key={item}
                    className={styles.tag}
                    closable
                    onClose={() => handleEditClose(item)}
                  >
                    {item}
                  </Tag>
                ))} */}
                {tagList && tagList.length > 0 && (
                  <SortableList
                    distance={2}
                    items={tagList}
                    axis={'xy'}
                    onSortEnd={onSortEnd}
                  />
                )}
              </Form.Item>
            )}
          </Form>
        </Modal>
      </Drawer>
    </div>
  );
};

export default EditFormModal;
