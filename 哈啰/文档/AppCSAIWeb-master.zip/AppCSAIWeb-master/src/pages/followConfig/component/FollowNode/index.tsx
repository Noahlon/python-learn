import React, { useEffect, useState, memo, useRef } from 'react';
import { Card, Alert, Modal, Popover, Pagination, Spin, message } from 'antd';
import styles from './index.less';
import EditNodeModal from '../EditNodeModal';
import { useAccess } from '@umijs/max';
import { DEFAULT_QUERY_PARAMS } from '../EditFormModal/config';
import {
  followNodeList,
  followNodeListPage,
  followNodeDeleteNodeSet,
} from '@/api/followForm';

const FollowNode: React.FC = () => {
  const access = useAccess();
  const [curModalInfo, setCurModalInfo] = useState<any>(undefined);
  const [curModalType, setCurModalType] = useState<number>(undefined);
  // eslint-disable-next-line
  const [tableData, setTableData] = useState<followNodeList[]>([]);
  const [pagination, setPagination] = useState({ ...DEFAULT_QUERY_PARAMS });
  // eslint-disable-next-line
  const [tableTotal, setTableTotal] = useState<number>();
  const [tableLoading, setTableLoading] = useState(false);

  // 搜索params
  const queryParams = useRef(DEFAULT_QUERY_PARAMS);

  // fetch跟进表单列表
  const fetchFollowNodeList = async () => {
    const params = {
      ...queryParams.current,
    };
    setTableLoading(true);
    try {
      const res = await followNodeListPage(params);
      const { pageSize, pageNum, totalRecord, list } = res?.data;
      if (res?.data) {
        setTableData(list);
        setTableTotal(totalRecord);
        queryParams.current = { ...queryParams.current, pageNum, pageSize };
        setPagination(queryParams.current);
      }
    } catch (error) {
      console.log('接口出错');
    }
    setTableLoading(false);
  };

  const editHanlder = (followNodeSetGuid: string) => {
    setCurModalType(1);
    setCurModalInfo(followNodeSetGuid);
  };

  const createHandler = () => {
    setCurModalType(2);
  };

  const deleteHanlder = (followNodeSetGuid: string) => {
    Modal.confirm({
      title: '删除该跟进节点集？',
      content: '删除后，数据无法恢复',
      okText: '确定',
      cancelText: '取消',
      onOk() {
        followNodeDeleteNodeSet({ followNodeSetGuid }).then((res) => {
          if (res?.code === 0) {
            message.success('删除成功!');
            fetchFollowNodeList();
          }
        });
      },
    });
  };

  const onClose = () => {
    setCurModalType(undefined);
    setCurModalInfo(undefined);
    fetchFollowNodeList();
  };
  const onOK = () => {
    setCurModalType(undefined);
    setCurModalInfo(undefined);
    fetchFollowNodeList();
  };

  const getClickBtn = (code: number, followNodeSetGuid: string) => {
    switch (code) {
      case 1:
        return (
          <div
            onClick={() => editHanlder(followNodeSetGuid)}
            className={styles.textBtn}
          >
            {'编辑'}
          </div>
        );
      case 2:
        return (
          <div
            onClick={() => deleteHanlder(followNodeSetGuid)}
            className={styles.textBtn}
          >
            {'删除'}
          </div>
        );
    }
  };

  const getCardRender = (followNodeSetGuid: string) => {
    const cardPoivthList = [];
    if (access?.authCodeList?.includes('Call-System-Follow-Node-Edit')) {
      cardPoivthList.push(getClickBtn(1, followNodeSetGuid));
    }
    if (access?.authCodeList?.includes('Call-System-Follow-Node-Delete')) {
      cardPoivthList.push(getClickBtn(2, followNodeSetGuid));
    }
    return cardPoivthList;
  };

  // 页面页数change
  const handlePageChange = (pageNum: number, pageSize?: number) => {
    const paginationObj = {
      pageNum,
      pageSize: pageSize ?? queryParams.current.pageSize,
    };
    queryParams.current = { ...queryParams.current, ...paginationObj };
    setPagination(paginationObj);
    fetchFollowNodeList();
  };

  useEffect(() => {
    fetchFollowNodeList();
  }, []);

  return (
    <div className={styles.followNodeOutWrap}>
      <Alert
        style={{ width: '98%', margin: '10px auto' }}
        message="配置提示"
        description="结合具体的业务场景，定义座席在跟进过程节点，例如在保险拉新场景中的跟进节点包括需求确认、产品介绍、意向确认、完成投保、售后跟进、续保提醒等。        "
        type="info"
        showIcon
      />
      <Spin spinning={tableLoading}>
        <div className={styles.followConfiguration}>
          {access?.authCodeList?.includes('Call-System-Follow-Node-Add') && (
            <Card hoverable className={styles.emptyBox} onClick={createHandler}>
              <span className={styles.txt}>+新增</span>
            </Card>
          )}
          {tableData.map((item: any) => {
            return (
              <Card
                key={item.followNodeSetGuid}
                className={styles.contentCard}
                actions={getCardRender(item.followNodeSetGuid)}
              >
                <Popover
                  content={
                    <div className={styles.titleContent}>
                      {item.followNodeSetName}
                    </div>
                  }
                  trigger="hover"
                  placement="top"
                >
                  <div className={`${styles.title} ellipsis2`}>
                    {item.followNodeSetName}
                  </div>
                </Popover>
                <div className={styles.text}>
                  关联项目数：{item.projectCount}
                </div>
                <div className={styles.text}>节点数：{item.nodeCount}个</div>
              </Card>
            );
          })}
        </div>
      </Spin>

      {tableData?.length > 0 && (
        <Pagination
          current={pagination.pageNum}
          showSizeChanger={true}
          pageSize={pagination.pageSize}
          total={tableTotal}
          showTotal={(total) => `总共 ${total} 条`}
          onChange={handlePageChange}
          className={styles.paginationBox}
        />
      )}
      {curModalType && (
        <EditNodeModal
          onClose={onClose}
          onOk={onOK}
          info={curModalInfo}
          type={curModalType}
        ></EditNodeModal>
      )}
    </div>
  );
};

export default memo(FollowNode);
