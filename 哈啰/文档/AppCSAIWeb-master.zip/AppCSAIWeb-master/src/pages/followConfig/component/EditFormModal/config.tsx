import { notification } from 'antd';
import React from 'react';
import { SortableHandle } from 'react-sortable-hoc';
import { MenuOutlined } from '@ant-design/icons';
import { PREVIEWFORMTYPE } from '../PreviewModal/config';
import { IFieldList } from '@/api/followForm';
import type { ColumnsType } from 'antd/es/table';

const DragHandle = SortableHandle(() => (
  <MenuOutlined style={{ cursor: 'grab', color: '#999' }} />
));

export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 10,
};

export const openNotificationWithIcon = (successMsg: string) => {
  notification['success']({
    message: '操作成功',
    description: successMsg,
  });
};

export const column: ColumnsType<IFieldList> = [
  {
    title: '',
    dataIndex: 'sort',
    fixed: 'left',
    className: 'drag-visible',
    width: 50,
    render: () => <DragHandle />,
  },
  {
    title: '字段名称',
    fixed: 'left',
    dataIndex: 'fieldName',
    key: 'fieldName',
    ellipsis: true,
  },
  {
    title: '类型',
    dataIndex: 'fieldTypeDesc',
    key: 'fieldTypeDesc',
    ellipsis: true,
  },
  {
    title: '值',
    dataIndex: 'fieldOptionList',
    key: 'fieldOptionList',
    ellipsis: true,
    align: 'center',
    render: (text: string | string[]) => {
      let renderTxt = '-';
      if (Array.isArray(text)) {
        renderTxt =
          text?.length === 0 ? '-' : text.join(',') ? text.join(',') : '-';
      } else {
        renderTxt = text ? text : '-';
      }
      return <div className="ellipsis1">{renderTxt}</div>;
    },
  },
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
    ellipsis: true,
  },
  {
    title: '操作',
    dataIndex: 'operation',
    key: 'operation',
    width: 80,
    fixed: 'right',
  },
];

export const selectShowSceneOpts = [
  { label: '单行文本', value: PREVIEWFORMTYPE.INPUT },
  { label: '复选框', value: PREVIEWFORMTYPE.CHECKBOX },
  { label: '多行文本', value: PREVIEWFORMTYPE.TEXTAREA },
  { label: '单选框', value: PREVIEWFORMTYPE.RADIO },
  { label: '时间选择器', value: PREVIEWFORMTYPE.TIMESELECT },
];

export const taskTransferOpts = [
  { label: '启用', value: '1' },
  { label: '禁用', value: '0' },
];
