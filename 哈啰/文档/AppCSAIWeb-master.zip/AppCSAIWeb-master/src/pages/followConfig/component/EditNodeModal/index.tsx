import {
  Button,
  Col,
  Drawer,
  Form,
  Input,
  Row,
  Space,
  Table,
  Popconfirm,
  Typography,
  message,
  notification,
} from 'antd';
import React, { useEffect, useState } from 'react';
import { column as baseColumn } from './config';
import useTableSort from '../../useTableSort';
import { v1 as uuidv1 } from 'uuid';
import { CloseCircleOutlined } from '@ant-design/icons';
import {
  followQueryDetailNodeSetGuid,
  followNodeAddNodeSet,
  projectsData,
  nodeListData,
} from '@/api/followForm';
import styles from './index.less';
interface IProps {
  onOk?: () => void;
  onClose?: () => void;
  info?: string;
  type: number;
}
const { Text } = Typography;

const EditNodeModal: React.FC<IProps> = (props) => {
  const { onOk, onClose, info, type } = props;
  const [tableData, setTableData] = useState([]);
  const [tableLoading, setTableLoading] = useState(false);
  const [mainEditForm] = Form.useForm();
  const [editModalLoading, setEditModalLoading] = useState<boolean>();
  const [nodeInput, setNodeInput] = useState<string>('');
  //关联项目
  const [projects, setProjects] = useState<projectsData[]>([]);
  const confirmDelete = (index: number) => {
    const _tableData = tableData.filter((_, i) => {
      return i !== index;
    });
    setTableData(_tableData); // 更新状态，触发组件重新渲染
    message.success('删除成功');
  };

  // 修改 columns 以包含 setTableType
  const columns = baseColumn.map((col) => {
    if (col.key === 'operation') {
      return {
        ...col,
        // eslint-disable-next-line
        render: (_: any, record: any, index) => (
          <Popconfirm
            icon={<CloseCircleOutlined style={{ color: 'red' }} />}
            title="你确定要删除这个节点吗？"
            onConfirm={() => {
              confirmDelete(index);
            }}
            okText="确定"
            cancelText="取消"
          >
            <Button type="link">删除</Button>
          </Popconfirm>
        ),
      };
    }
    return col;
  });

  // sort通道位置
  const sortEndCallback = (arr) => {
    setTableData(arr);
  };
  // sort通道table component
  const getTableComponent = useTableSort(
    tableData,
    setTableData,
    sortEndCallback,
  );

  const handleEditTableOk = async () => {
    if (tableData.length >= 50) {
      message.error('节点集下最多创建50个节点');
      return;
    }
    if (tableData.some((item) => item.nodeName === nodeInput)) {
      message.error('该节点名称已存在');
      return;
    }
    if (nodeInput === '') {
      message.info('请输入要添加的内容');
      return;
    }
    const _tableData = JSON.parse(JSON.stringify(tableData));
    _tableData.push({
      fieldGuid: uuidv1(),
      nodeName: nodeInput,
    });
    setNodeInput('');
    setTableData(_tableData);
    message.success('添加成功');
  };
  const tableComponent = getTableComponent();
  const getCurTypeTitle = (type: number) => {
    switch (type) {
      case 1:
        return '编辑';
      case 2:
        return '新增';
    }
  };
  const getDrawerClose = () => {
    mainEditForm?.resetFields();
    onClose?.();
  };

  const getSubmit = async () => {
    const values = await mainEditForm.validateFields();
    if (tableData.length === 0) {
      message.error('至少填写一个节点');
      return;
    }
    setEditModalLoading(true);
    let args = {
      ...values,
      nodeList: tableData,
    };
    if (type === 1) {
      args.followNodeSetGuid = info || '';
    }
    const res = await followNodeAddNodeSet(args);
    if (res?.code === 0) {
      notification.success({
        message: `操作成功`,
        description: '已同步更新项目的跟进节点',
        placement: 'topRight',
      });
      onOk?.();
      setEditModalLoading(false);
    } else {
      setEditModalLoading(false);
    }
  };

  const handleNodeInput = (e) => {
    setNodeInput(e.target.value);
  };
  // 获取节点详情
  const getDetail = async () => {
    setTableLoading(true);
    const res = await followQueryDetailNodeSetGuid({ followNodeSetGuid: info });
    if (res?.code === 0) {
      setTableLoading(false);
      const nodeList = res?.data.nodeList;
      // 新增一个filedGuid 控制拖动
      const newList = nodeList.map((item: nodeListData) => {
        return {
          ...item,
          fieldGuid: uuidv1(),
        };
      });
      setTableData(newList);
      mainEditForm.setFieldsValue(res?.data);
      setProjects(res?.data?.projects);
    }
  };

  useEffect(() => {
    if (type === 1) {
      getDetail();
    }
  }, [type]);

  return (
    <>
      <Drawer
        title={getCurTypeTitle(type)}
        open={!!type}
        onClose={getDrawerClose}
        width={'40%'}
        footer={
          <Space>
            <Button onClick={onClose}>取消</Button>
            <Button
              onClick={getSubmit}
              type="primary"
              loading={editModalLoading}
            >
              确定
            </Button>
          </Space>
        }
        footerStyle={{ textAlign: 'right' }}
      >
        <Form
          form={mainEditForm}
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 14 }}
        >
          <Form.Item
            label="节点集名称"
            name={'followNodeSetName'}
            rules={[{ required: true, message: '请输入节点名称' }]}
          >
            <Input maxLength={30}></Input>
          </Form.Item>
          <Form.Item label="关联项目" name={'relation'}>
            <Space direction="vertical">
              {projects?.map((item) => {
                return (
                  <Text strong key={item.projectGuid}>
                    {item.projectName}
                  </Text>
                );
              })}
            </Space>
          </Form.Item>
        </Form>
        <div className={styles.line}></div>
        <div className={styles.editInfo}>
          <Space style={{ paddingTop: '10px' }}>
            <span>字段信息({tableData.length})</span>
          </Space>
          <Row justify={'space-between'} style={{ padding: '10px 12px' }}>
            <Col span={20}>
              <Input
                placeholder="请输入"
                width={'400'}
                value={nodeInput}
                onChange={handleNodeInput}
                onPressEnter={handleEditTableOk}
              ></Input>
            </Col>
            <Col span={4} style={{ textAlign: 'center' }}>
              <Button onClick={handleEditTableOk} type="primary">
                新增
              </Button>
            </Col>
          </Row>
          <div className={styles.tableNodeContent} id="tableWrap">
            <Table
              columns={columns}
              dataSource={tableData}
              rowKey="fieldGuid"
              scroll={{ x: 'max-content', y: 500 }}
              loading={tableLoading}
              pagination={false}
              components={tableComponent}
              style={{ marginTop: '20px', height: '520px', overflowY: 'auto' }}
              bordered
              size="small"
            />
          </div>
        </div>
      </Drawer>
    </>
  );
};

export default EditNodeModal;
