import React from 'react';
import {
  SortableContainerProps,
  SortEnd,
  SortableContainer,
  SortableElement,
} from 'react-sortable-hoc';
import { arrayMoveImmutable } from 'array-move';

const useTableSort = (
  tableData,
  setTableData,
  sortEndCallback: (arr) => void,
) => {
  const SortableItem = SortableElement(
    (props: React.HTMLAttributes<HTMLTableRowElement>) => <tr {...props} />,
  );
  const SortableBody = SortableContainer(
    (props: React.HTMLAttributes<HTMLTableSectionElement>) => (
      <tbody {...props} />
    ),
  );

  // 拖动模块
  const onSortEnd = ({ oldIndex, newIndex }: SortEnd) => {
    if (oldIndex === newIndex) return;
    const newData = arrayMoveImmutable(
      tableData.slice(),
      oldIndex,
      newIndex,
    ).filter((el: any) => !!el);
    sortEndCallback?.(newData);
    setTableData(newData);
  };

  const DraggableContainer = (props: SortableContainerProps) => (
    <SortableBody
      useDragHandle
      disableAutoscroll
      helperClass="sortableHelper"
      onSortEnd={onSortEnd}
      {...props}
    />
  );

  const DraggableBodyRow: React.FC<any> = ({ ...restProps }) => {
    const index = tableData.findIndex(
      (x) => x.fieldGuid === restProps['data-row-key'],
    );
    return <SortableItem index={index} {...restProps} />;
  };

  const getTableComponent = () => {
    return tableData
      ? {
          body: {
            wrapper: DraggableContainer,
            row: DraggableBodyRow,
          },
        }
      : {};
  };

  return getTableComponent;
};
export default useTableSort;
