import React, { useEffect } from 'react';
import styles from './index.less';

const Report: React.FC = () => {
  console.log(REACT_APP_ENV);
  const _url = 'https://databox.hellobike.cn/#/aurora/9782';
  // if (REACT_APP_ENV === 'dev' || REACT_APP_ENV === 'fat') {
  //   _url = 'https://fat-databox.hellobike.cn/#/aurora/9782';
  // } else if (REACT_APP_ENV === 'uat') {
  //   _url = 'https://uat-databox.hellobike.cn/#/aurora/9782';
  // } else if (REACT_APP_ENV === 'pre') {
  //   _url = 'https://pre-databox.hellobike.cn/#/aurora/9782';
  // } else if (REACT_APP_ENV === 'pro') {
  //   _url = 'https://pro-databox.hellobike.cn/#/aurora/9782';
  // }
  //  onClick={() => history.push({pathname: '/home/444', query: { name: '11', age: '22' }})}
  useEffect(() => {
    // const iframe = document.createElement('iframe');
    // iframe.sandbox = "allow-same-origin allow-scripts allow-popups allow-forms";
    // iframe.className = styles.reportIframeWrap;
    // let state = 0;
    // iframe.onload = function() {
    //   if(state === 1) {
    //       // let data = JSON.parse(iframe.contentWindow.name);
    //       // console.log(data);
    //       // iframe.contentWindow.document.write('');
    //       // iframe.contentWindow.close();
    //     // document.body.removeChild(iframe);
    //     setTimeout(() => {
    //       const _head =
    //       iframe?.contentWindow?.name;
    //       console.log('1', _head);
    //       console.log('2', iframe?.contentWindow?.document.getElementById('app'));
    //       // if (_head?.length) {
    //       //   _head[0].style.display = 'none';
    //       // }
    //       //   // } catch (e) {}
    //     }, 5000);
    //   } else if(state === 0) {
    //     state = 1;
    //     iframe.contentWindow.location = 'http://localhost:8000/reportManage/report';
    //   }
    // };
    // iframe.src = 'https://databox.hellobike.cn/#/aurora/9782';
    // document.getElementById('reportWrap').appendChild(iframe);
    // setTimeout(() => {
    //   // try {
    //     // const _head = document.getElementById('reportIframeWrap')?.contentWindow?.document.getElementsByClassName(
    //     //     'navbar',
    //     //   );
    //     const _head =
    //       window.frames['reportIframeWrap']?.document.getElementsByClassName(
    //         'navbar',
    //       );
    //     console.log('1', _head);
    //     if (_head?.length) {
    //       _head[0].style.display = 'none';
    //     }
    //   // } catch (e) {}
    // }, 2000);
    // document.getElementById('reportIframeWrap').onload = function () {
    //   console.log(11111)
    //   try {
    //     const _head =
    //       window.frames['reportIframeWrap']?.document.getElementsByClassName(
    //         'navbar',
    //       );
    //     if (_head?.length) {
    //       console.log('2', _head[0]);
    //       _head[0].style.display = 'none';
    //     }
    //   } catch (e) {}
    // };
    // const iframe = document.getElementById('reportIframeWrap');
    // iframe.onload = function () {
    //   setTimeout(() => {
    //     console.log('进来了');
    //     const doc = window.frames['reportIframeWrap']?.document;
    //     console.log('1', doc);
    //     const ele = doc?.getElementsByClassName('navbar');
    //     console.log('2', ele);
    //     const _ele = doc?.querySelector('.navbar');
    //     console.log('3', _ele);
    //   }, 3000);
    // };
  }, []);

  return (
    <div className={styles.wrap} id="reportWrap">
      <iframe
        id="reportIframeWrap"
        name="reportIframeWrap"
        title="iframe"
        src={_url}
        sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
        scrolling="auto"
        className={styles.reportIframeWrap}
      ></iframe>
    </div>
  );
};

export default Report;
