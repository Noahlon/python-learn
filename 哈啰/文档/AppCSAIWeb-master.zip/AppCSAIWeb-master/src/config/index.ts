import moment from 'moment';

export const timeRanges: any = {
  今天: [
    moment('00:00:00', 'HH:mm:ss').startOf('day'),
    moment('23:59:59', 'HH:mm:ss'),
  ],
  昨天: [
    moment('00:00:00', 'HH:mm:ss').subtract(1, 'days'),
    moment('23:59:59', 'HH:mm:ss').subtract(1, 'days'),
  ],
  // 近三天: [
  //   moment('00:00:00', 'HH:mm:ss').subtract(2, 'days'),
  //   moment('23:59:59', 'HH:mm:ss'),
  // ],
  近一周: [
    moment('00:00:00', 'HH:mm:ss').subtract(6, 'days'),
    moment('23:59:59', 'HH:mm:ss'),
  ],
  近30天: [
    moment('00:00:00', 'HH:mm:ss').subtract(29, 'days'),
    moment('23:59:59', 'HH:mm:ss'),
  ],
  近60天: [
    moment('00:00:00', 'HH:mm:ss').subtract(59, 'days'),
    moment('23:59:59', 'HH:mm:ss'),
  ],
  近90天: [
    moment('00:00:00', 'HH:mm:ss').subtract(89, 'days'),
    moment('23:59:59', 'HH:mm:ss'),
  ],
  近180天: [
    moment('00:00:00', 'HH:mm:ss').subtract(179, 'days'),
    moment('23:59:59', 'HH:mm:ss'),
  ],
};

export const formatType = 'YYYY-MM-DD HH:mm:ss';
export const formatTypeDiagonal = 'YYYY/MM/DD HH:mm:ss';

export const DEFAULT_QUERY_PARAMS = {
  pageNum: 1,
  pageSize: 100,
};
