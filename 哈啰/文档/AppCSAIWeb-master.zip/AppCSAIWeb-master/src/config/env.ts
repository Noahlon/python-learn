type EnvConfig = {
  API_HOST: string;
  UPLOAD_API: string;
  API_KB_HOST: string;
  BFF_UPLOAD_LOGIN: string;
  AUDIO_RECORDER_URL: string;
};

type ApiEnvConfig = {
  API_HOST: string;
};

const config: Record<string, EnvConfig> = {
  dev: {
    API_HOST: 'https://fat-bff-admin.hellobike.cn/general/bffGeneralReqLogin',
    UPLOAD_API: 'https://fat-bff-admin.hellobike.cn/file/upload',
    BFF_UPLOAD_LOGIN:
      'https://fat-bff-admin.hellobike.cn/general/fileUploadLogin',
    API_KB_HOST: 'https://fat-cs-admin.hellobike.cn',
    AUDIO_RECORDER_URL: 'https://fat-aicc-audio-recorder.hellobike.cn',
  },
  fat: {
    API_HOST: 'https://fat-bff-admin.hellobike.cn/general/bffGeneralReqLogin',
    UPLOAD_API: 'https://fat-bff-admin.hellobike.cn/file/upload',
    BFF_UPLOAD_LOGIN:
      'https://fat-bff-admin.hellobike.cn/general/fileUploadLogin',
    API_KB_HOST: 'https://fat-cs-admin.hellobike.cn',
    AUDIO_RECORDER_URL: 'https://fat-aicc-audio-recorder.hellobike.cn',
  },
  uat: {
    API_HOST: 'https://uat-bff-admin.hellobike.cn/general/bffGeneralReqLogin',
    UPLOAD_API: 'https://uat-bff-admin.hellobike.cn/file/upload',
    BFF_UPLOAD_LOGIN:
      'https://uat-bff-admin.hellobike.cn/general/fileUploadLogin',
    API_KB_HOST: 'https://uat-cs-admin.hellobike.cn',
    AUDIO_RECORDER_URL: 'https://uat-aicc-audio-recorder.hellobike.cn',
  },
  pre: {
    API_HOST: 'https://pre-bff-admin.hellobike.cn/general/bffGeneralReqLogin',
    UPLOAD_API: 'https://pre-bff-admin.hellobike.cn/file/upload',
    BFF_UPLOAD_LOGIN:
      'https://pre-bff-admin.hellobike.cn/general/fileUploadLogin',
    API_KB_HOST: 'https://pre-css-admin.hellobike.cn',
    AUDIO_RECORDER_URL: 'https://pre-aicc-audio-recorder.hellobike.cn',
  },
  pro: {
    API_HOST: 'https://bff-admin.hellobike.cn/general/bffGeneralReqLogin',
    UPLOAD_API: 'https://bff-admin.hellobike.cn/file/upload',
    BFF_UPLOAD_LOGIN: 'https://bff-admin.hellobike.cn/general/fileUploadLogin',
    API_KB_HOST: 'https://css-admin.hellobike.cn',
    AUDIO_RECORDER_URL: 'https://aicc-audio-recorder.hellobike.com',
  },
} as const;

const apiConfig: Record<string, ApiEnvConfig> = {
  dev: {
    API_HOST: 'https://fat-im-api.hellobike.com',
  },
  fat: {
    API_HOST: 'https://fat-im-api.hellobike.com',
  },
  fat2: {
    API_HOST: 'https://fat-im-api.hellobike.com',
  },
  fat3: {
    API_HOST: 'https://fat-im-api.hellobike.com',
  },
  fat4: {
    API_HOST: 'https://fat-im-api.hellobike.com',
  },
  uat: {
    API_HOST: 'https://uat-im-api.hellobike.com',
  },
  pre: {
    API_HOST: 'https://pre-im-api.hellobike.com',
  },
  pro: {
    API_HOST: 'https://im-api.hellobike.com',
  },
} as const;

const CONFIGAPI = apiConfig[REACT_APP_ENV].API_HOST;

export { CONFIGAPI };

export default config[REACT_APP_ENV] || config.dev;
export const apiHost =
  apiConfig[REACT_APP_ENV].API_HOST || apiConfig.dev.API_HOST;
export const env = REACT_APP_ENV; // REACT_APP_ENV;
