import React from 'react';
import ssoAuth from '@hb/sso-auth2';
import { RunTimeLayoutConfig } from '@umijs/max';
import UBT from '@/utils/ubt';
import { env } from '@/config/env';

import './app.css';
import './assets/iconfont/iconfont.js';
import { InitialState } from './access';
import { getLoginUserInfo } from './api/user';
import ErrorBoundaryComponent from './errorBoundaryComponent';
import pkg from '../package.json';

export const layout: RunTimeLayoutConfig = () => {
  return {
    logo: 'https://m.hellobike.com/resource/helloyun/22121/MDFpu_lQLPDhtqG17XLrDNAsvNBcewm6V2DveGbTgCfoTOi4C7AA_1479_715.png?x-oss-process=image/quality,q_80',
    title: '外呼机器人',
    layout: 'side',
    fixedHeader: false,
    fixSiderbar: false,
    menu: { locale: false },
    token: {
      header: {
        colorBgHeader: '#fff',
        colorHeaderTitle: '#fff',
        colorTextMenu: '#dfdfdf',
        colorTextMenuSecondary: '#dfdfdf',
        colorTextMenuSelected: '#fff',
        colorBgMenuItemSelected: '#22272b',
        colorTextMenuActive: 'rgba(255,255,255,0.85)',
        colorTextRightActionsItem: '#dfdfdf',
      },
      colorTextAppListIconHover: '#fff',
      colorTextAppListIcon: '#dfdfdf',
      sider: {
        colorMenuBackground: '#292f33',
        colorMenuItemDivider: '#fff',
        colorBgMenuItemHover: '#08f',
        colorBgMenuItemSelected: '#08f',
        colorTextMenuItemHover: '#fff',
        colorTextMenuTitle: '#fff',
        colorTextMenu: '#fff',
        colorTextMenuSelected: '#fff',
        colorTextMenuActive: '#fff',
        colorBgMenuItemCollapsedHover: '#242424',
      },
    },
    breadcrumbRender: (routers = []) => [
      {
        path: '/',
        breadcrumbName: '外呼机器人',
      },
      ...routers,
    ],
    menuFooterRender: () => null,
    // menuItemRender: (logo, title) => {
    //   console.log(logo)
    //   return <div className="menuItem">
    //     <svg className="menuIcon" aria-hidden="true">
    //       <use xlinkHref={`#${logo}`}></use>
    //     </svg>
    //     {title}
    //   </div>
    // },
    footerRender: () => null,
    rightRender: () => <></>,
    ErrorBoundary: ErrorBoundaryComponent,
  };
};

// export function onRouteChange({ location, routes }) {
// const nowPath = routes[0].routes.filter(item => item.path === location.pathname)
//   const isLogin = localStorage.getItem('username')
//   //如果数组有值，有auth属性，并且没有登陆，就让它跳转到login页，并且附带跳转参数
//   if (nowPath.length === 1 && nowPath[0].auth && !isLogin) {
//       history.push({
//           pathname: '/login',
//           query: {
//               form: location.pathname
//           }
//       })
//   }
// }

export declare type ENV = 'dev' | 'fat' | 'uat' | 'pre' | 'pro';

export const render = async (oldRender: () => void): Promise<void> => {
  const res = await ssoAuth.signIn({
    clientId: 'AppCSAIWeb',
    clientSecret: '03698f5865c74205ba76efa77ff4712f',
  });
  try {
    // 初始化 tianqi 埋点
    UBT.config({
      env,
      debug: env !== 'pro', // 非生产环境都打开
      categoryId: 'iot',
    });

    UBT.bindData({
      appVersion: pkg.version,
      appName: pkg.name,
      userGuid: () => res?.guid,
    });
  } catch (e) {
    console.log(e);
  }
  oldRender();
};

// 运行时配置

// 全局初始化数据配置，用于 Layout 用户信息和权限初始化
// 更多信息见文档：https://next.umijs.org/docs/api/runtime-config#getinitialstate
export async function getInitialState(): Promise<InitialState> {
  // console.log(ssoAuth);
  // console.log(ssoAuth.userInfo);
  // console.log(ssoAuth.token);
  const data = await getLoginUserInfo();
  return { authCodeList: data || [] };
}
