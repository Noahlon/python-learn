import request from '@/utils/request';
import { apiHost } from '@/config/env';
import { ICommonResponse } from './baseInterface';

interface AddApiReq {
  serviceName: string;
  apiIllustrate: string;
  apiAction: string;
  apiIface: string;
  apiMethod: string;
  soaGroup?: string;
  soaTag?: string;
  requestParam?: any[];
  responseParam?: any[];
}
// 更新api
interface UpdateApiReq extends AddApiReq {
  guid: string;
}

export const updateApi = async (
  param: UpdateApiReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${apiHost}/gateway/api/update`, param);
  return res;
};

export const addApi = async (param: AddApiReq): Promise<ICommonResponse> => {
  const res = await request.post(`${apiHost}/gateway/api/add`, param);
  return res;
};
