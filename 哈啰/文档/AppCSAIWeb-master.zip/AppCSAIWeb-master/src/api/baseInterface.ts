export interface IPageRequest {
  pageIndex: number;
  pageSize: number;
}
export interface IResponse {
  info?: string;
  status: number;
  data?: unknown;
  success?: boolean;
}
export interface IPageResponse extends IResponse {
  data: unknown[];
  recordsCount: number;
}

export interface ICommonResponse {
  success?: boolean;
  status?: number;
  msg?: string;
  data?: any;
  code?: string | number;
}

export interface ICommonResponseList<T> extends ICommonResponse {
  data: {
    pageNum: number;
    pageSize: number;
    totalRecord: number;
    totalPages: number;
    list: T[];
  };
}

export interface IBasicResponse {
  status?: number;
  info?: string;
}
export interface IBooleanRes extends IResponse {
  success: any;
  data: boolean;
}
