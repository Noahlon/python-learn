import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface taskTemplatePageIList {
  guid?: string;
  name?: string;
  taskName?: string;
  exeStartTime?: string;
  exeEndTime?: string;
  autoRetry?: number;
  autoRetryDesc?: string;
  autoStartup?: number;
  autoStartupDesc?: string;
  remark?: string;
  ext?: string;
  tenant?: string;
  operator?: string;
  createBy?: string;
  createTime?: string;
  updateTime?: string;
  deleteFlag?: boolean;
  faqGuid?: string;
  groupId?: string;
  faqName?: string;
  expectLoadCount?: number;
  tenantName?: string;
  taskType?: number;
  transfer?: number;
  tenantLineGroupId?: string;
  tenantLineGroupCode?: string;
  tenantLineGroupName?: string;
  carrierAreaLimit?: ICarrierLimit4List[];
}

export interface ILongTaskStatistics {
  taskDate?: string;
  taskGuid?: number;
  tenantName?: string;
  taskName?: string;
  faqName?: string;
  taskStatus?: string;
  loadCount?: number;
  taskLoadCount?: number;
  uploadPhoneCount?: number;
  dailyExecutionCount?: number;
  dailyCallCount?: number;
  dailyCalledCount?: number;
  waitingCallNumber?: number;
  taskCompletionRate?: string;
  dailyPutCount?: number;
  dailyPutRate?: string;
  callComplete1?: string;
  callComplete2?: string;
  callComplete3?: string;
  dailySendSmsNumber?: number;
  dailySuccessSmsNumber?: number;
  dailyFailSmsNumber?: number;
  dailyUnknowSmsNumber?: number;
  dailySmsTriggerRate?: string;
  dailySmsSuccessRate?: string;
  dailySendSmsCount?: number;
  dailySmsSuccessCount?: number;
  dailySmsBillingCount?: string;
  dailyCallBillingCount?: string;
  dailyCallTime?: number;
  dailyAverageCallTime?: number;
  totalSecondsHang?: number;
  totalSecondsHangRate?: string;
  totalNoInteraction?: number;
  totalNoInteractionRate?: string;
  totalBlackList?: number;
  totalBlackListRate?: string;
  totalRateLimit?: number;
  totalRateLimitRate?: string;
  ruleIntercept?: number;
  ruleInterceptRate?: string;
  differentIntercept?: number;
  differentInterceptRate?: string;
  callDifferent1?: number;
  callDifferent1Rate?: string;
  totalIntentClassifyA?: number;
  totalIntentClassifyB?: number;
  totalIntentClassifyC?: number;
  totalIntentClassifyD?: number;
  totalIntentClassifyE?: number;
  totalIntentClassifyF?: number;
  totalIntentClassifyG?: number;
  totalIntentClassifyH?: number;
  totalIntentClassifyI?: string;
  totalIntentClassifyJ?: string;
  totalIntentClassifyARate?: string;
  totalIntentClassifyBRate?: string;
  totalIntentClassifyCRate?: string;
  totalIntentClassifyDRate?: string;
  totalIntentClassifyERate?: string;
  totalIntentClassifyFRate?: string;
  totalIntentClassifyGRate?: string;
  totalIntentClassifyHRate?: string;
  totalIntentClassifyIRate?: string;
  totalIntentClassifyJRate?: string;
  children?: [];
}

/* 自动生成的 Interface */

export interface taskTemplatePageRes extends ICommonResponse {
  pageNum?: number;
  pageSize?: number;
  totalRecord?: number;
  totalPages?: number;
  namelistNum?: number;
  list?: taskTemplatePageIList[];
}

export interface ITaskListReq {
  name?: string;
  faqName?: string;
  startTime?: string;
  endTime?: string;
  status?: number;
  pageNum: number;
  pageSize: number;
  statusList?: number[];
  statisticsWaitCount?: number;
  tenant?: string;
  tenantList?: number[];
  taskTypeList?: number[];
  multipleSmsLink?: number;
}

export interface ICarrierLimit4List {
  carrier?: number;
  carrierDesc?: string;
  provinceCount?: number;
  cityCount?: number;
}

export interface ITaskInfo {
  id?: string;
  guid?: string;
  name?: string;
  exeStartTime?: string;
  exeEndTime?: string;
  autoRetry?: number;
  autoRetryDesc?: string;
  autoStartup?: number;
  autoStartupDesc?: string;
  sourceType?: number;
  expectLoadCount?: number;
  ext?: string;
  tenant?: string;
  operator?: string;
  createBy?: string;
  templateGuid?: string;
  templateName?: string;
  createTime?: string;
  updateTime?: string;
  delete?: string;
  faqGuid?: string;
  faqName?: string;
  status?: number;
  statusDesc?: string;
  bizScene?: number;
  loadCount?: number;
  waitCallQuantity?: number;
  telephoneQuantity?: number;
  addNum?: number;
  callComplete1?: string;
  callComplete2?: string;
  callComplete3?: string;
  taskType: number;
  transfer: number;
  multipleSmsLinkDesc: string;
  tenantName: string;
  carrierAreaLimit?: ICarrierLimit4List[];
  tenantLineGroupName?: string;
}

export interface ITaskInfoRes {
  pageNum: number;
  pageSize: number;
  totalRecord: number;
  totalPages: number;
  list: ITaskInfo[];
  namelistNum?: number;
}

export interface ILongTaskStatisticsoRes {
  pageNum: number;
  pageSize: number;
  totalRecord: number;
  list: ILongTaskStatistics[];
}

export interface ITaskProcessInfoReq {
  taskGuid?: string;
  faqGuid?: string;
}

export interface ITaskProcessInfo {
  totalPut?: number;
  totalCall?: number;
  totalComplete?: number;
  total?: number;
  percentagePut?: string;
  percentageCall?: string;
  percentageComplete?: string;
}

export interface ISubTaskInfo {
  guid: string;
  taskGuid?: string;
  phone?: string;
  name?: string;
  companyName?: string;
  firstRegion?: string;
  secondRegion?: string;
  carrierType?: number;
  callTimes?: number;
  putTimes?: number;
  lastCallResult?: string;
  lastExeTime?: string;
  createTime?: string;
  status?: number;
  sendSms?: number;
  sendSmsResult?: number;
  sendSmsResultDesc?: string;
}

// export interface ISubTaskListReq {
//   taskGuid?: string;
//   pageNum?: number;
//   pageSize?: number;
//   type?: number;
//   phone?: string;
//   namelist_guid?: string;
//   minPutTimes?: string;
//   maxPutTimes?: string;
//   minCallTimes?: string;
//   maxCallTimes?: string;
// }
export interface ISubTaskListReq {
  taskGuid?: string;
  pageNum?: number;
  pageSize?: number;
  type?: number;
  phone?: string;
  name?: string;
  companyName?: string;
  namelistGuid?: string;
  carrierType?: number;
  citys?: string[];
  minPutTimes?: string;
  maxPutTimes?: string;
  minCallTimes?: string;
  maxCallTimes?: string;
  startTime?: string;
  endTime?: string;
  minExeTime?: string;
  maxExeTime?: string;
  lastCallResultList?: number[];
  carrierTypeList?: number[];
  statusList?: number[];
  expectCount?: number;
  sendSms?: number;
  sendSmsResult?: number;
}

export interface ISubTaskInfoRes {
  pageNum?: number;
  pageSize?: number;
  totalRecord?: number;
  totalPages?: number;
  list?: ISubTaskInfo[];
}

export interface StatisticalParams {
  startDate?: string;
  endDate?: string;
  taskName?: string;
  taskStatus?: number;
  tenantCode?: string;
  faqName?: string;
  pageSize: number;
  pageNum: number;
}

// export interface IUploadFileReq {
//   bffAction?: string;
//   taskGuid?: string;
//   fileName?: any;
// }

export interface OverallResponseType extends ICommonResponse {
  data: {
    totalWaiting?: number; // 待呼数(待呼名单数)
    totalPut?: number; // 接通名单数(名单列表接通次数>=1的名单量)
    total?: number; // 总名单数
    totalCall?: number; // 外呼名单数(名单列表外呼次数>=1的名单量)
    totalDialogue?: number; // 话单总数
    totalDialoguePut?: number; // 接通话单总数
    percentagePut?: string; // 名单接通率
    percentageComplete?: string; // 名单完成率
    percentageDialoguePut?: string; // 外呼接通率
  };
}

export interface RoundDetailsResponseType extends ICommonResponse {
  data: {
    callTimes?: number; // 第N轮外呼
    totalPut?: number; // 接通数
    total?: number; // 外呼数
    percentagePut?: string; // 接通率
  }[];
}

export interface ProcessFunnelResponseType extends ICommonResponse {
  data: {
    total: number;
    totalPut: number;
    totalCall: number;
    percentageCall: string;
    percentageDialoguePut: string;
    totalSms: number;
    successSms: number;
    percentageSms: string;
    percentageSmsSuccess: string;
    totalCallDialogueSms: string;
    smsClickNum:number;
    smsClickRate:number
  };
}

export interface ProcessResponseType extends ICommonResponse {
  data: {
    total?: number; // 总名单数
    details?: {
      key?: string; // 意图
      totalKey?: number; // 总数
      percentageKey?: string; // 占比
    }[];
  };
}

export interface TaskMonitoringResponseType extends ICommonResponse {
  data: {
    concurrenceRate?: number; // 单并发流速(近五分钟内的通话记录数*12/锁定并发)
    taskRate?: number; // 任务流速(近五分钟内的通话记录数*12)
    percentagePut?: number; // 外呼接通率(近五分钟内接通的通话记录数/近五分钟内的通话记录数)
  };
}

export interface ProcessStatisticResponseType extends ICommonResponse {
  data: {
    statisticsTime?: string; // 统计时间
    statisticsData?: string; // 统计数据
  }[];
}

export interface DownloadResponseType extends ICommonResponse {
  data: {
    ossUrl: string;
  };
}

export interface IBatchExeTimeItem {
  guid: string;
  exeStartTime: string;
  exeEndTime: string;
  autoRetry?: string;
  ext: string;
}
// 批量编辑任务
export interface ITaskBatchEdit {
  taskGuidList: string[];
  callDuration?: any[];
  autoRetry?: string;
  transfer?: string;
}

export interface IBatchExeTimeReq {
  itemList: IBatchExeTimeItem[];
}

export interface IBatchExecReq {
  taskGuidList: string[] | undefined;
  lastCallResult?: number;
  minPutTimes?: number;
  maxPutTimes?: number;
  minLastExeTime?: string;
  maxLastExeTime?: string;
  secondRegionList?: string[];
  minCallTimes?: number;
  maxCallTimes?: number;
}

export interface ITaskTemplateReq {
  tenantList?: number[];
  name?: string;
  taskName?: string;
  faqName?: string;
  bpoVersion?: number;
}

export interface ITaskTemplatePageReq {
  tenantList?: number[];
  name?: string;
  taskName?: string;
  faqName?: string;
  templateName?:string;
  tenant?: string;
  faqGuid?: string;
  pageNum: number;
  pageSize: number;
}

interface ILongTaskStatisticsReq {
  startDate?: string;
  endDate?: string;
  tenantCode?: string;
  taskName?: string;
  faqName?: string;
  taskStatus?: number;
  statusList?: number[];
  tenantList?: string[];
  pageSize?: number;
  pageNum?: number;
}

export interface ITenantTaskQueryReq {
  tenantCodes: string[];
}

export interface ITenantTaskQuery {
  tenantName?: string;
  tenantCode?: string;
  taskNum?: string;
  waitCallQuantity?: string;
  totalExpectLoadCount?: string;
  executeStatus?: number; //执行状态, 1:未开始;2:执行中;3:完成
}

export interface ITenantTaskQueryResponse extends ICommonResponse {
  data: ITenantTaskQuery[];
}

export interface ILimitInfo {
  label?: string;
  value?: string;
  children?: {
    label: string;
    value: string;
  }[];
  allCity?: number;
}

export interface ICarrierAreaLimit {
  carrier?: number;
  carrierDesc?: string;
  limitInfo?: ILimitInfo[];
}

export interface ICarrierAreaLimitResponse extends ICommonResponse {
  data: {
    carrierAreaLimit: ICarrierAreaLimit[];
  };
}

export interface IProvinceCity {
  firstChar?: string;
  value?: string;
  label?: string;
  children?: {
    value?: string;
    label?: string;
  }[];
}

export interface IProvinceCityResponse extends ICommonResponse {
  data: IProvinceCity[];
}

export interface ITaskFaqList extends ICommonResponse {
  data: {
    speechId?: string;
    speechName?: string;
    version?: string;
  }[];
}

// 任务列表
export const getTaskList = async (
  params: ITaskListReq,
): Promise<ITaskInfoRes> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.task.pageListTask',
    ...params,
  });
  return res?.data as unknown as ITaskInfoRes;
};

// 查询任务执行统计信息
export const getTaskProcessInfo = async (
  params: ITaskProcessInfoReq,
): Promise<ITaskProcessInfo> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.task.taskProcessInfo',
    ...params,
  });
  return res?.data as unknown as ITaskProcessInfo;
};

// 任务模版
export const listTaskTemplate = async (
  params: ITaskTemplateReq,
): Promise<any[]> => {
  const res = await request.post<any>(`${API.API_HOST}`, {
    bffAction: 'css.call.task.listTaskTemplate',
    ...params,
  });
  return res?.data;
};

// 创建任务模版
export const createOrUpdateTaskTemplate = async (
  params: any,
): Promise<any[]> => {
  const res = await request.post<any>(`${API.API_HOST}`, {
    bffAction: 'task.createOrUpdateTaskTemplate',
    ...params,
  });
  return res as any;
};

// 删除任务模版
export const deleteTaskTemplate = async (
  params: any,
): Promise<ICommonResponse> => {
  const res = await request.post<any>(`${API.API_HOST}`, {
    bffAction: 'task.deleteTaskTemplate',
    ...params,
  });
  return res;
};

// 查询子任务信息
export const getSubTaskList = async (
  params: ISubTaskListReq,
): Promise<ISubTaskInfoRes> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.task.pageListSubTask',
    ...params,
  });
  return (res?.data as unknown as ISubTaskInfoRes) || {};
};

// 创建自定义任务
export const createTask = async (params: any): Promise<any[]> => {
  const res = await request.post<any>(`${API.API_HOST}`, {
    bffAction: 'task.createTask',
    ...params,
  });
  return res as any;
};

// 删除自定义任务
export const deleteTask = async (params: any): Promise<any> => {
  const res = await request.post<any>(`${API.API_HOST}`, {
    bffAction: 'task.deleteTask',
    ...params,
  });
  return res as any;
};

// 更新自定义任务

export const updateTask = async (params: any): Promise<any> => {
  const res = await request.post<any>(`${API.API_HOST}`, {
    bffAction: 'task.updateTask',
    ...params,
  });
  return res;
};

// 上传名单
export const uploadTaskDataFile = async (params): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(
    `${API.BFF_UPLOAD_LOGIN}`,
    params,
    {
      headers: { 'Content-Type': 'multipart/form-data;' },
    },
  );
  return res;
};

// 补呼
export const supplementCall = async (params: {
  guid: string;
  taskGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse, ICommonResponse>(
    `${API.API_HOST}`,
    {
      bffAction: 'task.manualRetry',
      ...params,
    },
  );
  return res;
};

// 停止任务
export const pauseTask = async (params: {
  guid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'task.pauseTask',
    ...params,
  });
  return res;
};

// 开始任务
export const startTask = async (params: {
  guid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'task.startTask',
    ...params,
  });
  return res;
};

// 结束长期任务
export const endTask = async (params: {
  guid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'task.finishTask',
    ...params,
  });
  return res;
};

// 批量添加呼叫
export const batchAddCallTask = async (
  params: ISubTaskListReq,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'batchAppendWaitingCallSubTask',
    ...params,
  });
  return res;
};

// 批量取消呼叫
export const batchCancelCallTask = async (
  params: ISubTaskListReq,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'releaseWaitingCallSubTask',
    ...params,
  });
  return res;
};

// 单条取消呼叫
export const singleCancelCallTask = async (params: {
  guid: string;
  taskGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'task.manualRelease',
    ...params,
  });
  return res;
};

// 任务整体执行情况
export const getOverall = async (params: {
  taskGuid: string;
  tenant: string;
}): Promise<OverallResponseType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.overall',
    ...params,
  });
  return res;
};

// 轮次明细情况
export const getRoundDetail = async (params: {
  taskGuid: string;
  tenant: string;
}): Promise<RoundDetailsResponseType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.processCallTimes',
    ...params,
  });
  return res;
};

// 转化漏斗明细情况
export const getProcessFunnel = async (params: {
  taskGuid: string;
  tenant: string;
}): Promise<ProcessFunnelResponseType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.funnelShapedInfo',
    ...params,
  });
  return res;
};

// 意图分类明细情况
export const getProcessIntention = async (params: {
  taskGuid: string;
  tenant: string;
  speechId?: string;
}): Promise<ProcessResponseType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.processIntention',
    ...params,
  });
  return res;
};

// 命中标签明细情况
export const getProcessWithTag = async (params: {
  taskGuid: string;
  tenant: string;
  speechId?: string;
}): Promise<ProcessResponseType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.processWithTag',
    ...params,
  });
  return res;
};

// 命中呼叫状态情况
export const getProcessWithResult = async (params: {
  taskGuid: string;
  tenant: string;
}): Promise<ProcessResponseType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.processWithResult',
    ...params,
  });
  return res;
};

// 运行监测
export const getTaskMonitoring = async (params: {
  taskGuid: string;
  tenant: string;
}): Promise<TaskMonitoringResponseType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.taskMonitoring',
    ...params,
  });
  return res;
};

// 过程统计
export const getProcessStatistic = async (params: {
  taskGuid: string;
  type: number; // 0 单并发流速，1任务流速，2 呼叫接通率,默认0
  interval: number; // 计量单位(5,15,30) 分钟
  tenant: string;
  queryDate: string; // 查询日期
}): Promise<ProcessStatisticResponseType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.processStatistics',
    ...params,
  });
  return res;
};

// 任务校验
export const checkTaskOperate = async (params: {
  tenant: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.checkTaskOperate',
    ...params,
  });
  return res;
};

// 批量停止任务
export const patchPauseTask = async (params: {
  guidList: string[];
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.batchPauseTask',
    ...params,
  });
  return res;
};

// 批量添加呼叫
export const batchExec = async (
  params: IBatchExecReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.batchAddCall',
    ...params,
  });
  return res;
};

// 查询执行详情
export const queryExecDtl = async (params: {
  batchId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.queryExecDtl',
    ...params,
  });
  return res;
};

// 批量开始任务
export const patchStartTask = async (params: {
  itemList: { guid: string; expectLoadCount: number | undefined }[];
  tenantLineGroupId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.batchStartTask',
    ...params,
  });
  return res;
};

// 下载转化漏斗明细情况
export const downloadFunnelInfo = async (params: {
  taskGuid: string;
  tenant: string;
}): Promise<DownloadResponseType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.funnelShapedInfoExport',
    ...params,
  });
  return res;
};

// 下载意图分类明细情况
export const downloadIntention = async (params: {
  taskGuid: string;
  tenant: string;
}): Promise<DownloadResponseType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.downloadIntention',
    ...params,
  });
  return res;
};

//任务统计列表
export const getStatisticsList = async (
  params: StatisticalParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.day.statistics',
    ...params,
  });
  return res;
};

// 任务统计total
export const getTaskTotal = async (
  params: StatisticalParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.day.total',
    ...params,
  });
  return res;
};

// 下载命中标签明细情况
export const downloadTag = async (params: {
  taskGuid: string;
  tenant: string;
}): Promise<DownloadResponseType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.downloadTag',
    ...params,
  });
  return res;
};

// 下载命中呼叫状态情况
export const downloadResult = async (params: {
  taskGuid: string;
  tenant: string;
}): Promise<DownloadResponseType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.downloadResult',
    ...params,
  });
  return res;
};

// 任务列表导出
export const taskExport = async (
  params: StatisticalParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.task.day.export',
  });
  return res;
};

// 任务批量设置
export const batchExeTime = async (
  params: IBatchExeTimeReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'task.batchExeTime',
  });
  return res;
};

// 下载模版
export const downloadTaskTemplate = async (params: {
  guid: string;
  uploadType: string;
  fileType?: number;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.downloadTemplate',
    ...params,
  });
  return res;
};
// 批量编辑任务
export const taskBatchEdit = async (
  params: ITaskBatchEdit,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.task.batchEdit',
  });
  return res;
};
// 查询线路组并发数量
export const getTenantConcurrencytask = async (params: {
  code: number;
  tenantLineGroupId: string;
  bpoVersion?: number;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.linegroup.concurrency',
    ...params,
  });
  return res;
};
// 任务模版（分页版本）
export const taskTemplatePage = async (
  params: ITaskTemplatePageReq,
): Promise<taskTemplatePageRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.taskTemplatePage',
    ...params,
  });
  return res?.data;
};
// 添加执行策略
export const taskStrategyAdd = async (
  params: any,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.strategy.add',
    ...params,
  });
  return res;
};

// 任务中心-分页查询任务统计列表
export const queryLongTaskStatistics = async (
  params: ILongTaskStatisticsReq,
): Promise<ILongTaskStatisticsoRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.long.task.statistics',
    ...params,
  });
  return res?.data;
};

// 任务中心-根据任务ID查询任务子集
export const queryLongSubTaskStatistics = async (params: {
  taskGuid: string;
  taskDate: string;
}): Promise<ILongTaskStatisticsoRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.subset.statistics',
    ...params,
  });
  return res?.data;
};

// 任务中心-任务统计导出
export const longTaskExport = async (
  params: StatisticalParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.long.task.day.export',
  });
  return res;
};

// 编辑执行策略
export const taskStrategyUpdate = async (
  params: any,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.strategy.update',
    ...params,
  });
  return res;
};
// 长期任务统计total
export const getLongTaskTotal = async (
  params: StatisticalParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.long.task.day.total',
    ...params,
  });
  return res;
};

// 删除执行策略
export const taskStrategyDelete = async (
  params: any,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.strategy.delete',
    ...params,
  });
  return res;
};

// 查询执行策略列表
export const getTaskStrategyList = async (
  params: any,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.strategy.list',
    ...params,
  });
  return res;
};

// 查询任务不可外呼时间段
export const getForbidCallDuration = async (
  params: any,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.forbid.call.duration.get',
    ...params,
  });
  return res;
};

// 查询外呼策略名单条件
export const getStrategyConditionList =
  async (): Promise<taskTemplatePageRes> => {
    const res = await request.post(`${API.API_HOST}`, {
      bffAction: 'css.strategy.condition.typeList',
    });
    return res;
  };

// 租户维度任务聚合信息查询
export const getTenantTaskQuery = async (
  params: ITenantTaskQueryReq,
): Promise<ITenantTaskQueryResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'tenant.task.aggregation.query',
    ...params,
  });
  return res;
};

// 租户维度任务批量启动
export const tenantTaskBatchStart = async (
  params: ITenantTaskQueryReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'tenant.task.batch.start',
    ...params,
  });
  return res;
};

// 租户维度任务聚合信息查询-轮询
export const getTenantTaskPollingQuery = async (
  params: ITenantTaskQueryReq,
): Promise<ITenantTaskQueryResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'tenant.task.aggregation.polling',
    ...params,
  });
  return res;
};

// 查询任务盲区配置信息
export const queryTaskLimitExt = async (params: {
  taskGuid: string;
}): Promise<ICarrierAreaLimitResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.taskExt',
    ...params,
  });
  return res;
};

//查询任务模板盲区配置信息
export const queryTemplateLimitExt = async (params: {
  templateGuid: string;
}): Promise<ICarrierAreaLimitResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.taskTemplateExt',
    ...params,
  });
  return res;
};

//获取省市列表用于盲区配置
export const queryProvinceCityList =
  async (): Promise<IProvinceCityResponse> => {
    const res = await request.post(`${API.API_HOST}`, {
      bffAction: 'css.call.provinceCityList2',
    });
    return res;
  };

//获取任务统计运行日期列表
export const queryTaskRunDateList = async (params: {
  taskGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.taskRunDateList',
    ...params,
  });
  return res;
};

//校验话术下变量是否冲突
export const checkTaskVariable = async (params: {
  historySpeechList: string[];
  speechList: string[];
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.checkVariable',
    ...params,
  });
  return res;
};

//任务有数据的话术列表
export const queryTaskFaqList = async (params: {
  taskGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.faqList',
    ...params,
  });
  return res;
};
//获取系统时间
export interface IPsystemDateResponse extends ICommonResponse {
  data: {
    systemDate?: string;
  };
}
export const taskTemplateSystemDate =
  async (): Promise<IPsystemDateResponse> => {
    const res = await request.post(`${API.API_HOST}`, {
      bffAction: 'css.call.task.systemDate',
    });
    return res;
  };
//复制的任务模版内容
export interface IDcopiedTemplateResponse extends ICommonResponse {
  data: IDcopiedTemplateData;
}
export interface IDcopiedTemplateData {
  name?: string;
  taskName?: string;
  exeStartTime?: string;
  exeEndTime?: string;
  autoRetry?: number;
  autoRetryDesc?: string;
  autoStartup?: number;
  autoStartupDesc?: string;
  remark?: string;
  ext?: string;
  tenant?: string;
  operator?: string;
  createBy?: string;
  createTime?: string;
  updateTime?: string;
  faqGuid?: string;
  faqName?: string;
  groupId?: string;
  expectLoadCount?: number;
  tenantName?: string;
  taskType?: number;
  transfer?: number;
  tenantLineGroupId?: string;
  tenantLineGroupCode?: string;
  tenantLineGroupName?: string;
  thirdBlacklistIntercept?: number;
  featureIntercept?: number;
  multipleSmsLink?: number;
  extConfigInfo?: string;
  loadFlag?: number;
  callbackSwitch?: number;
  initStart?: number;
  phoneType?: number;
  carrierAreaLimit?: ICarrierAreaLimit[];
  taskStrategyList?: ITaskStrategyList[];
  callbackCallTimes?: number[];
}

interface ITaskStrategyList {
  strategyName?: string;
  faqName?: string;
  faqNames?: string;
  faqGroupIds?: string;
  exeStartDate?: string;
  status?: number;
  statusDesc?: string;
  exeEndDate?: string;
  exeStartTime?: string;
  exeEndTime?: string;
  callDuration?: ICallDuration[];
  strategyCondition?: IStrategyCondition;
}

interface IStrategyCondition {
  citys?: string[];
  minCallTimes?: number;
  maxCallTimes?: number;
  minPutTimes?: number;
  maxPutTimes?: number;
  lastIntentClassifys?: string[];
  lastCallResults?: number;
  minLastExeTime?: string;
  maxLastExeTime?: string;
  minLastAnswerTime?: string;
  maxLastAnswerTime?: string;
  minJoinTime?: string;
  maxJoinTime?: string;
  lastHitLabels?: string[];
}

interface ICallDuration {
  startTime?: string;
  endTime?: string;
}
export const copiedTemplate = async (params: {
  guid: string;
}): Promise<IDcopiedTemplateResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.task.copiedTemplate',
    ...params,
  });
  return res;
};

//任务中心-名单管理导出
interface IDtaskPhoneExportParams {
  tenant?: string;
  phone?: string;
  name?: string;
  companyName?: string;
  namelistGuid?: number;
  carrierTypeList?: number[];
  firstRegion?: string;
  secondRegion?: string;
  citys?: string[];
  minPutTimes?: number;
  maxPutTimes?: number;
  minCallTimes?: number;
  maxCallTimes?: number;
  taskGuid: number;
  type: number;
  startTime?: string;
  endTime?: string;
  minLastExeTime?: string;
  maxLastExeTime?: string;
  minExeTime?: string;
  maxExeTime?: string;
  lastCallResultList?: number[];
  statusList?: number[];
  callingNumber?: string;
  sendSms?: number;
  sendSmsResult?: number;
  lastHitLabels?: string[];
  minLastAnswerTime?: string;
  maxLastAnswerTime?: string;
  lastIntentClassifys?: string[];
  minCallTimesToday?: number;
  maxCallTimesToday?: number;
  minPutTimesToday?: number;
  maxPutTimesToday?: number;
  executeToday?: number;
  sendSmsToday?: number;
  sendSmsResultToday?: number;
  exportExternalId: number;
}
export const taskPhoneExport = async (
  params: IDtaskPhoneExportParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.phone.export',
    ...params,
  });
  return res;
};
