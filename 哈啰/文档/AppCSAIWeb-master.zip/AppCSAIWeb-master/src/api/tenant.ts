import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface ITenantInfo {
  id: string;
  tenant: number;
  desc?: string;
  name?: string;
  code?: string;
  contact?: string;
  createTime?: string;
  updateTime?: string;
  remark?: string;
}

interface ITenantListRes extends ICommonResponse {
  data: ITenantInfo[];
}
// 租户列表
export const getTenantList = async (params: {
  pageSize: number;
  pageNum: number;
}): Promise<ITenantListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.tenant.list',
  });
  return res;
};

// 租户列表for BPO2.0
//transferVersion 1-1.0 / 2-2.0
export const getTenantVersionList = async (params: {
  pageSize: number;
  pageNum: number;
  transferVersion?: number;
}): Promise<ITenantListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.tenant.version.list',
  });
  return res;
};
