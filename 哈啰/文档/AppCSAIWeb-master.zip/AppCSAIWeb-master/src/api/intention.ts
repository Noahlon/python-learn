import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface IntentionCollectInfo {
  guid?: string;
  name?: string;
  tenant?: number;
  speechGuid?: string;
  description?: string;
  knowledgeCount?: number;
  modelId?: string;
  modelName?: string;
}

interface IntentionCollectListRes extends ICommonResponse {
  data: IntentionCollectInfo[];
}

export interface IntentionInfo {
  faqId?: string;
  name?: string;
  guid: string;
  kcGuid: string;
  kcName: string;
  showDeleteButton?: number;
  modelGuid?: string;
  propertyType?: number;
  propertyName?: string;
}

interface IntentionListRes extends ICommonResponse {
  data: IntentionInfo[];
}

export interface ISimilarOrPhraseInfo {
  faqId?: string;
  name?: string;
}

interface ISimilarOrPhraseRes extends ICommonResponse {
  data: {
    knowledgeList: string[];
    count: number;
  };
}

interface IntentionUploadRes extends ICommonResponse {
  data: {
    ossUrl: string;
    success: boolean;
  };
}

export interface IntentionOpt {
  id: string;
  name: string;
  list: IntentionOpt[];
}

export interface IntentionLearningType {
  kcGuid?: string;
  faqId?: string;
  phrases?: string;
  nearQuestions?: string;
  kernelSentenceInfo?: string;
  kcFaqInfoList?: any;
}

interface IntentionOptsRes extends ICommonResponse {
  data: IntentionOpt[];
}

export interface IntentionLearningRecordType {
  pageSize?: number; // 页大小
  pageNum?: number; // 当前页
  status?: number; // 0 待处理，1已处理
  userInput?: string; // 用户文本
  speechName?: string; // 话术名称
  bizId?: string; // 所属行业
  startCreateTime?: string; // 开始时间
  endCreateTime?: string; // 结束时间
  startHandleTime?: string; // 处理开始时间
  endHandleTime?: string; // 处理结束时间
  handleResult?: number; // 1 忽略 2 已学习
  commendIntentionId?: string;
}

export interface IntentionLearningExeType {
  kbGuid?: string; // 集合id
  faqId?: string; // 意图id
  phrases?: string; // 短语
  nearQuestions?: string; // 相似问
  recordIds?: string[]; // 记录id
}

export interface QueryKernelObj {
  sentenceInfo: string;
  kernelId: string;
  faqId: string;
}

export interface QueryRegexObj {
  regexInfo: string;
  regexId: string;
  faqId: string;
}

export interface QueryKernelRes extends ICommonResponse {
  data: QueryKernelObj[];
}

export interface DistinctKernelReq {
  faqId: string;
  kcGuid: string;
  sentenceInfo: string;
}
export interface CommendIntentionObj {
  faqId: string;
  name: string;
}
export interface CommendIntentionRes extends ICommonResponse {
  data: {
    pageNum: number;
    pageSize: number;
    totalRecord: number;
    totalPages: number;
    list?: CommendIntentionObj[];
  };
}

export interface QueryKernelObj {
  sentenceInfo: string;
  kernelId: string;
  faqId: string;
}

export interface QueryKernelRes extends ICommonResponse {
  data: QueryKernelObj[];
}

export interface DistinctKernelReq {
  faqId: string;
  kcGuid: string;
  sentenceInfo: string;
}
export interface CommendIntentionObj {
  faqId: string;
  name: string;
}
export interface CommendIntentionRes extends ICommonResponse {
  data: {
    pageNum: number;
    pageSize: number;
    totalRecord: number;
    totalPages: number;
    list?: CommendIntentionObj[];
  };
}

// 意图集合列表
export const getTradeIntentionList = async (params: {
  bizId: string;
}): Promise<IntentionCollectListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.new.intention.kcList',
  });
  return res;
};

// 更新意图集合缓存
export const refreshPhraseCache = async (params: {
  guid: string;
}): Promise<IntentionCollectListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.kc.refreshPhraseCache',
  });
  return res;
};

// 意图列表
export const getNewIntentionListById = async (params: {
  kcGuid: string;
}): Promise<IntentionListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.new.intention.knowList',
  });
  return res;
};

// 意图列表
export const getNewIntentionList = async (params: {
  kcGuid: string;
  type: number;
  content?: string;
}): Promise<IntentionListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.new.intention.query',
  });
  return res;
};

// 创建意图
export const addIntention = async (params: {
  kcGuid: string;
  name: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.new.intention.create',
  });
  return res;
};

// 编辑意图
export const editIntention = async (params: {
  kcGuid: string;
  name: string;
  faqId: string;
  modelGuid?: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.new.intention.editName',
  });
  return res;
};

// 相似问去重
export const extendDistinct = async (params: {
  extendFaqName: string;
  standardFaqGuid: string;
}): Promise<ISimilarOrPhraseRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.new.extend.distinct',
  });
  return res;
};

// 短语去重
export const phraseDistinct = async (params: {
  extendFaqName: string;
  standardFaqGuid: string;
}): Promise<ISimilarOrPhraseRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.new.phrase.distinct',
  });
  return res;
};

// 清除所有相似问
export const deleteAllSimilar = async (params: {
  standardFaqGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.new.extend.deleteAll',
  });
  return res;
};

// 清除所有短语
export const deleteAllPhrase = async (params: {
  faqId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.new.phrase.deleteAll',
  });
  return res;
};

// 意图批量导出
export const intentionDownload = async (params: {
  kcGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.knowledge.download',
  });
  return res;
};

// 意图批量导入
export const intentionUpload = async (params: {
  kcGuid: string;
  ossUrl: string;
}): Promise<IntentionUploadRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.knowledge.upload',
  });
  return res;
};

// 根据Id集合获取意图级联
export const getIntentionOptsByIDs = async (params: {
  bizId?: string;
  bizIdList?: string[];
  kcIds?: string[];
}): Promise<IntentionOptsRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.knowledge.info.short',
  });
  return res;
};

// 根据id 获取意图文字数组
export const getIntentionTextByIDs = async (params: {
  faqIds: string[];
}): Promise<IntentionOptsRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.knowledge.query.batch',
  });
  return res;
};

// 批量修改 意图
export const updateCorpusBatch = async (params: {
  speechGuid: string;
  corpusSource: number;
  intentionIds: string[];
  pageNum: 1;
  pageSize: 10;
}): Promise<IntentionOptsRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.corpus.update.sp.batch',
  });
  return res;
};

// 意图测试(cc.intention.test.execute)
export const intentionTest = async (params: {
  sentence: string;
  kcGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'cc.intention.test.execute',
  });
  return res;
};

// 查看测试记录(cc.intention.test.find)
export const findIntentionTestRecord = async (params: {
  pageSize: number;
  pageNum: number;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'cc.intention.test.find',
  });
  return res;
};

// 意图测试学习(cc.intention.test.learn)
export const intentionLearning = async (
  params: IntentionLearningType,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'cc.intention.test.learn',
  });
  return res;
};

// 查看意图学习记录(cc.intention.learn.find)
export const findIntentionLearningRecord = async (
  params: IntentionLearningRecordType,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'cc.intention.learn.find',
  });
  return res;
};

// 忽略意图记录(cc.intention.learn.ignore)
export const ignoreIntentionRecord = async (params: {
  recordIds: string[];
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'cc.intention.learn.ignore',
  });
  return res;
};

// 意图学习执行学习(cc.intention.learn.execute)
export const intentionLearningExe = async (
  params: IntentionLearningExeType,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'cc.intention.learn.execute',
  });
  return res;
};

// 获取意图学习设置(cc.intention.learn.getSetting)
export const getIntentionSetting = async (): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'cc.intention.learn.getSetting',
  });
  return res;
};

// 设置意图学习设置(cc.intention.learn.setSetting)
export const setIntentionSetting = async (params: {
  textLength: number;
  speechGroupInfos: {
    speechGroupId: string; //话术组id
    speechName: string; //话术名
  }[];
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'cc.intention.learn.setSetting',
  });
  return res;
};

// 获取意图集合组织树(css.call.new.intention.kcTree)
export const getIntentionTree = async (): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.new.intention.kcTree',
  });
  return res;
};
// 获取所有意图
export const getGroupWithKc = async (): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.knowledge.groupWithKc',
  });
  return res;
};

// 查询【核心句】
export const queryKnowledgeKernel = async (params: {
  faqId: string;
}): Promise<QueryKernelRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.knowledge.queryKernel',
    ...params,
  });
  return res;
};

// 清除所有【核心句】
export const deleteAllKernel = async (params: {
  faqId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.kernel.deleteAll',
    ...params,
  });
  return res;
};

// 删除单个【核心句】
export const deleteKnowledgeKernel = async (params: {
  kernelId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.kernel.delete',
    ...params,
  });
  return res;
};

// 拆分新增【核心句】
export const distinctKnowledgeKernel = async (
  params: DistinctKernelReq,
): Promise<ISimilarOrPhraseRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.kernel.distinct',
    ...params,
  });
  return res;
};

// 插入【核心句】
export const batchKnowledgeKernel = async (
  params: DistinctKernelReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.kernel.insert',
    ...params,
  });
  return res;
};

// 查询意图学习推荐意图分页信息
export const queryCommendIntention = async (params: {
  pageSize: number;
  pageNum: number;
}): Promise<CommendIntentionRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.knowledge.pageLearn',
    ...params,
  });
  return res;
};

// 正则
// 查询正则
export const knowledgeQueryRegex = async (params: {
  faqId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(
    `${API.API_HOST}?css.call.knowledge.queryRegex`,
    {
      bffAction: 'css.call.knowledge.queryRegex',
      ...params,
    },
  );
  return res;
};
// css.call.regex.insert(插入正则)
export const regexInsert = async (params: {
  faqId: string;
  regexInfo: string;
  kcGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?css.call.regex.insert`, {
    bffAction: 'css.call.regex.insert',
    ...params,
  });
  return res;
};
// 意图正则拆分 css.call.regex.distinct
export const regexDistinct = async (params: {
  faqId: string;
  regexInfo: string;
  kcGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?css.call.regex.distinct`, {
    bffAction: 'css.call.regex.distinct',
    ...params,
  });
  return res;
};
// 清除所有【正则】
export const regexDeleteAll = async (params: {
  faqId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.regex.deleteAll',
    ...params,
  });
  return res;
};
// 删除单个【正则】
export const regexDelete = async (params: {
  regexId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.regex.delete',
    ...params,
  });
  return res;
};

// 复制 css.call.knowledge.copyRegex
export const copyKnowledgeRegex = async (params: {
  faqId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.knowledge.copyRegex',
    ...params,
  });
  return res;
};
