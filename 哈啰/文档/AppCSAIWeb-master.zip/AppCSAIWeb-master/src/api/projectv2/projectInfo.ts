import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse, ICommonResponseList } from '../baseInterface';

/**
 * 查询项目列表interface
 */
export interface ProjectListParams {
  pageSize: number;
  pageNum: number;
  tenantCodeList?: number[];
  projectName?: string;
  projectStatus?: number;
}

export interface ProjectListObj {
  guid?: string;
  projectName?: string;
  tenantName?: string;
  totalRosterCount?: number;
  projectStatus?: number;
  rosterBatchCount?: number;
  runningTaskCount?: number;
  totalTaskCount?: number;
  closingDate?: string;
}

type ProjectListRes = ICommonResponseList<ProjectListObj>;

/**
 * 新增/编辑项目基本信息interface
 */
export interface ProjectUpdateParams {
  guid?: string;
  projectName: string;
  tenantCode: number;
  formGuid: string;
  followNodeSetGuid: string;
  callLineGuidList: [string, string];
  smsGuidList?: string[];
  projectStatus: number;
  validityPeriod?: number;
  closingDate?: string;
  projectDesc?: string;
}

/**
 * 编辑项目拦截策略interface
 */
export interface UpdateStrategyParams {
  strategy: string;
  aiCallOutSwitch: number;
  collaborateSwitch: number;
  predictionSwitch: number;
  predictionLevelOneBizId?: string;
  predictionLevelTwoBizId?: string;
  predictionSceneBizId?: string;
  seatsCallOutSwitch: number;
  seatsCallOutLevelOneBizId?: string;
  seatsCallOutLevelTwoBizId?: string;
  seatsCallOutSceneBizId?: string;
}

/**
 * 查询项目详情interface
 */
export interface ProjectDetailObj {
  guid?: string;
  projectName?: string;
  projectStatus?: number;
  tenantName?: string;
  tenantCode?: number;
  formGuid?: string;
  formName?: string;
  followNodeSetGuid?: string;
  followNodeSetName?: string;
  smsInfoList?: {
    smsTemplateName?: string;
    smsTemplateGuid?: string;
  }[];
  validityPeriod?: number;
  closingDate?: string;
  projectDesc?: string;
  createdByName?: string;
  createTime?: string;
  batchCount?: number;
  totalRosterCount?: number;
  runningTaskCount?: number;
  totalTaskCount?: number;
  callLineNameList: [string, string];
  projectUpdateStrategyRequests?: UpdateStrategyParams[];
  nodeList?: {
    nodeName?: string;
    nodeGuid?: string;
    sort?: string;
  }[];
  canCopyPhone?: number;
}

export interface ProjectDetailRes extends ICommonResponse {
  data: ProjectDetailObj;
}

/**
 * 查询所有启用中的表单interface
 */
export interface FormListRes extends ICommonResponse {
  data: {
    formGuid: string;
    formName: string;
  }[];
}

/**
 * 查询所有启用的节点集interface
 */
export interface NodeListRes extends ICommonResponse {
  data: {
    followNodeSetGuid: string;
    followNodeSetName: string;
  }[];
}

// -------------------------------------------------

// 查询项目列表
export const queryProjectList = async (
  params: ProjectListParams,
): Promise<ProjectListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.project.list',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 创建项目
export const saveProject = async (
  params: ProjectUpdateParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.project.save',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 编辑项目基本信息
export const updateProjectInfo = async (
  params: ProjectUpdateParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.project.update.info',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 编辑项目拦截策略
export const UpdateStrateg = async (params: {
  projectGuid: string;
  projectInfoRequests: UpdateStrategyParams[];
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.project.update.strategy',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 查询项目详情
export const queryProjectDetail = async (params: {
  guid: string;
}): Promise<ProjectDetailRes> => {
  const res = await request.post(`${API.API_HOST}?ha.project.detail`, {
    bffAction: 'ha.project.detail',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 更新项目status
export const updateProjectStatus = async (params: {
  guid: string;
  projectStatus: number;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.project.update.status',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 查询所有启用中的表单
export const querySeatFormList = async (): Promise<FormListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'seat.form.listAll',
    bpoVersion: 2,
  });
  return res;
};

// 查询所有启用的节点集
export const querySeatNodeList = async (): Promise<NodeListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'seat.followNode.listAll',
    bpoVersion: 2,
  });
  return res;
};

// 查询存储自动调整并发开关时间
export const queryAdviceEffectTime = async (): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.advice.effictive.time',
    bpoVersion: 2,
  });
  return res;
};
