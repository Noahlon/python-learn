import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse, ICommonResponseList } from '../baseInterface';

// 查询项目任务列表
export interface HaTaskPageParams {
  pageSize: number;
  pageNum: number;
  projectGuid: string;
  taskType?: number;
  taskName?: string;
  status?: number;
}
export interface HaTaskPageObj {
  pageNum?: number;
  pageSize?: number;
  totalRecord?: number;
  totalPages?: number;
  list?: TaskPageTable[];
}
export interface TaskPageTable {
  taskGuid?: string;
  guid?: string;
  name?: string;
  taskType?: number;
  taskTypeDesc?: string;
  telephoneCount?: number;
  status?: number;
  statusDesc?: string;
  loadCount?: number;
  totalCallRate?: string;
  completableRate?: string;
  transferRate?: string;
  totalUnCall?: number;
  createdByName?: string;
  createTime?: string;
}
type HaTaskPageRes = ICommonResponseList<HaTaskPageObj>;
export const haTaskPage = async (
  params: HaTaskPageParams,
): Promise<HaTaskPageRes> => {
  const res = await request.post(`${API.API_HOST}?ha.task.page`, {
    bffAction: 'ha.task.page',
    bpoVersion: 2,
    ...params,
  });
  return res;
};
// ha.task.create(创建任务)
export interface CreateTaskRequest {
  projectGuid: string;
  name: string;
  exeTime?: string;
  taskType: number;
  tenant: string;
  skillGroupList?: ISkillGroupList[];
  templateGuid?: string;
  templateName?: string;
  faqGuid?: string;
  faqName?: string;
  tenantLineGroupId?: string;
  multipleSmsLink?: number;
  exeStartTime?: string;
  exeEndTime?: string;
  ext?: string;
  expectLoadCount?: number;
  featureIntercept?: number;
  thirdBlacklistIntercept?: number;
  taskGuid?: string; // 更新新增任务ID
  followupRecordAutoCommitTime?: number;
}
export interface ISkillGroupList {
  skillGroupGuid?: string;
  skillGroupName?: string;
  groupLeaderGuid?: string;
  groupLeaderName?: string;
  seatCount?: number;
  rosterCount: number;
}
export const haTaskCreate = async (
  params: CreateTaskRequest,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?ha.task.create`, {
    bffAction: 'ha.task.create',
    bpoVersion: 2,
    ...params,
  });
  return res;
};
// ha.task.update(编辑任务)
export const haTaskUpdate = async (
  params: CreateTaskRequest,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?ha.task.update`, {
    bffAction: 'ha.task.update',
    bpoVersion: 2,
    ...params,
  });
  return res;
};
// 任务详情 ha.task.detail
export interface TaskDetailObj {
  projectGuid?: string;
  projectName?: string;
  taskGuid?: string;
  guid?: string;
  status?: number;
  statusDesc?: string;
  telephoneCount?: number;
  totalUnCall?: number;
  name?: string;
  taskName?: string;
  exeTime?: string;
  taskType?: number;
  taskTypeDesc?: string;
  tenantCode?: number;
  skillGroupList?: ISkillGroupList[]; // 调用创建任务定义方法
  templateGuid?: string;
  templateName?: string;
  faqGuid?: string;
  faqName?: string;
  tenantLineGroupId?: string;
  tenantLineGroupCode?: string;
  tenantLineGroupName?: string;
  multipleSmsLink?: number;
  exeStartTime?: string;
  exeEndTime?: string;
  ext?: string;
  expectLoadCount?: number;
  featureIntercept?: number;
  thirdBlacklistIntercept?: number;
  totalCallRate?: string;
  completableRate?: string;
  transferRate?: string;
  loadCount?: number;
  actualLoadCount?: number;
  createdByName?: string;
  createTime?: string;
  smsTemplateResponseList?: ISmsTemplateResponseList[];
  waitSeatCount?: number;
  callCompletingRate?: string;
  adviceMultiple?: string;
  multiple?: string;
  autoAdviceLoadCount: boolean;
  expectHumanLoadCount?: number;
  followupRecordAutoCommitTime?: number;
  effectiveConcurrency?: string;
  autoAdjustCoefficient?: number;
  onWayCount?: number;
  predictRingDuration?: number;
  exceedRingDurationCount?: number;
  triggerTransferRate?: string;
  putThoughRate?: string;
}
interface ISmsTemplateResponseList {
  templateName?: string;
  templateGuid?: string;
}

interface IAutoCommitTimeListRes extends ICommonResponse {
  data: {
    time: string;
    desc: string;
  }[];
}

export interface TaskDetailRes extends ICommonResponse {
  data: TaskDetailObj;
}

// 任务整体执行情况
interface StatisticAllRes extends ICommonResponse {
  data: {
    total: number;
    totalWaiting: number;
    totalPut: number;
    totalCall: number;
    totalDialogue: number;
    totalDialoguePut: number;
    percentageComplete: string;
    percentagePut: string;
    percentageDialoguePut: string;
    totalDialogueTransfer: number;
    percentageCallTransfer: string;
    percentageThrough: string;
    totalTransfer: number;
    percentagePersonTransfer: string;
  };
}

// 名单统计信息
export interface PersonListRes extends ICommonResponse {
  data: {
    totalCount: number;
    details: {
      count: number;
      type: number;
      typeDesc: string;
      percentageKey: string;
    }[];
  };
}

// 转化漏斗
interface FunnelRes extends ICommonResponse {
  data: {
    total: number;
    totalPut: number;
    totalCall: number;
    percentageCall: string;
    percentageDialoguePut: string;
    totalSms: number;
    successSms: number;
    percentageSms: string;
    percentageSmsSuccess: string;
  };
}

// 意向分类 || 命中标签 || 呼叫状态
interface TaskCommonRes extends ICommonResponse {
  data: {
    total: number;
    details: {
      key: string;
      totalKey: number;
      percentageKey: string;
    }[];
  };
}

// 呼叫轮次统计 || 接通轮次统计 || 接通率轮次统计
interface CallRoundRes extends ICommonResponse {
  data: {
    total: number;
    details: {
      callTimes: string;
      totalKey: number;
      percentageKey: string;
    }[];
  };
}

// 查询当前排队座席信息
export interface TaskSeatWaitRes extends ICommonResponse {
  data: {
    seatGuid?: string;
    seatName?: string;
    skillGroupGuid?: string;
    skillGroupName?: string;
    time?: string;
  }[];
}

// 查询任务下座席统计数据
export interface SeatStatisticsRes extends ICommonResponse {
  data: {
    skillGroupGuid?: string;
    skillGroupName?: string;
    signInSeatCount?: number;
    issuedPersonListCount?: number;
  }[];
}

// 查询15分钟内平均等待时长 interface
interface AverageWaitSecondsRes extends ICommonResponse {
  data: string;
}

// 任务详情
export const haTaskDetail = async (params: {
  taskGuid: string;
}): Promise<TaskDetailRes> => {
  const res = await request.post(`${API.API_HOST}?ha.task.detail`, {
    bffAction: 'ha.task.detail',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// ha.task.start(启动任务)
export const haTaskStart = async (params: {
  taskGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?ha.task.start`, {
    bffAction: 'ha.task.start',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 删除任务
export const haTaskDelete = async (params: {
  taskGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?ha.task.delete`, {
    bffAction: 'ha.task.delete',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 暂停任务
export const haTaskStop = async (params: {
  taskGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?ha.task.stop`, {
    bffAction: 'ha.task.stop',
    bpoVersion: 2,
    ...params,
  });
  return res;
};
//  结束任务 ha.task.finish
export const haTaskFinish = async (params: {
  taskGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?ha.task.finish`, {
    bffAction: 'ha.task.finish',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 任务整体执行情况
export const taskStatisticAll = async (params: {
  taskGuid: string;
}): Promise<StatisticAllRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.statistic.overall',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 名单统计信息
export const taskPersonList = async (params: {
  taskGuid: string;
}): Promise<PersonListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.statistic.personList',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 转化漏斗
export const taskFunnel = async (params: {
  taskGuid: string;
}): Promise<FunnelRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.statistic.funnel',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 意向分类
export const taskIntent = async (params: {
  taskGuid: string;
}): Promise<TaskCommonRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.statistic.intent',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 命中标签
export const taskTag = async (params: {
  taskGuid: string;
}): Promise<TaskCommonRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.statistic.tag',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 呼叫状态
export const taskCallStatus = async (params: {
  taskGuid: string;
}): Promise<TaskCommonRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.statistic.call',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 呼叫轮次统计
export const taskCallRound = async (params: {
  taskGuid: string;
}): Promise<CallRoundRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.statistic.callRound',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 接通轮次统计
export const taskThroughRound = async (params: {
  taskGuid: string;
}): Promise<CallRoundRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.statistic.throughRound',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 接通率轮次统计
export const taskThroughRateRound = async (params: {
  taskGuid: string;
}): Promise<CallRoundRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'task.statistic.throughRateRound',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 查询任务下座席统计数据
export const querySeatStatisticsInfo = async (params: {
  taskGuid: string;
}): Promise<SeatStatisticsRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.task.querySeatStatisticsInfo',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 存储任务并发倍数
export const saveTaskMultiple = async (params: {
  taskGuid: string;
  multiple: string;
}): Promise<SeatStatisticsRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.task.multiple.save',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 查询15分钟内平均等待时长
export const queryAverageWaitSeconds = async (params: {
  taskGuid: string;
}): Promise<AverageWaitSecondsRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.task.queryAverageWaitSeconds',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 查询当前排队座席信息
export const queryTaskSeatWaitInfo = async (params: {
  taskGuid: string;
}): Promise<TaskSeatWaitRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.task.queryTaskSeatWaitInfo',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 存储自动调整并发开关
export const saveAutoadvice = async (params: {
  taskGuid: string;
  autoAdviceLoadCount: boolean;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.task.autoadvice.save',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 自动提交时刻枚举
export const getAutoCommitTimeList =
  async (): Promise<IAutoCommitTimeListRes> => {
    const res = await request.post(
      `${API.API_HOST}?ha.task.getAutoCommitTimeList`,
      {
        bffAction: 'ha.task.getAutoCommitTimeList',
        bpoVersion: 2,
      },
    );
    return res;
  };

  /**
   * 查询任务下签入座席列表
   * 
   * */ 
  
  /**
   * 查询当前排队座席信息
  **/
export interface SingDeatRes extends ICommonResponse {
  data: {
    seatGuid?: string;
    seatName?: string;
    seatAccount?: string;
  }[];
}
  export const singDeat = async (params: {
  taskGuid: string;
}): Promise<SingDeatRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.task.sign.seat',
    bpoVersion: 2,
    ...params,
  });
  return res;
};
/**
 * ha.task.seat.logout(强制签出任务下签入的座席)
*/
  export const singLogut = async (params: {
  taskGuid: string;seatGuid:string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.task.seat.logout',
    bpoVersion: 2,
    ...params,
  });
  return res;
};