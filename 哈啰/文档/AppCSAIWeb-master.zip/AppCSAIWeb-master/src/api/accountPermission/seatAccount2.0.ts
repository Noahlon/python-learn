import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse, ICommonResponseList } from '../baseInterface';

// 座席列表入参
export interface SeatAccountParams {
  seatAccount?: string;
  skillGroupGuid?: string;
  status?: number;
  pageSize: number;
  pageNum: number;
}
export interface SeatAccountObj {
  seatGuid?: string;
  seatName?: string;
  seatAccount?: string;
  phoneNum?: string;
  email?: string;
  skillGroupGuid?: string;
  skillGroupName?: string;
  status?: string;
  createdBy?: string;
  createTime?: string;
  updateTime?: string;
  avatar?: string;
}
type SeatAccountRes = ICommonResponseList<SeatAccountObj>;
// 座席列表
export const seatAccountListPage = async (
  params: SeatAccountParams,
): Promise<SeatAccountRes> => {
  const res = await request.post(`${API.API_HOST}?seat.seatAccount.listPage`, {
    bffAction: 'seat.seatAccount.listPage',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 新增座席
export interface SeatAccountModifyParams {
  seatAccount: string;
  seatGuid?: string;
  avatar?: string;
  phoneNum?: string;
  seatName: string;
  email?: string;
  skillGroupGuid?: string;
}

export const seatAccountModify = async (
  params: SeatAccountModifyParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?seat.seatAccount.modify`, {
    bffAction: 'seat.seatAccount.modify',
    bpoVersion: 2,
    ...params,
  });
  return res;
};
// 默认头像 seat.seatAccount.queryDefaultAvatar
export const seatAccountQueryDefaultAvatar =
  async (): Promise<ICommonResponse> => {
    const res = await request.post(
      `${API.API_HOST}?seat.seatAccount.queryDefaultAvatar`,
      {
        bffAction: 'seat.seatAccount.queryDefaultAvatar',
        bpoVersion: 2,
      },
    );
    return res;
  };
// 重置密码 seat.seatAccount.resetPassword
export const seatAccountResetPassword = async (params: {
  seatGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(
    `${API.API_HOST}?seat.seatAccount.resetPassword`,
    {
      bffAction: 'seat.seatAccount.resetPassword',
      bpoVersion: 2,
      ...params,
    },
  );
  return res;
};

// 批量编辑
export interface SeatAccountBatchEditPrams {
  skillGroupGuid: string;
  seatGuidList: string[];
}

export const seatAccountBatchEdit = async (
  params: SeatAccountBatchEditPrams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?seat.seatAccount.batchEdit`, {
    bffAction: 'seat.seatAccount.batchEdit',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

//批量导入
export const seatAccountBatchImport = async (params: {
  fileUrl: string;
  fileName: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(
    `${API.API_HOST}?seat.seatAccount.batchImport`,
    {
      bffAction: 'seat.seatAccount.batchImport',
      bpoVersion: 2,
      ...params,
    },
  );
  return res;
};
// 下载导入模板 /seat.seatAccount.downloadTemplate
export const seatAccountDownloadTemplate =
  async (): Promise<ICommonResponse> => {
    const res = await request.post(
      `${API.API_HOST}?seat.seatAccount.downTemplate`,
      {
        bffAction: 'seat.seatAccount.downTemplate',
        bpoVersion: 2,
      },
    );
    return res;
  };
// (查询所有技能组)
export const seatAccountQueryAll = async (): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?seat.skillGroup.queryAll`, {
    bffAction: 'seat.skillGroup.queryAll',
    bpoVersion: 2,
  });
  return res;
};

// 座席账号导出
export const seatAccountExport = async (params: {
  seatAccount: string;
  skillGroupGuid: string;
  status: number;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?seat.seatAccount.export`, {
    bffAction: 'seat.seatAccount.export',
    ...params,
    bpoVersion: 2,
  });
  return res;
};
