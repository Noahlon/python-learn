import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse, ICommonResponseList } from '../baseInterface';

/**
 * 数据权限列表interface
 */
export interface AccessListParams {
  pageSize: number;
  pageNum: number;
  userName?: string;
  trueName?: string;
  userSource?: number;
  tenant?: number;
}

export interface AccessListObj {
  id: string;
  guid: string;
  userName: string;
  trueName?: string;
  userSource: number;
  userSourceDesc: string;
  tenantIdList: number[];
  tenantNameList: string[];
  createBy: string;
  createTime: string;
  updateTime: string;
  superButton: number;
}

type AccessListRes = ICommonResponseList<AccessListObj>;

/**
 * 创建、编辑数据权限interface
 */
export interface AccessUpdateParams {
  id?: string;
  userName: string;
  trueName?: string;
  guid?: string;
  userSource: number;
  tenantIdList: number[];
  superButton?: number;
}

/**
 * 根据用户信息查询账号完整信息interface
 */
export interface UserInfoRes extends ICommonResponse {
  data: {
    id?: number;
    bizGuid?: string;
    userName?: string;
    trueName?: string;
    creatorName?: string;
    creatorTrueName?: string;
    updaterName?: string;
    employeeId?: number;
    createTime?: string;
    updateTime?: string;
    userSource?: number;
    userWorkNum?: string;
    positionStatus?: number;
    rangeType?: number;
  };
}

/**
 * 账号类型枚举列表interface
 */
export interface UserSourceListRes extends ICommonResponse {
  data: {
    userSourceCode: number;
    userSourceName: string;
  }[];
}

// -------------------------------------------------

// 数据权限列表
export const queryAccessList = async (
  params: AccessListParams,
): Promise<AccessListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'tenant.access.page',
    ...params,
  });
  return res;
};

// 创建数据权限
export const cteateAccess = async (
  params: AccessUpdateParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'tenant.access.create',
    ...params,
  });
  return res;
};

// 编辑数据权限
export const updateAccess = async (
  params: AccessUpdateParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'tenant.access.update',
    ...params,
  });
  return res;
};

// 根据用户信息查询账号完整信息
export const queryAccessUserInfo = async (params: {
  email: string;
  userSource: number;
}): Promise<UserInfoRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'tenant.access.user.info',
    ...params,
  });
  return res;
};

// 账号类型枚举列表
export const queryUserSourceList = async (): Promise<UserSourceListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'tenant.access.usersource',
  });
  return res;
};
