import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse, ICommonResponseList } from '../baseInterface';

/**
 * 分页查询技能组列表interface
 */
export interface SkillGroupParams {
  skillGroupName?: string;
  status?: number;
  groupLeaderName?: string;
  tenantList?: number[];
  managerName?: string;
  pageSize?: number;
  pageNum?: number;
}

export interface SkillGroupObj {
  skillGroupGuid?: string;
  skillGroupName?: string;
  groupLeaderGuid?: string;
  groupLeaderName?: string;
  tenantList?: {
    code: number;
    name: string;
  }[];
  remark?: string;
  status?: number;
  seatCount?: number;
  managerList?: {
    managerGuid?: string;
    managerName?: string;
  }[];
}

type SkillGroupRes = ICommonResponseList<SkillGroupObj>;

/**
 * 新增/编辑技能组interface
 */
export interface SkillUpdateParams {
  skillGroupGuid?: string;
  skillGroupName: string;
  groupLeaderGuid: string;
  tenantList: number[];
  addedSeatList?: string[];
  deletedSeatList?: string[];
  status: number;
  remark?: string;
  managerGuidList: string[];
}

/**
 * 查询技能组详情interface
 */
export interface SeatObj {
  seatGuid?: string;
  seatName?: string;
  seatAccount?: string;
  createTime?: string;
}

export interface SkillDetailRes extends ICommonResponse {
  data: {
    skillGroupGuid?: string;
    skillGroupName?: string;
    groupLeaderGuid?: string;
    groupLeaderName?: string;
    tenantList?: {
      code: number;
      name: string;
    }[];
    remark?: string;
    status?: number;
    seatCount?: number;
    seatList?: SeatObj[];
    managerList?: {
      managerGuid?: string;
      managerName?: string;
    }[];
  };
}

/**
 * 预删除interface
 */
export interface PreDelRes extends ICommonResponse {
  data: {
    errorMsg?: string;
    delSuccess: boolean;
  };
}

/**
 * 查询所有技能组interface
 */
export interface AllSkillGroupObj {
  skillGroupGuid?: string;
  skillGroupName?: string;
  groupLeaderGuid?: string;
  groupLeaderName?: string;
  seatCount?: number;
}
export interface AllSkillGroupRes extends ICommonResponse {
  data: AllSkillGroupObj[];
}

/**
 * 查询所有启用的座席interface
 */
export interface SeatAccountObj {
  seatGuid?: string;
  seatName?: string;
  seatAccount?: string;
  createTime?: string;
}

export interface SeatAccountRes extends ICommonResponse {
  data: SeatAccountObj[];
}

// -------------------------------------------------

// 分页查询技能组列表
export const querySkillGroup = async (
  params: SkillGroupParams,
): Promise<SkillGroupRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'seat.skillGroup.listPage',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

//  新增/编辑技能组
export const updateSkillGroup = async (
  params: SkillUpdateParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'seat.skillGroup.modify',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 查询技能组详情
export const queryskillGroupDetail = async (params: {
  skillGroupGuid: string;
}): Promise<SkillDetailRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'seat.skillGroup.queryDetail',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 预删除租户
export const preDelTenant = async (params: {
  tenantCode: number;
  skillGroupGuid: string;
}): Promise<PreDelRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'seat.skillGroup.preDelTenant',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 预删除座席
export const preDelSeat = async (params: {
  seatGuid: string;
  skillGroupGuid: string;
}): Promise<PreDelRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'seat.skillGroup.preDelSeat',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 查询所有技能组
export const queryAllSkillGroup = async (
  params: {
    tenantCodeList?: number[];
  } = {},
): Promise<AllSkillGroupRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'seat.skillGroup.queryAll',
    bpoVersion: 2,
    ...params,
  });
  return res;
};

// 查询所有启用的座席
export const querySeatAccount = async (
  params: {
    skillGroupFilterTag?: boolean;
  } = {},
): Promise<SeatAccountRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'seat.seatAccount.listSeat',
    bpoVersion: 2,
    ...params,
  });
  return res;
};
