import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface IDistributeRuleList {
  channelId: number;
  channelName?: string;
  percentage: string;
  taskTemplateId: string;
  taskTemplateName?: string;
  planChannelTaskId?: string;
  planChannelTaskStatus?: number;
  planChannelTaskStatusDesc?: string;
}

export interface ITemplateInfo {
  templateId?: string;
  templateName: string;
  tenantCode: string;
  tenantName?: string;
  distributeType: number;
  distributeRuleList?: IDistributeRuleList[];
  latestUseTime?: string;
  creator?: string;
  createTime?: string;
}

export interface IPlanInfo {
  id?: string;
  distributePlanName?: string;
  tenantCode?: string;
  tenantName?: string;
  distributeType?: number;
  distributeTypeDesc?: string;
  distributeRuleList?: IDistributeRuleList[];
}

export interface IChannelList {
  channelId: number;
  channelName: string;
}

interface ChannelListRes extends ICommonResponse {
  data: IChannelList[];
}

interface ITemplateList {
  templateId: string;
  templateName: string;
}

interface IChannelTemplateList extends ICommonResponse {
  data: {
    channelId: number;
    channelName: string;
    templateList: ITemplateList[];
  };
}

// 创建计划模板
export const createPlanTemplate = async (
  params: ITemplateInfo,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'plan.template.create',
    ...params,
  });
  return res;
};

// 编辑计划模板
export const editPlanTemplate = async (
  params: ITemplateInfo,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'plan.template.edit',
    ...params,
  });
  return res;
};

// 查询渠道商列表（不带分页）
export const queryChannelList = async (): Promise<ChannelListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'channel.list',
  });
  return res;
};

// 查询渠道任务模板列表（不带分页）
export const queryChannelTemplateList = async (params: {
  channelId: number;
  tenantCode: number;
}): Promise<IChannelTemplateList> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'channel.template.list',
  });
  return res.data;
};
