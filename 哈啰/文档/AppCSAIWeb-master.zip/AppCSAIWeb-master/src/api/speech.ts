import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';
import { ICallDetailRes } from './call';

export interface ISpeechListReq {
  pageSize: number;
  pageNum: number;
  speechName?: string;
  status?: string;
  tenant?: string;
  tenants?: string[];
  existDraft?: number;
  notAllowRepeat?: boolean;
  isTransfer?: boolean;
  isSpeechVariable?: number;
}

export interface ISpeechInfo {
  tenant?: number;
  isDraft?: number;
  isVisiable?: number;
  tenantDesc?: string;
  bizSceneDesc?: string;
  bizName?: string;
  bizScene?: string;
  speechName?: string;
  desc?: string;
  nodePhases?: string;
  nodes?: string;
  guid?: string;
  groupId?: string;
  speechVersion?: string;
  statusLabel?: string;
  status?: number;
  intentionCollections?: {
    intentionCollectionId: string;
    intentionCollectionName: string;
  }[];
  bizId?: string;
  flowCanvasInfo?: string;
  ttsServer: string;
  modelId: string;
  isFullTtsCompose?: boolean;
  chineseForeignCompare: number;
  acousticsParams: IAcousticsParam[];
  isTransfer?: boolean;
  transferVersion?: number;
  isSpeechVariable?: number;
  recordGather: boolean;
}

export interface ISpeechListRes extends ICommonResponse {
  data: {
    totalRecord: number;
    list: ISpeechInfo[];
  };
}

export interface IAddSpeechReq {
  guid?: string;
  speechId?: string;
  copySpeechGuid?: string;
  speechName: string;
  desc?: string;
  bizId: string;
  tenant: number;
  bizScene: number;
  intentionCollectionIds?: string[];
  ttsServer: string;
  modelId: string;
  isFullTtsCompose?: boolean;
  speechRate?: number;
  pitchRate?: number;
  volume?: number;
  asrCode?: string;
  asrServer?: string;
}

export interface IAudioListReq {
  pageSize: number;
  pageNum: number;
  corpusName?: string;
  speechGuid?: string;
  asc?: boolean;
}

export interface IAudioInfo {
  childProcessName?: string;
  corpusName?: string;
  corpusSource?: number;
  id: string;
  contentText?: string;
  corpusStatus?: number;
  updateTime?: string;
  corpusFileUri?: string;
  order: number;
}

export interface IAudioListRes extends ICommonResponse {
  data: {
    totalRecord: number;
    list: IAudioInfo[];
  };
}

export interface Intention {
  id: string;
  name?: string;
  list?: string;
}

export interface ICorpusContent {
  order: number;
  type: number;
  contentText?: string;
  variableInfo?: {
    variableCode?: string;
    variableName?: string;
    variableValueCompletion?: string;
    preVariableValueCompletion?: string;
  };
}

export interface ICorpus {
  id: string;
  corpusName: string;
  corpusContentDetails?: ICorpusContent[];
  tenant?: number;
  description?: string;
  breakType?: number;
  breakTypeLabel?: string;
  priority?: string;
  updateTime?: string;
  intentionIds?: string[];
  intentions?: Intention[];
  intentionLabels?: string[];
  intentionClassification?: string;
  jumpType?: number;
  jumpTypeLabel?: string;
  author?: string;
  corePhrases?: string[];
  smsTemplateId?: string;
  playEndTimeoutButton?: number;
  playEndTimeout?: number;
  unBreakableDuration?: number;
  unBreakableDurationButton?: number;
}

export interface ICorpusListReq {
  pageSize: number;
  pageNum: number;
  corpusName?: string;
  corpusSource?: number;
  breakType?: number;
  speechGuid?: string;
  triggerSendMsg?:boolean
}

export interface ICorpusListRes extends ICommonResponse {
  data: {
    totalRecord: number;
    list: ICorpus[];
  };
}

export interface IEditCorpusReq {
  id?: string;
  corpusSource: string;
  speechGuid?: string;
  corpusName: string;
  intentionIds?: string[];
  intentionLabels?: string[];
  intentionClassification?: string;
  contentText?: string;
  priority?: string;
  breakType?: number;
  jumpType?: number;
  playRepeatButton?: number;
}

export interface ITradeSpeechList {
  children: ITradeSpeechList[];
  guid: string;
  level: number;
  name: string;
  type: number;
  disabled?: boolean;
  speechGroupId?: string;
}

export interface ITradeSpeechListRes extends ICommonResponse {
  data: ITradeSpeechList[];
}

export interface ISpeechTrain {
  speechTrainId: string;
  createTime: string;
  sessionId: string;
  callTestType?: number;
  callLineName?: string;
  calledNumber?: string;
  callLineGuid?: string;
  callLineSupplierGuid?: string; // 线路供应商
  ccServer?: string; // 呼叫中心枚举值
}

export interface ITrainSpeechListRes extends ICommonResponse {
  data: ISpeechTrain[];
}

export interface IVariable {
  id: string;
  speechGuid: string;
  variableName: string;
  variableType: number;
  variableCode: string;
  defaultValue: string;
  useCount: number;
  useCorpus: string[];
  variableValueCompletion?: string;
  preVariableValueCompletion?: string;
}

export interface IVariableListRes extends ICommonResponse {
  data: IVariable[];
}

export interface ITTS {
  ttsServer: string;
  ttsServerName: string;
  ttsParameter: {
    speechRateMin?: number;
    speechRateMax?: number;
    speechRate?: number;
    speechStep?: number;
    pitchRateMin?: number;
    pitchRateMax?: number;
    pitchRate?: number;
    pitchStep?: number;
    volumeMin?: number;
    volumeMax?: number;
    volume?: number;
  };
  children: {
    ttsSpeakerCode: string;
    ttsVoiceName: string;
    ttsSpeakerTagColor?: string;
    ttsSpeakerTag?: string;
  }[];
  fullTtsSetFlag: boolean;
}

export interface ITTSListRes extends ICommonResponse {
  data: {
    ttsVoiceServerDTOList: ITTS[];
  };
}

export default interface AsrServer {
  asrServer: string;
  asrServerName: string;
  children: {
    asrCode: string;
    asrName: string;
  }[];
}

export interface IAsrCodeListRes extends ICommonResponse {
  data: {
    asrVoiceServerDTOList: AsrServer[];
  };
}

export interface IAcousticsParam {
  type?: number;
  desc?: string;
  value?: string;
  name?: string;
}

export interface ITTSVoiceRes {
  text: string;
  voiceCode: string;
  ttsReqParam: {
    speechRate: number;
    pitchRate: number;
    volume: number;
  };
  ttsServer: string;
  asrCode?: string;
}

export interface IAcousticeListRes extends ICommonResponse {
  data: IAcousticsParam[];
}

export interface IAudioProofread {
  speechGuid?: string;
  id?: string;
  corpusName?: string;
  contentLength?: number;
  audioPlayTime?: number;
  corpusFileUri?: string;
  audioTextLength?: number;
  proofreadTime?: string;
  order: number;
  contentText?: string;
  proofreadResult: {
    type?: number;
    text?: string;
  }[];
}

export interface IAudioProofreadRes extends ICommonResponse {
  data: {
    totalRecord: number;
    list: IAudioProofread[];
  };
}

export interface ICallDurationInfo {
  index: string;
  number: string;
  rate: string | number;
}

export interface IDailyAverageCallInfo {
  speechGuid: string;
  speechVersion: string;
  averageTime: string;
  date: string;
  dateStr: string;
}

export interface IMainHangUp {
  corpusName: string;
  count: string;
  rate: string;
  hitCorpusHandUpRate: string;
}

export interface IHitInfo {
  name: string;
  count: string;
}

export interface IStatisticRes extends ICommonResponse {
  data: {
    callDurationInfoList: ICallDurationInfo[];
    averageCallDuration: string;
    dailyAverageCallInfoList: IDailyAverageCallInfo[];
    mainList: IMainHangUp[];
    answerList: IMainHangUp[];
    hitIntentionList: IHitInfo[];
    hitAnswerList: IHitInfo[];
    notHitIntentionList: string[];
    notHitAnswerList: string[];
  };
}

export interface IStatisticChart {
  data: string;
  dataStr: string;
  name: string;
  number: string;
  rate: string | number;
}

export interface ITrainUserInfo {
  variableCode?: string;
  variableType?: number;
  calledNumber?: string;
  callGuid?: string;
  variableValue?: string;
  variableName?: string;
  callId?: string;
}

export interface IStatisticChartRes extends ICommonResponse {
  data: IStatisticChart[];
}

export interface SpeechListRes extends ICommonResponse {
  guid?: string;
  speechName?: string;
  desc?: string;
}

// 话术列表
export const getSpeechList = async (
  params: ISpeechListReq,
): Promise<ISpeechListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.listSpeech',
  });
  return res;
};

// 话术列表（不分页，转接/未转接的话术）
export const getSpeechOpts = async (params: {
  tenantCode: number;
  transfer: boolean;
  bpoVersion?: number;
}): Promise<SpeechListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'speech.list',
  });
  return res;
};

// 新增话术
export const addSpeech = async (
  params: IAddSpeechReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.create',
  });
  return res;
};

// 编辑话术
export const editSpeech = async (
  params: IAddSpeechReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.editSpeech',
  });
  return res;
};

// 复制话术
export const copySpeech = async (
  params: IAddSpeechReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.copy',
  });
  return res;
};

// 音频列表
export const getAudioPageInfo = async (
  params: IAudioListReq,
): Promise<IAudioListRes> => {
  const res = await request.post<IAudioListRes, IAudioListRes>(
    `${API.API_HOST}`,
    {
      ...params,
      bffAction: 'css.call.audio.getAudioPageInfo',
    },
  );
  return res;
};

// 音频编辑
export const editAudio = async (params: {
  id: string;
  contentText: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.audio.edit',
  });
  return res;
};

// 音频重置
export const audioReset = async (params: {
  id: string;
  corpusStatus: number;
  order?: number;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.audio.audioReset',
  });
  return res;
};

// 分发后修改音频状态
export const editAudioStatus = async (params: {
  id: string;
  corpusFileUri?: string;
  corpusFileKey?: string;
  order: number;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.audio.editAudioStatus',
  });
  return res;
};

// 音频管理批量下载
export const getCorpusFileUriLists = async (params: {
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.audio.batchDownload',
  });
  return res;
};

// 音频管理批量上传
export const corpusFileBatchUpload = async (params: {
  speechGuid: string;
  ossUrl: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.audio.batchUpload',
  });
  return res;
};

// 音频管理批量上传
export const corpusFileBatchUploadV2 = async (params: {
  speechGuid: string;
  audioUploadDatas?: { fileName: string; ossUrl: string }[];
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.audio.batchUploadV2',
  });
  return res;
};

// 批量tts生成
export const corpusTTS = async (params: {
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.audio.batchGeneration',
  });
  return res;
};

// 语料上传
export const corpusUpload = async (params: {
  name: string;
  contentText: string;
  corpusFileUri: string;
  order: number;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.corpus.upload',
  });
  return res;
};

// 主流程语料保存check（检查语料名称是否重复）
export const checkSpeechName = async (params: {
  guid: string;
  corpusId: string;
  corpusName: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.check',
  });
  return res;
};

// 语料列表
export const getCorpusList = async (
  params: ICorpusListReq,
): Promise<ICorpusListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.corpus.list',
  });
  return res;
};

// 根据id集合查找语料列表
export const getCorpusListByIds = async (params: {
  ids?: string[];
  speechGuid: string;
  corpusName?: string;
  corpusSource: number;
}): Promise<ICorpus[]> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.corpus.list.short',
  });
  return res.data;
};

// 新增语料
export const addCorpus = async (
  params: IEditCorpusReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.corpus.create',
  });
  return res;
};

// 编辑语料
export const editCorpus = async (
  params: IEditCorpusReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.corpus.update',
  });
  return res;
};

// 特殊场景-新增语料
export const addSceneCorpus = async (
  params: IEditCorpusReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.corpus.create.special',
  });
  return res;
};

// 特殊场景-编辑语料
export const editSceneCorpus = async (
  params: IEditCorpusReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.corpus.update.special',
  });
  return res;
};

// 删除语料
export const deleteCorpus = async (params: {
  id: string;
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.corpus.delete',
  });
  return res;
};

// 批量导出语料
export const exportBatchCorpus = async (params: {
  corpusName?: string;
  corpusSource: number;
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.corpus.export',
  });
  return res;
};

// 批量导入语料
export const importBatchCorpus = async (params: {
  speechGuid: string;
  corpusFileUri: string;
  bizId: string;
  kcIds?: string[];
  corpusSource?: any;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.corpus.import',
  });
  return res;
};

// // 获取答疑库导出模版文件
// export const getExportCorpusTemplate = async (params): Promise<ICommonResponse> => {
//   const res = await request.post(`${API.API_HOST}`, {
//     ...params,
//     bffAction: 'css.call.corpue.template',
//   });
//   return res;
// };

// 特殊场景排序
export const speechSortTabs = async (params: {
  preId?: string;
  afterId?: string;
  id: string;
  speechGuid: string;
  corpusSource: any;
  sort: number;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.corpus.update.sort.sp',
    ...params,
  });
  return res;
};

// 意向分类-分类列表
export const classificationList = async (params: {
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.classification.list',
    ...params,
  });
  return res;
};

// 意向分类-分类更新
export const classificationUpdate = async (params: {
  id: string;
  classificationName: string;
  classificationDesc: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.classification.update',
    ...params,
  });
  return res;
};

// 意向分类-新增意向分类
export const classificationAdd = async (params: {
  speechGuid: string;
  classificationName: string;
  classificationDesc: string;
  classification: string; //分类
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.classification.add',
    ...params,
  });
  return res;
};

// 意向分类-分类排序
export const classificationSort = async (params: {
  speechGuid: string;
  preId: string;
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.classification.sort',
    ...params,
  });
  return res;
};

// 意向分类-标签列表
export const classificationLabelList = async (params: {
  speechGuid?: string;
  groupCode: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.label.list',
    ...params,
  });
  return res;
};

// 意向分类-标签更新
export const classificationLabelUpdate = async (params: {
  id: string;
  labelName: string;
  speechGuid: string;
  groupId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.label.update',
    ...params,
  });
  return res;
};

// 意向分类-创建标签
export const classificationLabelCreateBatch = async (params: {
  speechGuid: string;
  labels: any;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.label.create.batch',
    ...params,
  });
  return res;
};

// 意向分类-删除标签
export const classificationLabelDelete = async (params: {
  id: string;
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.label.delete',
    ...params,
  });
  return res;
};

// 意向分类-标签
export const classificationLabelCheck = async (params: {
  labelNames: string;
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.label.check',
    ...params,
  });
  return res;
};

// 根据行业获取话术
export const getSpeechListByTrade = async (params: {
  status: number;
}): Promise<ITradeSpeechListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.listWithBiz',
    ...params,
  });
  return res;
};

// 版本记录
export const getVersion = async (params: {
  groupId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.version.list',
    ...params,
  });
  return res;
};

// 草稿保存
export const saveCache = async (params: {
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.refreshSpCache',
    ...params,
  });
  return res;
};

// 版本发布
export const published = async (params: {
  guid: string;
  speechVersion?: string;
  versionDesc?: string;
  speechVersionName?: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.publish',
    ...params,
  });
  return res;
};

// 版本发布之前校验
export const publishCheck = async (params: {
  guid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.publish.check',
    ...params,
  });
  return res;
};

// 标签组列表
export const labelGrouplList = async (params: {
  speechGuid?: string;
  groupId?: string;
  haveDefault?: boolean;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.label.group.list',
    ...params,
  });
  return res;
};

// 新增标签组
export const createLabelGroup = async (params: {
  speechGuid?: string;
  id?: string;
  labelGroupName?: string;
  labels?: any[];
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.label.group.create',
    ...params,
  });
  return res;
};

// 删除标签组
export const deleteLabeGrouplList = async (params: {
  id: string;
  speechGuid?: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.label.group.delete',
    ...params,
  });
  return res;
};

// 更新标签组
export const updateLabelGroup = async (params: {
  labelGroupName?: string;
  labels?: string;
  id?: string;
  speechGuid?: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.label.group.update',
    ...params,
  });
  return res;
};

// 拖拽标签组
export const moveLabel = async (params: {
  sourceLabelGroupId: string;
  targetLabelGroupId: string;
  labelIds: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.label.group.move',
    ...params,
  });
  return res;
};

// 获取话术训练历史列表
export const getSpeechTrainList = async (params: {
  groupId?: string;
}): Promise<ITrainSpeechListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.train.list',
  });
  return res;
};

// 话术训练创建
export const createSpeechTrain = async (params: {
  callType: number;
  calledNumber?: number;
  callLineGuid?: string;
  speechGuid: string;
  speechVariables?: any;
  ccServer: string;
}): Promise<ISpeechTrain> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.train.create',
  });
  return res.data;
};

// 话术训练删除
export const deleteSpeechTrain = async (params: {
  speechTrainingId: string;
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.train.delete',
  });
  return res;
};

// 话术训练详情
export const trainDetail = async (params: {
  sessionId: string;
  speechGuid: string;
  translateSwitch?: number;
}): Promise<ICallDetailRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.train.detail',
  });
  return res;
};

// 话术训练用户信息
export const trainVariablesDetail = async (params: {
  sessionId: string;
}): Promise<ITrainUserInfo[]> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.collectVal',
  });
  return res.data;
};

// 批量删除
export const batchDelQABase = async (params: {
  ids: string[];
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.corpus.delete.batch',
  });
  return res;
};

// 音频增加批量重置功能
export const batchResetAudio = async (params: {
  audioList: {
    id: string;
    order: number | string;
  }[];
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.audio.audioResetBatch',
  });
  return res;
};

// 删除草稿
export const deleteDraft = async (params: {
  guid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.draft.delete',
  });
  return res;
};

// 获取变量列表
export const getSpeechVariable = async (params: {
  speechGuid?: string;
}): Promise<IVariableListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speechVariable.find',
  });
  return res;
};

// 删除变量
export const deleteVariable = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speechVariable.delete',
  });
  return res;
};

// 编辑变量
export const editVariable = async (params: {
  id: string;
  variableName: string;
  variableType: number;
  speechGuid: string;
  defaultValue?: string;
  variableValueCompletion?: string;
  preVariableValueCompletion?: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speechVariable.update',
  });
  return res;
};

// 新增变量
export const addVariable = async (params: {
  variableName: string;
  variableType: number;
  speechGuid: string;
  defaultValue?: string;
  variableValueCompletion?: string;
  preVariableValueCompletion?: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speechVariable.add',
  });
  return res;
};

// tts模型列表
export const queryTtsSpeakerList = async (): Promise<ITTSListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'call.voice.queryTtsSpeakerList',
  });
  return res;
};

// asr模型列表
export const queryAsrServerList = async (): Promise<IAsrCodeListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.voice.asr.server.list',
  });
  return res;
};

// 获取连续超时
export const timeoutIntention = async (params: {
  pageSize: number;
  pageNum: number;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.timeout.intention.list',
  });
  return res;
};

// 指定语料中的触发意图
export const getSpecifyIntention = async (params: {
  pageSize: number;
  pageNum: number;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.specify.intention.list',
  });
  return res;
};

// 声学参数列表
export const acousticsParamList = async (params: {
  pageSize: number;
  pageNum: number;
}): Promise<IAcousticeListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.acoustics.params.list',
  });
  return res;
};

// 声学参数编辑
export const editAcousticsParam = async (params: {
  guid: string;
  acousticsParams: IAcousticsParam[];
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.acoustics.params.edit',
  });
  return res;
};

// 效果试听
export const voiceTTS = async (
  params: ITTSVoiceRes,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.callCenter.voice.tts',
  });
  return res;
};

// 效果试听(返回voiceGuid)
export const voiceTTSNew = async (
  params: ITTSVoiceRes,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.callCenter.voice.tts.new',
  });
  return res;
};

// 获取音频地址
export const queryVoiceUrl = async (params: {
  voiceGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.callCenter.query.voice.url',
  });
  return res;
};

// 获取统计数据
export const getSpeechStatistic = async (params: {
  startCreateTime?: string;
  endCreateTime?: string;
  speechGuid?: string[];
  speechGroupId: string;
  name: string;
}): Promise<IStatisticRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.statistics',
  });
  return res;
};

// 音频校对数据列表
export const getAudioProofreadList = async (params: {
  speechGuid: string;
  pageSize: number;
  pageNum: number;
}): Promise<IAudioProofreadRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.audio.proofread.result',
  });
  return res;
};

// 获取统计数据折线图
export const getSpeechStatisticChart = async (params: {
  speechGuid?: string[];
  speechGroupId: string;
  name: string;
  corpusList?: string[];
  startCreateTime?: string;
  endCreateTime?: string;
  corpusType: number;
}): Promise<IStatisticChartRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.statisticsChart',
  });
  return res;
};

// 音频校对
export const audioStartProofread = async (params: {
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.audio.startProofread',
  });
  return res;
};

// 话术统计导出
export const getSpeechStatisticExport = async (params: {
  speechGuid?: string[];
  speechGroupId: string;
  name: string;
  startCreateTime?: string;
  endCreateTime?: string;
  excelType: number;
  corpusList?: string[];
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.statisticsExcel',
  });
  return res;
};
// 获取短信模板
export const getAllSmsTemplate = async (): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.sms.getAllSmsTemplate',
  });
  return res;
};

// 翻译
export const onlineTranslation = async (params: {
  fileName: string;
  fileUrl: string;
  translateLanguageType: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.online.translation',
    ...params,
  });
  return res;
};

// 下载翻译
export const uploadTranslation = async (params: {
  guid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.online.download.translateFile',
    ...params,
  });
  return res;
};

// 翻译枚举
export const translationLanguage = async (): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.online.translation.language',
  });
  return res;
};

//话术新增迭代
export interface IDversionAddParams {
  copySpeechGuid: string;
  groupId: string;
  speechVersion: string;
  versionDesc: string;
  speechVersionName: string;
}

export const versionAdd = async (
  params: IDversionAddParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.draft.create',
    ...params,
  });
  return res || {};
};

//编辑话术版本
export interface IDversionEditParams {
  speechId: string;
  groupId: string;
  versionDesc: string;
  speechVersionName: string;
}

export const versionEdit = async (
  params: IDversionEditParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.version.edit',
    ...params,
  });
  return res || {};
};

//获取话术最新的版本
export const latestVersion = async (params: {
  groupId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.latestVersion',
    ...params,
  });
  return res || {};
};

//话术版本tab

export interface ISpeechVersionTabDataRes extends ICommonResponse {
  data?: ISpeechVersionTabData[];
}
export interface ISpeechVersionTabData {
  speechGuid?: string;
  speechGroupId?: string;
  status?: number;
  statusLabel?: string;
  speechVersionName?: string;
  speechVersion?: string;
  versionDesc?: string;
  iterationCode?: number;
  iterationCodeDesc?: string;
}
export const speechVersionTab = async (params: {
  groupId: string;
}): Promise<ISpeechVersionTabDataRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.versionTab',
    ...params,
  });
  return res || {};
};
