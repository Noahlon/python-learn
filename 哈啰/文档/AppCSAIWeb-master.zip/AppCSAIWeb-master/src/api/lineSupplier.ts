import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface addSupplierType {
  supplierName: string;
  contacts: string;
  remark: string;
}
export interface findPageType {
  supplierGuid?: string;
  pageSize: number;
  pageNum: number;
  status?: number;
  supporterLineName?: string;
}
export interface editSupplierType {
  supplierName: string;
  contacts: string;
  supplierStatus: number;
  guid: string;
  remark?: string;
}

export interface lineListType {
  supplierGuid: string;
  startDate: string;
  endDate: string;
  pageSize: number;
  pageNum: number;
}
export interface callFrequencyListType {
  frequencyCount: number;
  timePeriod: number;
  timeUnit: string;
}

export interface IUpdateList {
  lineGroupGuid: string;
  lineGuid: string;
  parallelNum: number;
  maxUseParallelNum: number;
}

export interface addRouterType {
  supplierGuid: string;
  supporterLineName: string;
  numberType: number;
  ip: string;
  port: string;
  callingNumber: string;
  concurrentLimit: number;
  prefixCalled?: string;
  realCallingNumber?: string;
  // attributions?: {
  //   province?: string;
  //   city?: string;
  // }[];
  attributions?: any[];
  // province?: string;
  // city?: string;
  price?: string;
  carrier?: number;
  calcPriceUnit?: number;
  dayCallLimit?: number;
  callFrequencyList?: callFrequencyListType[];
  callThroughFrequencyList?: callFrequencyListType[];
  areaLimit?: any;
  remark?: string;
  guid?: string;
  supportGlobalCountry?: number;
}

interface lineAddNumberType {
  attributions?: any[];
  carrier?: number;
  concurrentLimit?: number;
  dayCallLimit?: number;
  lineGuid?: string;
  realCallingNumber?: string;
}

interface SupplierParams {
  guid?: string;
  supplierStatus?: number;
  supplierName?: string;
  supporterLineName?: string;
  callingNumber?: string;
  maxSize?: number;
}

interface LineSupplierRes extends ICommonResponse {
  data: {
    guid?: string;
    supplierName?: string;
    supplierNumber?: string;
    contacts?: string;
    supplierStatus?: number;
    remark?: string;
    createTime?: string;
  }[];
}

interface UnbindTenantLineRes extends ICommonResponse {
  data: {
    withoutCallLine?: boolean;
  };
}

interface AddTenantLineParams {
  lineGuid: string;
  lineGroupGuid: string;
  tenantCode: number;
  parallelNum: number;
}

// 查找线路供应商
export const getLineSupplier = async (
  params?: SupplierParams,
): Promise<LineSupplierRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...(params || {}),
    bffAction: 'css.call.line.findSuppliers',
  });
  return res;
};

// 新增商户
export const addSupplier = async (
  params: addSupplierType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.addSupplier',
  });
  return res;
};

// 分页查询线路
export const findPage = async (
  params: findPageType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.findPage',
  });
  return res;
};

// 添加线路
export const addRouter = async (
  params: addRouterType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.add',
  });
  return res;
};

// 修改路线
export const updateRouter = async (
  params: addRouterType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.update',
  });
  return res;
};

// 修改线路供应商
export const editSupplier = async (
  params: editSupplierType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.updateSupplier',
  });
  return res;
};

// 改变线路状态
export const changeStatus = async (params: {
  guid: string;
  status: number;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.changeStatus',
  });
  return res;
};

// 获取关联租户
export const getLinkTenant = async (params: {
  guid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.tenant.line.use',
  });
  return res;
};

// 根据guid获取路线
export const getRouter = async (params: {
  guid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.get',
  });
  return res;
};

// 上传调试
export const upload = async (params: {
  supplierGuid: string;
  aliOssUrl: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.upload',
  });
  return res;
};

// 简单查询供应商线路
export const findSimple = async (params: {
  supplierGuid: string;
  status: number;
  syncStatus: number;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.findSimple',
  });
  return res;
};

// 查询线路
export const findTenantUse = async (params: {
  supplierGuid: string;
  status: number;
  syncStatus: number;
  tenantId: string;
  callTimes: number;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.findTenantUse',
  });
  return res;
};

// 简单查询供应商
export const findSimpleSupplier = async (params: {
  supplierStatus: number;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'call.line.findSimpleSupplier',
  });
  return res;
};

// 线路管理-数据统计
export const lineStatisticsList = async (
  params: lineListType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.statistics',
  });
  return res;
};

// 线路管理-线路供应商-号码信息-线路号码增加
export const lineAddNumber = async (
  params: lineAddNumberType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.addNumber',
  });
  return res;
};

// 线路管理-线路供应商-号码信息-线路号码修改
export const lineUpdateNumber = async (
  params: lineAddNumberType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.updateNumber',
  });
  return res;
};

// 线路管理-线路供应商-号码信息-修改线路号码状态
export const lineUpdateNumberStatus = async (params: {
  guid: string;
  status: number;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.updateNumberSatus',
  });
  return res;
};

// 线路管理-线路供应商-号码信息-线路号码获取
export const getLineNumber = async (params: {
  guid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.getNumber',
  });
  return res;
};

// 线路管理-线路供应商-号码信息-分页获取线路号码
export const findNumberPage = async (params: {
  lineGuid: string;
  pageSize: number;
  pageNum: number;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.findNumberPage',
  });
  return res;
};

// 线路管理-线路供应商-号码信息-批量修改线路号码
export const batchUpdateNumber = async (params: {
  guids: string[];
  key: string;
  value: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.batchUpdateNumber',
  });
  return res;
};

// 线路管理-线路供应商-号码信息-上传线路号码信息
export const uploadNumbers = async (params: any): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.uploadNumbers',
  });
  return res;
};

// 线路管理-线路供应商-号码信息-批量修改线路号码
export const lineSync = async (params: {
  guid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.line.sync',
  });
  return res;
};

// 线路管理-线路供应商-号码信息-批量修改线路号码
export const initiate = async (params: {
  userPhone?: string;
  realCallingNumber?: string;
  speechId?: string;
  tenant?: number;
  bizScene?: string;
  ccServer: string;
  lineGuid: string;
}) => {
  const res = await request.post(
    `${API.API_HOST}`,
    {
      ...params,
      bffAction: 'css.call.dialogue.initiate',
    },
    {
      noValidate: true,
    },
  );
  return res;
};

// 查询所有线路
export const findAllSuppliers = async (params?: {
  bpoVersion?: number;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.line.findSuppliers.all',
    ...params,
  });
  return res;
};

//查询线路关联情况
export const queryAllTenantLinePage = async (params?: {
  lineGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.line.page',
    ...params,
  });
  return res;
};

//新增线路关联
export const addTenantLine = async (
  params: AddTenantLineParams,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.tenant.line.add',
  });
  return res;
};

//解除线路关联
export const unbindTenantLine = async (params: {
  lineGuid: string;
  lineGroupGuid: string;
  forceUnBind: boolean;
}): Promise<UnbindTenantLineRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.tenant.line.unbind',
  });
  return res;
};

//通过租户查询可关联的线路组
export const queryTenantLineBindGroup = async (params?: {
  lineGuid: string;
  tenantCode: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.line.bindGroup',
    ...params,
  });
  return res;
};

//修改线路组线路并发
export const updateTenantParallel = async (params?: {
  updateList: IUpdateList[];
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.update.parallel',
    ...params,
  });
  return res;
};
