import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

interface IListDataType {
  supplierName: string;
  guid: string;
  supplierCode: string;
  billMonth: string;
  uploadUserName: string;
  uploadTime: string;
}

interface ICallDetailInput {
  msg: string;
  code: number;
  data: {
    totalPages: number;
    totalRecord: number;
    list: IListDataType[];
    pageNum: number;
  };
  success: boolean;
}

// 模板下载
export const getDownloadUrl = async (): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.bill.downloadTemplate',
  });
  return res;
};
// 明细导入
export const getUploadDetail = async (params: {
  supplierCode: string;
  billMonth: string;
  fileUrl: string;
  fileName: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.bill.uploadBill',
  });
  return res;
};
// 明细删除
export const getDeleteDetail = async (
  guid: string,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    guid,
    bffAction: 'css.call.bill.deleteBill',
  });
  return res;
};
// 分页查询导入记录列表
export const getCallDetailSearch = async (params: {
  billMonth: string;
  pageNum: number;
  pageSize: number;
}): Promise<ICallDetailInput> => {
  const res: ICallDetailInput = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.bill.uploadRecordPage',
  });
  return res;
};
