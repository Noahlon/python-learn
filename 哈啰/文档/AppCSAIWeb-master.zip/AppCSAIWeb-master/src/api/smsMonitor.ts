import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

/**
 * 查询短信监控-短信模版列表interface
 */
export interface SmsMonitorParams {
  templateName?: string;
  tenantIds?: string[];
  smsProviderTypes?: number[];
  channelName?: string;
  startDate: string;
  endDate: string;
  querySource: number;
  pageNum?: number;
  pageSize?: number;
  sort?: number;
  sortParam?: string;
  sortAsc?: number;
}
export interface SmsMonitorObj {
  fifteenMinSmsTotalNum?: number;
  templateName?: string;
  templateId?: number;
  tenantId?: string;
  tenantName?: string;
  smsProviderName?: string;
  channelName?: string;
  channelId?: string;
  todaySmsTotalNum?: number;
  dialogueTodayNum?: number;
  dialogueFifteenMinNum?: number;
  compensateTodayNum?: number;
  compensateFifteenMinNum?: number;
  sendSuccessTodayNum?: number;
  sendSuccessTodayRate?: number;
  sendSuccessFifteenMinNum?: number;
  sendSuccessFifteenMinRate?: number;
  sendFailTodayNum?: number;
  sendFailTodayRate?: number;
  sendFailFifteenMinNum?: number;
  sendFailFifteenMinRate?: number;
  sendUnKnownTodayNum?: number;
  sendUnKnownTodayRate?: number;
  sendUnKnownFifteenMinNum?: number;
  sendUnKnownFifteenMinRate?: number;
  routeFailTodayNum?: number;
  routeFailTodayRate?: number;
  routeFailFifteenMinNum?: number;
  routeFailFifteenMinRate?: number;
  sendLimitTodayNum?: number;
  sendLimitTodayRate?: number;
  sendLimitFifteenMinNum?: number;
  sendLimitFifteenMinRate?: number;
  noConcurrencyTodayNum?: number;
  noConcurrencyTodayRate?: number;
  noConcurrencyFifteenMinNum?: number;
  noConcurrencyFifteenMinRate?: number;
  unicomBillingUnitPrice?: number;
  mobileBillingUnitPrice?: number;
  telecomBillingUnitPrice?: number;
  otherBillingUnitPrice?: number;
}

export interface SmsMonitorRes extends ICommonResponse {
  data: {
    pageNum: number;
    pageSize: number;
    totalRecord: number;
    totalPages: number;
    list: SmsMonitorObj[];
  };
}

/**
 * （发送/路由）查看详情interface
 */
export interface SmsSendRouteResultParams {
  pageNum?: number;
  pageSize?: number;
  templateId?: number;
  channelId?: string;
  startDate?: string;
  endDate?: string;
  minType?: number;
  querySource?: number;
}

interface IPolyLineList {
  statisticsDate?: string;
  minTotalNum?: number;
  desc?: string;
  inner?: IInnerOuter[];
}

interface IInnerOuter {
  num?: number;
  rate?: number;
  desc?: number;
}

export interface SmsSendRouteResultRes extends ICommonResponse {
  data: {
    totalNum?: number;
    outer?: IInnerOuter[];
    list?: IPolyLineList[];
  };
}

/**
 * 短信模版查看详情导出interface
 */
interface templateExportParams {
  pageNum?: number;
  pageSize?: number;
  templateId?: number;
  channelId?: string;
  startDate?: string;
  endDate?: string;
  exportType?: number;
}

interface templateExportRes extends ICommonResponse {
  data: {
    ossUrl: string;
  };
}

export interface ReqSmsMonitorHisData {
  tenantIds?: string[];
  templateName?: string;
  startDate: string;
  endDate: string;
}

export interface SmsMonitorHisDataList extends ICommonResponse {
  tenantId?: string;
  id?: number;
  dateDesc?: string;
  tenantName?: string;
  templateName?: string;
  templateId?: string;
  billingTotalNum?: number;
  billingPrice?: string;
  billingTotal?: string;
  todaySmsTotalNum?: number;
  dialogueTotalNum?: number;
  compensateTotalNum?: number;
  sendSuccessTotalNum?: number;
  sendSuccessTotalRate?: number;
  sendFailTotalNum?: number;
  sendFailTotalRate?: number;
  sendUnKnownTotalNum?: number;
  sendUnKnownTotalRate?: number;
  routeFailTotalNum?: number;
  routeFailTotalRate?: number;
  sendLimitTotalNum?: number;
  sendLimitTotalRate?: number;
  noConcurrencyTotalNum?: number;
  noConcurrencyTotalRate?: number;
  belongRouteFailTotalNum?: number;
  belongRouteFailTotalRate?: number;
  unicomBillingUnitPrice?: number;
  mobileBillingUnitPrice?: number;
  telecomBillingUnitPrice?: number;
  otherBillingUnitPrice?: number;
}

export interface SmsMonitorHisData {
  pageNum?: number;
  pageSize?: number;
  totalRecord?: number;
  totalPages?: number;
  namelistNum?: number;
  list?: SmsMonitorHisDataList[];
}

interface DosageExportRes extends ICommonResponse {
  data: {
    ossUrl: string;
  };
}

export interface SmsMonitorHisReq {
  pageSize: number;
  pageNum: number;
  tenantIds?: string[];
  templateName?: string;
  startDate: string;
  endDate: string;
}

export interface SmsMonitorHisListRes extends ICommonResponse {
  data?: SmsMonitorHisListData;
}

/* 自动生成的 Interface */

export interface SmsMonitorHisListData {
  billingTotalNum?: number;
  billingPrice?: string;
  billingTotal?: string;
  todaySmsTotalNum?: number;
  dialogueTotalNum?: number;
  compensateTotalNum?: number;
  sendSuccessTotalNum?: number;
  sendSuccessTotalRate?: number;
  sendFailTotalNum?: number;
  sendFailTotalRate?: number;
  sendUnKnownTotalNum?: number;
  sendUnKnownTotalRate?: number;
  routeFailTotalNum?: number;
  routeFailTotalRate?: number;
  sendLimitTotalNum?: number;
  sendLimitTotalRate?: number;
  noConcurrencyTotalNum?: number;
  noConcurrencyTotalRate?: number;
  belongRouteFailTotalNum?: number;
  belongRouteFailTotalRate?: number;
}

// -----------------------------

// 查询短信监控-短信模版列表
export const queryMonitorList = async (
  params: SmsMonitorParams,
): Promise<SmsMonitorRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.sms.monitor.list',
    ...params,
  });
  return res;
};

// 发送查看详情
export const querySmsSendResult = async (
  params: SmsSendRouteResultParams,
): Promise<SmsSendRouteResultRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.sms.sendResult.detail',
    ...params,
  });
  return res;
};

// 路由结果查看详情
export const querySmsRouteResult = async (
  params: SmsSendRouteResultParams,
): Promise<SmsSendRouteResultRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.sms.routeResult.detail',
    ...params,
  });
  return res;
};

// 导出
export const exportSmsTemplate = async (
  params: templateExportParams,
): Promise<templateExportRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.sms.template.export',
    ...params,
  });
  return res;
};

// 短信模版历史列表-统计栏
export const monitorHisStatistics = async (
  params: ReqSmsMonitorHisData,
): Promise<SmsMonitorHisListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.monitorHis.statistics',
    ...params,
  });
  return res;
};

// 短信模版历史列表-导出 sms.monitorHis.export
export const smsMonitorHisExport = async (
  params: ReqSmsMonitorHisData,
): Promise<DosageExportRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.monitorHis.export',
    ...params,
  });
  return res;
};

// 查询短信监控-短信模版列表
export const smsMonitorHisList = async (
  params: SmsMonitorHisReq,
): Promise<SmsMonitorRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.monitorHis.list',
    ...params,
  });
  return res;
};
