import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface UpdateTenantType {
  id: '3961576266541826049';
  name: string;
  contact: string;
  remark: string;
  code: number;
  voiceServiceBillingModel: number;
}

export interface CreateTenantType {
  name: string;
  contact: string;
  remark: string;
  voiceServiceBillingModel: number;
  // code: number;
}

// export interface TenantLineListType {
//   tenantId: string;
//   pageSize: number;
//   pageNum: number;
//   callTimes: number;
//   callLineId?: string;
// }

export interface TenantLineNumberResultType {
  tenantId?: string;
  tenantLineId?: string;
  routeProvince?: boolean;
  routeCountry?: boolean;
  routeArea?: boolean;
  routeCity?: boolean;
  maxCallOneDay?: number;
  maxCallConcurrent?: number;
  lineNumberId: string;
  lineId?: string;
  id?: string;
  callNumber?: string;
  callNumberBelong?: ProvinceCityType[];
}

export interface ProvinceCityType {
  city: string;
  province: string;
}

// export interface TenantLineCreateType {
//   tenantId: string;
//   callLineId: string;
//   parallelNum: number;
//   maxUseParallelNum: number;
//   callTimes: number;
// }

// export interface TenantLineUpdateType {
//   id: string;
//   tenantId: string;
//   callLineId: string;
//   parallelNum: number;
//   maxUseParallelNum: number;
//   callTimes: number;
// }

// export interface TenantLineNumberListParamsType {
//   tenantId?: string;
//   callLineId?: string;
//   pageNum: number;
//   pageSize: number;
//   tenantLineId?: string;
//   id?: string;
//   callNumber?: string;
//   callNumberBelong?: any;
//   isFilter?: boolean;
//   isUse?: boolean;
// }

export interface ITenantConfigInfo {
  tenantId: string;
  thirdBlacklistIntercept?: number;
  featureIntercept?: number;
  differentIntercept?: number;
  platformBlacklistIntercept?: number;
  platformFrequencyIntercept?: number;
}

export interface ITenantConfigRes extends ICommonResponse {
  data: ITenantConfigInfo;
}

export interface ITenantNumber {
  lineNumberId: string;
  routeCity?: boolean;
  routeProvince?: boolean;
  routeArea?: boolean;
  routeCountry?: boolean;
}

// export interface ITenantNumberAddReq {
//   id: string;
//   callNumberList: ITenantNumber[];
// }

export interface ITenantLineNumberInfo {
  list: TenantLineNumberResultType[];
  totalRecord: number;
  pageNum: number;
  pageSize: number;
}

export interface ITenantLineNumberRes extends ICommonResponse {
  data: ITenantLineNumberInfo;
}

// 租户列表（带分页）
export interface TenantListType {
  pageSize: number;
  pageNum: number;
  tenantName?: string;
}

export interface voiceServiceBillingModelObj {
  id: number;
  name: string;
}

export interface TenantListObj {
  id?: string;
  tenant: number;
  desc?: string;
  name?: string;
  code?: number;
  contact?: string;
  createTime?: string;
  remark?: string;
  updateTime?: string;
  voiceServiceBillingModel?: number;
  voiceServiceBillingModelDetail?: voiceServiceBillingModelObj;
  useTransfer?: number;
  transferVersion: number;
  paymentCompanyName?: string;
  billingModel:string;
  aiMaxDuration: number;
  humanMaxDuration: number;
  customType?:number;
}

export interface TenantListRes extends ICommonResponse {
  data: {
    pageNum: number;
    pageSize: number;
    totalRecord: number;
    totalPages: number;
    list: TenantListObj[];
  };
}

// 查询租户下的线路组(不分页)
export interface LinegroupObj {
  tenantLineGroupId?: string;
  tenantLineGroupCode?: string;
  tenantLineGroupName?: string;
  parallelNum?: string;
  lineNum?: string;
  remark?: string;
  updateTime?: string;
  createTime?: string;
  creator?: string;
}

export interface TenantLinegroupRes extends ICommonResponse {
  data: LinegroupObj[];
}

// 租户下新增线路组和编辑线路组
interface LinegroupCreateOrUpdateParams {
  tenantCode: number;
  tenantLineGroupName: string;
  remark?: string;
  tenantLineGroupId?: string;
}

interface LinegroupCreateOrUpdateRes extends ICommonResponse {
  data: {
    tenantLineGroupId?: string;
    tenantLineGroupCode?: string;
  };
}

// 租户下删除线路组
interface LinegroupDeleteParams {
  tenantCode: number;
  tenantLineGroupId: string;
}

// 线路组关联的线路列表查询
interface LineListParams {
  tenantCode: number;
  tenantLineGroupId: string;
  pageNum: number;
  pageSize: number;
}

interface ICallThroughFrequencyList {
  frequencyCount?: number;
  timePeriod?: number;
  timeUnit?: string;
}

type ICallFrequencyList = ICallThroughFrequencyList;

interface IAreaLimitDisplay {
  province?: string;
  cities?: string[];
}

type IAttributionDisplay = IAreaLimitDisplay;

export interface ILineListObj {
  tenantLineGroupId?: string;
  tenantLineGroupAndLineId?: string;
  tenantCode?: number;
  callLineId?: string;
  supplierName?: string;
  supplierLineStatus?: string;
  supporterLineName?: string;
  callingNumber?: string;
  parallelNum?: number;
  maxParallelNum?: number;
  routeCity?: boolean;
  routeProvince?: boolean;
  routeCountry?: boolean;
  sort?: number;
  createTime?: string;
  updateTime?: string;
  isDelete?: boolean;
  callNumberTotal?: number;
  attributionDisplay?: IAttributionDisplay[];
  cityCount?: number;
  provinceCount?: number;
  areaLimit?: string;
  areaLimitDisplay?: IAreaLimitDisplay[];
  callFrequencyList?: ICallFrequencyList[];
  callThroughFrequencyList?: ICallThroughFrequencyList[];
  areaLimitCityCount?: number;
  areaLimitProvinceCount?: number;
  price?: number;
  monthlyRent?: number;
  maxUseParallelNum?: number;
  assistParallelNum?: number;
  routeType?: number;
}

interface LineListData {
  pageNum?: number;
  pageSize?: number;
  totalRecord?: number;
  totalPages?: number;
  namelistNum?: number;
  list?: ILineListObj[];
}

interface LineListRes extends ICommonResponse {
  data?: LineListData;
}

interface LinegroupUseParams {
  supplierGuid?: string;
  supporterLineName?: string;
  maxSize?: number;
  tenantCode: number;
  status: number;
  syncStatus: number;
  tenantLineGroupId: string;
}

interface LinegroupUseObj {
  lineGuid?: string;
  supporterLineName?: string;
  maxParallelNum?: number;
  callingNumber?: string;
  tenantlinegroupUse?: boolean;
  supplierGuid?: string;
  disabled?: boolean;
}

interface LinegroupUseRes extends ICommonResponse {
  data: LinegroupUseObj[];
}

// 租户下线路组关联的线路新增、编辑
interface CreateUpdateLineParams {
  tenantCode: number;
  tenantLineGroupId: string;
  callLineId: string;
  parallelNum: number;
  routeCity: boolean;
  routeProvince: boolean;
  routeArea: boolean;
  routeCountry: boolean;
  tenantLineGroupAndLineId: number;
  maxUseParallelNum: number;
  routeType: number;
}

// 更新线路组中线路的优先级
interface SortTenantLineParams {
  tenantLineGroupId: string;
  sort: number;
  tenantLineGroupAndLineId: string;
}

// 新增租户线路组配置新增/更新
interface UpdateLineSettingParams {
  tenantId: string;
  tenantLineGroupId: string;
  assist: number;
  planCallRate?: string;
}

interface VoiceBillingModelRes extends ICommonResponse {
  data?: voiceServiceBillingModelObj[];
}

// 租户线路组配置查询
interface FindLineSettingRes extends ICommonResponse {
  data: UpdateLineSettingParams & { updateLineTime?: string };
}

/* 自动生成的 Interface */

export interface IRuleList {
  firstType: number; //一级规则
  secondType: number; //二级规则
  sortValue: number; //行号
  columnSortValue: number; //列号
}

export interface ICallbackRuleInfo {
  ruleList?: IRuleList[];
  maxDialoguePush?: number;
}

interface CallbackRuleRes extends ICommonResponse {
  data: ICallbackRuleInfo;
}

interface SaveCallbackRuleReq {
  tenantCode: number;
  maxDialoguePush?: number;
  ruleList?: IRuleList[];
}

// 租户删除
export const delTenant = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.delete',
    ...params,
  });
  return res;
};

// 租户更新
export const updateTenant = async (
  params: UpdateTenantType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.update',
    ...params,
  });
  return res;
};

// 租户创建
export const createTenant = async (
  params: CreateTenantType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.create',
    ...params,
  });
  return res;
};

// 租户列表
export const tenantList = async (
  params: TenantListType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.list',
    ...params,
  });
  return res;
};

// 租户线路列表
// export const tenantLineList = async (
//   params: TenantLineListType,
// ): Promise<ICommonResponse> => {
//   const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
//     bffAction: 'css.call.tenant.line.list',
//     ...params,
//   });
//   return res;
// };

// 租户线路基础信息添加
// export const tenantLineCreate = async (
//   params: TenantLineCreateType,
// ): Promise<ICommonResponse> => {
//   const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
//     bffAction: 'css.call.tenant.line.create',
//     ...params,
//   });
//   return res;
// };

// 租户线路基础信息更改
// export const tenantLineUpdate = async (
//   params: TenantLineUpdateType,
// ): Promise<ICommonResponse> => {
//   const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
//     bffAction: 'css.call.tenant.line.updateBase',
//     ...params,
//   });
//   return res;
// };

// 租户线路删除
// export const tenantLineDel = async (params: {
//   id: string;
// }): Promise<ICommonResponse> => {
//   const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
//     bffAction: 'css.call.tenant.line.delete',
//     ...params,
//   });
//   return res;
// };

// 租户线路排序调整
// export const tenantLineSort = async (params: {
//   id: string;
//   sort: number;
//   callTimes: number;
// }): Promise<ICommonResponse> => {
//   const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
//     bffAction: 'css.call.tenant.line.sort',
//     ...params,
//   });
//   return res;
// };

// 租户线路号码列表
// export const tenantLineNumberList = async (
//   params: TenantLineNumberListParamsType,
// ): Promise<ITenantLineNumberRes> => {
//   const res = await request.post(`${API.API_HOST}`, {
//     bffAction: 'css.call.tenant.line.number',
//     ...params,
//   });
//   return res;
// };

// 租户线路号码列表2
// export const tenantLineNumberListV2 = async (
//   params: TenantLineNumberListParamsType,
// ): Promise<ITenantLineNumberRes> => {
//   const res = await request.post(`${API.API_HOST}`, {
//     bffAction: 'css.call.tenant.line.list.v2',
//     ...params,
//   });
//   return res;
// };

// 租户线路号码新增
// export const tenantLineNumberAdd = async (
//   params: ITenantNumberAddReq,
// ): Promise<ICommonResponse> => {
//   const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
//     bffAction: 'css.call.tenant.line.addNum',
//     ...params,
//   });
//   return res;
// };

// 租户线路号码删除
// export const tenantLineNumberDelete = async (params: {
//   id: string;
// }): Promise<ICommonResponse> => {
//   const res = await request.post(`${API.API_HOST}`, {
//     bffAction: 'css.tenant.line.number.delete',
//     ...params,
//   });
//   return res;
// };

// 租户线路号码更改
// export const tenantLineNumberUpdate = async (
//   params: ITenantNumberAddReq,
// ): Promise<ICommonResponse> => {
//   const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
//     bffAction: 'css.call.tenant.line.updateNum',
//     ...params,
//   });
//   return res;
// };

// 租户线路号码批量更新
// export const tenantLineNumberBatchUpdate = async (params: {
//   status: boolean;
//   routeCity?: Array<number>;
//   routeProvince?: Array<number>;
//   routeCountry?: Array<number>;
// }): Promise<ICommonResponse> => {
//   const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
//     bffAction: 'css.tenant.line.number.batchUp',
//     ...params,
//   });
//   return res;
// };

// 更新租户配置
// export const updateTenantSetting = async (params: {
//   tenantId: string;
//   callTimes: number;
//   assist?: 0 | 1; // 0 关闭，1开启
//   planCallRate?: string;
// }): Promise<ICommonResponse> => {
//   const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
//     bffAction: 'css.call.tenant.setting.update',
//     ...params,
//   });
//   return res;
// };

// 获取租户配置
// export const getTenantSetting = async (params: {
//   tenantId: string;
//   callTimes: number;
// }): Promise<ICommonResponse> => {
//   const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
//     bffAction: 'css.call.tenant.setting.find',
//     ...params,
//   });
//   return res;
// };

// 获取租户配置信息
export const getTenantConfigInfo = async (params: {
  tenantId: string;
}): Promise<ITenantConfigRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.config.find',
    ...params,
  });
  return res;
};

// 更改租户配置信息
export const updateTenantConfig = async (
  params: ITenantConfigInfo,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.config.update',
    ...params,
  });
  return res;
};

// 新租户列表（带分页）
export const tenantPageList = async (
  params: TenantListType,
): Promise<TenantListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.page.list',
    ...params,
  });
  return res;
};

// 查询租户线路组（不带分页）
export const queryTenantLinegroupPage = async (params: {
  tenantCode: number;
  bpoVersion?: number;
}): Promise<TenantLinegroupRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.linegroup.list',
    ...params,
  });
  return res;
};

// 租户下新增线路组和编辑线路组
export const linegroupCreateOrUpdate = async (
  params: LinegroupCreateOrUpdateParams,
): Promise<LinegroupCreateOrUpdateRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.linegroup.save',
    ...params,
  });
  return res;
};

// 租户下删除线路组
export const deleteTenantLineGroup = async (
  params: LinegroupDeleteParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.linegroup.del',
    ...params,
  });
  return res;
};

// 查询租户线路组下线路
export const queryTenantLineList = async (
  params: LineListParams,
): Promise<LineListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.groupline.list',
    ...params,
  });
  return res;
};

// 查询租户线路组下线路
export const findTenantlinegroupUse = async (
  params: LinegroupUseParams,
): Promise<LinegroupUseRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.linegroup.linegroupUse',
    ...params,
  });
  return res;
};

// 租户下线路组关联的线路新增、编辑
export const createUpdateLine = async (
  params: CreateUpdateLineParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.groupline.save',
    ...params,
  });
  return res;
};

// 租户下线路组关联的线路删除
export const deleteTenantLine = async (params: {
  tenantLineGroupAndLineId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.groupline.del',
    ...params,
  });
  return res;
};

// 更新线路组中线路的优先级
export const sortTenantLine = async (
  params: SortTenantLineParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.tenant.groupline.sort',
    ...params,
  });
  return res;
};

// 租户线路组配置新增/更新
export const updateLineSetting = async (
  params: UpdateLineSettingParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.group.setting.update',
    ...params,
  });
  return res;
};

// 租户线路组配置查询
export const findLineSetting = async (params: {
  tenantId: string;
  tenantLineGroupId: string;
}): Promise<FindLineSettingRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.group.setting.find',
    ...params,
  });
  return res;
};

// 租户线路查询语音业务计费模式
export const getVoiceBillingModel = async (params: {
  pageNum: number;
  pageSize: number;
}): Promise<VoiceBillingModelRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'cc.tenant.get.voiceBillingModel',
    ...params,
  });
  return res;
};

// 租户回传规则信息查询
export const getTenantCallbackRule = async (params: {
  tenantCode: number;
}): Promise<CallbackRuleRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'tenant.callback.rule.query',
    ...params,
  });
  return res;
};

// 租户回传规则信息保存
export const saveTenantCallbackRule = async (
  params: SaveCallbackRuleReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'tenant.callback.rule.save',
    ...params,
  });
  return res;
};

//租户回传规则枚举值列表
export const getCallbackRuleList = async (): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'tenant.callback.rule.list',
  });
  return res;
};

// 查询意向分类映射列表
export interface MappingListParams {
  tenantCode?: number;
}
export const mappingList = async (params:MappingListParams): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.intent.mapping.list',
    ...params,
  });
  return res;
};

// 新增意向分类映射
export interface MappingAddParams {
  tenantCode:string;
	innerList:string[];
	outerIntentClassify:string;
	outerIntentClassifyName:string;
	remark:string;
}
export const mappingAdd = async (params:MappingListParams): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.intent.mapping.add',
    ...params,
  });
  return res;
};
//  编辑意向分类映射
export interface MappingEditParams {
  id:string;
	innerList:string[];
	outerIntentClassify:string;
	outerIntentClassifyName:string;
	remark:string;
}
export const mappingEdit = async (params:MappingEditParams): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.intent.mapping.edit',
    ...params,
  });
  return res;
};
//  删除意向分类映射  /css.intent.mapping.delete
export interface MappingDeleteParams {
  id:string;
}

export const mappingDelete = async (params:MappingDeleteParams): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.intent.mapping.delete',
    ...params,
  });
  return res;
};