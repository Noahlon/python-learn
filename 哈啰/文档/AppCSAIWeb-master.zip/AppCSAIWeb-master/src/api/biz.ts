import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface IAudioListReq {
  pageSize: number;
  pageNum: number;
  corpusName?: string;
}

export interface IBizInfo {
  id: string;
  name: string;
  bizType: number;
  isLeaf?: boolean;
  loading?: boolean;
  children?: IBizInfo[];
}

export interface IBizListRes extends ICommonResponse {
  data: IBizInfo[];
}

// 行业列表
export const getBizTreeList = async (params: {
  includeScene?: boolean;
}): Promise<IBizListRes> => {
  const res = await request.post<IBizListRes, IBizListRes>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.bizTree.list',
  });
  return res;
};

// 获取行业场景(单条)
export const getBizScene = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.bizScene.get',
  });
  return res;
};

// 删除行业场景
export const delBizScene = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.bizScene.delete',
  });
  return res;
};

// 修改行业场景
export const updateBizScene = async (params: {
  id: string;
  sceneName: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.bizScene.update',
  });
  return res;
};

// 新增行业场景
export const createBizScene = async (params: {
  bizId: string;
  sceneName: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.bizScene.create',
  });
  return res;
};

// 获取行业
export const getField = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.biz.get',
  });
  return res;
};

// 删除行业
export const delField = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.biz.delete',
  });
  return res;
};

// 修改行业
export const updateField = async (params: {
  id: string;
  bizName: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.biz.update',
  });
  return res;
};

// 新增行业
export const addField = async (params: {
  bizName: string | null;
  parentId?: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.biz.create',
  });
  return res;
};
