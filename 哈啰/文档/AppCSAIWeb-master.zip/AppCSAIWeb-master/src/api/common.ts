import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

interface IEnumListParams {
  typeList: string[] | number[];
}

interface IEnumData {
  code: number;
  value: string;
}

export interface IEnumRes {
  type: number | string;
  enumConstantDTOList: IEnumData[];
}

export interface IEnumListRes extends ICommonResponse {
  data: IEnumRes[];
}

// 根据类型列表获取枚举列表
export const getEnumListByType = async (
  params: IEnumListParams,
): Promise<IEnumListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'cc.common.getEnumListByTypeList',
  });
  return res;
};
/**
 * 获取省市区地址Ts类型
 */
export interface CITYLIST {
  area_code: number | string;
  area_name: number | string;
  parent_code: number | string;
  level: number | string;
}
export interface ProvinceCityList extends ICommonResponse {
  data?: CITYLIST[];
}
/**
 * 获取省市区地址
 */

export const getProvinceCityList = async (): Promise<ProvinceCityList> => {
  const res = await request.post(
    `${API.API_HOST}?cc.common.getProvinceCityList`,
    {
      bffAction: 'cc.common.getProvinceCityList',
    },
  );
  if (res?.data) {
    return res.data;
  }
  return [];
};

// interface OssTokenType {
//   accessKeyId: string;
//   accessKeySecret: string;
//   securityToken: string;
//   region: string;
//   bucket: string;
//   baseDir: string;
// }

// oss.token.get

export const getOSSToken = async (): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'distribute.oss.sts.token',
  });
  return res;
};

export const authorize = async (params: {
  ossUrl: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'distribute.oss.authorize',
  });
  return res;
};
