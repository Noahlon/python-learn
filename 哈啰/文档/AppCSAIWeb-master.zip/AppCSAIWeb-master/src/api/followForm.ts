import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

// 分页查询表单列表
export interface formDetailListPageReq {
  pageSize: number;
  pageNum: number;
}
export interface formListPageRes extends ICommonResponse {
  data: formListPageResData;
}

export interface formListPageResData {
  totalRecord?: number;
  pageNum?: number;
  pageSize?: number;
  totalPages?: number;
  list?: formList[];
}
export interface formList {
  formGuid?: string;
  formName?: string;
  status?: number;
  projectCount?: number;
  fieldCount?: number;
}

export const formListPage = async (
  params: formDetailListPageReq,
): Promise<formListPageRes> => {
  const res = await request.post(`${API.API_HOST}?seat.form.listPage`, {
    ...params,
    bffAction: 'seat.form.listPage',
  });
  return res;
};

// 编辑新增任务跟进表单
export interface formEditReq {
  formGuid?: string;
  formName?: string;
  status?: string;
  fieldList?: IFieldList[];
}

export interface IFieldList {
  fieldType?: string;
  fieldName?: string;
  status?: string;
  fieldOptionList?: string[];
  fieldGuid?: string;
}
export const followFormModify = async (
  params: formEditReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?seat.form.modify`, {
    ...params,
    bffAction: 'seat.form.modify',
  });
  return res;
};

// 删除任务跟进表单
export const followFormDelete = async (params: {
  formGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?seat.form.delete`, {
    ...params,
    bffAction: 'seat.form.delete',
  });
  return res;
};

// 查询表单详情
export interface formDetailsReq {
  formGuid: string;
}

export interface formDetailsRes extends ICommonResponse {
  data: formDetailData;
}

export interface projectsData {
  projectGuid?: string;
  projectName?: string;
}

interface formDetailData {
  formGuid?: string;
  formName?: string;
  status?: string;
  projects?: projectsData[];
  fieldList?: formDetailProjects[];
}
export interface formDetailProjects {
  fieldType?: string;
  fieldTypeDesc?: string;
  fieldGuid?: string;
  fieldName?: string;
  status?: string;
  fieldOptionList?: string[];
}

export const followFormDetails = async (
  params: formDetailsReq,
): Promise<formDetailsRes> => {
  const res = await request.post(`${API.API_HOST}?seat.form.queryDetail`, {
    ...params,
    bffAction: 'seat.form.queryDetail',
  });
  return res;
};
// 预览表单 seat.form.preview
export interface followFormPreviewRes extends ICommonResponse {
  data: {
    formGuid?: string;
    fieldList?: string[];
  };
}
export const followFormPreview = async (params: {
  formGuid: string;
  bpoVersion?: number;
}): Promise<followFormPreviewRes> => {
  const res = await request.post(`${API.API_HOST}?seat.form.preview`, {
    ...params,
    bffAction: 'seat.form.preview',
  });
  return res;
};

export interface followNodeListPageRes {
  data?: followNodeListData;
}

export interface followNodeListData {
  totalRecord?: number;
  pageNum?: number;
  pageSize?: number;
  totalPages?: number;
  list?: followNodeList[];
}

export interface followNodeList {
  followNodeSetGuid?: string;
  followNodeSetName?: string;
  projectCount?: string;
  nodeCount?: string;
}

export const followNodeListPage = async (params: {
  pageSize: number;
  pageNum: number;
}): Promise<followNodeListPageRes> => {
  const res = await request.post(`${API.API_HOST}?seat.followNode.listPage`, {
    ...params,
    bffAction: 'seat.followNode.listPage',
  });
  return res;
};

// 查询节点集详情
export interface followNodeSetGuidRes {
  code?: number;
  data?: followNodeSetGuidData;
}

export interface nodeListData {
  nodeName?: string;
  nodeGuid?: string;
  sort?: string;
}

interface followNodeSetGuidData {
  followNodeSetGuid?: string;
  followNodeSetName?: string;
  projects?: projectsData[];
  nodeList?: nodeListData[];
}
export const followQueryDetailNodeSetGuid = async (params: {
  followNodeSetGuid: string;
}): Promise<followNodeSetGuidRes> => {
  const res = await request.post(
    `${API.API_HOST}?seat.followNode.queryDetail`,
    {
      ...params,
      bffAction: 'seat.followNode.queryDetail',
    },
  );
  return res;
};

// 新增编辑节点集
export interface followNodeAddNodeSetReq {
  formGuid?: string;
  formName?: string;
  status?: string;
  nodeList?: string[];
}

export const followNodeAddNodeSet = async (
  params: followNodeAddNodeSetReq,
): Promise<ICommonResponse> => {
  const res = await request.post(
    `${API.API_HOST}?seat.followNode.editNodeSet`,
    {
      ...params,
      bffAction: 'seat.followNode.editNodeSet',
    },
  );
  return res;
};

// 删除节点集
export const followNodeDeleteNodeSet = async (params: {
  followNodeSetGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(
    `${API.API_HOST}?seat.followNode.deleteNodeSet`,
    {
      ...params,
      bffAction: 'seat.followNode.deleteNodeSet',
    },
  );
  return res;
};
// 帮助中心
export const helpcenterDetail = async (): Promise<ICommonResponse> => {
  const res = await request.post(
    `${API.API_HOST}?seat.helpcenter.queryDetail`,
    {
      bffAction: 'seat.helpcenter.queryDetail',
    },
  );
  return res;
};
// 帮助中心新增
export const helpcenterModify = async (params: {
  content: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?seat.helpcenter.modify`, {
    ...params,
    bffAction: 'seat.helpcenter.modify',
  });
  return res;
};
// 查询转接配置
export const transferConfigDetail = async (): Promise<ICommonResponse> => {
  const res = await request.post(
    `${API.API_HOST}?transferConfiguration.query`,
    {
      bffAction: 'transferConfiguration.query',
    },
  );
  return res;
};
// 编辑转接配置
export interface ModifyParams {
  waitTime: number;
  audio: string;
  guid?: string;
}
export const transferConfigModify = async (
  params: ModifyParams,
): Promise<ICommonResponse> => {
  const res = await request.post(
    `${API.API_HOST}?transferConfiguration.modify`,
    {
      ...params,
      bffAction: 'transferConfiguration.modify',
    },
  );
  return res;
};
