import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse, ICommonResponseList } from '../baseInterface';
// (批次列表查询)
export interface RosterBatchPageParams {
  batchName?: number;
  pageSize: number;
  pageNum: number;
}
export interface RosterBatchPageObj {
  batchName?: string;
  batchGuid?: string;
  nameListCount?: number;
  newlyAddCount?: number;
  repeatCount?: number;
  failCount?: number;
  createdBy?: string;
  createdByName?: string;
  createTime?: string;
  failOssUrl?: string;
  operation?: number;
}
type RosterBatchPageRes = ICommonResponseList<RosterBatchPageObj>;
export const rosterBatchPage = async (
  params: RosterBatchPageParams,
): Promise<RosterBatchPageRes> => {
  const res = await request.post(`${API.API_HOST}?roster.batch.page`, {
    bffAction: 'roster.batch.page',
    ...params,
  });
  return res;
};
//(批量添加名单)
export interface RosterBatchImportAddParams {
  projectGuid: number;
  file: string;
  fileName: string;
  uploadType: string;
}
export const rosterBatchImportAdd = async (
  params,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?roster.batch.importAdd`, {
    bffAction: 'roster.batch.importAdd',
    ...params,
  });
  return res;
};

//名单导入下载模版接口
export interface RosterDownloadTemplateParams {
  projectGuid: number;
  uploadType: string;
  fileType: string | number;
}
export const rosterDownloadTemplate = async (
  params: RosterDownloadTemplateParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}?roster.downloadTemplate`, {
    bffAction: 'roster.downloadTemplate',
    ...params,
  });
  return res;
};
