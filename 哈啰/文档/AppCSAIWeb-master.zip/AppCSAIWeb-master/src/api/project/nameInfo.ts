import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse, ICommonResponseList } from '../baseInterface';

/**
 * 名单列表tab栏数据统计interface
 */
export interface NameStatisticsObj {
  nameListCount?: number;
  toBeIssuedCount?: number;
  toBeAllocatedCount?: number;
  allocatedCount?: number;
  collectedCount?: number;
  followingCount?: number;
  followSuccessCount?: number;
  followFailCount?: number;
}

interface NameStatisticsRes extends ICommonResponse {
  data: NameStatisticsObj;
}

// 所有筛选条件interface
export interface FilterCriteria {
  projectGuid: string;
  operationRosterBox?: boolean;
  phoneNum?: string;
  phoneNumMd5?: string;
  uploadNewid?: string;
  uploadGuid?: string;
  citys?: string[];
  carrier?: string;
  wanderStatus?: number;
  followStatuList?: number[];
  followupNodeName?: string;
  taskType?: number;
  taskName?: string;
  taskStatuList?: number[];
  executeCountStart?: number;
  executeCountEnd?: number;
  executeStatuList?: number[];
  calloutResultList?: number[];
  skillGroupGuid?: string;
  seatsGuidOrName?: string;
  followRemark?: string;
  startCalloutCount?: number;
  endCalloutCount?: number;
  startThroughCount?: number;
  endThroughCount?: number;
  startSeatCalloutCount?: number;
  endSeatCalloutCount?: number;
  startSeatThroughCount?: number;
  endSeatThroughCount?: number;
  intentClassifyList?: string[];
  intentionLabelList?: string[];
  startCalloutTime?: string;
  endCalloutTime?: string;
  startThroughTime?: string;
  endThroughTime?: string;
  startNextFollowTime?: string;
  endNextFollowTime?: string;
  startCollectedTime?: string;
  endCollectedTime?: string;
  startAssignedTime?: string;
  endAssignedTime?: string;
  startDistributeTime?: string;
  endDistributeTime?: string;
  startAddTime?: string;
  endAddTime?: string;
}

/**
 * 名单列表interface
 */
export type RosterListParams = FilterCriteria & {
  pageSize: number;
  pageNum: number;
};

export interface RosterListObj {
  guid?: string;
  phoneNum?: string;
  phoneNumMd5?: string;
  uploadNewid?: string;
  uploadGuid?: string;
  customerName?: string;
  companyName?: string;
  projectName?: string;
  projectGuid?: string;
  province?: string;
  city?: string;
  carrierType?: number;
  carrierDesc?: string;
  wanderStatus?: number;
  wanderStatusDesc?: string;
  followStatus?: number;
  followStatusDesc?: string;
  followNodeSetName?: string;
  followNodeSetGuid?: string;
  taskType?: number;
  taskTypeDesc?: string;
  taskName?: string;
  taskStatus?: number;
  taskStatusDesc?: string;
  executeStatus?: number;
  executeStatusDesc?: string;
  skillGroupName?: string;
  skillGroupGuid?: string;
  seatsName?: string;
  seatsGuid?: string;
  followRemark?: string;
  calloutCount?: number;
  throughCount?: number;
  seatCalloutCount?: number;
  seatThroughCount?: number;
  intentClassify?: string;
  intentionLabel?: string;
  calloutTime?: string;
  throughTime?: string;
  nextFollowTime?: string;
  collectedTime?: string;
  assignedTime?: string;
  distributeTime?: string;
  addTime?: string;
  batchGuid?: string;
}

type RosterListRes = ICommonResponseList<RosterListObj>;

/**
 * 获取待操作的名单数量interface
 */
export interface RosterWanderRes extends ICommonResponse {
  data: {
    waitRosterWithOutTaskCount: number;
    waitRosterCount: number;
  };
}

/**
 * 回收/激活interface
 */
type RosterActionParams = FilterCriteria & {
  waitRosterCount: number;
};

/**
 * 下发名单interface
 */
interface ISkillGroupList {
  skillGroupGuid?: string;
  skillGroupName?: string;
  skillGroupLeader?: string;
  skillGroupWorkerNum?: number;
  rosterCount?: number;
}

export interface IUpdateTaskInfo {
  exeTime?: string;
  tenant?: string;
  name?: string;
  exeStartTime?: string;
  exeEndTime?: string;
  autoRetry?: string;
  autoStartup?: number;
  sourceType?: number;
  ext?: string;
  operator?: string;
  createBy?: string;
  templateGuid?: number;
  templateName?: string;
  faqGuid?: string;
  groupId?: string;
  faqName?: string;
  bizScene?: string;
  expectLoadCount?: number;
  taskType?: number;
  transfer?: number;
  tenantLineGroupId?: string;
  thirdBlacklistIntercept?: number;
  featureIntercept?: number;
  multipleSmsLink?: number;
  skillGroupList?: ISkillGroupList[];
}

export type RosterDistributeParams = FilterCriteria & {
  waitRosterWithOutTaskCount?: number;
  projectGuid: string;
  skillGroupList?: ISkillGroupList[];
  updateTaskInfo: IUpdateTaskInfo;
};

/**
 * 名单详情interface
 */
interface IRosterImportRecordDTOList {
  batchName?: string;
  batchGuid?: string;
  createdBy?: string;
  createdByName?: string;
  createTime?: string;
}

interface IRosterWanderInfoList {
  guid?: string;
  createTime?: string;
  rosterGuid?: string;
  operation?: string;
  operationType?: number;
  createdBy?: string;
  createdByName?: string;
}

interface IRosterInfoDTO {
  guid?: string;
  phoneNum?: string;
  phoneNumMd5?: string;
  uploadNewid?: string;
  uploadGuid?: string;
  customerName?: string;
  companyName?: string;
  projectName?: string;
  projectGuid?: string;
  province?: string;
  city?: string;
  carrierType?: number;
  carrierDesc?: string;
  wanderStatus?: number;
  wanderStatusDesc?: string;
  followStatus?: number;
  followStatusDesc?: string;
  followNodeSetName?: string;
  followNodeSetGuid?: string;
  taskType?: number;
  taskTypeDesc?: string;
  taskName?: string;
  taskStatus?: number;
  taskStatusDesc?: string;
  executeStatus?: number;
  executeStatusDesc?: string;
  skillGroupName?: string;
  skillGroupGuid?: string;
  seatsName?: string;
  seatsGuid?: string;
  followRemark?: string;
  calloutCount?: number;
  throughCount?: number;
  seatCalloutCount?: number;
  seatThroughCount?: number;
  intentClassify?: string;
  intentionLabel?: string;
  calloutTime?: string;
  throughTime?: string;
  nextFollowTime?: string;
  collectedTime?: string;
  assignedTime?: string;
  distributeTime?: string;
  addTime?: string;
  batchGuid?: string;
  followResult?: string;
}

export interface RosterDetail {
  rosterInfoDTO?: IRosterInfoDTO;
  rosterWanderInfoList?: IRosterWanderInfoList[];
  rosterImportRecordDTOList?: IRosterImportRecordDTOList[];
}
export interface RosterDetailRes extends ICommonResponse {
  data: RosterDetail;
}

/**
 * 名单下发查询任务列表interface
 */
interface IManualDeliveryTaskList {
  projectGuid?: string;
  projectName?: string;
  taskGuid?: string;
  guid?: string;
  status?: number;
  statusDesc?: string;
  telephoneCount?: number;
  totalUnCall?: number;
  name?: string;
  exeTime?: string;
  taskType?: number;
  taskTypeDesc?: string;
  tenant?: number;
  skillGroupList?: ISkillGroupList[];
  templateGuid?: string;
  templateName?: string;
  faqGuid?: string;
  faqName?: string;
  tenantLineGroupId?: string;
  tenantLineGroupCode?: string;
  tenantLineGroupName?: string;
  multipleSmsLink?: number;
  exeStartTime?: string;
  exeEndTime?: string;
  ext?: string;
  expectLoadCount?: number;
  featureIntercept?: number;
  thirdBlacklistIntercept?: number;
  totalCallRate?: string;
  completableRate?: string;
  transferRate?: string;
  loadCount?: number;
  createdByName?: string;
  createTime?: string;
}

interface TaskListObj {
  taskType?: number;
  taskTypeName?: number;
  manualDeliveryTaskList?: IManualDeliveryTaskList[];
}
export interface TaskListRes extends ICommonResponse {
  data: TaskListObj[];
}

/**
 * 名单所有枚举interface
 */
export interface HumanEnumRes extends ICommonResponse {
  data: {
    enumDesc: string;
    enumStr: string;
    valueLableDTOList: { label: string; value: number }[];
  }[];
}

/**
 * 根据名单查询跟进记录interface
 */
interface FollowRecordParams {
  rosterGuid: string;
  projectGuid: string;
  recordType?: number;
}

export interface FollowRecordRes extends ICommonResponse {
  data: {
    taskType: number;
    taskTypeDesc: string;
    taskName: string;
    callResult: number;
    callResultDesc: string;
    callTime: string;
    followupResult?: number;
    followupResultDesc?: string;
    callDuration?: number;
    callRecordingUrl?: string;
    intentClassifyType?: string;
    intentClassifyTypeDesc?: string;
    followupNodeGuid?: string;
    followupNodeName?: string;
    nextFollowTime?: string;
    remark?: string;
    seatName?: string;
    messageRecord?: {
      signature: string;
      templateContentDetails: {
        type: number;
        contentText: string;
        variableInfo: {
          variableCode: string;
          variableName: string;
          variableType: number;
        };
      }[];
    };
    formFields?: {
      fieldType: string;
      fieldName: string;
      fieldValue?: string;
      fieldValues?: string[];
      options?: {
        label: string;
        value: string;
      }[];
    }[];
  }[];
}

// -------------------------------------------------

// 名单列表tab栏数据统计
export const queryNameNStatistics = async (params: {
  projectGuid: string;
}): Promise<NameStatisticsRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.personList.statistics',
    ...params,
  });
  return res;
};

// 名单列表
export const queryRosterList = async (
  params: RosterListParams,
): Promise<RosterListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'roster.info.page',
    ...params,
  });
  return res;
};

// 获取待操作的名单数量
export const queryRosterWander = async (
  params: FilterCriteria,
): Promise<RosterWanderRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'roster.wander',
    ...params,
  });
  return res;
};

// 激活名单
export const activeRoster = async (
  params: RosterActionParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'roster.active',
    ...params,
  });
  return res;
};

// 回收名单
export const recoveryRoster = async (
  params: RosterActionParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'roster.recovery',
    ...params,
  });
  return res;
};

// 下发名单
export const distributeRoster = async (
  params: RosterDistributeParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'roster.distribute',
    ...params,
  });
  return res;
};

// 名单详情
export const getRosterDetail = async (params: {
  rosterGuid: string;
  projectGuid: string;
}): Promise<RosterDetailRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'roster.info.detail',
    ...params,
  });
  return res;
};

// 名单下发查询任务列表
export const getRosterTaskList = async (params: {
  projectGuid: string;
}): Promise<TaskListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'ha.task.list.roster',
    ...params,
  });
  return res;
};

// 名单下发所有枚举接口
export const getRosterEnumList = async (): Promise<HumanEnumRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'human.common.enum.list',
  });
  return res;
};

// 根据名单查询跟进记录
export const getFollowRecord = async (
  params: FollowRecordParams,
): Promise<FollowRecordRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'seat.followup.record.list',
    ...params,
  });
  return res;
};
