import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface AddblackGroupType {
  groupName: string;
  sceneIds?: string[];
  groupDesc: string;
  tenantList?: number[];
  excludeTenantList?: number[];
}
export interface EditBlackGroupType {
  id: string;
  groupName: string;
  sceneIds?: string[];
  groupDesc: string;
  tenantList?: number[];
  excludeTenantList?: number[];
}

export interface UploadBlackType {
  groupId: string;
  aliOssUrl: string;
  fileName: string;
}

export interface IBlackRuleRes extends ICommonResponse {
  data: {
    pageNum: number;
    pageSize: number;
    totalRecord: number;
    totalPages: number;
    list: IBlackRule[];
  };
}

export interface IBlackRule {
  id?: string;
  dayLimit: number;
  bizSceneIds?: string[];
  sceneNames?: string[];
  speechGuids?: string[];
  groupId: string;
  ruleName: string;
  ruleSettings?: {
    count: string;
    rules: {
      guid?: string;
      name: string;
    }[];
    type: number;
  }[];
  startDurationCall?: number;
  endDurationCall?: number;
  startUserSpeakCount?: number;
  endUserSpeakCount?: number;
  startSpeechCount?: number;
  endSpeechCount?: number;
  intentClassify?: string;
  speeches?: { speechGuid: string; name: string }[];
}

export interface IBlackInfo {
  author?: string;
  authorId?: string;
  createTime?: string;
  groupId?: string;
  id?: string;
  listNumber?: number;
  recordName: string;
  recordStatus?: number;
  sceneIds?: string[];
  validListNumber?: number;
}

export interface IBlackListRes {
  pageNum?: number;
  pageSize?: number;
  totalRecord?: number;
  totalPages?: number;
  list?: IBlackInfo[];
}

export interface IAddQuicklyParams {
  groupId: string;
  instructions: string;
  expireTime: string;
  mobileList: string[];
}

// 查找黑名单组
export const getBlackCard = async (): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.findGroups',
  });
  return res;
};

// 查找黑名单组
export const findCard = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.findGroup',
    ...params,
  });
  return res;
};

// 新增黑名单组 下拉
export const getDropList = async (params: {
  includeScene: boolean;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.bizTree.list',
    ...params,
  });
  return res;
};

// 新增黑名单组
export const addBlackGroup = async (
  params: AddblackGroupType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.addGroup',
    ...params,
  });
  return res;
};

// 删除黑名单组
export const delBlackGroup = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.delGroup',
    ...params,
  });
  return res;
};

// 修改黑名单组
export const editBlackGroup = async (
  params: EditBlackGroupType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.updateGroup',
    ...params,
  });
  return res;
};

// 黑名单上传
export const uploadBlack = async (
  params: UploadBlackType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.upload',
    ...params,
  });
  return res;
};

// 黑名单记录查询
export const blackListLog = async (params: {
  groupId: string;
  pageSize: number;
  pageNum: number;
}): Promise<IBlackListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.findRecordPage',
    ...params,
  });
  return res?.data;
};

// 黑名单记录删除
export const delDlackListLog = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.delRecord',
    ...params,
  });
  return res;
};

// 黑名单记录导出
export const exportBlackListLog = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.export',
    ...params,
  });
  return res;
};

// 黑名单账号查询
export const findBlackList = async (params: {
  mobile: string;
  groupId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.findBlackList',
    ...params,
  });
  return res;
};

// 黑名单规则列表
export const getBlackRuleList = async (params: {
  pageNum: number;
  pageSize: number;
  groupId: string;
}): Promise<IBlackRuleRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.findRules',
    ...params,
  });
  return res;
};

// 新增黑名单规则
export const addBlackRule = async (
  params: IBlackRule,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.addRule',
    ...params,
  });
  return res;
};

// 快捷新增黑名单规则
export const addBlackQuickly = async (
  params: IAddQuicklyParams,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.quicklyAdd',
    ...params,
  });
  return res;
};

// 编辑黑名单规则
export const editBlackRule = async (
  params: IBlackRule,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.updateRule',
    ...params,
  });
  return res;
};

// 删除黑名单规则
export const deleteBlackRule = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.cc.blacklist.delRule',
    ...params,
  });
  return res;
};
