import request from '@/utils/request';
import API from '@/config/env';
import { IResponse, IBooleanRes, ICommonResponse } from './baseInterface';

export interface LANGUAGEs {
  speechId: string;
  guid: string;
  id: string;
  tenant: number;
  bizScene: string;
  kbGuid: string;
  author: string;
  speechName: string;
  updateTime: string;
  businessType: number;
  desc: string;
  faqId: string;
}

export interface IinitiateRes {
  code?: string | number;
  data?: any;
  msg?: string;
}

export interface IDialogueReq {
  tenant: number;
  userPhone: string;
  bizScene: string;
  speechId: string;
  speechGroupId?: string;
  isDraft: boolean;
  ccServer: string;
}

export interface Intention {
  classification: string;
  desc: string;
}

export interface IntentionLabel {
  code: string;
  desc: string;
}

interface LANGUAGEsRes extends IResponse {
  data: {
    list: LANGUAGEs[];
  };
}

interface ExportFile extends IResponse {
  data: { aliOssUrl?: string };
}

export interface IPhrase {
  guid: string;
  id: string;
  faqId: string;
  phrase: string;
  segments: string[];
  createTime: string;
  updateTime: string;
  isDelete: boolean;
}

interface IPhraseRes extends IResponse {
  data: IPhrase[];
}

export interface IBreak {
  type: number;
  desc: string;
}

interface IBreakRes extends IResponse {
  data: IBreak[];
}

export const getList = async (
  data: any,
): Promise<{
  list: LANGUAGEs[];
}> => {
  const res = await request.post<LANGUAGEsRes, LANGUAGEsRes>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.speech.listSpeech',
      ...data,
    },
  );
  return res?.data;
};

/**
 * 获取全部租户
 */

export const getSimpleList = async (
  data: any,
): Promise<{
  list: LANGUAGEs[];
}> => {
  const res = await request.post<LANGUAGEsRes, LANGUAGEsRes>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.speech.simple.list',
      ...data,
    },
  );
  return res?.data;
};

export const insertOrderClassify = async (data: any): Promise<LANGUAGEs[]> => {
  const res = await request.post<any>(
    `${API.API_KB_HOST}/orderClassify/insertOrderClassify`,
    data,
  );
  return res.data;
};

export const addKB = async (param: any): Promise<IBooleanRes> => {
  const res = await request.post<IBooleanRes, IBooleanRes>(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.create',
    ...param,
  });
  return res;
};

export const editKB = async (param: any): Promise<IBooleanRes> => {
  const res = await request.post<IBooleanRes, IBooleanRes>(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.editSpeech',
    ...param,
  });
  return res;
};

export const deleteKB = async (param: any): Promise<IBooleanRes> => {
  const res = await request.post<IBooleanRes, IBooleanRes>(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.delete',
    ...param,
  });
  return res;
};

// 知识维护接口

export const getKnowledgeList = async (data: any): Promise<any[]> => {
  const res = await request.post<LANGUAGEsRes, LANGUAGEsRes>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.knowledge.list',
      ...data,
    },
  );
  return res?.data || {};
};

export const uploadMusic = async (file: unknown): Promise<string> => {
  const res = await request.post(`${API.UPLOAD_API}`, file, {
    headers: { 'Content-Type': 'multipart/form-data;' },
  });
  return res?.data;
};

// 语料分发
export const uploadCorpus = async (data: any): Promise<any[]> => {
  const res = await request.post<LANGUAGEsRes, LANGUAGEsRes>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.corpus.upload',
      ...data,
    },
  );
  return res?.data || [];
};

// 语料合成

export const transferCorpus = async (data: any): Promise<any[]> => {
  const res = await request.post<LANGUAGEsRes, LANGUAGEsRes>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.corpus.transfer',
      ...data,
    },
  );
  return res?.data;
};

// 创建知识

export const createKnowledge = async (data: any): Promise<any[]> => {
  const res = await request.post<LANGUAGEsRes, LANGUAGEsRes>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.knowledge.create',
      ...data,
    },
  );
  return res as any;
};

// 编辑知识

export const editKnowledge = async (data: any): Promise<any[]> => {
  const res = await request.post<LANGUAGEsRes, LANGUAGEsRes>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.knowledge.edit',
      ...data,
    },
  );
  return res as any;
};

// 根据id 获取知识
export const getKnowledgeById = async (faqId: string): Promise<any> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.knowledge.get',
    faqId,
  });
  return res as any;
};

// 删除
export const deleteK = async (params: any): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.knowledge.delete',
    ...params,
  });
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return res as any;
};

// 业务线
export const tenantList = async (data: any): Promise<LANGUAGEs[]> => {
  const res = await request.post<LANGUAGEsRes, LANGUAGEsRes>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.tenant.list',
      ...data,
    },
  );
  return res?.data || [];
};

// 知识集合列表
export const kcList = async (data: any): Promise<LANGUAGEs[]> => {
  const res = await request.post<LANGUAGEsRes, LANGUAGEsRes>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.kc.list',
      ...data,
    },
  );
  return res?.data || {};
};

// 创建知识集合
export const createKc = async (data: any): Promise<LANGUAGEs[]> => {
  const res = await request.post<LANGUAGEsRes, LANGUAGEsRes>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.kc.create',
      ...data,
    },
  );
  return res;
};

// 编辑知识集合
export const editKc = async (data: any): Promise<LANGUAGEs[]> => {
  const res = await request.post<LANGUAGEsRes, LANGUAGEsRes>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.edit',
      ...data,
    },
  );
  return res;
};
// 删除知识集合

export const deleteKc = async (data: any): Promise<LANGUAGEs[]> => {
  const res = await request.post<LANGUAGEsRes, LANGUAGEsRes>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.kc.delete',
      ...data,
    },
  );
  return res;
};

// 语音测试
export const dialogueTest = async (
  params: IDialogueReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.dialogue.initiate.version',
    ...params,
  });
  return res;
};

// 查询意向列表
export const getIntentionList = async (params: {
  pageNum: number;
  pageSize: number;
  speechGuid?: string;
  speechGroupIdList?: string[];
  orderByName: boolean;
  bpoVersion?: number;
}): Promise<Intention[]> => {
  const res = await request.post<Intention[]>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.classification.list',
      ...params,
    },
    {
      noValidate: true,
    },
  );
  return res.data || [];
};

// 查询所有意向列表
export const getIntentionListAll = async (params: {
  pageNum: number;
  pageSize: number;
  bpoVersion?: number;
}): Promise<Intention[]> => {
  const res = await request.post<Intention[]>(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.intention.classifys',
      ...params,
    },
    {
      noValidate: true,
    },
  );
  return res.data || [];
};

// 查询列表
export const getIntentionLabelList = async (params: {
  pageNum: number;
  pageSize: number;
  speechGuid: string;
}): Promise<{ labelName: string; code: string }[]> => {
  const res = await request.post(
    `${API.API_HOST}`,
    {
      bffAction: 'css.call.label.list',
      ...params,
    },
    {
      noValidate: true,
    },
  );
  return res.data || [];
};

// 下载模版
export const uploadTaskTemplate = async (): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'task.exportTaskTemplate',
  });
  return res as any;
};

// 导出话术
export const exportSpeech = async (params: {
  guid: string;
}): Promise<ExportFile> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.knowledge.export',
  });
  return res;
};

// 上传文件
export const uploadFile = async (file: unknown): Promise<string> => {
  const res = await request.post(`${API.UPLOAD_API}`, file, {
    headers: { 'Content-Type': 'multipart/form-data;' },
  });
  return res?.data;
};

// 导入话术
export const importSpeech = async (params: {
  aliOssUrl: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.knowledge.import',
  });
  return res;
};

// 导入知识集合
export const importKc = async (params: {
  aliOssUrl: string;
}): Promise<IResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.kc.import',
  });
  return res;
};

// 导出知识集合
export const exportkc = async (params: {
  guid: string;
}): Promise<ExportFile> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.kc.export',
  });
  return res;
};

// 查询打断列表
export const queryBreakList = async (): Promise<IBreakRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.corpus.break.type.list',
    pageNum: 1,
    pageSize: 200,
  });
  return res;
};

// 查询短语
export const queryPhrase = async (params: {
  faqId: string;
}): Promise<IPhraseRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.knowledge.queryPhrase',
    ...params,
  });
  return res;
};

// 新增短语
export const addPhrase = async (params: {
  phrase: string;
  faqId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.knowledge.insertPhrase',
    ...params,
  });
  return res;
};

// 删除短语
export const deletePhrase = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.knowledge.deletePhrase',
    ...params,
  });
  return res;
};

// 获取算法意图
export const getSimpleQuery = async (params: {
  name?: string;
  faqIds?: string[];
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.knowledge.simpleQuery',
    ...params,
  });
  return res;
};
