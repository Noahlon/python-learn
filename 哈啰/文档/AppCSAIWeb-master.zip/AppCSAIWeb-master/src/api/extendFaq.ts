import request from '@/utils/request';
import API from '@/config/env';
import { IResponse } from './baseInterface';

export const getExtendFaqList = async (params: {
  standardFaqGuid: string;
  modelGuid?: string;
}): Promise<IExtendFaq[]> => {
  const res = await request.post<IExtendFaqRet>(
    `${API.API_HOST}`,
    // 'https://yapi.hellobike.cn/mock/5251/180026',
    {
      bffAction: 'css.call.knowledge.query',
      ...params,
    },
  );
  return res.data as any;
};

// 创建任务模版
export const createExtendFaq = async (params: {
  standardFaqGuid: string;
  extendFaqName: string;
  ignoreSimilarCheck: boolean;
}): Promise<ICreateExtendFaqRet> => {
  const res = await request.post<ICreateExtendFaqRet>(`${API.API_HOST}`, {
    bffAction: 'css.call.knowledge.insert',
    ...params,
  });
  return res as any;
};

export const deleteExtendFaq = async (params: {
  extendFaqGuid: string;
}): Promise<IResponse> => {
  const res = await request.post<IResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.knowledge.deleteFaq',
    ...params,
  });
  return res;
};

export interface IExtendFaq {
  guid: string;
  faqGuid: string;
  extendFaqName: string;
}

export interface IExtendFaqRet extends IResponse {
  data: IExtendFaq;
}

export interface ICreateExtendFaqRet extends IResponse {
  data?: {
    checkSimilarSuccess: boolean;
    similarExtendFaqResDTOList?: similarExtendFaqResDTO[];
  };
}

export interface similarExtendFaqResDTO {
  faqName: string;
  extendFaqName: string;
  similarRate: number;
}
