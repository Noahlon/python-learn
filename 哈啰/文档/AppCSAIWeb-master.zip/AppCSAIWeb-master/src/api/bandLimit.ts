import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface IAudioListReq {
  pageSize: number;
  pageNum: number;
  corpusName?: string;
}

export interface IRule {
  frequencyCount: number;
  timePeriod: number;
  timeUnit: string;
  type: number;
}

export interface taskFilterEnum {
  taskName: string;
  taskRangeCode: string;
}

export interface faqFilterEnum {
  faqName: string;
  faqRangeCode: string;
}

export interface IRuleInfo {
  id: string;
  name: string;
  showScene: number;
  bizId?: string;
  bizSceneId?: string;
  updateTime?: string;
  updateUser: string;
  remark?: string;
  rule: IRule[];
  taskFilter?: taskFilterEnum[];
  faqFilter?: faqFilterEnum[];
  tenantInfoList?: {
    tenantCode?: number;
    tenantName?: string;
  }[];
  tenantList?: number[];
}

export interface IEditBandRuleRes {
  id?: string;
  name: string;
  bizId?: string;
  bizSceneId?: string;
  remark?: string;
  rule: IRule[];
  taskFilter?: taskFilterEnum[];
  faqFilter?: faqFilterEnum[];
  tenantList?: number[];
}

export interface queryRangeIdentifierEnum {
  code?: string;
  desc?: string;
}
export interface queryRangeIdentifierResponse extends ICommonResponse {
  data?: queryRangeIdentifierEnum[];
}

export interface IRuleListRes extends ICommonResponse {
  data: IRuleInfo[];
}
// 限频列表
export const getRuleList = async (): Promise<IRuleListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.biz.rule.list',
  });
  return res;
};

// 限频列表
export const deleteBandRule = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.biz.rule.delete',
  });
  return res;
};

// 新增平台限频
export const addBandRule = async (
  params: IEditBandRuleRes,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.biz.rule.create',
  });
  return res;
};

// 编辑平台限频
export const editBandRule = async (
  params: IEditBandRuleRes,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.biz.rule.update',
  });
  return res;
};

// 平台限频范围枚举
export const queryRangeIdentifier =
  async (): Promise<queryRangeIdentifierResponse> => {
    const res = await request.post(`${API.API_HOST}`, {
      bffAction: 'css.call.rangeIdentifier',
    });
    return res;
  };
