import request from '@/utils/request';

const getEnv = () => {
  switch (REACT_APP_ENV) {
    case 'pro':
    case 'pre':
    case 'uat':
    case 'fat':
      return REACT_APP_ENV;
    default:
      return 'fat';
  }
};
export const getLoginUserInfo = async (): Promise<string[]> => {
  const res = await request.get(
    'https://sso-api.hellobike.cn/systemUser/getLoginUserInfo',
    {
      params: {
        env: getEnv(),
      },
    },
  );
  return res.data?.userActions || [];
};
