import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

/**
 * 子流程列表interface
 */

export interface ChildSpeechObj {
  id: string;
  childProcessGuid: string;
  speechGuid: string;
  childSpeechName: string;
  childSpeechDesc: string;
  hitLimit: string;
  sort: number;
  createTime: string;
  updateTime: string;
  firstKnowledgeId: string;
}

export interface ChildSpeechListRes extends ICommonResponse {
  data: ChildSpeechObj[];
}

/**
 * 子流程详情interface
 */
export interface ChildSpeechDetail extends ChildSpeechObj {
  childNodePhases: string;
  childNodes: string;
  childFlowCanvasInfo: string;
}

export interface ChildSpeechInfoRes extends ICommonResponse {
  data: ChildSpeechDetail;
}

/**
 * 创建&编辑子流程interface
 */
export interface ChildSpeechSaveParams {
  speechGuid: string;
  childSpeechName: string;
  hitLimit: string;
  childProcessGuid?: string;
}

/**
 * 编辑子流程(画布)interface
 */
export interface ChildSpeechEditParams {
  speechGuid: string;
  childProcessGuid: string;
  childNodes: string;
  childNodePhases: string;
  childFlowCanvasInfo: string;
}

/**
 * 排序子流程interface
 */
export interface ChildSpeechSortParams {
  id: string;
  preId: string;
  speechGuid: string;
}

/**
 * 画布中保存时确认是否与子流程中重名interface
 */
export interface ChildSpeechCheckParams {
  guid: string;
  corpusId: string;
  corpusName: string;
  childProcessGuid: string;
}

// -------------------------------------------

// 子流程列表api
export const getChildSpeechList = async (params: {
  speechGuid: string;
}): Promise<ChildSpeechListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.child.speech.list',
    ...params,
  });
  return res;
};

// 子流程详情api
export const getChildSpeechInfo = async (params: {
  speechGuid: string;
  childProcessGuid: string;
}): Promise<ChildSpeechInfoRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.child.speech.info',
    ...params,
  });
  return res;
};

// 创建&编辑子流程api
export const saveChildSpeech = async (
  params: ChildSpeechSaveParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.child.speech.save',
    ...params,
  });
  return res;
};

// 编辑子流程(画布)api
export const editChildSpeech = async (
  params: ChildSpeechEditParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.child.speech.edit',
    ...params,
  });
  return res;
};

// 删除子流程api
export const deleteChildSpeech = async (params: {
  speechGuid: string;
  childProcessGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.child.speech.del',
    ...params,
  });
  return res;
};

// 排序子流程api
export const sortChildSpeech = async (
  params: ChildSpeechSortParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.child.speech.sort',
    ...params,
  });
  return res;
};

// 子流程保存校验是否有节点重名api
export const checkChildSpeechName = async (
  params: ChildSpeechCheckParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.child.speech.check',
    ...params,
  });
  return res;
};
