import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse, ICommonResponseList } from './baseInterface';

/**
 * 短链列表interface
 */
export interface ChainListParams {
  pageSize: number;
  pageNum: number;
  tenantIds?: number[];
  shortChainName?: string;
  originalUrl?: string;
  shortChainUrl?: string;
  templateName?: string;
  startCreateTime?: string;
  endCreateTime?: string;
}

export interface ChainObj {
  shortChainName: string;
  tenantId: number;
  tenantName: string;
  originalUrl: string;
  shortChainUrl: string;
  effectiveDate: number;
  templateNames: string;
  status: number;
  hitNum: number;
  authorName: string;
  createTime: string;
  id: string;
}

type ChainListRes = ICommonResponseList<ChainObj>;

/**
 * 创建、编辑短链interface
 */
export interface ChainSaveParams {
  id?: string;
  tenantId: number;
  shortChainName: string;
  originalUrl: string;
  effectiveDate: number;
  remark?: string;
}

/**
 * 短链访问详情interface
 */
export interface ChainHitLogInfoParams {
  pageSize: number;
  pageNum: number;
  startCreateTime?: string;
  endCreateTime?: string;
  shortChainUrl?: string;
}

export interface ChainHitLogObj {
  id: string;
  shortChainUrl: string;
  mobilePhoneModel: string;
  operatingSystem: string;
  browser: string;
  ip: string;
  ipAddress: string;
  ipAddressOwner: string;
  screenResolution: string;
  hitTime: string;
  createTime: string;
}

type ChainHitLogRes = ICommonResponseList<ChainHitLogObj>;

/**
 * 导出访问详情interface
 */
interface ExportChain extends ICommonResponse {
  data: {
    ossUrl: string;
  };
}

/**
 * 短链组列表（千人千链）interface
 */
export interface TaskChainListParams {
  pageSize: number;
  pageNum: number;
  tenantIds?: number[];
  taskName?: string;
  startCreateTime?: string;
  endCreateTime?: string;
}

export interface TaskChainListObj {
  taskName: string;
  taskGuid: string;
  tenantId: number;
  tenantName: string;
  shortChainNum: number;
  hitToTalNum: number;
  hitUVNum: number;
  createTime: string;
}

type TaskChainListRes = ICommonResponseList<TaskChainListObj>;

/**
 * 短链组详情列表interface
 */
interface TaskChainInfoParams {
  pageSize: number;
  pageNum: number;
  taskGuid: string;
}

export interface TaskChainObj {
  id: string;
  phoneNumber: string;
  originalUrl: string;
  shortChainUrl: string;
  intentClassify: string;
  intentClassifyName: string;
  mobilePhoneModel: string;
  operatingSystem: string;
  browser: string;
  ip: string;
  ipAddress: string;
  ipAddressOwner: string;
  screenResolution: string;
  hitNum: number;
  userMd5: string;
  userGuid: string;
  userNewId: string;
  lastHitTime: string;
  createTime: string;
}

type TaskChainInfoRes = ICommonResponseList<TaskChainObj>;

/**
 * 短链组详情interface
 */
export interface TaskChainInfoObj extends ICommonResponse {
  data: {
    shortChainNum: number;
    hitToTalNum: number;
    hitUVNum: number;
    taskGuid: string;
  };
}

// 短链列表
export const queryChainList = async (
  params: ChainListParams,
): Promise<ChainListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.chain.pageList',
    ...params,
  });
  return res;
};

// 创建、编辑短链
export const saveChain = async (
  params: ChainSaveParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.chain.save',
    ...params,
  });
  return res;
};

// 启用禁用短链
export const changeChainStatus = async (params: {
  id: string;
  statusChange: number;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.chain.statusChange',
    ...params,
  });
  return res;
};

// 短链访问详情
export const queryChainHitInfo = async (
  params: ChainHitLogInfoParams,
): Promise<ChainHitLogRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.chain.hit.logInfo',
    ...params,
  });
  return res;
};

// 导出访问详情
export const exportChainHitLog = async (
  params: ChainHitLogInfoParams,
): Promise<ExportChain> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.chain.hit.logInfo.export',
    ...params,
  });
  return res;
};

// 短链组列表
export const queryTaskChainRecord = async (
  params: TaskChainListParams,
): Promise<TaskChainListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.task.chain.record',
    ...params,
  });
  return res;
};

// 短链组详情列表
export const queryTaskChainRecordInfo = async (
  params: TaskChainInfoParams,
): Promise<TaskChainInfoRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.task.chain.record.info',
    ...params,
  });
  return res;
};

// 短链组详情
export const queryTaskChainInfo = async (params: {
  taskGuid: string;
}): Promise<TaskChainInfoObj> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.task.chain.info',
    ...params,
  });
  return res;
};

// 短链组详情导出
export const exportTaskChain = async (params: {
  taskGuid: string;
}): Promise<ExportChain> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.task.chain.export',
    ...params,
  });
  return res;
};
