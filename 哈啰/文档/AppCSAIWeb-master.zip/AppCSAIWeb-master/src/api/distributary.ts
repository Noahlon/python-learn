import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface IDplanParams {
  pageSize?: number;
  pageNum?: number;
  planId?: string;
  planName?: string;
  tenantCodeList?: string[];
  distributeType?: number;
  channelId?: number;
  createStartTime?: string;
  createEndTime?: string;
}

export interface IDplanPageResponse {
  code?: number;
  msg?: string;
  data?: IDplanPageQuery;
}
export interface IDplanPageQuery {
  pageNum: number;
  pageSize: number;
  totalRecord: number;
  totalPages: number;
  list?: IDlanPageList[];
}

export interface IDlanPageList {
  id?: string;
  distributePlanName?: string;
  tenantCode?: string;
  tenantName?: string;
  distributeType?: number;
  distributeTypeDesc?: string;
  uploadDataNum?: number;
  creator?: string;
  createTime?: string;
  templateId?: string;
  templateName?: string;
  distributeRuleList?: IDplanPageRuleList[];
}

export interface IDplanPageRuleList {
  channelId?: string;
  channelName?: string;
  taskTemplateId?: string;
  taskTemplateName?: string;
  percentage?: string;
  quantity?: number;
}

// 计划分页查询
export const planPageQuery = async (
  params: IDplanParams,
): Promise<IDplanPageResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'plan.pageQuery',
    ...params,
  });
  return res || {};
};

export interface IDplanCreate {
  distributePlanName: string;
  distributeType: number;
  tenantCode: string;
  tenantName: string;
  distributeRuleList: IDplanPageRuleList[];
}

// 计划新增
export const planCreate = async (params: IDplanCreate) => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'plan.create',
    ...params,
  });
  return res || {};
};
export interface IDPlanEdit {
  id: string;
  distributePlanName: string;
  tenantCode: string;
  tenantName: string;
  distributeType: number;
  distributeRuleList: IDplanPageRuleList[];
}

// 计划编辑
export const planEdit = async (params: IDPlanEdit) => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'plan.edit',
    ...params,
  });
  return res || {};
};
export interface IDplanDel {
  planId?: string;
}

// 计划删除
export const planDelete = async (params: IDplanDel) => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'plan.delete',
    ...params,
  });
  return res?.data || {};
};

export interface IDplanDetailParams {
  planId: string;
}

export interface IDplanDetail {
  id?: string;
  distributePlanName?: string;
  tenantCode?: string;
  tenantName?: string;
  distributeType?: number;
  distributeTypeDesc?: string;
  distributeRuleList?: IDplanDetailRuleList[];
  creator?: string;
  createTime?: string;
  templateId?: string;
  templateName?: string;
}

export interface IDplanDetailRuleList {
  channelId?: string;
  channelName?: string;
  percentage?: string;
  taskTemplateId?: string;
  taskTemplateName?: string;
  planChannelTaskId?: string;
  planChannelTaskStatus?: number;
  planChannelTaskStatusDesc?: string;
  check?: boolean;
}
// 计划详情
export const planDetail = async (
  params: IDplanDetailParams,
): Promise<IDplanDetail> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'plan.detail',
    ...params,
  });
  return res?.data || {};
};

export interface IDtemplateParams {
  templateId?: string;
  distributeType?: number;
  templateName?: string;
  tenantCodeList?: string[];
  channelId?: string;
  sortColumn?: string;
  sortType?: string;
  pageNum?: number;
  pageSize?: number;
}

export interface IDtemplateList {
  pageNum?: number;
  pageSize?: number;
  totalRecord?: number;
  totalPages?: number;
  list?: IDtemplateListColumn[];
}

export interface IDtemplateListResponse {
  success?: boolean;
  code?: number;
  data?: IDtemplateListData;
}
export interface IDtemplateListData {
  pageNum?: number;
  pageSize?: number;
  totalRecord?: number;
  totalPages?: number;
  list?: IDtemplateListColumn[];
}
export interface IDtemplateListColumn {
  templateId?: string;
  templateName?: string;
  tenantCode?: string;
  tenantName?: string;
  distributeType?: number;
  distributeRuleList?: IDtemplateRuleList[];
  latestUseTime?: string;
  creator?: string;
  createTime?: string;
  id?: string;
  distributePlanName?: string;
}

export interface IDtemplateRuleList {
  channelName?: string;
  channelId?: number;
  percentage?: string;
  taskTemplateId?: string;
  taskTemplateName?: string;
}
// 模版列表
export const templateList = async (
  params: IDtemplateParams,
): Promise<IDtemplateListResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'plan.template.pageQuery',
    ...params,
  });
  return res || {};
};

export interface IDtemplateCreate {
  templateName: string;
  tenantCode: string;
  tenantName?: string;
  distributeType: number;
  distributeRuleList: IDtemplateRuleList[];
}

export interface IDtemplateEdit {
  templateId?: string;
  templateName?: string;
  tenantCode?: string;
  tenantName?: string;
  distributeType: number;
  distributeRuleList: IDtemplateRuleList[];
}

//新增模版
export const templateCreate = async (
  params: IDtemplateEdit,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'plan.template.create',
    ...params,
  });
  return res || {};
};

//编辑模版
export const templateEdit = async (
  params: IDtemplateEdit,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'plan.template.edit',
    ...params,
  });
  return res || {};
};
export interface IDtemplateDelete {
  templateId: string;
}

//   删除模版
export const templateDelete = async (
  params: IDtemplateDelete,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'plan.template.delete',
    ...params,
  });
  return res?.data || {};
};

export interface IchannelList {
  channelId: string;
  channelName: string;
}
//渠道商列表
export const channelList = async (): Promise<IchannelList[]> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'channel.list',
  });
  return res?.data || [];
};

interface IDatachannelTemplateParams {
  channelId?: string;
  tenantCode?: string;
  channelIdList?: number[];
}

export interface IDatachannelTemplateList {
  channelId: string;
  channelName: string;
  templateList: ITemplateList[];
}

export interface ITemplateList {
  templateId: string;
  templateName: string;
}
//渠道模板列表
export const channelTemplateList = async (
  params: IDatachannelTemplateParams,
): Promise<IDatachannelTemplateList[]> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'channel.template.list',
    ...params,
  });
  return res?.data || [];
};

export interface IDRetryParams {
  planChannelTaskId: string;
}
//重试创建渠道任务
export const channelTaskRetry = async (
  params: IDRetryParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'channel.task.retry',
    ...params,
  });
  return res || {};
};

export interface IDStatParams {
  planId: string;
}
export interface IStatDataResponse extends ICommonResponse {
  data?: IStatData;
}
export interface IStatData {
  sentTotalSum?: number;
  sentSuccessSum?: number;
  callDialogueNumSum?: number;
  throughCallDialogueNumSum?: number;
  costUnitSum?: number;
  throughRosterNumSum?: number;
  throughRosterPercentage?: string;
  totalSendSmsSum?: number;
  totalSmsSuccSum?: number;
  totalSmsUnit?: number;
  totalSmsSuccRate?: string;
  channelTaskStatList?: IStatList[];
  totalIntentClassifyList?: IIntentClassifyList[];
  totalConversionFunnel?: IConversionFunnel[];
}
export interface IStatList {
  channelId?: number;
  channelName?: string;
  supplierTaskName?: string;
  supplierTaskId?: string;
  sentTotalNum?: number;
  sentTotalNumPercentage?: string;
  sentSuccessSum?: number;
  callDialogueNum?: number;
  throughCallDialogueNum?: number;
  costUnit?: number;
  throughRosterNum?: number;
  throughRosterPercentage?: string;
  latestSentTime?: string;
  sendSmsSum?: number;
  smsSuccSum?: number;
  smsSuccRate?: string;
  smsUnit?: number;
  intentClassifyList?: IIntentClassifyList[];
  conversionFunnel?: IConversionFunnel[];
}
export interface IConversionFunnel {
  name?: string;
  code?: string;
  id?: number;
  value?: number;
}

export interface IIntentClassifyList {
  name?: string;
  code?: string;
  value?: number;
  percentage?: string;
}

//渠道任务统计
export const channelTaskStat = async (
  params: IDStatParams,
): Promise<IStatDataResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'channel.task.stat',
    ...params,
  });
  return res || {};
};

export interface IDqueryUploadParams {
  uploadType?: number;
  distributePlanId?: string;
  distributeStatus?: number;
  pageNum?: number;
  pageSize?: number;
}

export interface IDqueryUploadListData {
  pageNum?: number;
  pageSize?: number;
  totalRecord?: number;
  list?: IqueryUploadList[];
}

export interface IqueryUploadList {
  id?: string;
  uploadType?: number;
  rosterType?: number;
  rosterTypeDesc?: string;
  uploadStatus?: number;
  uploadCount?: number;
  distributeStatus?: number;
  distributeCount?: number;
  operator?: string;
  uploadTime?: string;
}

//名单上传记录
export const queryUploadList = async (
  params: IDqueryUploadParams,
): Promise<IDqueryUploadListData> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'roster.queryUploadList',
    ...params,
  });
  return res?.data || {};
};

export interface IDqueryDistributeParams {
  channelId?: string;
  taskName?: string;
  pageSize?: number;
  pageNum?: number;
  distributePlanId?: string;
}

export interface IDqueryDistributeList {
  pageNum?: number;
  pageSize?: number;
  totalRecord?: number;
  list?: IDqueryDistribute[];
}

export interface IDqueryDistribute {
  id?: string;
  channelName?: string;
  taskName?: string;
  taskId?: string;
  distributeCount?: string;
  successCount?: string;
  distributeTime?: string;
}
//查询名单下发记录
export const queryDistributeList = async (
  params: IDqueryDistributeParams,
): Promise<IDqueryDistributeList> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'roster.queryDistributeList',
    ...params,
  });
  return res?.data || {};
};

export interface IDrosterDownload {
  type?: number;
}

//下载名单模版
export const rosterDownload = async (
  params: IDrosterDownload,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'roster.download',
    ...params,
  });
  return res || {};
};

export interface IDrosterUploadFile {
  fileUrl: string;
  fileName: string;
  distributePlanId: string;
  rosterType: number;
}
//下载名单模版
export const rosterUploadFile = async (
  params: IDrosterUploadFile,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'roster.uploadFile',
    ...params,
  });
  return res || {};
};

interface IDrosterRetryDistributeParams {
  distributePlanId: string;
  uploadRecordId: string;
}
//重试下发
export const rosterRetryDistribute = async (
  params: IDrosterRetryDistributeParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'roster.retryDistribute',
    ...params,
  });
  return res || {};
};

//  ---------------------------- > 查询话单列表
export interface IDdialogueListParams {
  platformId?: string;
  distributePlanName?: string;
  channelId?: number;
  distributePlanId?: string;
  md5?: string;
  calledNumber?: string;
  supplierTaskId?: string;
  supplierTaskName?: string;
  callResultList?: number[];
  intentClassifyList?: string[];
  intentClassifyName?: string;
  hitIntentions?: string[];
  excludeIntentions?: string[];
  isHitSms?: number;
  seatName?: string;
  durationCallAiStart?: number;
  durationCallAiEnd?: number;
  durationCallManualStart?: number;
  durationCallManualEnd?: number;
  realCallingNumber?: string;
  totalTimeStart?: number;
  totalTimeEnd?: number;
  ringTimeStart?: number;
  ringTimeEnd?: number;
  dialTimeStart?: string;
  dialTimeEnd?: string;
  hangupTimeStart?: string;
  hangupTimeEnd?: string;
  callType?: number;
  callingNumber?: string;
  costUnitStart?: number;
  costUnitEnd?: number;
  dialogueGuid?: string;
  citys?: string[];
  carrierList?: number[];
  speechCountStart?: number;
  speechCountEnd?: number;
  sex?: number;
  releaseInitiator?: number;
  createTimeStart: string;
  createTimeEnd: string;
  pageNum?: number;
  pageSize?: number;
}
export interface IDdialogueListRes extends ICommonResponse {
  data?: IDdialogueListInfo;
}

export interface IDdialogueListInfo {
  pageNum?: number;
  pageSize?: number;
  totalRecord: string;
  list?: IDdialogueListItem[];
}

export interface IDdialogueListItem {
  externalId: string;
  platformId: string;
  channelName: string;
  id: string;
  distributePlanName: string;
  distributePlanId: string;
  md5: string;
  calledNumber: string;
  supplierTaskId: string;
  supplierTaskName: string;
  speechTemplateId?: string;
  enterpriseId?: string;
  callResult: number;
  callResultDesc: string;
  intentClassify?: string;
  intentClassifyName?: string;
  hitIntentions?: string[];
  isHitSms?: number;
  seatName?: string;
  durationCallAi?: number;
  durationCallManual?: number;
  realCallingNumber?: string;
  totalTime?: number;
  ringTime?: number;
  dialTime?: string;
  hangupTime?: string;
  callType?: number;
  callingNumber?: string;
  costUnit?: number;
  customName?: string;
  dialogueGuid: string;
  recordUrl?: string;
  lineId?: string;
  city?: string;
  province?: string;
  carrier?: number;
  speechCount?: number;
  sex?: number;
  releaseInitiator?: number;
  createTime: string;
  tenantId?: string;
}
export const dialogueList = async (
  params: IDdialogueListParams,
): Promise<IDdialogueListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'dialogue.queryDialogueList',
    ...params,
  });
  return res || {};
};

//  ---------------------------- >查询话单详情
export interface IDdialogueQueryDetailParams {
  id: string;
  calledNumber: string;
}
export interface IDdialogueQueryDetailRes extends ICommonResponse {
  data?: IDdialogueQueryDetailInfo;
}
export interface IDdialogueQueryDetailInfo {
  id: string;
  answerTime?: string;
  hangupTime?: string;
  recordUrl?: string;
  speakList?: IDQueryDetailSpeakList[];
}

export interface IDQueryDetailSpeakList {
  speakId: string;
  speaker: number;
  speakContent: string;
  speakTime: string;
}
export const dialogueQueryDetail = async (
  params: IDdialogueQueryDetailParams,
): Promise<IDdialogueQueryDetailRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'dialogue.queryDetail',
    ...params,
  });
  return res || {};
};

//  ---------------------------->导出通话记录
export const dialogueExport = async (
  params: IDdialogueListParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'dialogue.export',
    ...params,
  });
  return res || {};
};

//  ---------------------------->通话结果枚举值列表 入参 :type=1
export interface IDRosterEnum {
  type?: number;
}
export interface IDRosterEnumDataRes extends ICommonResponse {
  data?: IDRosterEnumData;
}

interface IDRosterEnumData {
  enumConstantDTOList?: IEnumConstantDTOList[];
  type?: number;
}

interface IEnumConstantDTOList {
  code?: string;
  value?: string;
}
export const getRosterEnumList = async (
  params: IDRosterEnum,
): Promise<IDRosterEnumDataRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'common.enum.list',
    ...params,
  });
  return res || {};
};

//  ----------------------------> 渠道短信列表
export interface ISmsRecordListParams {
  pageSize?: number;
  pageNum?: number;
  channelId?: number;
  guid?: string;
  phoneNum?: string;
  phoneNumMd5?: string;
  distributePlanId?: string;
  distributePlanName?: string;
  supplierTaskId?: string;
  supplierTaskName?: string;
  sendResultList?: number[];
  signature?: string;
  content?: string;
  createBeginTime?: string;
  createEndTime?: string;
  sendBeginTime?: string;
  sendEndTime?: string;
  receiveResultBeginTime?: string;
  receiveResultEndTime?: string;
  seatsName?: string;
  callGuid?: string;
  cityList?: string[];
  carrierList?: number[];
}
export interface ISmsRecordListRes extends ICommonResponse {
  data?: ISmsRecordData;
}
export interface ISmsRecordData {
  pageNum?: number;
  pageSize?: number;
  totalRecord?: number;
  totalPages?: number;
  list?: ISmsRecordList[];
}
export interface ISmsRecordList {
  guid?: string;
  channelId?: number;
  channelName?: string;
  externalId?: string;
  phoneNum?: string;
  phoneNumMd5?: string;
  distributePlanId?: string;
  distributePlanName?: string;
  supplierTaskId?: string;
  supplierTaskName?: string;
  tenantCode?: string;
  signature?: string;
  content?: string;
  sendResultDesc?: string;
  sendResult?: string;
  createTime?: string;
  sendTime?: string;
  receiveResultTime?: string;
  seatsName?: string;
  billingNum?: string;
  customName?: string;
  callGuid?: string;
  province?: string;
  city?: string;
  carrier?: number;
  enterpriseId?: string;
  speechName?: string;
}
export const getSmsRecordList = async (
  params: ISmsRecordListParams,
): Promise<ISmsRecordListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.record',
    ...params,
  });
  return res || {};
};

// 复制分流计划模版
export interface IStemplateCopyRes extends ICommonResponse {
  data?: IStemplateCopyData;
}
export interface IStemplateCopyData {
  tenantCode: string;
  tenantName: string;
  distributeType: number;
  templateName: string;
  distributeRuleList: IDtemplateRuleList[];
}

export const templateCopy = async (params: {
  templateId: string;
}): Promise<IStemplateCopyRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'plan.template.copy',
    ...params,
  });
  return res || {};
};

//  ---------------------------->导出短信记录

/* 自动生成的 Interface */
export const smsRecordExport = async (
  params: ISmsRecordListParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.record.export',
    ...params,
  });
  return res || {};
};
