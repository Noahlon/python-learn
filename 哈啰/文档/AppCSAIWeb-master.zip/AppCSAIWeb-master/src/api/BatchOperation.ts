import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

interface EditBlackGroupType {
  taskGuid?: string;
  pageNum: number;
  pageSize: number;
  namelistType?: number;
  name?: string;
}

export const queryList = async (
  params: EditBlackGroupType,
): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'task.pageListTaskNamelist',
    ...params,
  });
  return res;
};
