import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponseList } from './baseInterface';

// 分页查询下载列表
export interface ExportListParams {
  pageSize: number;
  pageNum: number;
  bizTypeCode?: string;
  statusCode?: string;
  operatorTimeStart?: string;
  operatorTimeEnd?: string;
}

export interface ExportListObj {
  guid?: string;
  bizTypeCode?: string;
  bizTypeDesc?: string;
  statusCode?: string;
  statusDesc?: string;
  operatorTime?: string;
  operatorName?: string;
  failReason?: string;
  fileUrl?: string;
  count?: number;
}

type ExportListRes = ICommonResponseList<ExportListObj>;

// 分页查询下载列表
export const getFileExportList = async (
  params: ExportListParams,
): Promise<ExportListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.file.export.list',
  });
  return res;
};

export interface IDExportListParams {
  pageNum: number;
  pageSize: number;
  bizType?: number;
  status?: number;
  createTimeStart?: string;
  createTimeEnd?: string;
}
export interface IDgetFileExportRecordObj {
  id: string;
  bizType: number;
  status: number;
  createTime: string;
  operator: string;
  failReason?: string;
  exportCount?: number;
  fileUrl?: string;
}
type FileExportRecordRes = ICommonResponseList<IDgetFileExportRecordObj>;
// 渠道下载列表
export const getFileExportRecordList = async (
  params: IDExportListParams,
): Promise<FileExportRecordRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'file.export.record',
  });
  return res;
};
