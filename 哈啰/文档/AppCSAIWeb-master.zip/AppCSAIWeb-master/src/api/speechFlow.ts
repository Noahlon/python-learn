import request from '@/utils/request';
import API, { CONFIGAPI } from '@/config/env';
import { IResponse, ICommonResponse } from './baseInterface';

/**
 * 查询有知识库的工单分类 以tree形式返回
 * url:  /orderClassify/getClassifyTree
 * YAPI: https://yapi.hellobike.cn/project/131/interface/api/124395
 */

export interface ISubNodeRouteMessage {
  routeName?: string;
  routeType?: number;
  routeCondition?: string;
  routeTarget?: string;
  id?: string;
}

export interface ISubNodeMessage {
  id: string;
  nodeType: number;
  code?: string;
  name?: string;
  faqId?: string;
  routeName?: string;
  routeNodeConfigs?: ISubNodeRouteMessage[];
}

export interface IRouteCondition {
  label: string;
  value: string;
}
export interface IRouteType {
  msg: string;
  code: number;
  mark: boolean;
  routeCondition: IRouteCondition[];
}

export interface IBreed {
  routeName: string;
  routeType: IRouteType[];
}
export interface ITemplateData {
  type?: string;
  phase: string;
  name: string;
  knowledgeNodeMessageList?: ISubNodeMessage[];
}

export interface IMold {
  nodeType: string;
  process: IBreed[];
}

export interface ISubNodeAdd {
  name: string;
  nodeType: number;
}

export interface ITemplateRes {
  masterplate?: ITemplateData[];
  mold: IMold[];
  subNodeData: ISubNodeAdd[];
}

export interface ISubNodeReq {
  nodeType?: number;
  code?: string;
}

export interface INodePhasesReq {
  breakType?: string;
  name?: string;
  type?: number;
  phase?: string;
  mainFlow?: boolean;
  nodeTypes?: ISubNodeReq[];
  knowledgeBaseScope?: string[];
  intentionClassification?: string;
  intentionLabels?: string[];
}

export interface IEditProcessReq {
  nodes: string;
  flowCanvasInfo: string;
  nodePhases: string;
  tenant?: number;
  guid: string;
}

export interface IQueryProcessReq {
  guid?: string;
  groupId: string;
}

export interface IProcessInfo {
  flowCanvasInfo: string;
  nodePhases: string;
  nodes: string;
}

export interface IKnowleCollectListReq {
  speechGuid?: string;
  pageSize: number;
  pageNum: number;
  tenant?: any;
  isContainsGlobal?: boolean;
}

export interface IKnowleCollectList {
  tenant: number;
  description: string;
  guid: string;
  name: string;
  speechGuid: string;
}

export interface IKnowleCollectListRes extends ICommonResponse {
  data: {
    list: IKnowleCollectList[];
  };
}

export interface IKnowleListReq {
  kcGuid: string;
  pageSize: number;
  pageNum: number;
}

export interface IKnowledgeReplyContentDTOList {
  contentText: string;
  corpusStatus: number;
  corpusFileUri: string;
  corpusFileKey: number;
  order: number;
}

export interface IKnowleList {
  faqId: string;
  name: string;
  answerGuid: string;
  kcGuid: string;
  kcName: string;
  knowledgeReplyContentDTOList: IKnowledgeReplyContentDTOList[];
  author: string;
  categoryIdList: string;
  updateTime: string;
}

export interface IKnowleListRes extends ICommonResponse {
  data: {
    list: IKnowleList[];
  };
}

export interface IRules {
  ruleName: string;
  speechGuid?: string;
  id?: string;
  intentionClassification?: string;
  intentionLabels?: string[];
  priority?: number;
  purposeRule?: {
    callConnectStatus?: number;
    callConnectStatusList?: number[];
    userSayRegexpStr?: string;
    // hitChildPhase?: {
    //   childPhases?: {
    //     code: string;
    //     desc: string;
    //   }[];
    //   hitChildPhaseCodes?: string[];
    //   num?: number;
    // };
    // hitQA?: {
    //   hitFaqIds?: string[];
    //   hitCorpusIds?: string[];
    //   num?: number;
    // };
    // hitAlgorithmIntention?: {
    //   hitAlgorithmIntentions?: string[];
    //   num?: number;
    // };
    hitQACorpus?: {
      hitCorpuses: { corpusId: string; corpusName: string }[];
      num?: number;
      max?: number;
      selectAll?: boolean;
    };
    globalPriority?: {
      hitCorpuses: { corpusId: string; corpusName: string }[];
      num?: number;
      max?: number;
      selectAll?: boolean;
    };
    releaseInitiator?: number;
    // hitPhraseIntention?: {
    //   hitPhraseIntentions?: string[];
    //   num?: number;
    // };
    hitIntention?: {
      hitIntentions: { intentionId: string; name: string }[];
      num?: number;
      max?: number;
    };
    hitLabel?: {
      labels: { code: string; labelName: string }[];
      num?: number;
      max?: number;
    };

    hitLabelGroup?: {
      labelGroups: { code: string; labelGroupName: string }[];
      num?: number;
      max?: number;
    };
    hitIntentionPath?: { intentionId: string; name: string }[];
    callDuration?: {
      min?: number;
      max?: number;
    };
    userSayTimes?: {
      min?: number;
      max?: number;
    };
    dialogueRounds?: {
      min?: number;
      max?: number;
    };
    //肯定次数
    affirmativeNumber?: {
      min?: number;
      max?: number;
    };
    //否定次数
    negativeNumber?: {
      min?: number;
      max?: number;
    };
    //疑问次数
    questioningNumber?: {
      min?: number;
      max?: number;
    };
    lastIntentionNegative?: boolean; //最后是否否定
    lastIntentionAffirmative?: boolean; //最后是否肯定
  };
}

export interface IRulesListRes extends ICommonResponse {
  data: IRules[];
}

export interface ISubProcess {
  code: string;
  desc: string;
}

export interface ISubProcessListRes extends ICommonResponse {
  data: ISubProcess[];
}

export interface IApi {
  apiAction: string;
  apiIface: string;
  apiIllustrate: string;
  apiMethod: string;
  apiStatus: string;
  apiVersion: string;
  businessType: string;
  creatorName: string;
  guid: string;
  modifierName: string;
  serviceName: string;
  soaGroup: string | null;
  soaTag: string | null;
}

export interface IApiListRes extends ICommonResponse {
  data: {
    list: IApi[];
    pageNumber: number;
    pageSize: number;
    total: string;
  };
}

export interface IApiParam {
  apiGuid: string;
  children?: IApiParam[];
  defaultValue?: string;
  fieldAlias: string;
  guid: string;
  paramDescription: string;
  paramField: string;
  paramType: string;
  parentField?: string;
  parentGuid?: string;
  requireType?: string;
  docDisplay: 1;
  __key?: string;
}

export interface IParamRes extends ICommonResponse {
  data: {
    apiAction: string;
    apiIface: string;
    apiIllustrate: string;
    apiMethod: string;
    apiStatus: string;
    apiVersion: string;
    businessType: string;
    creatorName: string;
    guid: string;
    modifierName: string;
    serviceName: string;
    soaGroup: string | null;
    soaTag: string | null;
    requestParam: IApiParam[];
    responseParam: IApiParam[];
  };
}

export interface IOP {
  opKey: string;
  opValue: string;
  paramNum: number;
}

export interface IOPList {
  typeName: string;
  opList?: IOP[];
}

export interface IOPListRes extends ICommonResponse {
  data: IOPList[];
}

export interface IConditionData {
  variableType: number;
  variableName: string;
  needType: number;
  filterVariableTypes?: number[];
  opList: IOP[];
}

export interface IConditionRes extends ICommonResponse {
  data: IConditionData[];
}

// 获取模版接口
export const getNodeProcessList = async (): Promise<ITemplateRes[]> => {
  const res = await request.post<IResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.nodeProcess',
  });
  return (res?.data as unknown as ITemplateRes[]) || [];
};

// 流程维护
export const editProcessConfig = async (
  params: IEditProcessReq,
): Promise<IResponse> => {
  const res = await request.post<IResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.edit',
  });
  return res;
};

// 请求流程详情
// export const getProcessDetail = async (
//   params: IQueryProcessReq,
// ): Promise<IResponse> => {
//   const res = await request.post<IResponse>(`${API.API_HOST}`, {
//     ...params,
//     bffAction: 'css.call.speech.published.get',
//   });
//   return res;
// };

// export const getGroup = async (
//   params: IQueryProcessReq,
// ): Promise<IResponse> => {
//   const res = await request.post<IResponse>(`${API.API_HOST}`, {
//     ...params,
//     bffAction: 'css.call.speech.group.get',
//   });
//   return res;
// };

//获取话术详情

export interface IDspeechDetailRes extends ICommonResponse {
  data?: IDspeechDetail;
}
export interface IDspeechDetail {
  guid?: string;
  tenant?: number;
  tenantDesc?: string;
  bizId?: string;
  bizName?: string;
  intentionCollections?: IIntentionCollections[];
  bizScene?: string;
  bizSceneDesc?: string;
  speechName?: string;
  desc?: string;
  nodePhases?: string;
  nodes?: string;
  author?: string;
  flowCanvasInfo?: string;
  updateTime?: string;
  speechVersion?: string;
  statusLabel?: string;
  status?: number;
  groupId?: string;
  isDraft?: number;
  isVisiable?: number;
  ttsServer?: string;
  modelId?: string;
  isFullTtsCompose?: boolean;
  chineseForeignCompare?: number;
  acousticsParams?: IAcousticsParams[];
  ttsModelParam?: ITtsModelParam;
  transferVersion?: number;
  recordGather?: boolean;
}

interface ITtsModelParam {
  speechRate?: number;
  volume?: number;
  pitchRate?: number;
}

interface IAcousticsParams {
  type?: number;
  name?: string;
  desc?: string;
  value?: string;
}

interface IIntentionCollections {
  intentionCollectionId: string;
  intentionCollectionName: string;
}
export const getProcessDetail = async (params: {
  guid?: string;
  groupId?: string;
}): Promise<IDspeechDetailRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.detail',
    ...params,
  });
  return res || {};
};
export const getGroup = async (params: {
  guid?: string;
  groupId?: string;
}): Promise<IDspeechDetailRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.detail',
    ...params,
  });
  return res || {};
};

// 创建话术草稿
export const createDraftSpeech = async (params: {
  copySpeechGuid: string;
}): Promise<IResponse> => {
  const res = await request.post<IResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.speech.draft.create',
  });
  return res;
};

// 获取知识集合列表
export const getKnowleCollectList = async (
  params: IKnowleCollectListReq,
): Promise<IKnowleCollectList[]> => {
  const res = await request.post<IKnowleCollectListRes, IKnowleCollectListRes>(
    `${API.API_HOST}`,
    {
      ...params,
      bffAction: 'css.call.kc.list',
    },
  );
  return res?.data?.list || [];
};

// 获取知识列表
export const getKnowleList = async (
  params: IKnowleListReq,
): Promise<IKnowleList[]> => {
  const res = await request.post<IKnowleListRes, IKnowleListRes>(
    `${API.API_HOST}`,
    {
      ...params,
      bffAction: 'css.call.knowledge.list',
    },
  );
  return res?.data?.list || [];
};

// 获取规则列表
export const getRulesList = async (params: {
  speechGuid?: string;
  ids?: string[];
}): Promise<IRulesListRes> => {
  const res = await request.post<IRulesListRes, IRulesListRes>(
    `${API.API_HOST}`,
    {
      ...params,
      bffAction: 'css.call.purposerule.list',
    },
  );
  return res;
};

// 新增规则
export const addRule = async (params: IRules): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.purposerule.create',
  });
  return res;
};

// 编辑规则
export const editRule = async (params: IRules): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.purposerule.edit',
  });
  return res;
};

// 删除规则
export const deletetRule = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.purposerule.delete',
  });
  return res;
};

// 子流程列表
export const getProcessList = async (params?: {
  speechGuid?: string;
}): Promise<ISubProcessListRes> => {
  const res = await request.post<ISubProcessListRes, ISubProcessListRes>(
    `${API.API_HOST}`,
    {
      ...params,
      bffAction: 'css.call.speech.child.phase',
    },
  );
  return res;
};

// 废弃
export const abandon = async (params: {
  guid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.abandon',
    ...params,
  });
  return res;
};

// 拖拽
export const ruleMove = async (params: {
  id: string;
  priority: string | number;
  pre: string | number;
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.call.purposerule.move',
    ...params,
  });
  return res;
};

// 获取接口下拉
export const getApiList = async (params: {
  pageSize: number;
  pageNum: number;
  businessType?: string;
}): Promise<IApiListRes> => {
  const res = await request.get(`${CONFIGAPI}/gateway/api/search`, {
    params: params,
  });
  return res;
};

// 获取接口下的出参数据
export const getResParamList = async (id: string): Promise<IParamRes> => {
  const res = await request.get(`${CONFIGAPI}/gateway/api/${id}`);
  return res;
};

// 获取操作符枚举
export const getOPList = async (): Promise<IOPListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.op.list',
  });
  return res;
};

// 获取条件分支返回判断条件列表
export const getConditionList = async (): Promise<IConditionRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.condition.list',
  });
  return res;
};

// 配置话术最大振铃时长
export const speechRingEdit = async (params: {
  speechGuid: string;
  maxRingTime: string | number;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.speech.ring.edit',
    ...params,
  });
  return res;
};

// 话术最大振铃时长获取
export const speechRingGet = async (params: {
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(`${API.API_HOST}`, {
    bffAction: 'css.speech.ring.get',
    ...params,
  });
  return res;
};

export interface IDpriorityQueryResponse extends ICommonResponse {
  data: IDpriorityQueryList[];
}

export interface IDpriorityQueryList {
  code?: number;
  desc?: string;
  priority?: number;
  canEdit?: boolean;
}
// 话术语料优先级配置查询
export const priorityQuery = async (params: {
  speechGuid: string;
}): Promise<IDpriorityQueryResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.speech.priority.query',
    ...params,
  });
  return res;
};

export interface IDprioritySaveParams {
  speechGuid: string;
  corpusHintPriorityDTOList?: IDprioritySaveList[];
}

export interface IDprioritySaveList {
  code: number;
  desc: string;
  priority: number;
}

// 话术语料优先级配置编辑保存
export const prioritySave = async (
  params: IDprioritySaveParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.speech.priority.save',
    ...params,
  });
  return res;
};

export interface ISwitchAudioRecorderStatusParams {
  guid: string;
  recordGather: boolean;
}
export const switchAudioRecorderStatus = async (
  params: ISwitchAudioRecorderStatusParams,
): Promise<ICommonResponse> =>
  request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.speech.record.collect',
    ...params,
  });

//查询语料关联短信情况
export interface ISpeechSmsListResponse extends ICommonResponse {
  data: ISpeechSmsListData[];
}
export interface ISpeechSmsListData {
  corpusId?: string;
  corpusName?: string;
  corpusSource?: string;
  corpusSourceName?: string;
  triggerSendMsg?: number;
  smsTemplateId?: string;
  open?: boolean;
}

export const speechSmsList = async (params: {
  speechGuid: string;
}): Promise<ISpeechSmsListResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.speech.sms.list',
    ...params,
  });
  return res;
};

// 语料关联短信批量编辑
export interface IDspeechSmsEditParams {
  speechGuid: string;
  corpusSmsTemplateList: ICorpusSmsTemplateList[];
}

export interface ICorpusSmsTemplateList {
  corpusId?: string;
  smsTemplateId?: string;
}

export const speechSmsEdit = async (
  params: IDspeechSmsEditParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.speech.sms.edit',
    ...params,
  });
  return res;
};

// 话术语料回复优先级配置查询
export const corpusPriorityQuery = async (params: {
  speechGuid: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'corpus.priority.query',
    ...params,
  });
  return res;
};

//话术语料回复优先级配置保存
export interface corpusPrioritySaveParams {
  speechGuid: string;
  corpusMatchRuleDTOList?: ICorpusMatchRuleDTOList[];
}

export interface ICorpusMatchRuleDTOList {
  code: number;
  desc: string;
  priority: number;
}
export const corpusPrioritySave = async (
  params: corpusPrioritySaveParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'corpus.priority.save',
    ...params,
  });
  return res;
};
