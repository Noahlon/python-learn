import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

/**
 * 查询有知识库的工单分类 以tree形式返回
 * url:  /orderClassify/getClassifyTree
 * YAPI: https://yapi.hellobike.cn/project/131/interface/api/124395
 */
export const getClassifyTree = async (): Promise<ICommonResponse> => {
  const res = await request.post<ICommonResponse>(
    `${API.API_KB_HOST}/orderClassify/getClassifyTree`,
    {},
  );
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return res as any;
};
