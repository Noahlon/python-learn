import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

interface EmergencyStatusRes extends ICommonResponse {
  data: number;
}

// 紧急制动状态查询接口
export const queryEmergencyStatus = async (params: {
  emergencyCode: string;
}): Promise<EmergencyStatusRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.emergency.queryStatus',
  });
  return res;
};

// 变更紧急制动状态
export const changeEmergencyStatus = async (params: {
  emergencyCode: string;
  status: number;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.emergency.updateStatus',
  });
  return res;
};
