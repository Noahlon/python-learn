import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface addParams {
  guid?: string;
  supplierGuid: string;
  signallingCode: number;
  callResultContrast?: string;
  interpretation?: string;
}
export interface listParams {
  pageSize: number;
  pageNum: number;
  supplierGuid?: string;
}
export interface signallingListType {
  guid?: string;
  supplierGuid: string;
  signallingCode: number;
  callResultContrast?: string;
  callResultContrastDesc?: string;
  interpretation?: string;
}

export interface signallingDataType extends ICommonResponse {
  data: {
    pageNum: number;
    pageSize: number;
    totalRecord: number;
    totalPages: number;
    list: signallingListType[];
  };
}

// 供应商信令码对照信息列表
export const getSignallingList = async (
  params: listParams,
): Promise<signallingDataType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'signal.page',
    ...params,
  });
  return res;
};

// 供应商信令码对照信息新增
export const addSignalling = async (
  params: addParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'signal.add',
    ...params,
  });
  return res;
};

// 供应商信令码对照信息编辑
export const editSignalling = async (
  params: addParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'signal.edit',
    ...params,
  });
  return res;
};

// 供应商信令码对照信息删除
export const deleteSignalling = async (params: {
  guid?: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'signal.del',
    ...params,
  });
  return res;
};

// 获取外呼结果接口
export const getCallResultList = async (): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'callout.result.listV2',
  });
  return res;
};

// 供应商信令码对照信息上传模版
export const template = async (): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'signal.template',
  });
  return res;
};

// 供应商信令码对照信息上传
export const importSignalling = async (params: {
  ossUrl?: string;
  supplierGuid?: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'signal.import',
    ...params,
  });
  return res;
};
