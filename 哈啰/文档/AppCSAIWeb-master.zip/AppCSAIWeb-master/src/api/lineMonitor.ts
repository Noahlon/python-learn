import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface ILineInfo {
  id: string;
  statisticsDate?: string;
  tenantCode?: string;
  statisticKey?: string;
  supplierGuid?: string;
  lineGuid?: string;
  tenantName?: string;
  callingNumber?: string;
  lineName?: string;
  supplierName?: string;
  totalConcurrency?: string;
  allocatedConcurrency?: string;
  totalCall?: string;
  totalCall15Min?: string;
  totalPut?: string;
  totalPut15Min?: string;
  putRate?: string;
  putRate15Min?: string;
  costUnit?: number;
  costUnit15Min?: number;
  sumDurationCall?: number;
  avgDurationCall?: number;
  totalNotUserSpeak?: string;
  totalNotUserSpeak15Min?: string;
  notUserSpeakRate?: string;
  notUserSpeakRate15Min?: string;
  totalShortCallDuration?: string;
  totalShortCallDuration15Min?: string;
  shortCallDurationRate?: string;
  shortCallDurationRate15Min?: string;
  totalRateLimit?: string;
  totalRateLimit15Min?: string;
  rateLimitRate?: string;
  rateLimitRate15Min?: string;
  totalBlack?: string;
  totalBlack15Min?: string;
  totalBlackRate?: string;
  totalBlackRate15Min?: string;
  tenantBilling?: number;
}

interface ILineResponse extends ICommonResponse {
  data: {
    totalRecord?: number;
    totalPages?: number;
    list: ILineInfo[];
  };
}

interface ILineListReq {
  statisticsType?: number;
  statisticKey?: string;
  interval?: number;
  startDate?: string;
  endDate?: string;
  pageNum: number;
  pageSize: number;
  processStatisticKeyList?: string[];
  processStatisticKeyType?: number;
  taskGuid?: string;
  intentClassify?: string;
  supplierName?: string;
  callingNumber?: string;
  tenantCode?: string;
}

// 租户线路，供应商线路统计
export const getLine = async (params: ILineListReq): Promise<ILineResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.statistics.countCall',
    ...params,
  });
  return res;
};

interface ILineStatisticsReq {
  statisticsType: number;
  statisticKey: string;
  startDate?: string;
  endDate?: string;
  pageSize?: number;
  pageNum?: number;
}

interface ILineProcessReq extends ILineStatisticsReq {
  interval: number;
  pageNum: number;
  pageSize: number;
  processStatisticKeyList?: number[] | string[];
  processStatisticKeyType?: number;
}

export interface ILineProcess {
  statisticsDate?: string;
  calloutResult?: number;
  calloutResultDesc?: string;
  callsCount?: number;
  callsRate?: string;
  value?: any;
}

interface ILineProcessRes extends ICommonResponse {
  data: ILineProcess[];
}

// 监控详情页-外呼结果统计
export const getLineCallProcess = async (
  params: ILineProcessReq,
): Promise<ILineProcessRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.statistics.process',
    ...params,
  });
  return res;
};

export interface ICallOut {
  statisticsDate?: string;
  totalCall?: number;
}

interface ICallOutRes extends ICommonResponse {
  data: ICallOut[];
}

// 监控详情页-送呼数量统计
export const getLineCallOut = async (params: {
  statisticsType: number;
  statisticKey: string;
  startDate?: string;
  endDate?: string;
  interval: number;
  pageNum: number;
  pageSize: number;
}): Promise<ICallOutRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.statistics.callout',
    ...params,
  });
  return res;
};

interface ILineProvinceReq extends ILineStatisticsReq {
  pageNum: number;
  pageSize: number;
}

export interface ILineProvince {
  totalPut?: string;
  totalPutRate?: string;
  totalCall?: string;
  totalCallRate?: string;
  province?: string;
  city?: string;
  index?: number;
}

interface StatisticsProvinceResponseType extends ICommonResponse {
  data: {
    statistics?: ILineProvince[];
    totalCall?: number;
  };
}

// 监控详情页-省份统计
export const statisticsProvince = async (
  params: ILineProvinceReq,
): Promise<StatisticsProvinceResponseType> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.statistics.cityRatio',
    ...params,
  });
  return res;
};

export interface ILineAbnormal {
  statisticsDate?: string;
  abnormalType?: string;
  abnormalTypeDesc?: string;
  callsCount?: number;
  callsRate?: string;
}

interface ILineAbnormalRes extends ICommonResponse {
  data?: ILineAbnormal[];
}

// 监控详情页-异常
export const getLineAbnormal = async (
  params: ILineProcessReq,
): Promise<ILineAbnormalRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.statistics.abnormal',
    ...params,
  });
  return res;
};

export interface ILinePie {
  status?: string;
  desc?: string;
  rate?: number;
  num?: number;
}

interface ILinePieRes extends ICommonResponse {
  data?: {
    list: ILinePie[];
    totalCall: number;
    totalConcurrency?: number;
    allocatedConcurrency?: number;
  };
}

// 监控详情页-外呼占比
export const getLineCallPie = async (
  params: ILineStatisticsReq,
): Promise<ILinePieRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.statistics.resultRatio',
    ...params,
  });
  return res;
};

interface IStatisticsCallNumUseReq {
  startDate?: string;
  endDate?: string;
  lineGuid: string;
  pageSize: number;
  pageNum: number;
}

export interface ICallNumUse {
  callingNumber: string;
  totalCall?: number;
  totalPut: number;
  totalPutRate: string;
  totalConcurrency: number;
  allocatedConcurrency: number;
}

interface IStatisticsCallNumUseRes extends ICommonResponse {
  data: {
    list: ICallNumUse[];
    totalRecord?: number;
  };
}

// 号码使用统计
export const statisticsCallNumUse = async (
  params: IStatisticsCallNumUseReq,
): Promise<IStatisticsCallNumUseRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.statistics.callNumUse',
    ...params,
  });
  return res;
};

export interface IStatisticsInfo {
  typeDesc?: string;
  statisticsDate?: string;
  callsCount?: number;
  callsRate?: number;
}

interface IStatisticsCallNumUseInfoRes extends ICommonResponse {
  data: IStatisticsInfo[];
}

// 号码使用统计详情（折线图）
export const statisticsCallNumUseInfo = async (params: {
  startDate?: string;
  endDate?: string;
  callingNumber: string;
  supplierLineGuid: string;
}): Promise<IStatisticsCallNumUseInfoRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.statistics.callNumInfo',
    ...params,
  });
  return res;
};

export interface ICallNumArea {
  province?: string;
  city?: string;
  totalCall?: number;
  totalPut?: number;
  index?: number;
}

interface IStatisticsCallNumAreaRes extends ICommonResponse {
  data: {
    list: ICallNumArea[];
    totalRecord?: number;
  };
}

// 号码省市接通情况
export const statisticsCallNumArea = async (
  params: IStatisticsCallNumUseReq,
): Promise<IStatisticsCallNumAreaRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.statistics.callNumArea',
    ...params,
  });
  return res;
};

export interface ICallNumAreaInfo {
  typeDesc?: string;
  statisticsDate?: string;
  callsCount?: number;
  callsRate?: number;
}

interface IStatisticsCallNumAreaInfoRes extends ICommonResponse {
  data: ICallNumAreaInfo[];
}

// 号码省市接通统计详情（折线图）
export const statisticsCallNumAreaInfo = async (params: {
  startDate?: string;
  endDate?: string;
  supplierLineGuid: string;
  city?: string;
}): Promise<IStatisticsCallNumAreaInfoRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.statistics.numAreaInfo',
    ...params,
  });
  return res;
};

// 线路监控导出
export const statisticsExport = async (
  params: ILineListReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.statistics.export',
    ...params,
  });
  return res;
};

// 线路监控饼图外呼结果导出
export const statisticsCallResultExport = async (
  params: ILineStatisticsReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.statistics.ratioExcel',
    ...params,
  });
  return res;
};

// 线路省市导出
export const statisticsCityExport = async (
  params: ILineStatisticsReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.statistics.cityExcel',
    ...params,
  });
  return res;
};
