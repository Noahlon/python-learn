import request from '@/utils/request';
import API from '@/config/env';
import type {
  DataType,
  SortDataType,
  DownLoadListType,
} from '@/pages/supllierReconciliation/differenceManagement/type';

export interface DiffTableInfoDataType {
  totalPages: number;
  totalRecord: number;
  pageNum: number;
  list: DataType[];
}
export interface SupplierOptionsDataType {
  supplierName: string;
  supplierCode: string;
}
export interface allPageTotalType {
  helloBillingUnitNumSum: string;
  helloBillAmountSum: string;
  supplierBillingUnitNumSum: string;
  billUnitDiffNumSum: string;
  billUnitDiffAmountSum: string;
}
// 获取表格数据
export const getDiffTableInfo = async (
  params: SortDataType,
): Promise<DiffTableInfoDataType> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.bill.queryBillDiffPage',
  });
  return res?.data as unknown as DiffTableInfoDataType;
};
// 获取下载明细
export const getDownLoadDetail = async (guid: string): Promise<string> => {
  const res = await request.post(`${API.API_HOST}`, {
    guid: guid,
    bffAction: 'css.call.bill.downloadDetail',
  });
  return res?.data as unknown as string;
};
// 获取下载列表
export const getDownLoadList = async (
  params: DownLoadListType,
): Promise<string> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.bill.downloadDiffList',
  });
  return res?.data as unknown as string;
};
// 供应商账单金额重算
export const reloadSupplierBillDiff = async (guid: string): Promise<string> => {
  const res = await request.post(`${API.API_HOST}`, {
    guid: guid,
    bffAction: 'css.call.bill.reloadBillDiff',
  });
  return res?.data as unknown as string;
};
// 供应商下拉框
export const reqSupplierOptions = async (): Promise<
  SupplierOptionsDataType[]
> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.call.bill.querySupplierList',
  });
  console.log('供应商列表:', res.data);
  return res?.data as unknown as SupplierOptionsDataType[];
};
// 所有页合计
export const getAllPageTotal = async (
  params: DownLoadListType,
): Promise<allPageTotalType> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.bill.queryDiffSummary',
  });
  return res?.data as unknown as allPageTotalType;
};
