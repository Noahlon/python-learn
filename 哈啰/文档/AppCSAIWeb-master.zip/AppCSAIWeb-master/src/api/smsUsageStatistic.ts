import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

/**
 * 用量统计interface
 */
export interface IsDosageParams {
  templateName?: string;
  tenantIds?: number[];
  smsProviderTypes?: number[];
  channelName?: string;
  startDate?: string;
  endDate?: string;
  pageNum?: number;
  pageSize?: number;
}

export interface SmsUsageObj {
  billingNum?: number;
  billingPrice?: number;
  billingTotal?: number;
  tenantName?: string;
  dateDesc?: string;
  templateName?: string;
  smsProviderName?: string;
  channelName?: string;
  todaySmsTotalNum?: number;
  sendSuccessTotalNum?: number;
  sendSuccessTotalRate?: number;
  sendFailTotalNum?: number;
  sendFailTotalRate?: number;
  sendUnKnownTotalNum?: number;
  sendUnKnownTotalRate?: number;
}

export interface SmsUsageRes extends ICommonResponse {
  data: {
    pageNum: number;
    pageSize: number;
    totalRecord: number;
    totalPages: number;
    list: SmsUsageObj[];
  };
}

/**
 * 用量统计-总量interface
 */
export interface SmsUsageTotalRes extends ICommonResponse {
  data: SmsUsageObj;
}

/**
 * 用量统计导出interface
 */
interface DosageExportParams {
  templateName?: string;
  tenantIds?: number[];
  smsProviderType?: number[];
  channelName?: string;
  startDate?: string;
  endDate?: string;
}

interface dosageExportRes extends ICommonResponse {
  data: {
    ossUrl: string;
  };
}

// 用量统计
export const queryDosageList = async (
  params: IsDosageParams,
): Promise<SmsUsageRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.sms.dosage.list',
  });
  return res;
};

// 用量统计-总计
export const queryDosageTotal = async (
  params: IsDosageParams,
): Promise<SmsUsageTotalRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.sms.dosage.total',
  });
  return res;
};

// 导出
export const exportDosageList = async (
  params: DosageExportParams,
): Promise<dosageExportRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.sms.dosage.export',
  });
  return res;
};
