import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface IVariableInfo {
  variableCode?: string;
  variableName?: string;
  variableType?: number;
}

export interface ITemplateContentDetails {
  order?: number;
  type?: number;
  contentText?: string;
  variableInfo?: IVariableInfo;
}

/**
 * 查询短信模板interface
 */
export interface SmsTemplateParams {
  templateName?: string;
  tenantList?: string[] | number[];
  signature?: string;
  pageNum: number;
  pageSize: number;
  bpoVersion?: number;
}

export interface SmsTemplateObj {
  templateName?: string;
  tenant?: string;
  signature?: string;
  variableNum?: number;
  id?: string;
  content?: string;
  creatorName?: string;
  createTime?: string;
  carrierType?: number[];
  supplierNameList?: string[];
  templateContentDetails?: ITemplateContentDetails[];
  linkType?: number;
  link?: string;
  chainId?: string;
  chain?: string;
  areaLimitDisplay?: {
    cities: string[];
    province: string[];
  }[];
  channelWithSms?: boolean;
  unicomBillingUnitPrice?: number;
  mobileBillingUnitPrice?: number;
  telecomBillingUnitPrice?: number;
  otherBillingUnitPrice?: number;
}

export interface SmsTemplateRes extends ICommonResponse {
  data: {
    pageNum: number;
    pageSize: number;
    totalRecord: number;
    totalPages: number;
    list: SmsTemplateObj[];
  };
}

/**
 * 创建和编辑短信模板interface
 */
export interface CreateUpdateTemplateParams {
  templateName: string;
  tenant: string | number;
  signature?: string;
  templateContent: string;
  id: string;
  content: string;
  variableNum: number;
  templateContentDetails: ITemplateContentDetails[];
  chainId?: string;
  link?: string;
  linkType?: string | number;
  unicomBillingUnitPrice: number;
  mobileBillingUnitPrice: number;
  telecomBillingUnitPrice: number;
  otherBillingUnitPrice: number;
  variableCode?: string;
}

/**
 * 测试发送短信interface
 */
export interface TestSmsParams {
  templateId: string;
  phoneNumber: string;
  variableMap?: {
    [prop: string]: {
      value: string;
      hsCode?: string;
    };
  };
}

/**
 * 查询火山消息组下的模板信息interface
 */
export interface QueryTemplateByAccountObj {
  name: string;
  templateId: string;
  content: string;
}

export interface QueryTemplateByAccountRes extends ICommonResponse {
  data: QueryTemplateByAccountObj[];
}

/**
 * 查询通道interface
 */
interface IAreaLimitDisplay {
  province?: string;
  cities?: string[];
}

export interface ITemplateChannels {
  templateChannelId?: string;
  channelId?: string;
  supplierTemplateId?: string;
  supplierType?: number;
  priority?: number;
  channelName?: string;
  carrierType?: number[];
  price?: number;
  areaLimitCityCount?: number;
  areaLimitProvinceCount?: number;
  areaLimitDisplay?: IAreaLimitDisplay[];
  signature?: string;
  content?: string;
  channelContentDetails?: ITemplateContentDetails[];
  linkType?: number;
  link?: string;
  chainId?: string;
  chain?: string;
  chainName?: string;
  variableInfos?: IVariableInfo[];
}

interface ITemplateChannelsObj {
  templateId?: string;
  templateName?: string;
  templateChannels?: ITemplateChannels[];
}

export interface QueryTemplateChannelRes extends ICommonResponse {
  data: ITemplateChannelsObj[];
}

/**
 * 添加通道interface
 */
export interface CreateTemplateChannelParams {
  templateId?: string;
  channelId: string;
  supplierTemplateId?: string;
  signature?: string;
  content?: string;
  channelContentDetails?: ITemplateContentDetails[];
  chainId?: string;
  link?: string;
  linkType?: string | number;
  variableInfos?: IVariableInfo[];
}

export interface CreateTemplateChannelRes extends ICommonResponse {
  data?: string;
}

/**
 * 编辑通道interface
 */
export interface UpdateTemplateChannelParams {
  templateChannelId: string;
  channelId: string;
  supplierType: number;
  supplierTemplateId?: string;
  signature?: string;
  content?: string;
  channelContentDetails?: ITemplateContentDetails[];
  chainId?: string;
  link?: string;
  linkType?: string | number;
  variableInfos?: IVariableInfo[];
}

/**
 * 通道位置调整interface
 */
export interface SortChannelParams {
  templateId: string;
  moveTemplateChannelId: string;
  targetTemplateChannelId: string;
  moveType: 0 | 1;
}

/**
 * 查询短信模板变量interface
 */
export interface QueryTemplateVariableObj extends IVariableInfo {
  id?: string;
}

export interface QueryTemplateVariableRes extends ICommonResponse {
  data: QueryTemplateVariableObj[];
}

/**
 * 添加短信模板变量interface
 */
export interface CreateTemplateVariableParams {
  templateId?: string;
  variableInfo: IVariableInfo;
}

export interface CreateTemplateVariableRes extends ICommonResponse {
  data?: string;
}

/**
 * 短信模版获取短链interface
 */
export interface SmsChainQueryRes extends ICommonResponse {
  data: {
    tenant: string;
    chain: string;
    chainName: string;
    chainId: string;
  }[];
}

/**
 * 链接类型interface
 */
export interface SmsLinkTypeRes extends ICommonResponse {
  data: {
    code: number;
    name: string;
  }[];
}

//----------------------------------------------------

// 查询短信模版
export const querySmsTemplate = async (
  params: SmsTemplateParams,
): Promise<SmsTemplateRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.queryTemplate',
    ...params,
  });
  return res;
};

// 创建短信模板
export const createSmsTemplate = async (
  params: CreateUpdateTemplateParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.createTemplate',
    ...params,
  });
  return res;
};

// 编辑短信模板
export const updateSmsTemplate = async (
  params: CreateUpdateTemplateParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.updateTemplate',
    ...params,
  });
  return res;
};

// 测试发送短信
export const testSendSms = async (
  params: TestSmsParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.sms.test',
    ...params,
  });
  return res;
};

// 删除短信模板
export const deleteSmsTemplate = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.deleteTemplate',
    ...params,
  });
  return res;
};

// 查询火山消息组下的模板信息
export const querySmsTemplateByAccount = async (params: {
  subAccount: string;
}): Promise<QueryTemplateByAccountRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.channel.queryHSTemplate',
    ...params,
  });
  return res;
};

// 查询通道
export const queryTemplateChannel = async (params?: {
  templateId?: string;
  templateStatus?: 0 | 1;
}): Promise<QueryTemplateChannelRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.queryChannel',
    ...params,
  });
  return res;
};

// 查询通道（包含模版已删除的）
export const queryTemplateStaticsChannel =
  async (): Promise<QueryTemplateChannelRes> => {
    const res = await request.post(`${API.API_HOST}`, {
      bffAction: 'sms.template.staticsChannel',
    });
    return res;
  };

// 添加通道
export const createTemplateChannel = async (
  params: CreateTemplateChannelParams,
): Promise<CreateTemplateChannelRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.addTemplateChannel',
    ...params,
  });
  return res;
};

// 编辑通道
export const updateTemplateChannel = async (
  params: UpdateTemplateChannelParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.updateChannel',
    ...params,
  });
  return res;
};

// 通道位置调整
export const sortTemplateChannel = async (
  params: SortChannelParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.sortChannel',
    ...params,
  });
  return res;
};

// 删除通道
export const deleteSmsTemplateChannel = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.deleteChannel',
    ...params,
  });
  return res;
};

// 查询短信模板变量
export const queryTemplateVariable = async (params: {
  templateId: string;
  variableType?: number;
}): Promise<QueryTemplateVariableRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.queryVariable',
    ...params,
  });
  return res;
};

// 添加短信模板变量
export const createTemplateVariable = async (
  params: CreateTemplateVariableParams,
): Promise<CreateTemplateVariableRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.createVariable',
    ...params,
  });
  return res;
};

// 删除短信模板变量
export const deleteTemplateVariable = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.deleteVariable',
    ...params,
  });
  return res;
};

// 原始/短链枚举查询
export const smsLinkTypeEnum = async (): Promise<SmsLinkTypeRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.linkTypeEnum',
  });
  return res;
};

// 短链-新增查询短链接口
export const smsChainQueryList = async (params: {
  tenant: string;
}): Promise<SmsChainQueryRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.chain.queryList',
    ...params,
  });
  return res;
};

// 复制短信模板
export const copySmsTemplate = async (params: {
  copySmsTemplateId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.copySmsTemplate',
    ...params,
  });
  return res;
};

//粘贴替换短信通道
export const pasteSmsChannel = async (params: {
  copySmsTemplateId: string;
  pasteSmsTemplateId?: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.template.pasteSmsChannel',
    ...params,
  });
  return res;
};
