import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

interface ISmsRecordListP {
  speechName: string;
  signature: string;
  sendResult: number;
  createTime: any;
  createTimeStart: string;
  createTimeEnd: string;
  commitTime: any;
  commitTimeStart: string;
  commitTimeEnd: string;
  smsChannelName: string;
  routeResult: number;
  recordType: number;
  smsProviderType: number;
  cityList: string[];
  sessionId: string;
  commitResult: number;
  phoneNumber: number;
  tenantId: string[];
  taskName: string;
  pageSize: number;
  pageNum: number;
  projectName: string;
  smsSourceList: string[];
  projectTaskTypeList: string[];
  skillGroupName: string;
  seatName: string;
}

interface UpWardSmsRecord {
  createTime: any;
  phoneNumber?: string;
  tenantId?: string;
  replySendStartTime?: string;
  replySendEndTime?: string;
  replyContent?: string;
  smsProvider?: string;
  pageSize?: number;
  pageNum?: number;
}
export type UpWardSmsRecordParams = Partial<UpWardSmsRecord>;

export type ISmsRecordListParams = Partial<ISmsRecordListP>;

export interface UpWardSmsRecordList {
  id?: string;
  phoneNumber?: string;
  tenantIdList?: string[];
  tenantName?: string;
  smsProvider?: string;
  replySendTime?: string;
  content?: string;
  replyContent?: string;
  createTime?: string;
  sessionId?: string;
}

export interface ISmsRecord {
  speechName: string;
  signature: string;
  sendResult: string;
  sessionId: string;
  commitResult: string;
  phoneNumber: string;
  tenantName: string;
  createTime: string;
  smsProvider: string;
  guid: string;
  taskName: string;
  provinceAndCity: string;
  messageContent: string;
  projectName: string;
  projectGuid: string;
  smsSource: string;
  smsSourceDesc: string;
  skillGroupName: string;
  seatName: string;
  carrierDesc: string;
  carrierType: number;
}

export interface ISmsRecordListRes extends ICommonResponse {
  data: {
    list: Partial<ISmsRecord>[];
    pageNum: number;
    pageSize: number;
    totalPages: number;
    totalRecord: number;
  };
}

export interface UpWardSmsRecordListRes extends ICommonResponse {
  data: {
    list: Partial<UpWardSmsRecordList>[];
    pageNum: number;
    pageSize: number;
    totalPages: number;
    totalRecord: number;
  };
}

// 短信记录列表
export const getSmsRecordList = async (
  params: ISmsRecordListParams,
): Promise<ISmsRecordListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.sms.recordList',
  });
  return res;
};

// 短信上行记录列表
export const getUpwardSmsRecordList = async (
  params: UpWardSmsRecordParams,
): Promise<UpWardSmsRecordListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.sms.reply.recordList',
  });
  return res;
};

// 短信上行记录导出
export const exportUpwardSmsRecord = async (
  params: UpWardSmsRecordParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.sms.reply.recordList.export',
  });
  return res;
};

// 短信下行记录导出
export const exportRecordList = async (
  params: ISmsRecordListParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.sms.recordList.export',
  });
  return res;
};
