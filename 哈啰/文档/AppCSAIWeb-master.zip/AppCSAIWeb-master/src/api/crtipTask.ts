import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface businessCtripTaskDownloadRes extends ICommonResponse {
  data?: string;
}

export interface businessCtripTaskListReq {
  pageNum?: number;
  pageSize?: number;
  taskId?: number;
  startTime?: string;
  endTime?: string;
  taskState?: number;
}

export interface businessCtripTaskListRes extends ICommonResponse {
  data?: ctripTaskListData;
}

export interface ctripTaskListData {
  pageNum?: number;
  pageSize?: number;
  totalPages?: number;
  totalRecord?: number;
  list?: ctripTaskList[];
}

export interface ctripTaskList {
  id?: string;
  uploadQty?: number;
  returnQty?: number;
  callQty?: number;
  noCallQty?: number;
  uploadUser?: string;
  createTimeStr?: string;
  taskState?: number;
  taskStateStr?: string;
}

export interface businessCtripExportRes extends ICommonResponse {
  data: string;
}

// 携程撞库任务   导入名单
export const businessCtripTaskUpload = async (params: {
  uploadFileUrls: string[];
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'business.ctripTask.upload',
  });
  return res;
};

// 携程撞库任务   下载导入名单
export const businessCtripTaskDownload = async (params: {
  taskId: string;
}): Promise<businessCtripTaskDownloadRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'business.ctripTask.download',
  });
  return res;
};

// 携程撞库   任务列表
export const businessCtripTaskList = async (
  params: businessCtripTaskListReq,
): Promise<businessCtripTaskListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'business.ctripTask.list',
  });
  return res;
};

// 携程撞库 任务下载完成名单
export const businessCtripExport = async (params: {
  taskId: string;
}): Promise<businessCtripExportRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'business.ctripTask.export',
  });
  return res;
};
