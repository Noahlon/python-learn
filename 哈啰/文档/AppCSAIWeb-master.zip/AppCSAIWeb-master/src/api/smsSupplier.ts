import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

/**
 * 查询短信供应商信息interface
 */
export interface SmsSupplierParams {
  supplierName?: string;
  pageSize: number;
  pageNum: number;
}

export interface SmsSupplierObj {
  supplierName: string;
  contactName: string;
  contactPhone?: string;
  contactEmail?: string;
  remark?: string;
  channelSize: number;
  creatorName: string;
  createTime: string;
  id: string;
  supplierType: number;
}

export interface SmsSupplierRes extends ICommonResponse {
  data: {
    pageNum: number;
    pageSize: number;
    totalRecord: number;
    totalPages: number;
    list: SmsSupplierObj[];
  };
}

/**
 * 创建短信供应商interface
 */
export interface CreateSmsSupplierParams {
  supplierName: string;
  contactName: string;
  contactPhone?: string;
  contactEmail?: string;
  supplierType: number;
  remark?: string;
}

/**
 * 编辑短信供应商信息interface
 */
export interface UpdateSmsSupplierParams {
  supplierName: string;
  contactName: string;
  contactPhone?: string;
  contactEmail?: string;
  remark?: string;
  id: string;
}

/**
 * 查询短信通道interface
 */
interface ISmsChannelLimit {
  frequencyCount?: number;
  timePeriod?: number;
  timeUnit?: string;
}

export interface ISmsChannelObj {
  channelName?: string;
  price?: number;
  carrierType?: number[];
  ruleLimit?: ISmsChannelLimit[];
  areaLimit?: string;
  concurrentLimit?: number;
  creatorName?: string;
  createTime?: string;
  id?: string;
  supplierType?: number;
  subAccount?: string;
  remark?: string;
  associateTemplate?: string[];
  areaLimitDisplay?: { province: string; cities: string[] }[];
  areaLimitCityCount?: number;
  areaLimitProvinceCount?: number;
  account?: string;
  password?: string;
}

export interface SmsChannelObj {
  supplierName: string;
  supplierType: string;
  channelList: ISmsChannelObj[];
}

export interface SmsChannelRes extends ICommonResponse {
  data: SmsChannelObj[];
}

/**
 * 查询火山消息组信息interface
 */
interface SmsSubAccountObj {
  subAccountName: string;
  subAccountId: string;
}

export interface SmsSubAccountRes extends ICommonResponse {
  data: SmsSubAccountObj[];
}

/**
 * 创建短信通道interface
 */

interface IChanneRuleLimit {
  frequencyCount?: number;
  timePeriod?: number;
  timeUnit?: string;
}

export interface IChanneAreaLimit {
  label?: string;
  value?: string;
  child?: {
    label?: string;
    value?: string;
  }[];
}

export interface CreateSmsChannelParams {
  channelName: string;
  price: number;
  carrierType: number[];
  concurrentLimit?: number;
  ruleLimit?: IChanneRuleLimit[];
  areaLimit?: IChanneAreaLimit[];
  remark?: string;
  subAccount?: string;
  supplierType: number;
  account?: string;
  password?: string;
}

export interface UpdateSmsChannelParams extends CreateSmsChannelParams {
  id: string;
}

/**
 * 查询供应商额外信息
 */
export interface SupplierExtInfoRes extends ICommonResponse {
  data: {
    id: string;
    supplierName: string;
    supplierType: number;
  }[];
}

// 查询短信供应商信息
export const querySmsSupplier = async (
  params: SmsSupplierParams,
): Promise<SmsSupplierRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.supplier.pageQuerySupplier',
    ...params,
  });
  return res;
};

// 创建短信供应商
export const createSmsSupplier = async (
  params: CreateSmsSupplierParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.supplier.createSupplier',
    ...params,
  });
  return res;
};

// 编辑短信供应商信息
export const updateSmsSupplier = async (
  params: UpdateSmsSupplierParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.supplier.updateSupplier',
    ...params,
  });
  return res;
};

// 删除短信供应商信息
export const deleteSmsSupplier = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.supplier.deleteSupplier',
    ...params,
  });
  return res;
};

// 查询短信通道
export const querySmsChannel = async (params?: {
  supplierType: number;
}): Promise<SmsChannelRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.channel.queryChannel',
    ...params,
  });
  return res;
};

// 查询火山消息组信息
export const querySmsSubAccount = async (): Promise<SmsSubAccountRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.channel.querySubAccount',
  });
  return res;
};

// 创建短信通道
export const createSmsChannel = async (
  params: CreateSmsChannelParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.channel.createChannel',
    ...params,
  });
  return res;
};

// 更新短信通道
export const updateSmsChannel = async (
  params: UpdateSmsChannelParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.channel.updateChannel',
    ...params,
  });
  return res;
};

// 删除短信通道
export const deleteSmsChannel = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.channel.deleteChannel',
    ...params,
  });
  return res;
};

// 查询供应商额外信息
export const querySupplierExtInfo = async (): Promise<SupplierExtInfoRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'sms.querySupplierExtInfo',
  });
  return res;
};
