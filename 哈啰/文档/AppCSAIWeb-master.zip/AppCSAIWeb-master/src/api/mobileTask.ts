import request from '@/utils/request';
// import API from '@/config/env';
import API from '@/config/env';
import { ICommonResponse } from './baseInterface';

export interface defaultData {
  orgChannel?: string;
}

export interface businessMobileTaskDownloadRes extends ICommonResponse {
  data?: string;
}

export interface businessMobileListReq {
  taskId?:string;
	taskName?:string;
	startTime:string;
	endTime:string;
	taskStatus?:number;
	orgChannel:string;
	pageNum:number;
	pageSize:number;
}

export type MoboleListParams = Partial<businessMobileListReq>;

export interface mobileTaskList {
  id: string;
	taskName: string;
	orgChannel: string;
	orgModel: string;
	uploadQty: string;
	returnQty: string;
	canCallQty: number;
	canotCallQty: string;
	uploadUser: string;
	createTime: string;
	taskStatus: string;
}

export interface mobileTaskListData {
  pageNum?: number;
  pageSize?: number;
  totalPages?: number;
  totalRecord?: number;
  list?: mobileTaskList[];
}

export interface businessMobileTaskListRes extends ICommonResponse {
  data?: mobileTaskListData;
}

export interface businessMobileExportRes extends ICommonResponse {
  data: string;
}
// 移动撞库渠道
export const queryChannel = async (): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'business.channelTask.getChannel',
  });
  return res;
};
// 数据模型
export const queryModel = async (params: {
  channelKey: string
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'business.channelTask.queryModel',
  });
  return res;
};
// 渠道撞库任务导入名单
export const businessMobileTaskUpload = async (params: {
  orgChannel:string;
	taskName:string;
	orgModel:string;
  uploadFile: string[];
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'business.channelTask.importTask',
  });
  return res;
};

// 渠道撞库任务下载导入名单
export const businessMobileTaskDownload = async (params: {
  taskId: string;
}): Promise<businessMobileTaskDownloadRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'business.channelTask.download',
  });
  return res;
};

// 渠道撞库任务列表
export const businessCtripTaskList = async (
  params: MoboleListParams,
): Promise<businessMobileTaskListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'business.channelTask.pageList',
  });
  return res;
};

// 渠道撞库任务下载完成名单
export const businessMobileExport = async (params: {
  taskId: string;
}): Promise<businessMobileExportRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'business.channelTask.export',
  });
  return res;
};
