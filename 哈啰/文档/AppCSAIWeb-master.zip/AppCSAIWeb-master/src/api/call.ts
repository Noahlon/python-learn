import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse, IResponse } from './baseInterface';

export interface ICallList {
  guid?: string;
  recordFile?: string;
  contactType?: number;
  calloutResultDesc?: string;
  startCreateTime?: string;
  carrier?: string;
  speechName?: string;
  callingNumber?: string;
  calledNumber?: string;
  tenant?: string;
  releaseInitiator?: number;
  realCallingNumber?: string;
  hangupTime?: string;
  answerTime?: string;
  durationRing?: string;
  durationCall?: number;
  dialTime?: string;
  calloutResult?: number;
  intentClassify?: string;
  tags?: string;
  userSpeakCount?: string;
  speechCount?: string;
  recognizedIntentList?: string[];
  province?: string;
  city?: string;
  hitSms?: number;
  isComplaint: boolean;
  bizReqId?: string;
  sessionId?: string;
}

export interface ICallListRes {
  code?: number;
  msg: string;
  success: boolean;
  data: {
    list: ICallList[];
    pageNum: number;
    pageSize: number;
    totalPages: number;
    totalRecord: number;
    tenantBilling: number;
  };
}

export interface ICallListReq {
  taskName?: string;
  startCreateTime?: string;
  endCreateTime?: string;
  carrier?: string;
  speechName?: string;
  startDurationWait?: number;
  endDurationWait?: number;
  callingNumber?: string;
  calledNumber?: string;
  realCallingNumber?: string;
  tenant?: string;
  releaseInitiator?: number;
  startHangupTime?: string;
  endHangupTime?: string;
  startAnswerTime?: string;
  endAnswerTime?: string;
  startDurationRing?: number;
  endDurationRing?: number;
  startDurationCall?: number;
  endDurationCall?: number;
  startDialTime?: string;
  endDialTime?: string;
  calloutResult?: number;
  intentClassifyList?: string[];
  tags?: string;
  tagsList?: string[];
  userSpeakCount?: number;
  speechCount?: number;
  recognizedIntentList?: string[];
  citys?: string[];
  hitSms?: number;
}

export interface IIntention {
  intention: string;
  score: number;
  intentionColleciton: string;
  isHit: boolean;
  intentionObtainType?: number;
  hitPhrases?: string[];
  translateHitPhrases?: string[];
  version?: string;
}

interface ICorrectionInfo {
  asrIssues?: string; //ASR识别不准具体问题描述
  missingCorpus?: string; //缺少语料具体问题描述
  intentIssues?: string; //意图识别问题
  intentIssuesList?: number[]; //意图识别问题id IntentIssuesEnum枚举key
  otherDescription?: string; //其他问题描述
}

export interface ICallMsg {
  speaker: number;
  speakId?: string;
  speakContent?: string;
  translateSpeakContent?: string;
  speakTime: string;
  userIntentions?: IIntention[];
  breakType?: number;
  isUnifiedAnswer: boolean;
  corpusSourceDesc?: string;
  corpusName?: string;
  segments?: string[];
  translateSegments?: string[];
  isTriggerTransfer?: boolean;
  splitAudioUrl?: string;
  playTime?: number;
  hitCoreNodeName?: string;
  hitCorePhrases?: string[];
  correctionInfo?: ICorrectionInfo;
  sentRecogResultList?: ISentRecogResultList[];
  intentDetectionInfoList?: IIntentDetectionInfoList[];
  jumpTypeDesc: string;
  jumpType: string;
}
interface hitIntentionPropertySet {
  propertyName: string;
  propertyType: number;
}
export interface ISentRecogResultList {
  intentDetectionType?: string;
  intentDetectionTypeName?: string;
  hitIntentSetName?: string;
  hitIntent?: string;
  hitInfo?: string;
}

export interface IIntentDetectionInfoList {
  intentDetectionType?: string;
  intentDetectionTypeName?: string;
  hitIntentSetName?: string;
  hitIntent?: string;
  intentAttributes?: number;
  intentAttributesDesc?: string;
  hitInfo?: string;
  isMatchedCorpus?: boolean;
  corpusName?: string;
  corpusPriority?: string;
  corpusId?: string;
  corpusSource?: string;
  corpusSourceName?: string;
  isInReplyScope?: boolean;
  hasRemainingPlayCount?: boolean;
  isReplyCorpus?: boolean;
  keySort?: number;
}
export interface ICallDialogue {
  guid: string;
  createTime?: string;
  speechName?: string;
  callingNumber?: string;
  calledNumber?: string;
  bizScene?: string;
  bizReqId?: string;
  recordFile?: string;
  releaseInitiator?: number;
  contactType?: number;
  hangupTime?: string;
  answerTime?: string;
  dialTime?: string;
  durationRing?: number;
  durationCall?: number;
  calloutResult?: number;
  carrier?: string;
  province?: string;
  city?: string;
  outConversationId?: string;
  tags?: string;
  userSpeakCount?: number;
  speechCount?: number;
  recognizedIntent?: string;
  hitIntentionPropertySet?: hitIntentionPropertySet[];
  intentClassify?: string;
  isComplaint?: boolean;
  transferTime?: string;
  taskName?: string;
  asrServer?: string;
  intentionObtainType?: number;
  intentClassifyDesc?: string;
  suppliersLineName?: string;
  realCallingNumber?: string;
  suppliersName?: string;
  intentClassifyName?: string;
  skillGroupName?: string;
  seatName?: string;
  signalCode?: string;
  signalDesc?: string;
  isTriggerTransfer?: boolean;
  correctionMarkType?: number[];
  correctionInfo?: {
    gender?: string;
    accuracy?: string;
    remark?: string;
    accuracyReasonList?: string[];
  };
  ttsServerName?: string;
  ttsCodeName?: string;
  intentionClassification?:string;
  intentionClassificationDesc?:string;
  userCharacteristicLabel?:string;
  ruleIntentionClassify?:string
  modelIntentionClassify?:string
  inferenceReson?:string;
  intentionTrend?:string;
}

interface IRearAsrInfos {
  asrInput?: string;
  asrRearTime?: string;
  asrType?: number;
  asrTypeDesc?: string;
  intentionClassification?: string;
  intentionClassificationDesc?: string;
  sentRecogResultList?: ISentRecogResultList[];
  intentDetectionInfoList?: IIntentDetectionInfoList[];
}

export interface ICallDetail {
  callDialogueResDTO?: ICallDialogue;
  speakContents?: ICallMsg[];
  hitAdvancedRules?: string[];
  rearAsrInfoList?: IRearAsrInfos[];
  hitIntentionPropertySet?: hitIntentionPropertySet[];
  modelIdentificationInformation?:any
}

export interface ICallDetailRes extends IResponse {
  data: ICallDetail;
}

export interface ICallResultO {
  status: number;
  desc: string;
  complaintDesc?: string;
}

export interface ICallResult {
  value: number;
  label: string;
}

interface ICallResultRes extends IResponse {
  data: ICallResultO[];
}

export interface ruleTypeRes {
  featureRuleType: string;
  featureRuleTypeName: string;
}

interface IRuleTypeRes extends ICommonResponse {
  data: ruleTypeRes[];
}

// 获取通话记录列表
export const getCallList = async (
  params: ICallListReq,
): Promise<ICallListRes> => {
  const res = await request.post<ICallListRes, ICallListRes>(
    `${API.API_HOST}`,
    {
      ...params,
      bffAction: 'css.callCenter.query.call',
    },
  );
  return res;
};

// 获取通话详情
export const getCallDetail = async (params: {
  dialogueGuid: string;
  createTime?: string;
}): Promise<ICallDetailRes> => {
  const res = await request.post<ICallDetailRes, ICallDetailRes>(
    `${API.API_HOST}`,
    {
      ...params,
      bffAction: 'css.callCenter.query.callDetail',
    },
  );
  return res;
};

// 获取通话结果
export const getCallResultList = async (): Promise<ICallResultRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.callout.result.list',
  });
  return res;
};

export interface AddComplaintParams {
  dialogueGuid: string;
  isComplaint: boolean;
  calledNumber: string;
  groupIdList?: string[];
}

// 更改标记
export const addComplaint = async (
  params: AddComplaintParams,
): Promise<ICallResultRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.callCenter.addComplaint',
  });
  return res;
};

//
export const getRuleType = async (): Promise<IRuleTypeRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'css.feature.rule.type',
  });
  return res;
};

export interface ComplainBlaGroupRes extends ICommonResponse {
  data: {
    blacklistGroupId: string;
    blacklistGroupName: string;
  }[];
}

// 查询话单标记的黑名单组
export const getComplainBlaGroup = async (params: {
  sessionId: string;
}): Promise<ComplainBlaGroupRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.call.query.complainBlaGroup',
  });
  return res;
};

// 导出
export const exportCallList = async (
  params: ICallListReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.callCenter.export.call',
  });
  return res;
};

// 三方黑名单供应商列表接口
export const blackListSupplierList = async (): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'cc.common.blackListSupplierList',
  });
  return res;
};
interface ICorrection {
  gender: string;
  accuracy: string;
  remark?: string;
  accuracyReasonList?: string[];
  sessionId: string;
}

// 话单纠错
export const correction = async (
  params: ICorrection,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.dialogue.correction',
  });
  return res;
};

interface IPhraseCorrection {
  speakId: string; //回复轮次对话唯一id
  asrIssues?: string; //ASR识别不准具体问题描述
  missingCorpus?: string; //缺少语料具体问题描述
  intentIssues?: string; //意图识别问题
  intentIssuesList?: number[]; //意图识别问题id IntentIssuesEnum枚举key
  otherDescription?: string; //其他问题描述
  sessionId: string; //话单sessionId
}

// 单句纠错
export const phraseCorrection = async (
  params: IPhraseCorrection,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'css.phrase.correction',
  });
  return res;
};
