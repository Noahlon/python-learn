import request from '@/utils/request';
import API from '@/config/env';
import { ICommonResponse, ICommonResponseList } from './baseInterface';

// 模型列表interface
export interface ModelListParams {
  pageSize: number;
  pageNum: number;
  modelName?: string;
  bizId?: number;
  level?: number;
  modelStatus?: string[];
  sort?: number;
  sortParam?: string;
  sortAsc?: number;
  endCreateTime?: string;
}

export interface ModelTrainObj {
  modelId?: string;
  modelName?: string;
  modelAlgorithmId?: string;
  levelOneBizId?: string;
  levelOneBizName?: string;
  levelTwoBizId?: string;
  levelTwoBizName?: string;
  bizSceneId?: string;
  bizSceneName?: string;
  modelVersion?: string;
  modelStatus?: string;
  modelTestResult?: string;
  intentionCount?: number;
  knowledgeCount?: number;
  trainingTime?: string;
  verifyTime?: string;
  modelRemark?: string;
  createTime?: string;
}

type ModelListRes = ICommonResponseList<ModelTrainObj>;

// 新增模型interface
export interface SaveModelParams {
  modelName: string;
  levelOneBizId: string;
  levelOneBizName?: string;
  levelTwoBizId: string;
  levelTwoBizName?: string;
  bizSceneId: string;
  bizSceneName?: string;
  modelUrl: string;
  modelRemark?: string;
}

// 编辑模型interface
export interface UpdateModelParams {
  modelId: string;
  modelName: string;
  modelRemark?: string;
}

// 提交验证-回显详情interface
export interface VerifyDetail {
  submitIntentionCount?: number;
  modelIntentionCount?: number;
  intentionOverRate?: string;
  knowledgeCount?: number;
}

export interface VerifyDetailRes extends ICommonResponse {
  data: VerifyDetail;
}

// 提交验证-列表interface
export interface VerifyListParams {
  pageSize: number;
  pageNum: number;
  name?: string;
  modelId: string;
}

export interface VerifyListObj {
  id?: string;
  knowledgeDesc?: string;
  knowledgeName?: string;
  errorDesc?: string;
}

type VerifyListRes = ICommonResponseList<VerifyListObj>;

// 验证结果-回显详情interface
export interface ResultDetailParams {
  modelId: string;
  modelStatus?: string;
}

export interface ResultDetailObj {
  intentionOverRate?: string;
  identifyRate?: string;
  knowledgeCount?: number;
}

export interface ResultDetailRes extends ICommonResponse {
  data: ResultDetailObj;
}

// 验证结果-列表interface

export interface ResultListParams {
  pageSize: number;
  pageNum: number;
  name?: string;
  verifyResult?: number;
  modelId: string;
}

export interface ResultListObj {
  id?: string;
  verifyKnowledge?: string;
  correctIntention?: string;
  identifyIntention?: string;
  identifyResult?: number;
}

type ResultListRes = ICommonResponseList<ResultListObj>;

export interface intentionCreateReq {
  name: string;
  modelId: string;
}

export interface modelDimQueryReq {
  content: string;
  modelId: string;
}

export interface modelDimQueryRes extends ICommonResponse {
  data?: modelDimQueryData[];
}

export interface modelDimQueryData {
  guid?: string;
  faqId?: string;
  name?: string;
  modelId?: string;
}

export interface modelDimEditReq {
  name: string;
  faqId: string;
  modelId: string;
}

export interface modelDimDeleteReq {
  faqId: string;
}

export interface modelKnowledgeUploadReq {
  modelId: string;
  ossUrl: string;
}

export interface modelKnowledgeUploadRes extends ICommonResponse {
  data?: {
    success: boolean;
    ossUrl: string;
  };
}

export interface modelKnowledgeDownloadReq {
  modelId: string;
}

export interface modelKnowledgeQuestionReq {
  pageSize: number;
  pageNum: number;
  faqId: string;
}

export interface modelKnowledgeQuestionRes extends ICommonResponse {
  pageNum?: number;
  pageSize?: number;
  totalRecord?: number;
  totalPages?: number;
  namelistNum?: number;
  list?: modelKnowledgeQuestionList[];
}
export interface modelKnowledgeQuestionList {
  guid?: string;
  faqId?: string;
  similarFaqName?: string;
}

export interface modelTrainExtendDistinctReq {
  extendFaqName: string;
  faqId: string;
  modelId: string;
}

export interface modelTrainExtendDistinctRes extends ICommonResponse {
  data?: {
    knowledgeList: string[];
    count: number;
    modelSaveKnowledgeDTOS: ImodelSaveKnowledge[];
  };
}
export interface ImodelSaveKnowledge {
  similarFaqName: string;
  errorDesc: string;
}

export interface modelTrainKnowledgeInsertReq {
  extendFaqName: string;
  faqId: string;
  modelId: string;
}

export interface modelTrainNameQueryReq {
  modelStatus: string;
  levelOneBizId?: string;
  levelTwoBizId?: string;
}

export interface modelTrainNameQueryRes extends ICommonResponse {
  data?: ImodelTrainNameQueryData[];
}

export interface ImodelTrainNameQueryData {
  modelId: string;
  modelName: string;
}

export interface intentionKnowledgeCollectionCreateReq {
  name: string;
  tenant?: number;
  speechGuid?: string;
  speechName?: string;
  description: string;
  bizId: string;
  modelId: string;
}

export interface intentionKnowledgeCollectionEditReq {
  guid: string;
  name?: string;
  speechName?: string;
  description?: string;
  modelId?: string;
}

// -------------------------------------------------------------------

// 模型列表
export const getModelTrainList = async (
  params: ModelListParams,
): Promise<ModelListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.list',
    ...params,
  });
  return res;
};

// 新增模型
export const saveModelTrain = async (
  params: SaveModelParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.save',
    ...params,
  });
  return res;
};

// 编辑模型
export const updateModelTrain = async (
  params: UpdateModelParams,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.update',
    ...params,
  });
  return res;
};

// 提交训练
export const commitModelTrain = async (params: {
  modelId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.commit',
    ...params,
  });
  return res;
};

// 废弃模型
export const discardModel = async (params: {
  modelId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.discard',
    ...params,
  });
  return res;
};

// 提交验证-批量导入
export const uploadModelVerify = async (params: {
  modelId: string;
  ossUrl: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.verify.upload',
    ...params,
  });
  return res;
};

// 提交验证-批量导出
export const downloadModelVerify = async (params: {
  modelId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.verify.download',
    ...params,
  });
  return res;
};

// 提交验证-回显详情
export const getVerifyDetail = async (params: {
  modelId: string;
}): Promise<VerifyDetailRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.verify.detail',
    ...params,
  });
  return res;
};

// 提交验证-列表
export const getVerifyList = async (
  params: VerifyListParams,
): Promise<VerifyListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.verify.listAll',
    ...params,
  });
  return res;
};

// 提交验证-清空
export const delAllVerify = async (params: {
  modelId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.verify.delAll',
    ...params,
  });
  return res;
};

// 提交验证-单个删除
export const delOneVerify = async (params: {
  id: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.verify.delOne',
    ...params,
  });
  return res;
};

// 提交验证-提交
export const submitModelVerify = async (params: {
  modelId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.verify.submit',
    ...params,
  });
  return res;
};

// 验证结果-回显详情
export const getTrainResultDetail = async (
  params: ResultDetailParams,
): Promise<ResultDetailRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.result.detail',
    ...params,
  });
  return res;
};

// 验证结果-列表
export const getTrainResultList = async (
  params: ResultListParams,
): Promise<ResultListRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.result.list',
    ...params,
  });
  return res;
};

// 验证结果-批量导出
export const downloadTrainResult = async (params: {
  modelId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    bffAction: 'model.train.result.download',
    ...params,
  });
  return res;
};

// 训练样本-新建意图
export const modelDimCreate = async (
  params: intentionCreateReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'model.train.intention.create',
  });
  return res;
};

// 训练样本-意图 模糊查询
export const modelDimQuery = async (
  params: modelDimQueryReq,
): Promise<modelDimQueryRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'model.train.intention.query',
  });
  return res;
};

// 训练样本-编辑意图名称
export const modelDimEdit = async (
  params: modelDimEditReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'model.train.intention.editName',
  });
  return res;
};
// 训练样本-删除意图
export const modelDimDelete = async (
  params: modelDimDeleteReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'model.train.knowledge.del',
  });
  return res;
};
// 训练样本-批量上传
export const modelKnowledgeUpload = async (
  params: modelKnowledgeUploadReq,
): Promise<modelKnowledgeUploadRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'model.train.knowledge.upload',
  });
  return res;
};

// 训练样本-批量导出
export const modelKnowledgeDownload = async (
  params: modelKnowledgeDownloadReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'model.train.knowledge.download',
  });
  return res;
};

// 训练样本-相似问 模糊查询（分页）
export const modelKnowledgeQuestion = async (
  params: modelKnowledgeQuestionReq,
): Promise<modelKnowledgeQuestionRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'model.train.knowledge.query',
  });
  return res;
};

// 训练样本-添加相似问
export const modelTrainExtendDistinct = async (
  params: modelTrainExtendDistinctReq,
): Promise<modelTrainExtendDistinctRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'model.train.extend.distinct',
  });
  return res;
};

// 训练样本-删除单个相似问
export const modelTrainDeleteFaq = async (params: {
  guid: string;
  modelId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'model.train.deleteFaq',
  });
  return res;
};

// 训练样本-清除全部相似问
export const modelTrainDeleteFaqAll = async (params: {
  faqId: string;
  modelId: string;
}): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'model.train.deleteFaqAll',
  });
  return res;
};

// 训练样本-确定保存相似问单个或批量
export const modelTrainKnowledgeInsert = async (
  params: modelTrainKnowledgeInsertReq,
): Promise<ICommonResponse> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'model.train.knowledge.insert',
  });
  return res;
};

// 训练样本-查询已验证完整模型 -- 模型列表枚举
export const modelTrainNameQuery = async (
  params: modelTrainNameQueryReq,
): Promise<modelTrainNameQueryRes> => {
  const res = await request.post(`${API.API_HOST}`, {
    ...params,
    bffAction: 'model.train.modelList',
  });
  return res;
};
