import HeaderRight from '@/components/Header';
import { Outlet } from '@umijs/max';
import React from 'react';

import styles from './index.less';

const Layouts = () => {
  return (
    <div className={styles.wrap}>
      <HeaderRight />
      <div className={styles.content}>
        <div className={styles.contentdiv}>
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default Layouts;
