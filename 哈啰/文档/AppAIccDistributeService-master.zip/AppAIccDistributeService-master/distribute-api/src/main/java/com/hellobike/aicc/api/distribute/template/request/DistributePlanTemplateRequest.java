package com.hellobike.aicc.api.distribute.template.request;

import com.hellobike.aicc.api.distribute.plan.dto.DistributeRule;
import com.hellobike.aicc.common.basic.LoginParam;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * @Author: hjj
 * @CreateTime: 2025-02-28
 * @Description: 新增计划模板对象
 * @Version: 1.0
 */
@Data
public class DistributePlanTemplateRequest extends LoginParam {

    /**
     * 模板id
     */
    private String templateId;
    /**
     * 模板名称
     */
    @NotBlank(message = "模版名称不能为空")
    @Size(min = 1, max = 200, message = "模版名称长度不合法")
    private String templateName;

    /**
     * 租户code
     */
    @NotBlank(message = "租户code不能为空")
    private String tenantCode;

    /**
     * 租户名称
     */
    @NotBlank(message = "租户名称不能为空")
    private String tenantName;

    /**
     * 分流类型
     * @see com.hellobike.aicc.common.enums.DistributeTypeEnum
     */
    private Integer distributeType;

    /**
     * 分流类型描述
     */
    private String distributeTypeDesc;

    /**
     * 分流规则
     */
    private List<DistributeRule> distributeRuleList;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private String createTime;

}
