package com.hellobike.aicc.api.file.request;

import com.hellobike.aicc.api.basic.PageParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  15:09:50
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class FileExportRecordRequest extends PageParam {

    /**
     * 文件类型 1-通话记录 2-短信记录
     */
    private Integer bizType;

    /**
     * 状态 1-执行中 2-执行成功 3-执行失败
     */
    private Integer status;

    /**
     * 操作时间开始
     */
    private String createTimeStart;

    /**
     * 操作时间结束
     */
    private String createTimeEnd;
}
