package com.hellobike.aicc.api.roster.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author zhangzhuoqi
 * @since 2025-03-18  11:33:55
 */
@Data
public class RosterRetryDistributeRequest {

    /**
     * 分流计划id
     */
    @NotBlank(message = "分流计划id不能为空")
    private String distributePlanId;

    /**
     * 上传记录id
     */
    @NotBlank(message = "上传记录id不能为空")
    private String uploadRecordId;
}
