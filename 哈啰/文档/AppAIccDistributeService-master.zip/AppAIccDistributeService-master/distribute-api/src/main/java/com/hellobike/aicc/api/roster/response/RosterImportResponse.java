package com.hellobike.aicc.api.roster.response;

import lombok.Data;

/**
 * @author zhangzhuoqi
 * @since 2025-03-20  14:05:40
 */
@Data
public class RosterImportResponse {

    /**
     * 重复数量
     */
    private Integer duplicationCount;

    /**
     * 成功数量
     */
    private Integer successCount;

    /**
     * 失败数量
     */
    private Integer failCount;
}
