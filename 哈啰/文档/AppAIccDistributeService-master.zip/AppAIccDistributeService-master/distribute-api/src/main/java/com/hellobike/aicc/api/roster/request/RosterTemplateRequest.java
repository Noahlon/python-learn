package com.hellobike.aicc.api.roster.request;

import com.hellobike.aicc.common.basic.LoginParam;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Getter
@Setter
public class RosterTemplateRequest extends LoginParam {

    /**
     * 文件类型，1-csv 2-xlsx
     */
    @NotNull(message = "文件类型不能为空")
    private Integer type;
}
