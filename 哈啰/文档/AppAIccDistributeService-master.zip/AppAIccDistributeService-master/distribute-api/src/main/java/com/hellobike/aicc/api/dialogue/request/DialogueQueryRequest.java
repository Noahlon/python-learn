package com.hellobike.aicc.api.dialogue.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-04-17  15:42:47
 */
@Data
public class DialogueQueryRequest {

    /**
     * 手机号集合
     */
    @NotEmpty
    private List<String> phoneList;

    /**
     * 分流计划id
     */
    @NotBlank
    private String distributePlanId;
}
