package com.hellobike.aicc.api.distribute.plan.dto;

import com.hellobike.aicc.common.basic.LoginParam;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.collections.CollectionUtils;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * @author fanxiaodongwb230
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ExternalDistributePlan extends LoginParam {
    /**
     * 分流计划id
     */
    private String id;

    /**
     * 分流计划模板id
     */
    private String distributePlanTemplateId;

    /**
     * 计划名称
     */
    private String distributePlanName;

    /**
     * 租户code
     */
    private String tenantCode;

    /**
     * 租户名称
     */
    private String tenantName;

    /**
     * 分流类型
     * DistributeTypeEnum
     */
    private Integer distributeType;

    /**
     * 分流类型描述
     */
    private String distributeTypeDesc;

    /**
     * 数据总量
     */
    private Long uploadDataNum;

    /**
     * 分流规则
     */
    private List<DistributeRule> distributeRuleList;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private String createTime;

    public boolean validate() {
        return CollectionUtils.isEmpty(distributeRuleList) || distributeRuleList.size() > 20;
    }
}
