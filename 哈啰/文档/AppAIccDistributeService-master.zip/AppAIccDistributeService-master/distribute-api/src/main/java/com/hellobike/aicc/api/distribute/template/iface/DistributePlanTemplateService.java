package com.hellobike.aicc.api.distribute.template.iface;


import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.distribute.template.request.CommonPlanTemplateRequest;
import com.hellobike.aicc.api.distribute.template.request.CopyTemplateResponse;
import com.hellobike.aicc.api.distribute.template.request.DistributePlanTemplateQueryRequest;
import com.hellobike.aicc.api.distribute.template.request.DistributePlanTemplateRequest;
import com.hellobike.aicc.api.distribute.template.response.DistributePlanTemplateResponse;
import com.hellobike.aicc.common.basic.PageResult;

import java.util.List;


/**
 * @Author: hjj
 * @CreateTime: 2025-02-28
 * @Description: 分流web层
 * @Version: 1.0
 */
public interface DistributePlanTemplateService {

    /**
     * 创建分流计划模板
     * @param request 分流计划模板对象
     * @return 分流计划模板ID
     */
    Result<String> createPlanTemplate(DistributePlanTemplateRequest request);

    /**
     * 编辑分流计划模板
     * @param request 分流计划模板对象
     * @return 分流计划模板ID
     */
    Result<String> editPlanTemplate(DistributePlanTemplateRequest request);

    /**
     * 删除分流计划模板
     * @param request
     * @return
     */
    public Result<String> deletePlanTemplate(CommonPlanTemplateRequest request);

    /**
     * 查询分流计划模板
     * @param request
     * @return
     */
    Result<PageResult<DistributePlanTemplateResponse>> queryPlanTemplate(DistributePlanTemplateQueryRequest request);


    /**
     * 查询全量分流模版list
     * @param request
     * @return
     */
    Result<List<DistributePlanTemplateResponse>> queryPlanTemplateList(CommonPlanTemplateRequest request);

    /**
     * 复制分流模版
     * @api plan.template.copy
     * @param request request
     * @return
     */
    Result<CopyTemplateResponse> copyTemplate(CommonPlanTemplateRequest request);

}
