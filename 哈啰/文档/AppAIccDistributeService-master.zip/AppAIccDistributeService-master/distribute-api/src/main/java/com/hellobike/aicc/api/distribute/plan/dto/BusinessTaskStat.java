package com.hellobike.aicc.api.distribute.plan.dto;

import lombok.Data;

import java.util.List;

/**
 * @author zhengchenyang
 * @date 2025/4/22
 * @desc 商业化后台 任务统计数据
 */

@Data
public class BusinessTaskStat {
    /**
     * 任务名称
     */
    private String taskName;

    /**
     * 任务id
     */
    private String taskId;

    /**
     * 上传总量
     */
    private Long uploadNum;

    /**
     * 已呼叫话单量
     */
    private Long callRosterNum;

    /**
     * 接通名单数
     */
    private Long throughRosterNum;

    /**
     * 接通话单量
     */
    private Long throughCallDialogueNum;

    /**
     * 语音计费数
     */
    private Long costUnit;

    /**
     * 名单接通率
     */
    private String throughRosterPercentage;

    /**
     * 创建时间
     */
    private String createTime;

    /**
     * 短信发送数量
     */
    private Long sendSmsSum;

    /**
     * 短信成功数量
     */
    private Long smsSuccSum;

    /**
     * 短信成功率
     */
    private String smsSuccRate;

    /**
     * 短信计费数
     */
    private Long smsUnit;

    /**
     * 意图分类总计
     */
    private List<IntentionClassify> intentClassifyList;

    /**
     * 转化漏斗总计
     */
    private List<ConversionFunnel> conversionFunnel;
}
