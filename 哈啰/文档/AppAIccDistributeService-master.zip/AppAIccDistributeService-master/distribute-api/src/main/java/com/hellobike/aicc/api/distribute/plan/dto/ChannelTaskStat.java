package com.hellobike.aicc.api.distribute.plan.dto;

import lombok.Data;

import java.util.List;

/**
 * @author fanxiaodongwb230
 */
@Data
public class ChannelTaskStat {
    /**
     * 渠道商id
     */
    private Integer channelId;

    /**
     * 渠道商名称
     */
    private String channelName;

    /**
     * 三方任务名称
     */
    private String supplierTaskName;

    /**
     * 三方任务id
     */
    private String supplierTaskId;

    /**
     * 下发总量
     */
    private Long sentTotalNum;

    /**
     * 下发总量占比
     */
    private String sentTotalNumPercentage;

    /**
     * 下发成功量
     */
    private Long sentSuccessNum;

    /**
     * 话单量
     */
    private Long callDialogueNum;

    /**
     * 接通话单量
     */
    private Long throughCallDialogueNum;

    /**
     * 计费数
     */
    private Long costUnit;

    /**
     * 接通名单数
     */
    private Long throughRosterNum;

    /**
     * 名单接通率
     */
    private String throughRosterPercentage;

    /**
     * 最新下发时间
     */
    private String latestSentTime;

    /**
     * 创建时间
     */
    private String createTime;

    /**
     * 短信发送数量
     */
    private Long sendSmsSum;

    /**
     * 短信成功数量
     */
    private Long smsSuccSum;

    /**
     * 短信成功率
     */
    private String smsSuccRate;

    /**
     * 短信计费数
     */
    private Long smsUnit;


    /**
     * 意图分类总计
     */
    private List<IntentionClassify> intentClassifyList;

    /**
     * 转化漏斗总计
     */
    private List<ConversionFunnel> conversionFunnel;
}
