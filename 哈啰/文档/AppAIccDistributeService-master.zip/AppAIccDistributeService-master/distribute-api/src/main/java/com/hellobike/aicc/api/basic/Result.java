package com.hellobike.aicc.api.basic;

import com.hellobike.aicc.common.exception.BusinessErrorCode;
import lombok.Getter;
import lombok.ToString;


/**
 * * @author older
 */
@Getter
@ToString
public class Result<T> {
    public static final int SUCCESS = 200;
    /**
     * 前端统一框架处理，0表示成功
     */
    public static final int FRONT_SUCCESS = 0;

    private Integer code;
    private String msg;
    private T data;

    private Boolean success;

    public Result() {
        this(SUCCESS);
    }

    public Result(T data) {
        this();
        this.data = data;
    }

    private Result(int code) {
        this.code = code;
    }

    private Result(int code, String msg) {
        this(code);
        this.msg = msg;
    }

    public Result(int code, String msg, T data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    /**
     * @param data 业务数据
     * @param <T>  业务数据类型
     * @return 正确带业务数据的返回值
     */
    public static <T> Result<T> ok(T data) {
        return new Result<>(data);
    }

    /**
     * @param <T> 业务数据类型
     * @return 正确带业务数据的返回值
     */
    public static <T> Result<T> ok() {
        return new Result<>(null);
    }

    /**
     * 返回给前端的成功，code为0
     *
     * @param data 业务数据
     * @param <T>  业务数据类型
     * @return 正确带业务数据的返回值
     */
    public static <T> Result<T> frontOk(T data) {
        return new Result<>(FRONT_SUCCESS, null, data);
    }

    /**
     * 返回给前端的成功，code为0
     *
     * @param <T> 业务数据类型
     * @return 正确带业务数据的返回值
     */
    public static <T> Result<T> frontOk() {
        return new Result<>(FRONT_SUCCESS, null, null);
    }

    /**
     * @param code 错误码
     * @param msg  错误信息
     * @return 错误返回值
     */
    public static <T> Result<T> fail(int code, String msg) {
        return new Result<>(code, msg);
    }

    /**
     * @param code   错误码
     * @param format 错误信息模板
     * @param args   错误信息参数
     * @return 错误返回值
     */
    public static <T> Result<T> fail(int code, String format, Object... args) {
        return new Result<>(code, String.format(format, args));
    }

    /**
     * @param code 错误码枚举类
     * @return 错误返回值
     */
    public static <T> Result<T> fail(BusinessErrorCode code) {
        return fail(code.getCode(), code.getDesc());
    }

    /**
     * @param code 错误码枚举类
     * @param args 错误信息或匹配缺省错误信息模板的参数
     * @return 错误返回值
     */
    public static <T> Result<T> fail(BusinessErrorCode code, Object... args) {
        return fail(code.getCode(), code.getDesc(), args);
    }

    /**
     * @param error 错误码
     * @return 错误返回值
     */
    public static <T> Result<T> failWithData(BusinessErrorCode error, T data) {
        Result<T> result = new Result<>(error.getCode(), error.getDesc());
        result.data = data;
        return result;
    }

    /**
     * @param data body
     * @param code 错误码
     * @return 错误返回值
     */
    public static <T> Result<T> failWithData(T data, BusinessErrorCode code, Object... args) {
        Result<T> result = fail(code.getCode(), code.getDesc(), args);
        result.data = data;
        return result;
    }

    /**
     * @return 是否成功
     */
    public boolean getSuccess() {
        return code == SUCCESS || code == FRONT_SUCCESS;
    }

    public void setCode(int code){
        this.code = code;
    }
}
