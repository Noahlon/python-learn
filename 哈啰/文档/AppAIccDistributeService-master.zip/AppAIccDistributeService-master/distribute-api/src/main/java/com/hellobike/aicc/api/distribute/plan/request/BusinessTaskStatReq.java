package com.hellobike.aicc.api.distribute.plan.request;

import com.hellobike.aicc.api.basic.PageParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * @author zhengchenyang
 * @date 2025/4/22
 * @desc 商业化后台 任务统计请求
 */

@EqualsAndHashCode(callSuper = true)
@Data
public class BusinessTaskStatReq extends PageParam implements Serializable {
    /**
     * 租户id
     */
    private String tenantId;

    /**
     * 任务id
     */
    private String taskId;

    /**
     * 任务名称
     */
    private String taskName;

}
