package com.hellobike.aicc.api.distribute.plan.dto;

import lombok.Data;

/**
 * @author zhengchenyang
 * @date 2025/4/22
 * @desc 意图分类数据
 */
@Data
public class IntentionClassify {
    /**
     * 名称
     */
    private String name;
    /**
     * 标识
     */
    private String code;

    /**
     * 数据
     */
    private Long value;

    /**
     * 百分比
     */
    private String percentage;
}
