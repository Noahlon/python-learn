package com.hellobike.aicc.api.file.iface;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.file.request.FileExportRecordRequest;
import com.hellobike.aicc.api.file.response.FileExportRecordResponse;
import com.hellobike.aicc.common.basic.PageResult;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  15:05:29
 */
public interface FileExportService {

    Result<PageResult<FileExportRecordResponse>> pageRecord(FileExportRecordRequest request);
}
