package com.hellobike.aicc.api.basic;

import com.hellobike.aicc.common.basic.LoginParam;
import lombok.Getter;
import lombok.Setter;

/**
 * @author older
 */
@Setter
@Getter
public class PageParam extends LoginParam {

    /**
     * pageSize 每页查询数
     */
    private Integer pageSize = 50;

    /**
     * 页码 查询的页码，从1开始
     */
    private Integer pageNum = 1;
}
