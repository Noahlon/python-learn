package com.hellobike.aicc.api.distribute.upload.request;

import com.hellobike.aicc.api.basic.PageParam;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @Author: hjj
 * @CreateTime: 2025-02-28
 * @Description: 计划模板查询对象
 * @Version: 1.0
 */
@Data
public class DistributeUploadFileQueryRequest extends PageParam implements Serializable{

    private String id;

    /**
     * 数据密级S2,文件名称
     */
    private String fileName;

    /**
     * 数据密级S2,分流计划id
     */
    private Long distributePlanId;

}
