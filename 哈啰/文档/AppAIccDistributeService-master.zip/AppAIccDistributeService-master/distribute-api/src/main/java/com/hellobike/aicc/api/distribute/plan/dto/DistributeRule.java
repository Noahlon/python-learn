package com.hellobike.aicc.api.distribute.plan.dto;

import lombok.Data;

/**
 * 分流规则
 *
 * @author panlongqian
 * @since 2025-03-10
 */
@Data
public class DistributeRule {
    /**
     * 渠道商id
     */
    private Integer channelId;

    /**
     * 渠道商名称
     */
    private String channelName;

    /**
     * 分配比例
     */
    private String percentage;

    /**
     * 下发比例（下发到三方渠道任务成功的数据量 / 分流计划中上传成功的总量）
     */
    private String sendPercentage;

    /**
     * 任务模板id
     */
    private String taskTemplateId;

    /**
     * 任务模板名称
     */
    private String taskTemplateName;

    /**
     * 三方任务名称
     */
    private String supplierTaskName;

    /**
     * 数据量
     */
    private Long quantity;

    /**
     * 计划渠道任务表id
     */
    private String planChannelTaskId;

    /**
     * 计划渠道任务表状态,0-任务创建失败，1-任务创建成功
     */
    private Integer planChannelTaskStatus;

    /**
     * 计划渠道任务表状态描述,0-失败，1-成功
     */
    private String planChannelTaskStatusDesc;
}
