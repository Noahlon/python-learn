package com.hellobike.aicc.api.common.response;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * oss令牌信息
 */
@Setter
@Getter
@Accessors(chain = true)
public class OssTokenResponse {
    private String accessKeyId;

    private String securityToken;

    private String accessKeySecret;

    private String region;

    private String bucket;

    private String baseDir;
}
