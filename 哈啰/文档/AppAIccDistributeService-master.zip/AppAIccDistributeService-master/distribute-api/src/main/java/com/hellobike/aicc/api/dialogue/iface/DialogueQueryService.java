package com.hellobike.aicc.api.dialogue.iface;

import com.hellobike.aicc.api.dialogue.request.DialogueDetailRequest;
import com.hellobike.aicc.api.dialogue.request.DialogueQueryRequest;
import com.hellobike.aicc.api.dialogue.response.DialogueDetailResponse;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.dialogue.request.DialogueListQueryRequest;
import com.hellobike.aicc.api.dialogue.response.DialogueInfoResponse;

import java.util.List;

/**
 * 话单相关查询操作
 */
public interface DialogueQueryService {
    /**
     * 查询话单记录列表
     * @param req
     * @api dialogue.queryDialogueList
     * @return
     */
    Result<PageResult<DialogueInfoResponse>> queryDialogueRecords(DialogueListQueryRequest req);

    /**
     * 查询话单详情
     * @param req
     * @api dialogue.queryDetail
     * @return
     */
    Result<DialogueDetailResponse> queryDetail(DialogueDetailRequest req);

    /**
     * 导出通话记录
     * @param req
     * @api dialogue.export
     * @return
     */
    Result<Void> export(DialogueListQueryRequest req);

    /**
     * 从数据库查询话单（目前仅供测试内部调用使用）
     * @return
     */
    Result<List<Object>> queryFromDB(DialogueQueryRequest req);
}
