package com.hellobike.aicc.api.file.response;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  15:07:38
 */
@Data
public class FileExportRecordResponse {

    private String id;

    /**
     * 数据密级S2,文件类型
     * @see com.hellobike.aicc.common.enums.FileExportBizTypeEnum
     */
    private Integer bizType;

    /**
     * 数据密级S2,执行状态
     * @see com.hellobike.aicc.common.enums.FileExportStatusEnum
     */
    private Integer status;

    /**
     * 数据密级S2,文件地址
     */
    private String fileUrl;

    /**
     * 数据密级S2,导出失败原因
     */
    private String failReason;

    /**
     * 数据密级S2,操作人姓名
     */
    private String operator;

    /**
     * 数据密级S2,导出数据量
     */
    private Integer exportCount;

    /**
     * 数据密级S2,创建时间
     */
    private String createTime;

}
