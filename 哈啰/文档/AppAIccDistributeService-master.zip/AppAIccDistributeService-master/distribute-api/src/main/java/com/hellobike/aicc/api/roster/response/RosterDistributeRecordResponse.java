package com.hellobike.aicc.api.roster.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RosterDistributeRecordResponse {
    /**
     * 记录id
     */
    private String id;

    /**
     * 渠道名称
     */
    private String channelName;

    /**
     * 任务名称
     */
    private String taskName;

    /**
     * 任务id
     */
    private String taskId;

    /**
     * 下发数量
     */
    private String distributeCount;

    /**
     * 成功数量
     */
    private String successCount;

    /**
     * 下发时间
     */
    private String distributeTime;
}
