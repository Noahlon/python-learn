package com.hellobike.aicc.api.callback.iface;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.callback.request.CallDialogueCallBackRequest;
import com.hellobike.aicc.api.callback.request.ChannelCallBackBaseRequest;
import com.hellobike.aicc.api.callback.request.SmsRecordCallBackRequest;

/**
 * 渠道商回调相关接口
 */
public interface ChannelCallBackService {
    /**
     * 话单回调
     */
    Result<Void> callDialogueCallBack(ChannelCallBackBaseRequest<CallDialogueCallBackRequest> request);

    /**
     * 短信记录回调
     */
    Result<Void> smsRecordCallBack(ChannelCallBackBaseRequest<SmsRecordCallBackRequest> request);
}
