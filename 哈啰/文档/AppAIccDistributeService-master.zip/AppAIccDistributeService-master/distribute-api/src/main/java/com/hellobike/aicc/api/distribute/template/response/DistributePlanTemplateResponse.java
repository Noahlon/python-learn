package com.hellobike.aicc.api.distribute.template.response;
import com.hellobike.aicc.api.distribute.plan.dto.DistributeRule;
import lombok.Data;

import java.util.List;

/**
 * @Author: hjj
 * @CreateTime: 2025-02-28
 * @Description: 分流计划模板查询返回对象
 * @Version: 1.0
 */
@Data
public class DistributePlanTemplateResponse {
    /**
     * 模板id
     */
    private String templateId;

    /**
     * 模板名称
     */
    private String templateName;

    /**
     * 租户id
     */
    private String tenantCode;

    /**
     * 租户名称
     */
    private String tenantName;

    /**
     * 分流类型
     * @see com.hellobike.aicc.common.enums.DistributeTypeEnum
     */
    private Integer distributeType;

    /**
     * 分流规则
     */
    private List<DistributeRule> distributeRuleList;

    /**
     * 最近使用时间
     */
    private String latestUseTime;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private String createTime;
}
