package com.hellobike.aicc.api.common.iface;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.common.request.EnumRequest;
import com.hellobike.aicc.api.common.response.EnumResponse;

/**
 * @author zhangzhuoqi
 * @since 2025-04-22  16:14:50
 */
public interface CommonService {

    /**
     * 获取枚举
     *
     * @author zhangzhuoqi
     * @since 2025/4/22 17:04
     * @param request req
     * @return Result<EnumResponse>
     **/
    Result<EnumResponse> queryEnumList(EnumRequest request);
}
