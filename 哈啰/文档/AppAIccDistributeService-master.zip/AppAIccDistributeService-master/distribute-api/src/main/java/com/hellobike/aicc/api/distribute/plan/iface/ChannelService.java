package com.hellobike.aicc.api.distribute.plan.iface;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.distribute.plan.request.BusinessTaskStatReq;
import com.hellobike.aicc.api.distribute.plan.request.ChannelQueryRequest;
import com.hellobike.aicc.api.distribute.plan.request.ChannelTaskRequest;
import com.hellobike.aicc.api.distribute.plan.request.RetryCreateChannelTaskRequest;
import com.hellobike.aicc.api.distribute.plan.response.BusinessTaskStatResponse;
import com.hellobike.aicc.api.distribute.plan.response.ChannelResponse;
import com.hellobike.aicc.api.distribute.plan.response.ChannelTaskStatResponse;

import java.util.List;

public interface ChannelService {
    /**
     * 查询渠道商列表
     */
    Result<List<ChannelResponse>> queryChannelList(ChannelQueryRequest request);

    /**
     * 根据渠道商id查询渠道商完整信息，包括渠道商模板信息
     */
    Result<List<ChannelResponse>> queryChannelDetail(ChannelQueryRequest request);

    /**
     * 重试创建渠道任务
     */
    Result<Void> retryCreateChannelTask(RetryCreateChannelTaskRequest request);

    /**
     * 渠道任务统计
     */
    Result<ChannelTaskStatResponse> channelTaskStat(ChannelTaskRequest request);

    /**
     * 商户任务统计
     */
    Result<BusinessTaskStatResponse> businessTaskStat(BusinessTaskStatReq request);
}
