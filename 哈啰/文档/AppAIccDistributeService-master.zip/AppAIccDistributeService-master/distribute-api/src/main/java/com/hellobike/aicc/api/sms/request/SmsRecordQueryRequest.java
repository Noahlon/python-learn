package com.hellobike.aicc.api.sms.request;

import com.hellobike.aicc.api.basic.PageParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class SmsRecordQueryRequest extends PageParam {
    /**
     * 唯一id
     */
    private String guid;

    /**
     * 平台数据唯一标识
     */
    private String platformId;

    /**
     * 渠道商id
     */
    private Integer channelId;

    /**
     * 手机号码
     */
    private String phoneNumber;

    /**
     * 手机号码的32位小写md5加密
     */
    private String phoneNumberMd5;

    /**
     * 分流计划id
     */
    private String distributePlanId;

    /**
     * 分流计划名称
     */
    private String distributePlanName;

    /**
     * 渠道商任务id
     */
    private String supplierTaskId;

    /**
     * 渠道商任务名称
     */
    private String supplierTaskName;

    /**
     * 发送结果列表
     */
    private List<Integer> sendResultList;

    /**
     * 短信签名
     */
    private String signature;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 创建起始时间
     */
    @NotBlank(message = "创建起始时间不能为空")
    private String createBeginTime;

    /**
     * 创建结束时间
     */
    @NotBlank(message = "创建结束时间不能为空")
    private String createEndTime;

    /**
     * 发送起始时间
     */
    private String sendBeginTime;

    /**
     * 发送结束时间
     */
    private String sendEndTime;

    /**
     * 收到回执起始时间
     */
    private String receiveResultBeginTime;

    /**
     * 收到回执结束时间
     */
    private String receiveResultEndTime;

    /**
     * 坐席名称
     */
    private String seatsName;

    /**
     * 渠道商通话记录id
     */
    private String callGuid;

    /**
     * 城市
     */
    private List<String> cityList;

    /**
     * 运营商列表
     */
    private List<Integer> carrierList;
}
