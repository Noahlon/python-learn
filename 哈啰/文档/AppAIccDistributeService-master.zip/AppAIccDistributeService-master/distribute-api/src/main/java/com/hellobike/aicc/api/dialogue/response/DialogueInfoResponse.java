package com.hellobike.aicc.api.dialogue.response;

import com.hellobike.aicc.common.enums.CallResultEnum;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * 话单信息
 */
@Getter
@Setter
public class DialogueInfoResponse {

    /**
     * 话单id
     */
    private String id;

    /**
     * 渠道商名称
     */
    private String channelName;

    /**
     * 客户数据标识
     */
    private String externalId;

    /**
     * 平台数据标识
     */
    private String platformId;

    /**
     * 分流计划名称
     */
    private String distributePlanName;

    /**
     * 分流计划ID
     */
    private String distributePlanId;

    /**
     * 小写md5
     */
    private String md5;

    /**
     * 被叫号码
     */
    private String calledNumber;

    /**
     * 任务ID
     */
    private String supplierTaskId;

    /**
     * 任务名称
     */
    private String supplierTaskName;

    /**
     * 话术模板ID
     */
    private String speechTemplateId;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 呼叫结果
     * @see CallResultEnum
     */
    private Integer callResult;

    /**
     * 呼叫结果
     * @see CallResultEnum
     */
    private String callResultDesc;

    /**
     * 意向分类Code
     */
    private String intentClassify;

    /**
     * 意向分类名称
     */
    private String intentClassifyName;

    /**
     * 命中意图
     */
    private List<String> hitIntentions;

    /**
     * 触发短信 1：触发 0：未触发
     */
    private Integer isHitSms;

    /**
     * 坐席姓名
     */
    private String seatName;

    /**
     * AI通话时长 (合并原开始/结束字段)
     */
    private Integer durationCallAi;

    /**
     * 人工通话时长 (合并原开始/结束字段)
     */
    private Integer durationCallManual;

    /**
     * 中继外显号
     */
    private String realCallingNumber;

    /**
     * 通话时长
     */
    private Integer totalTime;

    /**
     * 振铃时长
     */
    private Integer ringTime;

    /**
     * 拨打时间
     */
    private String dialTime;

    /**
     * 挂机时间
     */
    private String hangupTime;

    /**
     * 通话类型
     * @see com.hellobike.aicc.common.enums.CallTypeEnum
     */
    private Integer callType;

    /**
     * 主叫号码
     */
    private String callingNumber;

    /**
     * 计费单元数
     */
    private Integer costUnit;

    /**
     * 客户姓名
     */
    private String customName;

    /**
     * 渠道商通话唯一ID
     */
    private String dialogueGuid;

    /**
     * 通话完整录音地址
     */
    private String recordUrl;

    /**
     * 线路ID
     */
    private String lineId;

    /**
     * 数据密级S2,号码归属城市
     */
    private String city;

    /**
     * 数据密级S2,号码归属省份
     */
    private String province;

    /**
     * 运营商
     * @see com.hellobike.aicc.common.enums.CarrierTypeEnum
     */
    private Integer carrier;

    /**
     * 对话轮次
     */
    private Integer speechCount;

    /**
     * 性别 (1男 2女 3未知)
     * @see com.hellobike.aicc.common.enums.SexEnum
     */
    private Integer sex;

    /**
     * 挂断方
     * @see com.hellobike.aicc.common.enums.ReleaseInitiatorEnum
     */
    private Integer releaseInitiator;

    /**
     * 创建时间
     */
    private String createTime;

    /**
     * 租户code
     */
    private String tenantId;

    /**
     * 租户名称
     */
    private String tenantName;

}
