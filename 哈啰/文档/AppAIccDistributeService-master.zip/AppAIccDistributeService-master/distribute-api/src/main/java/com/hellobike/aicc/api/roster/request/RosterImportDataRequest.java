package com.hellobike.aicc.api.roster.request;

import lombok.Data;

import java.util.Map;

/**
 * @author zhangzhuoqi
 * @since 2025-03-20  10:13:49
 */
@Data
public class RosterImportDataRequest {

    /**
     * 手机号/md5
     */
    private String phone;

    /**
     * 姓名
     */
    private String name;

    /**
     * 客户名单数据标识
     */
    private String dataIdentifier;

    /**
     * 变量信息
     */
    private Map<String, String> variableInfos;
}
