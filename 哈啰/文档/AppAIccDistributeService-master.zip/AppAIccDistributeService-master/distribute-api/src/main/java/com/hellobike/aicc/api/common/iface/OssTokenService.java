package com.hellobike.aicc.api.common.iface;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.common.request.OSSAuthorizeRequest;
import com.hellobike.aicc.api.common.response.OSSAuthorizeResponse;
import com.hellobike.aicc.api.common.response.OssTokenResponse;
import com.hellobike.aicc.common.basic.LoginParam;

/**
 * 获取oss临时token
 */
public interface OssTokenService {
    /**
     * oss临时令牌获取
     *
     * @param request 请求参数
     * @return oss临时token信息
     */
    Result<OssTokenResponse> getOssTempToken(LoginParam request);

    /**
     * 资源授权
     */
    Result<OSSAuthorizeResponse> resourceAuthorize(OSSAuthorizeRequest request);
}
