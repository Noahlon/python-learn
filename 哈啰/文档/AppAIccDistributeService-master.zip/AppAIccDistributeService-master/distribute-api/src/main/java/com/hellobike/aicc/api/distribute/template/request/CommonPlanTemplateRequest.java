package com.hellobike.aicc.api.distribute.template.request;

import com.hellobike.aicc.common.basic.LoginParam;
import lombok.Data;

/**
 * @Author: hjj
 * @CreateTime: 2025-02-28
 * @Description: 新增计划模板对象
 * @Version: 1.0
 */
@Data
public class CommonPlanTemplateRequest extends LoginParam {

    /**
     * 模板id
     */
    private String templateId;
    /**
     * 模板名称
     */
    private String templateName;

    /**
     * 租户code
     */
    private String tenantCode;

    /**
     * 租户名称
     */
    private String tenantName;


}
