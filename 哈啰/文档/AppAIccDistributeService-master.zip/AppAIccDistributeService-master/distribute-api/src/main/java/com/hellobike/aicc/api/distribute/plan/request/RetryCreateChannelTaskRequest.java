package com.hellobike.aicc.api.distribute.plan.request;

import com.hellobike.aicc.common.basic.LoginParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;

/**
 * @author zhangzhuoqi
 * @since 2025-03-10  13:46:57
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class RetryCreateChannelTaskRequest extends LoginParam {
    /**
     * 计划渠道任务表id
     */
    @NotBlank(message = "任务id不能为空")
    private String planChannelTaskId;
}
