package com.hellobike.aicc.api.distribute.plan.response;

import lombok.Data;

import java.util.List;

/**
 * 类说明
 *
 * @author panlongqian
 * @since 2025-03-11
 */
@Data
public class ChannelResponse {
    private Integer channelId;

    private String channelName;

    private List<ChannelTemplate> templateList;

    /**
     * 渠道商模板entity
     */
    @Data
    public static class ChannelTemplate {
        /**
         * 模板id
         */
        private String templateId;

        /**
         * 模板名称
         */
        private String templateName;
    }
}
