package com.hellobike.aicc.api.distribute.plan.iface;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.distribute.plan.dto.DistributePlan;
import com.hellobike.aicc.api.distribute.plan.dto.ExternalDistributePlan;
import com.hellobike.aicc.api.distribute.plan.request.DistributePlanQueryRequest;
import com.hellobike.aicc.api.distribute.plan.request.DistributePlanRequest;
import com.hellobike.aicc.common.basic.PageResult;


/**
 * 分流web层
 */
public interface DistributePlanService {
    /**
     * 创建分流计划
     */
    Result<String> createDistributePlan(DistributePlan request);

    /**
     * 更新分流计划
     */
    Result<Void> updateDistributePlan(DistributePlan request);

    /**
     * 查询分流计划
     */
    Result<PageResult<DistributePlan>> pageQueryDistributePlan(DistributePlanQueryRequest request);

    /**
     * 查询分流计划详情
     */
    Result<DistributePlan> queryDistributePlanDetail(DistributePlanRequest request);

    /**
     * 创建分流计划
     */
    Result<String> createExternalDistributePlan(ExternalDistributePlan request);
}
