package com.hellobike.aicc.api.sms.response;

import lombok.Data;

@Data
public class SmsRecordResponse {
    /**
     * 唯一id
     */
    private String guid;

    /**
     * 平台数据唯一标识
     */
    private String platformId;

    /**
     * 渠道商id
     */
    private Integer channelId;

    /**
     * 渠道商名称
     */
    private String channelName;

    /**
     * 客户数据标识
     */
    private String externalId;

    /**
     * 手机号码
     */
    private String phoneNumber;

    /**
     * 手机号码的32位小写md5加密
     */
    private String phoneNumberMd5;

    /**
     * 分流计划id
     */
    private String distributePlanId;

    /**
     * 分流计划名称
     */
    private String distributePlanName;

    /**
     * 渠道商任务id
     */
    private String supplierTaskId;

    /**
     * 渠道商任务名称
     */
    private String supplierTaskName;

    /**
     * 企业id
     */
    private String enterpriseId;

    /**
     * 话术名称
     */
    private String speechName;

    /**
     * 租户code
     */
    private String tenantCode;

    /**
     * 短信签名
     */
    private String signature;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 短信发送结果
     */
    private Integer sendResult;

    /**
     * 短信发送结果描述
     */
    private String sendResultDesc;

    /**
     * 短信发送时间
     */
    private String sendTime;

    /**
     * 收到短信结果时间
     */
    private String receiveResultTime;

    /**
     * 计费条数
     */
    private Integer billingNum;

    /**
     * 坐席名称
     */
    private String seatsName;

    /**
     * 客户名称
     */
    private String customName;

    /**
     * 渠道商通话记录id
     */
    private String callGuid;

    /**
     * 运营商
     */
    private Integer carrier;

    /**
     * 省份
     */
    private String province;

    /**
     * 城市
     */
    private String city;

    /**
     * 创建时间
     */
    private String createTime;
}
