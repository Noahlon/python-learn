package com.hellobike.aicc.api.distribute.plan.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author zhengchenyang
 * @date 2025/4/22
 * @desc
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConversionFunnel {
    /**
     * 项名称
     */
    private String  name;

    /**
     * 标识
     */
    private String  code;

    /**
     * id
     */
    private Integer id;

    /**
     * 数量
     */
    private Long value;
}
