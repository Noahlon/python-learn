package com.hellobike.aicc.api.roster.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RosterUploadRecordResponse {
    /**
     * 上传记录id
     */
    private String id;

    /**
     * 上传方式 1手动 2接口
     */
    private Integer uploadType;

    /**
     * 上传状态
     * @see com.hellobike.aicc.common.enums.UploadStatusEnum
     */
    private Integer uploadStatus;

    /**
     * 上传失败原因
     */
    private String uploadFailReason;

    /**
     * 上传数量
     */
    private Integer uploadCount;

    /**
     * 下发状态
     * @see com.hellobike.aicc.common.enums.DistributeStatusEnum
     */
    private Integer distributeStatus;

    /**
     * 下发数量
     */
    private Integer distributeCount;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 上传时间
     */
    private String uploadTime;

    /**
     * 名单类型
     */
    private Integer rosterType;

    /**
     * 名单类型描述
     */
    private String rosterTypeDesc;
}
