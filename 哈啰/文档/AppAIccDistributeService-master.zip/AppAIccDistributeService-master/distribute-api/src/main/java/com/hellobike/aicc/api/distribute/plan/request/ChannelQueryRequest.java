package com.hellobike.aicc.api.distribute.plan.request;

import com.hellobike.aicc.common.basic.LoginParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * 计划模板查询对象
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ChannelQueryRequest extends LoginParam {
    /**
     * 渠道商id
     */
    private Integer channelId;

    /**
     * 渠道商id列表
     */
    private List<Integer> channelIdList;

    /**
     * 租户code
     */
    private String tenantCode;
}
