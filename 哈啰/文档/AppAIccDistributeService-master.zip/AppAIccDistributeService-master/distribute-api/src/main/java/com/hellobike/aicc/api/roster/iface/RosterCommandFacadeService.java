package com.hellobike.aicc.api.roster.iface;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.roster.request.RosterImportRequest;
import com.hellobike.aicc.api.roster.request.RosterRetryDistributeRequest;
import com.hellobike.aicc.api.roster.response.RosterImportResponse;

/**
 * 名单相关执行操作
 */
public interface RosterCommandFacadeService {
    /**
     * 重试下发名单
     *
     * @return Result<Void>
     * @api roster.retryDistribute
     **/
    Result<Void> retryDistribute(RosterRetryDistributeRequest request);

    /**
     * 接口上传名单
     *
     * @param request
     * @return Result<Void>
     * @author zhangzhuoqi
     * @since 2025/3/20 10:10
     **/
    Result<RosterImportResponse> importRoster(RosterImportRequest request);

}
