package com.hellobike.aicc.api.distribute.plan.response;

import com.hellobike.aicc.api.distribute.plan.dto.ChannelTaskStat;
import com.hellobike.aicc.api.distribute.plan.dto.ConversionFunnel;
import com.hellobike.aicc.api.distribute.plan.dto.IntentionClassify;
import lombok.Data;

import java.util.List;

/**
 * @author fanxiaodongwb230
 */
@Data
public class ChannelTaskStatResponse {
    /**
     * 下发量统计
     */
    private Long sentTotalSum;

    /**
     * 下发成功量统计
     */
    private Long sentSuccessSum;

    /**
     * 话单量统计
     */
    private Long callDialogueNumSum;

    /**
     * 接通话单量统计
     */
    private Long throughCallDialogueNumSum;

    /**
     * 计费数统计
     */
    private Long costUnitSum;

    /**
     * 接通名单数统计
     */
    private Long throughRosterNumSum;

    /**
     * 名单接通率
     */
    private String throughRosterPercentage;

    /**
     * 短信发送量总计
     */
    private Long totalSendSmsSum;

    /**
     * 短信成功数总计
     */
    private Long totalSmsSuccSum;

    /**
     * 短信整体成功率
     */
    private String totalSmsSuccRate;

    /**
     * 短信计费数
     */
    private Long totalSmsUnit;

    /**
     * 渠道任务列表
     */
    private List<ChannelTaskStat> channelTaskStatList;

    /**
     * 意图分类总计
     */
    private List<IntentionClassify> totalIntentClassifyList;

    /**
     * 转化漏斗总计
     */
    private List<ConversionFunnel> totalConversionFunnel;

}
