package com.hellobike.aicc.api.distribute.upload.response;
import com.hellobike.aicc.api.distribute.plan.dto.DistributeRule;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @Author: fanxiaodongwb230
 * @CreateTime: 2025-03-14
 * @Description: 计划模板文件返回对象
 * @Version: 1.0
 */
@Data
public class DistributeUploadFileResponse {
    private String id;

    /**
     * 数据密级S2,文件名称
     */
    private String fileName;

    /**
     * 数据密级S2,文件连接
     */
    private String fileUrl;

    /**
     * 数据密级S2,分流计划id
     */
    private Long distributePlanId;

    /**
     * 数据密级S2,成功条数
     */
    private Integer successCount;

    /**
     * 数据密级S2,失败条数
     */
    private Integer failedCount;

    /**
     * 数据密级S2,重复条数
     */
    private Integer duplicateCount;

    /**
     * 数据密级S2,操作类型
     * 暂定：1:添加呼叫，2：取消呼叫
     */
    private Integer operationType;

    /**
     * 数据密级S2,状态(10:待处理，15:处理中，20：失败，30：完成，40：文件格式有误)
     */
    private Integer status;

    /**
     * 数据密级S2,状态描述
     */
    private Integer status_desc;

    /**
     * 数据密级S2,创建人
     */
    private String creator;

    /**
     * 数据密级S1,创建时间
     */
    private LocalDateTime createTime;
}
