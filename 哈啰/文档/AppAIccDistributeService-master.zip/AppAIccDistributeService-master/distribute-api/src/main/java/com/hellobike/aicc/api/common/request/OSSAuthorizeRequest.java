package com.hellobike.aicc.api.common.request;

import com.hellobike.aicc.common.basic.LoginParam;
import lombok.Getter;
import lombok.Setter;

/**
 * 资源授权表单
 *
 * @author LuJ
 * @since 2024-02-28 18:37
 */
@Setter
@Getter
public class OSSAuthorizeRequest extends LoginParam {
    /**
     * 待授权资源
     */
    private String ossUrl;
}
