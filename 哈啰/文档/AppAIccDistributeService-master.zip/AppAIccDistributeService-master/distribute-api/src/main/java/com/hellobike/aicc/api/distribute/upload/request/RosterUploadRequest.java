package com.hellobike.aicc.api.distribute.upload.request;

import com.hellobike.aicc.common.basic.LoginParam;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Getter
@Setter
public class RosterUploadRequest extends LoginParam {

    /**
     * 上传名单文件地址
     */
    @NotBlank(message = "文件地址不能为空")
    private String fileUrl;

    /**
     * 上传名单文件名称
     */
    @NotBlank(message = "文件名称不能为空")
    private String fileName;

    /**
     * 分流计划id
     */
    @NotBlank(message = "分流计划id不能为空")
    private String distributePlanId;

    @NotNull(message = "名单类型不能为空")
    private Integer rosterType;
}
