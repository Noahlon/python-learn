package com.hellobike.aicc.api.dialogue.response;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-04-17  14:44:26
 */
@Data
public class DialogueDetailResponse {

    /**
     * 话单id
     */
    private String id;

    /**
     * 接通时间
     */
    private String answerTime;

    /**
     * 挂断时间
     */
    private String hangupTime;

    /**
     * 录音文件地址
     */
    private String recordUrl;

    /**
     * 对话信息
     */
    private List<DialogueSpeakResponse> speakList;
}
