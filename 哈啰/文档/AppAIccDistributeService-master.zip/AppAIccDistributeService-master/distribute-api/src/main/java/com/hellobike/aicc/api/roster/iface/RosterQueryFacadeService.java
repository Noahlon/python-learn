package com.hellobike.aicc.api.roster.iface;

import com.hellobike.aicc.api.roster.request.RosterTemplateRequest;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.roster.request.RosterDistributeQueryRequest;
import com.hellobike.aicc.api.roster.request.RosterUploadQueryRequest;
import com.hellobike.aicc.api.roster.response.RosterDistributeRecordResponse;
import com.hellobike.aicc.api.roster.response.RosterUploadRecordResponse;

/**
 * 名单相关查询操作
 */
public interface RosterQueryFacadeService {
    /**
     * 查询上传记录列表
     * @param rosterUploadQueryRequest
     * @api roster.queryUploadList
     * @return
     */
    Result<PageResult<RosterUploadRecordResponse>> queryUploadRecords(RosterUploadQueryRequest rosterUploadQueryRequest);

    /**
     * 查询下发记录列表
     * @param rosterDistributeQueryRequest
     * @api roster.queryDistributeList
     * @return
     */
    Result<PageResult<RosterDistributeRecordResponse>> queryDistributeRecords(RosterDistributeQueryRequest rosterDistributeQueryRequest);

    /**
     * 下载名单导入模版
     * @api roster.download
     * @param rosterTemplateRequest
     * @return
     */
    Result<String> downloadRosterTemplate(RosterTemplateRequest rosterTemplateRequest);
}
