package com.hellobike.aicc.api.roster.request;

import com.hellobike.aicc.api.basic.PageParam;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
public class RosterUploadQueryRequest extends PageParam {

    /**
     * 上传方式 1手动 2接口
     */
    private Integer uploadType;

    /**
     * 分流计划id
     */
    @NotBlank(message = "分流计划id不能为空")
    private String distributePlanId;

    /**
     * 下发状态
     * @see com.hellobike.aicc.common.enums.DistributeStatusEnum
     */
    private Integer distributeStatus;
}
