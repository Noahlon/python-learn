package com.hellobike.aicc.api.distribute.plan.request;

import com.hellobike.aicc.common.basic.LoginParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author fanxiaodongwb230
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ChannelTaskRequest extends LoginParam {
    private String planId;
}
