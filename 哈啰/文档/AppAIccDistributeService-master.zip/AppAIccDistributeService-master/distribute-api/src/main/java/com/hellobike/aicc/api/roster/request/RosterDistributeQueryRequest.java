package com.hellobike.aicc.api.roster.request;

import com.hellobike.aicc.api.basic.PageParam;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
public class RosterDistributeQueryRequest extends PageParam {

    /**
     * 渠道id
     */
    private String channelId;

    /**
     * 三方任务名称
     */
    private String taskName;

    /**
     * 分流计划id
     */
    @NotBlank(message = "分流计划id不能为空")
    private String distributePlanId;
}
