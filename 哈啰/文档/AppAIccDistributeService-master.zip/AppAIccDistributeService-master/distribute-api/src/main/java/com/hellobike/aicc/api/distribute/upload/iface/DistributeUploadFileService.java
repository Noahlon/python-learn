package com.hellobike.aicc.api.distribute.upload.iface;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.distribute.upload.request.DistributeUploadFileQueryRequest;
import com.hellobike.aicc.api.distribute.upload.response.DistributeUploadFileResponse;
import com.hellobike.aicc.api.distribute.upload.request.RosterUploadRequest;
import com.hellobike.aicc.common.basic.PageResult;

/**
 * 分流文件服务web层接口
 */
public interface DistributeUploadFileService {
    /**
     * 上传名单
     * @api roster.uploadFile
     * @param request 上传请求
     * @return 上传结果
     */
    Result<Boolean> uploadRoster(RosterUploadRequest request);

    /**
     * 查询上传文件列表
     */
    Result<PageResult<DistributeUploadFileResponse>> queryUploadFileList(DistributeUploadFileQueryRequest request);
}
