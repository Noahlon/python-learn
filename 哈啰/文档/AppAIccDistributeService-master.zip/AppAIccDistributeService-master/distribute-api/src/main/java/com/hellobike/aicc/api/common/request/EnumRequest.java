package com.hellobike.aicc.api.common.request;

import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author zhangzhuoqi
 * @since 2025-04-22  16:21:31
 */
@Data
public class EnumRequest {

    @NotNull(message = "类型不能为空")
    private Integer type;
}
