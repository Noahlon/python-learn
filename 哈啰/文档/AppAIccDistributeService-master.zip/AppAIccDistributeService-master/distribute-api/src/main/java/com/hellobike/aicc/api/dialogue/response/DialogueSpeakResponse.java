package com.hellobike.aicc.api.dialogue.response;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-04-17  14:50:12
 */
@Data
public class DialogueSpeakResponse {

    /**
     * 说话id
     */
    private String speakId;

    /**
     * 说话方 1-呼叫方 2-被叫方
     */
    private Integer speaker;

    /**
     * 说话内容
     */
    private String speakContent;

    /**
     * 说话时间
     */
    private String speakTime;
}
