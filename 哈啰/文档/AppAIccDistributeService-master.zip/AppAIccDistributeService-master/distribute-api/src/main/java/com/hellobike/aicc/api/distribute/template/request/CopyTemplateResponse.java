package com.hellobike.aicc.api.distribute.template.request;

import com.hellobike.aicc.api.distribute.plan.dto.DistributeRule;
import lombok.Data;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-05-21  11:07:49
 */
@Data
public class CopyTemplateResponse {

    /**
     * 租户id
     */
    private String tenantCode;

    /**
     * 租户名称
     */
    private String tenantName;

    /**
     * 模版名称
     */
    private String templateName;
    /**
     * 分流类型
     * @see com.hellobike.aicc.common.enums.DistributeTypeEnum
     */
    private Integer distributeType;

    /**
     * 分流规则
     */
    private List<DistributeRule> distributeRuleList;
}
