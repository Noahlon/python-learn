package com.hellobike.aicc.api.distribute.plan.request;

import com.hellobike.aicc.api.basic.PageParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

/**
 * 计划模板查询对象
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class DistributePlanQueryRequest extends PageParam implements Serializable {
    /**
     * 分流计划id
     */
    private String planId;

    /**
     * 分流计划名称
     */
    private String planName;

    /**
     * 租户code
     */
    private List<String> tenantCodeList;


    /**
     * 分配类型
     * DistributeTypeNum
     */
    private Integer distributeType;

    /**
     * 渠道商id
     */
    private Integer channelId;

    /**
     * 创建开始时间
     */
    private String createStartTime;

    /**
     * 创建结束时间
     */
    private String createEndTime;

    /**
     * 三方任务模版id
     */
    private String supplierTemplateId;

    /**
     * 三方任务模版名称
     */
    private String supplierTemplateName;

    /**
     * 计划模版id
     */
    private String planTemplateId;

    /**
     * 计划模版名称
     */
    private String planTemplateName;
}
