package com.hellobike.aicc.api.common.response;

import lombok.Getter;
import lombok.Setter;

/**
 * 类说明
 *
 * @author panlongqian
 * @since 2024-12-17
 */

@Setter
@Getter
public class OSSAuthorizeResponse {
    /**
     * 授权后的访问地址
     */
    private String authorizedUrl;
    /**
     * 过期时间，时间戳
     */
    private Long expired;
}
