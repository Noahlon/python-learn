package com.hellobike.aicc.api.dialogue.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author zhangzhuoqi
 * @since 2025-04-17  14:44:38
 */
@Data
public class DialogueDetailRequest {

    /**
     * 话单id
     */
    @NotBlank(message = "话单id不能为空")
    private String id;

    /**
     * 被叫号
     */
    @NotBlank(message = "被叫号不能为空")
    private String calledNumber;
}
