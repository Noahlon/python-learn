package com.hellobike.aicc.api.roster.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-20  10:12:03
 */
@Data
public class RosterImportRequest {

    /**
     * 租户id
     */
    @NotBlank(message = "租户id不能为空")
    private String tenantId;

    /**
     * 分流计划id
     */
    @NotBlank(message = "分流计划id不能为空")
    private String distributePlanId;


    /**
     * 上传名单类型
     * @see com.hellobike.aicc.common.enums.RosterTypeEnum
     */
    private Integer rosterType = 1;

    /**
     * 名单数据
     */
    @NotEmpty(message = "名单数据不能为空")
    private List<RosterImportDataRequest> dataList;

}
