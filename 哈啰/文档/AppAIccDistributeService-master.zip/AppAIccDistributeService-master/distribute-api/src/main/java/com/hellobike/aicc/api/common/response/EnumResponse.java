package com.hellobike.aicc.api.common.response;

import com.hellobike.aicc.common.dto.CommonEnumDTO;
import com.hellobike.css.ai.api.iface.common.dto.EnumConstantDTO;
import lombok.Data;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-04-22  16:22:02
 */
@Data
public class EnumResponse {

    private List<CommonEnumDTO> enumConstantDTOList;
    private Integer type;

}
