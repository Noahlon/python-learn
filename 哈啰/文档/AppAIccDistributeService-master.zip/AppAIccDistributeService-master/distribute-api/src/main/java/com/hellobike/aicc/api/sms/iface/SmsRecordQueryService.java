package com.hellobike.aicc.api.sms.iface;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.sms.request.SmsRecordQueryRequest;
import com.hellobike.aicc.api.sms.response.SmsRecordResponse;
import com.hellobike.aicc.common.basic.PageResult;

/**
 * 短信记录查询接口
 *
 * @author panlongqian
 * @since 2025-04-24
 */
public interface SmsRecordQueryService {
    /**
     * 分页查询短信记录
     */
    Result<PageResult<SmsRecordResponse>> querySmsRecords(SmsRecordQueryRequest request);

    /**
     * 导出短信记录
     */
    Result<Void> export(SmsRecordQueryRequest request);
}
