package com.hellobike.aicc.api.distribute.template.request;

import com.hellobike.aicc.api.basic.PageParam;
import com.hellobike.aicc.api.distribute.plan.dto.DistributeRule;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @Author: hjj
 * @CreateTime: 2025-02-28
 * @Description: 计划模板查询对象
 * @Version: 1.0
 */
@Data
public class DistributePlanTemplateQueryRequest extends PageParam implements Serializable{
    /**
     * 模板id
     */
    private String templateId;
    /**
     * 模板名称
     */
    private String templateName;

    /**
     * 租户id集合
     */
    private List<String> tenantCodeList;

    /**
     * 分配类型
     * @see com.hellobike.aicc.common.enums.DistributeTypeEnum
     */
    private Integer distributeType;

    /**
     * 渠道商id
     */
    private String channelId;
    /**
     * 排序字段
     */
    private String sortColumn;

    /**
     * 排序方式 ASC，DESC
     */
    private String sortType;




}
