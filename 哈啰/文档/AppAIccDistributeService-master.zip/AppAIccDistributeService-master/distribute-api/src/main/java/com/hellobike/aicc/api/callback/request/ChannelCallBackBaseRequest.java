package com.hellobike.aicc.api.callback.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class ChannelCallBackBaseRequest<T> {
    @NotBlank(message = "appKey不能为空")
    private String appKey;

    private T data;
}
