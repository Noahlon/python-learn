package com.hellobike.aicc.api.callback.request;

import com.hellobike.aicc.common.enums.CarrierTypeEnum;
import com.hellobike.aicc.common.enums.SmsSendResultEnum;
import com.hellobike.aicc.common.enums.SmsSubmitResultEnum;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.css.ai.common.enums.cc.CarrierEnum;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;

@Data
public class SmsRecordCallBackRequest {
    /**
     * 表示精确到秒的时间字符串长度（格式如 yyyy-MM-dd HH:mm:ss）
     */
    private static final int TIME_STR_LENGTH_SECOND = 19;

    /**
     * 短信id
     */
    private String smsId;

    /**
     * 任务id
     */
    private String taskId;

    /**
     * 任务名称
     */
    private String taskName;

    /**
     * 通话记录id
     */
    private String dialogueGuid;

    /**
     * 名单唯一标识
     */
    private String rosterKey;

    /**
     * 手机号码
     */
    private String phoneNumber;

    /**
     * 手机号码md5
     */
    private String md5;

    /**
     * 省份
     */
    private String province;

    /**
     * 城市
     */
    private String city;

    /**
     * 运营商
     */
    private Integer carrier;

    /**
     * 短信签名
     */
    private String signature;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 短信发送结果
     */
    private Integer sendResult;

    /**
     * 短信发送时间
     */
    private String sendTime;

    /**
     * 短信提交结果
     */
    private Integer submitResult;

    /**
     * 短信提交时间
     */
    private String submitTime;

    /**
     * 短信计费数
     */
    private Integer billingNum;

    /**
     * 企业id
     */
    private String enterpriseId;

    public boolean isValid() {
        if (this.sendTime != null) {
            this.sendTime = removeMilliseconds(this.sendTime);
        }
        if (this.submitTime != null) {
            this.submitTime = removeMilliseconds(this.submitTime);
        }
        if (StringUtils.isAnyBlank(smsId, taskId, taskName, dialogueGuid, rosterKey)) {
            return false;
        }

        if (StringUtils.isAnyBlank(province, city,phoneNumber)) {
            return false;
        }

        if (CarrierTypeEnum.getEnumByCode(carrier) == null) {
            return false;
        }

        if (sendResult != null && SmsSendResultEnum.getByCode(sendResult) == null) {
            return false;
        }

        if (submitResult != null && SmsSubmitResultEnum.getByCode(submitResult) == null) {
            return false;
        }

        return !StringUtils.isAnyBlank(signature, content);
    }

    /**
     * 去除毫秒部分，保留到秒
     */
    private String removeMilliseconds(String timeStr) {
        if (timeStr == null || timeStr.length() < TIME_STR_LENGTH_SECOND) {
            return timeStr;
        }
        return timeStr.length() >= TIME_STR_LENGTH_SECOND ? timeStr.substring(0, TIME_STR_LENGTH_SECOND) : timeStr;
    }
}
