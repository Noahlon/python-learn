package com.hellobike.aicc.api.distribute.plan.response;

import com.hellobike.aicc.api.distribute.plan.dto.BusinessTaskStat;
import com.hellobike.aicc.api.distribute.plan.dto.ChannelTaskStat;
import com.hellobike.aicc.api.distribute.plan.dto.ConversionFunnel;
import com.hellobike.aicc.api.distribute.plan.dto.IntentionClassify;
import com.hellobike.aicc.common.basic.PageResult;
import lombok.Data;

import java.util.List;

/**
 * @author zhengchenyang
 */

@Data
public class BusinessTaskStatResponse {
    /**
     * 上传量统计
     */
    private Long totalUploadNum = 0L;

    /**
     * 上传成功量统计
     */
    private Long totalCallRosterNum = 0L;

    /**
     * 接通话单量统计
     */
    private Long totalThroughCallDialogueNum = 0L;

    /**
     * 计费数统计
     */
    private Long costUnitSum = 0L;

    /**
     * 接通名单数统计
     */
    private Long throughRosterNumSum = 0L;

    /**
     * 名单接通率
     */
    private String throughRosterPercentage;

    /**
     * 短信发送量总计
     */
    private Long totalSendSmsNum = 0L;

    /**
     * 短信成功数总计
     */
    private Long totalSmsSuccNum = 0L;

    /**
     * 短信整体成功率
     */
    private String totalSmsSuccRate;

    /**
     * 短信计费数
     */
    private Long totalSmsUnit = 0L;

    /**
     * 渠道任务列表
     */
    private PageResult<BusinessTaskStat> businessTaskStatList;

    /**
     * 意图分类总计
     */
    private List<IntentionClassify> totalIntentClassifyList;

    /**
     * 转化漏斗总计
     */
    private List<ConversionFunnel> totalConversionFunnel;

    /**
     * 最近一次统计时间
     */
    private String lastStatTime;

    /**
     * 统计天数范围
     */
    private Integer statDayRange;

}
