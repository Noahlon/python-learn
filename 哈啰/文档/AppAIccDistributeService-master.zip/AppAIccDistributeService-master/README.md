# 帮助文档

https://hellobike.yuque.com/vl1gd8/sr4wh0/zpztge

# 中间件需要配置

[中间件文档大全](https://hellobike.yuque.com/vl1gd8/xazxnw/fkvrf4)


# 注意init.script配置文件

本地init.script没有用，发布请使用静态模版配置《Java初始化脚本》

远程调试配置=注释了

JMX端口配置=默认值

各个环境区分内容如下：

```shell

# FAT
START_OPTS="$START_OPTS -Denv=fat"
START_OPTS="$START_OPTS -Dowl.metrics.kafka.servers=fat-kafka1.ttbike.com.cn:9092,fat-kafka2.ttbike.com.cn:9092,fat-kafka3.ttbike.com.cn:9092"
START_OPTS="$START_OPTS -Dapollo.meta=http://fat-apollometa.hellobike.cn:10080"
START_OPTS="$START_OPTS -DbasicConf.host=https://fat-basicconf.hellobike.cn"

# UAT
START_OPTS="$START_OPTS -Denv=uat"
START_OPTS="$START_OPTS -Dowl.metrics.kafka.servers=uat-kafka1.ttbike.com.cn:9092,uat-kafka2.ttbike.com.cn:9092,uat-kafka3.ttbike.com.cn:9092"
START_OPTS="$START_OPTS -Dapollo.meta=http://uat-apollometa.hellobike.cn:10080"
START_OPTS="$START_OPTS -DbasicConf.host=https://uat-basicconf.hellobike.cn"

# PT
START_OPTS="$START_OPTS -Denv=pt"
START_OPTS="$START_OPTS -Dowl.metrics.kafka.servers=pt-kafka1.ttbike.com.cn:9092,pt-kafka2.ttbike.com.cn:9092,pt-kafka3.ttbike.com.cn:9092"
START_OPTS="$START_OPTS -Dapollo.meta=http://pt-apollometa.hellobike.cn:10080"
START_OPTS="$START_OPTS -DbasicConf.host=https://pt-basicconf.hellobike.cn"

# PRO
START_OPTS="$START_OPTS -Denv=pro"
START_OPTS="$START_OPTS -Dowl.metrics.kafka.servers=owl.kafka1.ttbike.com.cn:9092,owl.kafka2.ttbike.com.cn:9092,owl.kafka3.ttbike.com.cn:9092"
START_OPTS="$START_OPTS -Dapollo.meta=http://meta.config.ttbike.com.cn:10080"
START_OPTS="$START_OPTS -DbasicConf.host=http://basic-conf-inner.hellobike.cn"

```









