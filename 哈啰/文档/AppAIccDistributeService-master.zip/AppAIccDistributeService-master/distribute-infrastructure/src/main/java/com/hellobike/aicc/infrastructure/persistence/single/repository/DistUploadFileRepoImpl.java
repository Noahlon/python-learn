package com.hellobike.aicc.infrastructure.persistence.single.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DeleteEnum;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.distribute.entity.DistributeUploadFileEntity;
import com.hellobike.aicc.domain.distribute.repo.DistUploadFileRepo;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributeUploadFileCondition;
import com.hellobike.aicc.infrastructure.convert.DistributeUploadFileConvert;
import com.hellobike.aicc.infrastructure.persistence.single.mapper.DistributeUploadFileMapper;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributeUploadFilePO;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class DistUploadFileRepoImpl extends ServiceImpl<DistributeUploadFileMapper, DistributeUploadFilePO> implements DistUploadFileRepo {
    @Resource
    private IdGeneratorService idGeneratorService;
    @Resource
    private DistributeUploadFileConvert distributeUploadFileConvert;

    @Override
    public void saveOrUpdateUpLoadFile(DistributeUploadFileEntity distributeUploadFileEntity) {
        if (distributeUploadFileEntity.getId() == null) {
            distributeUploadFileEntity.setId(idGeneratorService.getLongId());
        }
        DistributeUploadFilePO po = distributeUploadFileConvert.convert(distributeUploadFileEntity);
        saveOrUpdate(po);
    }

    @Override
    public PageResult<DistributeUploadFileEntity> pageQueryUploadFile(DistributeUploadFileCondition condition) {
        LambdaQueryWrapper<DistributeUploadFilePO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributeUploadFilePO::getIsDelete, DeleteEnum.NO.getCode())
                .eq(StringUtils.isNotBlank(condition.getId()), DistributeUploadFilePO::getId, condition.getId())
                .eq(condition.getDistributePlanId() != null, DistributeUploadFilePO::getDistributePlanId, condition.getDistributePlanId())
                .like(StringUtils.isNotBlank(condition.getFileName()), DistributeUploadFilePO::getFileName, condition.getFileName());
        queryWrapper.orderByDesc(DistributeUploadFilePO::getCreateTime);
        Page<DistributeUploadFilePO> page = page(new Page<>(condition.getPageNum(), condition.getPageSize()), queryWrapper);
        return distributeUploadFileConvert.convert(page);
    }

    @Override
    public List<DistributeUploadFileEntity> queryByCondition(DistributeUploadFileCondition condition) {
        LambdaQueryWrapper<DistributeUploadFilePO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributeUploadFilePO::getIsDelete, DeleteEnum.NO.getCode())
                .eq(condition.getDistributePlanId() != null, DistributeUploadFilePO::getDistributePlanId, condition.getDistributePlanId())
                .in(CollectionUtils.isNotEmpty(condition.getStatusList()), DistributeUploadFilePO::getStatus, condition.getStatusList())
                .orderByAsc(DistributeUploadFilePO::getCreateTime);
        List<DistributeUploadFilePO> distributeUploadFilePOS = baseMapper.selectList(queryWrapper);
        return distributeUploadFileConvert.convert(distributeUploadFilePOS);
    }
}
