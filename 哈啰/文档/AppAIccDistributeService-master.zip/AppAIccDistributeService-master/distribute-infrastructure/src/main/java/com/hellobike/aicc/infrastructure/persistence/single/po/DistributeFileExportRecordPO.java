package com.hellobike.aicc.infrastructure.persistence.single.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 数据密级S2,分流平台文件导出记录
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-05-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_distribute_file_export_record")
public class DistributeFileExportRecordPO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id" ,type = IdType.INPUT)
    private Long id;

    /**
     * 数据密级S2,文件类型
     */
    @TableField("biz_type")
    private Integer bizType;

    /**
     * 数据密级S2,执行状态
     */
    @TableField("status")
    private Integer status;

    /**
     * 数据密级S2,文件名称
     */
    @TableField("file_name")
    private String fileName;

    /**
     * 数据密级S2,文件地址
     */
    @TableField("file_url")
    private String fileUrl;

    /**
     * 数据密级S2,导出失败原因
     */
    @TableField("fail_reason")
    private String failReason;

    /**
     * 数据密级S2,操作人姓名
     */
    @TableField("operator")
    private String operator;

    /**
     * 数据密级S2,导出数据量
     */
    @TableField("export_count")
    private Integer exportCount;

    /**
     * 数据密级S2,创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,是否删除
     */
    @TableField("is_delete")
    private Integer isDelete;


    public static final String BIZ_TYPE = "biz_type";

    public static final String STATUS = "status";

    public static final String FILE_NAME = "file_name";

    public static final String FILE_URL = "file_url";

    public static final String FAIL_REASON = "fail_reason";

    public static final String OPERATOR = "operator";

    public static final String EXPORT_COUNT = "export_count";

    public static final String CREATE_TIME = "create_time";

    public static final String UPDATE_TIME = "update_time";

    public static final String IS_DELETE = "is_delete";

}
