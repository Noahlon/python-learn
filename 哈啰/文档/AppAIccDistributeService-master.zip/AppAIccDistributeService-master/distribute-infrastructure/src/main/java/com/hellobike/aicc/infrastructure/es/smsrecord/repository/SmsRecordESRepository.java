package com.hellobike.aicc.infrastructure.es.smsrecord.repository;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hellobike.aicc.common.enums.SmsSendResultEnum;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.smsrecord.entity.ChannelTaskSmsStat;
import com.hellobike.aicc.domain.smsrecord.entity.DistPlanSmsStat;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordCondition;
import com.hellobike.aicc.infrastructure.es.BaseEsRepository;
import com.hellobike.aicc.infrastructure.es.EsPage;
import com.hellobike.aicc.infrastructure.es.EsQueryWrapper;
import com.hellobike.aicc.infrastructure.es.smsrecord.po.SmsRecordESPO;
import com.hellobike.es.sdk.common.EsApplication;
import com.hellobike.es.sdk.common.iface.ISearchRepository;
import com.hellobike.es.sdk.template.RestHighLevelClientFacade;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.support.IndicesOptions;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.filter.FilterAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.filter.ParsedFilter;
import org.elasticsearch.search.aggregations.bucket.terms.ParsedLongTerms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.ParsedCardinality;
import org.elasticsearch.search.aggregations.metrics.ParsedSum;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Slf4j
@Service
public class SmsRecordESRepository extends BaseEsRepository {
    private static final String SMS_RECORD_INDEX_PER = "aicc_distribute_sms_record_index";

    @Value("${es.search.max.size:10000}")
    private Long maxSize;

    @Value("${jest.client.indexMaxSize:120}")
    private Integer indexMaxSize;

    @Value("${jest.client.indexMaxSize.button:true}")
    private Boolean indexMaxSizeButton;

    @Override
    public String getIndex() {
        return SMS_RECORD_INDEX_PER;
    }

    public boolean save(List<SmsRecordESPO> smsRecordESPOList, LocalDateTime indexDate) {
        try {
            BulkRequest bulkRequest = new BulkRequest();
            for (SmsRecordESPO smsRecord : smsRecordESPOList) {
                String indexName = getIndex() + "-" + DateUtils.formatMonthEsIndex(indexDate);
                String jsonDocument;
                try {
                    ObjectMapper mapper = new ObjectMapper();
                    jsonDocument = mapper.writeValueAsString(smsRecord);
                } catch (JsonProcessingException e) {
                    throw new RuntimeException(e);
                }

                IndexRequest indexRequest = new IndexRequest(indexName)
                        .source(jsonDocument, XContentType.JSON)
                        .id(String.valueOf(smsRecord.getGuid()));

                bulkRequest.add(indexRequest);
            }
            return insertOrUpdateList(bulkRequest);
        }catch (Exception e){
            log.error("保存短信es失败,e:",e);
            return false;
        }
    }

    public EsPage<SmsRecordESPO> pageSmsRecord(SmsRecordCondition condition) {
        EsQueryWrapper esQueryWrapper = buildQryWrapperBySms(condition);
        List<String> indexes = buildSmsRecordIndex(condition);
        FieldSortBuilder sort;
        if (!StrUtil.isEmpty(condition.getSortRule())) {
            sort = SortBuilders.fieldSort(condition.getSortRule()).order(SortOrder.DESC);
        } else {
            sort = SortBuilders.fieldSort(SmsRecordESPO.CREATE_TIME).order(SortOrder.DESC);
        }
        int pageNum = Objects.isNull(condition.getPageNum()) ? 1 : condition.getPageNum();
        int pageSize = Objects.isNull(condition.getPageSize()) ? 10 : condition.getPageSize();

        List<SmsRecordESPO> currentPageData = new ArrayList<>();
        Object[] searchAfterValues;

        int fromIndex = (pageNum - 1) * pageSize;
        int requiredSize = fromIndex + pageSize;
        int fetchedSize = 0;
        long totalCount = count(esQueryWrapper, indexes);

        while (fetchedSize < requiredSize) {
            EsPage<SmsRecordESPO> esPage;
            try {
                esPage = searchWithSearchAfter(esQueryWrapper, SmsRecordESPO.class, sort, maxSize, indexes);
            } catch (IOException e) {
                log.error("roster.searchWithSearchAfter异常", e);
                throw new RuntimeException(e);
            }
            List<SmsRecordESPO> data = esPage.getData();

            if (data.isEmpty()) {
                break;
            }

            int toFetch = Math.min(data.size(), requiredSize - fetchedSize);
            currentPageData.addAll(data.subList(0, toFetch));
            fetchedSize += toFetch;

            // 下次查询值
            searchAfterValues = esPage.getNextSearchAfterValues();
            esQueryWrapper.setSearchAfterValues(searchAfterValues);

            //优化内存，剔除不需要的数据
            data.subList(0, toFetch).clear();
        }

        //计算最终需要的数据
        fromIndex = (pageNum - 1) * pageSize;
        int toIndex = Math.min(fromIndex + pageSize, currentPageData.size());

        List<SmsRecordESPO> pageData = currentPageData.subList(fromIndex, toIndex);
        return new EsPage<>(totalCount, pageNum, pageSize, pageData);

    }

    public List<ChannelTaskSmsStat> smsStatByChannelTask(SmsRecordCondition condition) {

        EsQueryWrapper esQueryWrapper = buildQryWrapperBySms(condition);
        List<String> indexList = buildSmsRecordIndex(condition);
        try {
            ISearchRepository searchRepository = EsApplication.getInstance().getSearchRepository(clusterName);
            RestHighLevelClientFacade client = searchRepository.getRestHighLevelClientFacade();
            //发送量
            AggregationBuilder sendSum = AggregationBuilders.cardinality("sendSum").field(SmsRecordESPO.ROSTER_ID);

            //发送成功量
            FilterAggregationBuilder succSum = AggregationBuilders
                    .filter("succSum", QueryBuilders.termQuery(SmsRecordESPO.SEND_RESULT, SmsSendResultEnum.SUCCESS.getCode()))
                    .subAggregation(AggregationBuilders.cardinality("succSum").field(SmsRecordESPO.ROSTER_ID));

            //计费数
            AggregationBuilder smsUnit = AggregationBuilders
                    .filter("smsUnit", QueryBuilders.termQuery(SmsRecordESPO.SEND_RESULT, SmsSendResultEnum.SUCCESS.getCode()))
                    .subAggregation(AggregationBuilders.sum("smsUnit").field(SmsRecordESPO.BILLING_NUM));

            TermsAggregationBuilder termsAggregationBuilder = AggregationBuilders
                    .terms("group_by_channel_task_id")
                    .field(SmsRecordESPO.CHANNEL_TASK_ID)
                    // 限制聚合数量为1000（统计1000个通道的信息）
                    .size(1000)
                    .subAggregation(sendSum)
                    .subAggregation(succSum)
                    .subAggregation(smsUnit);

            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(esQueryWrapper.build())
                    .aggregation(termsAggregationBuilder)
                    .size(0);

            String[] indexArray = buildIndex(indexList);
            SearchRequest searchRequest = new SearchRequest(indexArray);
            searchRequest.source(searchSourceBuilder);
            searchRequest.indicesOptions(IndicesOptions.fromOptions(true, false, true, false));

            SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
            if (searchResponse == null) {
                log.error("渠道任务短信记录统计response为null");
                return new ArrayList<>();
            }

            Aggregations aggregations = searchResponse.getAggregations();
            ParsedLongTerms term = aggregations.get("group_by_channel_task_id");

            List<ChannelTaskSmsStat> result = new ArrayList<>();
            for (Terms.Bucket bucket : term.getBuckets()) {
                Long channelTaskId = (Long) bucket.getKey();
                ChannelTaskSmsStat statisticEntity = new ChannelTaskSmsStat();
                statisticEntity.setChannelTaskId(String.valueOf(channelTaskId));

                Map<String, Aggregation> aggregationsAsMap = bucket.getAggregations().getAsMap();

                //发送量
                ParsedCardinality sendSumP = (ParsedCardinality) aggregationsAsMap.get("sendSum");

                //计费数
                ParsedFilter smsUnitFilter = (ParsedFilter) aggregationsAsMap.get("smsUnit");
                ParsedSum smsUnitP = smsUnitFilter.getAggregations().get("smsUnit");

                //接通话单量
                ParsedFilter smsSuccFilter = (ParsedFilter) aggregationsAsMap.get("succSum");
                ParsedCardinality smsSuccSumP = smsSuccFilter.getAggregations().get("succSum");

                statisticEntity.setSendSum(sendSumP.getValue());
                statisticEntity.setSmsUnit((long) smsUnitP.getValue());
                statisticEntity.setSuccSum(smsSuccSumP.getValue());
                result.add(statisticEntity);
            }
            return result;

        } catch (Exception e) {
            log.error("统计异常", e);
            return new ArrayList<>();
        }
    }

    public List<DistPlanSmsStat> smsStatByDistPlan(SmsRecordCondition condition) {

        EsQueryWrapper esQueryWrapper = buildQryWrapperBySms(condition);
        List<String> indexList = buildSmsRecordIndex(condition);
        try {
            ISearchRepository searchRepository = EsApplication.getInstance().getSearchRepository(clusterName);
            RestHighLevelClientFacade client = searchRepository.getRestHighLevelClientFacade();
            //发送量
            AggregationBuilder sendSum = AggregationBuilders.cardinality("sendSum").field(SmsRecordESPO.ROSTER_ID);

            //发送成功量
            FilterAggregationBuilder succSum = AggregationBuilders
                    .filter("succSum", QueryBuilders.termQuery(SmsRecordESPO.SEND_RESULT, SmsSendResultEnum.SUCCESS.getCode()))
                    .subAggregation(AggregationBuilders.cardinality("succSum").field(SmsRecordESPO.ROSTER_ID));

            //计费数
            AggregationBuilder smsUnit = AggregationBuilders
                    .filter("smsUnit", QueryBuilders.termQuery(SmsRecordESPO.SEND_RESULT, SmsSendResultEnum.SUCCESS.getCode()))
                    .subAggregation(AggregationBuilders.sum("smsUnit").field(SmsRecordESPO.BILLING_NUM));

            TermsAggregationBuilder termsAggregationBuilder = AggregationBuilders
                    .terms("group_by_dist_plan_id")
                    .field(SmsRecordESPO.DISTRIBUTE_PLAN_ID)
                    // 限制聚合数量为1000（统计1000个通道的信息）
                    .size(1000)
                    .subAggregation(sendSum)
                    .subAggregation(succSum)
                    .subAggregation(smsUnit);

            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(esQueryWrapper.build())
                    .aggregation(termsAggregationBuilder)
                    .size(0);

            String[] indexArray = buildIndex(indexList);
            SearchRequest searchRequest = new SearchRequest(indexArray);
            searchRequest.source(searchSourceBuilder);
            searchRequest.indicesOptions(IndicesOptions.fromOptions(true, false, true, false));

            SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
            if (searchResponse == null) {
                log.error("分流计划短信记录统计response为null");
                return new ArrayList<>();
            }

            Aggregations aggregations = searchResponse.getAggregations();
            ParsedLongTerms term = aggregations.get("group_by_dist_plan_id");

            List<DistPlanSmsStat> result = new ArrayList<>();
            for (Terms.Bucket bucket : term.getBuckets()) {
                Long planId = (Long) bucket.getKey();
                DistPlanSmsStat statisticEntity = new DistPlanSmsStat();
                statisticEntity.setPlanId(String.valueOf(planId));

                Map<String, Aggregation> aggregationsAsMap = bucket.getAggregations().getAsMap();

                //发送量
                ParsedCardinality sendSumP = (ParsedCardinality) aggregationsAsMap.get("sendSum");

                //计费数
                ParsedFilter smsUnitFilter = (ParsedFilter) aggregationsAsMap.get("smsUnit");
                ParsedSum smsUnitP = smsUnitFilter.getAggregations().get("smsUnit");

                //接通话单量
                ParsedFilter smsSuccFilter = (ParsedFilter) aggregationsAsMap.get("succSum");
                ParsedCardinality smsSuccSumP = smsSuccFilter.getAggregations().get("succSum");

                statisticEntity.setSendSum(sendSumP.getValue());
                statisticEntity.setSmsUnit((long) smsUnitP.getValue());
                statisticEntity.setSuccSum(smsSuccSumP.getValue());
                result.add(statisticEntity);
            }
            return result;

        } catch (Exception e) {
            log.error("统计异常", e);
            return new ArrayList<>();
        }
    }

    public DistPlanSmsStat smsStatByTenant(SmsRecordCondition condition) {
        EsQueryWrapper esQueryWrapper = buildQryWrapperBySms(condition);
        List<String> indexList = buildSmsRecordIndex(condition);
        try {
            ISearchRepository searchRepository = EsApplication.getInstance().getSearchRepository(clusterName);
            RestHighLevelClientFacade client = searchRepository.getRestHighLevelClientFacade();

            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(esQueryWrapper.build())
                    .aggregation(AggregationBuilders.sum("smsUnit").field(SmsRecordESPO.BILLING_NUM))
                    .aggregation(AggregationBuilders.cardinality("sendSum").field(SmsRecordESPO.ROSTER_ID))
                    .aggregation(AggregationBuilders.filter("succSum", QueryBuilders.termQuery(SmsRecordESPO.SEND_RESULT, SmsSendResultEnum.SUCCESS.getCode()))
                            .subAggregation(AggregationBuilders.cardinality("succSum").field(SmsRecordESPO.ROSTER_ID)))
                    .size(0);

            String[] indexArray = buildIndex(indexList);
            SearchRequest searchRequest = new SearchRequest(indexArray);
            searchRequest.source(searchSourceBuilder);
            searchRequest.indicesOptions(IndicesOptions.fromOptions(true, false, true, false));

            SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
            if (searchResponse == null) {
                log.error("租户短信记录统计response为null");
                return null;
            }

            Map<String, Aggregation> map = searchResponse.getAggregations().asMap();
            // 名单发送量
            ParsedCardinality sendSumP = (ParsedCardinality) map.get("sendSum");

            // 计费数
            ParsedSum smsUnitP = (ParsedSum) map.get("smsUnit");

            ParsedFilter smsSuccFilter = (ParsedFilter) map.get("succSum");
            ParsedCardinality smsSuccSumP = smsSuccFilter.getAggregations().get("succSum");

            DistPlanSmsStat statisticEntity = new DistPlanSmsStat();
            statisticEntity.setSendSum(sendSumP.getValue());
            statisticEntity.setSmsUnit((long) smsUnitP.getValue());
            statisticEntity.setSuccSum(smsSuccSumP.getValue());

            return statisticEntity;

        } catch (Exception e) {
            log.error("统计异常", e);
            return null;
        }
    }


    private EsQueryWrapper buildQryWrapperBySms(SmsRecordCondition condition) {
        EsQueryWrapper wrapper = new EsQueryWrapper();
        wrapper.eq(SmsRecordESPO.CHANNEL_ID, condition.getChannelId() == null ? null : String.valueOf(condition.getChannelId()));
        wrapper.eq(SmsRecordESPO.GUID, condition.getGuid());
        wrapper.eq(SmsRecordESPO.PLATFORM_ID, condition.getPlatformId());
        wrapper.eq(SmsRecordESPO.PHONE_NUMBER, condition.getPhoneNumber());
        wrapper.eq(SmsRecordESPO.PHONE_NUMBER_MD5, condition.getPhoneNumberMd5());
        wrapper.wildcard(SmsRecordESPO.DISTRIBUTE_PLAN_NAME, wildcardBuild(condition.getDistributePlanName()));
        wrapper.eq(SmsRecordESPO.DISTRIBUTE_PLAN_ID, condition.getDistributePlanId() == null ? null : condition.getDistributePlanId());
        wrapper.eqs(SmsRecordESPO.DISTRIBUTE_PLAN_ID, CollectionUtils.isEmpty(condition.getDistributePlanIdList()) ? null : condition.getDistributePlanIdList());
        wrapper.eq(SmsRecordESPO.SUPPLIER_TASK_ID, condition.getSupplierTaskId());
        wrapper.wildcard(SmsRecordESPO.SUPPLIER_TASK_NAME, wildcardBuild(condition.getSupplierTaskName()));
        wrapper.eqs(SmsRecordESPO.SEND_RESULT, condition.getSendResultList());
        wrapper.wildcard(SmsRecordESPO.SIGNATURE, wildcardBuild(condition.getSignature()));
        wrapper.wildcard(SmsRecordESPO.CONTENT, wildcardBuild(condition.getContent()));
        wrapper.gte(SmsRecordESPO.CREATE_TIME, Objects.nonNull(condition.getCreateBeginTime()) ? DateUtils.format(condition.getCreateBeginTime()) : null);
        wrapper.lte(SmsRecordESPO.CREATE_TIME, Objects.nonNull(condition.getCreateEndTime()) ? DateUtils.format(condition.getCreateEndTime()) : null);
        wrapper.gte(SmsRecordESPO.SEND_TIME, StringUtils.isBlank(condition.getSendBeginTime()) ? null : condition.getSendBeginTime());
        wrapper.lte(SmsRecordESPO.SEND_TIME, StringUtils.isBlank(condition.getSendEndTime()) ? null : condition.getSendEndTime());
        wrapper.gte(SmsRecordESPO.RECEIVE_RESULT_TIME, StringUtils.isBlank(condition.getReceiveResultBeginTime()) ? null : condition.getReceiveResultBeginTime());
        wrapper.lte(SmsRecordESPO.RECEIVE_RESULT_TIME, StringUtils.isBlank(condition.getReceiveResultEndTime()) ? null : condition.getReceiveResultEndTime());
        wrapper.eq(SmsRecordESPO.SEATS_NAME, condition.getSeatsName());
        wrapper.eq(SmsRecordESPO.SUPPLIER_CALL_GUID, condition.getSupplierCallGuid());
        wrapper.eqs(SmsRecordESPO.CITY, condition.getCityList());
        wrapper.eqs(SmsRecordESPO.CARRIER, condition.getCarrierList());
        return wrapper;
    }

    private List<String> buildSmsRecordIndex(SmsRecordCondition condition) {
        // 索引范围优先级 传入的索引 > 创建时间范围 > 全部索引
        if (CollectionUtil.isNotEmpty(condition.getIndexes())) {
            return condition.getIndexes();
        }

        List<String> monthBetween = DateUtils.getMonthBetween(condition.getCreateBeginTime(), condition.getCreateEndTime());
        if (CollectionUtil.isEmpty(monthBetween) || (monthBetween.size() > indexMaxSize && indexMaxSizeButton)) {
            return Collections.singletonList("20*");
        } else {
            return monthBetween;
        }
    }

    public long countSmsRecord(SmsRecordCondition condition) {
        EsQueryWrapper wrapper = buildQryWrapperBySms(condition);
        return count(wrapper, buildSmsRecordIndex(condition));
    }


    public EsPage<SmsRecordESPO> scrollQueryForExport(SmsRecordCondition condition, String scrollId) {
        EsQueryWrapper esQueryWrapper = buildQryWrapperBySms(condition);
        List<String> indexes = buildSmsRecordIndex(condition);
        FieldSortBuilder sort;
        if (!StrUtil.isEmpty(condition.getSortRule())) {
            sort = SortBuilders.fieldSort(condition.getSortRule()).order(SortOrder.DESC);
        } else {
            sort = SortBuilders.fieldSort(SmsRecordESPO.CREATE_TIME).order(SortOrder.DESC);
        }
        try {
            EsPage<SmsRecordESPO> page = searchWithScrollV2(esQueryWrapper, SmsRecordESPO.class, CACHE_TIME_10, maxSize, indexes, sort, SmsRecordESPO.GUID, false, scrollId);
            log.info("短信记录ES滚动查询 scrollId {}", page.getScrollId());
            return page;
        } catch (Exception e) {
            log.error("短信ES滚动查询异常，e:", e);
            throw new RuntimeException(e);
        }
    }
}
