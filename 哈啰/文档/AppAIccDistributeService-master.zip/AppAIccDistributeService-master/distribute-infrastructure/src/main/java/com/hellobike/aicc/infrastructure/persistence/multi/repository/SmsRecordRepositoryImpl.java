package com.hellobike.aicc.infrastructure.persistence.multi.repository;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DeleteEnum;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.smsrecord.dto.SmsRecordScrollQueryDTO;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordCondition;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;
import com.hellobike.aicc.domain.smsrecord.repo.SmsRecordRepository;
import com.hellobike.aicc.infrastructure.convert.SmsRecordInfConvert;
import com.hellobike.aicc.infrastructure.es.EsPage;
import com.hellobike.aicc.infrastructure.es.smsrecord.po.SmsRecordESPO;
import com.hellobike.aicc.infrastructure.es.smsrecord.repository.SmsRecordESRepository;
import com.hellobike.aicc.infrastructure.persistence.multi.mapper.SmsRecordMapper;
import com.hellobike.aicc.infrastructure.persistence.multi.po.SmsRecordPO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Objects;

@Service
@Slf4j
public class SmsRecordRepositoryImpl extends ServiceImpl<SmsRecordMapper, SmsRecordPO> implements SmsRecordRepository {
    @Resource
    private SmsRecordInfConvert smsRecordInfConvert;

    @Resource
    private SmsRecordESRepository smsRecordESRepository;

    @Override
    public SmsRecordEntity getById(Long id, String phoneNumMd5) {
        if (Objects.isNull(id) || StrUtil.isBlank(phoneNumMd5)) {
            return null;
        }
        LambdaQueryWrapper<SmsRecordPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(SmsRecordPO::getGuid, id)
                .eq(SmsRecordPO::getPhoneNumberMd5, phoneNumMd5)
                .eq(SmsRecordPO::getIsDelete, DeleteEnum.NO.getCode());
        SmsRecordPO po = getOne(queryWrapper, false);
        return smsRecordInfConvert.convert2Entity(po);
    }

    @Override
    @Transactional(transactionManager = "dataSourceTransactionManager2", rollbackFor = Exception.class)
    public boolean save(SmsRecordEntity entity) {
        SmsRecordPO smsRecordPO = smsRecordInfConvert.convert2po(entity);
        LocalDateTime nowTime = LocalDateTime.now();
        smsRecordPO.setCreateTime(nowTime);
        smsRecordPO.setUpdateTime(nowTime);
        smsRecordPO.setIsDelete(DeleteEnum.NO.getCode());

        boolean isSave = save(smsRecordPO);
        if (!isSave) {
            log.error("DB保存短信记录失败，源短信记录id为:{}", entity.getSupplierSmsGuid());
            return false;
        }

        SmsRecordESPO smsRecordESPO = smsRecordInfConvert.convert2EsPo(smsRecordPO);
        boolean isSaveES = smsRecordESRepository.save(Collections.singletonList(smsRecordESPO), smsRecordPO.getCreateTime());
        if (!isSaveES) {
            log.error("ES保存短信记录失败，源短信记录id为:{}", entity.getSupplierSmsGuid());
            throw new RuntimeException("ES保存短信记录失败");
        }
        return true;
    }

    @Override
    public SmsRecordEntity getSmsRecordBySupplier(String supplierSmsGuid, String phoneNumberMd5, Integer channelId) {
        if (StrUtil.isBlank(supplierSmsGuid) || StrUtil.isBlank(phoneNumberMd5)) {
            return null;
        }
        LambdaQueryWrapper<SmsRecordPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper
                .eq(SmsRecordPO::getSupplierSmsGuid, supplierSmsGuid)
                .eq(SmsRecordPO::getPhoneNumberMd5, phoneNumberMd5)
                .eq(Objects.nonNull(channelId), SmsRecordPO::getChannelId, channelId)
                .eq(SmsRecordPO::getIsDelete, DeleteEnum.NO.getCode());
        SmsRecordPO smsRecordPO = getOne(queryWrapper, false);
        return smsRecordInfConvert.convert2Entity(smsRecordPO);
    }

    @Override
    @Transactional(transactionManager = "dataSourceTransactionManager2", rollbackFor = Exception.class)
    public boolean updateById(SmsRecordEntity entity) {
        SmsRecordPO smsRecordPO = smsRecordInfConvert.convert2po(entity);
        LambdaUpdateWrapper<SmsRecordPO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper
                .eq(SmsRecordPO::getGuid, smsRecordPO.getGuid())
                .eq(SmsRecordPO::getPhoneNumberMd5, smsRecordPO.getPhoneNumberMd5());
        boolean isSave = update(smsRecordPO, updateWrapper);
        if (!isSave) {
            log.error("DB保存短信记录失败，源短信记录id为: {}", entity.getSupplierSmsGuid());
            return false;
        }
        //保存es
        SmsRecordESPO smsRecordESPO = smsRecordInfConvert.convert2EsPo(smsRecordPO);
        boolean isSaveES = smsRecordESRepository.save(Collections.singletonList(smsRecordESPO), smsRecordPO.getCreateTime());
        if (!isSaveES) {
            log.error("ES保存短信记录失败，源短信记录id为: {}", entity.getSupplierSmsGuid());
            throw new RuntimeException("ES保存短信记录失败");
        }
        return true;
    }

    @Override
    public PageResult<SmsRecordEntity> pageQuerySmsRecord(SmsRecordCondition condition) {
        try {
            EsPage<SmsRecordESPO> esPage = smsRecordESRepository.pageSmsRecord(condition);
            if (Objects.isNull(esPage) || CollectionUtil.isEmpty(esPage.getData())) {
                return PageResult.getEmptyPage(condition.getPageNum(), condition.getPageSize());
            }

            return smsRecordInfConvert.esPageToPageResult(esPage);
        } catch (Exception e) {
            log.error("分页查询短信记录错误,e:", e);
            return PageResult.getEmptyPage(condition.getPageNum(), condition.getPageSize());
        }
    }

    @Override
    public long countSmsRecord(SmsRecordCondition condition) {
        return smsRecordESRepository.countSmsRecord(condition);
    }

    @Override
    public SmsRecordScrollQueryDTO listSmsForExport(SmsRecordCondition condition, String scrollId) {
        EsPage<SmsRecordESPO> esPage = smsRecordESRepository.scrollQueryForExport(condition, scrollId);
        SmsRecordScrollQueryDTO scrollQueryDTO = new SmsRecordScrollQueryDTO();
        scrollQueryDTO.setScrollId(esPage.getScrollId());
        scrollQueryDTO.setSmsRecordList(smsRecordInfConvert.convert(esPage.getData()));
        return scrollQueryDTO;
    }

    @Override
    public boolean updateWhenCheckStatus(SmsRecordEntity smsRecord, Integer beforeStatus, Integer afterStatus) {
        SmsRecordPO smsRecordPO = smsRecordInfConvert.convert2po(smsRecord);
        smsRecordPO.setUpdateTime(LocalDateTime.now());
        LambdaUpdateWrapper<SmsRecordPO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper
                .eq(SmsRecordPO::getGuid, smsRecord.getGuid())
                .eq(SmsRecordPO::getPhoneNumberMd5, smsRecord.getPhoneNumberMd5())
                .eq(SmsRecordPO::getSendResult, beforeStatus)
                .eq(SmsRecordPO::getIsDelete, DeleteEnum.NO.getCode())
                .set(SmsRecordPO::getSendResult, afterStatus);
        boolean isSave = update(updateWrapper);
        if (!isSave) {
            log.info("修改短信记录失败，po: {}", BaseJsonUtils.writeValue(smsRecordPO));
            return false;
        }
        //保存es
        SmsRecordESPO smsRecordESPO = smsRecordInfConvert.convert2EsPo(smsRecordPO);
        boolean isSaveES = smsRecordESRepository.save(Collections.singletonList(smsRecordESPO), smsRecordPO.getCreateTime());
        if (!isSaveES) {
            log.error("ES保存短信记录失败，po: {}", BaseJsonUtils.writeValue(smsRecordPO));

            return true;
        }
        return true;
    }
}
