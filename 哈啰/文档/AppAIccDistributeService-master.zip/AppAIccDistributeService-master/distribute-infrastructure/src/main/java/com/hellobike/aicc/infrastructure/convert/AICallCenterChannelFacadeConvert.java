package com.hellobike.aicc.infrastructure.convert;

import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.dto.ChannelTaskCreateDTO;
import com.hellobike.aicc.domain.distribute.entity.DistributeRuleEntity;
import com.hellobike.css.ai.api.iface.task.request.CreateTaskByTemplateGuidRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", imports = {BaseJsonUtils.class, DistributeRuleEntity.class})
public interface AICallCenterChannelFacadeConvert {
    @Mapping(target = "templateGuid", source = "taskTemplateId")
    CreateTaskByTemplateGuidRequest convert(ChannelTaskCreateDTO dto);
}
