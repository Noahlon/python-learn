package com.hellobike.aicc.infrastructure.es.calldialogue.condition;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-12  10:24:14
 */
@Data
public class CallDialogueESCondition implements Serializable {

    private static final long serialVersionUID = -9219223547613950639L;

    /**
     * es索引后缀（日期格式：yyyyMMdd）
     */
    private List<String> indexes;

    /**
     * 页大小
     */
    private Integer pageSize;

    /**
     * 页码
     */
    private Integer pageNum;

    /**
     * 话单id
     */
    private String id;

    /**
     * 平台数据标识
     */
    private String platformId;

    /**
     * 分流计划名称
     */
    private String distributePlanName;

    /**
     * 分流计划ID
     */
    private String distributePlanId;

    /**
     * 分流计划ID
     */
    private List<String> distributePlanIdList;

    /**
     * 小写md5
     */
    private String md5;

    /**
     * 被叫号码
     */
    private String calledNumber;

    /**
     * 被叫号码集合
     */
    private List<String> calledNumberList;

    /**
     * 三方任务id
     */
    private String supplierTaskId;

    /**
     * 三方任务名称
     */
    private String supplierTaskName;

    /**
     * 呼叫结果
     */
    private List<Integer> callResultList;

    /**
     * 意向分类Code
     */
    private Integer intentClassify;

    /**
     * 意向分类Code集合
     */
    private List<String> intentClassifyList;

    /**
     * 意向分类名称
     */
    private String intentClassifyName;

    /**
     * 命中意图
     */
    private List<String> hitIntentions;

    /**
     * 不包含-命中意图
     */
    private List<String> excludeIntentions;

    /**
     * 是否触发短信
     */
    private Integer isHitSms;

    /**
     * 坐席姓名
     */
    private String seatName;

    /**
     * AI通话时长开始
     */
    private Integer durationCallAiStart;

    /**
     * AI通话时长结束
     */
    private Integer durationCallAiEnd;

    /**
     * 人工通话时长开始
     */
    private Integer durationCallManualStart;

    /**
     * 人工通话时长结束
     */
    private Integer durationCallManualEnd;

    /**
     * 中继外显号码
     */
    private String realCallingNumber;

    /**
     * 呼叫时长起始
     */
    private Integer totalTimeStart;

    /**
     * 呼叫时长终止
     */
    private Integer totalTimeEnd;

    /**
     * 振铃时长开始
     */
    private Integer ringTimeStart;

    /**
     * 振铃时长结束
     */
    private Integer ringTimeEnd;

    /**
     * 开始呼叫时间起始
     */
    private LocalDateTime dialTimeStart;

    /**
     * 开始呼叫时间结束
     */
    private LocalDateTime dialTimeEnd;

    /**
     * 挂断时间起始
     */
    private LocalDateTime hangupTimeStart;

    /**
     * 挂断时间截止
     */
    private LocalDateTime hangupTimeEnd;

    /**
     * 通话类型
     */
    private Integer callType;

    /**
     * 主叫号
     */
    private String callingNumber;

    /**
     * 计费单元数开始
     */
    private Integer costUnitStart;

    /**
     * 计费单元数截止
     */
    private Integer costUnitEnd;

    /**
     * 通话唯一ID
     */
    private String dialogueGuid;

    /**
     * 号码归属城市集合
     */
    private List<String> citys;

    /**
     * 运营商
     */
    private List<Integer> carrierList;

    /**
     * 对话轮次开始
     */
    private Integer speechCountStart;

    /**
     * 对话轮次截止
     */
    private Integer speechCountEnd;

    /**
     * 性别 (1男 2女)
     */
    private Integer sex;

    /**
     * 挂断方 (0：未知；1：机器人；2：客户)
     */
    private Integer releaseInitiator;

    /**
     * 排序规则
     */
    private String sortRule;

    /**
     * 创建时间-开始
     */
    private LocalDateTime createTimeStart;

    /**
     * 创建时间-结束
     */
    private LocalDateTime createTimeEnd;

    /**
     * 渠道任务ID
     */
    private String channelTaskId;

    /**
     * 渠道id
     */
    private Integer channelId;

    /**
     * 租户id
     */
    private String tenantId;
}
