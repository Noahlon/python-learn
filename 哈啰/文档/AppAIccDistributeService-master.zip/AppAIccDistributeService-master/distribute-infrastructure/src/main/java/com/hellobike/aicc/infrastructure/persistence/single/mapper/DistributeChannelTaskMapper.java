package com.hellobike.aicc.infrastructure.persistence.single.mapper;

import com.hellobike.aicc.infrastructure.persistence.single.po.DistributeChannelTaskPO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 数据密级S2,分流渠道任务表 Mapper 接口
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
public interface DistributeChannelTaskMapper extends BaseMapper<DistributeChannelTaskPO> {

}
