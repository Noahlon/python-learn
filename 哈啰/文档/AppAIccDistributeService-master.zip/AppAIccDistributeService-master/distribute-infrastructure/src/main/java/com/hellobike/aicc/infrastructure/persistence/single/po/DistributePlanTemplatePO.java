package com.hellobike.aicc.infrastructure.persistence.single.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hellobike.aicc.domain.distribute.entity.DistributeRuleEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 数据密级S2,分流计划模版
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_distribute_plan_template")
public class DistributePlanTemplatePO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id" ,type = IdType.INPUT)
    private Long id;

    /**
     * 数据密级S2,模板名称
     */
    @TableField("template_name")
    private String templateName;

    /**
     * 数据密级S2,租户id
     */
    @TableField("tenant_code")
    private String tenantCode;

    /**
     * 数据密级S2,租户名称
     */
    @TableField("tenant_name")
    private String tenantName;

    /**
     * 数据密级S2,分流类型，1-实时分流，2-离线分流
     */
    @TableField("distribute_type")
    private Integer distributeType;

    /**
     * 数据密级S2,分流类型描述
     */
    @TableField("distribute_type_desc")
    private String distributeTypeDesc;

    /**
     * 数据密级S2,分流规则
     */
    @TableField("distribute_rule")
    private String distributeRule;


    /**
     * 数据密级S2,创建人
     */
    @TableField("creator")
    private String creator;

    /**
     * 数据密级S2,最近使用时间
     */
    @TableField("latest_using_time")
    private LocalDateTime latestUsingTime;

    /**
     * 数据密级S2,创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,逻辑删除
     */
    @TableField("is_delete")
    private Integer isDelete;


    public static final String TEMPLATE_NAME = "template_name";

    public static final String TENANT_CODE = "tenant_code";

    public static final String TENANT_NAME = "tenant_name";

    public static final String DISTRIBUTE_TYPE = "distribute_type";

    public static final String DISTRIBUTE_TYPE_DESC = "distribute_type_desc";

    public static final String DISTRIBUTE_RULE = "distribute_rule";

    public static final String CREATOR = "creator";

    public static final String LATEST_USING_TIME = "latest_using_time";

    public static final String CREATE_TIME = "create_time";

    public static final String UPDATE_TIME = "update_time";

    public static final String IS_DELETE = "is_delete";

}
