package com.hellobike.aicc.infrastructure.persistence.single.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributeUploadFilePO;

/**
 * <p>
 * 数据密级S2,分流计划文件上传Mapper 接口
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
public interface DistributeUploadFileMapper extends BaseMapper<DistributeUploadFilePO> {

}
