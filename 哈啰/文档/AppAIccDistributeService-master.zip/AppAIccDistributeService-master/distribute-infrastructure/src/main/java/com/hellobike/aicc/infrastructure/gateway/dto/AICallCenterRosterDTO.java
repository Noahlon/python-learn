package com.hellobike.aicc.infrastructure.gateway.dto;

import lombok.Data;

/**
 * @author zhangzhuoqi
 * @since 2025-03-18  13:56:06
 */
@Data
public class AICallCenterRosterDTO {

    /**
     * 手机号
     */
    private String phone;

    /**
     * 手机号md5
     */
    private String md5Phone;

    /**
     * 客户名称
     */
    private String name;

    /**
     * 变量信息 json格式
     */
    private String variableInfos;

    /**
     * 外部id
     */
    private String externalId;
}
