package com.hellobike.aicc.infrastructure.persistence.multi.repository;
import com.google.common.collect.Lists;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DeleteEnum;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.domain.dialogue.dto.CallDialogueQueryConditionDTO;
import com.hellobike.aicc.domain.dialogue.dto.CallDialogueScrollQueryDTO;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import com.hellobike.aicc.domain.dialogue.repo.CallDialogueRepository;
import com.hellobike.aicc.infrastructure.convert.CallDialogueInfConvert;
import com.hellobike.aicc.infrastructure.es.EsPage;
import com.hellobike.aicc.infrastructure.es.calldialogue.condition.CallDialogueESCondition;
import com.hellobike.aicc.infrastructure.es.calldialogue.po.CallDialogueESPO;
import com.hellobike.aicc.infrastructure.es.calldialogue.repository.CallDialogueESRepository;
import com.hellobike.aicc.infrastructure.persistence.multi.mapper.CallDialogueMapper;
import com.hellobike.aicc.infrastructure.persistence.multi.po.CallDialoguePO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * 数据密级S2,分流平台话单 服务实现类
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Service
@Slf4j
public class CallDialogueRepositoryImpl extends ServiceImpl<CallDialogueMapper, CallDialoguePO> implements CallDialogueRepository {

    @Resource
    private CallDialogueInfConvert callDialogueInfConvert;

    @Resource
    private CallDialogueESRepository callDialogueESRepository;

    @Override
    public boolean save(CallDialogueEntity callDialogueEntity) {

        String dialogueGuid = callDialogueEntity.getDialogueGuid();
        String calledNumber = callDialogueEntity.getCalledNumber();
        AssertUtils.notNull(dialogueGuid, "三方话单id不能为空");
        AssertUtils.notNull(calledNumber, "被叫号不能为空");

        CallDialoguePO callDialoguePO = callDialogueInfConvert.toPO(callDialogueEntity);
        LocalDateTime nowTime = LocalDateTime.now();
        callDialoguePO.setUpdateTime(nowTime);

        boolean isSave;

        callDialoguePO.setCreateTime(nowTime);
        isSave = this.save(callDialoguePO);

        if (!isSave) {
            log.error("DB保存话单失败，dialogueGuid:{},calledNumber:{}", dialogueGuid, calledNumber);
            return false;
        }
        //保存es
        CallDialogueESPO callDialogueESPO = callDialogueInfConvert.poToES(callDialoguePO);
        callDialogueESPO.setIndexDate(nowTime);
        callDialogueESPO.setIsDelete(DeleteEnum.NO.getCode());
        boolean isSaveES = callDialogueESRepository.save(Collections.singletonList(callDialogueESPO));
        if (!isSaveES) {
            log.error("ES保存话单失败，dialogueGuid:{},calledNumber:{}", dialogueGuid, calledNumber);
            return true;
        }
        return true;
    }

    @Override
    public boolean updateById(CallDialogueEntity callDialogueEntity) {
        String dialogueGuid = callDialogueEntity.getDialogueGuid();
        String calledNumber = callDialogueEntity.getCalledNumber();
        AssertUtils.notNull(dialogueGuid, "三方话单id不能为空");
        AssertUtils.notNull(calledNumber, "被叫号不能为空");
        AssertUtils.notNull(callDialogueEntity.getId(), "话单id不能为空");

        CallDialoguePO callDialoguePO = callDialogueInfConvert.toPO(callDialogueEntity);
        LocalDateTime nowTime = LocalDateTime.now();
        callDialoguePO.setUpdateTime(nowTime);

        boolean isSave;

        callDialoguePO.setCreateTime(callDialogueEntity.getCreateTime());
        callDialoguePO.setId(callDialogueEntity.getId());
        LambdaUpdateWrapper<CallDialoguePO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper
                .eq(CallDialoguePO::getId, callDialogueEntity.getId())
                .eq(CallDialoguePO::getCalledNumber, calledNumber);
        isSave = this.update(callDialoguePO, updateWrapper);

        if (!isSave) {
            log.error("DB保存话单失败，dialogueGuid:{},calledNumber:{}", dialogueGuid, calledNumber);
            return false;
        }
        //保存es
        CallDialogueESPO callDialogueESPO = callDialogueInfConvert.poToES(callDialoguePO);
        callDialogueESPO.setIndexDate(nowTime);
        callDialogueESPO.setIsDelete(DeleteEnum.NO.getCode());
        boolean isSaveES = callDialogueESRepository.save(Collections.singletonList(callDialogueESPO));
        if (!isSaveES) {
            log.error("ES保存话单失败，dialogueGuid:{},calledNumber:{}", dialogueGuid, calledNumber);
            return true;
        }
        return true;
    }

    @Override
    public PageResult<CallDialogueEntity> pageCallDialogue(CallDialogueQueryConditionDTO condition, Integer pageNum, Integer pageSize) {
        CallDialogueESCondition esCondition = callDialogueInfConvert.toESCondition(condition);
        esCondition.setPageNum(pageNum);
        esCondition.setPageSize(pageSize);
        try {
            EsPage<CallDialogueESPO> esPage = callDialogueESRepository.pageCallDialogue(esCondition);
            if (Objects.isNull(esPage) || CollectionUtil.isEmpty(esPage.getData())) {
                return PageResult.getEmptyPage(pageNum, pageSize);
            }

            return callDialogueInfConvert.esPageToPageResult(esPage);
        } catch (Exception e) {
            log.error("分页查询话单错误,e:", e);
            return PageResult.getEmptyPage(pageNum, pageSize);
        }

    }

    @Override
    public CallDialogueEntity getCallDialogueBySupplier(String dialogueGuid, String calledNumber, Integer channelId) {
        if (StrUtil.isBlank(dialogueGuid) || StrUtil.isBlank(calledNumber)){
            return null;
        }
        LambdaQueryWrapper<CallDialoguePO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper
                .eq(CallDialoguePO::getDialogueGuid, dialogueGuid)
                .eq(CallDialoguePO::getCalledNumber, calledNumber)
                .eq(Objects.nonNull(channelId), CallDialoguePO::getChannelId, channelId)
                .eq(CallDialoguePO::getIsDelete, DeleteEnum.NO.getCode());
        queryWrapper.select(CallDialoguePO::getId,CallDialoguePO::getCreateTime);
        CallDialoguePO callDialoguePO = getOne(queryWrapper, false);
        return callDialogueInfConvert.toEntity(callDialoguePO);

    }

    @Override
    public CallDialogueEntity getDetail(Long id, String calledNumber) {
        if (Objects.isNull(id) || StrUtil.isBlank(calledNumber)){
            return null;
        }
        LambdaQueryWrapper<CallDialoguePO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper
                .eq(CallDialoguePO::getId, id)
                .eq(CallDialoguePO::getCalledNumber, calledNumber)
                .eq(CallDialoguePO::getIsDelete, DeleteEnum.NO.getCode());
        CallDialoguePO callDialoguePO = getOne(queryWrapper, false);
        return callDialogueInfConvert.toEntity(callDialoguePO);
    }

    @Override
    public CallDialogueScrollQueryDTO listDialogueForExport(CallDialogueQueryConditionDTO condition, String scrollId) {
        CallDialogueESCondition esCondition = callDialogueInfConvert.toESCondition(condition);
        EsPage<CallDialogueESPO> esPage = callDialogueESRepository.scrollQueryForExport(esCondition, scrollId);
        CallDialogueScrollQueryDTO scrollQueryDTO = new CallDialogueScrollQueryDTO();
        scrollQueryDTO.setScrollId(esPage.getScrollId());
        scrollQueryDTO.setDialogueList(callDialogueInfConvert.esPOListToEntityList(esPage.getData()));
        return scrollQueryDTO;
    }

    @Override
    public long countCallDialogue(CallDialogueQueryConditionDTO condition) {
        CallDialogueESCondition esCondition = callDialogueInfConvert.toESCondition(condition);
        return callDialogueESRepository.countCallDialogue(esCondition);
    }


}
