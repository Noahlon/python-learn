package com.hellobike.aicc.infrastructure.job;

import com.hellobike.aicc.domain.roster.service.RosterDomainService;
import com.hellobike.base.flexjob.common.model.base.ReturnT;
import com.hellobike.base.flexjob.common.participant.ParticipantParams;
import com.hellobike.base.flexjob.participant.starter.spring.JobHandle;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * 名单离线聚合下发-定时任务
 *
 * @author zhangzhuoqi
 * @since 2025-03-21  14:19:36
 */
@Service
@Slf4j
@JobHandle("rosterAggDistributeJob")
public class RosterAggDistributeJob {

    @Resource
    private RosterDomainService rosterDomainService;

    public ReturnT<String> trigger(ParticipantParams params) {
        try {
            rosterDomainService.aggDistribute();
            return new ReturnT<>(ReturnT.SUCCESS_CODE, "名单离线聚合下发执行完毕");
        }catch (Exception e){
            log.error("名单离线聚合下发执行失败，e:",e);
            return new ReturnT<>(ReturnT.FAIL_CODE, "名单离线聚合下发执行失败");
        }
    }
}
