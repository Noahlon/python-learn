package com.hellobike.aicc.infrastructure.hms.consumer.dialogue;

import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.dto.ChannelDialoguePushDTO;
import com.hellobike.aicc.domain.channelcallback.service.CallbackService;
import com.hellobike.aicc.domain.common.service.DingTalkService;
import com.hellobike.aicc.infrastructure.hms.consumer.BaseMsgConsumer;
import com.hellobike.hms.sdk.consumer.ConsumeMessage;
import com.hellobike.hms.sdk.consumer.MsgRetryStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Objects;

/**
 *
 */
@Slf4j
@Component
public class ChannelDialogueMsgConsumer extends BaseMsgConsumer {
    private static final String CONSUMER = "aicc_channel_dialogue_callback_topic_local_consumer";

    @Resource
    private CallbackService callbackService;

    @Resource
    private DingTalkService dingTalkService;

    @Override
    protected String getConsumerName() {
        return CONSUMER;
    }

    @Override
    public MsgRetryStatus msgProcess(ConsumeMessage mqMessage) {
        try {
            doConsumer(mqMessage);
        } catch (Exception e) {
            log.error("消费渠道话单记录异常,e:", e);
            dingTalkService.sendDialogueFailedAlert(mqMessage.getKey());
        }
        return MsgRetryStatus.SUCCEED;
    }

    private void doConsumer(ConsumeMessage mqMessage) {
        String msgBody = new String(mqMessage.getPayload());
        log.info("渠道话单记录消息key:{}", mqMessage.getKey());
        ChannelDialoguePushDTO dialoguePushDTO = BaseJsonUtils.readValue(msgBody, ChannelDialoguePushDTO.class);
        if (Objects.isNull(dialoguePushDTO) || Objects.isNull(dialoguePushDTO.getChannelId()) || Objects.isNull(dialoguePushDTO.getDialogueCallBackDTO())) {
            log.error("渠道话单消息为空, 或者渠道id为空dto:{}", dialoguePushDTO);
            return;
        }
        callbackService.callDialogueCallBack(dialoguePushDTO.getDialogueCallBackDTO(), dialoguePushDTO.getChannelId());
    }
}
