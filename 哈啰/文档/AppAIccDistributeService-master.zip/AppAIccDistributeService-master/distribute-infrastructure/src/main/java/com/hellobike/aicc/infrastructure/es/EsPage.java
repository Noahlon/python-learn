package com.hellobike.aicc.infrastructure.es;

import lombok.Data;

import java.util.List;


@Data
public class EsPage<T> {
    private long totalSize;
    private int currentPage;
    private int pageSize;
    private List<T> data;
    private Object[] nextSearchAfterValues;

    public EsPage() {
    }

    public EsPage(long totalSize, int currentPage, int pageSize, List<T> data) {
        this.totalSize = totalSize;
        this.currentPage = currentPage;
        this.pageSize = pageSize;
        this.data = data;
    }

    public EsPage(int totalSize, int currentPage, int pageSize, List<T> data, Object[] nextSearchAfterValues, String scrollId) {
        this.totalSize = totalSize;
        this.currentPage = currentPage;
        this.pageSize = pageSize;
        this.data = data;
        this.nextSearchAfterValues = nextSearchAfterValues;
        this.scrollId = scrollId;
    }

    /**
     * 滚动id
     */
    private String scrollId;

    public boolean hasNext() {
        return this.currentPage < getTotalPages();
    }

    public long getTotalPages() {
        return this.totalSize / this.pageSize + (this.totalSize % this.pageSize > 0 ? 1 : 0);
    }
}