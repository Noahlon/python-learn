package com.hellobike.aicc.infrastructure.job;

import cn.hutool.core.collection.CollectionUtil;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributeRuleEntity;
import com.hellobike.aicc.domain.distribute.repo.DistChannelTaskRepo;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.base.flexjob.common.model.base.ReturnT;
import com.hellobike.base.flexjob.common.participant.ParticipantParams;
import com.hellobike.base.flexjob.participant.starter.spring.JobHandle;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 渠道任务表，三方任务模版名称历史数据修复
 * @author zhangzhuoqi
 * @since 2025-06-10  13:25:38
 */
@Service
@Slf4j
@JobHandle("channelTaskDataFixJob")
public class ChannelTaskDataFixJob {

    @Resource
    private DistPlanRepo distPlanRepo;

    @Resource
    private DistChannelTaskRepo distChannelTaskRepo;

    public ReturnT<String> trigger(ParticipantParams params) {
        log.info("开始处理三方任务模版名称历史数据修复");
        try {
            doTrigger();
            return new ReturnT<>(ReturnT.SUCCESS_CODE, "三方任务模版名称历史数据修复执行完毕");
        } catch (Exception e) {
            log.error("三方任务模版名称历史数据修复任务异常", e);
            return new ReturnT<>(ReturnT.FAIL_CODE, "三方任务模版名称历史数据修复任务异常");
        }
    }

    private void doTrigger() {
        //查询全量分流计划
        List<DistributePlanEntity> planEntityList = distPlanRepo.queryAllEffectiveDistPlans();
        for (DistributePlanEntity planEntity : planEntityList) {
            List<DistributeRuleEntity> distributeRuleList = planEntity.getDistributeRuleList();
            if (CollectionUtil.isEmpty(distributeRuleList)){
                continue;
            }
            Map<String, String> templateMap = distributeRuleList.stream().collect(Collectors.toMap(DistributeRuleEntity::getTaskTemplateId, DistributeRuleEntity::getTaskTemplateName));
            List<DistributeChannelTaskEntity> taskList = distChannelTaskRepo.queryDistributePlanTaskList(planEntity.getId());
            if (CollectionUtil.isEmpty(taskList)){
                continue;
            }
            for (DistributeChannelTaskEntity taskEntity : taskList) {
                if (templateMap.containsKey(taskEntity.getSupplierTaskTemplateId())){
                    taskEntity.setSupplierTaskTemplateName(templateMap.get(taskEntity.getSupplierTaskTemplateId()));
                }
                distChannelTaskRepo.updateDistributeChannelTask(taskEntity);
            }
        }
    }
}
