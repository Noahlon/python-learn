package com.hellobike.aicc.infrastructure.persistence.multi.mapper;

import com.hellobike.aicc.infrastructure.persistence.multi.po.CallDialoguePO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 数据密级S2,分流平台话单 Mapper 接口
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
public interface CallDialogueMapper extends BaseMapper<CallDialoguePO> {

}
