package com.hellobike.aicc.infrastructure.persistence.multi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hellobike.aicc.infrastructure.persistence.multi.po.SupplierSmsRecordPO;

public interface SupplierSmsRecordMapper extends BaseMapper<SupplierSmsRecordPO> {

}
