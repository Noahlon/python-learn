package com.hellobike.aicc.infrastructure.persistence.multi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hellobike.aicc.infrastructure.persistence.multi.po.SmsRecordPO;

public interface SmsRecordMapper extends BaseMapper<SmsRecordPO> {

}
