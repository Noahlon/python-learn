package com.hellobike.aicc.infrastructure.persistence.multi.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 数据密级S2,分流平台话单
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_call_dialogue")
public class CallDialoguePO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id" ,type = IdType.INPUT)
    private Long id;

    /**
     * 数据密级S2,创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,逻辑删除
     */
    @TableField("is_delete")
    private Integer isDelete;

    /**
     * 数据密级S2,企业id
     */
    @TableField("enterprise_id")
    private String enterpriseId;

    /**
     * 数据密级S2,租户id
     */
    @TableField("tenant_id")
    private String tenantId;

    /**
     * 数据密级S2,呼叫结果
     */
    @TableField("call_result")
    private Integer callResult;

    /**
     * 数据密级S2,供应商呼叫结果code
     */
    @TableField("supplier_call_result")
    private String supplierCallResult;

    /**
     * 数据密级S2,知识标签
     */
    @TableField("tags")
    private String tags;

    /**
     * 数据密级S2,说话次数
     */
    @TableField("speak_count")
    private Integer speakCount;

    /**
     * 数据密级S2,分流计划模版id
     */
    @TableField("template_id")
    private Long templateId;

    /**
     * 数据密级S2,意向分类code
     */
    @TableField("intent_classify")
    private String intentClassify;

    /**
     * 数据密级S2,意向分类名称
     */
    @TableField("intent_classify_name")
    private String intentClassifyName;

    /**
     * 数据密级S2,座席名称
     */
    @TableField("seat_name")
    private String seatName;

    /**
     * 数据密级S2,命中意图
     */
    @TableField("hit_intentions")
    private String hitIntentions;

    /**
     * 数据密级S2,是否触发短信
     */
    @TableField("is_hit_sms")
    private Integer isHitSms;

    /**
     * 数据密级S2,ai段时长
     */
    @TableField("duration_call_ai")
    private Integer durationCallAi;

    /**
     * 数据密级S2,人工段时长
     */
    @TableField("duration_call_manual")
    private Integer durationCallManual;

    /**
     * 数据密级S2,中继外显号
     */
    @TableField("real_calling_number")
    private String realCallingNumber;

    /**
     * 数据密级S2,通话时长
     */
    @TableField("total_time")
    private Integer totalTime;

    /**
     * 数据密级S2,振铃时长
     */
    @TableField("ring_time")
    private Integer ringTime;

    /**
     * 数据密级S2,拨打时间
     */
    @TableField("dial_time")
    private LocalDateTime dialTime;

    /**
     * 数据密级S2,挂机时间
     */
    @TableField("hangup_time")
    private LocalDateTime hangupTime;

    /**
     * 数据密级S2,接通时间
     */
    @TableField("answer_time")
    private LocalDateTime answerTime;

    /**
     * 数据密级S2,通话类型
     */
    @TableField("call_type")
    private Integer callType;

    /**
     * 数据密级S2,主叫号码
     */
    @TableField("calling_number")
    private String callingNumber;

    /**
     * 数据密级S2,计费单元数
     */
    @TableField("cost_unit")
    private Integer costUnit;

    /**
     * 数据密级S2,客户姓名
     */
    @TableField("custom_name")
    private String customName;

    /**
     * 数据密级S2,通话唯一id
     */
    @TableField("dialogue_guid")
    private String dialogueGuid;

    /**
     * 数据密级S2,通话录音地址
     */
    @TableField("record_url")
    private String recordUrl;

    /**
     * 数据密级S2,线路id
     */
    @TableField("line_id")
    private String lineId;

    /**
     * 数据密级S2,号码归属城市
     */
    @TableField("city")
    private String city;

    /**
     * 数据密级S2,号码归属省份
     */
    @TableField("province")
    private String province;

    /**
     * 数据密级S2,运营商
     */
    @TableField("carrier")
    private Integer carrier;

    /**
     * 数据密级S2,对话轮次
     */
    @TableField("speech_count")
    private Integer speechCount;

    /**
     * 数据密级S2,性别
     */
    @TableField("sex")
    private Integer sex;

    /**
     * 数据密级S2,挂断方
     */
    @TableField("release_initiator")
    private Integer releaseInitiator;

    /**
     * 数据密级S2,外部数据唯一标识
     */
    @TableField("external_id")
    private String externalId;

    /**
     * 数据密级S2,平台数据唯一标识
     */
    @TableField("platform_id")
    private String platformId;

    /**
     * 数据密级S2,被叫号
     */
    @TableField("called_number")
    private String calledNumber;

    /**
     * 数据密级S2,渠道任务id
     */
    @TableField("channel_task_id")
    private Long channelTaskId;

    /**
     * 数据密级S2,扩展信息
     */
    @TableField("ext_info")
    private String extInfo;

    /**
     * 数据密级S2,三方任务id
     */
    @TableField("supplier_task_id")
    private String supplierTaskId;

    /**
     * 数据密级S2,三方任务名称
     */
    @TableField("supplier_task_name")
    private String supplierTaskName;

    /**
     * 数据密级S2,三方任务模版id
     */
    @TableField("supplier_task_template_id")
    private String supplierTaskTemplateId;

    /**
     * 数据密级S2,名单id
     */
    @TableField("roster_id")
    private Long rosterId;

    /**
     * 数据密级S2,分流计划id
     */
    @TableField("distribute_plan_id")
    private Long distributePlanId;

    /**
     * 数据密级S2,分流计划名称
     */
    @TableField("distribute_plan_name")
    private String distributePlanName;

    /**
     * 数据密级S2,手机号md5
     */
    @TableField("md5")
    private String md5;

    /**
     * 数据密级S2,渠道id
     */
    @TableField("channel_id")
    private Integer channelId;

    /**
     * 数据密级S2,渠道名称
     */
    @TableField("channel_name")
    private String channelName;

    /**
     * 数据密级S2,对话信息
     */
    @TableField("speak_info")
    private String speakInfo;

    public static final String CREATE_TIME = "create_time";

    public static final String UPDATE_TIME = "update_time";

    public static final String IS_DELETE = "is_delete";

    public static final String ENTERPRISE_ID = "enterprise_id";

    public static final String CALL_RESULT = "call_result";

    public static final String INTENT_CLASSIFY = "intent_classify";

    public static final String HIT_INTENTIONS = "hit_intentions";

    public static final String IS_HIT_SMS = "is_hit_sms";

    public static final String DURATION_CALL_AI = "duration_call_ai";

    public static final String DURATION_CALL_MANUAL = "duration_call_manual";

    public static final String REAL_CALLING_NUMBER = "real_calling_number";

    public static final String TOTAL_TIME = "total_time";

    public static final String RING_TIME = "ring_time";

    public static final String DIAL_TIME = "dial_time";

    public static final String HANGUP_TIME = "hangup_time";

    public static final String CALL_TYPE = "call_type";

    public static final String CALLING_NUMBER = "calling_number";

    public static final String COST_UNIT = "cost_unit";

    public static final String CUSTOM_NAME = "custom_name";

    public static final String DIALOGUE_GUID = "dialogue_guid";

    public static final String RECORD_URL = "record_url";

    public static final String LINE_ID = "line_id";

    public static final String ATTRIBUTION = "attribution";

    public static final String CARRIER = "carrier";

    public static final String SPEECH_COUNT = "speech_count";

    public static final String SEX = "sex";

    public static final String RELEASE_INITIATOR = "release_initiator";

    public static final String EXTERNAL_ID = "external_id";

    public static final String PLATFORM_ID = "platform_id";

    public static final String CALLED_NUMBER = "called_number";

    public static final String CHANNEL_TASK_ID = "channel_task_id";

    public static final String EXT_INFO = "ext_info";

    public static final String SUPPLIER_TASK_ID = "supplier_task_id";

    public static final String SUPPLIER_TASK_NAME = "supplier_task_name";

    public static final String SUPPLIER_TASK_TEMPLATE_ID = "supplier_task_template_id";

    public static final String ROSTER_ID = "roster_id";

    public static final String DISTRIBUTE_PLAN_ID = "distribute_plan_id";

    public static final String DISTRIBUTE_PLAN_NAME = "distribute_plan_name";

    public static final String MD5 = "md5";

    public static final String SEAT_NAME = "seat_name";

    public static final String CITY = "city";

    public static final String PROVINCE = "province";

    public static final String ANSWER_TIME = "answer_time";

}
