package com.hellobike.aicc.infrastructure.es.roster.po;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.searchbox.annotations.JestId;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-05-23  13:44:36
 */
@Data
public class PlanRosterESPO {

    /**
     * 索引日期(分流计划创建时间)
     */
    private LocalDateTime distPlanCreateTime;

    @JestId
    private Long id;

    /**
     * 数据密级S2,手机号
     */
    private String phoneNum;

    /**
     * 数据密级S2,客户数据唯一标识
     */
    private String externalId;

    /**
     * 数据密级S2,平台数据唯一标识
     */
    private String platformId;

    /**
     * 数据密级S2,客户姓名
     */
    private String customerName;

    /**
     * 数据密级S2,变量信息
     */
    private String variableInfo;

    /**
     * 数据密级S2,分流计划id
     */
    private Long distributePlanId;

    /**
     * 数据密级S2,分表键（分流计划id+手机号最后一位）
     */
    private String partitionCode;

    /**
     * 数据密级S2,上传记录id
     */
    private Long uploadRecordId;

    /**
     * 数据密级S2,下发记录id
     */
    private Long distributeRecordId;

    /**
     * 数据密级S2,下发状态
     */
    private Integer distributeStatus;

    /**
     * 数据密级S2,渠道id
     */
    private Integer channelId;

    /**
     * 数据密级S2,渠道任务id
     */
    private Long channelTaskId;

    /**
     * 数据密级S2,渠道名称
     */
    private String channelName;

    /**
     * 手机号md5
     */
    private String md5;

    /**
     * 三方任务id
     */
    private String supplierTaskId;

    /**
     * 三方任务名称
     */
    private String supplierTaskName;

    /**
     * 数据密级S2,话单数量
     */
    private Integer callDialogueNum;

    /**
     * 数据密级S2,接通话单数
     */
    private Integer throughCallDialogueNum;

    /**
     * 数据密级S2,上传时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String uploadTime;

    /**
     * 数据密级S2,下发时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String distributeTime;

    /**
     * 数据密级S2,最近呼叫时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String lastCallTime;

    /**
     * 数据密级S2,最近接通时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String lastThroughTime;

    /**
     * 数据密级S2,名单类型
     * @see com.hellobike.aicc.common.enums.RosterTypeEnum
     */
    private Integer rosterType;

    /**
     * 数据密级S2,创建时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String updateTime;

    /**
     * 数据密级S2,逻辑删除
     */
    private Integer isDelete;

    /**
     * 命中规则
     */
    private String hitRule;

    /**
     * 是否命中规则 0-否 1-是
     */
    private Integer isHitRule;

    /**
     * 是否撞库 0-否 1-是
     */
    private Integer isImpact;

    /**
     * 不下发原因
     */
    private String notDistReason;

    /**
     * 最近外呼状态
     * @see com.hellobike.aicc.common.enums.CallResultEnum
     */
    private Integer lastCallResult;

    /**
     * 短信发送次数
     */
    private Integer smsSendCount;

    /**
     * 短信发送成功次数
     */
    private Integer smsSendSuccessCount;

    /**
     * 租户id
     */
    private String tenantId;

    public static final String ID = "id";
    public static final String PHONE_NUM = "phoneNum";
    public static final String EXTERNAL_ID = "externalId";
    public static final String PLATFORM_ID = "platformId";
    public static final String CUSTOMER_NAME = "customerName";
    public static final String VARIABLE_INFO = "variableInfo";
    public static final String DISTRIBUTE_PLAN_ID = "distributePlanId";
    public static final String PARTITION_CODE = "partitionCode";
    public static final String UPLOAD_RECORD_ID = "uploadRecordId";
    public static final String DISTRIBUTE_RECORD_ID = "distributeRecordId";
    public static final String DISTRIBUTE_STATUS = "distributeStatus";
    public static final String CHANNEL_ID = "channelId";
    public static final String CHANNEL_TASK_ID = "channelTaskId";
    public static final String CHANNEL_NAME = "channelName";
    public static final String MD5 = "md5";
    public static final String SUPPLIER_TASK_ID = "supplierTaskId";
    public static final String SUPPLIER_TASK_NAME = "supplierTaskName";
    public static final String CALL_DIALOGUE_NUM = "callDialogueNum";
    public static final String THROUGH_CALL_DIALOGUE_NUM = "throughCallDialogueNum";
    public static final String UPLOAD_TIME = "uploadTime";
    public static final String DISTRIBUTE_TIME = "distributeTime";
    public static final String LAST_CALL_TIME = "lastCallTime";
    public static final String LAST_THROUGH_TIME = "lastThroughTime";
    public static final String EXT_INFO = "extInfo";
    public static final String ROSTER_TYPE = "rosterType";
    public static final String CREATE_TIME = "createTime";
    public static final String UPDATE_TIME = "updateTime";
    public static final String IS_DELETE = "isDelete";
    public static final String HIT_RULE = "hitRule";
    public static final String IS_HIT_RULE = "isHitRule";
    public static final String IS_IMPACT = "isImpact";
    public static final String NOT_DIST_REASON = "notDistReason";
    public static final String LAST_CALL_RESULT = "lastCallResult";
    public static final String SMS_SEND_COUNT = "smsSendCount";
    public static final String SMS_SEND_SUCCESS_COUNT = "smsSendSuccessCount";
    public static final String TENANT_ID = "tenantId";

}
