package com.hellobike.aicc.infrastructure.convert;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.smsrecord.entity.SmsCheckEntity;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;
import com.hellobike.aicc.infrastructure.es.EsPage;
import com.hellobike.aicc.infrastructure.es.smsrecord.po.SmsRecordESPO;
import com.hellobike.aicc.domain.smsrecord.dto.CssSmsRecordMsgDTO;
import com.hellobike.aicc.infrastructure.hms.dto.SmsRecordPushMsgDTO;
import com.hellobike.aicc.infrastructure.persistence.multi.po.SmsRecordPO;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributeSmsCheckPO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring", imports = DateUtils.class)
public interface SmsRecordInfConvert {
    @Mappings({
            @Mapping(source = "id", target = "supplierSmsGuid"),
            @Mapping(source = "md5", target = "phoneNumberMd5"),
            @Mapping(source = "tenantId", target = "tenantCode"),
            @Mapping(source = "callGuid", target = "supplierCallGuid"),
            @Mapping(source = "taskGuid", target = "supplierTaskId"),
            @Mapping(source = "taskName", target = "supplierTaskName"),
            @Mapping(target = "sendTime", expression = "java(DateUtils.toLocalDateTime(dto.getSendTime()))")
    })
    SmsRecordEntity convert(CssSmsRecordMsgDTO dto);

    SmsRecordPO convert2po(SmsRecordEntity entity);

    SmsRecordEntity convert2Entity(SmsRecordPO entity);

    @Mappings({
            @Mapping(source = "submitTime", target = "submitTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "sendTime", target = "sendTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "receiveResultTime", target = "receiveResultTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "createTime", target = "createTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "updateTime", target = "updateTime", dateFormat = "yyyy-MM-dd HH:mm:ss")
    })
    SmsRecordESPO convert2EsPo(SmsRecordPO po);

    @Mappings({
            @Mapping(source = "guid", target = "smsId"),
            @Mapping(source = "distributePlanId", target = "taskId"),
            @Mapping(source = "distributePlanName", target = "taskName"),
            @Mapping(source = "distributePlanCallId", target = "dialogueGuid"),
            @Mapping(source = "phoneNumberMd5", target = "md5"),
            @Mapping(source = "tenantCode", target = "tenantId"),
            @Mapping(source = "sendTime", target = "sendTime", dateFormat = "yyyy-MM-dd HH:mm:ss")
    })
    SmsRecordPushMsgDTO convert(SmsRecordEntity entity);

    @Mappings({
            @Mapping(target = "submitTime", expression = "java(DateUtils.toLocalDateTime(esPo.getSubmitTime()))"),
            @Mapping(target = "sendTime", expression = "java(DateUtils.toLocalDateTime(esPo.getSendTime()))"),
            @Mapping(target = "receiveResultTime", expression = "java(DateUtils.toLocalDateTime(esPo.getReceiveResultTime()))"),
            @Mapping(target = "createTime", expression = "java(DateUtils.toLocalDateTime(esPo.getCreateTime()))"),
            @Mapping(target = "updateTime", expression = "java(DateUtils.toLocalDateTime(esPo.getUpdateTime()))")
    })
    SmsRecordEntity convert(SmsRecordESPO esPo);

    default PageResult<SmsRecordEntity> esPageToPageResult(EsPage<SmsRecordESPO> esPage) {
        PageResult<SmsRecordEntity> pageResult = new PageResult<>();
        pageResult.setPageNum(esPage.getCurrentPage());
        pageResult.setPageSize(esPage.getPageSize());
        pageResult.setTotalRecord(esPage.getTotalSize());
        pageResult.setTotalPages(esPage.getTotalPages());
        pageResult.setList(convert(esPage.getData()));
        return pageResult;
    }

    List<SmsRecordEntity> convert(List<SmsRecordESPO> poList);

    DistributeSmsCheckPO convertCheckPO(SmsCheckEntity entity);

    SmsCheckEntity convertCheckEntity(DistributeSmsCheckPO po);

    List<SmsCheckEntity> convertCheckEntity(List<DistributeSmsCheckPO> poList);
}
