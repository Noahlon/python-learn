package com.hellobike.aicc.infrastructure.persistence.single.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 数据密级S2,分流计划上传文件
 * </p>
 *
 * @author fanxiaodongwb230@hellobike.com
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_distribute_upload_file")
public class DistributeUploadFilePO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.INPUT)
    private Long id;

    /**
     * 数据密级S2,文件名称
     */
    @TableField("file_name")
    private String fileName;

    /**
     * 数据密级S2,文件连接
     */
    @TableField("file_url")
    private String fileUrl;

    /**
     * 数据密级S2,分流计划id
     */
    @TableField("distribute_plan_id")
    private Long distributePlanId;

    /**
     * 数据密级S2,成功条数
     */
    @TableField("success_count")
    private Integer successCount;

    /**
     * 数据密级S2,失败条数
     */
    @TableField("failed_count")
    private Integer failedCount;

    /**
     * 数据密级S2,重复条数
     */
    @TableField("duplicate_count")
    private Integer duplicateCount;

    /**
     * 数据密级S2,操作类型
     * 暂定：1:添加呼叫，2：取消呼叫
     */
    @TableField("operation_type")
    private Integer operationType;

    /**
     * 数据密级S2,状态
     */
    @TableField("status")
    private Integer status;

    /**
     * 数据密级S2,状态描述
     */
    @TableField("status_desc")
    private String statusDesc;

    /**
     * 数据密级S2,失败原因
     */
    @TableField("failed_desc")
    private String failedDesc;

    /**
     * 数据密级S2,创建人
     */
    @TableField("creator")
    private String creator;

    /**
     * 数据密级S2,失败信息url
     */
    @TableField("failed_url")
    private String failedUrl;

    /**
     * 数据密级S2,上传记录id
     */
    @TableField("upload_record_id")
    private Long uploadRecordId;
    /**
     * 数据密级S1,创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 数据密级S1,最近更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 数据密级S1,逻辑删除
     */
    @TableField("is_delete")
    private Integer isDelete;

    public static final String ID = "id";

    public static final String FILE_NAME = "file_name";

    public static final String FILE_URL = "file_url";

    public static final String FAILED_URL = "failed_url";

    public static final String DISTRIBUTE_PLAN_ID = "distribute_plan_id";

    public static final String SUCCESS_COUNT = "success_count";

    public static final String FAILED_COUNT = "failed_count";

    public static final String DUPLICATE_COUNT = "duplicate_count";

    public static final String OPERATION_TYPE = "operation_type";

    public static final String OPERATOR = "operator";

    public static final String CREATOR = "creator";

    public static final String CREATE_TIME = "create_time";

    public static final String UPDATE_TIME = "update_time";

    public static final String IS_DELETE = "is_delete";

    public static final String STATUS = "status";

    public static final String STATUS_DESC = "status_desc";


}
