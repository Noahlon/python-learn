package com.hellobike.aicc.infrastructure.roster;

import com.ctrip.framework.apollo.ConfigService;
import com.google.common.util.concurrent.RateLimiter;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.roster.dto.RosterUpdDTO;
import com.hellobike.aicc.domain.roster.service.RosterMsgService;
import com.hellobike.aicc.infrastructure.hms.producer.RosterUpdProducer;
import com.hellobike.soa.starter.spring.event.SoaStartedEvent;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-05-24  10:55:54
 */
@Slf4j
@Service
public class RosterMsgServiceImpl implements RosterMsgService , ApplicationListener<SoaStartedEvent> {

    @Resource
    private RosterUpdProducer rosterUpdProducer;

    @Value("${roster.send.rate:2000}")
    private Integer rosterSendRate;

    /**
     * 发送限流器（防止发送速度过快）
     */
    private RateLimiter rateLimiter;

    @Override
    public boolean sendUpdMsg(RosterUpdDTO msg) {
        if (StringUtils.isAnyBlank(msg.getId(),msg.getPlanId(),msg.getPhoneNum(),msg.getPlanCreateTime())){
            log.warn("发送名单消息字段为空,msg:{}", BaseJsonUtils.writeValue(msg));
            return false;
        }
        //rateLimiter.acquire();
        rosterUpdProducer.sendMsg(msg);
        /*if (!flag){
            log.error("发送名单消息失败,msg:{}", BaseJsonUtils.writeValue(msg));
        }
        return flag;*/
        return true;
    }

    @Override
    public void onApplicationEvent(SoaStartedEvent soaStartedEvent) {
        rateLimiter = RateLimiter.create(rosterSendRate);
        //监听渠道配置变动
        ConfigService.getAppConfig().addChangeListener(changeEvent -> {
            try {
                //初始化监听事件
                String key = "roster.send.rate";
                if (changeEvent.isChanged(key)) {
                    String newValue = changeEvent.getChange(key).getNewValue();
                    rateLimiter.setRate(Integer.parseInt(newValue));
                }
            } catch (Exception e) {
                log.error("apollo change error", e);
            }
        });
    }
}
