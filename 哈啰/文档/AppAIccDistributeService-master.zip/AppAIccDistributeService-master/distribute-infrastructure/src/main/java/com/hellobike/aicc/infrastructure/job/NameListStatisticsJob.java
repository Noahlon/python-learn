package com.hellobike.aicc.infrastructure.job;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.common.enums.ChannelEnum;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.repo.DistChannelTaskRepo;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.infrastructure.job.dto.TenantStatisticsDTO;
import com.hellobike.base.flexjob.common.model.base.ReturnT;
import com.hellobike.base.flexjob.common.participant.ParticipantParams;
import com.hellobike.base.flexjob.participant.starter.spring.JobHandle;
import com.hellobike.css.ai.common.util.DateUtils;
import com.hellobike.css.ai.common.util.DingNotifyUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 分流名单每日统计-定时任务
 */
@Service
@Slf4j
@JobHandle("nameListStatisticsJob")
public class NameListStatisticsJob {
    @Resource
    private DistPlanRepo distPlanRepo;

    @Resource
    private DistChannelTaskRepo distChannelTaskRepo;

    @Resource
    private DingNotifyUtil dingNotifyUtil;


    @Value("#{'${tenant.profit.robot.token.list:2c7b7c1b7fbeea5e34dc21e9b3c39bd05f9f6e9cf6450ace7973ae57b62bd2cf}'.split(',')}")
    private List<String> tokenList;

    @Value("#{'${statistics.tenant.array:11116}'.split(',')}")
    private List<String> tenantCodeList;

    /**
     * 租户计费单元价格和单位利润配置
     * {
     * "11050":
     * {
     * "price": "0.12",
     * "profit": "0.03"
     * },
     * "11055":
     * {
     * "price": "0.11",
     * "profit": "0.02"
     * }
     * <p>
     * }
     */
    @Value("${tenant.price.config:{}}")
    private String tenantPriceConfig;

    private static final String PRICE = "price";
    private static final String PROFIT = "profit";
    //如果不配置，默认单价0.12元，默认单位利润0.007元
    private static final BigDecimal UNIT_PRICE = BigDecimal.valueOf(0.12);
    private static final BigDecimal UNIT_PROFIT = BigDecimal.valueOf(0.007);

    public ReturnT<String> trigger(ParticipantParams params) {
        try {
            String extendParams = params.getExtendParams();
            LocalDate localDate = LocalDate.now();
            if (StrUtil.isNotBlank(extendParams)) {
                String date = extendParams;
                localDate = DateUtils.toLocalDate(date, DateUtils.DATE_FORMATTER);
            }
            String dateString = DateUtils.getDateString(localDate);
            LocalDateTime startTime = localDate.atStartOfDay();
            LocalDateTime endTime = startTime.plusDays(1L);
            List<TenantStatisticsDTO> tenantStatisticsDTOList = new ArrayList<>();
            for (String tenantCode : tenantCodeList) {
                TenantStatisticsDTO tenantStatisticsDTO = this.tenantStatistics(tenantCode, startTime, endTime);
                if (Objects.isNull(tenantStatisticsDTO)) {
                    continue;
                }
                tenantStatisticsDTOList.add(tenantStatisticsDTO);
            }
            //拿到所有租户统计数据后，拼接钉钉通知
            this.sendDingNotify(dateString, tenantStatisticsDTOList);
            return new ReturnT<>(ReturnT.SUCCESS_CODE, "分流名单统计任务执行完毕");
        } catch (Exception e) {
            log.error("分流名单统计任务异常", e);
            return new ReturnT<>(ReturnT.FAIL_CODE, "分流名单统计任务异常");
        }
    }

    /**
     * 单个租户下分流出去的名单统计；
     *
     * @param tenantCode
     * @param startTime
     * @param endTime
     */
    private TenantStatisticsDTO tenantStatistics(String tenantCode, LocalDateTime startTime, LocalDateTime endTime) {
        List<DistributePlanEntity> distributePlanEntities = distPlanRepo.queryDistributePlanList(tenantCode, startTime, endTime);
        if (CollectionUtils.isEmpty(distributePlanEntities)) {
            log.info("租户{}没有执行过分流任务", tenantCode);
            return null;
        }
        TenantStatisticsDTO tenantStatisticsDTO = new TenantStatisticsDTO();
        tenantStatisticsDTO.setTenantCode(tenantCode);
        try {
            DistributePlanEntity distributePlanEntity1 = distributePlanEntities.get(0);
            tenantStatisticsDTO.setTenantName(distributePlanEntity1.getTenantName());
            long total = 0L;
            long totalPutCount = 0L;
            long totalCostUnit = 0L;
            for (DistributePlanEntity distributePlanEntity : distributePlanEntities) {
                List<DistributeChannelTaskEntity> distributeChannelTaskEntities = distChannelTaskRepo.queryEsPlanTaskList(distributePlanEntity.getId(), distributePlanEntity.getCreateTime());
                if (CollectionUtils.isEmpty(distributeChannelTaskEntities)) {
                    continue;
                }
                //去掉内部渠道
                List<DistributeChannelTaskEntity> taskEntities = distributeChannelTaskEntities.stream().filter(o -> !String.valueOf(ChannelEnum.HELLO_AI_CALL.getChannelId()).equals(o.getChannelId())).collect(Collectors.toList());
                long totalSum = taskEntities.stream().filter(o -> Objects.nonNull(o.getSentTotalNum())).mapToLong(DistributeChannelTaskEntity::getSentTotalNum).sum();
                long putCountSum = taskEntities.stream().filter(o -> Objects.nonNull(o.getThroughRosterNum())).mapToLong(DistributeChannelTaskEntity::getThroughRosterNum).sum();
                long costUnitSum = taskEntities.stream().filter(o -> Objects.nonNull(o.getCostUnit())).mapToLong(DistributeChannelTaskEntity::getCostUnit).sum();
                total += totalSum;
                totalPutCount += putCountSum;
                totalCostUnit += costUnitSum;
            }
            tenantStatisticsDTO.setTotalCount(total);
            tenantStatisticsDTO.setTotalDailyPutCount(totalPutCount);
            tenantStatisticsDTO.setTotalDailyCallBillingCount(totalCostUnit);

            BigDecimal price = UNIT_PRICE;
            BigDecimal profit = UNIT_PROFIT;
            Map<String, Object> tenantPriceMapConfig = JSONObject.parseObject(tenantPriceConfig);
            if (tenantPriceMapConfig.containsKey(tenantCode)) {
                Map<String, Object> map = (Map<String, Object>) tenantPriceMapConfig.get(tenantCode);
                if (Objects.nonNull(map.get(PRICE))) {
                    price = new BigDecimal(String.valueOf(map.get(PRICE)));
                }
                if (Objects.nonNull(map.get(PROFIT))) {
                    profit = new BigDecimal(String.valueOf(map.get(PROFIT)));
                }
            }
            //计算营收和利润
            BigDecimal billingCount = BigDecimal.valueOf(tenantStatisticsDTO.getTotalDailyCallBillingCount());
            tenantStatisticsDTO.setTotalDailyCallBill(billingCount.multiply(price));
            tenantStatisticsDTO.setTotalDailyCallProfit(billingCount.multiply(profit));
        } catch (Exception e) {
            log.error("nameListStatisticsJob：{}执行异常", tenantCode, e);
            return null;
        }
        return tenantStatisticsDTO;
    }

    private void sendDingNotify(String dateString, List<TenantStatisticsDTO> tenantStatisticsDTOList) {
        log.info("nameListStatisticsJob.sendDingNotify，数量：{}", tenantStatisticsDTOList.size());
        try {
            String title = dateString + "分流业务通知";
            StringBuilder text = new StringBuilder("| 租户名称                     | 分流日语音利润（预估） | 分流日名单数 | 分流日语音计费单元数 |\n" +
                    "|------------------------------|----------|------------------|--------------------|\n");
            TenantStatisticsDTO total = new TenantStatisticsDTO();
            if (CollectionUtils.isNotEmpty(tenantStatisticsDTOList)) {
                //倒序
                tenantStatisticsDTOList.sort(Comparator.comparing(TenantStatisticsDTO::getTotalDailyCallProfit).reversed());
                for (TenantStatisticsDTO tenantStatisticsDTO : tenantStatisticsDTOList) {
                    text.append("| ");
                    text.append(tenantStatisticsDTO.getTenantName());
                    text.append(" | ");

//                text.append("<span style=\"color:red\">");
                    text.append(tenantStatisticsDTO.getTotalDailyCallProfit().setScale(3, RoundingMode.HALF_UP).toPlainString()).append("元 | ");
                    total.setTotalDailyCallProfit(total.getTotalDailyCallProfit().add(tenantStatisticsDTO.getTotalDailyCallProfit()));


                    total.setTotalCount(total.getTotalCount() + tenantStatisticsDTO.getTotalCount());
                    text.append(tenantStatisticsDTO.getTotalCount()).append(" | ");
                    //如果租户日名单数为0，则用红色字体表示
//                if(tenantStatisticsDTO.getTotalCount() == 0){
//                    text.append("<span style=\"color:red\">0</span> | ");
//                }else {
//
//                }
                    total.setTotalDailyCallBillingCount(total.getTotalDailyCallBillingCount() + tenantStatisticsDTO.getTotalDailyCallBillingCount());
                    text.append(tenantStatisticsDTO.getTotalDailyCallBillingCount()).append(" |\n");

//                total.setTotalDailyCallBill(total.getTotalDailyCallBill().add(tenantStatisticsDTO.getTotalDailyCallBill()));
//                text.append(tenantStatisticsDTO.getTotalDailyCallBill().setScale(3, RoundingMode.HALF_UP).toPlainString()).append("元 |\n");
                }
            }
            text.append("| ");
            text.append(dateString);
            text.append("分流总计");
            text.append(" | ");
            text.append(total.getTotalDailyCallProfit().setScale(3, RoundingMode.HALF_UP).toPlainString()).append("元 | ");
            text.append(total.getTotalCount()).append(" | ");
            text.append(total.getTotalDailyCallBillingCount()).append(" |");
//            text.append(total.getTotalDailyCallBill().setScale(3, RoundingMode.HALF_UP).toPlainString()).append("元 |");

//            String test = "| 租户名称                     | 日名单数 | 日语音计费单元数 | 日语音营收（预估） | 日语音利润（预估） |\n" +
//                    "|------------------------------|------------|------------------|--------------------|--------------------|\n" +
//                    "| 姚际科技                     | 4        | 98               | 25.0元             | <span style=\"color:red\">10.0元</span> |\n" +
//                    "| 上海同保科技有限公司（众安金融） | <span style=\"color:red\">0</span> | <span style=\"color:red\">0</span> | <span style=\"color:red\">0.000元</span> | <span style=\"color:red\">0.000元</span> |\n" +
//                    "| 总计                     | 4        | 98               | 25.0元             | <span style=\"color:red\">10.0元</span> |";
            log.info("nameListStatisticsJob.sendDingNotify：{}", text.toString());
            dingNotifyUtil.sendMarkDown(text.toString(), title, tokenList, false);
        } catch (Exception e) {
            log.error("nameListStatisticsJob.sendDingNotify执行异常", e);
        }
    }

}
