package com.hellobike.aicc.infrastructure.job;

import com.hellobike.aicc.domain.smsrecord.service.SmsDomainService;
import com.hellobike.base.flexjob.common.model.base.ReturnT;
import com.hellobike.base.flexjob.common.participant.ParticipantParams;
import com.hellobike.base.flexjob.participant.starter.spring.JobHandle;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * 短信发送状态检查
 *
 * @author zhangzhuoqi
 * @since 2025-06-10  16:26:58
 */
@Service
@Slf4j
@JobHandle("smsStatusCheckJob")
public class SmsStatusCheckJob {

    @Resource
    private SmsDomainService smsDomainService;

    public ReturnT<String> trigger(ParticipantParams params) {
        try {
            smsDomainService.checkSmsStatus();
            return new ReturnT<>(ReturnT.SUCCESS_CODE, "短信发送状态检查执行完毕");
        } catch (Exception e) {
            log.error("短信发送状态检查执行失败，e:", e);
            return new ReturnT<>(ReturnT.FAIL_CODE, "短信发送状态检查执行失败");
        }
    }
}
