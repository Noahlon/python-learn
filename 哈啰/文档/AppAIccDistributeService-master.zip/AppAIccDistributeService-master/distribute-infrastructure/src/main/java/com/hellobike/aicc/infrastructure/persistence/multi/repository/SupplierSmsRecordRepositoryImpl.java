package com.hellobike.aicc.infrastructure.persistence.multi.repository;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hellobike.aicc.domain.smsrecord.entity.SupplierSmsRecordEntity;
import com.hellobike.aicc.domain.smsrecord.repo.SupplierSmsRecordRepository;
import com.hellobike.aicc.infrastructure.convert.SupplierSmsRecordInfConvert;
import com.hellobike.aicc.infrastructure.persistence.multi.mapper.SupplierSmsRecordMapper;
import com.hellobike.aicc.infrastructure.persistence.multi.po.SupplierSmsRecordPO;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class SupplierSmsRecordRepositoryImpl extends ServiceImpl<SupplierSmsRecordMapper, SupplierSmsRecordPO> implements SupplierSmsRecordRepository {

    @Resource
    private SupplierSmsRecordInfConvert convert;

    @Override
    public void save(SupplierSmsRecordEntity entity) {
        SupplierSmsRecordPO po = convert.convert(entity);
        save(po);
    }
}
