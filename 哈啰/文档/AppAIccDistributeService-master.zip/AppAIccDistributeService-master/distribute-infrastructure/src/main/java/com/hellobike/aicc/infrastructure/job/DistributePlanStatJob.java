package com.hellobike.aicc.infrastructure.job;

import com.hellobike.aicc.domain.distribute.service.DistributePlanStatDomainService;
import com.hellobike.base.flexjob.common.model.base.ReturnT;
import com.hellobike.base.flexjob.common.participant.ParticipantParams;
import com.hellobike.base.flexjob.participant.starter.spring.JobHandle;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import javax.annotation.Resource;

/**
 * 分流计划统计任务
 *
 * @author zhangzhuoqi
 * @since 2025-05-27  15:02:32
 */
@Service
@Slf4j
@JobHandle("distributePlanStatJob")
public class DistributePlanStatJob {

    @Resource
    private DistributePlanStatDomainService statDomainService;

    public ReturnT<String> trigger(ParticipantParams params) {
        try {
            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            statDomainService.stat();
            stopWatch.stop();
            log.info("分流统计耗时:{}", stopWatch.getTotalTimeMillis());
            return new ReturnT<>(ReturnT.SUCCESS_CODE, "分流统计完毕");
        }catch (Exception e){
            log.error("分流统计执行失败，e:",e);
            return new ReturnT<>(ReturnT.FAIL_CODE, "分流统计执行失败");
        }
    }
}
