package com.hellobike.aicc.infrastructure.convert;

import com.hellobike.aicc.domain.smsrecord.entity.SupplierSmsRecordEntity;
import com.hellobike.aicc.infrastructure.persistence.multi.po.SupplierSmsRecordPO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface SupplierSmsRecordInfConvert {
    SupplierSmsRecordPO convert(SupplierSmsRecordEntity entity);
}
