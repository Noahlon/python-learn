package com.hellobike.aicc.infrastructure.persistence.multi.repository;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DeleteEnum;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.domain.roster.dto.UploadRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;
import com.hellobike.aicc.domain.roster.repo.UploadRecordRepository;
import com.hellobike.aicc.infrastructure.convert.UploadRecordInfConvert;
import com.hellobike.aicc.infrastructure.persistence.multi.mapper.UploadRecordMapper;
import com.hellobike.aicc.infrastructure.persistence.multi.po.UploadRecordPO;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * <p>
 * 数据密级S2,上传记录 服务实现类
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Service
public class UploadRecordRepositoryImpl extends ServiceImpl<UploadRecordMapper, UploadRecordPO> implements UploadRecordRepository {

    @Resource
    private UploadRecordInfConvert uploadRecordInfConvert;

    @Override
    public void addRecord(UploadRecordEntity uploadRecordEntity) {
        checkPartitionKey(uploadRecordEntity.getDistributePlanId());
        AssertUtils.notNull(uploadRecordEntity.getId(), "上传记录id不能为空");
        UploadRecordPO po = uploadRecordInfConvert.toPO(uploadRecordEntity);
        this.save(po);
    }



    @Override
    public void updateRecordById(UploadRecordEntity uploadRecordEntity) {
        checkPartitionKey(uploadRecordEntity.getDistributePlanId());
        AssertUtils.notNull(uploadRecordEntity.getId(), "上传记录id不能为空");

        UploadRecordPO po = uploadRecordInfConvert.toPO(uploadRecordEntity);
        LambdaUpdateWrapper<UploadRecordPO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(UploadRecordPO::getId, uploadRecordEntity.getId())
                .eq(UploadRecordPO::getDistributePlanId, uploadRecordEntity.getDistributePlanId());

        this.update(po,updateWrapper);
    }

    @Override
    public UploadRecordEntity getRecordById(Long id, Long distributePlanId) {
        checkPartitionKey(distributePlanId);
        LambdaQueryWrapper<UploadRecordPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper
                .eq(UploadRecordPO::getId, id)
                .eq(UploadRecordPO::getDistributePlanId, distributePlanId)
                .eq(UploadRecordPO::getIsDelete, DeleteEnum.NO.getCode());
        UploadRecordPO po = getOne(queryWrapper);
        return uploadRecordInfConvert.toEntity(po);
    }

    @Override
    public List<UploadRecordEntity> queryByCondition(UploadRecordQueryConditionDTO conditionDTO) {
        if (Objects.isNull(conditionDTO)) {
            return Collections.emptyList();
        }
        checkPartitionKey(conditionDTO.getDistributePlanId());
        LambdaQueryWrapper<UploadRecordPO> queryWrapper = this.buildQueryWrapperByCondition(conditionDTO);
        List<UploadRecordPO> poList = this.list(queryWrapper);
        if (CollectionUtil.isEmpty(poList)) {
            return Collections.emptyList();
        }
        List<UploadRecordEntity> entityList = poList.stream().map(uploadRecordInfConvert::toEntity).collect(Collectors.toList());
        return entityList;
    }


    @Override
    public PageResult<UploadRecordEntity> pageByCondition(UploadRecordQueryConditionDTO conditionDTO, Integer pageNum, Integer pageSize) {
        if (Objects.isNull(conditionDTO)) {
            return PageResult.getEmptyPage(pageNum, pageSize);
        }
        checkPartitionKey(conditionDTO.getDistributePlanId());
        if (Objects.isNull(pageNum) || Objects.isNull(pageSize)) {
            return PageResult.getEmptyPage();
        }
        LambdaQueryWrapper<UploadRecordPO> queryWrapper = buildQueryWrapperByCondition(conditionDTO);
        //按照上传时间倒序
        queryWrapper.orderByDesc(UploadRecordPO::getUploadTime);
        Page<UploadRecordPO> page = new Page<>(pageNum, pageSize);
        this.page(page, queryWrapper);
        List<UploadRecordPO> records = page.getRecords();
        if (CollectionUtil.isEmpty(records)) {
            return PageResult.getEmptyPage(pageNum, pageSize);
        }
        List<UploadRecordEntity> entityList = page.getRecords().stream().map(uploadRecordInfConvert::toEntity).collect(Collectors.toList());
        PageResult<UploadRecordEntity> pageResult = new PageResult<>((int) page.getCurrent(), (int) page.getSize(), page.getTotal(), entityList);
        return pageResult;
    }

    @Override
    public void updateWhenDistribute(UploadRecordEntity uploadRecordEntity) {
        checkPartitionKey(uploadRecordEntity.getDistributePlanId());
        AssertUtils.notNull(uploadRecordEntity.getId(), "上传记录id不能为空");
        LambdaUpdateWrapper<UploadRecordPO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(UploadRecordPO::getId, uploadRecordEntity.getId())
                        .eq(UploadRecordPO::getDistributePlanId, uploadRecordEntity.getDistributePlanId());
        updateWrapper.setSql(" distribute_count = distribute_count + " + uploadRecordEntity.getDistributeCount());

        update(updateWrapper);
    }

    @Override
    public void updateUploadCount(Long id, Long distributePlanId, Integer uploadCount) {
        LambdaUpdateWrapper<UploadRecordPO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.setSql(" upload_count = upload_count + " + uploadCount)
                .eq(UploadRecordPO::getIsDelete, DeleteEnum.NO.getCode())
                .eq(UploadRecordPO::getId, id)
                .eq(UploadRecordPO::getDistributePlanId, distributePlanId);
        update(updateWrapper);
    }

    private LambdaQueryWrapper<UploadRecordPO> buildQueryWrapperByCondition(UploadRecordQueryConditionDTO conditionDTO) {
        LambdaQueryWrapper<UploadRecordPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Objects.nonNull(conditionDTO.getId()), UploadRecordPO::getId, conditionDTO.getId())
                .eq(Objects.nonNull(conditionDTO.getUploadType()), UploadRecordPO::getUploadType, conditionDTO.getUploadType())
                .eq(Objects.nonNull(conditionDTO.getUploadStatus()), UploadRecordPO::getUploadStatus, conditionDTO.getUploadStatus())
                .eq(Objects.nonNull(conditionDTO.getDistributeType()), UploadRecordPO::getDistributeType, conditionDTO.getDistributeType())
                .ge(Objects.nonNull(conditionDTO.getStartCreateTime()), UploadRecordPO::getCreateTime, conditionDTO.getStartCreateTime())
                .le(Objects.nonNull(conditionDTO.getEndCreateTime()), UploadRecordPO::getCreateTime, conditionDTO.getEndCreateTime())
                .ge(Objects.nonNull(conditionDTO.getStartUploadTime()), UploadRecordPO::getUploadTime, conditionDTO.getStartUploadTime())
                .le(Objects.nonNull(conditionDTO.getEndUploadTime()), UploadRecordPO::getUploadTime, conditionDTO.getEndUploadTime())
                .eq(Objects.nonNull(conditionDTO.getDistributePlanId()), UploadRecordPO::getDistributePlanId, conditionDTO.getDistributePlanId())
                .eq(Objects.nonNull(conditionDTO.getDistributeStatus()), UploadRecordPO::getDistributeStatus, conditionDTO.getDistributeStatus());
        if (Objects.nonNull(conditionDTO.getIsDelete())) {
            queryWrapper.eq(UploadRecordPO::getIsDelete, conditionDTO.getIsDelete());
        } else {
            queryWrapper.eq(UploadRecordPO::getIsDelete, DeleteEnum.NO.getCode());
        }
        return queryWrapper;
    }

    private void checkPartitionKey(Long distributePlanId) {
        AssertUtils.notNull(distributePlanId, "分流计划id不能为空");
    }
}
