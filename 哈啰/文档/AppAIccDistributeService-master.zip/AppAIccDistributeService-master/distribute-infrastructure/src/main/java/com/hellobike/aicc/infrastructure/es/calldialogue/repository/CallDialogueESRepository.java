package com.hellobike.aicc.infrastructure.es.calldialogue.repository;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hellobike.aicc.common.enums.CallResultEnum;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueStatisticEntity;
import com.hellobike.aicc.infrastructure.es.BaseEsRepository;
import com.hellobike.aicc.infrastructure.es.EsPage;
import com.hellobike.aicc.infrastructure.es.EsQueryWrapper;
import com.hellobike.aicc.infrastructure.es.calldialogue.condition.CallDialogueESCondition;
import com.hellobike.aicc.infrastructure.es.calldialogue.po.CallDialogueESPO;
import com.hellobike.es.sdk.common.EsApplication;
import com.hellobike.es.sdk.common.iface.ISearchRepository;
import com.hellobike.es.sdk.template.RestHighLevelClientFacade;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.support.IndicesOptions;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.filter.FilterAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.filter.ParsedFilter;
import org.elasticsearch.search.aggregations.bucket.terms.ParsedLongTerms;
import org.elasticsearch.search.aggregations.bucket.terms.ParsedStringTerms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.ParsedCardinality;
import org.elasticsearch.search.aggregations.metrics.ParsedSum;
import org.elasticsearch.search.aggregations.metrics.ParsedValueCount;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;

/**
 * @author zhangzhuoqi
 * @since 2025-03-11  14:51:33
 */
@Slf4j
@Service
public class CallDialogueESRepository extends BaseEsRepository {

    private static final String CALL_DIALOGUE_INDEX_PER = "aicc_distribute_t_call_dialogue";


    @Value("${es.search.max.size:10000}")
    private Long maxSize;

    @Value("${jest.client.indexMaxSize:120}")
    private Integer indexMaxSize;


    @Value("${jest.client.indexMaxSize.button:true}")
    private Boolean indexMaxSizeButton;

    @Override
    public String getIndex() {
        return CALL_DIALOGUE_INDEX_PER;
    }

    public boolean save(List<CallDialogueESPO> callDialogueESPOList) {
        try {
            BulkRequest bulkRequest = new BulkRequest();

            for (CallDialogueESPO callDialogueESPO : callDialogueESPOList) {
                LocalDateTime indexDate = callDialogueESPO.getIndexDate();
                callDialogueESPO.setIndexDate(null);

                String indexName = getIndex() + "-" + DateUtils.formatEsIndex(indexDate);

                String jsonDocument;
                try {
                    ObjectMapper mapper = new ObjectMapper();
                    jsonDocument = mapper.writeValueAsString(callDialogueESPO);
                } catch (JsonProcessingException e) {
                    throw new RuntimeException(e);
                }

                IndexRequest indexRequest = new IndexRequest(indexName)
                        .source(jsonDocument, XContentType.JSON)
                        .id(String.valueOf(callDialogueESPO.getId()));

                bulkRequest.add(indexRequest);
            }
            return insertOrUpdateList(bulkRequest);
        }catch (Exception e){
            log.error("保存话单es失败,e:", e);
            return false;
        }

    }

    public EsPage<CallDialogueESPO> pageCallDialogue(CallDialogueESCondition condition) {
        EsQueryWrapper esQueryWrapper = buildQryWrapperByDialogue(condition);
        List<String> indexes = buildCallDialogueIndex(condition);
        FieldSortBuilder sort;
        if (!StrUtil.isEmpty(condition.getSortRule())) {
            sort = SortBuilders.fieldSort(condition.getSortRule()).order(SortOrder.DESC);
        } else {
            sort = SortBuilders.fieldSort(CallDialogueESPO.CREATE_TIME).order(SortOrder.DESC);
        }
        int pageNum = Objects.isNull(condition.getPageNum()) ? 1 : condition.getPageNum();
        int pageSize = Objects.isNull(condition.getPageSize()) ? 10 : condition.getPageSize();

        List<CallDialogueESPO> currentPageData = new ArrayList<>();
        Object[] searchAfterValues;

        int fromIndex = (pageNum - 1) * pageSize;
        int requiredSize = fromIndex + pageSize;
        int fetchedSize = 0;
        long totalCount = count(esQueryWrapper, indexes);

        while (fetchedSize < requiredSize) {
            EsPage<CallDialogueESPO> esPage;
            try {
                esPage = searchWithSearchAfter(esQueryWrapper, CallDialogueESPO.class, sort, maxSize, indexes);
            } catch (IOException e) {
                log.error("roster.searchWithSearchAfter异常", e);
                throw new RuntimeException(e);
            }
            List<CallDialogueESPO> data = esPage.getData();

            if (data.isEmpty()) {
                break;
            }

            int toFetch = Math.min(data.size(), requiredSize - fetchedSize);
            currentPageData.addAll(data.subList(0, toFetch));
            fetchedSize += toFetch;

            // 下次查询值
            searchAfterValues = esPage.getNextSearchAfterValues();
            esQueryWrapper.setSearchAfterValues(searchAfterValues);

            //优化内存，剔除不需要的数据
            data.subList(0, toFetch).clear();
        }

        //计算最终需要的数据
        fromIndex = (pageNum - 1) * pageSize;
        int toIndex = Math.min(fromIndex + pageSize, currentPageData.size());

        List<CallDialogueESPO> pageData = currentPageData.subList(fromIndex, toIndex);
        return new EsPage<>(totalCount, pageNum, pageSize, pageData);

    }

    public EsPage<CallDialogueESPO> scrollQueryForExport(CallDialogueESCondition condition, String scrollId) {
        EsQueryWrapper esQueryWrapper = buildQryWrapperByDialogue(condition);
        List<String> indexes = buildCallDialogueIndex(condition);
        FieldSortBuilder sort;
        if (!StrUtil.isEmpty(condition.getSortRule())) {
            sort = SortBuilders.fieldSort(condition.getSortRule()).order(SortOrder.DESC);
        } else {
            sort = SortBuilders.fieldSort(CallDialogueESPO.CREATE_TIME).order(SortOrder.DESC);
        }
        try {
            EsPage<CallDialogueESPO> page = searchWithScrollV2(esQueryWrapper, CallDialogueESPO.class, CACHE_TIME_10, maxSize, indexes, sort, CallDialogueESPO.ID, false, scrollId);
            log.info("通话记录ES滚动查询 scrollId {}", page.getScrollId());
            return page;
        } catch (Exception e) {
            log.error("话单ES滚动查询异常，e:", e);
            throw new RuntimeException(e);
        }
    }


    private EsQueryWrapper buildQryWrapperByDialogue(CallDialogueESCondition condition) {
        EsQueryWrapper wrapper = new EsQueryWrapper();
        //话单id
        wrapper.eq(CallDialogueESPO.ID, condition.getId());
        //分流计划id
        wrapper.eq(CallDialogueESPO.DISTRIBUTE_PLAN_ID, condition.getDistributePlanId());
        wrapper.eqs(CallDialogueESPO.DISTRIBUTE_PLAN_ID, condition.getDistributePlanIdList());
        //分流计划名称
        wrapper.wildcard(CallDialogueESPO.DISTRIBUTE_PLAN_NAME, wildcardBuild(condition.getDistributePlanName()));
        //平台数据id
        wrapper.eq(CallDialogueESPO.PLATFORM_ID, condition.getPlatformId());
        //md5
        wrapper.eq(CallDialogueESPO.MD5, condition.getMd5());
        //被叫号码
        wrapper.eq(CallDialogueESPO.CALLED_NUMBER, condition.getCalledNumber());
        wrapper.eqs(CallDialogueESPO.CALLED_NUMBER, condition.getCalledNumberList());
        //供应商任务id
        wrapper.eq(CallDialogueESPO.SUPPLIER_TASK_ID, condition.getSupplierTaskId());
        //供应商任务名称
        wrapper.wildcard(CallDialogueESPO.SUPPLIER_TASK_NAME, wildcardBuild(condition.getSupplierTaskName()));
        //呼叫结果
        wrapper.eqs(CallDialogueESPO.CALL_RESULT, condition.getCallResultList());
        //意图分类code
        wrapper.eq(CallDialogueESPO.INTENT_CLASSIFY, Objects.nonNull(condition.getIntentClassify()) ? String.valueOf(condition.getIntentClassify()) : null);
        wrapper.eqs(CallDialogueESPO.INTENT_CLASSIFY, condition.getIntentClassifyList());
        //意图分类名称
        wrapper.wildcard(CallDialogueESPO.INTENT_CLASSIFY_NAME, wildcardBuild(condition.getIntentClassifyName()));
        //命中意图
        if (CollectionUtil.isNotEmpty(condition.getHitIntentions())) {
            BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
            for (String hitIntention : condition.getHitIntentions()) {
                boolQuery.should(QueryBuilders.wildcardQuery(CallDialogueESPO.HIT_INTENTIONS, wildcardBuild(hitIntention)));
            }
            wrapper.build().must(boolQuery);
        }
        //排除命中意图
        if (CollectionUtil.isNotEmpty(condition.getExcludeIntentions())) {
            BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
            for (String excludeIntention : condition.getExcludeIntentions()) {
                boolQuery.mustNot(QueryBuilders.wildcardQuery(CallDialogueESPO.HIT_INTENTIONS, wildcardBuild(excludeIntention)));
            }
            wrapper.build().must(boolQuery);
        }
        //是否命中短信
        wrapper.eq(CallDialogueESPO.IS_HIT_SMS, Objects.nonNull(condition.getIsHitSms()) ? String.valueOf(condition.getIsHitSms()) : null);
        //坐席名称
        wrapper.eq(CallDialogueESPO.SEAT_NAME, condition.getSeatName());
        //通话类型
        wrapper.eq(CallDialogueESPO.CALL_TYPE, Objects.nonNull(condition.getCallType()) ? String.valueOf(condition.getCallType()) : null);
        //AI通话时长
        wrapper.gte(CallDialogueESPO.DURATION_CALL_AI, Objects.nonNull(condition.getDurationCallAiStart()) ? String.valueOf(condition.getDurationCallAiStart()) : null);
        wrapper.lte(CallDialogueESPO.DURATION_CALL_AI, Objects.nonNull(condition.getDurationCallAiEnd()) ? String.valueOf(condition.getDurationCallAiEnd()) : null);
        //人工通话时长
        wrapper.gte(CallDialogueESPO.DURATION_CALL_MANUAL, Objects.nonNull(condition.getDurationCallManualStart()) ? String.valueOf(condition.getDurationCallManualStart()) : null);
        wrapper.lte(CallDialogueESPO.DURATION_CALL_MANUAL, Objects.nonNull(condition.getDurationCallManualEnd()) ? String.valueOf(condition.getDurationCallManualEnd()) : null);
        //中继外显号码
        wrapper.eq(CallDialogueESPO.REAL_CALLING_NUMBER, condition.getRealCallingNumber());
        //呼叫时长
        wrapper.gte(CallDialogueESPO.TOTAL_TIME, Objects.nonNull(condition.getTotalTimeStart()) ? String.valueOf(condition.getTotalTimeStart()) : null);
        wrapper.lte(CallDialogueESPO.TOTAL_TIME, Objects.nonNull(condition.getTotalTimeEnd()) ? String.valueOf(condition.getTotalTimeEnd()) : null);
        //振铃时长
        wrapper.gte(CallDialogueESPO.RING_TIME, Objects.nonNull(condition.getRingTimeStart()) ? String.valueOf(condition.getRingTimeStart()) : null);
        wrapper.lte(CallDialogueESPO.RING_TIME, Objects.nonNull(condition.getRingTimeEnd()) ? String.valueOf(condition.getRingTimeEnd()) : null);
        //开始呼叫时间
        wrapper.gte(CallDialogueESPO.DIAL_TIME, Objects.nonNull(condition.getDialTimeStart()) ? DateUtils.format(condition.getDialTimeStart()) : null);
        wrapper.lte(CallDialogueESPO.DIAL_TIME, Objects.nonNull(condition.getDialTimeEnd()) ? DateUtils.format(condition.getDialTimeEnd()) : null);
        //挂断时间
        wrapper.gte(CallDialogueESPO.HANGUP_TIME, Objects.nonNull(condition.getHangupTimeStart()) ? DateUtils.format(condition.getHangupTimeStart()) : null);
        wrapper.lte(CallDialogueESPO.HANGUP_TIME, Objects.nonNull(condition.getHangupTimeEnd()) ? DateUtils.format(condition.getHangupTimeEnd()) : null);
        //主叫号
        wrapper.eq(CallDialogueESPO.CALLING_NUMBER, condition.getCallingNumber());
        //计费单元数
        wrapper.gte(CallDialogueESPO.COST_UNIT, Objects.nonNull(condition.getCostUnitStart()) ? String.valueOf(condition.getCostUnitStart()) : null);
        wrapper.lte(CallDialogueESPO.COST_UNIT, Objects.nonNull(condition.getCostUnitEnd()) ? String.valueOf(condition.getCostUnitEnd()) : null);
        //性别
        wrapper.eq(CallDialogueESPO.SEX, Objects.nonNull(condition.getSex()) ? String.valueOf(condition.getSex()) : null);
        //挂断方
        wrapper.eq(CallDialogueESPO.RELEASE_INITIATOR, Objects.nonNull(condition.getReleaseInitiator()) ? String.valueOf(condition.getReleaseInitiator()) : null);
        //渠道商通话id
        wrapper.eq(CallDialogueESPO.DIALOGUE_GUID, condition.getDialogueGuid());
        //号码归属城市
        wrapper.eqs(CallDialogueESPO.CITY, condition.getCitys());
        //运营商
        wrapper.eqs(CallDialogueESPO.CARRIER, condition.getCarrierList());
        //对话轮次
        wrapper.gte(CallDialogueESPO.SPEECH_COUNT, Objects.nonNull(condition.getSpeechCountStart()) ? String.valueOf(condition.getSpeechCountStart()) : null);
        wrapper.lte(CallDialogueESPO.SPEECH_COUNT, Objects.nonNull(condition.getSpeechCountEnd()) ? String.valueOf(condition.getSpeechCountEnd()) : null);
        //创建时间
        wrapper.gte(CallDialogueESPO.CREATE_TIME, Objects.nonNull(condition.getCreateTimeStart()) ? DateUtils.format(condition.getCreateTimeStart()) : null);
        wrapper.lte(CallDialogueESPO.CREATE_TIME, Objects.nonNull(condition.getCreateTimeEnd()) ? DateUtils.format(condition.getCreateTimeEnd()) : null);
        //渠道任务id
        wrapper.eq(CallDialogueESPO.CHANNEL_TASK_ID, StrUtil.isNotBlank(condition.getChannelTaskId()) ? condition.getChannelTaskId() : null);
        //渠道id
        wrapper.eq(CallDialogueESPO.CHANNEL_ID, Objects.nonNull(condition.getChannelId()) ? String.valueOf(condition.getChannelId()) : null);
        //租户id
        wrapper.eq(CallDialogueESPO.TENANT_ID, StrUtil.isNotBlank(condition.getTenantId()) ? condition.getTenantId() : null);
        return wrapper;
    }

    private List<String> buildCallDialogueIndex(CallDialogueESCondition condition) {
        List<String> indexes = new ArrayList<>();
        //索引范围优先级 传入的索引 >  创建时间范围 > 全部索引

        //传入的索引
        if (CollectionUtil.isNotEmpty(condition.getIndexes())) {
            return condition.getIndexes();
        }
        LocalDateTime startDate = condition.getCreateTimeStart();
        LocalDateTime endDate = condition.getCreateTimeEnd();
        if (Objects.nonNull(startDate) && Objects.nonNull(endDate)) {
            // 当时间窗口范围过大走全索引*，防止es出现url过长
            if (ChronoUnit.DAYS.between(startDate, endDate) >= indexMaxSize && indexMaxSizeButton) {
                return indexes;
            }
            while (true) {
                if (startDate.isBefore(endDate)) {
                    indexes.add(DateUtils.formatEsIndex(startDate));
                    startDate = startDate.plusDays(1L);
                } else {
                    break;
                }
            }
            indexes.add(DateUtils.formatEsIndex(endDate));
            return indexes;
        }
        indexes.add(ALL_MATCH);
        return indexes;
    }

    public List<CallDialogueStatisticEntity> statDlgByChannelTask(CallDialogueESCondition condition) {
        return statDlg(condition, CallDialogueESPO.CHANNEL_TASK_ID, "group_by_channel_task_id",
                AggregationBuilders.count("callDialogueNum").field(CallDialogueESPO.ID),
                entity -> entity.setChannelTaskId(String.valueOf(entity.getChannelTaskId())));
    }

    public List<CallDialogueStatisticEntity> statDlgByPlan(CallDialogueESCondition condition) {
        return statDlg(condition, CallDialogueESPO.DISTRIBUTE_PLAN_ID, "group_by_dist_plan_id",
                AggregationBuilders.cardinality("callRosterNum").field(CallDialogueESPO.ROSTER_ID),
                entity -> entity.setPlanId(String.valueOf(entity.getPlanId())));
    }

    public CallDialogueStatisticEntity statDlgByTenant(CallDialogueESCondition condition) {

        EsQueryWrapper esQueryWrapper = buildQryWrapperByDialogue(condition);
        List<String> indexList = buildCallDialogueIndex(condition);
        try {
            ISearchRepository searchRepository = EsApplication.getInstance().getSearchRepository(clusterName);
            RestHighLevelClientFacade client = searchRepository.getRestHighLevelClientFacade();

            //接通话单量
            FilterAggregationBuilder throughCallDialogueNum = AggregationBuilders
                    .filter("throughCallDialogueNum", QueryBuilders.termQuery(CallDialogueESPO.CALL_RESULT, CallResultEnum.THROUGH.getCode()))
                    .subAggregation(AggregationBuilders.count("throughCallDialogueNum").field(CallDialogueESPO.ID));

            //计费数
            AggregationBuilder costUnitAgg = AggregationBuilders
                    .sum("costUnit").field(CallDialogueESPO.COST_UNIT);

            AggregationBuilder countAggregation = AggregationBuilders.cardinality("callRosterNum").field(CallDialogueESPO.ROSTER_ID);

            //接通名单数
            FilterAggregationBuilder throughRosterNum = AggregationBuilders
                    .filter("throughRosterNum", QueryBuilders.termQuery(CallDialogueESPO.CALL_RESULT, CallResultEnum.THROUGH.getCode()))
                    .subAggregation(AggregationBuilders.cardinality("throughRosterNum").field(CallDialogueESPO.ROSTER_ID));

            //意图分类统计，限制最多返回100个意图分类
            BoolQueryBuilder filterQuery = QueryBuilders.boolQuery()
                    .must(QueryBuilders.termQuery(CallDialogueESPO.CALL_RESULT, CallResultEnum.THROUGH.getCode()));

            TermsAggregationBuilder intentionStatAgg = AggregationBuilders
                    .terms("intentionStat")
                    .field(CallDialogueESPO.INTENT_CLASSIFY)
                    .size(100);

            FilterAggregationBuilder filteredIntentionStatAgg = AggregationBuilders
                    .filter("filtered_intention_stat", filterQuery)
                    .subAggregation(intentionStatAgg);

            String groupName = "group_by_tenant_id";
            AggregationBuilder aggregationBuilder = AggregationBuilders
                    .terms(groupName)
                    .field(CallDialogueESPO.TENANT_ID)
                    .subAggregation(countAggregation)
                    .subAggregation(throughCallDialogueNum)
                    .subAggregation(costUnitAgg)
                    .subAggregation(throughRosterNum)
                    .subAggregation(filteredIntentionStatAgg);

            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(esQueryWrapper.build())
                    .aggregation(aggregationBuilder)
                    .size(0);

            String[] indexArray = buildIndex(indexList);
            SearchRequest searchRequest = new SearchRequest(indexArray);
            searchRequest.source(searchSourceBuilder);
            searchRequest.indicesOptions(IndicesOptions.fromOptions(true, false, true, false));

            SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
            if (searchResponse == null) {
                log.error("渠道任务话单统计response为null");
                return null;
            }

            Aggregations aggregations = searchResponse.getAggregations();
            ParsedStringTerms term = aggregations.get(groupName);

            if (CollectionUtil.isEmpty(term.getBuckets())) {
                return null;
            }
            Terms.Bucket bucket = term.getBuckets().get(0);

            Map<String, Aggregation> aggregationsAsMap = bucket.getAggregations().getAsMap();

            //计数统计
            ParsedCardinality count = (ParsedCardinality) aggregationsAsMap.get(countAggregation.getName());

            //计费数
            ParsedSum costUnitNum = (ParsedSum) aggregationsAsMap.get("costUnit");

            //接通话单量
            ParsedFilter throughCallDialogueFilter = (ParsedFilter) aggregationsAsMap.get("throughCallDialogueNum");
            ParsedValueCount throughCallDialogueCount = throughCallDialogueFilter.getAggregations().get("throughCallDialogueNum");

            //接通名单量
            ParsedCardinality throughRosterCount = ((ParsedFilter) aggregationsAsMap.get("throughRosterNum")).getAggregations().get("throughRosterNum");

            //意图分类统计
            ParsedStringTerms intentionStatTerms = ((ParsedFilter) aggregationsAsMap.get("filtered_intention_stat")).getAggregations().get("intentionStat");

            // 创建统计实体对象
            CallDialogueStatisticEntity statisticEntity = new CallDialogueStatisticEntity();

            // 意图分类统计
            Map<String, Long> intentionStat = new HashMap<>();
            for (Terms.Bucket intentionBucket : intentionStatTerms.getBuckets()) {
                String intentClassify = intentionBucket.getKeyAsString();
                long docCount = intentionBucket.getDocCount();
                intentionStat.put(intentClassify, docCount);
            }
            statisticEntity.setCallDialogueNum(throughCallDialogueCount.getValue());
            statisticEntity.setCallRosterNum(count.getValue());
            statisticEntity.setCostUnit((long) costUnitNum.getValue());
            statisticEntity.setThroughCallDialogueNum(throughCallDialogueCount.getValue());
            statisticEntity.setThroughRosterNum(throughRosterCount.getValue());
            statisticEntity.setIntentionStat(intentionStat);
            return statisticEntity;

        } catch (Exception e) {
            log.error("统计异常", e);
            return null;
        }
    }

    /**
     * 通用的统计方法
     *
     * @param condition        查询条件
     * @param groupField       分组字段
     * @param groupName        分组名称
     * @param countAggregation 计数聚合
     * @param idSetter         设置ID的回调函数
     * @return 统计结果列表
     */
    private List<CallDialogueStatisticEntity> statDlg(
            CallDialogueESCondition condition,
            String groupField,
            String groupName,
            AggregationBuilder countAggregation,
            Consumer<CallDialogueStatisticEntity> idSetter) {

        EsQueryWrapper esQueryWrapper = buildQryWrapperByDialogue(condition);
        List<String> indexList = buildCallDialogueIndex(condition);
        try {
            ISearchRepository searchRepository = EsApplication.getInstance().getSearchRepository(clusterName);
            RestHighLevelClientFacade client = searchRepository.getRestHighLevelClientFacade();

            //话单量
            AggregationBuilder callDialogueCount = AggregationBuilders.count("callDialogueCount").field(CallDialogueESPO.ID);

            //接通话单量
            FilterAggregationBuilder throughCallDialogueNum = AggregationBuilders
                    .filter("throughCallDialogueNum", QueryBuilders.termQuery(CallDialogueESPO.CALL_RESULT, CallResultEnum.THROUGH.getCode()))
                    .subAggregation(AggregationBuilders.count("throughCallDialogueNum").field(CallDialogueESPO.ID));

            //计费数
            AggregationBuilder costUnit = AggregationBuilders
                    .sum("costUnit").field(CallDialogueESPO.COST_UNIT);

            //接通名单数
            FilterAggregationBuilder throughRosterNum = AggregationBuilders
                    .filter("throughRosterNum", QueryBuilders.termQuery(CallDialogueESPO.CALL_RESULT, CallResultEnum.THROUGH.getCode()))
                    .subAggregation(AggregationBuilders.cardinality("throughRosterNum").field(CallDialogueESPO.ROSTER_ID));

            //意图分类统计，限制最多返回100个意图分类
            BoolQueryBuilder filterQuery = QueryBuilders.boolQuery()
                    .must(QueryBuilders.termQuery(CallDialogueESPO.CALL_RESULT, CallResultEnum.THROUGH.getCode()));

            TermsAggregationBuilder intentionStatAgg = AggregationBuilders
                    .terms("intentionStat")
                    .field(CallDialogueESPO.INTENT_CLASSIFY)
                    .size(100);

            FilterAggregationBuilder filteredIntentionStatAgg = AggregationBuilders
                    .filter("filtered_intention_stat", filterQuery)
                    .subAggregation(intentionStatAgg);

            AggregationBuilder aggregationBuilder = AggregationBuilders
                    .terms(groupName)
                    //统计1000个分流计划
                    .size(1000)
                    .field(groupField)
                    .subAggregation(callDialogueCount)
                    .subAggregation(countAggregation)
                    .subAggregation(throughCallDialogueNum)
                    .subAggregation(costUnit)
                    .subAggregation(throughRosterNum)
                    .subAggregation(filteredIntentionStatAgg);

            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(esQueryWrapper.build())
                    .aggregation(aggregationBuilder)
                    .size(0);

            String[] indexArray = buildIndex(indexList);
            SearchRequest searchRequest = new SearchRequest(indexArray);
            searchRequest.source(searchSourceBuilder);
            searchRequest.indicesOptions(IndicesOptions.fromOptions(true, false, true, false));

            SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
            if (searchResponse == null) {
                log.error("渠道任务话单统计response为null");
                return new ArrayList<>();
            }

            Aggregations aggregations = searchResponse.getAggregations();
            ParsedLongTerms term = aggregations.get(groupName);

            List<CallDialogueStatisticEntity> result = new ArrayList<>();
            for (Terms.Bucket bucket : term.getBuckets()) {
                Long id = (Long) bucket.getKey();
                CallDialogueStatisticEntity statisticEntity = new CallDialogueStatisticEntity();
                statisticEntity.setChannelTaskId(String.valueOf(id));
                statisticEntity.setPlanId(String.valueOf(id));

                Map<String, Aggregation> aggregationsAsMap = bucket.getAggregations().getAsMap();

                //计数统计
                long countValue = 0;
                if (Objects.equals(groupName, "group_by_channel_task_id")){
                    ParsedValueCount parsedValueCount = (ParsedValueCount) aggregationsAsMap.get(countAggregation.getName());
                    countValue = parsedValueCount.getValue();
                }else {
                    ParsedCardinality count = (ParsedCardinality) aggregationsAsMap.get(countAggregation.getName());
                    countValue = count.getValue();
                }


                //计费数
                ParsedSum costUnitNum = (ParsedSum) aggregationsAsMap.get("costUnit");

                ParsedValueCount callDialogueValue = (ParsedValueCount) aggregationsAsMap.get("callDialogueCount");

                //接通话单量
                ParsedFilter throughCallDialogueFilter = (ParsedFilter) aggregationsAsMap.get("throughCallDialogueNum");
                ParsedValueCount throughCallDialogueCount = throughCallDialogueFilter.getAggregations().get("throughCallDialogueNum");

                //接通名单量
                ParsedCardinality throughRosterCount = ((ParsedFilter) aggregationsAsMap.get("throughRosterNum")).getAggregations().get("throughRosterNum");

                //意图分类统计
                ParsedStringTerms intentionStatTerms = ((ParsedFilter) aggregationsAsMap.get("filtered_intention_stat")).getAggregations().get("intentionStat");

                Map<String, Long> intentionStat = new HashMap<>();
                for (Terms.Bucket intentionBucket : intentionStatTerms.getBuckets()) {
                    String intentClassify = intentionBucket.getKeyAsString();
                    long docCount = intentionBucket.getDocCount();
                    intentionStat.put(intentClassify, docCount);
                }

                statisticEntity.setCallDialogueNum(callDialogueValue.getValue());

                //设置统计结果
                if ("callDialogueNum".equals(countAggregation.getName())) {
                    statisticEntity.setCallDialogueNum(countValue);
                } else {
                    statisticEntity.setCallRosterNum(countValue);
                }
                statisticEntity.setCostUnit((long) costUnitNum.getValue());
                statisticEntity.setThroughCallDialogueNum(throughCallDialogueCount.getValue());
                statisticEntity.setThroughRosterNum(throughRosterCount.getValue());
                statisticEntity.setIntentionStat(intentionStat);

                //设置ID
                if (Objects.nonNull(idSetter)) {
                    idSetter.accept(statisticEntity);
                }
                result.add(statisticEntity);
            }
            return result;

        } catch (Exception e) {
            log.error("统计异常", e);
            return new ArrayList<>();
        }
    }

    public long countCallDialogue(CallDialogueESCondition condition) {
        EsQueryWrapper wrapper = buildQryWrapperByDialogue(condition);
        List<String> indexList = buildCallDialogueIndex(condition);
        return count(wrapper, indexList);
    }
}
