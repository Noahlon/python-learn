package com.hellobike.aicc.infrastructure.hms.consumer;

import com.hellobike.hms.sdk.consumer.ConsumeMessage;
import com.hellobike.hms.sdk.consumer.MsgRetryStatus;

/**
 * 消费者基础接口
 *
 **/
public interface IBizMsgConsumer {
    /**
     * 消息处理
     *
     * @param msgBody 消息体
     * @return 消息回执
     */
    MsgRetryStatus msgProcess(ConsumeMessage msgBody);

}
