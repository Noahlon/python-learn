package com.hellobike.aicc.infrastructure.convert;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.distribute.entity.DistributeUploadFileEntity;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributeUploadFilePO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

/**
 * @author fanxiaodongwb230
 * @since 2025-03-17  17:44:42
 */
@Mapper(componentModel = "spring")
public interface DistributeUploadFileConvert {

    DistributeUploadFileEntity convert(DistributeUploadFilePO po);

    List<DistributeUploadFileEntity> convert(List<DistributeUploadFilePO> poList);

    DistributeUploadFilePO convert(DistributeUploadFileEntity entity);

    @Mappings({
            @Mapping(target = "list", source = "records"),
            @Mapping(target = "pageNum", source = "current"),
            @Mapping(target = "pageSize", source = "size"),
            @Mapping(target = "totalRecord", source = "total"),
            @Mapping(target = "totalPages", source = "pages")
    })
    PageResult<DistributeUploadFileEntity> convert(Page<DistributeUploadFilePO> page);
}