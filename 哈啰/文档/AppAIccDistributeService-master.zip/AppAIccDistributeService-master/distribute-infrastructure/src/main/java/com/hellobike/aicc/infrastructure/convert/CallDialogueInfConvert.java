package com.hellobike.aicc.infrastructure.convert;

import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.CallResultEnum;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.dialogue.dto.CallDialogueQueryConditionDTO;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import com.hellobike.aicc.domain.dialogue.entity.DialogueSpeakEntity;
import com.hellobike.aicc.infrastructure.es.EsPage;
import com.hellobike.aicc.infrastructure.es.calldialogue.condition.CallDialogueESCondition;
import com.hellobike.aicc.infrastructure.es.calldialogue.po.CallDialogueESPO;
import com.hellobike.aicc.infrastructure.hms.dto.CallDialogueMsgDTO;
import com.hellobike.aicc.infrastructure.persistence.multi.po.CallDialoguePO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-12  11:12:58
 */
@Mapper(componentModel = "spring",imports = {BaseJsonUtils.class, DateUtils.class, List.class, CallResultEnum.class, DialogueSpeakEntity.class, StrUtil.class})
public interface CallDialogueInfConvert {

    @Mapping(target = "hitIntentions", expression = "java(BaseJsonUtils.writeValue(entity.getHitIntentions()))")
    @Mapping(target = "tags", expression = "java(BaseJsonUtils.writeValue(entity.getTags()))")
    @Mapping(target = "speakInfo", expression = "java(BaseJsonUtils.writeValue(entity.getSpeakList()))")
    CallDialoguePO toPO(CallDialogueEntity entity);

    @Mapping(target = "hitIntentions", expression = "java(BaseJsonUtils.readValue(po.getHitIntentions(), List.class))")
    @Mapping(target = "tags", expression = "java(BaseJsonUtils.readValue(po.getTags(), List.class))")
    @Mapping(target = "speakList", expression = "java(StrUtil.isNotBlank(po.getSpeakInfo()) ? BaseJsonUtils.readValues(po.getSpeakInfo(), DialogueSpeakEntity.class) : null)")
    CallDialogueEntity toEntity(CallDialoguePO po);

    @Mapping(target = "dialTime", expression = "java(DateUtils.format(callDialoguePO.getDialTime()))")
    @Mapping(target = "hangupTime", expression = "java(DateUtils.format(callDialoguePO.getHangupTime()))")
    @Mapping(target = "createTime", expression = "java(DateUtils.format(callDialoguePO.getCreateTime()))")
    @Mapping(target = "updateTime", expression = "java(DateUtils.format(callDialoguePO.getUpdateTime()))")
    @Mapping(target = "answerTime", expression = "java(DateUtils.format(callDialoguePO.getAnswerTime()))")
    @Mapping(target = "hitIntentions", expression = "java(BaseJsonUtils.readValue(callDialoguePO.getHitIntentions(), List.class))")
    @Mapping(target = "tags", expression = "java(BaseJsonUtils.readValue(callDialoguePO.getTags(), List.class))")
    CallDialogueESPO poToES(CallDialoguePO callDialoguePO);

    CallDialogueESCondition toESCondition(CallDialogueQueryConditionDTO condition);

    @Mapping(target = "dialTime", expression = "java(DateUtils.toLocalDateTime(callDialogueESPO.getDialTime()))")
    @Mapping(target = "hangupTime", expression = "java(DateUtils.toLocalDateTime(callDialogueESPO.getHangupTime()))")
    @Mapping(target = "createTime", expression = "java(DateUtils.toLocalDateTime(callDialogueESPO.getCreateTime()))")
    @Mapping(target = "updateTime", expression = "java(DateUtils.toLocalDateTime(callDialogueESPO.getUpdateTime()))")
    @Mapping(target = "answerTime", expression = "java(DateUtils.toLocalDateTime(callDialogueESPO.getAnswerTime()))")
    CallDialogueEntity esPOToEntity(CallDialogueESPO callDialogueESPO);

    List<CallDialogueEntity> esPOListToEntityList(List<CallDialogueESPO> callDialogueESPOList);


    default PageResult<CallDialogueEntity> esPageToPageResult(EsPage<CallDialogueESPO> esPage) {
        PageResult<CallDialogueEntity> pageResult = new PageResult<>();
        pageResult.setPageNum(esPage.getCurrentPage());
        pageResult.setPageSize(esPage.getPageSize());
        pageResult.setTotalRecord(esPage.getTotalSize());
        pageResult.setTotalPages(esPage.getTotalPages());
        pageResult.setList(esPOListToEntityList(esPage.getData()));
        return pageResult;
    }

    @Mapping(target = "dataIdentifier", source = "externalId")
    @Mapping(target = "callResult", source = "callResult")
    @Mapping(target = "callResultDesc", expression = "java(entity.getCallResult() != null ? CallResultEnum.getDescByCode(entity.getCallResult()) : null)")
    @Mapping(target = "dialogueGuid", source = "id")
    @Mapping(target = "dialTime", expression = "java(DateUtils.format2MilliSecond(entity.getDialTime()))")
    @Mapping(target = "hangupTime", expression = "java(DateUtils.format2MilliSecond(entity.getHangupTime()))")
    CallDialogueMsgDTO callDialogueEntity2DTO(CallDialogueEntity entity);
}
