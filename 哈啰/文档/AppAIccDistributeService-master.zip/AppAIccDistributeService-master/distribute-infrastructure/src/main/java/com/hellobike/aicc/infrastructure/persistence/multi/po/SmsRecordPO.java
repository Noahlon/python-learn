package com.hellobike.aicc.infrastructure.persistence.multi.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 数据密级S2,分流平台短信记录
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_sms_record")
public class SmsRecordPO implements Serializable {
    private static final long serialVersionUID = 1L;

    @TableId(value = "guid", type = IdType.INPUT)
    private Long guid;

    /**
     * 数据密级S2,名单id
     */
    @TableField("roster_id")
    private Long rosterId;

    /**
     * 数据密级S2,平台数据唯一标识
     */
    @TableField("platform_id")
    private String platformId;

    /**
     * 数据密级S2,创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,逻辑删除
     */
    @TableField("is_delete")
    private Integer isDelete;

    /**
     * 渠道商id
     */
    @TableField("channel_id")
    private Integer channelId;

    /**
     * 渠道商名称
     */
    @TableField("channel_name")
    private String channelName;

    /**
     * 客户数据标识
     */
    @TableField("external_id")
    private String externalId;

    /**
     * 手机号码
     */
    @TableField("phone_number")
    private String phoneNumber;

    /**
     * 手机号码的32位小写md5加密
     */
    @TableField("phone_number_md5")
    private String phoneNumberMd5;

    /**
     * 分流计划id
     */
    @TableField("distribute_plan_id")
    private Long distributePlanId;

    /**
     * 渠道任务id
     */
    @TableField("channel_task_id")
    private Long channelTaskId;

    /**
     * 分流计划名称
     */
    @TableField("distribute_plan_name")
    private String distributePlanName;

    /**
     * 分流计划平台对应话单id
     */
    @TableField("distribute_plan_call_id")
    private Long distributePlanCallId;

    /**
     * 渠道商任务id
     */
    @TableField("supplier_task_id")
    private String supplierTaskId;

    /**
     * 渠道商任务名称
     */
    @TableField("supplier_task_name")
    private String supplierTaskName;

    /**
     * 企业id
     */
    @TableField("enterprise_id")
    private String enterpriseId;

    /**
     * 话术名称
     */
    @TableField("speech_name")
    private String speechName;

    /**
     * 租户code
     */
    @TableField("tenant_code")
    private String tenantCode;

    /**
     * 短信签名
     */
    @TableField("signature")
    private String signature;

    /**
     * 短信内容
     */
    @TableField("content")
    private String content;

    /**
     * 短信提交时间
     */
    @TableField("submit_time")
    private LocalDateTime submitTime;

    /**
     * 短信提交结果
     */
    @TableField("submit_result")
    private Integer submitResult;

    /**
     * 短信发送时间
     */
    @TableField("send_time")
    private LocalDateTime sendTime;

    /**
     * 短信发送结果
     */
    @TableField("send_result")
    private Integer sendResult;

    /**
     * 收到短信结果时间
     */
    @TableField("receive_result_time")
    private LocalDateTime receiveResultTime;

    /**
     * 计费条数
     */
    @TableField("billing_num")
    private Integer billingNum;

    /**
     * 坐席id
     */
    @TableField("seats_guid")
    private String seatsGuid;

    /**
     * 坐席名称
     */
    @TableField("seats_name")
    private String seatsName;

    /**
     * 客户名称
     */
    @TableField("custom_name")
    private String customName;

    /**
     * 渠道商通话记录id
     */
    @TableField("supplier_call_guid")
    private String supplierCallGuid;

    /**
     * 渠道商短信记录id
     */
    @TableField("supplier_sms_guid")
    private String supplierSmsGuid;

    /**
     * 运营商
     */
    @TableField("carrier")
    private Integer carrier;

    /**
     * 省份
     */
    @TableField("province")
    private String province;

    /**
     * 城市
     */
    @TableField("city")
    private String city;
}
