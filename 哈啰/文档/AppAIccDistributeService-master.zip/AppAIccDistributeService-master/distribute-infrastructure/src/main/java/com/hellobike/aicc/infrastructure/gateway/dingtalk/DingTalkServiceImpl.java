package com.hellobike.aicc.infrastructure.gateway.dingtalk;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.dingtalk.api.DefaultDingTalkClient;
import com.dingtalk.api.DingTalkClient;
import com.dingtalk.api.request.OapiRobotSendRequest;
import com.hellobike.aicc.common.component.ApolloConfigs;
import com.hellobike.aicc.domain.common.service.DingTalkService;
import com.taobao.api.TaobaoResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
@Slf4j
public class DingTalkServiceImpl implements DingTalkService {
    private static final String url = "https://oapi.dingtalk.com/robot/send?access_token=";

    private static final String MARK_DOWN = "markdown";

    @Resource
    private ApolloConfigs apolloConfigs;

    @Override
    public void sendChannelTaskCreateFailedAlert(Long planId, String channelName) {
        StringBuilder sb = new StringBuilder();
        sb.append("<strong><font color=red size=10>【渠道任务创建失败告警】</font></strong>").append("\n");
        sb.append("分流计划ID：").append(planId).append("\n");
        sb.append("渠道商名称：").append(channelName).append("\n");
        String text = sb.toString().replace("\n", "  \n");
        sendDingMsg("分流计划渠道任务创建失败告警", text);
    }

    @Override
    public void sendRosterDistributeFailedAlert(Long planId, String tenantName, String templateName, String failReason) {
        StringBuilder sb = new StringBuilder();
        sb.append("<strong><font color=red size=10>【名单下发失败告警】</font></strong>").append("\n");
        sb.append("分流计划ID：").append(planId).append("\n");
        if (StrUtil.isNotBlank(templateName)) {
            sb.append("模板名称：").append(templateName).append("\n");
        }
        if (StrUtil.isNotBlank(tenantName)) {
            sb.append("租户名称：").append(tenantName).append("\n");
        }
        sb.append("下发失败原因：").append(failReason).append("\n");
        String text = sb.toString().replace("\n", "  \n");
        sendDingMsg("分流计划名单下发失败告警", text);
    }

    @Override
    public void sendDialogueFailedAlert(String bizId) {
        StringBuilder sb = new StringBuilder();
        sb.append("<strong><font color=red size=10>【话单消费失败告警】</font></strong>").append("\n");
        sb.append("BIZ ID：").append(bizId).append("\n");
        String text = sb.toString().replace("\n", "  \n");
        sendDingMsg("分流话单消费失败告警", text);
    }

    @Override
    public void sendSmsRecordFailedAlert(String bizId) {
        StringBuilder sb = new StringBuilder();
        sb.append("<strong><font color=red size=10>【短信记录消费失败告警】</font></strong>").append("\n");
        sb.append("BIZ ID：").append(bizId).append("\n");
        String text = sb.toString().replace("\n", "  \n");
        sendDingMsg("分流短信记录消费失败告警", text);
    }

    @Override
    public void sendRosterFailedAlert(String messageId) {
        StringBuilder sb = new StringBuilder();
        sb.append("<strong><font color=red size=10>【名单更新失败告警】</font></strong>").append("\n");
        sb.append("MESSAGE ID：").append(messageId).append("\n");
        String text = sb.toString().replace("\n", "  \n");
        sendDingMsg("分流名单更新失败告警", text);
    }

    @Override
    public void sendChannelApiFail(String channelName, String apiName, String failReason) {
        StringBuilder sb = new StringBuilder();
        sb.append("<strong><font color=red size=10>【调用渠道商接口失败告警】</font></strong>").append("\n");
        sb.append("渠道商：").append(channelName).append("\n");
        sb.append("接口：").append(apiName).append("\n");
        sb.append("错误原因：").append(failReason).append("\n");
        String text = sb.toString().replace("\n", "  \n");
        sendDingMsg("分流调用渠道商接口失败告警", text);
    }

    private void sendDingMsg(String title, String text) {
        String dingTalkToken = apolloConfigs.getDingTalkToken();
        try {
            DingTalkClient client = new DefaultDingTalkClient(url + dingTalkToken);
            OapiRobotSendRequest request = new OapiRobotSendRequest();
            request.setMsgtype(MARK_DOWN);
            OapiRobotSendRequest.Markdown msgContent = new OapiRobotSendRequest.Markdown();
            String env = System.getProperty("env");
            msgContent.setTitle(StrUtil.isBlank(env) ? title : env + "-" + title);
            msgContent.setText(text);
            request.setMarkdown(msgContent);
            TaobaoResponse response = client.execute(request);
            log.info("钉钉消息响应：{}", JSON.toJSONString(response));
        } catch (Exception e) {
            log.error("发送钉钉消息异常：{}，token: {}，text: {}，title：{}", e, dingTalkToken, text, title);
        }
    }
}
