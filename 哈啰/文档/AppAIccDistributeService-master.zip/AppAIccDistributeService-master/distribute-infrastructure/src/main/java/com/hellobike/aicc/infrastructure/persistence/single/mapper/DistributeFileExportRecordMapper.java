package com.hellobike.aicc.infrastructure.persistence.single.mapper;

import com.hellobike.aicc.infrastructure.persistence.single.po.DistributeFileExportRecordPO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 数据密级S2,分流平台文件导出记录 Mapper 接口
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-05-22
 */
public interface DistributeFileExportRecordMapper extends BaseMapper<DistributeFileExportRecordPO> {

}
