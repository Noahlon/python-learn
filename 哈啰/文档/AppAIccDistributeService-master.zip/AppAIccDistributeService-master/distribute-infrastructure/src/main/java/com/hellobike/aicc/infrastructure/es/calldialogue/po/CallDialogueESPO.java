package com.hellobike.aicc.infrastructure.es.calldialogue.po;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.searchbox.annotations.JestId;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-11  14:44:44
 */
@Data
public class CallDialogueESPO {

    /**
     * 话单id
     */
    @JestId
    private Long id;

    /**
     * 数据密级S2,企业id
     */
    private String enterpriseId;

    /**
     * 数据密级S2,呼叫结果
     */
    private Integer callResult;

    /**
     * 数据密级S2,供应商呼叫结果code
     */
    private String supplierCallResult;

    /**
     * 数据密级S2,意向分类code
     */
    private String intentClassify;

    /**
     * 数据密级S2,意向分类名称
     */
    private String intentClassifyName;

    /**
     * 数据密级S2,命中意图
     */
    private List<String> hitIntentions;

    /**
     * 数据密级S2,是否触发短信
     */
    private Integer isHitSms;

    /**
     * 数据密级S2,ai段时长
     */
    private Integer durationCallAi;

    /**
     * 数据密级S2,人工段时长
     */
    private Integer durationCallManual;

    /**
     * 数据密级S2,中继外显号
     */
    private String realCallingNumber;

    /**
     * 数据密级S2,通话时长
     */
    private Integer totalTime;

    /**
     * 数据密级S2,振铃时长
     */
    private Integer ringTime;

    /**
     * 数据密级S2,拨打时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String dialTime;

    /**
     * 数据密级S2,挂机时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String hangupTime;

    /**
     * 数据密级S2,接通时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String answerTime;

    /**
     * 数据密级S2,通话类型
     */
    private Integer callType;

    /**
     * 数据密级S2,主叫号码
     */
    private String callingNumber;

    /**
     * 数据密级S2,计费单元数
     */
    private Integer costUnit;

    /**
     * 数据密级S2,客户姓名
     */
    private String customName;

    /**
     * 数据密级S2,通话唯一id
     */
    private String dialogueGuid;

    /**
     * 数据密级S2,通话录音地址
     */
    private String recordUrl;

    /**
     * 数据密级S2,线路id
     */
    private String lineId;

    /**
     * 数据密级S2,号码归属城市
     */
    private String city;

    /**
     * 数据密级S2,号码归属省份
     */
    private String province;

    /**
     * 数据密级S2,运营商
     */
    private Integer carrier;

    /**
     * 数据密级S2,对话轮次
     */
    private Integer speechCount;

    /**
     * 数据密级S2,性别
     */
    private Integer sex;

    /**
     * 数据密级S2,挂断方
     */
    private Integer releaseInitiator;

    /**
     * 数据密级S2,外部数据唯一标识
     */
    private String externalId;

    /**
     * 数据密级S2,平台数据唯一标识
     */
    private String platformId;

    /**
     * 数据密级S2,被叫号
     */
    private String calledNumber;

    /**
     * 数据密级S2,渠道任务id
     */
    private Long channelTaskId;

    /**
     * 数据密级S2,扩展信息
     */
    private String extInfo;

    /**
     * 数据密级S2,三方任务id
     */
    private String supplierTaskId;

    /**
     * 数据密级S2,三方任务名称
     */
    private String supplierTaskName;

    /**
     * 数据密级S2,三方任务模版id
     */
    private String supplierTaskTemplateId;

    /**
     * 数据密级S2,名单id
     */
    private Long rosterId;

    /**
     * 数据密级S2,分流计划id
     */
    private Long distributePlanId;

    /**
     * 数据密级S2,分流计划名称
     */
    private String distributePlanName;

    /**
     * 数据密级S2,手机号md5
     */
    private String md5;

    /**
     * 数据密级S2,座席名称
     */
    private String seatName;

    /**
     * 数据密级S2,创建时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String updateTime;

    /**
     * 索引日期
     */
    private LocalDateTime indexDate;

    /**
     * 数据密级S2,逻辑删除
     */
    private Integer isDelete;

    /**
     * 数据密级S2,知识标签
     */
    private List<String> tags;

    /**
     * 数据密级S2,说话次数
     */
    private Integer speakCount;

    /**
     * 数据密级S2,分流计划模版id
     */
    private Long templateId;

    /**
     * 数据密级S2,渠道id
     */
    private Integer channelId;

    /**
     * 数据密级S2,渠道名称
     */
    private String channelName;

    /**
     * 数据密级S2,租户id
     */
    private String tenantId;


    public static final String ID = "id";

    public static final String CREATE_TIME = "createTime";

    public static final String UPDATE_TIME = "updateTime";

    public static final String IS_DELETE = "isDelete";

    public static final String ENTERPRISE_ID = "enterpriseId";

    public static final String CALL_RESULT = "callResult";

    public static final String INTENT_CLASSIFY = "intentClassify";

    public static final String INTENT_CLASSIFY_NAME = "intentClassifyName";

    public static final String HIT_INTENTIONS = "hitIntentions";

    public static final String IS_HIT_SMS = "isHitSms";

    public static final String DURATION_CALL_AI = "durationCallAi";

    public static final String DURATION_CALL_MANUAL = "durationCallManual";

    public static final String REAL_CALLING_NUMBER = "realCallingNumber";

    public static final String TOTAL_TIME = "totalTime";

    public static final String RING_TIME = "ringTime";

    public static final String DIAL_TIME = "dialTime";

    public static final String HANGUP_TIME = "hangupTime";

    public static final String CALL_TYPE = "callType";

    public static final String CALLING_NUMBER = "callingNumber";

    public static final String COST_UNIT = "costUnit";

    public static final String CUSTOM_NAME = "customName";

    public static final String DIALOGUE_GUID = "dialogueGuid";

    public static final String RECORD_URL = "recordUrl";

    public static final String LINE_ID = "lineId";

    public static final String ATTRIBUTION = "attribution";

    public static final String CARRIER = "carrier";

    public static final String SPEECH_COUNT = "speechCount";

    public static final String SEX = "sex";

    public static final String RELEASE_INITIATOR = "releaseInitiator";

    public static final String EXTERNAL_ID = "externalId";

    public static final String PLATFORM_ID = "platformId";

    public static final String CALLED_NUMBER = "calledNumber";

    public static final String CHANNEL_TASK_ID = "channelTaskId";

    public static final String EXT_INFO = "extInfo";

    public static final String SUPPLIER_TASK_ID = "supplierTaskId";

    public static final String SUPPLIER_TASK_NAME = "supplierTaskName";

    public static final String SUPPLIER_TASK_TEMPLATE_ID = "supplierTaskTemplateId";

    public static final String ROSTER_ID = "rosterId";

    public static final String DISTRIBUTE_PLAN_ID = "distributePlanId";

    public static final String DISTRIBUTE_PLAN_NAME = "distributePlanName";

    public static final String MD5 = "md5";

    public static final String SEAT_NAME = "seatName";

    public static final String CITY = "city";

    public static final String PROVINCE = "province";

    public static final String ANSWER_TIME = "answerTime";

    public static final String SUPPLIER_CALL_RESULT = "supplierCallResult";

    public static final String TEMPLATE_ID = "templateId";

    public static final String CHANNEL_ID = "channelId";

    public static final String CHANNEL_NAME = "channelName";

    public static final String TENANT_ID = "tenantId";

}
