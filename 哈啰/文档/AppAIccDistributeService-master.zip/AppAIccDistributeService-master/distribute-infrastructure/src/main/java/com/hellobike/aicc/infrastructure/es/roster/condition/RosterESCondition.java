package com.hellobike.aicc.infrastructure.es.roster.condition;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-05-23  13:45:31
 */
@Data
public class RosterESCondition {

    /**
     * 索引日期(分流计划创建时间，必传)
     */
    private List<LocalDateTime> indexList;

    /**
     * 名单id
     */
    private String id;

    /**
     * 分流计划id
     */
    private String distributePlanId;

    /**
     * 分流计划id集合
     */
    private List<String> distributePlanIdList;

    /**
     * 渠道id
     */
    private Integer channelId;

    /**
     * 租户id
     */
    private String tenantId;


}
