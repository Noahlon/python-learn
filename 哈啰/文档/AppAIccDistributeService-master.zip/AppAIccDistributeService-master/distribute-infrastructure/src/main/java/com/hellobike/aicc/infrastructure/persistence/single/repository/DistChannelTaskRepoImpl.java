package com.hellobike.aicc.infrastructure.persistence.single.repository;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hellobike.aicc.common.component.ApolloConfigs;
import com.hellobike.aicc.common.enums.DeleteEnum;
import com.hellobike.aicc.common.enums.PlanChannelTaskStatusEnum;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueStatisticEntity;
import com.hellobike.aicc.domain.distribute.repo.DistChannelTaskRepo;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributeChannelTaskQryCondition;
import com.hellobike.aicc.domain.roster.entity.RosterStat;
import com.hellobike.aicc.domain.smsrecord.entity.ChannelTaskSmsStat;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordCondition;
import com.hellobike.aicc.infrastructure.convert.DistributeChannelTaskInfConvert;
import com.hellobike.aicc.infrastructure.es.calldialogue.condition.CallDialogueESCondition;
import com.hellobike.aicc.infrastructure.es.calldialogue.repository.CallDialogueESRepository;
import com.hellobike.aicc.infrastructure.es.roster.condition.RosterESCondition;
import com.hellobike.aicc.infrastructure.es.roster.repository.RosterESRepository;
import com.hellobike.aicc.infrastructure.es.smsrecord.repository.SmsRecordESRepository;
import com.hellobike.aicc.infrastructure.persistence.single.mapper.DistributeChannelTaskMapper;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributeChannelTaskPO;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * <p>
 * 数据密级S2,分流渠道任务表 服务实现类
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Service
public class DistChannelTaskRepoImpl extends ServiceImpl<DistributeChannelTaskMapper, DistributeChannelTaskPO> implements DistChannelTaskRepo {
    @Resource
    private DistributeChannelTaskInfConvert distributeChannelTaskInfConvert;

    @Resource
    private CallDialogueESRepository callDialogueESRepository;

    @Resource
    private SmsRecordESRepository smsRecordESRepository;

    @Resource
    private RosterESRepository rosterESRepository;

    @Resource
    private ApolloConfigs apolloConfigs;

    @Override
    public void createDistributeChannelTask(DistributeChannelTaskEntity distributeChannelTaskEntity) {
        DistributeChannelTaskPO po = distributeChannelTaskInfConvert.convert(distributeChannelTaskEntity);
        save(po);
    }

    @Override
    public DistributeChannelTaskEntity queryById(Long distributeChannelTaskId) {
        LambdaQueryWrapper<DistributeChannelTaskPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributeChannelTaskPO::getId, distributeChannelTaskId)
                .eq(DistributeChannelTaskPO::getIsDelete, DeleteEnum.NO.getCode());
        DistributeChannelTaskPO po = this.getBaseMapper().selectOne(queryWrapper);
        return distributeChannelTaskInfConvert.convert(po);
    }

    @Override
    public void updateDistributeChannelTask(DistributeChannelTaskEntity distributeChannelTaskEntity) {
        DistributeChannelTaskPO po = distributeChannelTaskInfConvert.convert(distributeChannelTaskEntity);
        updateById(po);
    }

    @Override
    public void updateWhenDistribute(DistributeChannelTaskEntity taskEntity) {
        LambdaUpdateWrapper<DistributeChannelTaskPO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.set(DistributeChannelTaskPO::getLatestSentTime, taskEntity.getLatestSentTime());
        //下发总量累加
        updateWrapper.setSql(" sent_total_num = sent_total_num + " + taskEntity.getSentTotalNum());
        //下发成功数量累加
        updateWrapper.setSql(" sent_success_num = sent_success_num + " + taskEntity.getSentSuccessNum());
        updateWrapper.eq(DistributeChannelTaskPO::getId, taskEntity.getId());

        update(updateWrapper);
    }

    @Override
    public List<DistributeChannelTaskEntity> queryDistributePlanTaskList(Long distributePlanId) {
        LambdaQueryWrapper<DistributeChannelTaskPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributeChannelTaskPO::getDistributePlanId, distributePlanId)
                .eq(DistributeChannelTaskPO::getIsDelete, DeleteEnum.NO.getCode());
        return distributeChannelTaskInfConvert.convert(this.getBaseMapper().selectList(queryWrapper));
    }

    @Override
    public List<DistributeChannelTaskEntity> queryTaskListByPlanIdList(List<Long> distributePlanIdList) {
        LambdaQueryWrapper<DistributeChannelTaskPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.in(DistributeChannelTaskPO::getDistributePlanId, distributePlanIdList)
                .eq(DistributeChannelTaskPO::getIsDelete, DeleteEnum.NO.getCode());
        return distributeChannelTaskInfConvert.convert(this.getBaseMapper().selectList(queryWrapper));
    }

    @Override
    public List<DistributeChannelTaskEntity> queryEsPlanTaskList(Long distributePlanId, LocalDateTime planCreateTime) {
        LambdaQueryWrapper<DistributeChannelTaskPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributeChannelTaskPO::getDistributePlanId, distributePlanId)
                .eq(DistributeChannelTaskPO::getIsDelete, DeleteEnum.NO.getCode())
                .eq(DistributeChannelTaskPO::getTaskStatus, PlanChannelTaskStatusEnum.SUCCESS.getCode())
                .orderByDesc(DistributeChannelTaskPO::getCreateTime);
        List<DistributeChannelTaskEntity> taskEntityList = distributeChannelTaskInfConvert.convert(this.getBaseMapper().selectList(queryWrapper));
        if (CollectionUtils.isEmpty(taskEntityList)) {
            return Collections.emptyList();
        }

        // 查询 ES 中的数据
        CallDialogueESCondition condition = new CallDialogueESCondition();
        condition.setDistributePlanId(String.valueOf(distributePlanId));
        condition.setIndexes(DateUtils.getDatesBetween(planCreateTime, LocalDateTime.now()));
        List<CallDialogueStatisticEntity> taskDialogueStatisticList = callDialogueESRepository.statDlgByChannelTask(condition);

        SmsRecordCondition smsCondition = new SmsRecordCondition();
        smsCondition.setDistributePlanId(String.valueOf(distributePlanId));
        smsCondition.setIndexes(DateUtils.getMonthBetween(planCreateTime, LocalDateTime.now()));
        List<ChannelTaskSmsStat> taskSmsStat = smsRecordESRepository.smsStatByChannelTask(smsCondition);

        // 将 taskDialogueStatisticList 转换为 Map，以提高查找效率
        Map<String, CallDialogueStatisticEntity> statisticMap = taskDialogueStatisticList.stream()
                .collect(Collectors.toMap(CallDialogueStatisticEntity::getChannelTaskId, statistic -> statistic));

        Map<String, ChannelTaskSmsStat> smsStatMap = taskSmsStat.stream()
                .collect(Collectors.toMap(ChannelTaskSmsStat::getChannelTaskId, statistic -> statistic));

        Map<String, RosterStat> rosterStatMap = new HashMap<>();
        if (planCreateTime.isAfter(DateUtils.toLocalDateTime(apolloConfigs.getStatV2Time()))){
            //再此之后创建的分流计划从名单es中统计名单相关数据
            RosterESCondition rosterESCondition = new RosterESCondition();
            rosterESCondition.setDistributePlanId(String.valueOf(distributePlanId));
            rosterESCondition.setIndexList(Collections.singletonList(planCreateTime));
            List<RosterStat> rosterStatList = rosterESRepository.statByChannelTask(rosterESCondition);
            rosterStatMap = rosterStatList.stream()
                    .collect(Collectors.toMap(RosterStat::getChannelTaskId, Function.identity()));
        }

        // 遍历 taskEntityList，根据 channelTaskId 从 statisticMap 中获取对应的 CallDialogueStatisticEntity 进行赋值
        Map<String, RosterStat> finalRosterStatMap = rosterStatMap;
        taskEntityList.forEach(entity -> {
            CallDialogueStatisticEntity statistic = statisticMap.get(String.valueOf(entity.getId()));
            ChannelTaskSmsStat smsStat = smsStatMap.get(String.valueOf(entity.getId()));
            RosterStat rosterStat = finalRosterStatMap.get(String.valueOf(entity.getId()));
            if (statistic != null) {
                entity.setCallDialogueNum(statistic.getCallDialogueNum());
                entity.setThroughCallDialogueNum(statistic.getThroughCallDialogueNum());
                entity.setCostUnit(statistic.getCostUnit());
                entity.setThroughRosterNum(statistic.getThroughRosterNum());
                entity.setIntentionStat(statistic.getIntentionStat());
            }
            if (smsStat != null) {
                entity.setSendSmsSum(smsStat.getSendSum());
                entity.setSmsSuccSum(smsStat.getSuccSum());
                entity.setSmsUnit(smsStat.getSmsUnit());
            }
            if (rosterStat != null) {
                entity.setThroughRosterNum(rosterStat.getThroughRosterNum());
                entity.setSendSmsSum(rosterStat.getSendSmsRosterNum());
                entity.setSmsSuccSum(rosterStat.getSendSmsSuccRosterNum());
            }
        });

        return taskEntityList;
    }

    @Override
    public List<DistributeChannelTaskEntity> queryByCondition(DistributeChannelTaskQryCondition condition) {
        LambdaQueryWrapper<DistributeChannelTaskPO> wrapper = buildQueryWrapper(condition);
        List<DistributeChannelTaskPO> list = this.list(wrapper);
        if (CollectionUtil.isEmpty(list)){
            return Collections.emptyList();
        }
        return distributeChannelTaskInfConvert.convert(list);
    }

    private LambdaQueryWrapper<DistributeChannelTaskPO> buildQueryWrapper(DistributeChannelTaskQryCondition condition) {
        LambdaQueryWrapper<DistributeChannelTaskPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(StrUtil.isNotBlank(condition.getSupplierTaskTemplateId()), DistributeChannelTaskPO::getSupplierTaskTemplateId, condition.getSupplierTaskTemplateId())
                .like(StrUtil.isNotBlank(condition.getSupplierTaskTemplateName()), DistributeChannelTaskPO::getSupplierTaskTemplateName, condition.getSupplierTaskTemplateName());
        return queryWrapper;
    }
}
