package com.hellobike.aicc.infrastructure.persistence.single.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 数据密级S2,分流计划统计表
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-05-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_distribute_plan_stat")
public class DistributePlanStatPO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id" ,type = IdType.INPUT)
    private Long id;

    /**
     * 数据密级S2,创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,是否删除
     */
    @TableField("is_delete")
    private Integer isDelete;

    /**
     * 数据密级S2,分流计划id
     */
    @TableField("distribute_plan_id")
    private Long distributePlanId;

    /**
     * 数据密级S2,分流计划名称
     */
    @TableField("distribute_plan_name")
    private String distributePlanName;

    /**
     * 数据密级S2,租户id
     */
    @TableField("tenant_id")
    private String tenantId;

    /**
     * 数据密级S2,租户名称
     */
    @TableField("tenant_name")
    private String tenantName;

    /**
     * 数据密级S2,上传数据量
     */
    @TableField("upload_data_num")
    private Integer uploadDataNum;

    /**
     * 数据密级S2,已呼名单数
     */
    @TableField("call_roster_num")
    private Integer callRosterNum;

    /**
     * 数据密级S2,接通话单量
     */
    @TableField("through_call_dialogue_num")
    private Integer throughCallDialogueNum;

    /**
     * 数据密级S2,话单计费数
     */
    @TableField("cost_unit")
    private Integer costUnit;

    /**
     * 数据密级S2,接通名单数
     */
    @TableField("through_roster_num")
    private Integer throughRosterNum;

    /**
     * 数据密级S2,发送短信名单数
     */
    @TableField("send_sms_roster_num")
    private Integer sendSmsRosterNum;

    /**
     * 数据密级S2,发送短信成功名单数
     */
    @TableField("sms_succ_roster_num")
    private Integer smsSuccRosterNum;

    /**
     * 数据密级S2,短信计费数
     */
    @TableField("sms_unit")
    private Integer smsUnit;

    /**
     * 数据密级S2,意向统计
     */
    @TableField("intentionStat")
    private String intentionStat;

    /**
     * 数据密级S2,分流计划创建时间
     */
    @TableField("plan_create_time")
    private LocalDateTime planCreateTime;

    /**
     * 数据密级S2,最近一次统计时间
     */
    @TableField("last_stat_time")
    private LocalDateTime lastStatTime;

    /**
     * 数据密级S2,话单量
     */
    @TableField("call_dialogue_num")
    private Integer callDialogueNum;

    /**
     * 数据密级S2,下发总数据量
     */
    @TableField("sentTotalNum")
    private Integer sentTotalNum;

    /**
     * 数据密级S2,下发成功数据量
     */
    @TableField("sentSuccessNum")
    private Integer sentSuccessNum;


    public static final String CREATE_TIME = "create_time";

    public static final String UPDATE_TIME = "update_time";

    public static final String IS_DELETE = "is_delete";

    public static final String DISTRIBUTE_PLAN_ID = "distribute_plan_id";

    public static final String DISTRIBUTE_PLAN_NAME = "distribute_plan_name";

    public static final String TENANT_ID = "tenant_id";

    public static final String TENANT_NAME = "tenant_name";

    public static final String UPLOAD_DATA_NUM = "upload_data_num";

    public static final String CALL_ROSTER_NUM = "call_roster_num";

    public static final String THROUGH_CALL_DIALOGUE_NUM = "through_call_dialogue_num";

    public static final String COST_UNIT = "cost_unit";

    public static final String THROUGH_ROSTER_NUM = "through_roster_num";

    public static final String SEND_SMS_ROSTER_NUM = "send_sms_roster_num";

    public static final String SMS_SUCC_ROSTER_NUM = "sms_succ_roster_num";

    public static final String SMS_UNIT = "sms_unit";

    public static final String INTENTIONSTAT = "intentionStat";

    public static final String PLAN_CREATE_TIME = "plan_create_time";

    public static final String LAST_STAT_TIME = "last_stat_time";

    public static final String CALL_DIALOGUE_NUM = "call_dialogue_num";

    public static final String SENTTOTALNUM = "sentTotalNum";

    public static final String SENTSUCCESSNUM = "sentSuccessNum";

}
