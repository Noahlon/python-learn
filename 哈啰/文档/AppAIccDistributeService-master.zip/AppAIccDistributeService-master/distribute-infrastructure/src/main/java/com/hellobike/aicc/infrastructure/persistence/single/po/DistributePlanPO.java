package com.hellobike.aicc.infrastructure.persistence.single.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 数据密级S2,分流计划表
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_distribute_plan")
public class DistributePlanPO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id" ,type = IdType.INPUT)
    private Long id;

    /**
     * 数据密级S2,分流计划名称
     */
    @TableField("distribute_plan_name")
    private String distributePlanName;

    /**
     * 数据密级S2,分流计划模板id
     */
    @TableField("template_id")
    private Long templateId;

    /**
     * 数据密级S2,租户id
     */
    @TableField("tenant_code")
    private String tenantCode;

    /**
     * 数据密级S2,租户名称
     */
    @TableField("tenant_name")
    private String tenantName;

    /**
     * 数据密级S2,分流类型，1-实时分流，2-离线分流
     */
    @TableField("distribute_type")
    private Integer distributeType;

    /**
     * 数据密级S2,分流类型描述
     */
    @TableField("distribute_type_desc")
    private String distributeTypeDesc;

    /**
     * 数据密级S2,上传数据量
     */
    @TableField("upload_data_num")
    private Long uploadDataNum;

    /**
     * 数据密级S2,分流规则
     */
    @TableField("distribute_rule")
    private String distributeRule;

    /**
     * 数据密级S2,创建人
     */
    @TableField("creator")
    private String creator;

    /**
     * 数据密级S2,创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,逻辑删除
     */
    @TableField("is_delete")
    private Integer isDelete;


    public static final String DISTRIBUTE_PLAN_NAME = "distribute_plan_name";

    public static final String TEMPLATE_ID = "template_id";

    public static final String TENANT_ID = "tenant_code";

    public static final String TENANT_NAME = "tenant_name";

    public static final String DISTRIBUTE_TYPE = "distribute_type";

    public static final String DISTRIBUTE_TYPE_DESC = "distribute_type_desc";

    public static final String UPLOAD_DATA_NUM = "upload_data_num";

    public static final String DISTRIBUTE_RULE = "distribute_rule";

    public static final String CREATOR = "creator";

    public static final String CREATE_TIME = "create_time";

    public static final String UPDATE_TIME = "update_time";

    public static final String IS_DELETE = "is_delete";

}
