/**
 * DingMsg.java
 * Copyright 2023 HelloBike , all rights reserved.
 * HelloBike PROPRIETARY/CONFIDENTIAL, any form of usage is subject to approval.
 */

package com.hellobike.aicc.infrastructure.notify.dingding.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * @author older
 * @since 2023/2/13
 */
@Getter
@Setter
@ToString
public class DingMsgDTO {

    public static final String MSG_TYPE_TEXT = "text";
    public static final String MSG_TYPE_MD = "markdown";

    /**
     * 告警类型
     * 和钉钉接口字段名称保持一致
     */
    private String msgtype;

    /**
     * 文本告警文案
     */
    private TextContentDTO text;

    /**
     * markdown告警内容
     */
    private MarkdownContentDTO markdown;

    /**
     * 艾特信息
     */
    private AtContentDTO at;

    /**
     * token列表
     */
    private List<String> tokenList;
}