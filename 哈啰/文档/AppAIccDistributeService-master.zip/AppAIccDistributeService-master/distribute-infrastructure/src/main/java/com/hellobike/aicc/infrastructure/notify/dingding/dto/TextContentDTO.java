/**
 * TextContent.java
 * Copyright 2023 HelloBike , all rights reserved.
 * HelloBike PROPRIETARY/CONFIDENTIAL, any form of usage is subject to approval.
 */

package com.hellobike.aicc.infrastructure.notify.dingding.dto;

import lombok.*;

/**
 * @author older
 * @since 2023/2/13
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TextContentDTO {
    /**
     * 文本告警文案
     */
    private String content;
}