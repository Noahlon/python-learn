package com.hellobike.aicc.infrastructure.es.roster.repository;

import cn.hutool.core.collection.CollectionUtil;
import com.hellobike.aicc.infrastructure.es.roster.po.PlanRosterESPO;
import com.hellobike.base.hammer.concurrent.HamExecutors;
import com.hellobike.base.hammer.concurrent.HamScheduleExecutorService;
import com.hellobike.base.hammer.concurrent.HamThreadFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.TimeUnit;

/**
 * @author zhangzhuoqi
 * @since 2025-05-23  14:23:06
 */
@Component
@Slf4j
public class RosterEsContainer {

    private final Queue<PlanRosterESPO> queueMsg;
    private final HamScheduleExecutorService executorService;

    @Value("${esRosterSubmitLimit:1000}")
    private Integer esRosterSubmitLimit;

    @Resource
    private RosterEsSubmit rosterEsSubmit;

    public RosterEsContainer() {
        queueMsg = new ConcurrentLinkedDeque<>();
        executorService = HamExecutors.createScheduledThreadPool(1,
                new HamThreadFactory("rosterSave2Es-ThreadPool"));
        executorService.scheduleAtFixedRate(this::execute, 15, 1, TimeUnit.SECONDS);
    }

    /**
     * 添加名单到对列(名单中分流计划创建时间必传，要不然无法确定索引日期就无法保存到es)
     *
     * @param rosterList 名单集合
     * @param flag       是否直接保存ES
     */
    public void addRoster(List<PlanRosterESPO> rosterList, boolean flag) {
        if (CollectionUtils.isEmpty(rosterList)) {
            return;
        }
        if (flag) {
            submitRoster2Es(rosterList);
            return;
        }
        if (queueMsg.size() > esRosterSubmitLimit) {
            executorService.submit(this::execute);
        }
        try {
            queueMsg.addAll(rosterList);
        } catch (Exception e) {
            log.error("RosterEsContainer队列导入异常", e);
        }
    }

    /**
     * 执行线程池延迟任务
     */
    private void execute() {
        try {
            List<PlanRosterESPO> list = new ArrayList<>();
            PlanRosterESPO rosterESPO = null;
            do {
                rosterESPO = queueMsg.poll();
                if (rosterESPO != null) {
                    list.add(rosterESPO);
                }
                if (list.size() > esRosterSubmitLimit) {
                    List<PlanRosterESPO> finalList = list;
                    executorService.submit(() -> submitRoster2Es(finalList));
                    list = new ArrayList<>();
                }
            } while (rosterESPO != null);
            if (CollectionUtil.isNotEmpty(list)) {
                List<PlanRosterESPO> finalList1 = list;
                executorService.submit(() -> submitRoster2Es(finalList1));
            }
        } catch (Exception ex) {
            log.error("添加子任务失败,e:", ex);
        }
    }

    private void submitRoster2Es(List<PlanRosterESPO> list) {
        try {
            rosterEsSubmit.esSubmitInvoke(list);
        } catch (Exception ex) {
            log.error("执行同步失败", ex);
        }
    }
}
