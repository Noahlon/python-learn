package com.hellobike.aicc.infrastructure.gateway.channel;

import com.hellobike.aicc.common.enums.RosterTypeEnum;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.dto.ChannelTaskCreateDTO;
import com.hellobike.aicc.domain.channel.entity.ChannelEntity;
import com.hellobike.aicc.domain.channel.entity.ChannelTaskEntity;
import com.hellobike.aicc.domain.channel.facade.AICallCenterChannelFacade;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.common.service.DingTalkService;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterDTO;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterResultDTO;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.infrastructure.convert.AICallCenterChannelFacadeConvert;
import com.hellobike.aicc.infrastructure.gateway.dto.AICallCenterRosterDTO;
import com.hellobike.css.ai.api.base.Result;
import com.hellobike.css.ai.api.iface.task.SmartCallTaskCommandService;
import com.hellobike.css.ai.api.iface.task.SmartCallTaskQueryService;
import com.hellobike.css.ai.api.iface.task.request.CreateTaskByTemplateGuidRequest;
import com.hellobike.css.ai.api.iface.task.request.ImportSubTaskRequest;
import com.hellobike.css.ai.api.iface.task.request.ListTaskTemplateRequest;
import com.hellobike.css.ai.api.iface.task.response.CreateTaskByTemplateGuidResponse;
import com.hellobike.css.ai.api.iface.task.response.ImportSubTaskResponse;
import com.hellobike.css.ai.api.iface.task.response.SmartCallTaskTemplateResponse;
import com.hellobike.soa.starter.spring.annotation.Reference;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * AI外呼渠道商接口门面
 *
 * @author panlongqian
 * @since 2025-03-12
 */

@Service
@Slf4j
public class AICallCenterChannelFacadeImpl implements AICallCenterChannelFacade {
    @Reference
    private SmartCallTaskCommandService smartCallTaskCommandService;

    @Reference
    private SmartCallTaskQueryService smartCallTaskQueryService;

    @Resource
    private AICallCenterChannelFacadeConvert convert;

    @Resource
    private DingTalkService dingTalkService;

    @Value("${css.import.retryCount:2}")
    private int retryCount;

    @Override
    public ChannelTaskEntity createChannelTask(ChannelTaskCreateDTO channelTaskCreateDTO) {
        try {
            CreateTaskByTemplateGuidRequest request = convert.convert(channelTaskCreateDTO);
            Result<CreateTaskByTemplateGuidResponse> queryResult = smartCallTaskCommandService.createTaskByTemplateGuidV2(request);
            if (queryResult == null || !queryResult.isSuccess() || queryResult.getData() == null) {
                dingTalkService.sendChannelTaskCreateFailedAlert(channelTaskCreateDTO.getDistributePlanId(), ChannelFactory.getHelloAiCall().getChannelName());
                log.error("创建外呼任务失败，异常信息为：{}", queryResult == null ? "null" : queryResult.getMsg());
                return null;
            }
            return new ChannelTaskEntity(String.valueOf(queryResult.getData().getTaskId()), queryResult.getData().getTaskName());
        } catch (Exception e) {
            dingTalkService.sendChannelTaskCreateFailedAlert(channelTaskCreateDTO.getDistributePlanId(), ChannelFactory.getHelloAiCall().getChannelName());
            log.error("创建外呼任务失败,模板id为：{}", channelTaskCreateDTO.getTaskTemplateId(), e);
            return null;
        }
    }

    @Override
    public List<ChannelEntity.ChannelTemplateEntity> queryChannelTemplateList(String tenantCode) {
        try {
            ListTaskTemplateRequest request = new ListTaskTemplateRequest();
            request.setTenant(tenantCode);
            Result<List<SmartCallTaskTemplateResponse>> listResult = smartCallTaskQueryService.listTaskTemplate(request);
            if (listResult == null || !listResult.isSuccess()) {
                log.error("查询外呼任务模板失败，异常信息为：{}", listResult == null ? "null" : listResult.getMsg());
                return null;
            }

            if (CollectionUtils.isEmpty(listResult.getData())) {
                return new ArrayList<>();
            }

            return listResult.getData()
                    .stream()
                    .map(it -> new ChannelEntity.ChannelTemplateEntity(it.getGuid(), it.getName()))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            log.error("查询外呼任务模板出现异常， 租户为：{}", tenantCode, e);
            return null;
        }
    }

    @Override
    public ChannelImportRosterResultDTO importRoster(ChannelImportRosterDTO channelImportRosterDTO) {
        ChannelImportRosterResultDTO channelImportRosterResultDTO = new ChannelImportRosterResultDTO(0, 0, false);

        if (CollectionUtils.isEmpty(channelImportRosterDTO.getRosterEntityList())) {
            return channelImportRosterResultDTO;
        }
        try {
            return doImportRoster(channelImportRosterDTO);
        } catch (Exception e) {
            log.error("调用外呼上传接口异常，e:", e);
            channelImportRosterResultDTO.setFailCount(channelImportRosterDTO.getRosterEntityList().size());
            channelImportRosterResultDTO.setAllFail(true);
        }
        return channelImportRosterResultDTO;
    }

    private ChannelImportRosterResultDTO doImportRoster(ChannelImportRosterDTO channelImportRosterDTO) {
        List<PlanRosterEntity> rosterEntityList = channelImportRosterDTO.getRosterEntityList();
        int totalSize = rosterEntityList.size();
        log.info("开始调用AI外呼上传名单,tenant:{},size:{},rosterType:{}", channelImportRosterDTO.getTenantCode(), totalSize, channelImportRosterDTO.getRosterType());
        ChannelImportRosterResultDTO channelImportRosterResultDTO = new ChannelImportRosterResultDTO(0, 0, false);
        ImportSubTaskRequest importSubTaskRequest = new ImportSubTaskRequest();
        importSubTaskRequest.setSize(totalSize);
        importSubTaskRequest.setTaskGuid(Long.valueOf(channelImportRosterDTO.getSupplierTaskId()));
        importSubTaskRequest.setTenant(channelImportRosterDTO.getTenantCode());
        if (Objects.equals(channelImportRosterDTO.getRosterType(), RosterTypeEnum.MD5.getCode())) {
            //外呼3标识md5
            importSubTaskRequest.setUploadType(3);
        } else if (Objects.equals(channelImportRosterDTO.getRosterType(), RosterTypeEnum.TELEPHONE.getCode())) {
            //0标识明文
            importSubTaskRequest.setUploadType(0);
        }
        List<AICallCenterRosterDTO> aiRosterList = channelImportRosterDTO.getRosterEntityList().stream().map(roster -> {
            AICallCenterRosterDTO aiCallCenterRosterDTO = new AICallCenterRosterDTO();
            aiCallCenterRosterDTO.setPhone(roster.getPhoneNum());
            aiCallCenterRosterDTO.setMd5Phone(Objects.equals(channelImportRosterDTO.getRosterType(), RosterTypeEnum.MD5.getCode()) ? roster.getPhoneNum() : null);
            aiCallCenterRosterDTO.setName(roster.getCustomerName());
            aiCallCenterRosterDTO.setVariableInfos(roster.getVariableInfo());
            //用分流平台的名单id+上传记录id作为外部id传给外呼
            aiCallCenterRosterDTO.setExternalId(roster.getId() + "-" + channelImportRosterDTO.getDistributePlanId());
            return aiCallCenterRosterDTO;
        }).collect(Collectors.toList());
        importSubTaskRequest.setText(BaseJsonUtils.writeValue(aiRosterList));

        ImportSubTaskResponse data = null;
        data = this.postImportRoster(importSubTaskRequest);
        //失败重试
        if (Objects.isNull(data)) {
            for (int i = 0; i < retryCount; i++) {
                data = this.postImportRoster(importSubTaskRequest);
                if (Objects.nonNull(data)) {
                    break;
                }
            }
        }
        if (Objects.isNull(data)) {
            channelImportRosterResultDTO.setFailCount(totalSize);
            channelImportRosterResultDTO.setAllFail(true);
            return channelImportRosterResultDTO;
        }

        //成功条数
        channelImportRosterResultDTO.setSuccessCount(Objects.nonNull(data.getSuccessCount()) ? data.getSuccessCount() : 0);
        /*Integer failCount = 0;
        if (Objects.nonNull(data.getDuplicationCount())) {
            failCount += data.getDuplicationCount();
        }
        if (Objects.nonNull(data.getFailCount())) {
            failCount += data.getFailCount();
        }*/
        //失败条数=总条数-成功条数
        channelImportRosterResultDTO.setFailCount(totalSize - channelImportRosterResultDTO.getSuccessCount());
        return channelImportRosterResultDTO;
    }

    private ImportSubTaskResponse postImportRoster(ImportSubTaskRequest importSubTaskRequest) {
        try {
            Result<ImportSubTaskResponse> result = smartCallTaskCommandService.importSubTask(importSubTaskRequest);
            if (isResultFail(result)) {
                return null;
            }
            log.info("调用ai外呼上传名单结果结束，res:{}", BaseJsonUtils.writeValue(result));
            return result.getData();
        } catch (Exception e) {
            log.error("调用ai外呼上传名单结果异常,e:", e);
            return null;
        }
    }

    private boolean isResultFail(Result<ImportSubTaskResponse> result) {
        return Objects.isNull(result) || !result.isSuccess() || Objects.isNull(result.getData());
    }
}
