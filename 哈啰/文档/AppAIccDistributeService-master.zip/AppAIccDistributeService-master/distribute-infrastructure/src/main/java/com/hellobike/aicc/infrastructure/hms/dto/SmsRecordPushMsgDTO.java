package com.hellobike.aicc.infrastructure.hms.dto;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 推送给客户的短信记录消息
 *
 * @author panlongqian
 * @since 2025-04-10
 */
@Data
public class SmsRecordPushMsgDTO {
    /**
     * 分流平台短信记录id
     */
    private String smsId;

    /**
     * 分流计划id
     */
    private String taskId;

    /**
     * 分流计划名称
     */
    private String taskName;

    /**
     * 分流计划平台通话记录id
     */
    private String dialogueGuid;

    /**
     * 手机号码
     */
    private String phoneNumber;

    /**
     * 手机号码的32位小写md5加密
     */
    private String md5;

    /**
     * 短信签名
     */
    private String signature;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 短信发送时间
     */
    private String sendTime;

    /**
     * 短信发送结果
     */
    private Integer sendResult;

    /**
     * 计费条数
     */
    private Integer billingNum;

    /**
     * 租户id（如果是外部渠道商，需要注意怎么查询租户id）
     */
    private String tenantId;
}
