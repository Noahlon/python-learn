package com.hellobike.aicc.infrastructure.job;

import com.hellobike.aicc.common.enums.RosterTypeEnum;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.roster.dto.UploadRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;
import com.hellobike.aicc.domain.roster.repo.UploadRecordRepository;
import com.hellobike.base.flexjob.common.model.base.ReturnT;
import com.hellobike.base.flexjob.common.participant.ParticipantParams;
import com.hellobike.base.flexjob.participant.starter.spring.JobHandle;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 上传记录上传类型字段初始化（如果为null则设置为1-明文上传）
 */
@Service
@Slf4j
@JobHandle("uploadRecordDataFixJob")
public class UploadRecordDataFixJob {
    @Resource
    private DistPlanRepo distPlanRepo;

    @Resource
    private UploadRecordRepository uploadRecordRepository;

    public ReturnT<String> trigger(ParticipantParams params) {
        log.info("开始处理上传记录上传类型字段初始化");
        try {
            doTrigger(params.getExtendParams());
            return new ReturnT<>(ReturnT.SUCCESS_CODE, "上传记录上传类型字段初始化任务执行完毕");
        } catch (Exception e) {
            log.error("处理上传记录上传类型字段初始化任务异常", e);
            return new ReturnT<>(ReturnT.FAIL_CODE, "处理上传记录上传类型字段初始化任务异常");
        }
    }

    private void doTrigger(String extendParams) {
        List<Long> distPlanIds = getDistPlanIds(extendParams);
        if (CollectionUtils.isEmpty(distPlanIds)) {
            return;
        }

        for (Long distPlanId : distPlanIds) {
            UploadRecordQueryConditionDTO condition = new UploadRecordQueryConditionDTO();
            condition.setDistributePlanId(distPlanId);
            List<UploadRecordEntity> uploadRecordEntities = uploadRecordRepository.queryByCondition(condition);
            for (UploadRecordEntity recordEntity : uploadRecordEntities) {
                if (recordEntity.getRosterType() == null) {
                    recordEntity.setRosterType(RosterTypeEnum.TELEPHONE.getCode());
                    uploadRecordRepository.updateRecordById(recordEntity);
                }
            }
        }
    }

    private List<Long> getDistPlanIds(String extendParams) {
        List<Long> distPlanIds = new ArrayList<>();
        if (StringUtils.isNotBlank(extendParams)) {
            distPlanIds.add(Long.valueOf(extendParams));
        } else {
            List<DistributePlanEntity> distributePlanEntities = distPlanRepo.queryAllEffectiveDistPlans();
            distPlanIds = distributePlanEntities.stream().map(DistributePlanEntity::getId).collect(Collectors.toList());
        }
        return distPlanIds;
    }
}
