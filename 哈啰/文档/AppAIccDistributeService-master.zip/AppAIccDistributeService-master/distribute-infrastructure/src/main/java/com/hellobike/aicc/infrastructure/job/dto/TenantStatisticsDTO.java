package com.hellobike.aicc.infrastructure.job.dto;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;

/**
 *
 */
@Data
public class TenantStatisticsDTO {


    /**
     * 租户code
     */
    private String tenantCode;

    /**
     * 租户名称
     */
    private String tenantName;

    /**
     * 总日名单数
     */
    private Long totalCount = 0L;

    /**
     * 总日接通数
     */
    private Long totalDailyPutCount = 0L;

    /**
     * 总日语音计费单元数
     */
    private Long totalDailyCallBillingCount = 0L;

    /**
     * 总日语音营收
     */
    private BigDecimal totalDailyCallBill = BigDecimal.ZERO;

    /**
     * 总日语音利润
     */
    private BigDecimal totalDailyCallProfit = BigDecimal.ZERO;
}
