package com.hellobike.aicc.infrastructure.persistence.multi.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 数据密级S2,名单
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_plan_roster")
public class PlanRosterPO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id" ,type = IdType.INPUT)
    private Long id;

    /**
     * 数据密级S2,手机号
     */
    @TableField("phone_num")
    private String phoneNum;

    /**
     * 数据密级S2,客户数据唯一标识
     */
    @TableField("external_id")
    private String externalId;

    /**
     * 数据密级S2,平台数据唯一标识
     */
    @TableField("platform_id")
    private String platformId;

    /**
     * 数据密级S2,客户姓名
     */
    @TableField("customer_name")
    private String customerName;

    /**
     * 数据密级S2,变量信息
     */
    @TableField("variable_info")
    private String variableInfo;

    /**
     * 数据密级S2,分流计划id
     */
    @TableField("distribute_plan_id")
    private Long distributePlanId;

    /**
     * 数据密级S2,分表键（分流计划id+手机号最后一位）
     */
    @TableField("partition_code")
    private String partitionCode;

    /**
     * 数据密级S2,上传记录id
     */
    @TableField("upload_record_id")
    private Long uploadRecordId;

    /**
     * 数据密级S2,下发记录id
     */
    @TableField("distribute_record_id")
    private Long distributeRecordId;

    /**
     * 数据密级S2,下发状态
     */
    @TableField("distribute_status")
    private Integer distributeStatus;

    /**
     * 数据密级S2,渠道id
     */
    @TableField("channel_id")
    private Integer channelId;

    /**
     * 数据密级S2,渠道任务id
     */
    @TableField("channel_task_id")
    private Long channelTaskId;

    /**
     * 数据密级S2,渠道名称
     */
    @TableField("channel_name")
    private String channelName;

    /**
     * 手机号md5
     */
    @TableField("md5")
    private String md5;

    /**
     * 三方任务id
     */
    @TableField("supplier_task_id")
    private String supplierTaskId;

    /**
     * 三方任务名称
     */
    @TableField("supplier_task_name")
    private String supplierTaskName;

    /**
     * 数据密级S2,话单数量
     */
    @TableField("call_dialogue_num")
    private Integer callDialogueNum;

    /**
     * 数据密级S2,接通话单数
     */
    @TableField("through_call_dialogue_num")
    private Integer throughCallDialogueNum;

    /**
     * 数据密级S2,上传时间
     */
    @TableField("upload_time")
    private LocalDateTime uploadTime;

    /**
     * 数据密级S2,下发时间
     */
    @TableField("distribute_time")
    private LocalDateTime distributeTime;

    /**
     * 数据密级S2,最近呼叫时间
     */
    @TableField("last_call_time")
    private LocalDateTime lastCallTime;

    /**
     * 数据密级S2,最近接通时间
     */
    @TableField("last_through_time")
    private LocalDateTime lastThroughTime;

    /**
     * 数据密级S2,扩展字段
     */
    @TableField("ext_info")
    private String extInfo;

    /**
     * 数据密级S2,名单类型
     * @see com.hellobike.aicc.common.enums.RosterTypeEnum
     */
    private Integer rosterType;

    /**
     * 数据密级S2,创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,逻辑删除
     */
    @TableField("is_delete")
    private Integer isDelete;

    /**
     * 命中规则
     */
    @TableField("hit_rule")
    private String hitRule;

    /**
     * 是否命中规则 0-否 1-是
     */
    @TableField("is_hit_rule")
    private Integer isHitRule;

    /**
     * 是否撞库 0-否 1-是
     */
    @TableField("is_impact")
    private Integer isImpact;

    /**
     * 不下发原因
     */
    @TableField("not_dist_reason")
    private String notDistReason;

    /**
     * 最近外呼状态
     * @see com.hellobike.aicc.common.enums.CallResultEnum
     */
    @TableField("last_call_result")
    private Integer lastCallResult;

    /**
     * 短信发送次数
     */
    @TableField("sms_send_count")
    private Integer smsSendCount;

    /**
     * 短信发送成功次数
     */
    @TableField("sms_send_success_count")
    private Integer smsSendSuccessCount;

    /**
     * 租户id
     */
    @TableField("tenant_id")
    private String tenantId;

    public static final String ENCRYPT_PHONE_NUM = "encrypt_phone_num";

    public static final String HASH_PHONE_NUM = "hash_phone_num";

    public static final String EXTERNAL_ID = "external_id";

    public static final String PLATFORM_ID = "platform_id";

    public static final String CUSTOMER_NAME = "customer_name";

    public static final String VARIABLE_INFO = "variable_info";

    public static final String DISTRIBUTE_PLAN_ID = "distribute_plan_id";

    public static final String UPLOAD_RECORD_ID = "upload_record_id";

    public static final String DISTRIBUTE_RECORD_ID = "distribute_record_id";

    public static final String DISTRIBUTE_STATUS = "distribute_status";

    public static final String CHANNEL_ID = "channel_id";

    public static final String CHANNEL_TASK_ID = "channel_task_id";

    public static final String SUPPLIER_TASK_NAME = "supplier_task_name";

    public static final String SUPPLIER_TASK_ID = "supplier_task_id";

    public static final String CALL_DIALOGUE_NUM = "call_dialogue_num";

    public static final String THROUGH_CALL_DIALOGUE_NUM = "through_call_dialogue_num";

    public static final String UPLOAD_TIME = "upload_time";

    public static final String DISTRIBUTE_TIME = "distribute_time";

    public static final String LAST_CALL_TIME = "last_call_time";

    public static final String LAST_THROUGH_TIME = "last_through_time";

    public static final String EXT_INFO = "ext_info";

    public static final String CREATE_TIME = "create_time";

    public static final String UPDATE_TIME = "update_time";

    public static final String IS_DELETE = "is_delete";

    public static final String LAST_CALL_RESULT = "last_call_result";

    public static final String SMS_SEND_COUNT = "sms_send_count";

    public static final String SMS_SEND_SUCCESS_COUNT = "sms_send_success_count";

}
