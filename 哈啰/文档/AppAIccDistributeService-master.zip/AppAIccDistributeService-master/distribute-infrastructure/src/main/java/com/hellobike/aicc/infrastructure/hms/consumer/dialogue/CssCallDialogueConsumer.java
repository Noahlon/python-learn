package com.hellobike.aicc.infrastructure.hms.consumer.dialogue;

import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.common.service.DingTalkService;
import com.hellobike.aicc.domain.dialogue.dto.CssCallDialogueDTO;
import com.hellobike.aicc.domain.dialogue.service.DialogueDomainService;
import com.hellobike.aicc.infrastructure.hms.consumer.BaseMsgConsumer;
import com.hellobike.hms.sdk.consumer.ConsumeMessage;
import com.hellobike.hms.sdk.consumer.MsgRetryStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Objects;

/**
 * 外呼话单消费者
 *
 * @author zhangzhuoqi
 * @since 2025-03-14  13:17:30
 */
@Slf4j
@Component
public class CssCallDialogueConsumer extends BaseMsgConsumer {

    private static final String CONSUMER = "css_call_dialogue_push_topic_aicc_distribute_consumer";

    @Resource
    private DialogueDomainService dialogueDomainService;

    @Resource
    private DingTalkService dingTalkService;

    @Override
    protected String getConsumerName() {
        return CONSUMER;
    }

    @Override
    public MsgRetryStatus msgProcess(ConsumeMessage mqMessage) {
        try {
            String msgBody = new String(mqMessage.getPayload());
            log.info("外呼话单消息:{}", msgBody);
            CssCallDialogueDTO cssCallDialogueDTO = BaseJsonUtils.readValue(msgBody, CssCallDialogueDTO.class);
            if (Objects.isNull(cssCallDialogueDTO) || StrUtil.isBlank(cssCallDialogueDTO.getGuid())) {
                log.error("css话单为空,dto:{}", cssCallDialogueDTO);
                return MsgRetryStatus.SUCCEED;
            }
            //不需要处理没有录音文件的
            if (StrUtil.isBlank(cssCallDialogueDTO.getRecordFile())) {
                log.info("当前话单录音文件不存在不处理，guid:{}", cssCallDialogueDTO.getGuid());
                return MsgRetryStatus.SUCCEED;
            }
            cssCallDialogueDTO.setDialogueGuid(cssCallDialogueDTO.getGuid());
            dialogueDomainService.handleCallDialogueCallBack(cssCallDialogueDTO, ChannelFactory.getHelloAiCall().getChannelId());
        } catch (Exception e) {
            log.error("消费外呼话单异常,e:", e);
            dingTalkService.sendDialogueFailedAlert(mqMessage.getMsgId());
        }
        return MsgRetryStatus.SUCCEED;
    }
}
