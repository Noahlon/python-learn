package com.hellobike.aicc.infrastructure.smsrecord;

import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;
import com.hellobike.aicc.domain.smsrecord.service.SmsRecordMsgService;
import com.hellobike.aicc.infrastructure.convert.SmsRecordInfConvert;
import com.hellobike.aicc.infrastructure.hms.dto.SmsRecordPushMsgDTO;
import com.hellobike.aicc.infrastructure.hms.producer.SmsRecordMsgProducer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
@Slf4j
public class SmsRecordMsgServiceImpl implements SmsRecordMsgService {
    @Resource
    private SmsRecordMsgProducer smsRecordMsgProducer;

    @Resource
    private SmsRecordInfConvert smsRecordInfConvert;

    @Override
    public void sendMsg(SmsRecordEntity smsRecord) {
        SmsRecordPushMsgDTO smsPushRecord = smsRecordInfConvert.convert(smsRecord);
        boolean sendRes = smsRecordMsgProducer.sendMsg(smsPushRecord);
        log.info("短信发送结果：{},id:{}", sendRes, smsPushRecord.getSmsId());
    }
}
