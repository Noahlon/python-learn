package com.hellobike.aicc.infrastructure.persistence.single.mapper;

import com.hellobike.aicc.infrastructure.persistence.single.po.DistributePlanStatPO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 数据密级S2,分流计划统计表 Mapper 接口
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-05-27
 */
public interface DistributePlanStatMapper extends BaseMapper<DistributePlanStatPO> {

}
