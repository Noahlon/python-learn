package com.hellobike.aicc.infrastructure.persistence.multi.repository;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hellobike.aicc.common.enums.DeleteEnum;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.common.util.DBPartitionUtils;
import com.hellobike.aicc.domain.roster.dto.BatchUpdRosterFieldDTO;
import com.hellobike.aicc.domain.roster.dto.RosterQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.repo.PlanRosterRepository;
import com.hellobike.aicc.infrastructure.convert.RosterInfConvert;
import com.hellobike.aicc.infrastructure.persistence.multi.mapper.PlanRosterMapper;
import com.hellobike.aicc.infrastructure.persistence.multi.po.PlanRosterPO;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * 数据密级S2,名单 服务实现类
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Service
public class PlanRosterRepositoryImpl extends ServiceImpl<PlanRosterMapper, PlanRosterPO> implements PlanRosterRepository {

    @Resource
    private RosterInfConvert rosterInfConvert;


    @Override
    public void updateRosterByCallBack(PlanRosterEntity entity) {
        checkPartitionCode(entity.getDistributePlanId(), entity.getPhoneNum());
        AssertUtils.notNull(entity.getId(), "名单id不能为空");
        String partitionCode = DBPartitionUtils.getRosterPartitionCode(entity.getDistributePlanId(), entity.getPhoneNum());
        LambdaUpdateWrapper<PlanRosterPO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper
                .eq(PlanRosterPO::getId, entity.getId())
                .eq(PlanRosterPO::getDistributePlanId, entity.getDistributePlanId())
                .eq(PlanRosterPO::getPartitionCode, partitionCode);
        //最近呼叫时间
        updateWrapper.set(Objects.nonNull(entity.getLastCallTime()), PlanRosterPO::getLastCallTime, entity.getLastCallTime());
        //最近接通时间
        updateWrapper.set(Objects.nonNull(entity.getLastThroughTime()), PlanRosterPO::getLastThroughTime, entity.getLastThroughTime());
        //最新外呼状态
        updateWrapper.set(Objects.nonNull(entity.getLastCallResult()), PlanRosterPO::getLastCallResult, entity.getLastCallResult());
        //接通话单数
        updateWrapper.setSql(Objects.nonNull(entity.getThroughCallDialogueNum()), " through_call_dialogue_num = through_call_dialogue_num + " + entity.getThroughCallDialogueNum());
        //话单数
        updateWrapper.setSql(Objects.nonNull(entity.getCallDialogueNum()), " call_dialogue_num = call_dialogue_num + " + entity.getCallDialogueNum());
        //短信发送次数
        updateWrapper.setSql(Objects.nonNull(entity.getSmsSendCount()), " sms_send_count = sms_send_count + " + entity.getSmsSendCount());
        //短信发送成功次数
        updateWrapper.setSql(Objects.nonNull(entity.getSmsSendSuccessCount()), " sms_send_success_count = sms_send_success_count + " + entity.getSmsSendSuccessCount());


        update(updateWrapper);
    }

    @Override
    public void batchSave(List<PlanRosterEntity> entityList) {
        entityList.stream().filter(it -> StringUtils.isBlank(it.getPartitionCode())).forEach(PlanRosterEntity::fillRosterPartitionCode);
        List<PlanRosterPO> poList = rosterInfConvert.toPOList(entityList);
        for (PlanRosterPO planRosterPO : poList) {
            save(planRosterPO);
        }
        /*Map<String, List<PlanRosterPO>> rosterMap = poList.stream().collect(Collectors.groupingBy(PlanRosterPO::getPartitionCode));
        List<CompletableFuture<Void>> futureList = new ArrayList<>();

        rosterMap.forEach((partitionCode, rosterList) -> {
            CompletableFuture<Void> future = CompletableFuture.runAsync(
                    () -> getBaseMapper().batchSave(rosterList), HammerThreadPoolUtil.getRosterSaveExecutor());
            futureList.add(future);
        });
        CompletableFuture.allOf(futureList.toArray(new CompletableFuture[0])).join();*/
    }

    @Override
    public PlanRosterEntity getRosterById(Long rosterId, Long distPlanId, String phoneNum) {
        AssertUtils.notNull(rosterId, "名单id不能为空");
        checkPartitionCode(distPlanId, phoneNum);
        LambdaQueryWrapper<PlanRosterPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(PlanRosterPO::getId, rosterId)
                .eq(PlanRosterPO::getPartitionCode, DBPartitionUtils.getRosterPartitionCode(distPlanId, phoneNum))
                .eq(PlanRosterPO::getIsDelete, DeleteEnum.NO.getCode());
        PlanRosterPO po = getOne(queryWrapper, false);
        return rosterInfConvert.toEntity(po);
    }

    @Override
    public void batchUpdWhenDistById(List<PlanRosterEntity> rosterEntityList, BatchUpdRosterFieldDTO field) {
        //按照分表键分组
        Map<String, List<PlanRosterEntity>> rosterMap = getPartitionCodeMap(rosterEntityList);
        rosterMap.forEach((partitionCode, rosterList) -> {
            List<Long> rosterIdList = rosterList.stream().map(PlanRosterEntity::getId).collect(Collectors.toList());
            LambdaUpdateWrapper<PlanRosterPO> updateWrapper = new LambdaUpdateWrapper<>();
            updateWrapper.set(Objects.nonNull(field.getRosterDistStatusEnum()), PlanRosterPO::getDistributeStatus, field.getRosterDistStatusEnum().getCode())
                    .set(Objects.nonNull(field.getDistributeTime()), PlanRosterPO::getDistributeTime, field.getDistributeTime());
            updateWrapper
                    .in(PlanRosterPO::getId, rosterIdList)
                    .eq(PlanRosterPO::getPartitionCode, partitionCode);
            update(updateWrapper);
        });
    }

    @Override
    public List<PlanRosterEntity> queryByCondition(Long distPlanId, RosterQueryConditionDTO condition) {
        AssertUtils.notNull(distPlanId, "分流计划id不能为空");
        Map<String, List<String>> phoneKeyMap = new HashMap<>();
        Set<String> partitionCodeList;
        if (CollectionUtil.isNotEmpty(condition.getPhoneNumList())) {
            //手机号按照分表键分组
            phoneKeyMap = condition.getPhoneNumList().stream().collect(Collectors.groupingBy(phoneNum -> DBPartitionUtils.getRosterPartitionCode(distPlanId, phoneNum)));
            partitionCodeList = new HashSet<>(phoneKeyMap.keySet());
        } else {
            partitionCodeList = DBPartitionUtils.getAllRosterPartitionCode(distPlanId);
        }

        List<PlanRosterEntity> entityList = new ArrayList<>();
        for (String partitionCode : partitionCodeList) {
            LambdaQueryWrapper<PlanRosterPO> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper
                    .eq(Objects.nonNull(condition.getId()), PlanRosterPO::getId, condition.getId())
                    .eq(PlanRosterPO::getDistributePlanId, distPlanId)
                    .eq(Objects.nonNull(condition.getDistributeRecordId()), PlanRosterPO::getDistributeRecordId, condition.getDistributeRecordId())
                    .eq(Objects.nonNull(condition.getUploadRecordId()), PlanRosterPO::getUploadRecordId, condition.getUploadRecordId())
                    .eq(PlanRosterPO::getIsDelete, DeleteEnum.NO.getCode());
            if (Objects.nonNull(condition.getDistributeStatus())) {
                queryWrapper.eq(PlanRosterPO::getDistributeStatus, condition.getDistributeStatus().getCode());
            }
            queryWrapper.eq(PlanRosterPO::getPartitionCode, partitionCode);
            if (phoneKeyMap.containsKey(partitionCode)) {
                List<String> phoneNumList = phoneKeyMap.get(partitionCode);
                queryWrapper.in(PlanRosterPO::getPhoneNum, phoneNumList);
            }
            List<PlanRosterPO> poList = list(queryWrapper);
            entityList.addAll(rosterInfConvert.toEntityList(poList));
        }
        return entityList;
    }

    @Override
    public void batchUpdateById(List<PlanRosterEntity> entityList) {
        Map<String, List<PlanRosterEntity>> partitionCodeMap = getPartitionCodeMap(entityList);
        partitionCodeMap.forEach((partitionCode, rosterList) -> {
            List<PlanRosterPO> poList = rosterInfConvert.toPOList(rosterList);
            batchUpdate(poList, partitionCode);
        });
    }

    private void batchUpdate(List<PlanRosterPO> poList, String partitionCode) {
        for (PlanRosterPO planRosterPO : poList) {
            LambdaUpdateWrapper<PlanRosterPO> updateWrapper = new LambdaUpdateWrapper<>();
            updateWrapper.eq(PlanRosterPO::getId, planRosterPO.getId()).eq(PlanRosterPO::getPartitionCode, partitionCode);
            updateWrapper.set(PlanRosterPO::getDistributeStatus, planRosterPO.getDistributeStatus());
            updateWrapper.set(PlanRosterPO::getChannelTaskId, planRosterPO.getChannelTaskId());
            updateWrapper.set(PlanRosterPO::getDistributeRecordId, planRosterPO.getDistributeRecordId());
            updateWrapper.set(PlanRosterPO::getChannelId, planRosterPO.getChannelId());
            updateWrapper.set(PlanRosterPO::getChannelName, planRosterPO.getChannelName());
            updateWrapper.set(PlanRosterPO::getSupplierTaskId, planRosterPO.getSupplierTaskId());
            updateWrapper.set(PlanRosterPO::getSupplierTaskName, planRosterPO.getSupplierTaskName());
            update(updateWrapper);
        }

    }

    @Override
    public List<PlanRosterEntity> queryByPartitionCode(String partitionCode, RosterQueryConditionDTO condition) {
        LambdaQueryWrapper<PlanRosterPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper
                .eq(PlanRosterPO::getPartitionCode, partitionCode)
                .eq(Objects.nonNull(condition.getDistributePlanId()), PlanRosterPO::getDistributePlanId, condition.getDistributePlanId())
                .in(CollectionUtils.isNotEmpty(condition.getPhoneNumList()), PlanRosterPO::getPhoneNum, condition.getPhoneNumList())
                .in(CollectionUtils.isNotEmpty(condition.getIdList()), PlanRosterPO::getId, condition.getIdList())
                .eq(PlanRosterPO::getIsDelete, DeleteEnum.NO.getCode());

        if (!Boolean.TRUE.equals(condition.getQueryAllField())){
            queryWrapper.select(PlanRosterPO::getPhoneNum, PlanRosterPO::getExternalId);
        }
        List<PlanRosterPO> poList = list(queryWrapper);
        return rosterInfConvert.toEntityList(poList);
    }

    private void checkPartitionCode(Long distributePlanId, String phoneNum) {
        AssertUtils.notNull(distributePlanId, "分流计划id不能为空");
        AssertUtils.notBlank(phoneNum, "手机号不能为空");
    }

    private Map<String, List<PlanRosterEntity>> getPartitionCodeMap(List<PlanRosterEntity> rosterEntityList) {
        return rosterEntityList.stream().collect(Collectors.groupingBy(e -> DBPartitionUtils.getRosterPartitionCode(e.getDistributePlanId(), e.getPhoneNum())));
    }
}
