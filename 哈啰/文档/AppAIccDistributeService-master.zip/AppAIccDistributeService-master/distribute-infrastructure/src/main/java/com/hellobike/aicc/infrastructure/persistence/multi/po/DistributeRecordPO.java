package com.hellobike.aicc.infrastructure.persistence.multi.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.hellobike.aicc.common.enums.DistributeRecordTypeEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 数据密级S2,下发记录
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_distribute_record")
public class DistributeRecordPO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id" ,type = IdType.INPUT)
    private Long id;

    /**
     * 数据密级S2,创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,逻辑删除
     */
    @TableField("is_delete")
    private Integer isDelete;

    /**
     * 数据密级S2,下发状态 1未下发 2下发中 3下发完成
     */
    @TableField("distribute_status")
    private Integer distributeStatus;

    /**
     * 下发类型
     * @see DistributeRecordTypeEnum
     */
    @TableField("distribute_type")
    private Integer distributeType;

    /**
     * 数据密级S2,下发数量
     */
    @TableField("distribute_count")
    private Integer distributeCount;

    /**
     * 数据密级S2,成功数量
     */
    @TableField("success_count")
    private Integer successCount;

    /**
     * 数据密级S2,下发时间
     */
    @TableField("distribute_time")
    private LocalDateTime distributeTime;

    /**
     * 渠道任务id
     */
    @TableField("channel_task_id")
    private Long channelTaskId;

    /**
     * 三方任务id
     */
    @TableField("supplier_task_id")
    private String supplierTaskId;

    /**
     * 三方任务名称
     */
    @TableField("supplier_task_name")
    private String supplierTaskName;

    /**
     * 数据密级S2,分流计划id
     */
    @TableField("distribute_plan_id")
    private Long distributePlanId;

    /**
     * 数据密级S2,渠道id
     */
    @TableField("channel_id")
    private Integer channelId;

    /**
     * 数据密级S2,上传记录id
     */
    @TableField("upload_record_id")
    private Long uploadRecordId;


    public static final String CREATE_TIME = "create_time";

    public static final String UPDATE_TIME = "update_time";

    public static final String IS_DELETE = "is_delete";

    public static final String DISTRIBUTE_STATUS = "distribute_status";

    public static final String DISTRIBUTE_COUNT = "distribute_count";

    public static final String SUCCESS_COUNT = "success_count";

    public static final String DISTRIBUTE_TIME = "distribute_time";

    public static final String CHANNEL_TASK_ID = "channel_task_id";

    public static final String SUPPLIER_TASK_ID = "supplier_task_id";

    public static final String SUPPLIER_TASK_NAME = "supplier_task_name";

    public static final String CHANNEL_TASK_NAME = "channel_task_name";

    public static final String DISTRIBUTE_PLAN_ID = "distribute_plan_id";

    public static final String CHANNEL_ID = "channel_id";

    public static final String UPLOAD_RECORD_ID = "upload_record_id";

}
