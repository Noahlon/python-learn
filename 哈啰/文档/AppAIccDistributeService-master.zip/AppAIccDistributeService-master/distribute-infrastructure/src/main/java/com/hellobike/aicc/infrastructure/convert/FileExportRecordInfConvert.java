package com.hellobike.aicc.infrastructure.convert;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.file.entity.FileExportRecordEntity;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributeFileExportRecordPO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  10:20:46
 */
@Mapper(componentModel = "spring")
public interface FileExportRecordInfConvert {

    FileExportRecordEntity toEntity(DistributeFileExportRecordPO po);

    DistributeFileExportRecordPO toPO(FileExportRecordEntity entity);

    @Mappings({
            @Mapping(target = "list", source = "records"),
            @Mapping(target = "pageNum", source = "current"),
            @Mapping(target = "pageSize", source = "size"),
            @Mapping(target = "totalRecord", source = "total"),
            @Mapping(target = "totalPages", source = "pages")
    })
    PageResult<FileExportRecordEntity> convertPage(Page<DistributeFileExportRecordPO> page);
}
