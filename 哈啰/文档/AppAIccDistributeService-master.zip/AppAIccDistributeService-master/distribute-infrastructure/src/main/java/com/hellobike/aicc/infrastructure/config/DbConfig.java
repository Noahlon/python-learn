package com.hellobike.aicc.infrastructure.config;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.core.config.GlobalConfig;
import com.baomidou.mybatisplus.core.toolkit.GlobalConfigUtils;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import com.baomidou.mybatisplus.extension.spring.MybatisSqlSessionFactoryBean;
import com.hellobike.hbdl.group.GroupDataSource;
import com.hellobike.hbdl.matrix.MatrixDataSource;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.io.IOException;
import java.util.Collections;

/**
 * 数据库配置
 *
 * @author LuJ
 * @since 2024-03-27 15:48
 */
@Slf4j
@Configuration
@EnableTransactionManagement
@MapperScan(basePackages = "com.hellobike.aicc.infrastructure.persistence.single.mapper", sqlSessionFactoryRef = "sqlSessionFactory")
@MapperScan(basePackages = {"com.hellobike.aicc.infrastructure.persistence.multi.mapper"}, sqlSessionFactoryRef = "sqlSessionFactory2")
public class DbConfig {


    @Value("${dbExtend.server-host}")
    private String host;

    @Value("${dbExtend.token}")
    private String token1;


    @Value("${dbExtend.token2}")
    private String token2;


    /**
     * 用了mybatis-plus，DataSource需要主动构造一下
     * GroupDataSource里已经包含了各类配置的初始化，不需要额外配置了
     */
    @Bean("dataSource2")
    public DataSource getDataSource2() {

        MatrixDataSource pds = new MatrixDataSource();
        pds.setBaseConfAddress(host);
        pds.setJdbcToken(token2);
        return pds;
    }

    @Bean("dataSource")
    public DataSource getDataSource() {
        GroupDataSource dataSource = new GroupDataSource();

        dataSource.setBaseConfAddress(host);
        dataSource.setJdbcToken(token1);

        return dataSource;
    }

    @Bean(name = "sqlSessionFactory2")
    public MybatisSqlSessionFactoryBean mybatisSqlSessionFactoryBean2(@Qualifier("dataSource2") DataSource dataSource, MybatisPlusInterceptor pageInterceptor) throws IOException {
        MybatisSqlSessionFactoryBean bean = new MybatisSqlSessionFactoryBean();
        GlobalConfig globalConfig = GlobalConfigUtils.defaults();
        //添加XML目录
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        bean.setMapperLocations(resolver.getResources("classpath*:mapper/multi/*.xml"));
        bean.setGlobalConfig(globalConfig);
        bean.setDataSource(dataSource);
        bean.setPlugins(pageInterceptor);
        bean.setTypeHandlers(new LocalDateTimeTypeHandlerCustomize());
        return bean;
    }

    @Bean("dataSourceTransactionManager2")
    public DataSourceTransactionManager dataSourceTransactionManager2(@Qualifier("dataSource2") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }


    @Bean(name = "sqlSessionFactory")
    public MybatisSqlSessionFactoryBean mybatisSqlSessionFactoryBean(@Qualifier("dataSource") DataSource dataSource, MybatisPlusInterceptor pageInterceptor) throws IOException {
        MybatisSqlSessionFactoryBean bean = new MybatisSqlSessionFactoryBean();
        GlobalConfig globalConfig = GlobalConfigUtils.defaults();
        //添加XML目录
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        bean.setMapperLocations(resolver.getResources("classpath*:mapper/single/*.xml"));
        bean.setGlobalConfig(globalConfig);
        bean.setDataSource(dataSource);
        bean.setPlugins(pageInterceptor);
        bean.setTypeHandlers(new LocalDateTimeTypeHandlerCustomize());
        return bean;
    }

    @Bean("dataSourceTransactionManager")
    @Primary
    public DataSourceTransactionManager dataSourceTransactionManager(@Qualifier("dataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }


    /**
     * 分页插件
     */
    @Bean
    public MybatisPlusInterceptor pageInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        PaginationInnerInterceptor paginationInterceptor = new PaginationInnerInterceptor(DbType.MYSQL);
        interceptor.setInterceptors(Collections.singletonList(paginationInterceptor));
        return interceptor;
    }
}
