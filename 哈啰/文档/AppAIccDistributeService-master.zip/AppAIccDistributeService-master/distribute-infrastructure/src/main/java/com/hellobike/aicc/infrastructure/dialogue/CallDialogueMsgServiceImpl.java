package com.hellobike.aicc.infrastructure.dialogue;

import com.hellobike.aicc.common.enums.RosterTypeEnum;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import com.hellobike.aicc.domain.dialogue.service.CallDialogueMsgService;
import com.hellobike.aicc.infrastructure.convert.CallDialogueInfConvert;
import com.hellobike.aicc.infrastructure.hms.dto.CallDialogueMsgDTO;
import com.hellobike.aicc.infrastructure.hms.producer.CallDialogueMsgProducer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-03-17  17:57:38
 */
@Service
@Slf4j
public class CallDialogueMsgServiceImpl implements CallDialogueMsgService {

    @Resource
    private CallDialogueMsgProducer callDialogueMsgProducer;

    @Resource
    private CallDialogueInfConvert callDialogueInfConvert;

    @Override
    public void sendMsg(CallDialogueEntity callDialogueEntity) {

        CallDialogueMsgDTO callDialogueMsgDTO = callDialogueInfConvert.callDialogueEntity2DTO(callDialogueEntity);
        if (Objects.equals(callDialogueEntity.getRosterType(), RosterTypeEnum.MD5.getCode())){
            callDialogueMsgDTO.setCalledNumber(callDialogueEntity.getMd5());
        }
        boolean sendRes = callDialogueMsgProducer.sendMsg(callDialogueMsgDTO);
        log.info("话单发送结果：{},id:{}", sendRes, callDialogueEntity.getId());
    }
}
