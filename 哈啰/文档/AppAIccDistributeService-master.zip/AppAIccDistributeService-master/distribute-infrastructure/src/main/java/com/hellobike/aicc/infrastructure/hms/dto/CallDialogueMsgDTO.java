package com.hellobike.aicc.infrastructure.hms.dto;

import lombok.Data;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-17  19:00:35
 */
@Data
public class CallDialogueMsgDTO {

    /**
     * 租户id
     */
    private String tenantId;

    /**
     * 企业id
     */
    private String enterpriseId;

    /**
     * 客户数据标识
     */
    private String dataIdentifier;

    /**
     * 平台数据标识
     */
    private String platformId;

    /**
     * 被叫号码
     */
    private String calledNumber;

    /**
     * 呼叫结果
     */
    private Integer callResult;

    /**
     * 呼叫结果描述
     */
    private String callResultDesc;

    /**
     * 意向分类code
     */
    private String intentClassify;

    /**
     * 意向分类名称
     */
    private String intentClassifyName;

    /**
     * 是否触发短信
     */
    private Integer isHitSms;

    /**
     * AI通话时长
     */
    private Integer durationCallAi;

    /**
     * 人工通话时长
     */
    private Integer durationCallManual;

    /**
     * 通话时长
     */
    private Integer totalTime;

    /**
     * 振铃时长
     */
    private Integer ringTime;

    /**
     * 开始时间
     */
    private String dialTime;

    /**
     * 挂机时间
     */
    private String hangupTime;

    /**
     * 计费单元数
     */
    private Integer costUnit;

    /**
     * 通话唯一id
     */
    private String dialogueGuid;

    /**
     * 挂断方
     */
    private Integer releaseInitiator;

    /**
     * 知识标签
     */
    private List<String> tags;

    /**
     * 分流计划模版id
     */
    private String templateId;

    /**
     * 说话次数
     */
    private Integer speakCount;

    /**
     * 数据密级S2,通话录音地址
     */
    private String recordUrl;

    /**
     * 对话轮次
     */
    private Integer speechCount;

    /**
     * 数据密级S2,分流计划id
     */
    private String distributePlanId;

    /**
     * 数据密级S2,分流计划名称
     */
    private String distributePlanName;
}
