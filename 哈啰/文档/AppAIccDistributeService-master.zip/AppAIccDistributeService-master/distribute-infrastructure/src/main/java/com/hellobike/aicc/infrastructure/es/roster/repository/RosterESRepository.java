package com.hellobike.aicc.infrastructure.es.roster.repository;

import cn.hutool.core.collection.CollectionUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.roster.entity.RosterStat;
import com.hellobike.aicc.infrastructure.es.BaseEsRepository;
import com.hellobike.aicc.infrastructure.es.EsQueryWrapper;
import com.hellobike.aicc.infrastructure.es.roster.condition.RosterESCondition;
import com.hellobike.aicc.infrastructure.es.roster.po.PlanRosterESPO;
import com.hellobike.es.sdk.common.EsApplication;
import com.hellobike.es.sdk.common.iface.ISearchRepository;
import com.hellobike.es.sdk.template.RestHighLevelClientFacade;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.support.IndicesOptions;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.filter.FilterAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.filter.ParsedFilter;
import org.elasticsearch.search.aggregations.bucket.terms.ParsedLongTerms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.ParsedValueCount;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-05-23  13:45:52
 */
@Slf4j
@Service
public class RosterESRepository extends BaseEsRepository {

    private static final String ROSTER_INDEX_PER = "aicc_distribute_roster_index";

    private static final String GROUP_BY_TASK = "group_by_task";
    private static final String GROUP_BY_PLAN = "group_by_plan";

    @Override
    public String getIndex() {
        return ROSTER_INDEX_PER;
    }

    public boolean save(List<PlanRosterESPO> rosterESPOList) {
        BulkRequest bulkRequest = new BulkRequest();

        for (PlanRosterESPO esPO : rosterESPOList) {
            LocalDateTime distPlanCreateTime = esPO.getDistPlanCreateTime();
            if (Objects.isNull(distPlanCreateTime)) {
                log.error("分流计划创建时间为空，rosterId:{}", esPO.getId());
                continue;
            }

            String indexName = getIndex() + "-" + DateUtils.formatEsIndex(distPlanCreateTime);
            esPO.setDistPlanCreateTime(null);

            String jsonDocument;
            try {
                ObjectMapper mapper = new ObjectMapper();
                jsonDocument = mapper.writeValueAsString(esPO);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }

            IndexRequest indexRequest = new IndexRequest(indexName)
                    .source(jsonDocument, XContentType.JSON)
                    .id(String.valueOf(esPO.getId()));

            bulkRequest.add(indexRequest);
        }
        return insertOrUpdateList(bulkRequest);
    }

    private EsQueryWrapper buildWrapper(RosterESCondition condition) {
        EsQueryWrapper wrapper = new EsQueryWrapper();
        //话单id
        wrapper.eq(PlanRosterESPO.ID, condition.getId());
        //分流计划id
        wrapper.eq(PlanRosterESPO.DISTRIBUTE_PLAN_ID, condition.getDistributePlanId());
        wrapper.eqs(PlanRosterESPO.DISTRIBUTE_PLAN_ID, condition.getDistributePlanIdList());
        //渠道id
        wrapper.eq(PlanRosterESPO.CHANNEL_ID, Objects.nonNull(condition.getChannelId()) ? String.valueOf(condition.getChannelId()) : null);
        return wrapper;
    }

    public List<RosterStat> statByChannelTask(RosterESCondition condition) {
        return statRoster(condition, PlanRosterESPO.CHANNEL_TASK_ID, GROUP_BY_TASK);
    }

    public List<RosterStat> statByPlan(RosterESCondition condition) {
        return statRoster(condition, PlanRosterESPO.DISTRIBUTE_PLAN_ID, GROUP_BY_PLAN);
    }

    private List<RosterStat> statRoster(
            RosterESCondition condition,
            String groupField,
            String groupName) {
        EsQueryWrapper wrapper = buildWrapper(condition);
        List<String> indexList = buildRosterIndex(condition);
        try {
            ISearchRepository searchRepository = EsApplication.getInstance().getSearchRepository(clusterName);
            RestHighLevelClientFacade client = searchRepository.getRestHighLevelClientFacade();
            //已呼叫名单数
            AggregationBuilder callRosterNum = AggregationBuilders
                    .filter("callRosterNum", QueryBuilders.rangeQuery(PlanRosterESPO.CALL_DIALOGUE_NUM).gt(0))
                    .subAggregation(AggregationBuilders.count("callRosterNum").field(PlanRosterESPO.ID));

            //接通名单数
            FilterAggregationBuilder throughRosterNum = AggregationBuilders
                    .filter("throughRosterNum", QueryBuilders.rangeQuery(PlanRosterESPO.THROUGH_CALL_DIALOGUE_NUM).gt(0))
                    .subAggregation(AggregationBuilders.count("throughRosterNum").field(PlanRosterESPO.ID));

            //发送短信名单数
            FilterAggregationBuilder sendSmsRosterNum = AggregationBuilders
                    .filter("sendSmsRosterNum", QueryBuilders.rangeQuery(PlanRosterESPO.SMS_SEND_COUNT).gt(0))
                    .subAggregation(AggregationBuilders.count("sendSmsRosterNum").field(PlanRosterESPO.ID));

            //发送短信成功名单数
            FilterAggregationBuilder sendSmsSuccRosterNum = AggregationBuilders
                    .filter("sendSmsSuccRosterNum", QueryBuilders.rangeQuery(PlanRosterESPO.SMS_SEND_SUCCESS_COUNT).gt(0))
                    .subAggregation(AggregationBuilders.count("sendSmsSuccRosterNum").field(PlanRosterESPO.ID));

            TermsAggregationBuilder termsAggregationBuilder = AggregationBuilders
                    .terms(groupName)
                    .field(groupField)
                    .size(1000)
                    .subAggregation(callRosterNum)
                    .subAggregation(throughRosterNum)
                    .subAggregation(sendSmsRosterNum)
                    .subAggregation(sendSmsSuccRosterNum);

            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(wrapper.build())
                    .aggregation(termsAggregationBuilder)
                    .size(0);

            String[] indexArray = buildIndex(indexList);
            SearchRequest searchRequest = new SearchRequest(indexArray);
            searchRequest.source(searchSourceBuilder);
            searchRequest.indicesOptions(IndicesOptions.fromOptions(true, false, true, false));

            SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
            if (searchResponse == null) {
                log.error("名单单统计response为null");
                return new ArrayList<>();
            }

            Aggregations aggregations = searchResponse.getAggregations();
            ParsedLongTerms term = aggregations.get(groupName);

            List<RosterStat> result = new ArrayList<>();
            for (Terms.Bucket bucket : term.getBuckets()) {
                RosterStat statisticEntity = new RosterStat();
                if (Objects.equals(groupName, GROUP_BY_PLAN)) {
                    statisticEntity.setDistributePlanId(String.valueOf(bucket.getKey()));
                } else if (Objects.equals(groupName, GROUP_BY_TASK)) {
                    statisticEntity.setChannelTaskId(String.valueOf(bucket.getKey()));
                }

                Map<String, Aggregation> aggregationsAsMap = bucket.getAggregations().getAsMap();

                //已呼叫名单数
                ParsedFilter callRosterNumFilter = (ParsedFilter) aggregationsAsMap.get("callRosterNum");
                ParsedValueCount callRosterNumCount = callRosterNumFilter.getAggregations().get("callRosterNum");

                //接通名单数
                ParsedFilter throughRosterNumFilter = (ParsedFilter) aggregationsAsMap.get("throughRosterNum");
                ParsedValueCount throughRosterNumCount = throughRosterNumFilter.getAggregations().get("throughRosterNum");

                //发送短信名单数
                ParsedFilter sendSmsRosterNumFilter = (ParsedFilter) aggregationsAsMap.get("sendSmsRosterNum");
                ParsedValueCount sendSmsRosterNumCount = sendSmsRosterNumFilter.getAggregations().get("sendSmsRosterNum");

                //发送短信名单数
                ParsedFilter sendSmsSuccRosterNumFilter = (ParsedFilter) aggregationsAsMap.get("sendSmsSuccRosterNum");
                ParsedValueCount sendSmsSuccRosterNumCount = sendSmsSuccRosterNumFilter.getAggregations().get("sendSmsSuccRosterNum");

                statisticEntity.setCallRosterNum(callRosterNumCount.getValue());
                statisticEntity.setThroughRosterNum(throughRosterNumCount.getValue());
                statisticEntity.setSendSmsRosterNum(sendSmsRosterNumCount.getValue());
                statisticEntity.setSendSmsSuccRosterNum(sendSmsSuccRosterNumCount.getValue());
                result.add(statisticEntity);
            }
            return result;

        } catch (Exception e) {
            log.error("名单统计异常", e);
            return new ArrayList<>();
        }

    }

    private List<String> buildRosterIndex(RosterESCondition condition) {
        List<String> indexList = new ArrayList<>();
        if (CollectionUtil.isNotEmpty(condition.getIndexList())) {
            condition.getIndexList().forEach(index -> indexList.add(DateUtils.formatEsIndex(index)));
        }
        return indexList;
    }


}
