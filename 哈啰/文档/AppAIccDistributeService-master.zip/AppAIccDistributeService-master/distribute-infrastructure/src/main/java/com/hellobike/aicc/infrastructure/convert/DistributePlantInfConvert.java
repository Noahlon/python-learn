package com.hellobike.aicc.infrastructure.convert;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributeRuleEntity;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributePlanPO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring", imports = {BaseJsonUtils.class, DistributeRuleEntity.class})
public interface DistributePlantInfConvert {
    @Mappings(
            @Mapping(target = "distributeRuleList", expression = "java(BaseJsonUtils.readValues(po.getDistributeRule(), DistributeRuleEntity.class))")
    )
    DistributePlanEntity toEntity(DistributePlanPO po);

    @Mappings(
            @Mapping(target = "distributeRule", expression = "java(BaseJsonUtils.writeValue(entity.getDistributeRuleList()))")
    )
    DistributePlanPO toPO(DistributePlanEntity entity);

    @Mappings({
            @Mapping(target = "list", source = "records"),
            @Mapping(target = "pageNum", source = "current"),
            @Mapping(target = "pageSize", source = "size"),
            @Mapping(target = "totalRecord", source = "total"),
            @Mapping(target = "totalPages", source = "pages")
    })
    PageResult<DistributePlanEntity> convert(Page<DistributePlanPO> page);

    List<DistributePlanEntity> convert(List<DistributePlanPO> list);
}
