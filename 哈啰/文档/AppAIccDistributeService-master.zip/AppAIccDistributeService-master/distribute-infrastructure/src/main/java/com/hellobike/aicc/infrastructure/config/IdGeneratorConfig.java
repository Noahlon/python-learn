package com.hellobike.aicc.infrastructure.config;

import com.hellobike.base.hammer.generator.IdGeneratorManager;
import com.hellobike.base.hammer.generator.LongIdConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * id生成器配置
 *
 * @author chenkangkang
 */
@Configuration
@Slf4j
public class IdGeneratorConfig {
    private static final String APP_ID_KEY = "APPID";
    private static final String ENV_KEY = "env";

    @Bean("longIdGenerator")
    public IdGeneratorManager newLongIdGenerator() {
        LongIdConfig idConfig = new LongIdConfig();
        idConfig.setAppId(System.getProperty(APP_ID_KEY));
        idConfig.setAppEnv(System.getProperty(ENV_KEY));
        return IdGeneratorManager.getInstance(idConfig);
    }

    @Bean
    public IdGeneratorManager longIdGenerator() {
        LongIdConfig idConfig = new LongIdConfig();
        idConfig.setAppId(System.getProperty(APP_ID_KEY));
        idConfig.setAppEnv(System.getProperty(ENV_KEY));
        return IdGeneratorManager.getInstance(idConfig);
    }

}
