package com.hellobike.aicc.infrastructure.es.smsrecord.po;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.searchbox.annotations.JestId;
import lombok.Data;

@Data
public class SmsRecordESPO {
    /**
     * 短信id
     */
    @JestId
    private Long guid;

    /**
     * 名单id
     */
    private Long rosterId;

    /**
     * 平台数据唯一标识
     */
    private String platformId;

    /**
     * 渠道id
     */
    private Integer channelId;

    /**
     * 渠道名称
     */
    private String channelName;

    /**
     * 客户数据标识
     */
    private String externalId;

    /**
     * 手机号码
     */
    private String phoneNumber;

    /**
     * 手机号码的32位小写md5加密
     */
    private String phoneNumberMd5;

    /**
     * 分流计划id
     */
    private Long distributePlanId;

    /**
     * 渠道任务id
     */
    private Long channelTaskId;

    /**
     * 分流计划名称
     */
    private String distributePlanName;

    /**
     * 分流计划平台对应话单id
     */
    private Long distributePlanCallId;

    /**
     * 渠道商任务id
     */
    private String supplierTaskId;

    /**
     * 渠道商任务名称
     */
    private String supplierTaskName;

    /**
     * 企业id
     */
    private String enterpriseId;

    /**
     * 话术名称
     */
    private String speechName;

    /**
     * 租户code
     */
    private String tenantCode;

    /**
     * 短信签名
     */
    private String signature;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 短信提交时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String submitTime;

    /**
     * 短信提交结果
     */
    private Integer submitResult;

    /**
     * 短信发送时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String sendTime;

    /**
     * 短信发送结果
     */
    private Integer sendResult;

    /**
     * 收到短信结果时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String receiveResultTime;

    /**
     * 计费条数
     */
    private Integer billingNum;

    /**
     * 坐席id
     */
    private String seatsGuid;

    /**
     * 坐席名称
     */
    private String seatsName;

    /**
     * 客户名称
     */
    private String customName;

    /**
     * 渠道商通话记录id
     */
    private String supplierCallGuid;

    /**
     * 渠道商短信记录id
     */
    private String supplierSmsGuid;

    /**
     * 运营商
     */
    private Integer carrier;

    /**
     * 省份
     */
    private String province;

    /**
     * 城市
     */
    private String city;

    /**
     * 创建时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String createTime;

    /**
     * 最近更新时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private String updateTime;

    /**
     * 逻辑删除
     */
    private Integer isDelete;

    public static final String CHANNEL_ID = "channelId";

    public static final String GUID = "guid";

    public static final String PLATFORM_ID = "platformId";

    public static final String PHONE_NUMBER = "phoneNumber";

    public static final String PHONE_NUMBER_MD5 = "phoneNumberMd5";

    public static final String DISTRIBUTE_PLAN_NAME = "distributePlanName";

    public static final String DISTRIBUTE_PLAN_ID = "distributePlanId";

    public static final String CHANNEL_TASK_ID = "channelTaskId";

    public static final String SUPPLIER_TASK_ID = "supplierTaskId";

    public static final String SUPPLIER_TASK_NAME = "supplierTaskName";

    public static final String SEND_RESULT = "sendResult";

    public static final String SIGNATURE = "signature";

    public static final String CONTENT = "content";

    public static final String CREATE_TIME = "createTime";

    public static final String SEND_TIME = "sendTime";

    public static final String RECEIVE_RESULT_TIME = "receiveResultTime";

    public static final String SEATS_NAME = "seatsName";

    public static final String SUPPLIER_CALL_GUID = "supplierCallGuid";

    public static final String CITY = "city";

    public static final String CARRIER = "carrier";

    public static final String BILLING_NUM = "billingNum";

    public static final String ROSTER_ID = "rosterId";
}
