package com.hellobike.aicc.infrastructure.persistence.multi.mapper;

import com.hellobike.aicc.infrastructure.persistence.multi.po.SupplierCallDialoguePO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 数据密级S2,渠道商原始话单表 Mapper 接口
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-04-22
 */
public interface SupplierCallDialogueMapper extends BaseMapper<SupplierCallDialoguePO> {

}
