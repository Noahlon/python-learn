package com.hellobike.aicc.infrastructure.hms.consumer.sms;

import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.dto.ChannelSmsPushDTO;
import com.hellobike.aicc.domain.channelcallback.service.CallbackService;
import com.hellobike.aicc.domain.common.service.DingTalkService;
import com.hellobike.aicc.infrastructure.hms.consumer.BaseMsgConsumer;
import com.hellobike.hms.sdk.consumer.ConsumeMessage;
import com.hellobike.hms.sdk.consumer.MsgRetryStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Objects;

/**
 *
 */
@Slf4j
@Component
public class ChannelSmsMsgConsumer extends BaseMsgConsumer {
    private static final String CONSUMER = "aicc_channel_sms_callback_topic_local_consumer";

    @Resource
    private CallbackService callbackService;

    @Resource
    private DingTalkService dingTalkService;

    @Override
    protected String getConsumerName() {
        return CONSUMER;
    }

    @Override
    public MsgRetryStatus msgProcess(ConsumeMessage mqMessage) {
        try {
            doConsumer(mqMessage);
        } catch (Exception e) {
            log.error("消费渠道短信记录异常,e:", e);
            dingTalkService.sendSmsRecordFailedAlert(mqMessage.getKey());
        }
        return MsgRetryStatus.SUCCEED;
    }

    private void doConsumer(ConsumeMessage mqMessage) {
        String msgBody = new String(mqMessage.getPayload());
        log.info("渠道短信记录消息key:{}", mqMessage.getKey());
        ChannelSmsPushDTO smsPushDTO = BaseJsonUtils.readValue(msgBody, ChannelSmsPushDTO.class);
        if (Objects.isNull(smsPushDTO) || Objects.isNull(smsPushDTO.getChannelId()) || Objects.isNull(smsPushDTO.getSmsRecordCallBackDTO())) {
            log.error("渠道短信消息为空, 或者渠道id为空dto:{}", smsPushDTO);
            return;
        }
        callbackService.smsRecordCallBack(smsPushDTO.getSmsRecordCallBackDTO(), smsPushDTO.getChannelId());
    }
}
