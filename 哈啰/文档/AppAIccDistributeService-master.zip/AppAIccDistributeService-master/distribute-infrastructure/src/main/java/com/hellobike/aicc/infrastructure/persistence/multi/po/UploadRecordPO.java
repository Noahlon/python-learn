package com.hellobike.aicc.infrastructure.persistence.multi.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 数据密级S2,上传记录
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_upload_record")
public class UploadRecordPO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id" ,type = IdType.INPUT)
    private Long id;

    /**
     * 数据密级S2,创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,逻辑删除
     */
    @TableField("is_delete")
    private Integer isDelete;

    /**
     * 数据密级S2,上传方式类型
     */
    @TableField("upload_type")
    private Integer uploadType;

    /**
     * 数据密级S2,上传状态
     */
    @TableField("upload_status")
    private Integer uploadStatus;

    /**
     * 数据密级S2,上传数量
     */
    @TableField("upload_count")
    private Integer uploadCount;

    /**
     * 数据密级S2,上传时间
     */
    @TableField("upload_time")
    private LocalDateTime uploadTime;

    /**
     * 数据密级S2,下发状态
     */
    @TableField("distribute_status")
    private Integer distributeStatus;

    /**
     * 数据密级S2,下发数量
     */
    @TableField("distribute_count")
    private Integer distributeCount;

    /**
     * 数据密级S2,操作人
     */
    @TableField("operator")
    private String operator;

    /**
     * 数据密级S2,分流类型
     */
    @TableField("distribute_type")
    private Integer distributeType;

    /**
     * 数据密级S2,分流计划id
     */
    @TableField("distribute_plan_id")
    private Long distributePlanId;

    /**
     * 数据密级S2,上传失败原因
     */
    @TableField("upload_fail_reason")
    private String uploadFailReason;

    /**
     * 数据密级S2,名单类型，1-明文，2-md5
     */
    @TableField("roster_type")
    private Integer rosterType;


    public static final String CREATE_TIME = "create_time";

    public static final String UPDATE_TIME = "update_time";

    public static final String IS_DELETE = "is_delete";

    public static final String UPLOAD_TYPE = "upload_type";

    public static final String UPLOAD_STATUS = "upload_status";

    public static final String UPLOAD_COUNT = "upload_count";

    public static final String DISTRIBUTE_STATUS = "distribute_status";

    public static final String DISTRIBUTE_COUNT = "distribute_count";

    public static final String UPLOAD_TIME = "upload_time";

    public static final String OPERATOR = "operator";

    public static final String SORT = "sort";

    public static final String DISTRIBUTE_TYPE = "distribute_type";

    public static final String DISTRIBUTE_PLAN_ID = "distribute_plan_id";

}
