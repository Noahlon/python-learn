package com.hellobike.aicc.infrastructure.persistence.single.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.file.dto.FileExportRecordConditionDTO;
import com.hellobike.aicc.domain.file.entity.FileExportRecordEntity;
import com.hellobike.aicc.domain.file.repo.FileExportRecordRepository;
import com.hellobike.aicc.infrastructure.convert.FileExportRecordInfConvert;
import com.hellobike.aicc.infrastructure.persistence.single.mapper.DistributeFileExportRecordMapper;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributeFileExportRecordPO;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Objects;

/**
 * <p>
 * 数据密级S2,分流平台文件导出记录 服务实现类
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-05-22
 */
@Service
public class DistributeFileExportRecordRepositoryImpl extends ServiceImpl<DistributeFileExportRecordMapper, DistributeFileExportRecordPO> implements FileExportRecordRepository {

    @Resource
    private FileExportRecordInfConvert exportRecordInfConvert;

    @Override
    public void saveOrUpdate(FileExportRecordEntity entity) {
        DistributeFileExportRecordPO po = exportRecordInfConvert.toPO(entity);
        saveOrUpdate(po);
    }

    @Override
    public PageResult<FileExportRecordEntity> pageRecord(FileExportRecordConditionDTO condition, Integer pageNum, Integer pageSize) {
        LambdaQueryWrapper<DistributeFileExportRecordPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Objects.nonNull(condition.getBizType()), DistributeFileExportRecordPO::getBizType, condition.getBizType())
                .eq(Objects.nonNull(condition.getStatus()), DistributeFileExportRecordPO::getStatus, condition.getStatus())
                .ge(Objects.nonNull(condition.getCreateTimeStart()), DistributeFileExportRecordPO::getCreateTime, condition.getCreateTimeStart())
                .le(Objects.nonNull(condition.getCreateTimeEnd()), DistributeFileExportRecordPO::getCreateTime, condition.getCreateTimeEnd())
                .orderByDesc(DistributeFileExportRecordPO::getCreateTime);
        Page<DistributeFileExportRecordPO> page = page(new Page<>(pageNum, pageSize), queryWrapper);
        return exportRecordInfConvert.convertPage(page);
    }
}
