package com.hellobike.aicc.infrastructure.hms.producer;

import com.alibaba.fastjson.JSON;
import com.hellobike.aicc.domain.roster.dto.RosterUpdDTO;
import com.hellobike.hms.sdk.Hms;
import com.hellobike.hms.sdk.common.SimpleMessage;
import com.hellobike.hms.sdk.common.SimpleMessageBuilder;
import com.hellobike.hms.sdk.producer.HmsCallBack;
import com.hellobike.hms.sdk.producer.SendResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @author zhangzhuoqi
 * @since 2025-05-24  10:50:53
 */
@Service
@Slf4j
public class RosterUpdProducer {

    private static final String TOPIC = "aicc_distribute_roster_topic";

    public void sendMsg(RosterUpdDTO msg) {
        SimpleMessage message = SimpleMessageBuilder
                .newInstance()
                .buildPaylod(JSON.toJSONBytes(msg))
                .buildKey(msg.getId())
                .build();
        Hms.sendAsync(TOPIC, message, new HmsCallBack() {
            @Override
            public void onException(Throwable exception) {
                log.error("名单消息发送异常key:{},e:", msg.getId(), exception);
            }

            @Override
            public void onResult(SendResponse response) {

            }
        });
    }
}
