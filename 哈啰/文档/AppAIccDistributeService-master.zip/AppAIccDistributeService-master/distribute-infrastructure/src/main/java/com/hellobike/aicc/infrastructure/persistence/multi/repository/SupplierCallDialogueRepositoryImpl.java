package com.hellobike.aicc.infrastructure.persistence.multi.repository;

import com.hellobike.aicc.domain.dialogue.entity.SupplierCallDialogueEntity;
import com.hellobike.aicc.domain.dialogue.repo.SupplierCallDialogueRepository;
import com.hellobike.aicc.infrastructure.convert.SupplierCallDialogueInfConvert;
import com.hellobike.aicc.infrastructure.persistence.multi.po.SupplierCallDialoguePO;
import com.hellobike.aicc.infrastructure.persistence.multi.mapper.SupplierCallDialogueMapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 * 数据密级S2,渠道商原始话单表 服务实现类
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-04-22
 */
@Service
public class SupplierCallDialogueRepositoryImpl extends ServiceImpl<SupplierCallDialogueMapper, SupplierCallDialoguePO> implements SupplierCallDialogueRepository {

    @Resource
    private SupplierCallDialogueInfConvert convert;

    @Override
    public void save(SupplierCallDialogueEntity supplierCallDialogueEntity) {
        SupplierCallDialoguePO po = convert.toPO(supplierCallDialogueEntity);
        save(po);
    }
}
