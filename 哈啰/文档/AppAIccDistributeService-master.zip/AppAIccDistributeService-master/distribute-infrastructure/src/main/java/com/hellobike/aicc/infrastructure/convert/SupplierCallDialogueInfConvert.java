package com.hellobike.aicc.infrastructure.convert;

import com.hellobike.aicc.domain.dialogue.entity.SupplierCallDialogueEntity;
import com.hellobike.aicc.infrastructure.persistence.multi.po.SupplierCallDialoguePO;
import org.mapstruct.Mapper;

/**
 * @author zhangzhuoqi
 * @since 2025-04-22  13:47:48
 */
@Mapper(componentModel = "spring")
public interface SupplierCallDialogueInfConvert {

    SupplierCallDialogueEntity toEntity(SupplierCallDialoguePO supplierCallDialoguePO);

    SupplierCallDialoguePO toPO(SupplierCallDialogueEntity supplierCallDialogueEntity);
}
