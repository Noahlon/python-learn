/**
 * AtContent.java
 * Copyright 2023 HelloBike , all rights reserved.
 * HelloBike PROPRIETARY/CONFIDENTIAL, any form of usage is subject to approval.
 */

package com.hellobike.aicc.infrastructure.notify.dingding.dto;

import lombok.*;

import java.util.List;

/**
 * @author older
 * @since 2023/2/13
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AtContentDTO {

    /**
     * 是否at所有人
     */
    private Boolean isAtAll = false;


    /**
     * 艾特人员列表
     */
    private List<String> atMobiles;
}