package com.hellobike.aicc.infrastructure.persistence.single.mapper;

import com.hellobike.aicc.infrastructure.persistence.single.po.DistributePlanTemplatePO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 数据密级S2,分流计划模版 Mapper 接口
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
public interface DistributePlanTemplateMapper extends BaseMapper<DistributePlanTemplatePO> {

}
