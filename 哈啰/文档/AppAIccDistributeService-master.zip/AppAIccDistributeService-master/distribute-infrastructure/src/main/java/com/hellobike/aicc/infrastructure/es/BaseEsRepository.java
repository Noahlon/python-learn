package com.hellobike.aicc.infrastructure.es;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hellobike.aicc.infrastructure.es.calldialogue.po.CallDialogueESPO;
import com.hellobike.es.sdk.common.EsApplication;
import com.hellobike.es.sdk.common.iface.ISearchRepository;
import com.hellobike.es.sdk.template.RestHighLevelClientFacade;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.ClearScrollRequest;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequest;
import org.elasticsearch.action.support.IndicesOptions;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.core.CountResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Slf4j
public abstract class BaseEsRepository {
    @Value("${es.cluster.name:AppHelloSearchServiceElasticsearch}")
    protected String clusterName;


    protected static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    public static final DateTimeFormatter YYYYMM_FORMATTER = DateTimeFormatter.ofPattern("yyyyMM");
    public static final DateTimeFormatter YYYYMMDD_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");
    public static final String CACHE_TIME = "5m";
    public static final String CACHE_TIME_10 = "10m";
    public static final String ALL_MATCH = "*";
    public static final String HITS_STR = "hits";
    public static final String AGGREGATIONS_STR = "aggregations";
    public static final String VALUE_STR = "value";
    public static final String SOURCE_STR = "_source";
    public static final String SCROLL_STR = "_scroll_id";
    public static final String SUM_FIELD_STR = "sum_field";
    public static final String INDEX_STR = "-";
    public static final Integer MAX_SEARCH_SIZE = 10000;

    /**
     * 设置索引
     *
     * @return 索引名称
     */
    public abstract String getIndex();

    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 新增/更新es
     */
    public boolean insertOrUpdateList(BulkRequest bulkRequest) {

        ISearchRepository searchRepository = EsApplication.getInstance().getSearchRepository(clusterName);
        RestHighLevelClientFacade client = searchRepository.getRestHighLevelClientFacade();

        // Execute BulkRequest
        BulkResponse bulkResponse = null;
        try {
            bulkResponse = client.bulk(bulkRequest, RequestOptions.DEFAULT);
        } catch (IOException e) {
            log.error("save2ESNew.es异常:", e);
        }

        if (Objects.isNull(bulkResponse) || bulkResponse.hasFailures()) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * es searchAfter查询
     */
    public <Data> EsPage<Data> searchWithSearchAfter(
            EsQueryWrapper esQueryWrapper,
            Class<Data> clazz,
            SortBuilder<?> sort,
            Long size,
            List<String> dateIndex) throws IOException {

        ISearchRepository searchRepository = EsApplication.getInstance().getSearchRepository(clusterName);
        RestHighLevelClientFacade client = searchRepository.getRestHighLevelClientFacade();

        String[] indexArray = buildIndex(dateIndex);
        SearchRequest searchRequest = new SearchRequest(indexArray);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder()
                .query(esQueryWrapper.build())
                .size(size.intValue())
                .sort(sort)
                .sort(SortBuilders.fieldSort("_id").order(SortOrder.DESC));

        // 设置 search_after 参数
        if (esQueryWrapper.getSearchAfterValues() != null) {
            searchSourceBuilder.searchAfter(esQueryWrapper.getSearchAfterValues());
        }

        searchRequest.source(searchSourceBuilder);
        searchRequest.indicesOptions(IndicesOptions.fromOptions(true, false, true, false));

        // 执行搜索请求
        SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);

        List<Data> dataList = new ArrayList<>();
        if (searchResponse == null || searchResponse.getHits().getTotalHits().value == 0) {
            return new EsPage<>(0, 1, size.intValue(), dataList, null, null);
        }

        for (SearchHit hit : searchResponse.getHits().getHits()) {
            Data data = objectMapper.readValue(hit.getSourceAsString(), clazz);
            dataList.add(data);
        }

        // 获取最后一个文档的排序值作为下一个 searchAfterValues
        Object[] nextSearchAfterValues = null;
        SearchHit[] hits = searchResponse.getHits().getHits();
        if (hits.length > 0) {
            nextSearchAfterValues = hits[hits.length - 1].getSortValues();
        }

        return new EsPage<>(0, 1, size.intValue(), dataList, nextSearchAfterValues, null);
    }


    /**
     * 字段计数
     *
     * @param esQueryWrapper
     * @return
     */
    public long count(EsQueryWrapper esQueryWrapper, List<String> dateIndex) {
        try {
            ISearchRepository searchRepository = EsApplication.getInstance().getSearchRepository(clusterName);
            RestHighLevelClientFacade client = searchRepository.getRestHighLevelClientFacade();

            String[] indexArray = buildIndex(dateIndex);
            CountRequest countRequest = new CountRequest(indexArray);
            countRequest.query(esQueryWrapper.build());
            countRequest.indicesOptions(IndicesOptions.fromOptions(true, true, true, false));
            CountResponse countResponse = null;
            countResponse = client.count(countRequest, RequestOptions.DEFAULT);
            long count = countResponse.getCount();
            return count;
        } catch (IOException e) {
            log.error("esCountV2.error", e);
        }
        return 0;
    }

    public String[] buildIndex(List<String> dateIndex) {
        List<String> indexes = new ArrayList<>();
        if (!CollectionUtil.isEmpty(dateIndex)) {
            for (String indexStr : dateIndex) {
                indexes.add(getIndex() + INDEX_STR + indexStr);
            }
        } else {
            indexes.add(getIndex() + ALL_MATCH);
        }

        return indexes.toArray(new String[0]);
    }

    /**
     * es scroll查询
     *
     * @param esQueryWrapper
     * @param clazz
     * @param scrollTime
     * @param size
     * @param dateIndex
     * @param clearButton
     * @param scrollId
     * @param <Data>
     * @return
     * @throws IOException
     */
    public <Data> EsPage<Data> searchWithScrollV2(
            EsQueryWrapper esQueryWrapper,
            Class<Data> clazz,
            String scrollTime,
            Long size,
            List<String> dateIndex,
            SortBuilder<?> sort,
            String idSort,
            Boolean clearButton,
            String scrollId) throws IOException {

        ISearchRepository searchRepository = EsApplication.getInstance().getSearchRepository(clusterName);
        RestHighLevelClientFacade client = (RestHighLevelClientFacade) searchRepository.getRestHighLevelClientFacade();


        if (scrollId == null) {
            // Build initial search request
            String[] indexArray = buildIndex(dateIndex);

            SearchRequest searchRequest = new SearchRequest(indexArray);
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder()
                    .query(esQueryWrapper.build())
                    .size(size.intValue())
                    .sort(sort)
                    .sort(SortBuilders.fieldSort(idSort).order(SortOrder.DESC));

            searchRequest.source(searchSourceBuilder);
            searchRequest.scroll(scrollTime);
            searchRequest.indicesOptions(IndicesOptions.fromOptions(true, false, true, false));

            CountRequest countRequest = new CountRequest(indexArray);
            countRequest.query(esQueryWrapper.build());
            countRequest.indicesOptions(IndicesOptions.fromOptions(true, false, true, false));
            CountResponse countResponse = client.count(countRequest, RequestOptions.DEFAULT);
            long count = countResponse.getCount();

            // Execute initial search
            SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);

            if (searchResponse.getHits().getTotalHits().value == 0) {
                return new EsPage<>(0, 1, size.intValue(), Collections.emptyList(), null, null);
            }

            // Process search response
            List<Data> sourceAsObjectList = new ArrayList<>();
            for (SearchHit hit : searchResponse.getHits().getHits()) {
//                Data data = JSON.parseObject(hit.getSourceAsString(), clazz);
                Data data = objectMapper.readValue(hit.getSourceAsString(), clazz);
                sourceAsObjectList.add(data);
            }

            scrollId = searchResponse.getScrollId();

            if (sourceAsObjectList.isEmpty() || clearButton) {
                ClearScrollRequest clearScrollRequest = new ClearScrollRequest();
                clearScrollRequest.setScrollIds(Collections.singletonList(scrollId));
                client.clearScroll(clearScrollRequest, RequestOptions.DEFAULT);
            }

            return new EsPage<>((int) count, 1, size.intValue(), sourceAsObjectList, null, scrollId);

        } else {
            // Execute scroll request
            SearchScrollRequest scrollRequest = new SearchScrollRequest(scrollId);
            scrollRequest.scroll(scrollTime);

            SearchResponse searchResponse = client.scroll(scrollRequest, RequestOptions.DEFAULT);

            if (searchResponse.getHits().getHits().length == 0) {
                return new EsPage<>(0, 1, size.intValue(), Collections.emptyList(), null, null);
            }

            // Process scroll response
            List<Data> result = new ArrayList<>();
            for (SearchHit hit : searchResponse.getHits().getHits()) {
                Data data = objectMapper.readValue(hit.getSourceAsString(), clazz);
                result.add(data);
            }

            if (result.isEmpty() || clearButton) {
                ClearScrollRequest clearScrollRequest = new ClearScrollRequest();
                clearScrollRequest.setScrollIds(Collections.singletonList(scrollId));
                client.clearScroll(clearScrollRequest, RequestOptions.DEFAULT);
            }

            return new EsPage<>(result.size(), 1, size.intValue(), result, null, scrollId);
        }
    }

    public void cleatScroll(String scrollId) {
        try {
            if (StrUtil.isEmpty(scrollId)) {
                return;
            }
            ISearchRepository searchRepository = EsApplication.getInstance().getSearchRepository(clusterName);
            RestHighLevelClientFacade client = (RestHighLevelClientFacade) searchRepository.getRestHighLevelClientFacade();

            ClearScrollRequest clearScrollRequest = new ClearScrollRequest();
            clearScrollRequest.setScrollIds(Collections.singletonList(scrollId));
            client.clearScroll(clearScrollRequest, RequestOptions.DEFAULT);
        } catch (IOException e) {
            log.error("cleatScroll error:", e);
        }
    }

    public String wildcardBuild(String fieldValue) {
        if (StrUtil.isEmpty(fieldValue)) {
            return null;
        }
        return "*" + fieldValue + "*";
    }


}
