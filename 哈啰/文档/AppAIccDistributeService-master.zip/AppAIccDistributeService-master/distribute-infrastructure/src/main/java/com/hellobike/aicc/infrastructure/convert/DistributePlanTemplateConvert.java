package com.hellobike.aicc.infrastructure.convert;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.distribute.entity.DistributeRuleEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanTemplateEntity;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributePlanTemplatePO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

/**
 * @author fanxiaodongwb230
 * @since 2025-03-07  17:44:42
 */
@Mapper(componentModel = "spring",imports = {BaseJsonUtils.class, DistributeRuleEntity.class})
public interface DistributePlanTemplateConvert {

    @Mappings(
            @Mapping(target = "distributeRuleList", expression = "java(po.getDistributeRule() != null ? BaseJsonUtils.readValues(po.getDistributeRule(), DistributeRuleEntity.class) : null)")
    )
    DistributePlanTemplateEntity convert(DistributePlanTemplatePO po);

    @Mappings(
            @Mapping(target = "distributeRule", expression = "java(entity.getDistributeRuleList() != null ? BaseJsonUtils.writeValue(entity.getDistributeRuleList()) : null)")
    )
    DistributePlanTemplatePO convert(DistributePlanTemplateEntity entity);

    @Mappings({
            @Mapping(target = "list", source = "records"),
            @Mapping(target = "pageNum", source = "current"),
            @Mapping(target = "pageSize", source = "size"),
            @Mapping(target = "totalRecord", source = "total"),
            @Mapping(target = "totalPages", source = "pages")
    })
    PageResult<DistributePlanTemplateEntity> convert(Page<DistributePlanTemplatePO> page);


    List<DistributePlanTemplateEntity> convert(List<DistributePlanTemplatePO> planTemplatePOList);


}