package com.hellobike.aicc.infrastructure.persistence.multi.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 数据密级S2,渠道商原始话单表
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-04-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_supplier_call_dialogue")
public class SupplierCallDialoguePO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id" ,type = IdType.INPUT)
    private Long id;

    /**
     * 数据密级S2,创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,是否删除
     */
    @TableField("is_delete")
    private Integer isDelete;

    /**
     * 数据密级S2,分流平台话单id
     */
    @TableField("call_id")
    private Long callId;

    /**
     * 数据密级S2,分流计划id
     */
    @TableField("distribute_plan_id")
    private Long distributePlanId;

    /**
     * 数据密级S2,供应商话单数据
     */
    @TableField("supplier_call_json")
    private String supplierCallJson;


    public static final String CREATE_TIME = "create_time";

    public static final String UPDATE_TIME = "update_time";

    public static final String IS_DELETE = "is_delete";

    public static final String CALL_ID = "call_id";

    public static final String DISTRIBUTE_PLAN_ID = "distribute_plan_id";

    public static final String SUPPLIER_CALL_JSON = "supplier_call_json";

}
