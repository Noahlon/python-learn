package com.hellobike.aicc.infrastructure.convert;

import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;
import com.hellobike.aicc.infrastructure.persistence.multi.po.UploadRecordPO;
import org.mapstruct.Mapper;

/**
 * @author zhangzhuoqi
 * @since 2025-03-07  17:44:42
 */
@Mapper(componentModel = "spring")
public interface UploadRecordInfConvert {

    UploadRecordEntity toEntity(UploadRecordPO uploadRecordPO);

    UploadRecordPO toPO(UploadRecordEntity uploadRecordEntity);
}
