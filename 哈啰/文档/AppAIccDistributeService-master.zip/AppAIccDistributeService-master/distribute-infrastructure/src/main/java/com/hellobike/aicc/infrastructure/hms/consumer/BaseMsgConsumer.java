package com.hellobike.aicc.infrastructure.hms.consumer;


import com.google.common.util.concurrent.RateLimiter;
import com.hellobike.hms.sdk.consumer.ConsumeMessage;
import com.hellobike.hms.sdk.consumer.MessageListener;
import com.hellobike.hms.sdk.consumer.MsgRetryStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * 消费者基类
 *
 */
@Slf4j
@Component
public abstract class BaseMsgConsumer implements MessageListener, IBizMsgConsumer {
    /**
     * 消息限流器
     */
    private RateLimiter rateLimiter;

    /**
     * 运行状态
     */
    private Boolean isRunning = false;

    /**
     * 是否打印日志
     */
    private Boolean isLog = false;

    /**
     * 是否消费消息
     */
    protected volatile Boolean handlerMsg;

    @Override
    public MsgRetryStatus onMessage(ConsumeMessage msg) {
        //限流
        rateLimiter.acquire();

        String msgContent = new String(msg.getPayload());
        try {
            if (!handlerMsg) {
                if (isLog) {
                    log.info("该消息不处理 topic={}, tag={}, msgId={}, partition={}, offset={}, msg={}",
                            msg.getTopic(), msg.getTag(), msg.getMsgId(), msg.getPartition(), msg.getOffset(), msgContent);
                }
                return MsgRetryStatus.SUCCEED;
            }
            if (isLog) {
                log.info("receive topic={}, tag={}, msgId={}, partition={}, offset={}, msg={}",
                        msg.getTopic(), msg.getTag(), msg.getMsgId(), msg.getPartition(), msg.getOffset(), msgContent);
            }
            // 处理消息
            return msgProcess(msg);
        } catch (Exception ex) {
            log.error("消息处理失败 : {}, msg={}", new String(msg.getPayload()), ex.getMessage(), ex);
            return MsgRetryStatus.RETRY;
        }
    }

    /**
     * 设置限流
     *
     * @param permitsPerSecond 限流数量
     */
    public void setRateLimit(Double permitsPerSecond) {
        if (permitsPerSecond == null) {
            return;
        }
        if (rateLimiter == null) {
            rateLimiter = RateLimiter.create(permitsPerSecond);
        } else {
            rateLimiter.setRate(permitsPerSecond);
        }
    }

    public void setHandlerMsg(Boolean handlerMsg) {
        this.handlerMsg = handlerMsg;
    }

    public Boolean getRunning() {
        return isRunning;
    }

    public void setRunning(Boolean running) {
        isRunning = running;
    }

    /**
     * 获取消费者名称
     *
     * @return 消费者名称
     */
    protected abstract String getConsumerName();

    /**
     * 获取tag
     *
     * @return tag列表
     */
    protected Set<String> getTagList() {
        return null;
    }

    public Boolean getIsLog() {
        return isLog;
    }

    public void setIsLog(Boolean isLog) {
        this.isLog = isLog;
    }
}
