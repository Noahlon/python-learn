package com.hellobike.aicc.infrastructure.es.roster.repository;

import cn.hutool.core.collection.CollectionUtil;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.common.util.DBPartitionUtils;
import com.hellobike.aicc.domain.roster.dto.RosterQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.repo.PlanRosterRepository;
import com.hellobike.aicc.infrastructure.convert.RosterInfConvert;
import com.hellobike.aicc.infrastructure.es.roster.po.PlanRosterESPO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author zhangzhuoqi
 * @since 2025-05-23  14:15:34
 */
@Slf4j
@Component
public class RosterEsSubmit {

    @Resource
    private RosterESRepository rosterESRepository;

    @Resource
    private PlanRosterRepository rosterRepository;

    @Resource
    private RosterInfConvert rosterInfConvert;


    @Retryable(maxAttempts = 3, value = Exception.class, backoff = @Backoff(delay = 1000, multiplier = 1.5))
    public void esSubmitInvoke(List<PlanRosterESPO> rosterESPOList) {
        try {
            List<PlanRosterESPO> finalList = handleQueueInfo(rosterESPOList);
            if (CollectionUtil.isEmpty(finalList)) {
                log.info("提交名单入es，名单为空");
                return;
            }
            rosterESRepository.save(finalList);
        } catch (Exception e) {
            log.error("EsSubTaskSubmit.esSubmitInvoke异常", e);
            throw new RuntimeException("执行同步失败", e);
        }
    }

    @Recover
    public void printErrorLog(Exception e, List<PlanRosterESPO> rosterESPOList) {
        List<Long> idList = rosterESPOList.stream()
                .map(PlanRosterESPO::getId)
                .collect(Collectors.toList());
        log.error("RosterEsSubmit执行同步失败-重试3次：idList:{}", BaseJsonUtils.writeValue(idList), e);
    }

    private List<PlanRosterESPO> handleQueueInfo(List<PlanRosterESPO> rosterESPOList) {
        if (CollectionUtil.isEmpty(rosterESPOList)) {
            return Collections.emptyList();
        }
        List<PlanRosterESPO> finalList = new ArrayList<>();
        //获取数据库最新数据
        Map<String, List<PlanRosterESPO>> rosterMap = rosterESPOList.stream().collect(Collectors.groupingBy(r -> DBPartitionUtils.getRosterPartitionCode(r.getDistributePlanId(), r.getPhoneNum())));
        Map<Long, LocalDateTime> indexMap = rosterESPOList.stream().collect(Collectors.toMap(PlanRosterESPO::getId, PlanRosterESPO::getDistPlanCreateTime, (k1, k2) -> k1));
        rosterMap.forEach((partitionCode, list) -> {
            RosterQueryConditionDTO conditionDTO = new RosterQueryConditionDTO();
            conditionDTO.setIdList(list.stream().map(PlanRosterESPO::getId).collect(Collectors.toList()));
            conditionDTO.setQueryAllField(true);
            List<PlanRosterEntity> rosterEntityList = rosterRepository.queryByPartitionCode(partitionCode, conditionDTO);
            if (CollectionUtil.isNotEmpty(rosterEntityList)) {
                for (PlanRosterEntity planRosterEntity : rosterEntityList) {
                    PlanRosterESPO rosterESPO = rosterInfConvert.entityToES(planRosterEntity);
                    rosterESPO.setDistPlanCreateTime(indexMap.get(rosterESPO.getId()));
                    finalList.add(rosterESPO);
                }
            }
        });
        return finalList;
    }

}
