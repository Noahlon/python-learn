package com.hellobike.aicc.infrastructure.hms.producer;

import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.dto.ChannelSmsPushDTO;
import com.hellobike.hms.sdk.Hms;
import com.hellobike.hms.sdk.common.SimpleMessage;
import com.hellobike.hms.sdk.common.SimpleMessageBuilder;
import com.hellobike.hms.sdk.producer.HmsCallBack;
import com.hellobike.hms.sdk.producer.SendResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


/**
 * 渠道短信记录推送消息生产者
 */
@Service
@Slf4j
public class ChannelSmsRecordMsgProducer {
    private static final String TOPIC = "aicc_channel_sms_callback_topic";

    public void sendMsg(ChannelSmsPushDTO msg) {
        log.info("ChannelSmsRecordMsgProducer.sendMsgKey:{}", msg.getSmsRecordCallBackDTO().getSmsId());
        SimpleMessage message = SimpleMessageBuilder
                .newInstance()
                .buildPaylod(BaseJsonUtils.writeValueAsBytes(msg))
                .buildKey(msg.getSmsRecordCallBackDTO().getSmsId())
                .build();
//        Map<String, String> headers = new HashMap<>();
//        message.setHeaders(headers);
        Hms.sendAsync(TOPIC, message, new HmsCallBack() {
            @Override
            public void onException(Throwable throwable) {
                // 正常情况下，发送不会失败
                log.error("ChannelSmsRecordMsgProducer消息:{}异步发送失败", msg.getSmsRecordCallBackDTO().getSmsId(), throwable);
            }

            @Override
            public void onResult(SendResponse sendResponse) {

            }
        });
    }
}
