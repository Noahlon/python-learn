package com.hellobike.aicc.infrastructure.hms.consumer.roster;

import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.common.service.DingTalkService;
import com.hellobike.aicc.domain.roster.dto.RosterUpdDTO;
import com.hellobike.aicc.infrastructure.es.roster.po.PlanRosterESPO;
import com.hellobike.aicc.infrastructure.es.roster.repository.RosterEsContainer;
import com.hellobike.aicc.infrastructure.hms.consumer.BaseMsgConsumer;
import com.hellobike.hms.sdk.consumer.ConsumeMessage;
import com.hellobike.hms.sdk.consumer.MsgRetryStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-05-24  10:07:06
 */
@Slf4j
@Component
public class RosterUpdConsumer extends BaseMsgConsumer {

    private static final String CONSUMER = "aicc_distribute_roster_topic_local_consumer";

    @Override
    protected String getConsumerName() {
        return CONSUMER;
    }

    @Resource
    private RosterEsContainer rosterEsContainer;

    @Resource
    private DingTalkService dingTalkService;

    @Override
    public MsgRetryStatus msgProcess(ConsumeMessage mqMessage) {
        try {
            //log.info("名单更新消息:{}", mqMessage);
            String msgBody = new String(mqMessage.getPayload());
            RosterUpdDTO rosterUpdDTO = BaseJsonUtils.readValue(msgBody, RosterUpdDTO.class);
            if (Objects.isNull(rosterUpdDTO)) {
                log.error("名单更新消息，body is null");
                return MsgRetryStatus.SUCCEED;
            }
            PlanRosterESPO planRosterESPO = new PlanRosterESPO();
            planRosterESPO.setId(Long.valueOf(rosterUpdDTO.getId()));
            planRosterESPO.setDistributePlanId(Long.valueOf(rosterUpdDTO.getPlanId()));
            planRosterESPO.setPhoneNum(rosterUpdDTO.getPhoneNum());
            planRosterESPO.setDistPlanCreateTime(DateUtils.toLocalDateTime(rosterUpdDTO.getPlanCreateTime()));
            rosterEsContainer.addRoster(Collections.singletonList(planRosterESPO), false);
        } catch (Exception e) {
            log.error("消费名单消息异常,e:", e);
            dingTalkService.sendRosterFailedAlert(mqMessage.getMsgId());
        }
        return MsgRetryStatus.SUCCEED;
    }
}
