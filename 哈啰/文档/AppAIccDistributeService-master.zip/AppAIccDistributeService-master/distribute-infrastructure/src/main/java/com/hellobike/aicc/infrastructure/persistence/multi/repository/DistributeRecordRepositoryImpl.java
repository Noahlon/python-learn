package com.hellobike.aicc.infrastructure.persistence.multi.repository;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DeleteEnum;
import com.hellobike.aicc.common.enums.DistributeRecordTypeEnum;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.domain.roster.dto.DistributeRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.DistributeRecordEntity;
import com.hellobike.aicc.domain.roster.repo.DistributeRecordRepository;
import com.hellobike.aicc.infrastructure.convert.DistributeRecordInfConvert;
import com.hellobike.aicc.infrastructure.persistence.multi.mapper.DistributeRecordMapper;
import com.hellobike.aicc.infrastructure.persistence.multi.po.DistributeRecordPO;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * <p>
 * 数据密级S2,下发记录 服务实现类
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Service
public class DistributeRecordRepositoryImpl extends ServiceImpl<DistributeRecordMapper, DistributeRecordPO> implements DistributeRecordRepository {

    @Resource
    private DistributeRecordInfConvert distributeRecordInfConvert;

    @Override
    public void addRecord(DistributeRecordEntity distributeRecordEntity) {
        checkPartitionKey(distributeRecordEntity.getDistributePlanId());
        AssertUtils.notNull(distributeRecordEntity.getId(), "下发记录id不能为空");
        DistributeRecordPO po = distributeRecordInfConvert.toPO(distributeRecordEntity);
        save(po);

    }

    @Override
    public void batchAddRecord(List<DistributeRecordEntity> distributeRecordEntityList) {
        if (CollectionUtil.isEmpty(distributeRecordEntityList)){
            return;
        }
        for (DistributeRecordEntity distributeRecordEntity : distributeRecordEntityList) {
            checkPartitionKey(distributeRecordEntity.getDistributePlanId());
            AssertUtils.notNull(distributeRecordEntity.getId(), "下发记录id不能为空");
        }
        List<DistributeRecordPO> poList = distributeRecordInfConvert.toPOList(distributeRecordEntityList);
        saveBatch(poList);
    }

    @Override
    public void updateRecordById(DistributeRecordEntity distributeRecordEntity) {
        checkPartitionKey(distributeRecordEntity.getDistributePlanId());
        AssertUtils.notNull(distributeRecordEntity.getId(), "上传记录id不能为空");
        DistributeRecordPO po = distributeRecordInfConvert.toPO(distributeRecordEntity);
        LambdaUpdateWrapper<DistributeRecordPO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(DistributeRecordPO::getId, distributeRecordEntity.getId())
                .eq(DistributeRecordPO::getDistributePlanId, distributeRecordEntity.getDistributePlanId());
        updateWrapper.set(Objects.nonNull(po.getDistributeStatus()), DistributeRecordPO::getDistributeStatus, po.getDistributeStatus());
        updateWrapper.set(Objects.nonNull(po.getDistributeTime()), DistributeRecordPO::getDistributeTime, po.getDistributeTime());
        updateWrapper.setSql(Objects.nonNull(po.getDistributeCount()), " distribute_count = distribute_count + " + distributeRecordEntity.getDistributeCount());
        updateWrapper.setSql(Objects.nonNull(po.getSuccessCount()), " success_count = success_count + " + distributeRecordEntity.getSuccessCount());

        update(updateWrapper);
    }

    @Override
    public void updateRecordType(Long uploadRecordId, Long distributePlanId, DistributeRecordTypeEnum recordType) {
        if (Objects.isNull(recordType) || Objects.isNull(uploadRecordId) || Objects.isNull(distributePlanId)) {
            return;
        }
        LambdaUpdateWrapper<DistributeRecordPO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.set(DistributeRecordPO::getDistributeType, recordType.getCode());
        updateWrapper.eq(DistributeRecordPO::getDistributePlanId, distributePlanId);
        updateWrapper.eq(DistributeRecordPO::getUploadRecordId, uploadRecordId);
        updateWrapper.eq(DistributeRecordPO::getIsDelete, DeleteEnum.NO.getCode());
        update(updateWrapper);

    }

    @Override
    public DistributeRecordEntity getRecordById(Long id, Long distributePlanId) {
        checkPartitionKey(distributePlanId);
        LambdaQueryWrapper<DistributeRecordPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper
                .eq(DistributeRecordPO::getId, id)
                .eq(DistributeRecordPO::getDistributePlanId, distributePlanId)
                .eq(DistributeRecordPO::getIsDelete, DeleteEnum.NO.getCode());
        DistributeRecordPO po = getOne(queryWrapper);
        return distributeRecordInfConvert.toEntity(po);

    }

    @Override
    public List<DistributeRecordEntity> queryByCondition(DistributeRecordQueryConditionDTO conditionDTO) {
        if (Objects.isNull(conditionDTO)) {
            return Collections.emptyList();
        }
        checkPartitionKey(conditionDTO.getDistributePlanId());
        LambdaQueryWrapper<DistributeRecordPO> queryWrapper = this.buildQueryWrapperByCondition(conditionDTO);
        List<DistributeRecordPO> poList = this.list(queryWrapper);
        if (CollectionUtil.isEmpty(poList)) {
            return Collections.emptyList();
        }
        List<DistributeRecordEntity> entityList = poList.stream().map(distributeRecordInfConvert::toEntity).collect(Collectors.toList());
        return entityList;
    }

    @Override
    public PageResult<DistributeRecordEntity> pageByCondition(DistributeRecordQueryConditionDTO conditionDTO, Integer pageNum, Integer pageSize) {
        if (Objects.isNull(conditionDTO)) {
            return PageResult.getEmptyPage(pageNum, pageSize);
        }
        checkPartitionKey(conditionDTO.getDistributePlanId());
        if (Objects.isNull(pageNum) || Objects.isNull(pageSize)) {
            return PageResult.getEmptyPage();
        }
        LambdaQueryWrapper<DistributeRecordPO> queryWrapper = buildQueryWrapperByCondition(conditionDTO);
        //下发时间倒序
        queryWrapper.orderByDesc(DistributeRecordPO::getDistributeTime);
        Page<DistributeRecordPO> page = new Page<>(pageNum, pageSize);
        this.page(page, queryWrapper);
        List<DistributeRecordPO> records = page.getRecords();
        if (CollectionUtil.isEmpty(records)) {
            return PageResult.getEmptyPage(pageNum, pageSize);
        }
        List<DistributeRecordEntity> entityList = page.getRecords().stream().map(distributeRecordInfConvert::toEntity).collect(Collectors.toList());
        PageResult<DistributeRecordEntity> pageResult = new PageResult<>((int) page.getCurrent(), (int) page.getSize(), page.getTotal(), entityList);
        return pageResult;
    }

    private LambdaQueryWrapper<DistributeRecordPO> buildQueryWrapperByCondition(DistributeRecordQueryConditionDTO conditionDTO) {
        LambdaQueryWrapper<DistributeRecordPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper
                .eq(DistributeRecordPO::getDistributePlanId, conditionDTO.getDistributePlanId())
                .eq(Objects.nonNull(conditionDTO.getId()), DistributeRecordPO::getId, conditionDTO.getId())
                .eq(Objects.nonNull(conditionDTO.getDistributeStatus()), DistributeRecordPO::getDistributeStatus, conditionDTO.getDistributeStatus())
                .eq(Objects.nonNull(conditionDTO.getDistributeType()), DistributeRecordPO::getDistributeType, conditionDTO.getDistributeType())
                .eq(Objects.nonNull(conditionDTO.getChannelTaskId()), DistributeRecordPO::getChannelTaskId, conditionDTO.getChannelTaskId())
                .eq(StrUtil.isNotBlank(conditionDTO.getSupplierTaskId()), DistributeRecordPO::getSupplierTaskId, conditionDTO.getSupplierTaskId())
                .like(StrUtil.isNotBlank(conditionDTO.getSupplierTaskName()), DistributeRecordPO::getSupplierTaskName, conditionDTO.getSupplierTaskName())
                .eq(Objects.nonNull(conditionDTO.getChannelId()), DistributeRecordPO::getChannelId, conditionDTO.getChannelId())
                .eq(Objects.nonNull(conditionDTO.getUploadRecordId()), DistributeRecordPO::getUploadRecordId, conditionDTO.getUploadRecordId())
                .eq(Objects.nonNull(conditionDTO.getIsDelete()), DistributeRecordPO::getIsDelete, conditionDTO.getIsDelete())
                .ge(Objects.nonNull(conditionDTO.getStartDistributeTime()), DistributeRecordPO::getDistributeTime, conditionDTO.getStartDistributeTime())
                .le(Objects.nonNull(conditionDTO.getEndDistributeTime()), DistributeRecordPO::getDistributeTime, conditionDTO.getEndDistributeTime())
                .ge(Objects.nonNull(conditionDTO.getStartCreateTime()), DistributeRecordPO::getCreateTime, conditionDTO.getStartCreateTime())
                .le(Objects.nonNull(conditionDTO.getEndCreateTime()), DistributeRecordPO::getCreateTime, conditionDTO.getEndCreateTime());
        if (Objects.isNull(conditionDTO.getIsDelete())) {
            queryWrapper.eq(DistributeRecordPO::getIsDelete, DeleteEnum.NO.getCode());
        }
        return queryWrapper;
    }

    private void checkPartitionKey(Long distributePlanId) {
        AssertUtils.notNull(distributePlanId, "分流计划id不能为空");
    }
}
