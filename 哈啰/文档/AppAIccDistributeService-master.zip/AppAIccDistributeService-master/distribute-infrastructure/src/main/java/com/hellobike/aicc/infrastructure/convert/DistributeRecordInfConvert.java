package com.hellobike.aicc.infrastructure.convert;

import com.hellobike.aicc.domain.roster.entity.DistributeRecordEntity;
import com.hellobike.aicc.infrastructure.persistence.multi.po.DistributeRecordPO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-10  16:45:54
 */
@Mapper(componentModel = "spring")
public interface DistributeRecordInfConvert {

    DistributeRecordPO toPO(DistributeRecordEntity distributeRecordEntity);

    DistributeRecordEntity toEntity(DistributeRecordPO distributeRecordPO);

    List<DistributeRecordPO> toPOList(List<DistributeRecordEntity> distributeRecordEntityList);
}
