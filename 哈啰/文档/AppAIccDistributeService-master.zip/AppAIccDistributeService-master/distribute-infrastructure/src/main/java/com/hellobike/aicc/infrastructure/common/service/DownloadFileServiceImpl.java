package com.hellobike.aicc.infrastructure.common.service;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.IdUtil;
import com.hellobike.aicc.common.util.FileUtils;
import com.hellobike.aicc.domain.common.service.DownloadFileService;
import com.hellobike.aicc.infrastructure.gateway.http.HttpClient;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * 下载文件到本地
 *
 * @author panlongqian
 * @since 2025-03-18
 */
@Service
@Slf4j
public class DownloadFileServiceImpl implements DownloadFileService {
    @Resource
    private HttpClient httpClient;

    @Override
    public String downloadFileToLocal(String fileUrl, String fileName) {
        if (StringUtils.isBlank(fileUrl)) {
            return null;
        }

        return downloadFile(fileUrl, fileName);
    }

    private String downloadFile(String fileUrl, String fileName) {
        String filePath = FileUtils.getTmpDirPath() + IdUtil.fastSimpleUUID() +FileUtils.getFileExtension(fileName);
        try {
            byte[] fileBytes = httpClient.getInputStreamFromFile(fileUrl);
            FileUtil.writeBytes(fileBytes, filePath);
            log.info("下载文件到：{}", filePath);
            return filePath;
        } catch (Exception e) {
            log.error("文件下载失败: {}", fileUrl, e);
            return null;
        }
    }


}
