package com.hellobike.aicc.infrastructure.gateway.channel;

import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.type.TypeReference;
import com.hellobike.aicc.common.enums.OpenApiCallBackTagEnum;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.dto.ChannelTaskCreateDTO;
import com.hellobike.aicc.domain.channel.entity.ChannelEntity;
import com.hellobike.aicc.domain.channel.entity.ChannelTaskEntity;
import com.hellobike.aicc.domain.channel.facade.OpenApiFacade;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.channel.factory.ChannelInfo;
import com.hellobike.aicc.domain.common.service.DingTalkService;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterDTO;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterResultDTO;
import com.hellobike.aicc.domain.roster.dto.ExtChannelImportRosterDTO;
import com.hellobike.aicc.domain.roster.dto.ExtPlanRosterDTO;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.infrastructure.gateway.dto.OpenApiImportRosterResDTO;
import com.hellobike.base.model.Proto;
import com.hellobike.openapi.iface.OpenApiCallBackIface;
import com.hellobike.openapi.iface.dto.CallbackExecuteReqDTO;
import com.hellobike.openapi.iface.dto.CallbackExecuteResDTO;
import com.hellobike.soa.starter.spring.annotation.Reference;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-05-12  15:46:20
 */
@Service
@Slf4j
public class OpenApiFacadeImpl implements OpenApiFacade {

    @Reference
    private OpenApiCallBackIface openApiCallBackIface;

    @Resource
    private DingTalkService dingTalkService;

    @Override
    public List<ChannelEntity.ChannelTemplateEntity> queryTemplateList(String appKey) {
        try {
            Map<String, Object> params = new HashMap<>(1);
            params.put("appKey", appKey);
            Proto<CallbackExecuteResDTO> resProto = executeCallback(OpenApiCallBackTagEnum.TEMPLATE_LIST, appKey, params);
            if (callBackIsSuccess(resProto)) {
                CallbackExecuteResDTO resDTO = resProto.getData();
                JSONObject resData = resDTO.getData();
                if (resData == null) {
                    log.info("查询渠道商模板接口报错, appKey: {}", appKey);
                    return Collections.emptyList();
                }
                JSONArray data = resData.getJSONArray("data");
                if (CollectionUtils.isEmpty(data)) {
                    log.info("查询渠道商模板列表为空, appKey: {}", appKey);
                    return Collections.emptyList();
                }
                return BaseJsonUtils.readValue(data.toJSONString(), new TypeReference<List<ChannelEntity.ChannelTemplateEntity>>() {
                });
            } else {
                log.info("查询渠道商模板信息失败, appKey: {}, 错误信息: {}", appKey, resProto != null ? resProto.getMsg() : "未知错误");
            }
        } catch (Exception e) {
            log.error("查询渠道商模板接口异常,e:", e);
        }
        return Collections.emptyList();
    }

    @Override
    public ChannelTaskEntity createTask(ChannelTaskCreateDTO channelTaskCreateDTO) {
        log.info("创建渠道任务,req:{}", BaseJsonUtils.writeValue(channelTaskCreateDTO));
        try {
            Map<String, Object> params = new HashMap<>(2);
            params.put("appKey", channelTaskCreateDTO.getAppKey());
            params.put("templateId", channelTaskCreateDTO.getTaskTemplateId());
            Proto<CallbackExecuteResDTO> resProto = executeCallback(OpenApiCallBackTagEnum.CREATE_TASK, channelTaskCreateDTO.getAppKey(), params);
            if (callBackIsSuccess(resProto)) {
                CallbackExecuteResDTO resDTO = resProto.getData();
                JSONObject resData = resDTO.getData();
                if (Objects.isNull(resData)) {
                    log.info("调用渠道商创建任务接口失败, appKey: {}", channelTaskCreateDTO.getAppKey());
                    return null;
                }
                JSONObject data = resData.getJSONObject("data");
                if (Objects.isNull(data)) {
                    log.info("渠道商创建任务失败, appKey: {}", channelTaskCreateDTO.getAppKey());
                    return null;
                }
                Object taskId = data.get("taskId");
                Object taskName = data.get("taskName");
                if (Objects.nonNull(taskId) && Objects.nonNull(taskName)) {
                    ChannelTaskEntity channelTaskEntity = new ChannelTaskEntity();
                    channelTaskEntity.setChannelTaskId(String.valueOf(taskId));
                    channelTaskEntity.setChannelTaskName(String.valueOf(taskName));
                    return channelTaskEntity;
                }
                return null;
            } else {
                log.error("渠道商创建任务返回失败结果, appKey: {}, 错误信息: {}", channelTaskCreateDTO.getAppKey(), resProto != null ? resProto.getMsg() : "未知错误");
            }
            return null;
        } catch (Exception e) {
            log.error("渠道商创建任务异常，e:", e);
            return null;
        }
    }

    @Override
    public ChannelImportRosterResultDTO importRoster(ChannelImportRosterDTO channelImportRosterDTO) {
        ChannelImportRosterResultDTO resultDTO = new ChannelImportRosterResultDTO(0, 0, false);
        int failCount = 0;
        int totalCount = channelImportRosterDTO.getRosterEntityList().size();
        try {
            ExtChannelImportRosterDTO rosterDTO = channelRosterApiConvert(channelImportRosterDTO);
            Map<String, Object> params = BaseJsonUtils.readValue(BaseJsonUtils.writeValue(rosterDTO), new TypeReference<Map<String, Object>>() {
            });
            Proto<CallbackExecuteResDTO> resProto = executeCallback(OpenApiCallBackTagEnum.IMPORT_ROSTER, rosterDTO.getAppKey(), params);

            if (callBackIsSuccess(resProto)) {
                CallbackExecuteResDTO resDTO = resProto.getData();
                JSONObject resData = resDTO.getData();
                if (Objects.isNull(resData)) {
                    log.info("调用渠道商上传名单接口失败, appKey: {}", rosterDTO.getAppKey());
                    resultDTO.setAllFail(true);
                    resultDTO.setFailCount(totalCount);
                    return resultDTO;
                }
                JSONObject data = resData.getJSONObject("data");
                if (Objects.isNull(data)) {
                    log.info("渠道商上传名单失败, appKey: {}", rosterDTO.getAppKey());
                    resultDTO.setAllFail(true);
                    resultDTO.setFailCount(totalCount);
                    return resultDTO;
                }
                OpenApiImportRosterResDTO rosterResDTO = BaseJsonUtils.readValue(data.toJSONString(), new TypeReference<OpenApiImportRosterResDTO>() {
                });
                if (Objects.nonNull(rosterResDTO.getDuplicationCount())) {
                    failCount += rosterResDTO.getDuplicationCount();
                }
                if (Objects.nonNull(rosterResDTO.getFailCount())) {
                    failCount += rosterResDTO.getFailCount();
                }
                if (totalCount == failCount) {
                    resultDTO.setAllFail(true);
                    resultDTO.setFailCount(failCount);
                    return resultDTO;
                }
                resultDTO.setSuccessCount(rosterResDTO.getSuccessCount());
                resultDTO.setFailCount(failCount);
                return resultDTO;
            } else {
                log.info("上传名单到渠道商返回失败结果, appKey: {}, 错误信息: {}", rosterDTO.getAppKey(), resProto != null ? resProto.getMsg() : "未知错误");
                resultDTO.setAllFail(true);
                resultDTO.setFailCount(totalCount);
                return resultDTO;
            }
        } catch (Exception e) {
            log.error("上传渠道商名单异常,e:", e);
            return new ChannelImportRosterResultDTO(0, totalCount, true);
        }

    }

    /**
     * 执行回调请求的通用方法
     *
     * @param callBackTag 回调标签
     * @param appKey      应用密钥
     * @param params      参数
     * @return 回调结果
     */
    private Proto<CallbackExecuteResDTO> executeCallback(OpenApiCallBackTagEnum callBackTag, String appKey, Map<String, Object> params) {
        CallbackExecuteReqDTO callbackExecuteReqDTO = new CallbackExecuteReqDTO();
        callbackExecuteReqDTO.setBizType(BIZ_TYPE);
        callbackExecuteReqDTO.setCallBackTag(callBackTag.getCallBackTag());
        callbackExecuteReqDTO.setAppKey(appKey);
        callbackExecuteReqDTO.setCallBackContent(new JSONObject(params));
        Proto<CallbackExecuteResDTO> proto = doExecute(callbackExecuteReqDTO);
        if (callBackIsSuccess(proto)) {
            return proto;
        }
        log.error("调用渠道商接口不成功,proto:{}", BaseJsonUtils.writeValue(proto));
        ChannelInfo channel = ChannelFactory.getChannel(appKey);
        //进行失败重试
        int rCount = 0;
        if (Objects.nonNull(channel) && Objects.nonNull(channel.getRetryCount()) && channel.getRetryCount() > 0) {
            log.info("调用渠道商接口不成功进行重试,count:{}", channel.getRetryCount());
            do {
                rCount++;
                proto = doExecute(callbackExecuteReqDTO);
                log.info("重试调用渠道商接口,第{}次", rCount);
                if (callBackIsSuccess(proto)) {
                    return proto;
                }
                ThreadUtil.sleep(100);
            } while (rCount < channel.getRetryCount());

            log.error("调用渠道商接口重试{}次失败,callBackTag:{}", rCount, proto);
            dingTalkService.sendChannelApiFail(channel.getChannelName(), callBackTag.getDesc(), proto != null ? BaseJsonUtils.writeValue(proto) : "未知错误");
        }

        return proto;
    }

    private Proto<CallbackExecuteResDTO> doExecute(CallbackExecuteReqDTO callbackExecuteReqDTO) {
        try {
            Proto<CallbackExecuteResDTO> proto = openApiCallBackIface.callBackExecute(callbackExecuteReqDTO);
            log.info("调用渠道商{}返回数据:{}", callbackExecuteReqDTO.getAppKey(), BaseJsonUtils.writeValue(proto));
            return proto;
        } catch (Exception e) {
            log.error("调用openApi平台失败, callBackTag: {}, appKey: {}", callbackExecuteReqDTO.getCallBackTag(), callbackExecuteReqDTO.getAppKey(), e);
            return null;
        }
    }

    private ExtChannelImportRosterDTO channelRosterApiConvert(ChannelImportRosterDTO rosterDTO) {
        ExtChannelImportRosterDTO extRosterDTO = new ExtChannelImportRosterDTO();
        extRosterDTO.setAppKey(rosterDTO.getAppKey());
        extRosterDTO.setSupplierTaskId(rosterDTO.getSupplierTaskId());
        extRosterDTO.setRosterType(rosterDTO.getRosterType());
        List<ExtPlanRosterDTO> extPlanRosterDTOList = new ArrayList<>();
        for (PlanRosterEntity entity : rosterDTO.getRosterEntityList()) {
            ExtPlanRosterDTO extPlanRosterDTO = new ExtPlanRosterDTO();
            extPlanRosterDTO.setPhone(entity.getPhoneNum());
            extPlanRosterDTO.setName(entity.getCustomerName());
            extPlanRosterDTO.setRosterKey(entity.getRosterKey());
            if (StrUtil.isNotBlank(entity.getVariableInfo())) {
                Map<?, ?> map = BaseJsonUtils.readValue(entity.getVariableInfo(), Map.class);
                if (Objects.nonNull(map)) {
                    Map<String, String> variableInfos = new HashMap<>();
                    map.forEach((k, v) -> variableInfos.put(String.valueOf(k), String.valueOf(v)));
                    extPlanRosterDTO.setVariableInfos(variableInfos);
                }
            }
            extPlanRosterDTOList.add(extPlanRosterDTO);
        }
        Integer channelId = rosterDTO.getRosterEntityList().get(0).getChannelId();
        //云动之外的渠道商名单集合采用json字符串
        ChannelInfo yunDongChannel = ChannelFactory.getYunDongChannel();
        if (Objects.nonNull(yunDongChannel) && Objects.equals(channelId, yunDongChannel.getChannelId())) {
            extRosterDTO.setRosterList(extPlanRosterDTOList);
        } else {
            extRosterDTO.setRosterListJson(BaseJsonUtils.writeValue(extPlanRosterDTOList));
        }

        return extRosterDTO;
    }

    private boolean callBackIsSuccess(Proto<CallbackExecuteResDTO> proto) {
        return proto != null && proto.ok(null) && proto.getData() != null && Boolean.TRUE.equals(proto.getData().getSuccess());
    }
}
