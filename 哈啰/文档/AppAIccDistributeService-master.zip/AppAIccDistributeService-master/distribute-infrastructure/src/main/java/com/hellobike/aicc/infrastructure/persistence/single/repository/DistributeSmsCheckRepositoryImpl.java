package com.hellobike.aicc.infrastructure.persistence.single.repository;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.hellobike.aicc.common.enums.DeleteEnum;
import com.hellobike.aicc.domain.smsrecord.dto.SmsCheckStatusQryConditionDTO;
import com.hellobike.aicc.domain.smsrecord.entity.SmsCheckEntity;
import com.hellobike.aicc.domain.smsrecord.repo.SmsCheckRepository;
import com.hellobike.aicc.infrastructure.convert.SmsRecordInfConvert;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributeSmsCheckPO;
import com.hellobike.aicc.infrastructure.persistence.single.mapper.DistributeSmsCheckMapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * 数据密级L2,短信状态检查表 服务实现类
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-06-10
 */
@Service
public class DistributeSmsCheckRepositoryImpl extends ServiceImpl<DistributeSmsCheckMapper, DistributeSmsCheckPO> implements SmsCheckRepository {

    @Resource
    private SmsRecordInfConvert convert;

    @Override
    public boolean save(SmsCheckEntity entity) {
        DistributeSmsCheckPO po = convert.convertCheckPO(entity);
        return save(po);
    }

    @Override
    public List<SmsCheckEntity> queryByCondition(SmsCheckStatusQryConditionDTO condition) {
        LambdaQueryWrapper<DistributeSmsCheckPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper
                .ge(Objects.nonNull(condition.getReceiveResultTimeStart()), DistributeSmsCheckPO::getReceiveResultTime, condition.getReceiveResultTimeStart())
                .le(Objects.nonNull(condition.getReceiveResultTimeEnd()), DistributeSmsCheckPO::getReceiveResultTime, condition.getReceiveResultTimeEnd())
                .eq(Objects.nonNull(condition.getHandleStatus()), DistributeSmsCheckPO::getHandleStatus, condition.getHandleStatus())
                .eq(Objects.nonNull(condition.getHandleSendResult()), DistributeSmsCheckPO::getHandleSendResult, condition.getHandleSendResult())
                .eq(DistributeSmsCheckPO::getIsDelete, DeleteEnum.NO.getCode());
        List<DistributeSmsCheckPO> list = list(queryWrapper);
        if (CollectionUtil.isEmpty(list)){
            return Collections.emptyList();
        }
        return convert.convertCheckEntity(list);
    }

    @Override
    public void updateById(SmsCheckEntity smsCheckEntity) {
        DistributeSmsCheckPO po = convert.convertCheckPO(smsCheckEntity);
        updateById(po);
    }
}
