package com.hellobike.aicc.infrastructure.common.service;

import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.base.hammer.generator.IdGeneratorManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class IdGeneratorServiceImpl implements IdGeneratorService {

    @Autowired
    @Qualifier("longIdGenerator")
    private IdGeneratorManager smsLongIdGenerator;

    @Override
    public Long getLongId() {
        return smsLongIdGenerator.nextId();
    }

    @Override
    public String getStringId() {
        return String.valueOf(getLongId());
    }
}
