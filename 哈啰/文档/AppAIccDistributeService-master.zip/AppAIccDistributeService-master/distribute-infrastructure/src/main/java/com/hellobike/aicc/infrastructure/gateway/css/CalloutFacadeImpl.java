package com.hellobike.aicc.infrastructure.gateway.css;

import cn.hutool.core.collection.CollectionUtil;
import com.google.api.client.util.Lists;
import com.hellobike.aicc.common.enums.SpeakerEnum;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.dialogue.entity.DialogueSpeakEntity;
import com.hellobike.aicc.domain.distribute.facade.CssCalloutFacade;
import com.hellobike.css.ai.api.base.Result;
import com.hellobike.css.ai.api.iface.cc.CalloutIface;
import com.hellobike.css.ai.api.model.cc.CallSpeakInfoReqDTO;
import com.hellobike.css.ai.api.model.cc.CallSpeakInfoResDTO;
import com.hellobike.soa.starter.spring.annotation.Reference;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author zhangzhuoqi
 * @since 2025-04-22  14:43:13
 */
@Service
@Slf4j
public class CalloutFacadeImpl implements CssCalloutFacade {

    @Reference
    private CalloutIface calloutIface;

    public List<DialogueSpeakEntity> querySpeakList(String bizReqId) {
        CallSpeakInfoReqDTO reqDTO = new CallSpeakInfoReqDTO();
        reqDTO.setBizReqId(bizReqId);
        try {
            Result<List<CallSpeakInfoResDTO>> result = calloutIface.queryCallSpeakInfo(reqDTO);
            if (Objects.isNull(result) || !result.isSuccess()) {
                log.error("查询css话单对话内容失败bizReqId:{},res:{}",bizReqId, BaseJsonUtils.writeValue(result));
                return Lists.newArrayList();
            }
            List<CallSpeakInfoResDTO> list = result.getData();
            if (CollectionUtil.isEmpty(list)){
                log.info("对话内容为空,bizReqId:{}",bizReqId);
                return Lists.newArrayList();
            }
            List<DialogueSpeakEntity> speakEntityList = list.stream().map(s -> {
                DialogueSpeakEntity entity = new DialogueSpeakEntity();
                entity.setSpeakId(s.getSpeakId());
                SpeakerEnum speakerEnum = SpeakerEnum.getByCode(s.getSpeaker());
                if (Objects.isNull(speakerEnum)) {
                    log.error("说话方枚举错误,speaker:{},bizReqId:{}", s.getSpeaker(), bizReqId);
                    return null;
                }
                entity.setSpeaker(speakerEnum.getCode());
                entity.setSpeakContent(s.getSpeakContent());
                entity.setSpeakTime(s.getSpeakTime());
                return entity;
            }).filter(Objects::nonNull).collect(Collectors.toList());
            return speakEntityList;
        }catch (Exception e){
            log.error("查询css话单对话内容异常bizReqId:{},e:",bizReqId,e);
            return Lists.newArrayList();
        }
    }
}
