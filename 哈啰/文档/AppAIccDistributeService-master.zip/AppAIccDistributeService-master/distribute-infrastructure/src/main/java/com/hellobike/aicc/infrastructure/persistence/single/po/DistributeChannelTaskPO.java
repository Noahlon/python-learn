package com.hellobike.aicc.infrastructure.persistence.single.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 数据密级S2,分流渠道任务表
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_distribute_channel_task")
public class DistributeChannelTaskPO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id" ,type = IdType.INPUT)
    private Long id;

    /**
     * 数据密级S2,分流计划id
     */
    @TableField("distribute_plan_id")
    private Long distributePlanId;

    /**
     * 数据密级S2,渠道id
     */
    @TableField("channel_id")
    private String channelId;

    /**
     * 数据密级S2,渠道名称
     */
    @TableField("channel_name")
    private String channelName;

    /**
     * 数据密级S2,三方任务id
     */
    @TableField("supplier_task_id")
    private String supplierTaskId;

    /**
     * 数据密级S2,三方任务名称
     */
    @TableField("supplier_task_name")
    private String supplierTaskName;

    /**
     * 数据密级S2,三方任务模板id
     */
    @TableField("supplier_task_template_id")
    private String supplierTaskTemplateId;

    /**
     * 三方任务模板名称
     */
    @TableField("supplier_task_template_name")
    private String supplierTaskTemplateName;

    /**
     * 数据密级S2,下发总数据量
     */
    @TableField("sent_total_num")
    private Long sentTotalNum;

    /**
     * 数据密级S2,下发成功数据量
     */
    @TableField("sent_success_num")
    private Long sentSuccessNum;

    /**
     * 数据密级S2,最近下发时间
     */
    @TableField("latest_sent_time")
    private LocalDateTime latestSentTime;

    /**
     * 数据密级S2,创建人
     */
    @TableField("creator")
    private String creator;

    /**
     * 数据密级S2,任务状态，1-任务创建成功、2-任务尚未创建、0-任务创建失败
     */
    @TableField("task_status")
    private Integer taskStatus;

    /**
     * 数据密级S2,创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,逻辑删除
     */
    @TableField("is_delete")
    private Integer isDelete;


    public static final String DISTRIBUTE_PLAN_ID = "distribute_plan_id";

    public static final String CHANNEL_ID = "channel_id";

    public static final String CHANNEL_NAME = "channel_name";

    public static final String SUPPLIER_TASK_ID = "supplier_task_id";

    public static final String SUPPLIER_TASK_NAME = "supplier_task_name";

    public static final String SUPPLIER_TASK_TEMPLATE_ID = "supplier_task_template_id";

    public static final String SENT_TOTAL_NUM = "sent_total_num";

    public static final String SENT_SUCCESS_NUM = "sent_success_num";

    public static final String LATEST_SENT_TIME = "latest_using_time";

    public static final String CREATOR = "creator";

    public static final String TASK_STATUS = "task_status";

    public static final String CREATE_TIME = "create_time";

    public static final String UPDATE_TIME = "update_time";

    public static final String IS_DELETE = "is_delete";

}
