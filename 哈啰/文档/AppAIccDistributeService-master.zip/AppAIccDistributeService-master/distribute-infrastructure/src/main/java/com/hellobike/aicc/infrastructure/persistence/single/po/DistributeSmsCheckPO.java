package com.hellobike.aicc.infrastructure.persistence.single.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 数据密级L2,短信状态检查表
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-06-10
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_distribute_sms_check")
public class DistributeSmsCheckPO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id" ,type = IdType.INPUT)
    private Long id;

    /**
     * 数据密级L2,短信id
     */
    @TableField("sms_id")
    private Long smsId;

    /**
     * 数据密级L2,手机号md5
     */
    @TableField("phone_number_md5")
    private String phoneNumberMd5;

    /**
     * 数据密级L2,分流计划id
     */
    @TableField("distribute_plan_id")
    private Long distributePlanId;

    /**
     * 数据密级L2,收到短信结果时间
     */
    @TableField("receive_result_time")
    private LocalDateTime receiveResultTime;

    /**
     * 数据密级L2,处理状态 0-未处理 1-已处理
     */
    @TableField("handle_status")
    private Integer handleStatus;

    /**
     * 数据密级L2,处理结果描述
     */
    @TableField("handle_result_desc")
    private String handleResultDesc;

    /**
     * 数据密级L2,待处理的短信发送结果
     */
    @TableField("handle_send_result")
    private Integer handleSendResult;

    /**
     * 数据密级L2,创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 数据密级L2,最近更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 数据密级L2,是否删除
     */
    @TableField("is_delete")
    private Integer isDelete;


    public static final String SMS_ID = "sms_id";

    public static final String PHONE_NUMBER_MD5 = "phone_number_md5";

    public static final String DISTRIBUTE_PLAN_ID = "distribute_plan_id";

    public static final String RECEIVE_RESULT_TIME = "receive_result_time";

    public static final String HANDLE_STATUS = "handle_status";

    public static final String HANDLE_RESULT_DESC = "handle_result_desc";

    public static final String HANDLE_SEND_RESULT = "handle_send_result";

    public static final String CREATE_TIME = "create_time";

    public static final String UPDATE_TIME = "update_time";

    public static final String IS_DELETE = "is_delete";

}
