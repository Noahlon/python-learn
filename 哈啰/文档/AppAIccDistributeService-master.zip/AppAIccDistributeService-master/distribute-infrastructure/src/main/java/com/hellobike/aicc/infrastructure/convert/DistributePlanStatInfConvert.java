package com.hellobike.aicc.infrastructure.convert;

import com.hellobike.aicc.domain.distribute.entity.DistributePlanStatEntity;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributePlanStatPO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-05-27  15:23:42
 */
@Mapper(componentModel = "spring")
public interface DistributePlanStatInfConvert {

    DistributePlanStatEntity toEntity(DistributePlanStatPO po);

    List<DistributePlanStatEntity> toEntity(List<DistributePlanStatPO> poList);

    DistributePlanStatPO toPO(DistributePlanStatEntity entity);

    List<DistributePlanStatPO> toPO(List<DistributePlanStatEntity> entityList);
}
