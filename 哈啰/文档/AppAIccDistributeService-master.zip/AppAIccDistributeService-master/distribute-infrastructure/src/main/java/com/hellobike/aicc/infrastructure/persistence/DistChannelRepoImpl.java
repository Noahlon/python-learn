package com.hellobike.aicc.infrastructure.persistence;

import com.alibaba.fastjson.JSON;
import com.hellobike.aicc.common.util.RedisKeyUtils;
import com.hellobike.aicc.domain.distribute.dto.ChannelTaskCounter;
import com.hellobike.aicc.domain.distribute.repo.DistChannelRepo;
import com.hellobike.base.flexjob.mapreduce.starter.model.consts.RedisKey;
import com.hellobike.base.redis.core.client.IRedisHelper;
import com.hellobike.base.redis.core.model.key.Key;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author zhengchenyang
 * @date 2025/3/21
 * @desc
 */
@Service
@Slf4j
public class DistChannelRepoImpl implements DistChannelRepo {
    @Resource
    private IRedisHelper redisHelper;

    @Override
    public Map<String, Long> queryTaskCounter(Long distributePlanId) {
        try {
            Map<String, String> taskCountMap = redisHelper.hgetAll(RedisKeyUtils.channelTaskCountKey(distributePlanId));
            if (MapUtils.isEmpty(taskCountMap)) {
                return new HashMap<>();
            }
            return taskCountMap.entrySet().stream().collect(HashMap::new, (m, v) -> m.put(v.getKey(), Long.parseLong(v.getValue())), HashMap::putAll);
        } catch (Exception e) {
            log.error("redis queryTaskCounter error,distributePlanId = {}", distributePlanId, e);
            return new HashMap<>();
        }
    }

    @Override
    public void incrTaskCounter(Long distributePlanId, String channelTaskKey, int count) {
        try {
            Key taskCountKey = RedisKeyUtils.channelTaskCountKey(distributePlanId);
            redisHelper.hincrby(taskCountKey, channelTaskKey, count);
            redisHelper.expire(taskCountKey, RedisKeyUtils.TIME_OUT_DAY);
        } catch (Exception e) {
            log.error("redis incrTaskCounter error,distributePlanId = {} , channelTaskKey = {}", distributePlanId, channelTaskKey, e);
        }
    }

    @Override
    public void delTaskCounter(Long distributePlanId) {
        try {
            redisHelper.del(RedisKeyUtils.channelTaskCountKey(distributePlanId));
        } catch (Exception e) {
            log.error("redis delTaskCounter error,distributePlanId = {}}", distributePlanId, e);
        }
    }
}
