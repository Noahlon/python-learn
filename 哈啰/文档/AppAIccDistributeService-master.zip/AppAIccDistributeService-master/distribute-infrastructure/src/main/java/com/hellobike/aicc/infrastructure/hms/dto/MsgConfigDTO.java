package com.hellobike.aicc.infrastructure.hms.dto;


import lombok.Data;

import java.util.Set;

/**
 * 消息配置实体
 *
 **/
@Data
public class MsgConfigDTO {

    /**
     * 消息消费者
     */
    private String consumerName;
    /**
     * 是否开启
     */
    private Boolean enable;
    /**
     * 消息消费者类名称
     */
    private String className;
    /**
     * 消息消费tag
     */
    private Set<String> tagList;
    /**
     * 消息默认限流
     */
    private Double rateLimit;

    /**
     * 是否消费消息
     */
    private Boolean handlerMsg;

    /**
     * 是否输出日志
     */
    private Boolean isLog;

    public MsgConfigDTO() {
        this.rateLimit = 10D;
        this.enable = false;
        this.handlerMsg = true;
        this.isLog = false;
    }
}
