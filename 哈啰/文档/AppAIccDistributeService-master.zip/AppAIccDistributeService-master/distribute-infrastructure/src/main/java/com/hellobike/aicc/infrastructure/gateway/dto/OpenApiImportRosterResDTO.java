package com.hellobike.aicc.infrastructure.gateway.dto;

import lombok.Data;

/**
 * @author zhangzhuoqi
 * @since 2025-05-12  16:10:07
 */
@Data
public class OpenApiImportRosterResDTO {

    /**
     * 上传名单成功数量
     */
    private Integer successCount;

    /**
     * 上传名单失败数量
     */
    private Integer failCount;

    /**
     * 重复数量
     */
    private Integer duplicationCount;
}
