package com.hellobike.aicc.infrastructure.convert;

import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributeChannelTaskPO;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface DistributeChannelTaskInfConvert {
    DistributeChannelTaskPO convert(DistributeChannelTaskEntity entity);

    DistributeChannelTaskEntity convert(DistributeChannelTaskPO po);

    List<DistributeChannelTaskEntity> convert(List<DistributeChannelTaskPO> po);
}
