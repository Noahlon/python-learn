package com.hellobike.aicc.infrastructure.hms.consumer;

import com.ctrip.framework.apollo.ConfigService;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.infrastructure.hms.dto.MsgConfigDTO;
import com.hellobike.hms.sdk.Hms;
import com.hellobike.soa.starter.spring.event.SoaStartedEvent;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 消费者启动服务
 **/
@Slf4j
@Component
public class ConsumerStarterService implements ApplicationListener<ApplicationEvent> {

    @Resource
    private ApplicationContext context;

    @Value("${distribute.consumers.append.config:}")
    private String consumerConfig;

    private List<MsgConfigDTO> msgConfigDTOList;

    private static final String ISORDERLY = "isOrderly";

    @Override
    public void onApplicationEvent(@NotNull ApplicationEvent event) {
        if (event instanceof SoaStartedEvent) {
            //1. 初始化消费者
            initConsumer();
            //2. 监听属性变动
            ConfigService.getAppConfig().addChangeListener(changeEvent -> {
                try {
                    //初始化监听事件
                    String key = "distribute.consumers.append.config";
                    if (changeEvent.isChanged(key)) {
                        setConsumerConfig(changeEvent.getChange(key).getNewValue());
                        initConsumer();
                    }
                } catch (Exception e) {
                    log.error("apollo change error", e);
                }
            });

        }
        if (event instanceof ContextClosedEvent) {
            stopAssetMsgHms();
        }
    }

    /**
     * 初始化消费者
     * 就算没有做阿波罗配置，也会启动所有消费者
     * 阿波罗配置会覆盖默认配置
     */
    private void initConsumer() {
        //获取配置
        if (!msgConfigCheck()) {
            return;
        }
        List<MsgConfigDTO> curConfigDTOList = getMsgConfigDTOList();
        Map<String, BaseMsgConsumer> typeToConsumerMap = context.getBeansOfType(BaseMsgConsumer.class);
        Map<String, MsgConfigDTO> classNameToConfigDtoMap = curConfigDTOList.stream().collect(Collectors.toMap(MsgConfigDTO::getClassName, Function.identity(), (o, n) -> o));
        for (BaseMsgConsumer msgConsumer : typeToConsumerMap.values()) {
            //默认限流为10
            double rateLimit = 10D;
            //默认开启消息
            boolean handlerMsg = true;
            boolean enable = true;

            String simpleName = msgConsumer.getClass().getSimpleName();
            MsgConfigDTO msgConfigDTO = classNameToConfigDtoMap.get(simpleName);

            String consumerName = msgConsumer.getConsumerName();
            Set<String> tagList = msgConsumer.getTagList();

            if (msgConfigDTO != null) {
                consumerName = msgConfigDTO.getConsumerName();
                rateLimit = msgConfigDTO.getRateLimit();
                handlerMsg = msgConfigDTO.getHandlerMsg();
                enable = msgConfigDTO.getEnable();
                tagList = msgConfigDTO.getTagList();
                msgConsumer.setIsLog(msgConfigDTO.getIsLog());
            }
            //设置限流
            msgConsumer.setRateLimit(rateLimit);
            //设置是否处理消息
            msgConsumer.setHandlerMsg(handlerMsg);

            //开始启动消费者
            if (enable && !msgConsumer.getRunning()) {
                if (CollectionUtils.isEmpty(tagList)) {
                    if (Objects.equals(simpleName, "RosterUpdConsumer")) {
                        //名单更新保证顺序消费
                        Properties properties = new Properties();
                        properties.setProperty(ISORDERLY, "true");
                        Hms.subscribe(consumerName, msgConsumer, properties);
                    }
                    Hms.subscribe(consumerName, msgConsumer);
                } else {
                    Hms.subscribe(consumerName, tagList, msgConsumer);
                }
                msgConsumer.setRunning(true);
                log.info("start {} consume..., tag={}", consumerName, tagList);
            }
            //开始停止消费者
            if (!enable) {
                Hms.stopConsumer(consumerName);
                msgConsumer.setRunning(false);
                log.info("stop {} consume..., tag={}", consumerName, tagList);
            }
        }
    }

    private boolean msgConfigCheck() {
        //获取配置
        String curConfig = getConsumerConfig();
        if (StringUtils.isBlank(curConfig)) {
            setMsgConfigDTOList(Collections.emptyList());
            return true;
        }
        List<MsgConfigDTO> curConfigDTOList = BaseJsonUtils.readValues(curConfig, MsgConfigDTO.class);
        if (null == curConfigDTOList || curConfigDTOList.stream().anyMatch(v -> StringUtils.isAnyBlank(v.getConsumerName(), v.getClassName()))) {
            log.error("init msg consume fail: topic or listener is null");
            return false;
        }
        setMsgConfigDTOList(curConfigDTOList);
        return true;
    }

    private void stopAssetMsgHms() {
        log.info("stop msg consume...");
        msgConfigCheck();
        List<MsgConfigDTO> curConfigDTOList = getMsgConfigDTOList();
        for (MsgConfigDTO msgConfigInfo : curConfigDTOList) {
            Hms.stopConsumer(msgConfigInfo.getConsumerName());
            BaseMsgConsumer msgListener = (BaseMsgConsumer) context.getBean(capitalizeFirstLetter(msgConfigInfo.getClassName()));
            msgListener.setRunning(false);
            log.info("stop {} consume..., tag={}", msgConfigInfo.getConsumerName(), msgConfigInfo.getTagList());
        }
    }

    /**
     * 首字母转为小写
     *
     * @param str 字符串
     * @return 字符串
     */
    public static String capitalizeFirstLetter(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }
        char firstChar = str.charAt(0);
        if (Character.isLowerCase(firstChar)) {
            return str;
        }
        return Character.toLowerCase(firstChar) + str.substring(1);
    }

    public List<MsgConfigDTO> getMsgConfigDTOList() {
        return msgConfigDTOList;
    }

    public void setMsgConfigDTOList(List<MsgConfigDTO> msgConfigDTOList) {
        this.msgConfigDTOList = msgConfigDTOList;
    }

    public void setConsumerConfig(String consumerConfig) {
        this.consumerConfig = consumerConfig;
    }

    public String getConsumerConfig() {
        return consumerConfig;
    }


}
