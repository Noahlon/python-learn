package com.hellobike.aicc.infrastructure.job;

import com.hellobike.aicc.common.enums.NameListStatusEnum;
import com.hellobike.aicc.domain.distribute.entity.DistributeUploadFileEntity;
import com.hellobike.aicc.domain.distribute.repo.DistUploadFileRepo;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributeUploadFileCondition;
import com.hellobike.aicc.domain.distribute.service.DistUploadFileDomainService;
import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;
import com.hellobike.aicc.domain.roster.repo.UploadRecordRepository;
import com.hellobike.base.flexjob.common.model.base.ReturnT;
import com.hellobike.base.flexjob.common.participant.ParticipantParams;
import com.hellobike.base.flexjob.participant.starter.spring.JobHandle;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 待解析待名单文件导入任务处理-定时任务
 */
@Service
@Slf4j
@JobHandle("nameListProcessJob")
public class NameListProcessJob {
    @Resource
    private DistUploadFileDomainService distUploadFileDomainService;

    @Resource
    private UploadRecordRepository uploadRecordRepository;

    @Resource
    private DistUploadFileRepo distUploadFileRepo;

    public ReturnT<String> trigger(ParticipantParams params) {
        log.info("开始处理待解析的名单导入任务");
        try {
            doTrigger();
            return new ReturnT<>(ReturnT.SUCCESS_CODE, "待解析的名单导入任务执行完毕");
        } catch (Exception e) {
            log.error("处理待解析的名单导入任务异常", e);
            return new ReturnT<>(ReturnT.FAIL_CODE, "处理待解析的名单导入任务异常");
        }
    }

    private void doTrigger() {
        DistributeUploadFileCondition condition = new DistributeUploadFileCondition();
        condition.setStatusList(Collections.singletonList(NameListStatusEnum.WAIT_PROCESS.getCode()));
        List<DistributeUploadFileEntity> taskList = distUploadFileRepo.queryByCondition(condition);
        if (CollectionUtils.isEmpty(taskList)) {
            return;
        }
        log.info("待解析的名单导入任务数量：{}", taskList.size());
        // 查询时已经根据创建时间正序排序，所以这里取第一条数据即可
        Map<Long, DistributeUploadFileEntity> planIdToFirstTask = taskList.stream()
                .collect(Collectors.toMap(DistributeUploadFileEntity::getDistributePlanId, Function.identity(), (existing, newItem) -> existing));
        planIdToFirstTask.values().forEach(this::doRetryUpload);
    }

    private void doRetryUpload(DistributeUploadFileEntity uploadFile) {
        try {
            log.info("定时任务开始处理名单导入任务，名单导入任务id为：{}", uploadFile.getId());
            Long uploadRecordId = uploadFile.getUploadRecordId();
            UploadRecordEntity uploadRecord = uploadRecordRepository.getRecordById(uploadRecordId, uploadFile.getDistributePlanId());
            if (uploadRecord == null) {
                log.error("上传记录查询为空");
                return;
            }

            // 在上传过程中，上传记录只会修改状态和上传数量、下发数量；防止误更新其他字段，只设置id和分流计划id
            UploadRecordEntity updateUploadRecord = new UploadRecordEntity();
            updateUploadRecord.setId(uploadRecord.getId());
            updateUploadRecord.setDistributePlanId(uploadRecord.getDistributePlanId());
            updateUploadRecord.setRosterType(uploadRecord.getRosterType());
            distUploadFileDomainService.doUpload(uploadFile, updateUploadRecord);
        } catch (Exception e) {
            log.error("处理待解析的名单导入任务异常, 上传文件任务id为：{}", uploadFile.getId(), e);
        }
    }
}
