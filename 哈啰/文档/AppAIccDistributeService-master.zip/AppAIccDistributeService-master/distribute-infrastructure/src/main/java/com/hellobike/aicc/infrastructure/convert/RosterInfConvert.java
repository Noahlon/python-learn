package com.hellobike.aicc.infrastructure.convert;

import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.infrastructure.es.roster.po.PlanRosterESPO;
import com.hellobike.aicc.infrastructure.persistence.multi.po.PlanRosterPO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-14  14:58:25
 */
@Mapper(componentModel = "spring", imports = {PlanRosterEntity.class, DateUtils.class})
public interface RosterInfConvert {

    PlanRosterEntity toEntity(PlanRosterPO po);

    PlanRosterPO toPO(PlanRosterEntity entity);

    List<PlanRosterPO> toPOList(List<PlanRosterEntity> entityList);

    List<PlanRosterEntity> toEntityList(List<PlanRosterPO> entityList);

    @Mapping(target = "uploadTime", expression = "java(DateUtils.format(po.getUploadTime()))")
    @Mapping(target = "distributeTime", expression = "java(DateUtils.format(po.getDistributeTime()))")
    @Mapping(target = "lastCallTime", expression = "java(DateUtils.format(po.getLastCallTime()))")
    @Mapping(target = "lastThroughTime", expression = "java(DateUtils.format(po.getLastThroughTime()))")
    @Mapping(target = "createTime", expression = "java(DateUtils.format(po.getCreateTime()))")
    @Mapping(target = "updateTime", expression = "java(DateUtils.format(po.getUpdateTime()))")
    PlanRosterESPO poToES(PlanRosterPO po);

    List<PlanRosterESPO> poToES(List<PlanRosterPO> poList);

    @Mapping(target = "uploadTime", expression = "java(DateUtils.toLocalDateTime(esPO.getUploadTime()))")
    @Mapping(target = "distributeTime", expression = "java(DateUtils.toLocalDateTime(esPO.getDistributeTime()))")
    @Mapping(target = "lastCallTime", expression = "java(DateUtils.toLocalDateTime(esPO.getLastCallTime()))")
    @Mapping(target = "lastThroughTime", expression = "java(DateUtils.toLocalDateTime(esPO.getLastThroughTime()))")
    @Mapping(target = "createTime", expression = "java(DateUtils.toLocalDateTime(esPO.getCreateTime()))")
    @Mapping(target = "updateTime", expression = "java(DateUtils.toLocalDateTime(esPO.getUpdateTime()))")
    PlanRosterPO esToPO(PlanRosterESPO esPO);

    List<PlanRosterPO> esToPO(List<PlanRosterESPO> esPOList);

    @Mapping(target = "uploadTime", expression = "java(DateUtils.format(entity.getUploadTime()))")
    @Mapping(target = "distributeTime", expression = "java(DateUtils.format(entity.getDistributeTime()))")
    @Mapping(target = "lastCallTime", expression = "java(DateUtils.format(entity.getLastCallTime()))")
    @Mapping(target = "lastThroughTime", expression = "java(DateUtils.format(entity.getLastThroughTime()))")
    @Mapping(target = "createTime", expression = "java(DateUtils.format(entity.getCreateTime()))")
    @Mapping(target = "updateTime", expression = "java(DateUtils.format(entity.getUpdateTime()))")
    PlanRosterESPO entityToES(PlanRosterEntity entity);

    List<PlanRosterESPO> entityToES(List<PlanRosterEntity> entityList);
}
