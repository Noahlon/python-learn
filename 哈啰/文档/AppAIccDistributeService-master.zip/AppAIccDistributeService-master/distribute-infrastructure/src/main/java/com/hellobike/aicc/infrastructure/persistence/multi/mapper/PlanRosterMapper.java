package com.hellobike.aicc.infrastructure.persistence.multi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hellobike.aicc.infrastructure.persistence.multi.po.PlanRosterPO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 数据密级S2,名单 Mapper 接口
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
public interface PlanRosterMapper extends BaseMapper<PlanRosterPO> {

    void batchSave(@Param("list") List<PlanRosterPO> list);
}
