package com.hellobike.aicc.infrastructure.gateway.css;

import cn.hutool.core.map.MapUtil;
import com.alibaba.fastjson.JSON;
import com.googlecode.aviator.AviatorEvaluator;
import com.hellobike.aicc.common.dto.DistPlanImpactRule;
import com.hellobike.aicc.common.enums.RosterDistributeStatusEnum;
import com.hellobike.aicc.common.enums.YesOrNoEnum;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.facade.RosterPortraitFacade;
import com.hellobike.css.ai.api.base.Result;
import com.hellobike.css.ai.api.iface.portrait.UserPortraitIface;
import com.hellobike.soa.starter.spring.annotation.Reference;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author zhangzhuoqi
 * @since 2025-04-11  10:35:50
 */
@Service
@Slf4j
public class RosterPortraitFacadeImpl implements RosterPortraitFacade {

    @Reference
    private UserPortraitIface userPortraitIface;

    private static final String IMPACT_FAIL_REASON = "撞库失败";
    private static final String IMPACT_NOT_HIT_REASON = "撞库未命中";

    @Override
    public void impact(DistPlanImpactRule ruleDTO, List<PlanRosterEntity> rosterList) {
        if (CollectionUtils.isEmpty(rosterList)) {
            return;
        }
        //撞库获取用户标签
        List<String> phoneMd5List = rosterList.stream().map(PlanRosterEntity::getMd5).distinct().collect(Collectors.toList());
        Map<String, Map<String, Object>> userMap;
        try {
            Result<Map<String, Map<String, Object>>> result = userPortraitIface.queryUserPortrait(phoneMd5List);
            if (result == null || !result.isSuccess() || MapUtil.isEmpty(result.getData())) {
                log.error("撞库获取用户标签失败,ruleDTO:{},failCount:{}", BaseJsonUtils.writeValue(ruleDTO), rosterList.size());
                rosterList.forEach(roster -> this.buildRosterImpactInfo(roster, RosterDistributeStatusEnum.NOT_DISTRIBUTE, false, IMPACT_FAIL_REASON));
                return;
            }
            userMap = result.getData();
        }catch (Exception e){
            log.error("撞库获取用户标签异常,ruleDTO:{},failCount:{}", BaseJsonUtils.writeValue(ruleDTO), rosterList.size(), e);
            rosterList.forEach(roster -> this.buildRosterImpactInfo(roster, RosterDistributeStatusEnum.NOT_DISTRIBUTE, false, IMPACT_FAIL_REASON));
            return;
        }

        for (PlanRosterEntity roster : rosterList) {
            Map<String, Object> userPortraitMap = userMap.get(roster.getMd5());
            //获取名单对应的标签
            if (MapUtil.isEmpty(userPortraitMap)) {
                this.buildRosterImpactInfo(roster, RosterDistributeStatusEnum.NOT_DISTRIBUTE, false, IMPACT_FAIL_REASON);
                continue;
            }
            boolean isHitRule = this.rosterIsHitRule(roster, ruleDTO, userPortraitMap);
            RosterDistributeStatusEnum rosterDistributeStatus;
            String notDistReason = null;
            //命中标签规则不为空则表示命中规则
            if (isHitRule) {
                rosterDistributeStatus = RosterDistributeStatusEnum.PENDING;
            } else {
                notDistReason = IMPACT_NOT_HIT_REASON;
                rosterDistributeStatus = RosterDistributeStatusEnum.NOT_DISTRIBUTE;
            }
            this.buildRosterImpactInfo(roster, rosterDistributeStatus, isHitRule, notDistReason);
        }
    }

    private boolean rosterIsHitRule(PlanRosterEntity roster, DistPlanImpactRule rule, Map<String, Object> userPortraitMap) {
        try {
            Map<String, Object> env = new HashMap<>();
            rule.getRuleList().forEach(portraitType -> {
                        if(!userPortraitMap.containsKey(portraitType)){
                            return;
                        }
                       env.put(portraitType,userPortraitMap.get(portraitType));
            });

            Map<String, String> rules = new HashMap<>();
            rules.put("rule", rule.getRuleExp());
            rules.put("env", JSON.toJSONString(env));
            roster.setHitRule(JSON.toJSONString(rules));
            return (boolean) AviatorEvaluator.execute(rule.getRuleExp(), env, true);
        } catch (Exception e) {
            log.error("rosterIsHitRule error, roster = {}", JSON.toJSONString(roster), e);
        }
        return false;
    }

    private void buildRosterImpactInfo(PlanRosterEntity roster,
                                       RosterDistributeStatusEnum rosterDistributeStatus,
                                       boolean isHitRule,
                                       String notDistReason) {
        roster.setIsImpact(YesOrNoEnum.YES.getCode());
        roster.setIsHitRule(isHitRule ? YesOrNoEnum.YES.getCode() : YesOrNoEnum.NO.getCode());
        roster.setNotDistReason(notDistReason);
        roster.setDistributeStatus(rosterDistributeStatus.getCode());
    }

}
