package com.hellobike.aicc.infrastructure.persistence.single.repository;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DeleteEnum;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.exception.BusinessException;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanTemplateEntity;
import com.hellobike.aicc.domain.distribute.repo.DistPlanTemplateRepo;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanTemplateCondition;
import com.hellobike.aicc.infrastructure.convert.DistributePlanTemplateConvert;
import com.hellobike.aicc.infrastructure.persistence.single.mapper.DistributePlanTemplateMapper;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributePlanTemplatePO;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * 数据密级S2,分流计划模版 服务实现类
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Service
public class DistPlanTemplateRepoImpl extends ServiceImpl<DistributePlanTemplateMapper, DistributePlanTemplatePO> implements DistPlanTemplateRepo {
    @Resource
    private DistributePlanTemplateMapper distributePlanTemplateMapper;
    @Resource
    private DistributePlanTemplateConvert distributePlanTemplateConvert;

    @Override
    public void save(DistributePlanTemplateEntity distributePlanTemplateEntity) {
        DistributePlanTemplatePO po = distributePlanTemplateConvert.convert(distributePlanTemplateEntity);
        save(po);
    }

    @Override
    public DistributePlanTemplateEntity queryById(Long id) {
        if (Objects.isNull(id)){
            return null;
        }
        LambdaQueryWrapper<DistributePlanTemplatePO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributePlanTemplatePO::getId, id)
                .eq(DistributePlanTemplatePO::getIsDelete, DeleteEnum.NO.getCode());
        DistributePlanTemplatePO distributePlanTemplatePO = this.getBaseMapper().selectOne(queryWrapper);
        return distributePlanTemplateConvert.convert(distributePlanTemplatePO);
    }

    @Override
    public void updateById(DistributePlanTemplateEntity distributePlanTemplateEntity) {
        DistributePlanTemplatePO po = distributePlanTemplateConvert.convert(distributePlanTemplateEntity);
        updateById(po);
    }

    @Override
    public boolean deleteById(Long id) {
        LambdaUpdateWrapper<DistributePlanTemplatePO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(DistributePlanTemplatePO::getId, id)
                .set(DistributePlanTemplatePO::getIsDelete, DeleteEnum.YES.getCode());
        return update(updateWrapper);
    }

    @Override
    public PageResult<DistributePlanTemplateEntity> queryPlanTemplate(DistributePlanTemplateCondition condition) {
        // 边界条件检查
        if (condition.getPageNum() <= 0 || condition.getPageSize() <= 0) {
            throw new BusinessException(BusinessErrorCode.PARAMETER_ERROR, "Invalid page index or page size");
        }
        LambdaQueryWrapper<DistributePlanTemplatePO> queryWrapper = buildQueryWrapper(condition);
        // 根据sortColumn及sortType增加排序条件
        if (StringUtils.isNotBlank(condition.getSortType())) {
            String defaultSortType = "asc";
            if (defaultSortType.equalsIgnoreCase(condition.getSortType())) {
                getDynamicSort(condition.getSortColumn(), queryWrapper, true);
            } else {
                getDynamicSort(condition.getSortColumn(), queryWrapper, false);
            }
        } else {
            queryWrapper.orderByDesc(DistributePlanTemplatePO::getCreateTime);
        }
        Page<DistributePlanTemplatePO> page = page(new Page<>(condition.getPageNum(), condition.getPageSize()), queryWrapper);
        return distributePlanTemplateConvert.convert(page);
    }

    @Override
    public List<DistributePlanTemplateEntity> queryByIdList(List<Long> idList) {
        if (CollectionUtil.isEmpty(idList)){
            return Collections.emptyList();
        }
        LambdaQueryWrapper<DistributePlanTemplatePO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.in(DistributePlanTemplatePO::getId, idList)
                .eq(DistributePlanTemplatePO::getIsDelete, DeleteEnum.NO.getCode());
        List<DistributePlanTemplatePO> list = list(queryWrapper);
        return distributePlanTemplateConvert.convert(list);
    }

    @Override
    public List<DistributePlanTemplateEntity> queryPlanTemplateList(String tenantCode) {
        LambdaQueryWrapper<DistributePlanTemplatePO> queryWrapper = new LambdaQueryWrapper<>();
        // 动态添加其他条件
        queryWrapper.eq(DistributePlanTemplatePO::getIsDelete, DeleteEnum.NO.getCode())
                .eq(StringUtils.isNotBlank(tenantCode), DistributePlanTemplatePO::getTenantCode,tenantCode)
                .orderByDesc(DistributePlanTemplatePO::getCreateTime);
        List<DistributePlanTemplatePO> list = list(queryWrapper);
        return distributePlanTemplateConvert.convert(list);
    }

    @Override
    public List<DistributePlanTemplateEntity> queryByCondition(DistributePlanTemplateCondition condition) {
        LambdaQueryWrapper<DistributePlanTemplatePO> queryWrapper = buildQueryWrapper(condition);
        List<DistributePlanTemplatePO> list = list(queryWrapper);
        if (CollectionUtil.isEmpty(list)){
            return Collections.emptyList();
        }
        return distributePlanTemplateConvert.convert(list);
    }

    private LambdaQueryWrapper<DistributePlanTemplatePO> buildQueryWrapper(DistributePlanTemplateCondition condition) {
        LambdaQueryWrapper<DistributePlanTemplatePO> queryWrapper = new LambdaQueryWrapper<>();
        // 动态添加其他条件
        queryWrapper.eq(DistributePlanTemplatePO::getIsDelete, DeleteEnum.NO.getCode())
                .eq(StringUtils.isNotBlank(condition.getTemplateId()), DistributePlanTemplatePO::getId, condition.getTemplateId())
                .like(StringUtils.isNotBlank(condition.getTemplateName()), DistributePlanTemplatePO::getTemplateName, condition.getTemplateName())
                .in(CollectionUtils.isNotEmpty(condition.getTenantCodeList()), DistributePlanTemplatePO::getTenantCode, condition.getTenantCodeList())
                .eq(condition.getDistributeType() != null, DistributePlanTemplatePO::getDistributeType, condition.getDistributeType())
                // 渠道商json过滤
                .and(condition.getChannelId() != null, wrapper -> wrapper.apply("JSON_CONTAINS(distribute_rule, JSON_OBJECT('channelId', {0}), '$')", condition.getChannelId()));
        return queryWrapper;
    }

    public void getDynamicSort(String sortColumn, LambdaQueryWrapper<DistributePlanTemplatePO> queryWrapper, boolean isAsc) {
        sortColumn = StringUtils.defaultIfBlank(sortColumn, "createTime");
        switch (sortColumn) {
            case "createTime":
                queryWrapper.orderBy(true, isAsc, DistributePlanTemplatePO::getCreateTime);
                break;
            case "latestUsingTime":
                queryWrapper.orderBy(true, isAsc, DistributePlanTemplatePO::getLatestUsingTime);
                break;
            default:
                throw new IllegalArgumentException("无效的字段: " + sortColumn);
        }
    }

}
