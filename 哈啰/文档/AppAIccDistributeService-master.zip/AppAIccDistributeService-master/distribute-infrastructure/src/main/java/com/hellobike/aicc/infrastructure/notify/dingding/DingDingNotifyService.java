package com.hellobike.aicc.infrastructure.notify.dingding;

import com.hellobike.aicc.infrastructure.convert.DingMsgConvert;
import com.hellobike.css.ai.common.util.DingNotifyUtil;
import com.hellobike.aicc.infrastructure.notify.dingding.dto.*;
import com.hellobike.unkonw.common.log.alert.model.DingMsg;
import com.hellobike.unkonw.common.log.alert.sender.DingTalkSender;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

/**
 * @author chenkangkang
 * @date 2023/12/5
 **/
@Component
public class DingDingNotifyService implements DingNotifyUtil {

    @Resource
    private DingTalkSender dingTalkSender;

    @Resource
    private DingMsgConvert dingMsgConvert;

    /**
     * 发送消息
     *
     * @param dingMsgDTO 消息内容
     */
    public void send(DingMsgDTO dingMsgDTO) {
        DingMsg dingMsg = dingMsgConvert.convert(dingMsgDTO);
        dingTalkSender.send(dingMsg, dingMsgDTO.getTokenList());
    }


    /**
     * 发送markdown消息
     *
     * @param title           标题
     * @param markdownContent markdown格式文本
     * @param tokenList       token列表
     */
    @Override
    public void sendMarkDown(String title, String markdownContent, List<String> tokenList) {
        MarkdownContentDTO contentDTO = new MarkdownContentDTO();
        contentDTO.setTitle(title);
        contentDTO.setText(markdownContent);

        DingMsgDTO dingMsgDTO = new DingMsgDTO();
        dingMsgDTO.setMsgtype(DingMsgDTO.MSG_TYPE_MD);
        dingMsgDTO.setMarkdown(contentDTO);
        dingMsgDTO.setTokenList(tokenList);
        send(dingMsgDTO);
    }

    /**
     * 发送普通格式消息
     *
     * @param content   告警内容
     * @param tokenList token列表
     */
    @Override
    public void sendText(String content, List<String> tokenList) {
        TextContentDTO contentDTO = new TextContentDTO();
        contentDTO.setContent(content);

        DingMsgDTO dingMsgDTO = new DingMsgDTO();
        dingMsgDTO.setMsgtype(DingMsgDTO.MSG_TYPE_TEXT);
        dingMsgDTO.setText(contentDTO);
        dingMsgDTO.setTokenList(tokenList);
        send(dingMsgDTO);
    }

    @Override
    public void sendMarkDown(String text, String title, String token, boolean atAll) {
        sendMarkDown(text, title, Collections.singletonList(text), atAll);
    }

    @Override
    public void sendMarkDown(String text, String title, List<String> tokenList, boolean atAll) {
        MarkdownContentDTO markdownContentDTO = new MarkdownContentDTO();
        markdownContentDTO.setText(text);
        markdownContentDTO.setTitle(title);

        AtContentDTO atContentDTO = new AtContentDTO();
        atContentDTO.setIsAtAll(atAll);

        DingMsgDTO dingMsgDTO = new DingMsgDTO();
        dingMsgDTO.setMsgtype(DingMsgDTO.MSG_TYPE_MD);
        dingMsgDTO.setMarkdown(markdownContentDTO);
        dingMsgDTO.setTokenList(tokenList);
        dingMsgDTO.setAt(atContentDTO);
        send(dingMsgDTO);
    }
}
