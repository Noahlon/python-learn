package com.hellobike.aicc.infrastructure.hms.consumer.sms;

import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.common.service.DingTalkService;
import com.hellobike.aicc.domain.smsrecord.dto.CssSmsRecordMsgDTO;
import com.hellobike.aicc.domain.smsrecord.handler.SmsCallBackHandler;
import com.hellobike.aicc.infrastructure.convert.SmsRecordInfConvert;
import com.hellobike.aicc.infrastructure.hms.consumer.BaseMsgConsumer;
import com.hellobike.hms.sdk.consumer.ConsumeMessage;
import com.hellobike.hms.sdk.consumer.MsgRetryStatus;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Objects;

/**
 * 外呼短信记录消费者
 *
 * @author panlongqian
 * @since 2025-04-10
 */
@Slf4j
@Component
public class CssSmsRecordConsumer extends BaseMsgConsumer {
    private static final String CONSUMER = "css_sms_record_push_inner_topic_aicc_distribute_consumer";

    @Resource
    private SmsRecordInfConvert smsRecordInfConvert;

    @Resource
    private DingTalkService dingTalkService;

    @Override
    protected String getConsumerName() {
        return CONSUMER;
    }

    @Override
    public MsgRetryStatus msgProcess(ConsumeMessage mqMessage) {
        try {
            doConsumer(mqMessage);
        } catch (Exception e) {
            log.error("消费外呼短信记录异常,e:", e);
            dingTalkService.sendSmsRecordFailedAlert(mqMessage.getMsgId());
        }
        return MsgRetryStatus.SUCCEED;
    }

    private void doConsumer(ConsumeMessage mqMessage) {
        String msgBody = new String(mqMessage.getPayload());
        log.info("外呼短信记录消息:{}", mqMessage);
        CssSmsRecordMsgDTO cssSmsRecord = BaseJsonUtils.readValue(msgBody, CssSmsRecordMsgDTO.class);
        if (Objects.isNull(cssSmsRecord) || StringUtils.isAnyBlank(cssSmsRecord.getId(), cssSmsRecord.getExternalId()) || StringUtils.isAllBlank(cssSmsRecord.getPhoneNumber(), cssSmsRecord.getMd5())) {
            log.error("外呼短信记录消息为空, 或者短信记录id为空，或者话单id为空，或者手机号码为空，dto:{}", cssSmsRecord);
            return;
        }

        SmsCallBackHandler smsHandler = ChannelFactory.getSmsHandler(ChannelFactory.getHelloAiCall().getChannelId());
        if (smsHandler == null) {
            log.error("外呼渠道不可用");
            return;
        }

        smsHandler.handlerSmsCallBack(cssSmsRecord, ChannelFactory.getHelloAiCall());
    }
}
