package com.hellobike.aicc.infrastructure.persistence.single.repository;

import cn.hutool.core.util.NumberUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.component.ApolloConfigs;
import com.hellobike.aicc.common.enums.DeleteEnum;
import com.hellobike.aicc.common.enums.DistributeTypeEnum;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueStatisticEntity;
import com.hellobike.aicc.domain.dialogue.entity.TenantStatEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanQueryCondition;
import com.hellobike.aicc.domain.roster.entity.RosterStat;
import com.hellobike.aicc.domain.smsrecord.entity.DistPlanSmsStat;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordCondition;
import com.hellobike.aicc.infrastructure.convert.DistributePlantInfConvert;
import com.hellobike.aicc.infrastructure.es.calldialogue.condition.CallDialogueESCondition;
import com.hellobike.aicc.infrastructure.es.calldialogue.repository.CallDialogueESRepository;
import com.hellobike.aicc.infrastructure.es.roster.condition.RosterESCondition;
import com.hellobike.aicc.infrastructure.es.roster.repository.RosterESRepository;
import com.hellobike.aicc.infrastructure.es.smsrecord.repository.SmsRecordESRepository;
import com.hellobike.aicc.infrastructure.persistence.single.mapper.DistributePlanMapper;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributePlanPO;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * <p>
 * 数据密级S2,分流计划表 服务实现类
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Service
public class DistPlanRepoImpl extends ServiceImpl<DistributePlanMapper, DistributePlanPO> implements DistPlanRepo {
    @Resource
    private DistributePlantInfConvert distributePlantInfConvert;

    @Resource
    private CallDialogueESRepository callDialogueESRepository;

    @Resource
    private SmsRecordESRepository smsRecordESRepository;

    @Resource
    private RosterESRepository rosterESRepository;

    @Resource
    private ApolloConfigs apolloConfigs;

    @Override
    public void createDistributePlan(DistributePlanEntity distributePlan) {
        DistributePlanPO po = distributePlantInfConvert.toPO(distributePlan);
        save(po);
    }

    @Override
    public void updateDistributePlan(DistributePlanEntity distributePlan) {
        DistributePlanPO po = distributePlantInfConvert.toPO(distributePlan);
        updateById(po);
    }

    @Override
    public DistributePlanEntity queryDistributePlanById(Long id) {
        LambdaQueryWrapper<DistributePlanPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributePlanPO::getId, id)
                .eq(DistributePlanPO::getIsDelete, DeleteEnum.NO.getCode());
        DistributePlanPO distributePlanPO = this.getBaseMapper().selectOne(queryWrapper);
        return distributePlantInfConvert.toEntity(distributePlanPO);
    }

    @Override
    public List<Long> queryByDistType(DistributeTypeEnum distributeTypeEnum) {
        if (Objects.isNull(distributeTypeEnum)) {
            return Collections.emptyList();
        }
        LambdaQueryWrapper<DistributePlanPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributePlanPO::getDistributeType, distributeTypeEnum.getCode())
                .eq(DistributePlanPO::getIsDelete, DeleteEnum.NO.getCode());
        queryWrapper.select(DistributePlanPO::getId);
        List<DistributePlanPO> list = list(queryWrapper);
        if (CollectionUtils.isEmpty(list)) {
            return Collections.emptyList();
        }
        return list.stream().map(DistributePlanPO::getId).collect(Collectors.toList());
    }

    @Override
    public PageResult<DistributePlanEntity> pageQueryDistributePlan(DistributePlanQueryCondition condition) {
        LambdaQueryWrapper<DistributePlanPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributePlanPO::getIsDelete, DeleteEnum.NO.getCode())
                .eq(StringUtils.isNotBlank(condition.getPlanId()), DistributePlanPO::getId, condition.getPlanId())
                .like(StringUtils.isNotBlank(condition.getPlanName()), DistributePlanPO::getDistributePlanName, condition.getPlanName())
                .in(CollectionUtils.isNotEmpty(condition.getTenantCodeList()), DistributePlanPO::getTenantCode, condition.getTenantCodeList())
                .eq(condition.getDistributeType() != null, DistributePlanPO::getDistributeType, condition.getDistributeType())
                .ge(StringUtils.isNotBlank(condition.getCreateStartTime()), DistributePlanPO::getCreateTime, condition.getCreateStartTime())
                .le(StringUtils.isNotBlank(condition.getCreateEndTime()), DistributePlanPO::getCreateTime, condition.getCreateEndTime())
                // 渠道商json过滤
                .and(condition.getChannelId() != null, wrapper -> wrapper.apply("JSON_CONTAINS(distribute_rule, JSON_OBJECT('channelId', {0}), '$')", condition.getChannelId()))
                .in(CollectionUtils.isNotEmpty(condition.getPlanTemplateIdList()), DistributePlanPO::getTemplateId, condition.getPlanTemplateIdList())
                .in(CollectionUtils.isNotEmpty(condition.getPlanIdList()), DistributePlanPO::getId, condition.getPlanIdList())
                .orderByDesc(DistributePlanPO::getCreateTime);
        if (Objects.nonNull(condition.getPlanTemplateId()) && NumberUtil.isLong(condition.getPlanTemplateId())){
            queryWrapper.eq(DistributePlanPO::getTemplateId, Long.valueOf(condition.getPlanTemplateId()));
        }

        Page<DistributePlanPO> page = page(new Page<>(condition.getPageNum(), condition.getPageSize()), queryWrapper);
        return distributePlantInfConvert.convert(page);
    }

    @Override
    public List<DistributePlanEntity> queryAllEffectiveDistPlans() {
        LambdaQueryWrapper<DistributePlanPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributePlanPO::getIsDelete, DeleteEnum.NO.getCode());
        List<DistributePlanPO> distributePlanPOList = this.getBaseMapper().selectList(queryWrapper);
        return distributePlantInfConvert.convert(distributePlanPOList);
    }

    @Override
    public void updateUploadDataNum(Long id, Integer uploadCount) {
        LambdaUpdateWrapper<DistributePlanPO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.setSql(" upload_data_num = upload_data_num + " + uploadCount)
                .eq(DistributePlanPO::getIsDelete, DeleteEnum.NO.getCode())
                .eq(DistributePlanPO::getId, id);
        update(updateWrapper);
    }

    @Override
    public PageResult<DistributePlanEntity> pageQueryDistPlanStat(DistributePlanQueryCondition condition) {
        LambdaQueryWrapper<DistributePlanPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributePlanPO::getIsDelete, DeleteEnum.NO.getCode())
                .eq(StringUtils.isNotBlank(condition.getPlanId()), DistributePlanPO::getId, condition.getPlanId())
                .like(StringUtils.isNotBlank(condition.getPlanName()), DistributePlanPO::getDistributePlanName, condition.getPlanName())
                .in(CollectionUtils.isNotEmpty(condition.getTenantCodeList()), DistributePlanPO::getTenantCode, condition.getTenantCodeList())
                .orderByDesc(DistributePlanPO::getCreateTime);

        Page<DistributePlanPO> page = page(new Page<>(condition.getPageNum(), condition.getPageSize()), queryWrapper);
        PageResult<DistributePlanEntity> planPageResult = distributePlantInfConvert.convert(page);
        if (planPageResult == null || planPageResult.isEmpty()) {
            return PageResult.getEmptyPage(condition.getPageNum(), condition.getPageSize());
        }

        List<DistributePlanEntity> planList = planPageResult.getList();
        this.statPlan(planList);

        return new PageResult<>(planPageResult.getPageNum(), planPageResult.getPageSize(), planPageResult.getTotalRecord(), planList);
    }

    @Override
    public void statPlan(List<DistributePlanEntity> planList) {
        LocalDateTime startTime = planList.get(planList.size() - 1).getCreateTime();
        List<String> planIdList = planList.stream().map(o -> String.valueOf(o.getId())).collect(Collectors.toList());

        CallDialogueESCondition dlgCondition = new CallDialogueESCondition();
        dlgCondition.setIndexes(DateUtils.getDatesBetween(startTime, LocalDateTime.now()));
        dlgCondition.setDistributePlanIdList(planIdList);
        List<CallDialogueStatisticEntity> taskDialogueStatisticList = callDialogueESRepository.statDlgByPlan(dlgCondition);

        SmsRecordCondition smsCondition = new SmsRecordCondition();
        smsCondition.setDistributePlanIdList(planIdList);
        smsCondition.setIndexes(DateUtils.getMonthBetween(startTime, LocalDateTime.now()));
        List<DistPlanSmsStat> taskSmsStat = smsRecordESRepository.smsStatByDistPlan(smsCondition);

        // 将 taskDialogueStatisticList 转换为 Map，以提高查找效率
        Map<String, CallDialogueStatisticEntity> statisticMap = taskDialogueStatisticList.stream()
                .collect(Collectors.toMap(CallDialogueStatisticEntity::getPlanId, statistic -> statistic));

        Map<String, DistPlanSmsStat> smsStatMap = taskSmsStat.stream()
                .collect(Collectors.toMap(DistPlanSmsStat::getPlanId, statistic -> statistic));

        Map<String, RosterStat> rosterStatMap = new HashMap<>();

        //筛选出用名单es统计的分流计划
        LocalDateTime statV2Time = DateUtils.toLocalDateTime(apolloConfigs.getStatV2Time());
        List<DistributePlanEntity> statRosterPlanList = planList.stream()
                .filter(d -> d.getCreateTime().isAfter(statV2Time))
                .collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(statRosterPlanList)) {
            RosterESCondition rosterESCondition = new RosterESCondition();
            rosterESCondition.setDistributePlanIdList(statRosterPlanList.stream().map(e -> String.valueOf(e.getId())).collect(Collectors.toList()));
            rosterESCondition.setIndexList(statRosterPlanList.stream().map(DistributePlanEntity::getCreateTime).collect(Collectors.toList()));
            List<RosterStat> rosterStatList = rosterESRepository.statByPlan(rosterESCondition);
            rosterStatMap = rosterStatList.stream().collect(Collectors.toMap(RosterStat::getDistributePlanId, Function.identity()));
        }

        Map<String, RosterStat> finalRosterStatMap = rosterStatMap;
        planList.forEach(entity -> {
            CallDialogueStatisticEntity statistic = statisticMap.get(String.valueOf(entity.getId()));
            DistPlanSmsStat smsStat = smsStatMap.get(String.valueOf(entity.getId()));
            RosterStat rosterStat = finalRosterStatMap.get(String.valueOf(entity.getId()));
            if (statistic != null) {
                entity.setCallRosterNum(statistic.getCallRosterNum());
                entity.setThroughCallDialogueNum(statistic.getThroughCallDialogueNum());
                entity.setCostUnit(statistic.getCostUnit());
                entity.setThroughRosterNum(statistic.getThroughRosterNum());
                entity.setIntentionStat(statistic.getIntentionStat());
                entity.setCallDialogueNum(statistic.getCallDialogueNum());
            }
            if (smsStat != null) {
                entity.setSendSmsSum(smsStat.getSendSum());
                entity.setSmsSuccSum(smsStat.getSuccSum());
                entity.setSmsUnit(smsStat.getSmsUnit());
            }
            if (rosterStat != null) {
                entity.setCallRosterNum(rosterStat.getCallRosterNum());
                entity.setThroughRosterNum(rosterStat.getThroughRosterNum());
                entity.setSendSmsSum(rosterStat.getSendSmsRosterNum());
                entity.setSmsSuccSum(rosterStat.getSendSmsSuccRosterNum());
            }
        });
    }

    @Override
    public TenantStatEntity queryDistPlanTotalStat(DistributePlanQueryCondition condition) {
        LambdaQueryWrapper<DistributePlanPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributePlanPO::getIsDelete, DeleteEnum.NO.getCode())
                .eq(StringUtils.isNotBlank(condition.getPlanId()), DistributePlanPO::getId, condition.getPlanId())
                .like(StringUtils.isNotBlank(condition.getPlanName()), DistributePlanPO::getDistributePlanName, condition.getPlanName())
                .in(CollectionUtils.isNotEmpty(condition.getTenantCodeList()), DistributePlanPO::getTenantCode, condition.getTenantCodeList())
                .orderByDesc(DistributePlanPO::getCreateTime);

        List<DistributePlanPO> planPoList = this.getBaseMapper().selectList(queryWrapper);
        List<DistributePlanEntity> planList = distributePlantInfConvert.convert(planPoList);
        if (CollectionUtils.isEmpty(planList)) {
            return new TenantStatEntity();
        }
        TenantStatEntity tenantStat = new TenantStatEntity();
        LocalDateTime startTime = planList.get(planList.size() - 1).getCreateTime();
        List<String> planIdList = planList.stream().map(o -> String.valueOf(o.getId())).collect(Collectors.toList());
        Long totalUploadDataNum = planList.stream().mapToLong(DistributePlanEntity::getUploadDataNum).sum();
        tenantStat.setUploadDataNum(totalUploadDataNum);
        tenantStat.setTenantId(CollectionUtils.isNotEmpty(condition.getTenantCodeList()) ? condition.getTenantCodeList().get(0) : null);
        CallDialogueESCondition dlgCondition = new CallDialogueESCondition();
        dlgCondition.setIndexes(DateUtils.getDatesBetween(startTime, LocalDateTime.now()));
        dlgCondition.setDistributePlanIdList(planIdList);
        dlgCondition.setTenantId(planList.get(0).getTenantCode());
        CallDialogueStatisticEntity dlgStat = callDialogueESRepository.statDlgByTenant(dlgCondition);
        if (dlgStat != null) {
            tenantStat.setCallDialogueNum(dlgStat.getCallDialogueNum());
            tenantStat.setCallRosterNum(dlgStat.getCallRosterNum());
            tenantStat.setThroughCallDialogueNum(dlgStat.getThroughCallDialogueNum());
            tenantStat.setCostUnit(dlgStat.getCostUnit());
            tenantStat.setThroughRosterNum(dlgStat.getThroughRosterNum());
            tenantStat.setIntentionStat(dlgStat.getIntentionStat());
        }

        SmsRecordCondition smsCondition = new SmsRecordCondition();
        smsCondition.setDistributePlanIdList(planIdList);
        smsCondition.setIndexes(DateUtils.getMonthBetween(startTime, LocalDateTime.now()));
        DistPlanSmsStat smsStat = smsRecordESRepository.smsStatByTenant(smsCondition);
        if (smsStat != null) {
            tenantStat.setSendSmsSum(smsStat.getSendSum());
            tenantStat.setSmsSuccSum(smsStat.getSuccSum());
            tenantStat.setSmsUnit(smsStat.getSmsUnit());
        }

        return tenantStat;
    }

    @Override
    public List<DistributePlanEntity> queryByCondition(DistributePlanQueryCondition condition) {
        LambdaQueryWrapper<DistributePlanPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributePlanPO::getIsDelete, DeleteEnum.NO.getCode())
                .ge(StringUtils.isNotBlank(condition.getCreateStartTime()), DistributePlanPO::getCreateTime, condition.getCreateStartTime())
                .le(StringUtils.isNotBlank(condition.getCreateEndTime()), DistributePlanPO::getCreateTime, condition.getCreateEndTime())
                .in(CollectionUtils.isNotEmpty(condition.getTenantCodeList()), DistributePlanPO::getTenantCode, condition.getTenantCodeList())
                .in(CollectionUtils.isNotEmpty(condition.getPlanIdList()), DistributePlanPO::getId, condition.getPlanIdList())
                .orderByDesc(DistributePlanPO::getCreateTime);
        List<DistributePlanPO> list = list(queryWrapper);
        if (CollectionUtils.isEmpty(list)) {
            return Collections.emptyList();
        }
        return distributePlantInfConvert.convert(list);
    }

    @Override
    public List<DistributePlanEntity> queryDistributePlanList(String tenantCode, LocalDateTime createStartTime, LocalDateTime createEndTime) {
        LambdaQueryWrapper<DistributePlanPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributePlanPO::getIsDelete, DeleteEnum.NO.getCode())
                .eq(DistributePlanPO::getTenantCode, tenantCode)
                .ge(Objects.nonNull(createStartTime), DistributePlanPO::getCreateTime, createStartTime)
                .le(Objects.nonNull(createEndTime), DistributePlanPO::getCreateTime, createEndTime)
                .orderByDesc(DistributePlanPO::getCreateTime);
        return distributePlantInfConvert.convert(this.getBaseMapper().selectList(queryWrapper));
    }
}
