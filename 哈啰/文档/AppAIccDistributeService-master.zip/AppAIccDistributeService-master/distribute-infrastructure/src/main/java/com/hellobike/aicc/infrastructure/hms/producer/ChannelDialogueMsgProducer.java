package com.hellobike.aicc.infrastructure.hms.producer;

import com.alibaba.fastjson.JSON;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.dto.ChannelDialoguePushDTO;
import com.hellobike.hms.sdk.Hms;
import com.hellobike.hms.sdk.common.SimpleMessage;
import com.hellobike.hms.sdk.common.SimpleMessageBuilder;
import com.hellobike.hms.sdk.producer.HmsCallBack;
import com.hellobike.hms.sdk.producer.SendResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * 渠道话单推送消息生产者
 */
@Service
@Slf4j
public class ChannelDialogueMsgProducer {

    private static final String TOPIC = "aicc_channel_dialogue_callback_topic";


    public void sendMsg(ChannelDialoguePushDTO msg) {
        log.info("ChannelDialogueMsgProducer.sendMsgKey:{}", msg.getDialogueCallBackDTO().getDialogueGuid());
        SimpleMessage message = SimpleMessageBuilder
                .newInstance()
                .buildPaylod(BaseJsonUtils.writeValueAsBytes(msg))
                .buildKey(msg.getDialogueCallBackDTO().getDialogueGuid())
                .build();
//        Map<String, String> headers = new HashMap<>();
//        message.setHeaders(headers);
//        Hms.send(TOPIC, message);
        Hms.sendAsync(TOPIC, message, new HmsCallBack() {
            @Override
            public void onException(Throwable throwable) {
                // 正常情况下，发送不会失败
                log.error("ChannelDialogueMsgProducer消息:{}异步发送失败", msg.getDialogueCallBackDTO().getDialogueGuid(), throwable);
            }

            @Override
            public void onResult(SendResponse sendResponse) {

            }
        });
    }
}
