package com.hellobike.aicc.infrastructure.convert;

import com.hellobike.aicc.infrastructure.notify.dingding.dto.DingMsgDTO;
import com.hellobike.unkonw.common.log.alert.model.DingMsg;
import org.mapstruct.Mapper;

/**
 * @author chenkangkang
 * @date 2023/12/6
 **/
@Mapper(componentModel = "spring")
public interface DingMsgConvert {


    /**
     * 转化
     *
     * @param source 源
     * @return 目标
     */
    DingMsg convert(DingMsgDTO source);
}
