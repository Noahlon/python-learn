package com.hellobike.aicc.infrastructure.persistence.single.repository;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DeleteEnum;
import com.hellobike.aicc.domain.distribute.dto.DistributePlanStatQryConditionDTO;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanStatEntity;
import com.hellobike.aicc.domain.distribute.repo.DistributePlanStatRepo;
import com.hellobike.aicc.infrastructure.convert.DistributePlanStatInfConvert;
import com.hellobike.aicc.infrastructure.persistence.single.mapper.DistributePlanStatMapper;
import com.hellobike.aicc.infrastructure.persistence.single.po.DistributePlanStatPO;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * 数据密级S2,分流计划统计表 服务实现类
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-05-27
 */
@Service
public class DistributePlanStatRepositoryImpl extends ServiceImpl<DistributePlanStatMapper, DistributePlanStatPO> implements DistributePlanStatRepo {

    @Resource
    private DistributePlanStatInfConvert convert;

    @Override
    public boolean saveOrUpdate(DistributePlanStatEntity statEntity) {
        DistributePlanStatPO po = convert.toPO(statEntity);
        LambdaUpdateWrapper<DistributePlanStatPO> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(DistributePlanStatPO::getDistributePlanId, po.getDistributePlanId());
        return saveOrUpdate(po, updateWrapper);
    }

    @Override
    public PageResult<DistributePlanStatEntity> pageQry(DistributePlanStatQryConditionDTO condition) {
        LambdaQueryWrapper<DistributePlanStatPO> queryWrapper = buildQueryWrapper(condition);
        queryWrapper.orderByDesc(DistributePlanStatPO::getPlanCreateTime);
        Page<DistributePlanStatPO> page = new Page<>(condition.getPageNum(), condition.getPageSize());
        this.page(page, queryWrapper);
        List<DistributePlanStatPO> records = page.getRecords();
        if (CollectionUtil.isEmpty(records)) {
            return PageResult.getEmptyPage(condition.getPageNum(), condition.getPageSize());
        }
        List<DistributePlanStatEntity> entity = convert.toEntity(records);
        PageResult<DistributePlanStatEntity> pageResult = new PageResult<>((int) page.getCurrent(), (int) page.getSize(), page.getTotal(), entity);
        return pageResult;
    }

    private LambdaQueryWrapper<DistributePlanStatPO> buildQueryWrapper(DistributePlanStatQryConditionDTO condition) {
        LambdaQueryWrapper<DistributePlanStatPO> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DistributePlanStatPO::getIsDelete, DeleteEnum.NO.getCode())
                .eq(StrUtil.isNotBlank(condition.getTenantId()) , DistributePlanStatPO::getTenantId, condition.getTenantId())
                .eq(Objects.nonNull(condition.getDistributePlanId()), DistributePlanStatPO::getDistributePlanId, condition.getDistributePlanId())
                .like(StrUtil.isNotBlank(condition.getDistributePlanName()), DistributePlanStatPO::getDistributePlanName, condition.getDistributePlanName())
                .ge(Objects.nonNull(condition.getPlanCreateTimeStart()), DistributePlanStatPO::getPlanCreateTime, condition.getPlanCreateTimeStart())
                .le(Objects.nonNull(condition.getPlanCreateTimeEnd()), DistributePlanStatPO::getPlanCreateTime, condition.getPlanCreateTimeEnd());
        return queryWrapper;
    }

    @Override
    public List<DistributePlanStatEntity> queryByCondition(DistributePlanStatQryConditionDTO conditionDTO) {
        LambdaQueryWrapper<DistributePlanStatPO> wrapper = buildQueryWrapper(conditionDTO);
        List<DistributePlanStatPO> poList = this.list(wrapper);
        if (CollectionUtil.isEmpty(poList)){
            return Collections.emptyList();
        }
        return convert.toEntity(poList);
    }
}
