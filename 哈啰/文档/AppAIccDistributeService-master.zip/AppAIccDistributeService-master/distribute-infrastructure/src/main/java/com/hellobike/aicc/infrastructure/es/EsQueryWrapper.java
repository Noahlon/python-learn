package com.hellobike.aicc.infrastructure.es;

import cn.hutool.core.util.StrUtil;
import com.alibaba.nacos.common.utils.CollectionUtils;
import org.apache.lucene.search.join.ScoreMode;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Objects;
import java.util.function.Function;


public class EsQueryWrapper {
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    private BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();

    private Object[] searchAfterValues;

    public EsQueryWrapper and(QueryBuilder queryBuilder) {
        if (Objects.nonNull(queryBuilder)) {
            boolQueryBuilder.filter(queryBuilder);
        }
        return this;
    }

    protected EsQueryWrapper range(String fieldName, Object from, Object to) {
        if (from instanceof LocalDateTime) {
            from = ((LocalDateTime) from).format(TIME_FORMATTER);
        }
        if (to instanceof LocalDateTime) {
            to = ((LocalDateTime) to).format(TIME_FORMATTER);
        }
        if (Objects.nonNull(from) && Objects.isNull(to)) {
            return and(QueryBuilders.rangeQuery(fieldName).gte(from));
        }
        if (Objects.isNull(from) && Objects.nonNull(to)) {
            return and(QueryBuilders.rangeQuery(fieldName).lt(to));
        }
        return Objects.nonNull(from) && Objects.nonNull(to) ? and(QueryBuilders.rangeQuery(fieldName).gte(from).lt(to)) : this;
    }

    public EsQueryWrapper eq(String fieldName, String fieldValue) {
        return Objects.nonNull(fieldName) && !StrUtil.isEmpty(fieldValue) ? and(QueryBuilders.termQuery(fieldName, fieldValue)) : this;
    }

    public EsQueryWrapper eqs(String fieldName, Collection<?> fieldValues) {
        return Objects.nonNull(fieldName) && CollectionUtils.isNotEmpty(fieldValues) ? and(QueryBuilders.termsQuery(fieldName, fieldValues)) : this;
    }

    public EsQueryWrapper must(String fieldName) {
        return Objects.nonNull(fieldName) ? and(QueryBuilders.boolQuery().must(QueryBuilders.existsQuery(fieldName))) : this;
    }

    public EsQueryWrapper mustNot(String fieldName) {
        return Objects.nonNull(fieldName) ? and(QueryBuilders.boolQuery().mustNot(QueryBuilders.existsQuery(fieldName))) : this;
    }

    public EsQueryWrapper wildcard(String fieldName, String fieldValue) {
        return Objects.nonNull(fieldName) && !StrUtil.isEmpty(fieldValue) ? and(QueryBuilders.wildcardQuery(fieldName, fieldValue)) : this;
    }

    public EsQueryWrapper regexp(String fieldName, String regexp) {
        return Objects.nonNull(fieldName) && Objects.nonNull(regexp) ? and(QueryBuilders.regexpQuery(fieldName, regexp)) : this;
    }

    public EsQueryWrapper like(String fieldName, String fieldValue) {
        return Objects.nonNull(fieldName) && Objects.nonNull(fieldValue) ? and(QueryBuilders.fuzzyQuery(fieldName, fieldValue)) : this;
    }

    public EsQueryWrapper likePrefix(String fieldName, String fieldValue) {
        return Objects.nonNull(fieldName) && Objects.nonNull(fieldValue) ? and(QueryBuilders.prefixQuery(fieldName, fieldValue)) : this;
    }

    public EsQueryWrapper gt(String fieldName, String fieldValue) {
        return Objects.nonNull(fieldName) && Objects.nonNull(fieldValue) ? and(QueryBuilders.rangeQuery(fieldName).gt(fieldValue)) : this;
    }

    public EsQueryWrapper gte(String fieldName, String fieldValue) {
        return Objects.nonNull(fieldName) && Objects.nonNull(fieldValue) ? and(QueryBuilders.rangeQuery(fieldName).gte(fieldValue)) : this;
    }

    public EsQueryWrapper lt(String fieldName, String fieldValue) {
        return Objects.nonNull(fieldName) && Objects.nonNull(fieldValue) ? and(QueryBuilders.rangeQuery(fieldName).lt(fieldValue)) : this;
    }

    public EsQueryWrapper lte(String fieldName, String fieldValue) {
        return Objects.nonNull(fieldName) && Objects.nonNull(fieldValue) ? and(QueryBuilders.rangeQuery(fieldName).lte(fieldValue)) : this;
    }

    public BoolQueryBuilder build() {
        return this.boolQueryBuilder;
    }

    public EsQueryWrapper should(Function<EsQueryWrapper, EsQueryWrapper>... functions) {
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        for (Function<EsQueryWrapper, EsQueryWrapper> function : functions) {
            boolQueryBuilder.should().add(function.apply(new EsQueryWrapper()).build());
        }
        and(boolQueryBuilder);
        return this;
    }

    public EsQueryWrapper nested(String path, Function<EsQueryWrapper, EsQueryWrapper> function) {
        EsQueryWrapper b = function.apply(new EsQueryWrapper());

        return and(QueryBuilders.nestedQuery(path, b.build(), ScoreMode.None));
    }

    public Object[] getSearchAfterValues() {
        return searchAfterValues;
    }

    public void setSearchAfterValues(Object[] searchAfterValues) {
        this.searchAfterValues = searchAfterValues;
    }

}

