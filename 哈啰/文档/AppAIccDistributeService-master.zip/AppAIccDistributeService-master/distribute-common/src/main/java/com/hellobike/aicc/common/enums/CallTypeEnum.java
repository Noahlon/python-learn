package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-03-17  15:07:25
 */
@Getter
@AllArgsConstructor
public enum CallTypeEnum {

    AI(1, "AI外呼"),
    HUMAN(2, "人工座席");

    private final Integer code;
    private final String desc;

    public static String getDescByCode(Integer code) {
        for (CallTypeEnum value : values()) {
            if (value.getCode().equals(code)) {
                return value.desc;
            }
        }
        return null;
    }
    public static CallTypeEnum getEnumByCode(Integer code) {
        for (CallTypeEnum value : values()) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }
}
