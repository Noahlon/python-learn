package com.hellobike.aicc.common.util;

import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nonnull;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

public class DateUtils extends org.apache.commons.lang3.time.DateUtils {

    public static final String DEFAULT_FORMAT_STR = "yyyy-MM-dd HH:mm:ss";
    public static final String DEFAULT_FORMAT_XG_STR = "yyyy/MM/dd HH:mm:ss";
    public static final String MS_FORMAT_STR = "yyyy-MM-dd HH:mm:ss.SSS";
    public static final String DATE_FORMAT_STR = "yyyy-MM-dd";
    public static final String ES_DATE_FORMAT_STR = "yyyyMMdd";

    public static final String MONTH_ES_DATE_FORMAT_STR = "yyyyMM";
    public static final String TIME_FORMAT_STR = "HH:mm:ss";

    public static final String TIME_MIN_FORMAT_STR = "HH:mm";

    public static final String DATE_TO_STRING_YM_PATTERN = "yyyy-MM";
    public static final String PURE_DATETIME_PATTERN = "yyyyMMddHHmmss";

    public static final DateTimeFormatter YYYYMMDD_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");
    public static final DateTimeFormatter YYYYMMDD_FORMATTER_SHORT = DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss");

    public static final DateTimeFormatter YYYYMMDDHHMMSS_FORMATTER_VARIABLE = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
    public static final DateTimeFormatter HHMMSS_FORMATTER_VARIABLE = DateTimeFormatter.ofPattern("HH:mm:ss");
    public static final DateTimeFormatter YYYYMMDD_FORMATTER_VARIABLE = DateTimeFormatter.ofPattern("yyyy/MM/dd");

    public static final DateTimeFormatter DEFAULT_FORMATTER = DateTimeFormatter.ofPattern(DEFAULT_FORMAT_STR);
    private static final DateTimeFormatter MS_FORMATTER = DateTimeFormatter.ofPattern(MS_FORMAT_STR);

    private static final DateTimeFormatter TIME_MIN_FORMATTER = DateTimeFormatter.ofPattern(TIME_MIN_FORMAT_STR);

    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern(DATE_FORMAT_STR);
    public static final DateTimeFormatter ES_DATE_FORMATTER = DateTimeFormatter.ofPattern(ES_DATE_FORMAT_STR);

    public static final DateTimeFormatter MONTH_ES_DATE_FORMATTER = DateTimeFormatter.ofPattern(MONTH_ES_DATE_FORMAT_STR);
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern(TIME_FORMAT_STR);

    private static final DateTimeFormatter SIMPLE_DATE_FORMATTER = DateTimeFormatter.ofPattern("MM/dd");

    public static final DateTimeFormatter PURE_DATETIME_FORMATTER = DateTimeFormatter.ofPattern(PURE_DATETIME_PATTERN);

    public static final DateTimeFormatter YM_FORMATTER = DateTimeFormatter.ofPattern(DATE_TO_STRING_YM_PATTERN);

    public static final DateTimeFormatter YM_D1_FORMATTER = new DateTimeFormatterBuilder()
            .appendPattern(DATE_TO_STRING_YM_PATTERN)
            .parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
            .toFormatter();

    private static final ThreadLocal<SimpleDateFormat> DEFAULT_SDF = ThreadLocal.withInitial(() -> new SimpleDateFormat(DEFAULT_FORMAT_STR));



    /**
     * 判断两个日期相差的时长，是否超出指定值
     *
     * @param beginDate 起始日期
     * @param endDate   结束日期
     * @param second    需要判断超出的时间，单位秒
     */
    public static boolean isTimeOver(Date beginDate, Date endDate, long second) {
        if (beginDate == null || endDate == null) {
            return false;
        }
        if (beginDate.before(endDate)) {
            return false;
        }

        return DateUtil.between(beginDate, endDate, DateUnit.SECOND) > second;
    }

    /**
     * 判断两个日期相差的时长，是否超出指定值
     *
     * @param beginDate 起始日期
     * @param endDate   结束日期
     * @param days      需要判断超出的时间，单位天
     */
    public static boolean isInvalid(Date beginDate, Date endDate, long days) {
        if (beginDate == null || endDate == null) {
            return false;
        }
        if (beginDate.before(endDate)) {
            return false;
        }
        return DateUtil.between(beginDate, endDate, DateUnit.SECOND) > days * 24 * 60 * 60;
    }

    /**
     * 判断两个日期相差的时长，是否超出指定值
     *
     * @param beginDate 起始日期
     * @param endDate   结束日期
     */
    public static int differentDay(Date beginDate, Date endDate) {
        if (beginDate == null || endDate == null) {
            return 0;
        }
        if (beginDate.before(endDate)) {
            return 0;
        }
        return (int) ((beginDate.getTime() - endDate.getTime()) / (24 * 60 * 60 * 1000));
    }

    /**
     * 获取当天的结束时间
     */
    public static Date getCurrentDayEndDate() {
        return Date.from(LocalDateTime.of(LocalDate.now(), LocalTime.MAX).atZone(ZoneId.systemDefault()).toInstant());
    }

    public static String format(Date date) {
        if (date == null) {
            return "";
        }
        return DEFAULT_SDF.get().format(date);
    }

    public static String format(LocalDateTime time) {
        if (time == null) {
            return null;
        }
        return DEFAULT_FORMATTER.format(time);
    }

    public static String format2MilliSecond(LocalDateTime time) {
        if (time == null) {
            return "";
        }
        return MS_FORMATTER.format(time);
    }

    public static String formatEsIndex(LocalDateTime time) {
        if (time == null) {
            return "";
        }
        return ES_DATE_FORMATTER.format(time);
    }

    public static List<String> getDatesBetween(LocalDateTime start, LocalDateTime end) {
        // 空值检查
        if (start == null || end == null || start.isAfter(end)) {
            return new ArrayList<>();
        }

        // 提取日期部分
        LocalDate startDate = start.toLocalDate();
        LocalDate endDate = end.toLocalDate();

        // 生成日期范围并格式化
        List<String> dateList = new ArrayList<>();
        for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusDays(1)) {
            dateList.add(date.format(ES_DATE_FORMATTER));
        }

        return dateList;
    }

    public static String formatMonthEsIndex(LocalDateTime time) {
        if (time == null) {
            return "";
        }
        return MONTH_ES_DATE_FORMATTER.format(time);
    }

    public static long toTimeMillis(LocalDateTime time) {
        return time.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

    /**
     * 获取当前月的开始时间
     */
    public static LocalDateTime getCurrentMonthStart() {
        return LocalDateTime.of(LocalDateTime.now().with(TemporalAdjusters.firstDayOfMonth()).toLocalDate(), LocalTime.MIN);
    }

    /**
     * 获取当前月的结束时间
     */
    public static LocalDateTime getCurrentMonthEnd() {
        return LocalDateTime.of(LocalDateTime.now().with(TemporalAdjusters.lastDayOfMonth()).toLocalDate(), LocalTime.MAX);
    }

    /**
     * 获取当天的开始时间
     */
    public static LocalDateTime getCurrentDayStart() {
        return LocalDateTime.of(LocalDate.now(), LocalTime.MIN);
    }

    /**
     * 获取当天的结束时间
     */
    public static LocalDateTime getCurrentDayEnd() {
        return LocalDateTime.of(LocalDate.now(), LocalTime.MAX);
    }

    /**
     * LocalDateTime 转成 Date
     */
    public static Date toDate(LocalDateTime time) {
        if (time == null) {
            return null;
        }
        return Date.from(time.atZone(ZoneId.systemDefault()).toInstant());
    }

    public static Date toDate(String date) {
        if (StringUtils.isEmpty(date)) {
            return null;
        }
        try {
            return DEFAULT_SDF.get().parse(date);
        } catch (ParseException e) {
            return null;
        }
    }

    public static LocalDateTime toLocalDateTime(@Nonnull Date date) {
        return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
    }

    /**
     * 是否是当天
     */
    public static boolean isToday(Date date) {
        if (date == null) {
            return false;
        }
        LocalDate localDate = toLocalDateTime(date).toLocalDate();
        return LocalDate.now().isEqual(localDate);
    }

    public static boolean isToday(LocalDateTime localDateTime) {
        if (localDateTime == null) {
            return false;
        }
        return LocalDate.now().isEqual(localDateTime.toLocalDate());
    }

    public static LocalDateTime toLocalDateTime(String time) {
        if (StringUtils.isEmpty(time)) {
            return null;
        }

        return LocalDateTime.parse(time, DEFAULT_FORMATTER);
    }

    public static LocalDateTime toMilliSecondLocalDateTime(String time) {
        if (StringUtils.isEmpty(time)) {
            return null;
        }

        return LocalDateTime.parse(time, MS_FORMATTER);
    }

    /**
     * 2023-12-25 11:18:12 -> LocalDateTime
     *
     * @param time
     */
    public static LocalDateTime toSecondLocalDateTime(String time, DateTimeFormatter dateTimeFormatter) {
        if (StrUtil.isBlank(time)) {
            return null;
        }

        return LocalDateTime.parse(time, dateTimeFormatter);
    }

    public static LocalDate toLocalDate(String time, DateTimeFormatter dateTimeFormatter) {
        if (StringUtils.isEmpty(time)) {
            return null;
        }
        return LocalDate.parse(time, dateTimeFormatter);
    }

    public static Date getFirstNonnullDate(Date... dates) {
        for (Date date : dates) {
            if (date != null) {
                return date;
            }
        }
        return null;
    }

    /**
     * 获取最早的时间
     */
    public static Date getEarliestDate(Date... dates) {
        return Stream.of(dates)
                .filter(Objects::nonNull)
                .min(Date::compareTo)
                .orElse(null);
    }

    /**
     * 获取最早的时间
     */
    public static LocalDateTime getEarliestDate(LocalDateTime... times) {
        return Stream.of(times)
                .filter(Objects::nonNull)
                .min(LocalDateTime::compareTo)
                .orElse(null);
    }

    /**
     * 获取最晚的时间
     */
    public static Date getLatestDate(Date... dates) {
        return Stream.of(dates)
                .filter(Objects::nonNull)
                .max(Date::compareTo)
                .orElse(null);
    }

    /**
     * 把时分秒转换成秒
     */
    public static Integer parseSeconds(String localTime) {
        if (StringUtils.isEmpty(localTime)) {
            return null;
        }
        return TIME_FORMATTER.parse(localTime).get(ChronoField.SECOND_OF_DAY);
    }

    /**
     * 把时分秒转换成秒
     */
    public static LocalTime parseLocalTime(String localTime) {
        if (StringUtils.isEmpty(localTime)) {
            return null;
        }
        return LocalTime.parse(localTime, TIME_MIN_FORMATTER);
    }

    public static String formatLocalTime(LocalTime localTime) {
        if (localTime == null) {
            return null;
        }
        return TIME_FORMATTER.format(localTime);
    }

    public static String getDateString(LocalDate date) {
        return YYYYMMDD_FORMATTER.format(date);
    }

    public static String getDatetimeString(LocalDateTime date, DateTimeFormatter dateTimeFormatter) {
        return dateTimeFormatter.format(date);
    }

    public static String getDateTimeString(LocalDateTime localDateTime) {
        return DEFAULT_FORMATTER.format(localDateTime);
    }

    public static String getDayString(LocalDateTime localDateTime) {
        return DATE_FORMATTER.format(localDateTime);
    }

    public static String getDayString(LocalDate localDate) {
        return DATE_FORMATTER.format(localDate);
    }

    /**
     * 计算统计时间
     *
     * @param dateTime
     * @param interval
     * @param flag     true:向上取整，false 向下取整
     * @return
     */
    public static LocalDateTime computeIntervalTime(LocalDateTime dateTime, Integer interval, boolean flag) {
        if (interval <= 0) {
            return dateTime;
        }
        int min = dateTime.getMinute();
        int count = min / interval;
        if (flag) {
            return dateTime.withMinute(count * interval).withSecond(0).withNano(0).plusMinutes(min % interval > 0 ? interval : 0);
        } else {
            return dateTime.withMinute(count * interval).withSecond(0).withNano(0);
        }
    }

    public static String localDate2SimpleStr(LocalDate localDate) {
        return SIMPLE_DATE_FORMATTER.format(localDate);
    }

    public static String localDateTimeSimpleStr(String timeStr) {
        LocalDateTime localDateTime = toSecondLocalDateTime(timeStr, DEFAULT_FORMATTER);
        return SIMPLE_DATE_FORMATTER.format(localDateTime);
    }

    /**
     * 计算俩个时间的分钟差
     *
     * @param start
     * @param end
     * @return
     */
    public static int computeDifferenceWithMin(LocalDateTime start, LocalDateTime end) {
        if (start == null || end == null) {
            return 0;
        }
        if (start.isAfter(end)) {
            return 0;
        }
        long startInstant = start.toEpochSecond(ZoneOffset.UTC);
        long endInstant = end.toEpochSecond(ZoneOffset.UTC);
        return (int) ((endInstant - startInstant) / 60);
    }

    public static String formatLocalDate(LocalDate localDate, DateTimeFormatter formatter) {
        if (Objects.isNull(localDate)) {
            return null;
        }
        return localDate.format(formatter);
    }

    public static String formatLocalDateTime(LocalDateTime localDateTime, DateTimeFormatter formatter) {
        if (Objects.isNull(localDateTime)) {
            return null;
        }
        return localDateTime.format(formatter);
    }


    public static boolean isVariableDate(String dateStr) {
        try {
            if (dateStr.length() == 19) {
                return LocalDateTime.parse(dateStr, YYYYMMDDHHMMSS_FORMATTER_VARIABLE) != null;
            } else if (dateStr.contains(":")) {
                return LocalTime.parse(dateStr, HHMMSS_FORMATTER_VARIABLE) != null;
            } else {
                return LocalDate.parse(dateStr, YYYYMMDD_FORMATTER_VARIABLE) != null;
            }
        } catch (Exception ex) {
        }
        return false;
    }

    /**
     * 时间戳转化dateTime
     * timestampForString 为秒，不为毫秒
     *
     * @return {@link LocalDateTime}
     */
    public static LocalDateTime timestamp2DateTime(String timestampForString) {
        if (StrUtil.isEmpty(timestampForString)) {
            return null;
        }
        long timestamp = Long.parseLong(timestampForString);
        return LocalDateTime.ofEpochSecond(timestamp, 0, ZoneOffset.ofHours(8));
    }

    /**
     * 时间戳转化dateTime
     *
     * @return {@link LocalDateTime}
     */
    public static LocalDateTime timestamp2DateTime(Long timestamp) {
        if (Objects.isNull(timestamp)) {
            return null;
        }
        return LocalDateTime.ofEpochSecond(timestamp / 1000, 0, ZoneOffset.ofHours(8));
    }

    ;

    /**
     * 获取当前时间的秒级别 当前时间2023-12-25 11:18:12 得到的结果是2023-12-25 11:18:00
     *
     * @return
     */
    public static LocalDateTime getMinSecond(LocalDateTime localDateTime) {
        if (Objects.isNull(localDateTime)) {
            return null;
        }

        // 如果当前时间的秒数不为0，将秒数设置为0
        if (localDateTime.getSecond() != 0) {
            localDateTime = localDateTime.minusSeconds(localDateTime.getSecond());
        }
        return toSecondLocalDateTime(localDateTime.format(DEFAULT_FORMATTER), DEFAULT_FORMATTER);
    }

    /**
     * 获取当前时间往后的整roundMinutes分钟
     * 如果 roundMinutes == 5
     * 2023-11-15 17:35:00 返回 2023-11-15 17:35:00
     * 2023-11-15 17:38:39 返回 2023-11-15 17:40:00
     * 2023-11-15 17:31:39 返回 2023-11-15 17:35:00
     *
     * @param currentTime
     * @param roundMinutes
     * @return
     */
    public static LocalDateTime getNearestRoundTime(LocalDateTime currentTime, int roundMinutes) {
        int currentMinutes = currentTime.getMinute();
        int remainder = currentMinutes % roundMinutes;
        int offsetMinutes = remainder == 0 ? 0 : roundMinutes - remainder;

        return currentTime.plusMinutes(offsetMinutes).withSecond(0).withNano(0);
    }

    /**
     * 秒数转换为x分x秒格式
     *
     * @param second
     * @return
     */
    public static String formatMinuteSecond(Integer second) {
        if (null == second || second <= 0) {
            return "0秒";
        }
        if (second < 60) {
            return String.format("%02d秒", second);
        }
        int minute = second / 60;
        int modSecond = second % 60;
        return String.format("%d分%02d秒", minute, modSecond);
    }

    /**
     * 寻找两个时间之间的月份
     */
    public static List<String> getMonthBetween(LocalDateTime startDate, LocalDateTime endDate) {
        List<String> monthList = new ArrayList<>();
        if (startDate == null || endDate == null || startDate.isAfter(endDate)) {
            return monthList;
        }

        // 标准化日期为月份的第一天零点（避免日期差异影响月份判断）
        LocalDateTime current = startDate.withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
        LocalDateTime targetEnd = endDate.withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);

        // 循环添加月份直到超出结束日期
        while (!current.isAfter(targetEnd)) {
            monthList.add(current.format(MONTH_ES_DATE_FORMATTER));
            current = current.plusMonths(1);
        }

        return monthList;
    }
}

