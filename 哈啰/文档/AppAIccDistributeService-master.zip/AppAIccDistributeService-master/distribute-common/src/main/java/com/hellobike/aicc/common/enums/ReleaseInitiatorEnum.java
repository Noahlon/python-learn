package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhangzhuoqi
 * @since 2025-03-17  15:40:36
 */
@AllArgsConstructor
@Getter
public enum ReleaseInitiatorEnum {

    UNKNOWN(0, "未知"),
    CALLER(1, "呼叫方"),
    CALLED_PARTY(2, "被叫方");

    private final Integer code;
    private final String desc;

    public static ReleaseInitiatorEnum getEnumByCode(Integer code) {
        for (ReleaseInitiatorEnum value : values()) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return UNKNOWN;
    }
}
