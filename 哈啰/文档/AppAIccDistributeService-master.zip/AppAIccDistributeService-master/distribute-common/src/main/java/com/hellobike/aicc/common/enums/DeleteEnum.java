package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhangzhuoqi
 * @since 2025-03-10  11:26:59
 */
@AllArgsConstructor
@Getter
public enum DeleteEnum {

    YES(1, "是"),
    NO(0, "否");

    private final Integer code;
    private final String desc;

}
