package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhangzhuoqi
 * @since 2025-03-10  11:00:50
 */
@AllArgsConstructor
@Getter
public enum UploadTypeEnum {

    INTERFACE(1, "接口上传"),
    MANUAL(2, "手动上传"),
    ;

    private final Integer code;

    private final String desc;
}
