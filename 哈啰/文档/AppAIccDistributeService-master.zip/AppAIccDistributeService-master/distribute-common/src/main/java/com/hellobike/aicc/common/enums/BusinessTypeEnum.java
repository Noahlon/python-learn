package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 业务模块标识
 *
 * @author zhangzhuoqi
 * @since 2024-06-04  20:43:43
 */
@AllArgsConstructor
@Getter
public enum BusinessTypeEnum {

    ROSTER("roster", "名单"),
    DIALOGUE("dialogue", "话单"),
    SMS("sms", "短信"),
    ;

    private final String type;
    private final String desc;
}
