package com.hellobike.aicc.common.util;


import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.exception.BusinessException;

import java.util.Collection;
import java.util.Objects;


/**
 * 异常断言工具类
 */
public class AssertUtils {

    public static void isTrue(boolean expression, BusinessErrorCode errorCode) {
        if (!expression) {
            throw new BusinessException(errorCode);
        }
    }

    public static void isTrue(boolean expression, BusinessErrorCode errorCode, String message) {
        if (!expression) {
            throw new BusinessException(errorCode, message);
        }
    }

    public static void isTrue(boolean expression, String message) {
        isTrue(expression, BusinessErrorCode.PARAMETER_ERROR, message);
    }

    public static void isFalse(boolean expression, BusinessErrorCode errorCode) {
        if (expression) {
            throw new BusinessException(errorCode);
        }
    }

    public static void isFalse(boolean expression, BusinessErrorCode errorCode, String message) {
        if (expression) {
            throw new BusinessException(errorCode, message);
        }
    }

    public static void isFalse(boolean expression, String message) {
        isFalse(expression, BusinessErrorCode.PARAMETER_ERROR, message);
    }

    public static void isNull(Object obj, BusinessErrorCode errorCode) {
        if (Objects.nonNull(obj)) {
            throw new BusinessException(errorCode);
        }
    }
    public static void isNull(Object obj, BusinessErrorCode errorCode, String message) {
        if (Objects.nonNull(obj)) {
            throw new BusinessException(errorCode, message);
        }
    }

    public static void isNull(Object obj, String message) {
        isNull(obj, BusinessErrorCode.PARAMETER_ERROR, message);
    }

    public static void notNull(Object obj, BusinessErrorCode errorCode, String message) {
        if (Objects.isNull(obj)) {
            throw new BusinessException(errorCode, message);
        }
    }

    public static void notNull(Object obj, BusinessErrorCode errorCode) {
        if (Objects.isNull(obj)) {
            throw new BusinessException(errorCode);
        }
    }

    public static void notNull(Object obj, String message) {
        notNull(obj, BusinessErrorCode.PARAMETER_ERROR, message);
    }

    public static void isBlank(String str, BusinessErrorCode errorCode, String message) {
        if (StrUtil.isNotBlank(str)) {
            throw new BusinessException(errorCode, message);
        }
    }

    public static void isBlank(String str, BusinessErrorCode errorCode) {
        if (StrUtil.isNotBlank(str)) {
            throw new BusinessException(errorCode);
        }
    }

    public static void isBlank(String str, String message) {
        isBlank(str, BusinessErrorCode.PARAMETER_ERROR, message);
    }

    public static void notBlank(String str, BusinessErrorCode errorCode, String message) {
        if (StrUtil.isBlank(str)) {
            throw new BusinessException(errorCode, message);
        }
    }

    public static void notBlank(String str, BusinessErrorCode errorCode) {
        if (StrUtil.isBlank(str)) {
            throw new BusinessException(errorCode);
        }
    }

    public static void notBlank(String str, String message) {
        notBlank(str, BusinessErrorCode.PARAMETER_ERROR, message);
    }

    public static void isEmpty(Collection<?> collection, String message) {
        isEmpty(collection, BusinessErrorCode.PARAMETER_ERROR, message);
    }

    public static void isEmpty(Collection<?> collection, BusinessErrorCode errorCode) {
        if (CollectionUtil.isNotEmpty(collection)) {
            throw new BusinessException(errorCode);
        }
    }

    public static void isEmpty(Collection<?> collection, BusinessErrorCode errorCode, String message) {
        if (CollectionUtil.isNotEmpty(collection)) {
            throw new BusinessException(errorCode, message);
        }
    }

    public static void notEmpty(Collection<?> collection, String message) {
        notEmpty(collection, BusinessErrorCode.PARAMETER_ERROR, message);
    }

    public static void notEmpty(Collection<?> collection, BusinessErrorCode errorCode) {
        if (CollectionUtil.isEmpty(collection)) {
            throw new BusinessException(errorCode);
        }
    }

    public static void notEmpty(Collection<?> collection, BusinessErrorCode errorCode, String message) {
        if (CollectionUtil.isEmpty(collection)) {
            throw new BusinessException(errorCode, message);
        }
    }
}
