package com.hellobike.aicc.common.util;

import cn.hutool.core.io.FileUtil;

import java.io.File;

/**
 * @author zhangzhuoqi
 * @since 2025-04-21  15:45:59
 */
public class FileUtils {

    public static String getTmpDirPath() {
        String tmpDir = System.getProperty("user.dir") + File.separator + "tmp" + File.separator;
        FileUtil.mkdir(tmpDir);
        return tmpDir;
    }

    public static String getFileExtension(String filename) {
        if (filename == null || filename.isEmpty()) {
            return "";
        }
        int dotIndex = filename.lastIndexOf('.');
        if (dotIndex == -1) {
            return ""; // 没有找到'.'，返回空字符串
        }
        // 如果'.'是文件名的第一个字符，则没有有效的扩展名
        if (dotIndex == 0) {
            return "";
        }
        // 提取并返回扩展名
        return filename.substring(dotIndex).toLowerCase();
    }
}
