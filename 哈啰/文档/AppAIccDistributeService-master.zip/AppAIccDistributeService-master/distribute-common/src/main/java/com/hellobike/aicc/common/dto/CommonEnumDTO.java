package com.hellobike.aicc.common.dto;

import lombok.Data;

/**
 * @author zhangzhuoqi
 * @since 2025-04-22  16:30:02
 */
@Data
public class CommonEnumDTO {

    private Integer code;

    private String value;
}
