package com.hellobike.aicc.common.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Component
public class HttpClientUtil {

    @Autowired
    private RestTemplate restTemplate;

    /**
     * 发送post请求，获取json结果
     *
     * @param uri       请求链接
     * @param body
     * @return 接口返回
     */
    public String post(String uri, Object body) {
        String result = StringUtils.EMPTY;
        try {
            return restTemplate.postForObject(uri, body, String.class);
        } catch (Exception e) {
            log.error("post请求：{}异常", uri, e);
        }
        return result;
    }


    public byte[] getForDownloadFile(String url) throws Exception {
        try{
            log.info("getForDownloadFile url:{}",url);
            return restTemplate.getForObject(url, byte[].class);
        }catch (Exception e){
            log.error("getForDownloadFile exception! {}", url,e);
            throw e;
        }
    }
}
