package com.hellobike.aicc.common.exception;

/**
 * 错误常量
 *
 * @author chenkangkang
 */
public interface ErrorCodeConstants {

    /**
     * 商业化错误信息
     */
    class BusinessPortalError {
        public static final int COMMON_ERROR = 499;
        public static final String COMMON_ERROR_MSG = "业务处理异常，请稍后重试";
        public static final int PARAMETER_ERROR = 400;
        public static final String PARAMETER_ERROR_MSG = "%s";

    }


    class DependencyError {
        public static final int COMMON_ERROR = 401;
        public static final String COMMON_ERROR_MSG = "%s";
    }

}
