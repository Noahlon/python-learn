package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhangzhuoqi
 * @since 2025-04-18  10:36:59
 */
@AllArgsConstructor
@Getter
public enum SpeakerEnum {

    CALLER(1, "呼叫方"),
    CALLED_PARTY(2, "被叫方");

    private final Integer code;
    private final String desc;

    public static SpeakerEnum getByCode(Integer code) {
        for (SpeakerEnum value : values()) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }
}
