package com.hellobike.aicc.common.util;

import java.util.HashSet;
import java.util.Set;

/**
 * 获取分表键
 *
 * @author zhangzhuoqi
 * @since 2025-03-18  20:55:49
 */
public class DBPartitionUtils {

    /**
     * 获取名单分表键
     * @param distributePlanId 分流计划id
     * @param phoneNum 手机号
     * @return
     */
    public static String getRosterPartitionCode(Long distributePlanId, String phoneNum) {
        //获取手机号最后一位
        String lastPhoneNum = phoneNum.substring(phoneNum.length() - 1);
        if (NumberChecker.isNumeric(lastPhoneNum)) {
            return distributePlanId + lastPhoneNum;
        } else {
            return String.valueOf(distributePlanId) + stringToRandomDigit(lastPhoneNum);
        }
    }

    /**
     * 获取名单所有分表键
     * @param distributePlanId 分流计划id
     * @return
     */
    public static Set<String> getAllRosterPartitionCode(Long distributePlanId) {
        Set<String> list = new HashSet<>();
        for (int i = 0; i < 10; i++) {
            list.add(String.valueOf(distributePlanId) + i);
        }
        return list;
    }

    private static int stringToRandomDigit(String s) {
        final int FNV_PRIME = 16777619;
        int hash = 0x811C9DC5; // FNV-1a 32位初始值

        for (char c : s.toCharArray()) {
            hash ^= c;       // 异或操作
            hash *= FNV_PRIME; // 乘法（自动溢出）
        }

        return Math.abs(hash) % 10;
    }
}
