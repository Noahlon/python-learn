package com.hellobike.aicc.common.util.export;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.excel.write.style.column.LongestMatchColumnWidthStyleStrategy;
import com.google.api.client.util.Lists;
import lombok.Data;

import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author zhangzhuoqi
 * @since 2025-04-25  11:23:21
 */
@Data
public class ExcelExporter implements Closeable {

    /**
     * 单Sheet最大行数（默认100w）
     */
    private static final Integer maxSheetRows = 100_0000;

    private Integer currentSheetIndex = 0;
    private Integer currentRowCount = 0;
    private ExcelWriter excelWriter;
    private WriteSheet currentSheet;
    private OutputStream outputStream;
    private List<ExportField> fields;
    private List<List<String>> headers;

    public static <T> ExcelExporter getInstance(OutputStream outputStream, Class<T> exportType,List<String> exportFields) {
        ExcelExporter excelExporter = new ExcelExporter();
        excelExporter.setOutputStream(outputStream);
        List<ExportField> fieldList = buildFields(exportType, exportFields);
        if (CollectionUtil.isEmpty(fieldList)){
            throw new IllegalArgumentException("导出字段为空");
        }
        ExcelWriter writer = EasyExcel.write(outputStream)
                .registerWriteHandler(new LongestMatchColumnWidthStyleStrategy())
                .build();
        excelExporter.setExcelWriter(writer);
        excelExporter.setFields(fieldList);
        List<List<String>> headerList = createHeaders(fieldList);
        excelExporter.setHeaders(headerList);
        excelExporter.setCurrentSheet(createNewSheet(0, headerList));
        return excelExporter;
    }
    public static <T> ExcelExporter getInstance(OutputStream outputStream, Class<T> exportType) {
        return getInstance(outputStream, exportType, null);
    }


    private static <T> List<ExportField> buildFields(Class<T> exportType, List<String> exportFields) {
        boolean isExportAll = CollectionUtil.isEmpty(exportFields);
        //获取当前对象的字段
        List<Field> fields = Lists.newArrayList(Arrays.asList(exportType.getDeclaredFields()));
        List<ExportField> fieldList = new ArrayList<>();
        Map<String , ExportField> fieldMap = new HashMap<>();
        for (Field field : fields) {
            ExcelProperty annotation = field.getAnnotation(ExcelProperty.class);
            if (annotation == null) {
                continue;
            }
            ExportField exportField = new ExportField();
            exportField.setFieldName(field.getName());
            exportField.setColumnName(annotation.value()[0]);
            fieldMap.put(field.getName(), exportField);
        }
        if (isExportAll){
            fieldList.addAll(fieldMap.values());
            return fieldList;
        }
        for (String exportField : exportFields) {
            if (!fieldMap.containsKey(exportField)){
                continue;
            }
            fieldList.add(fieldMap.get(exportField));
        }
        return fieldList;
    }

    public <T> void write(List<T> dataList) {

        if (CollectionUtil.isEmpty(dataList)) {
            return;
        }

        // 动态转换数据
        List<List<String>> dataMaps = convertData(dataList);

        // 判断是否需要新建Sheet
        if (currentRowCount + dataMaps.size() > maxSheetRows) {
            currentSheetIndex++;
            currentSheet = createNewSheet(currentSheetIndex, headers);
            currentRowCount = 0;
        }

        // 写入数据
        excelWriter.write(dataMaps, currentSheet);
        currentRowCount += dataMaps.size();

    }

    private static <T> WriteSheet createNewSheet(int sheetIndex, List<List<String>> headers) {
        return EasyExcel.writerSheet(sheetIndex, "Sheet" + sheetIndex)
                .head(headers)
                .build();
    }

    private static List<List<String>> createHeaders(List<ExportField> fields) {
        return fields.stream()
                .map(f -> Collections.singletonList(f.getColumnName()))
                .collect(Collectors.toList());
    }

    private <T> List<List<String>> convertData(List<T> data) {
        return data.stream().map(item -> {
            List<String> list = new ArrayList<>();
            fields.forEach(field -> {
                Object value = getFieldValue(item, field.getFieldName());
                list.add(value != null ? value.toString() : "");
            });
            return list;
        }).collect(Collectors.toList());
    }

    private Object getFieldValue(Object obj, String fieldName) {
        //todo zzq 反射缓存优化
        try {
            if (obj instanceof Map) {
                return ((Map<?, ?>) obj).get(fieldName);
            }
            Field field = obj.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            return field.get(obj);
        } catch (Exception e) {
            throw new RuntimeException("Error getting field value", e);
        }
    }

    public void finish(){
        if (excelWriter != null) {
            excelWriter.finish();
        }
    }

    @Override
    public void close() throws IOException {
        if (excelWriter != null) {
            excelWriter.close();
        }
    }
}
