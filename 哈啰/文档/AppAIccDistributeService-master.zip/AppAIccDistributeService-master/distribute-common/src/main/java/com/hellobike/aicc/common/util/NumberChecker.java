package com.hellobike.aicc.common.util;

/**
 * @author zhangzhuoqi
 * @since 2025-03-18  21:07:36
 */
public class NumberChecker {

    public static boolean isNumeric(String s) {
        if (s == null || s.isEmpty()) {
            return false;
        }
        int start = 0;
        if (s.charAt(0) == '-') { // 处理负数
            if (s.length() == 1) {
                return false; // 只有负号不合法
            }
            start = 1;
        }
        boolean dotFound = false; // 是否已经包含小数点
        for (int i = start; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '.') {
                if (dotFound) { // 只能有一个小数点
                    return false;
                }
                dotFound = true;
            } else if (c < '0' || c > '9') { // 非数字字符
                return false;
            }
        }
        return true;
    }
}
