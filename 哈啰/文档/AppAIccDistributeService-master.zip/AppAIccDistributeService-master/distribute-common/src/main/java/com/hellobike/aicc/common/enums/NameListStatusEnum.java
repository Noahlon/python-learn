package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 上传名单文件状态枚举
 */
@AllArgsConstructor
@Getter
public enum NameListStatusEnum {
    WAIT_PROCESS(0, "待处理"),

    PROCESSING(1, "处理中"),

    FINISHED(2, "完成"),

    FAILED(3, "失败");

    private final Integer code;

    private final String desc;
}
