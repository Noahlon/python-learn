package com.hellobike.aicc.common.exception;

import lombok.Getter;

/**
 * @author zhangzhuoqi
 * @since 2025-03-06  16:25:07
 */
@Getter
public enum BusinessErrorCode {

    /**
     * 通用异常
     */
    COMMON_ERROR(ErrorCodeConstants.BusinessPortalError.COMMON_ERROR, ErrorCodeConstants.BusinessPortalError.COMMON_ERROR_MSG),
    PARAMETER_ERROR(ErrorCodeConstants.BusinessPortalError.PARAMETER_ERROR, ErrorCodeConstants.BusinessPortalError.PARAMETER_ERROR_MSG),
    DEPENDENCY_ERROR(ErrorCodeConstants.DependencyError.COMMON_ERROR, ErrorCodeConstants.DependencyError.COMMON_ERROR_MSG),

    OSS_STS_TOKEN_ERROR(6001, "获取oss临时token失败"),

    /**
     * 分流错误 1001 ～ 1500
     */
    NO_PROCESSOR_ERROR(1001, "渠道商处理器不存在"),
    DIST_NOT_EXIST_ERROR(1002, "分流计划不存在"),
    DIST_RULE_NOT_EXIST_ERROR(1003, "分流规则为空"),
    TASK_NOT_SUCCESS(1004, "渠道任务尚未创建完成，暂不支持下发"),
    UPLOAD_STATUS_NOT_FAIL(1005, "该数据状态已更新请重试"),
    NOT_GET_PLAN_LOCK(1006, "未获取到分流计划锁"),
    NOT_GET_PRE_DIST_RECORD_ERROR(1007, "未查询到上传记录对应到预下发记录"),
    TASK_NOT_FAIL(1008, "该任务状态已更新，请刷新重试"),
    UPLOAD_STATUS_NOT_SUCCESS(1009, "当前上传记录尚未上传完成，请稍后再试"),
    RETRY_DIST_RECORD_EXIST(1010, "当前上传记录有准备下发的记录，无须再重试下发"),
    CHANNEL_TASK_RETRY_FAIL(1011, "任务创建失败，请重试或者联系开发同学帮忙排查问题"),
    NO_CHANNEL_ERROR(1012, "渠道商不存在"),
    TEMPLATE_NOT_EXIST(1013, "分流模版不存在"),


    /**
     * 名单错误 1501 ～ 2000
     */
    ROSTER_EMPTY(1501, "名单为空"),
    UPLOAD_RECORD_NOT_NULL(1502, "上传记录为空"),
    ROSTER_TASK_ERROR(1503, "名单绑定的任务在下发记录中不存在"),
    IMPORT_FILE_ERROR(1504, "文件格式有误"),
    IMPORT_SIZE_LIMIT_ERROR(1505, "导入名单数量超过限制"),
    IMPORT_DATA_ERROR(1506, "名单数据格式有误"),
    DOWNLOAD_FILE_ERROR(1507, "下载文件失败"),
    API_ROSTER_TENANT_ERROR(1508, "租户非法"),

    /**
     * 话单错误 2001 ～ 2500
     */
    DIALOGUE_CALL_BACK_NOT_EXIST(2001, "话单回调处理渠道商不存在"),
    UPLOAD_RECORD_NOT_ROSTER(2002, "当前上传记录中没有未下发的名单"),
    BUILD_CALL_BACK_ERROR(2003, "话单回调构建数据失败"),
    CALL_RECORD_EXPORT_IS_EMPTY(2004, "通话记录为空"),
    CALL_RECORD_EXPORT_URL_EMPTY(2005, "通话记录导出失败"),
    CALL_RECORD_EXPORT_ERROR(2006, "通话记录导出异常"),
    CALL_DIALOGUE_UPLOAD_OSS_ERROR(2007, "通话记录文件上传Oss失败"),

    /**
     * 渠道回调 3001~3500
     */
    CALL_BACK_ROSTER_ERROR(3001, "回调rosterKey不合法"),
    SAVE_SMS_RECORD_ERROR(3002, "保存短信记录失败"),

    /**
     * 短信错误 3501~4000
     */
    SMS_RECORD_EXPORT_IS_EMPTY(3501, "短信记录为空"),
    ;



    private final int code;
    private final String desc;

    BusinessErrorCode(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    /**
     * 仅做辅助使用，如果接口新增错误码但未及时发布或更新接口包则无法拿到枚举类
     *
     * @param code 错误码
     * @return 错误码枚举类
     */
    public static BusinessErrorCode of(int code) {
        for (BusinessErrorCode c : values()) {
            if (c.code == code) {
                return c;
            }
        }
        return null;
    }
}
