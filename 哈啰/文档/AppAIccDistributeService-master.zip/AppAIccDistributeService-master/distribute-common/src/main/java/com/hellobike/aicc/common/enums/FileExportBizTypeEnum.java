package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  10:25:39
 */
@AllArgsConstructor
@Getter
public enum FileExportBizTypeEnum {

    DIALOGUE(1, "通话记录"),

    SMS(2, "短信记录");

    private final Integer code;
    private final String desc;
}
