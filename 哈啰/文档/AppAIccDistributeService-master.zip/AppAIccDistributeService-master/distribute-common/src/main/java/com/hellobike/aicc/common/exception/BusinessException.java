/**
 * AssetException.java
 * Copyright 2019 HelloBike , all rights reserved.
 * HelloBike PROPRIETARY/CONFIDENTIAL, any form of usage is subject to approval.
 */

package com.hellobike.aicc.common.exception;

import lombok.Getter;

/**
 * @author oloer
 */
@Getter
public class BusinessException extends RuntimeException {
    private final BusinessErrorCode businessErrorCode;
    private final Object[] args;
    private Object data;

    public BusinessException(BusinessErrorCode assetErrorCode, Object... args) {
        this.businessErrorCode = assetErrorCode;
        this.args = args;
    }

    public BusinessException setData(Object data) {
        this.data = data;
        return this;
    }
}