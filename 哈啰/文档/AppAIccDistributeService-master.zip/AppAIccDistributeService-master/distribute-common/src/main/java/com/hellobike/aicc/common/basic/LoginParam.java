/*
 * LoginParam.java
 * Copyright 2022 HelloBike , all rights reserved.
 * HelloBike PROPRIETARY/CONFIDENTIAL, any form of usage is subject to approval.
 */

package com.hellobike.aicc.common.basic;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginParam {
    private BffLogin _user;

    private String bffAction;
}