package com.hellobike.aicc.common.component;

import cn.hutool.core.collection.CollectionUtil;
import com.hellobike.aicc.common.dto.DistPlanImpactRule;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-24  10:32:40
 */
@Data
@Component
public class ApolloConfigs {

    /**
     * 是否使用redis进行名单数据去重
     */
    @Value("${redis.dup.switch:true}")
    private Boolean useRedisRosterDup;

    /**
     * redis名单去重过期时间
     */
    @Value("${redis.dup.expire:30}")
    private Integer useRedisDupExpireSecond;

    /**
     * 名单入库每批次数量
     */
    @Value("${batch.save.name.list.size:200}")
    private Integer batchSaveNameListSize;

    /**
     * 上传记录聚合名单时间
     */
    @Value("${upload.record.agg.seconds:300}")
    private Integer uploadRecordAggSeconds;


    /**
     * 默认切流规则（外呼任务100%）
     */
    @Value("${default.dist.rule:null}")
    private String defaultDistRule;

    /**
     * 是否使用多线程保存名单
     */
    @Value("${useMultiTheadSaveRoster:true}")
    private Boolean useMultiTheadSaveRoster;

    /**
     * 钉钉告警token
     */
    @Value("${ding.talk.token:b22a445f096f94eaf37feeb60fbc25f073855627fe50c86845f63bb3b818eeff}")
    private String dingTalkToken;

    /**
     * 外呼通话结果映射配置
     */
    @Value("${css.callResult.mapping:}")
    private String cssCallResultMapping;

    @Value("${impactRule:}")
    private String impactRule;

    @Value("${impactLimit:5000}")
    private Integer impactLimit;

    @Value("${stat.v2.time:2023-05-26 15:00:00}")
    private String statV2Time;

    @Value("${business.stat.v2:true}")
    private Boolean businessStatV2;

    @Value("${stat.day.range:30}")
    private Integer statDayRange;

    @Value("${stat.day.query.range:30}")
    private Integer statQueryDayRange;

    @Value("${import.roster.limit:300}")
    private Integer importRosterLimit;

    @Value("${fileExport.oss.file.expire.day:15}")
    private int fileExportOssFileExpireDay;

    @Value("${fileExport.data.max.limit:500000}")
    private int fileExportDataMaxLimit;

    @Value("${sms.check.status.minutes:4320}")
    private int smsCheckStatusMinutes;

    @Value("${sms.check.status.minutes.end:1440}")
    private int smsCheckStatusMinutesEnd;

    /**
     * 获取撞库规则
     *
     * @param tenantId 租户id
     */
    public DistPlanImpactRule getImpactRuleByTenant(String tenantId) {
        List<DistPlanImpactRule> ruleDTOList = BaseJsonUtils.readValues(impactRule, DistPlanImpactRule.class);
        if (CollectionUtil.isEmpty(ruleDTOList)) {
            return null;
        }
        return ruleDTOList.stream()
                .filter(v -> v.getTenantId().equals(tenantId))
                .findFirst()
                .orElse(null);
    }
}
