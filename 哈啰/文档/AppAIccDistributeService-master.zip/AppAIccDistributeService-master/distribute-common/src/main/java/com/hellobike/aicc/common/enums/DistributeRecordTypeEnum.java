package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhangzhuoqi
 * @since 2025-03-17  10:31:45
 */
@Getter
@AllArgsConstructor
public enum DistributeRecordTypeEnum {

    PREPARE(1, "预下发"),
    FORMAL(2, "正式下发");


    private final Integer code;
    private final String desc;
}
