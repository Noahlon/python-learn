package com.hellobike.aicc.common.util.export;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author zhangzhuoqi
 * @since 2025-04-25  11:25:25
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExportField {

    private String columnName; // Excel列名
    private String fieldName;  // 对象属性名
}
