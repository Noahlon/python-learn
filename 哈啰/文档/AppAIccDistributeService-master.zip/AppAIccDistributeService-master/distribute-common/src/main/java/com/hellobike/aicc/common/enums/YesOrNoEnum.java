package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-03-17  11:34:47
 */
@AllArgsConstructor
@Getter
public enum YesOrNoEnum {
    NO(0, "否"),
    YES(1, "是");


    private final Integer code;
    private final String desc;
    public static String getDescByCode(Integer code) {
        for (YesOrNoEnum value : values()) {
            if (value.getCode().equals(code)) {
                return value.desc;
            }
        }
        return null;
    }
    public static YesOrNoEnum getEnumByCode(Integer code) {
        for (YesOrNoEnum value : YesOrNoEnum.values()) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }

}
