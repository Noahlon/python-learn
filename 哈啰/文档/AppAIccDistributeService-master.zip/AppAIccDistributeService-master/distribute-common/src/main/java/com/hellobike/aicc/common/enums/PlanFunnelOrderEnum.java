package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhengchenyang
 * @desc 分流计划漏斗顺序
 * @date 2025/04/22
 */

@AllArgsConstructor
@Getter
public enum PlanFunnelOrderEnum implements CommonFunnelEnum {
    /**
     * 上传名单总数
     */
    UPLOAD_NUM(1, "uploadDataNum", "上传名单数", false),

    CALL_ROSTER_SUM(2, "callRosterNum", "已呼叫名单数", false),

    THROUGH_ROSTER_NUM(3, "throughRosterNum", "名单接通量", false),

    SEND_SMS_NUM(4, "sendSmsSum", "发送短信名单数", false),

    SEND_SMS_SUC_NUM(5, "smsSuccSum", "短信成功名单量", false);

    private final Integer id;

    private final String code;

    private final String name;

    private final Boolean showFlag;

}
