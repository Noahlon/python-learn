package com.hellobike.aicc.common.util;

import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

@Slf4j
public class StringFieldUtils {

    /**
     * 将实体类中所有非静态String类型的null字段替换为空字符串
     * @param target 目标实体对象
     */
    public static void replaceNullStrings(Object target) {
        replaceNullStringsWith(target, "");
    }

    public static void replaceNullStringsWith(Object target, String replacement) {
        if (target == null) return;

        Class<?> clazz = target.getClass();

        while (clazz != null && clazz != Object.class) {
            for (Field field : clazz.getDeclaredFields()) {
                processField(field, target,replacement);
            }
            clazz = clazz.getSuperclass();
        }
    }

    private static void processField(Field field, Object target, String replacement) {
        try {
            // 跳过非String类型或静态字段
            if (field.getType() != String.class
                    || Modifier.isStatic(field.getModifiers())) {
                return;
            }

            // 保存原始访问权限
            boolean wasAccessible = field.isAccessible();

            try {
                // 解除访问限制（兼容Java 8）
                if (!wasAccessible) {
                    field.setAccessible(true);
                }

                // 获取字段值并替换null
                if (field.get(target) == null) {
                    field.set(target, replacement);
                }
            } finally {
                // 还原访问权限（如果原来不可访问）
                if (!wasAccessible) {
                    field.setAccessible(false);
                }
            }

        } catch (IllegalAccessException e) {
            log.error("字段处理失败: {}",field.getName(), e);
        }
    }
}