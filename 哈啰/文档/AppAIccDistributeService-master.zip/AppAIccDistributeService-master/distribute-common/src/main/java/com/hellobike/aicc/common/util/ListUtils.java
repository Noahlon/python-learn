package com.hellobike.aicc.common.util;

import cn.hutool.core.collection.CollectionUtil;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-06-09  14:40:07
 */
public class ListUtils {

    /**
     * 将集合均匀分割为count份
     *
     * @return List<List < T>>
     * @author zhangzhuoqi
     * @since 2025/6/9 14:40
     **/
    public static <T> List<List<T>> splitCollection(List<T> list, int count) {
        if (count <= 0) {
            throw new IllegalArgumentException("分割数必须大于0");
        }
        if (CollectionUtil.isEmpty(list)) {
            throw new IllegalArgumentException("输入集合不能为空");
        }


        int totalSize = list.size();
        int baseChunkSize = totalSize / count;  // 每份基础大小
        int remainder = totalSize % count;       // 余数，需分配到前remainder份

        List<List<T>> chunks = new ArrayList<>(count);
        int startIndex = 0;

        for (int i = 0; i < count; i++) {
            // 计算当前分片大小：前remainder份各加1
            int chunkSize = baseChunkSize + (i < remainder ? 1 : 0);

            // 如果最后几份可能为空（当threadCount > totalSize时）
            if (startIndex >= totalSize) {
                continue;
            }

            // 计算结束索引（不包括）
            int endIndex = Math.min(startIndex + chunkSize, totalSize);
            chunks.add(list.subList(startIndex, endIndex));
            startIndex = endIndex;
        }

        return chunks;
    }
}
