package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhangzhuoqi
 * @since 2025-03-10  10:54:34
 */
@AllArgsConstructor
@Getter
public enum UploadStatusEnum {
    /**
     * 待解析（文件上传了还未开始解析）
     */
    PENDING_ANALYSIS(0, "待解析"),
    FAIL(1, "上传失败"),
    UPLOAD_ING(2, "上传中"),
    UPLOAD_SUCCESS(3, "上传完成"),
    ;

    private final Integer code;

    private final String desc;
}
