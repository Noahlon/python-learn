package com.hellobike.aicc.common.basic;

import cn.hutool.core.collection.CollectionUtil;
import com.google.common.collect.Lists;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.Objects;

/**
 * @author older
 */
@Getter
@Setter
@NoArgsConstructor
public class PageResult<T> {

    public PageResult(Integer pageNum, Integer pageSize, Long totalRecord, List<T> list) {
        pageNum = Objects.nonNull(pageNum) ? pageNum : 1;
        pageSize = Objects.nonNull(pageSize) ? pageSize : 10;
        totalRecord = Objects.nonNull(totalRecord) ? totalRecord : 0;
        this.pageNum = pageNum;
        this.pageSize = pageSize;
        this.totalRecord = totalRecord;
        this.totalPages = totalRecord % pageSize == 0 ? totalRecord / pageSize : totalRecord / pageSize + 1;
        this.list = list;
    }

    private Integer pageNum;

    private Integer pageSize;

    private Long totalRecord;

    private Long totalPages;

    private List<T> list;

    public static <T> PageResult<T> getEmptyPage() {
        return new PageResult<>(1, 10, 0L, Lists.newArrayList());
    }

    public static <T> PageResult<T> getEmptyPage(Integer pageNum, Integer pageSize) {
        return new PageResult<>(pageNum, pageSize, 0L, Lists.newArrayList());
    }

    public <C> PageResult<C> clonePageResult(List<C> targetList) {
        return new PageResult<>(this.pageNum, this.pageSize, this.totalRecord, targetList);
    }

    public boolean isEmpty() {
        return CollectionUtil.isEmpty(this.list);
    }

}
