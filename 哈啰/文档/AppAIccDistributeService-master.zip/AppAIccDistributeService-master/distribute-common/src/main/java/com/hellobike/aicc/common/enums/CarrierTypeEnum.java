package com.hellobike.aicc.common.enums;

import cn.hutool.core.util.StrUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-03-17  15:30:11
 */
@Getter
@AllArgsConstructor
public enum CarrierTypeEnum {

    /**
     * 移动
     */
    CMCC(1,"移动"),
    /**
     * 联通
     */
    CUCC(2,"联通"),
    /**
     * 电信
     */
    CTCC(3,"电信"),
    /**
     * 虚拟
     */
    VIRTUAL(4,"虚拟"),
    /**
     * 未知
     */
    UN_KNOW(5,"未知");

    private final Integer code;
    private final String desc;

    public static CarrierTypeEnum getEnumByCode(Integer code) {
        if(Objects.isNull(code)) {
            return UN_KNOW;
        }
        CarrierTypeEnum[] values = CarrierTypeEnum.values();
        for (CarrierTypeEnum item : values) {
            if(Objects.equals(item.code, code)) {
                return item;
            }
        }
        return UN_KNOW;
    }

    public static CarrierTypeEnum getEnumByDesc(String carrier) {
        if (StrUtil.isBlank(carrier)){
            return UN_KNOW;
        }
        CarrierTypeEnum[] values = CarrierTypeEnum.values();
        for (CarrierTypeEnum item : values) {
            if(Objects.equals(item.desc, carrier.trim())) {
                return item;
            }
        }
        return UN_KNOW;
    }
}
