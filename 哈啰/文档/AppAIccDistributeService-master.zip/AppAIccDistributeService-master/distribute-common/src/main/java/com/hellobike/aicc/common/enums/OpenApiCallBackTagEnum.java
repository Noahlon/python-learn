package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhangzhuoqi
 * @since 2025-05-12  15:25:06
 */
@AllArgsConstructor
@Getter
public enum OpenApiCallBackTagEnum {


    TEMPLATE_LIST("channelTaskTemplateList", "查询渠道商任务模版"),
    CREATE_TASK("createChannelTask", "创建渠道任务"),
    IMPORT_ROSTER("importRoster", "上传名单");

    /**
     * 回调tag
     */
    private final String callBackTag;

    /**
     * 描述
     */
    private final String desc;

}
