package com.hellobike.aicc.common.dto;

import lombok.Data;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-04-11  10:59:51
 */
@Data
public class DistPlanImpactRule {
    /**
     * 租户id
     */
    private String tenantId;

    /**
     * 规则表达式
     */
    private String ruleExp;

    /**
     * 规则描述。示例"过滤非哈用户"
     */
    private String ruleDesc;

    /**
     * 规则列表
     */
    private List<String> ruleList;
}
