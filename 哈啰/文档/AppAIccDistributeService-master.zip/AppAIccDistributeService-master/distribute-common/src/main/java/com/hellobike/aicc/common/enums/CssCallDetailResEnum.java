package com.hellobike.aicc.common.enums;

import cn.hutool.core.util.StrUtil;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author caowei
 * date 2022-12-01
 */
public enum CssCallDetailResEnum {
//    INIT(-1000,"初始化"),
    TIMEOUT(-1,"超时"),
    SUCCESS(0,"已送呼"),
    CHATTING(2,"正在通话中"),
    FAIL(3,"无法接通"),
    TURN_OFF(4,"关机"),
    USER_BUSY(5,"用户正忙"),
    EMPTY_NUM(6,"空号"),
    WRONG_NUM(7,"号码错误"),
    USER_REJECT(8,"用户拒接"),
    PHONE_STOP(9,"停机"),
    USER_HANG_UP(15,"客户接听后并主动挂机"),
    USER_OFFLINE(16, "客户掉线"),
    THROUGH(18, "接通"),
    TRANSER_MANUAL(19, "转人工"),
    USER_NO_ACCEPT(20, "用户未接"),
    CALL_REMIND(22, "来电提醒"),
    CALL_IN_LIMIT(23, "呼入限制"),
    CALL_TRANSFER(25, "呼叫转移"),
    NETWORK_ERROR(26, "网络故障"),
    CALL_OUT_LIMIT(27, "呼出受限"),
    LINE_ERROR(28, "线路故障"),
    BLACK_LIST_ZHONGHONG(30, "未触达用户"),
    FAIL_TEMP(90, "无法接通-临时状态"),
    UNKNOWN(98, "未接通-原因未知"),
    BLACK_LIST(500, "平台黑名单"),
    CALL_FREQUENCY_LIMIT(501, "平台限频"),
    CALL_ROUTE_LINE_FAIL(502, "线路路由失败"),
    CALL_SAME_CALLED_NUMBER_FREQUENCY_LIMIT(503, "线路限频"),
    CALL_LINE_DAILY_FREQUENCY_LIMIT(504, "送呼上限限制"),
    CALL_AREA_LIMIT(505, "盲区限制"),
    CALL_NO_AVAILABLE_CONCURRENCY(506, "无可用并发"),
    CALL_NO_AVAILABLE_CITY_LINE(507, "归属地路由失败"),
    CALL_UNKNOWN_EXCEPTION(508, "业务未知异常"),
    OUTER_BLACK_LIST_SENSITIVE_NUMBER(511, "外部黑名单-敏感号码"),
    OUTER_BLACK_LIST_CALL_FREQUENCY_LIMIT(512, "外部黑名单-限频"),
    CALL_STRATEGY_LIMIT(513, "呼叫-限频"),
    THROUGH_STRATEGY_LIMIT(514, "接通-限频"),
    CALL_FEATURE_FREQUENCY_LIMIT(520,"标签限频"),
    CALL_CARRIER_TYPE_LIMIT(540,"运营商不支持"),
    CALL_ASSIGN_LINE_NO_AVAILABLE_CONCURRENCY(530,"指定线路无可用并发"),

    EXT_REJECT(1001, "座席拒接"),

    DEFAULT(-999, "未知的状态码")
    ;
    private Integer status;

    private String desc;

    CssCallDetailResEnum(Integer status, String desc) {

        this.status = status;
        this.desc = desc;
    }

    public Integer getStatus() {
        return status;
    }

    public String getDesc() {
        return desc;
    }

    public static CssCallDetailResEnum getEnumByStatus(Integer status) {
        if(Objects.isNull(status)) {
            return null;
        }
        for (CssCallDetailResEnum item : CssCallDetailResEnum.values()) {
            if(Objects.equals(item.status, status)) {
                return item;
            }
        }
        return DEFAULT;
    }

    public static Map<Integer, String> getAllEnumMaps(){
        CssCallDetailResEnum[] values = CssCallDetailResEnum.values();
        return Arrays.stream(values).collect(Collectors.toMap(CssCallDetailResEnum::getStatus, CssCallDetailResEnum::getDesc));
    }

    /**
     * 黑名单列表集合
     *
     * @return  黑名单的 Status 集合
     */
    public static List<Integer> blacklistStatusList(){
        return Arrays.asList(BLACK_LIST.status, OUTER_BLACK_LIST_SENSITIVE_NUMBER.status, OUTER_BLACK_LIST_CALL_FREQUENCY_LIMIT.status);
    }

    /**
     * 限频列表集合
     *
     * @return 限频的 Status 集合
     */
    public static List<Integer> frequencyLimitStatusList(){
        return Arrays.asList(CALL_FREQUENCY_LIMIT.status, CALL_SAME_CALLED_NUMBER_FREQUENCY_LIMIT.status);
    }

    /**
     * 标签限频列表集合
     *
     * @return 标签限频的 Status 集合
     */
    public static List<Integer> tagFrequencyLimitStatusList(){
        return Collections.singletonList(CALL_FEATURE_FREQUENCY_LIMIT.status);
    }


    /**
     * 描述是否存在
     *
     * @param resultDesc
     * @return
     */
    public static boolean descExist(String resultDesc) {
        if (StrUtil.isEmpty(resultDesc)) {
            return false;
        }
        return DESC_MAP.containsKey(resultDesc);
    }

    public static Integer getStatus(String desc) {
        if (StrUtil.isEmpty(desc)) {
            return DEFAULT.getStatus();
        }
        return DESC_MAP.get(desc);
    }


    public static final Map<Integer, String> STATUS_MAP;
    public static final Map<String, Integer> DESC_MAP;

    static {
        STATUS_MAP = new HashMap<>(64, 1);
        DESC_MAP = new HashMap<>(64, 1);
        for (CssCallDetailResEnum value : CssCallDetailResEnum.values()) {
            STATUS_MAP.put(value.getStatus(), value.getDesc());
            DESC_MAP.put(value.getDesc(), value.getStatus());
        }
    }



}
