package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;

/**
 * @author zhengchenyang
 * @date 2025/4/7
 * @desc 上传名单的类型
 */
@Getter
@AllArgsConstructor
public enum RosterTypeEnum {
    TELEPHONE(1, "明文"),

    MD5(2, "32位MD5");

    private final Integer code;
    private final String msg;

    private static final Map<Integer, RosterTypeEnum> CODE_TO_ENUM;

    private static final Pattern PHONE_PATTERN = Pattern.compile("^[0-9]{8,256}$");

    static {
        CODE_TO_ENUM = new HashMap<>();
        for (RosterTypeEnum value : RosterTypeEnum.values()) {
            CODE_TO_ENUM.put(value.getCode(), value);
        }
    }

    /**
     * 根据code获取msg
     *
     * @param code code
     * @return msg
     */
    public static String getMsgByCode(Integer code) {
        RosterTypeEnum rosterTypeEnum = CODE_TO_ENUM.get(code);
        if (Objects.isNull(rosterTypeEnum)) {
            return null;
        }
        return rosterTypeEnum.getMsg();
    }

    public static RosterTypeEnum getByCode(Integer code) {
        RosterTypeEnum rosterTypeEnum = CODE_TO_ENUM.get(code);
        if (Objects.isNull(rosterTypeEnum)) {
            return null;
        }
        return rosterTypeEnum;
    }

    public boolean check(String phoneNum) {
        switch (this) {
            case TELEPHONE:
                return PHONE_PATTERN.matcher(phoneNum).matches();
            case MD5:
                return phoneNum.length() == 32;
            default:
                return false;
        }
    }
}

