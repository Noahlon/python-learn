package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * 短信发送结果枚举
 */
@AllArgsConstructor
@Getter
public enum SmsSubmitResultEnum {
    SUCCESS(0, "提交成功"),

    FAILED(1, "提交失败");

    private final Integer code;

    private final String desc;

    public static SmsSubmitResultEnum getByCode(Integer code) {
        return Arrays.stream(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
    }
}
