package com.hellobike.aicc.common.util;

import com.hellobike.base.redis.core.model.key.Key;

/**
 * @author zhangzhuoqi
 * @since 2025-03-06  16:32:53
 */
public class RedisKeyUtils {
    /**
     * 4天超时
     */
    public static final int TIME_OUT_DAY = 60 * 60 * 24;

    public static final String ROSTER_DUPLICATE_KEY = "roster:duplicate:%s";

    /**
     * 离线分流锁
     */
    public static String asyncDistLockKey(Long distributePlanId) {
        return String.format("distribute:async:plan:%s", distributePlanId);
    }

    /**
     * 离线分流名单聚合操作
     */
    public static Key asyncDistRecorcKey(String uploadRecordId) {
        return Key.convertByFormat("distribute:async:uploadRecord:%s", uploadRecordId);
    }

    public static Key channelTaskCountKey(Long distributePlanId) {
        return Key.convertByFormat("channel.task.count:%s", distributePlanId);
    }

    /**
     * AI外呼话单锁
     */
    public static String cssDialogueLockKey(String dialogueId) {
        return String.format("distribute:dialogue:css:lock:%s", dialogueId);
    }

    /**
     * AI外呼短信记录锁
     */
    public static String cssSmsRecordLockKey(String smsId) {
        return String.format("distribute:sms:css:lock:%s", smsId);
    }

    /**
     * redis去重名单
     */
    public static Key redisDuplicate(String key) {
        return Key.convertByFormat(ROSTER_DUPLICATE_KEY, key);
    }
}
