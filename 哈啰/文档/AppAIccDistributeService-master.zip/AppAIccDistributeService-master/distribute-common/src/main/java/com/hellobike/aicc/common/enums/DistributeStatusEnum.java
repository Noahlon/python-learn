package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhangzhuoqi
 * @since 2025-03-10  10:57:34
 */

@AllArgsConstructor
@Getter
public enum DistributeStatusEnum {
    NOT_DISTRIBUTE(0, "无需下发"),
    PENDING(1, "未下发"),
    ING(2, "下发中"),
    SUCCESS(3, "下发完成"),

    /**
     * 渠道任务创建失败，此时状态为待下发，需要渠道任务重试创建成功后再次下发
     */
    FAIL(4, "下发失败"),
    ;


    private final Integer code;

    private final String desc;
}
