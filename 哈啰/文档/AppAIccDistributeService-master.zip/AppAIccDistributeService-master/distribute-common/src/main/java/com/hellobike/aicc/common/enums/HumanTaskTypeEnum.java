package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-03-17  15:03:46
 */
@AllArgsConstructor
@Getter
public enum HumanTaskTypeEnum {

    MANUAL_DELIVERY(0, "手动下发任务"),
    AI_CALL(1, "AI外呼任务"),
    FORECAST_CALL(2, "预测外呼任务"),
    HUMAN_MACHINE(3, "人机协作任务");

    private final Integer code;
    private final String desc;

    public static boolean isHumanCall(Integer code) {
        return Objects.equals(code, HumanTaskTypeEnum.MANUAL_DELIVERY.getCode())
                || Objects.equals(code, HumanTaskTypeEnum.FORECAST_CALL.getCode())
                || Objects.equals(code, HumanTaskTypeEnum.HUMAN_MACHINE.getCode());
    }
}
