package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

/**
 * @author zhangzhuoqi
 * @since 2025-04-22  16:25:23
 */
@AllArgsConstructor
@Getter
public enum ValueLableEnum {

    CALL_RESULT(1, CallResultEnum.class);

    private final Integer type;
    private final Class<? extends CommonEnum> enumClass;

    public static final Map<Integer, CommonEnum> ENUM_MAP = new HashMap<Integer, CommonEnum>(){
        private static final long serialVersionUID = 3795605570937010150L;
        {
        for (ValueLableEnum valueLableEnum : ValueLableEnum.values()) {
            put(valueLableEnum.getType(), valueLableEnum.getEnumClass().getEnumConstants()[0]);
        }
    }};

}
