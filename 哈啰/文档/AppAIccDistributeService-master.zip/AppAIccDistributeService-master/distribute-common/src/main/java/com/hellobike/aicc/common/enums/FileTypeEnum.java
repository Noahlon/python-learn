package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhangzhuoqi
 * @since 2025-03-13  14:05:40
 */
@AllArgsConstructor
@Getter
public enum FileTypeEnum {

    CSV(1 , "csv"),
    XLSX(2 , "xlsx");

    private final Integer code;
    private final String desc;
}
