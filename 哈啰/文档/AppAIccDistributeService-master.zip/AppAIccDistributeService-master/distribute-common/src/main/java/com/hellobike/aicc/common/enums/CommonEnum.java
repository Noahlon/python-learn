package com.hellobike.aicc.common.enums;

import com.hellobike.aicc.common.dto.CommonEnumDTO;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-04-22  16:28:40
 */
public interface CommonEnum {

    List<CommonEnumDTO> allEnum();
}
