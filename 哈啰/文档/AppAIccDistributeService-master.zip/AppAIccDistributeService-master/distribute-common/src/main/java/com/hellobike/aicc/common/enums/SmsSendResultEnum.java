package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * 短信发送结果枚举
 */
@AllArgsConstructor
@Getter
public enum SmsSendResultEnum {
    SUCCESS(0, "发送成功"),

    FAILED(1, "发送失败"),

    UNKNOWN(2, "未知");

    private final Integer code;

    private final String desc;

    public static SmsSendResultEnum getByCode(Integer code) {
        return Arrays.stream(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
    }

    public static String getMsg(Integer code) {
        return Arrays.stream(values()).filter(e -> e.getCode().equals(code)).map(SmsSendResultEnum::getDesc).findFirst().orElse("");
    }
}
