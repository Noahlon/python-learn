/*
 * BffLogin.java
 * Copyright 2022 HelloBike , all rights reserved.
 * HelloBike PROPRIETARY/CONFIDENTIAL, any form of usage is subject to approval.
 */

package com.hellobike.aicc.common.basic;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BffLogin {
    private String userName;

    private String realName;

    private String email;

    private String jobnumber;
}