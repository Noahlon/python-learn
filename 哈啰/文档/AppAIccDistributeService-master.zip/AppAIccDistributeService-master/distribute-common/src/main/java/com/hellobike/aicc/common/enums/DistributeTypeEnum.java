package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @Author: hjj
 * @CreateTime: 2025-02-28
 * @Description: 分流类型
 * @Version: 1.0
 */
@AllArgsConstructor
@Getter
public enum DistributeTypeEnum {
    SYNC(1, "实时分流"),
    ASYNC(2, "离线分流"),
    ;

    private final Integer code;

    private final String desc;

    public static DistributeTypeEnum getByCode(Integer code) {
        return Arrays.stream(values()).filter(it -> it.getCode().equals(code)).findFirst().orElse(null);
    }
}
