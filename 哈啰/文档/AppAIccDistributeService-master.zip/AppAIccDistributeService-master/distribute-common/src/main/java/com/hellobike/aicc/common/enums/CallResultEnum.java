package com.hellobike.aicc.common.enums;

import com.hellobike.aicc.common.dto.CommonEnumDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-04-01  14:48:35
 */
@AllArgsConstructor
@Getter
public enum CallResultEnum implements CommonEnum{
    FREQUENCY_LIMIT(1, "限频"),
    BLACK_LIST(2, "黑名单"),
    CALL_AREA_LIMIT(3, "盲区"),
    THROUGH(4, "接通"),
    TURN_OFF(5, "关机"),
    EMPTY_NUM(6, "空号"),
    PHONE_STOP(7, "停机"),
    OTHER_CALL_RESULT(8, "未接通"),
    DEFAULT(-999, "未知的状态码");

    private final Integer code;
    private final String desc;

    public static String getDescByCode(Integer code) {
        for (CallResultEnum value : CallResultEnum.values()) {
            if (value.getCode().equals(code)) {
                return value.getDesc();
            }
        }
        return DEFAULT.desc;
    }

    public static CallResultEnum getEnumByCode(Integer code) {
        if(Objects.isNull(code)) {
            return DEFAULT;
        }
        for (CallResultEnum value : CallResultEnum.values()) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return DEFAULT;
    }


    @Override
    public List<CommonEnumDTO> allEnum() {
        List<CommonEnumDTO> list = new ArrayList<>();
        for (CallResultEnum resultEnum : CallResultEnum.values()) {
            CommonEnumDTO commonEnumDTO = new CommonEnumDTO();
            commonEnumDTO.setCode(resultEnum.getCode());
            commonEnumDTO.setValue(resultEnum.getDesc());
            list.add(commonEnumDTO);
        }
        return list;
    }
}
