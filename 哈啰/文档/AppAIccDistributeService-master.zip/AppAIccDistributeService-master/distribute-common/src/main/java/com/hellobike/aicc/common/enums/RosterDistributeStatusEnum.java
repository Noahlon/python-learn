package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 名单下发状态枚举
 */

@AllArgsConstructor
@Getter
public enum RosterDistributeStatusEnum {
    PENDING(0, "待下发"),

    FINISHED(1, "下发完成"),

    FAILED(2, "下发失败"),

    NOT_DISTRIBUTE(3, "无需下发");

    private final Integer code;

    private final String desc;
}
