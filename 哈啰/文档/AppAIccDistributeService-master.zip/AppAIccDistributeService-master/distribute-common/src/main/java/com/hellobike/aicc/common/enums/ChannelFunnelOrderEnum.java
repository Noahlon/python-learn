package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhengchenyang
 * @desc  渠道任务漏斗顺序
 * @date 2025/04/22
 */

@AllArgsConstructor
@Getter
public enum ChannelFunnelOrderEnum implements CommonFunnelEnum{

    UPLOAD_NUM(1, "uploadDataNum", "数据量",true),

    ROSTER_SUM(2, "sentTotalNum","下发总量",false),

    DIST_SUC_SUM(3,"sentSuccessNum","下发成功量",false),

    THROUGH_ROSTER_NUM(4,"throughRosterNum","名单接通量",false),

    SEND_SMS_NUM(5, "sendSmsSum","发送短信名单数",false),

    SEND_SMS_SUC_NUM(6, "smsSuccSum","短信成功名单量",false);

    private final Integer id;

    private final String code;

    private final String name;

    private final Boolean showFlag;
}
