package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhangzhuoqi
 * @since 2025-04-17  11:15:11
 */
@AllArgsConstructor
@Getter
public enum SexEnum {
    MALE(1, "男"),
    FEMALE(2, "女"),
    UNKNOWN(3, "未知");

    private final Integer code;
    private final String desc;

    public static SexEnum getEnumByCode(Integer code) {
        for (SexEnum sexEnum : values()) {
            if (sexEnum.getCode().equals(code)) {
                return sexEnum;
            }
        }
        return UNKNOWN;
    }
}
