package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * 计划渠道任务表状态
 */

@AllArgsConstructor
@Getter
public enum PlanChannelTaskStatusEnum {
    FAILED(0, "任务创建失败"),

    SUCCESS(1, "任务创建成功"),

    /**
     * 渠道任务是分流计划创建完成后异步创建的，如果没有查询到渠道任务表记录，则状态为任务尚未创建
     */
    NOT_CREATE(2, "任务尚未创建");

    private final Integer code;

    private final String desc;

    public static String getDescByCode(Integer code) {
        return Arrays.stream(values())
                .filter(e -> e.getCode().equals(code))
                .map(PlanChannelTaskStatusEnum::getDesc)
                .findFirst()
                .orElse(null);
    }
}
