package com.hellobike.aicc.common.enums;

/**
 * @author zhangzhuoqi
 * @since 2025-04-28  11:05:59
 */
public interface CommonFunnelEnum {

    Integer getId();

    String getCode();

    String getName();

    /**
     * 当前字段是否只在总计行漏斗中 true:只展示在总计行漏斗中 false:总计和单条任务都展示
     */
    Boolean getShowFlag();

}
