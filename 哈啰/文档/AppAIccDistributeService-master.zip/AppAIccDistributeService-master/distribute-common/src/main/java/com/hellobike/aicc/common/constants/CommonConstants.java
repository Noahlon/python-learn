package com.hellobike.aicc.common.constants;

/**
 * @author zhangzhuoqi
 * @since 2025-04-21  18:12:41
 */
public interface CommonConstants {

    /**
     * 每个 sheet 页的数据最大条数
     */
    Integer MAX_SHEET_SIZE = 100_0000;

    /**
     * 导出文件失败原因
     */
    String EXPORT_ERROR = "导出失败，请稍后重试";

    /**
     * 短信未知状态超时
     */
    String SMS_UNKNOWN_OVERTIME = "短信未知状态超过%s分钟，置为失败";

    /**
     * 短信未知状态已变更
     */
    String SMS_UNKNOWN_DONE = "短信状态已经变更为%s";

    /**
     * 短信状态修改失败
     */
    String SMS_UNKNOWN_UPD_ERROR = "短信状态修改失败";
}
