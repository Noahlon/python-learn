package com.hellobike.aicc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  10:23:32
 */
@AllArgsConstructor
@Getter
public enum FileExportStatusEnum {
    PROCESS(1,"执行中"),
    SUCCESS(2,"执行成功"),
    FAIL(3,"执行失败");

    private final Integer code;
    private final String desc;
}
