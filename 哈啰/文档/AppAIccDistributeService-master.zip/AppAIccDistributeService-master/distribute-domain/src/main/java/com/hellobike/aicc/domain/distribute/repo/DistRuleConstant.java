package com.hellobike.aicc.domain.distribute.repo;

/**
 * @author zhengchenyang
 * @date 2025/03/20
 * @desc 规则常量
 */
public interface DistRuleConstant {

    /**
     * 规则缓存配置
     */
    interface RatioCaCheConfig {
        long MAXIMUM_SIZE = 40 * 10000;

        int INITIAL_CAPACITY = 1024 * 128;

        long EXPIRE_AFTER_WRITE_MINUTES = 60 * 24 * 7;

        long EXPIRE_AFTER_ACCESS_MINUTES = 60 * 24 * 7;
    }
}
