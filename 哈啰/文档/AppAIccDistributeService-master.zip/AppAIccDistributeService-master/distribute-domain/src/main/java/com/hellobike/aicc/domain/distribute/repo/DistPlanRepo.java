package com.hellobike.aicc.domain.distribute.repo;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DistributeTypeEnum;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueStatisticEntity;
import com.hellobike.aicc.domain.dialogue.entity.TenantStatEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanQueryCondition;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-07  14:40:14
 */
public interface DistPlanRepo {
    /**
     * 创建分流计划
     */
    void createDistributePlan(DistributePlanEntity distributePlan);

    /**
     * 更新分流计划
     */
    void updateDistributePlan(DistributePlanEntity distributePlan);

    /**
     * 根据id查询分流计划
     */
    DistributePlanEntity queryDistributePlanById(Long id);

    /**
     * 按照分流类型查询分流计划id
     *
     * @param distributeTypeEnum
     * @return
     */
    List<Long> queryByDistType(DistributeTypeEnum distributeTypeEnum);

    /**
     * 分页查询分流计划
     */
    PageResult<DistributePlanEntity> pageQueryDistributePlan(DistributePlanQueryCondition condition);

    /**
     * 查询全量生效中的分流计划
     */
    List<DistributePlanEntity> queryAllEffectiveDistPlans();

    /**
     * 更新上传数据量
     */
    void updateUploadDataNum(Long id, Integer uploadCount);

    PageResult<DistributePlanEntity> pageQueryDistPlanStat(DistributePlanQueryCondition condition);

    /**
     * 分流计划统计赋值
     * @param planList
     */
    void statPlan(List<DistributePlanEntity> planList);

    TenantStatEntity queryDistPlanTotalStat(DistributePlanQueryCondition condition);

    List<DistributePlanEntity> queryByCondition(DistributePlanQueryCondition condition);

    /**
     * 查询分流计划列表
     */
    List<DistributePlanEntity> queryDistributePlanList(String tenantCode, LocalDateTime createStartTime, LocalDateTime createEndTime);

}
