package com.hellobike.aicc.domain.channel.service.impl;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.PlanChannelTaskStatusEnum;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.exception.BusinessException;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.domain.channel.dto.ChannelTaskCreateDTO;
import com.hellobike.aicc.domain.channel.dto.ChannelTaskRetryDTO;
import com.hellobike.aicc.domain.channel.entity.ChannelEntity;
import com.hellobike.aicc.domain.channel.entity.ChannelTaskEntity;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.channel.factory.ChannelInfo;
import com.hellobike.aicc.domain.channel.processor.ChannelProcessor;
import com.hellobike.aicc.domain.channel.service.ChannelDomainService;
import com.hellobike.aicc.domain.channel.service.DistPlanQryParam;
import com.hellobike.aicc.domain.dialogue.entity.TenantStatEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.repo.DistChannelTaskRepo;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanQueryCondition;
import com.hellobike.base.redis.core.client.IRedisHelper;
import com.hellobike.base.redis.core.lock.RedisLock;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 类说明
 *
 * @author panlongqian
 * @since 2025-03-11
 */
@Service
@Slf4j
public class ChannelDomainServiceImpl implements ChannelDomainService {
    /**
     * 渠道任务重试状态锁
     */
    private static final String CHANNEL_TASK_RETRY_LOCK_KEY = "channel:task:retry:%s";

    private static final Integer EXTERNAL_CHANNEL_ID = 1;

    @Resource
    private DistChannelTaskRepo distChannelTaskRepo;

    @Resource
    private DistPlanRepo distPlanRepo;

    @Resource
    private IRedisHelper redisHelper;

    @Override
    public List<ChannelEntity> queryChannelList() {
        List<ChannelInfo> allChannel = ChannelFactory.getAllChannel();
        return allChannel.stream()
                .map(it -> new ChannelEntity(it.getChannelId(), it.getChannelName()))
                .collect(Collectors.toList());
    }

    @Override
    public List<ChannelEntity> queryChannelDetail(List<Integer> channelIdList, String tenantCode) {
        List<ChannelEntity> result = new ArrayList<>();
        List<ChannelEntity> questResult = new ArrayList<>();
        for (Integer channelId : new HashSet<>(channelIdList)) {
            // 获取渠道商处理器
            ChannelProcessor channelProcessor = ChannelFactory.getChannelProcessor(channelId);
            if (channelProcessor == null) {
                continue;
                //throw new BusinessException(BusinessErrorCode.NO_PROCESSOR_ERROR);
            }
            // 查询渠道商详情
            ChannelInfo channelInfo = ChannelFactory.getChannel(channelId);
            if (channelInfo == null) {
                continue;
                //throw new BusinessException(BusinessErrorCode.NO_CHANNEL_ERROR);
            }

            //如果是外呼平台传租户(tenantCode)。如果是渠道商，则调用渠道商接口查询详情
            ChannelEntity channelEntity;
            if (Objects.equals(channelInfo.getChannelId(), ChannelFactory.getHelloAiCall().getChannelId())) {
                channelEntity = channelProcessor.queryChannelDetail(tenantCode);
            } else {
                channelEntity = channelProcessor.queryChannelDetail(channelInfo.getAppKey());
            }
            if (channelEntity != null) {
                questResult.add(channelEntity);
            }
        }
        Map<Integer, ChannelEntity> channelEntityMap = questResult.stream().collect(Collectors.toMap(ChannelEntity::getChannelId, it -> it));
        for (Integer channelId : channelIdList) {
            ChannelEntity channelEntity = channelEntityMap.get(channelId);
            if (channelEntity != null) {
                result.add(channelEntity);
            }
        }
        return result;
    }

    @Override
    public void createDistributeChannelTask(DistributeChannelTaskEntity distributeChannelTaskEntity) {
        distChannelTaskRepo.createDistributeChannelTask(distributeChannelTaskEntity);
    }

    @Override
    public void retryCreateChannelTask(ChannelTaskRetryDTO channelTaskRetryDTO) {
        DistributeChannelTaskEntity channelTaskEntity = distChannelTaskRepo.queryById(Long.valueOf(channelTaskRetryDTO.getPlanChannelTaskId()));
        AssertUtils.notNull(channelTaskEntity, "渠道任务不存在");
        AssertUtils.isTrue(Objects.equals(channelTaskEntity.getTaskStatus(), PlanChannelTaskStatusEnum.FAILED.getCode()), "该任务状态已更新，请刷新重试");

        RedisLock redisLock = redisHelper.createLock(String.format(CHANNEL_TASK_RETRY_LOCK_KEY, channelTaskEntity.getId()));
        try {
            boolean lock = redisLock.blockAcquireRenewalLock(5, -1);
            AssertUtils.isTrue(lock, "该任务状态已更新，请刷新重试");
            channelTaskEntity = distChannelTaskRepo.queryById(Long.valueOf(channelTaskRetryDTO.getPlanChannelTaskId()));
            AssertUtils.isTrue(Objects.equals(channelTaskEntity.getTaskStatus(), PlanChannelTaskStatusEnum.FAILED.getCode()), "该任务状态已更新，请刷新重试");
            // 重新创建渠道任务
            ChannelProcessor channelProcessor = ChannelFactory.getChannelProcessor(Integer.valueOf(channelTaskEntity.getChannelId()));
            if (channelProcessor == null) {
                log.error("重试创建渠道任务找不到渠道处理器,渠道商id为：{}, 渠道商名称为：{}", channelTaskEntity.getChannelId(), channelTaskEntity.getChannelName());
                throw new BusinessException(BusinessErrorCode.CHANNEL_TASK_RETRY_FAIL);
            }

            ChannelTaskCreateDTO channelTaskCreateDTO = new ChannelTaskCreateDTO();
            channelTaskCreateDTO.setTaskTemplateId(channelTaskEntity.getSupplierTaskTemplateId());
            channelTaskCreateDTO.set_user(channelTaskRetryDTO.get_user());
            channelTaskCreateDTO.setDistributePlanId(channelTaskEntity.getDistributePlanId());
            channelTaskCreateDTO.setAppKey(ChannelFactory.getChannel(Integer.valueOf(channelTaskEntity.getChannelId())).getAppKey());
            ChannelTaskEntity channelTask = channelProcessor.createChannelTask(channelTaskCreateDTO);
            if (channelTask == null || StringUtils.isBlank(channelTask.getChannelTaskId())) {
                log.error("重试创建渠道任务失败,渠道商id为：{}, 渠道商名称为：{}", channelTaskEntity.getChannelId(), channelTaskEntity.getChannelName());
                throw new BusinessException(BusinessErrorCode.CHANNEL_TASK_RETRY_FAIL);
            } else {
                channelTaskEntity.setSupplierTaskId(channelTask.getChannelTaskId());
                channelTaskEntity.setSupplierTaskName(channelTask.getChannelTaskName());
                channelTaskEntity.setTaskStatus(PlanChannelTaskStatusEnum.SUCCESS.getCode());
            }
            distChannelTaskRepo.updateDistributeChannelTask(channelTaskEntity);
        } catch (Exception e) {
            log.error("重试创建渠道任务异常，渠道任务id为：{}", channelTaskRetryDTO.getPlanChannelTaskId(), e);
            throw new BusinessException(BusinessErrorCode.CHANNEL_TASK_RETRY_FAIL);
        } finally {
            redisLock.releaseLock();
        }
    }

    @Override
    public List<DistributeChannelTaskEntity> queryDistributeChannelTaskList(Long distributePlanId) {
        DistributePlanEntity distributePlanEntity = distPlanRepo.queryDistributePlanById(distributePlanId);
        return distChannelTaskRepo.queryEsPlanTaskList(distributePlanId, distributePlanEntity.getCreateTime());
    }

    @Override
    public PageResult<DistributePlanEntity> queryDistPlanStat(DistPlanQryParam request) {
        DistributePlanQueryCondition condition = new DistributePlanQueryCondition();
        condition.setPlanId(request.getPlanId());
        condition.setPlanName(request.getPlanName());
        condition.setTenantCodeList(Collections.singletonList(request.getTenantId()));
        condition.setPageNum(request.getPageNum());
        condition.setPageSize(request.getPageSize());
        return distPlanRepo.pageQueryDistPlanStat(condition);
    }

    @Override
    public TenantStatEntity queryDistPlanTotalStat(DistPlanQryParam request) {
        DistributePlanQueryCondition condition = new DistributePlanQueryCondition();
        condition.setTenantCodeList(Collections.singletonList(request.getTenantId()));
        condition.setPlanId(request.getPlanId());
        condition.setPlanName(request.getPlanName());
        return distPlanRepo.queryDistPlanTotalStat(condition);
    }
}
