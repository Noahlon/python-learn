package com.hellobike.aicc.domain.roster.dto;

import lombok.Data;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;

/**
 * @author fanxiaodongwb230
 * @since 2025-04-25  10:53:34
 */
@Data
@Accessors(chain = true)
@Slf4j
public class ExtPlanRosterDTO {
    /**
     * 手机号
     */
    private String phone;

    /**
     * 客户姓名
     */
    private String name;

    /**
     * 名单唯一标识（长度不超过128），通话/短信回调时将该字段透传返回
     */
    private String rosterKey;

    /**
     * 变量信息
     */
    private Map<String,String> variableInfos;


}
