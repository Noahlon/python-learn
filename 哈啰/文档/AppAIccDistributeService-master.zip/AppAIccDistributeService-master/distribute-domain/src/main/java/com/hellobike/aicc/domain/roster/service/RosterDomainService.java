package com.hellobike.aicc.domain.roster.service;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.roster.dto.DistributeRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.dto.NameListDupCheckResultDTO;
import com.hellobike.aicc.domain.roster.dto.RosterAPIImportDTO;
import com.hellobike.aicc.domain.roster.dto.RosterImportResultDTO;
import com.hellobike.aicc.domain.roster.dto.RosterRetryDistributeDTO;
import com.hellobike.aicc.domain.roster.dto.UploadRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.DistributeRecordEntity;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-07  16:43:34
 */
public interface RosterDomainService {
    /**
     * 分页查询上传记录
     *
     * @param conditionDTO
     * @param pageNum
     * @param pageSize
     * @return PageResult<UploadRecordEntity>
     * @author zhangzhuoqi
     * @since 2025/3/13 09:49
     **/
    PageResult<UploadRecordEntity> pageUploadRecord(UploadRecordQueryConditionDTO conditionDTO, Integer pageNum, Integer pageSize);

    /**
     * 分页查询下发记录
     *
     * @param conditionDTO
     * @param pageNum
     * @param pageSize
     * @return PageResult<DistributeRecordEntity>
     * @author zhangzhuoqi
     * @since 2025/3/13 09:51
     **/
    PageResult<DistributeRecordEntity> pageDistributeRecord(DistributeRecordQueryConditionDTO conditionDTO, Integer pageNum, Integer pageSize);

    /**
     * 重试下发名单
     *
     * @param retryDistributeDTO
     * @return void
     * @author zhangzhuoqi
     * @since 2025/3/18 11:39
     **/
    void retryDistribute(RosterRetryDistributeDTO retryDistributeDTO);

    /**
     * 名单数据库重复校验
     *
     * @param rosterEntityList 解析校验通道的名单列表
     */
    NameListDupCheckResultDTO rosterDupCheck(List<PlanRosterEntity> rosterEntityList, boolean isUseMultiThead);

    /**
     * 文件导入名单
     */
    void fileImportRoster(List<PlanRosterEntity> entityList, DistributePlanEntity distributePlan, String operator, UploadRecordEntity uploadRecordEntity);

    /**
     * 接口上传名单
     *
     * @param rosterAPIImportDTO
     * @return void
     * @author zhangzhuoqi
     * @since 2025/3/20 10:41
     **/
    RosterImportResultDTO apiImportRoster(RosterAPIImportDTO rosterAPIImportDTO);

    /**
     * 离线分流接口上传名单聚合下发
     *
     * @author zhangzhuoqi
     * @since 2025/3/21 14:23
     * @return void
     **/
    void aggDistribute();

    /**
     * 当出现异常情况时，对分流计划下的所有名单进行重试下发
     *
     * @author zhangzhuoqi
     * @since 2025/5/17 09:57
     * @param distPlanId  分流计划id
     * @param channelTaskId  渠道任务id
     * @return void
     **/
    void retryDistCompensate(Long distPlanId , Long channelTaskId);
}
