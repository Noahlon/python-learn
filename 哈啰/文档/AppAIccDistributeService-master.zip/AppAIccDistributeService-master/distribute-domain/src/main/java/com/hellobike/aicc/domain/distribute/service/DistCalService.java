package com.hellobike.aicc.domain.distribute.service;

import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;

import java.util.List;

/**
 * @author zhengchenyang
 * @date 2025/3/18
 * @desc
 */
public interface DistCalService {
    /**
     * 决策渠道
     *
     * @param plan
     * @param distTaskList
     * @param rosters
     */
    void decide(DistributePlanEntity plan, List<DistributeChannelTaskEntity> distTaskList, List<PlanRosterEntity> rosters);
}
