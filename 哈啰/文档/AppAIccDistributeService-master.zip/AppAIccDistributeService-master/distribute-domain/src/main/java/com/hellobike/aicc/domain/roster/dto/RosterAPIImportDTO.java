package com.hellobike.aicc.domain.roster.dto;

import cn.hutool.core.lang.Pair;
import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.common.enums.RosterTypeEnum;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * @author zhangzhuoqi
 * @since 2025-03-20  10:34:00
 */
@Data
@Slf4j
public class RosterAPIImportDTO {

    /**
     * 租户id
     */
    private String tenantId;

    /**
     * 分流计划id
     */
    private String distributePlanId;

    /**
     * 上传名单类型
     * @see com.hellobike.aicc.common.enums.RosterTypeEnum
     */
    private Integer rosterType;

    /**
     * 名单信息
     */
    private List<PlanRosterEntity> rosterEntityList;

    /**
     * 去掉重复或格式错误的数据
     * @return Pair<Integer, Integer> key：失败数量，value：重复数量
     */
    public Pair<Integer, Integer> rmDupAndFail() {
        int failCount = 0;
        int dupCount = 0;
        //名单信息按照手机号和数据标识去重
        Set<String> phoneNumSet = new HashSet<>();
        Iterator<PlanRosterEntity> iterator = rosterEntityList.iterator();
        while (iterator.hasNext()) {

            PlanRosterEntity next = iterator.next();
            RosterTypeEnum rosterTypeEnum;
            if (Objects.isNull(this.rosterType)){
                rosterTypeEnum = RosterTypeEnum.TELEPHONE;
            } else {
                rosterTypeEnum = RosterTypeEnum.getByCode(this.rosterType);
            }
            if (Objects.isNull(rosterTypeEnum)){
                log.error("名单类型错误:{},planId:{}", this.rosterType, distributePlanId);
                failCount++;
                iterator.remove();
                continue;
            }

            if (!rosterTypeEnum.check(next.getPhoneNum())) {
                log.error("手机号格式错误:{},planId:{}", next.getPhoneNum(), distributePlanId);
                failCount++;
                iterator.remove();
                continue;
            }
            if (StrUtil.isBlank(next.getExternalId()) || next.getExternalId().length() > 128) {
                log.error("外部id格式错误:{},planId:{}", next.getExternalId(), distributePlanId);
                failCount++;
                iterator.remove();
                continue;
            }
            if (StrUtil.isNotBlank(next.getCustomerName()) && next.getCustomerName().length() > 128) {
                log.error("客户姓名格式错误:{},planId:{}", next.getCustomerName(), distributePlanId);
                failCount++;
                iterator.remove();
                continue;
            }
            if (StrUtil.isNotBlank(next.getVariableInfo()) && next.getVariableInfo().length() > 2048){
                log.error("变量长度过长错误:{},planId:{}", next.getExternalId(), distributePlanId);
                failCount++;
                iterator.remove();
                continue;
            }
            String key = next.getPhoneNum() + "-" + next.getExternalId();
            if (phoneNumSet.contains(key)) {
                dupCount++;
                iterator.remove();
                continue;
            }
            phoneNumSet.add(key);
        }
        phoneNumSet.clear();
        return new Pair<>(failCount, dupCount);
    }
}
