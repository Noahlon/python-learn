package com.hellobike.aicc.domain.utils.oss;

import com.hellobike.aicc.common.util.ApplicationContextHandle;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.io.File;

@Data
@ConfigurationProperties(prefix = "oss")
@Component
public class OSSConfiguration {

    private String accessKeyId;

    private String accessKeySecret;

    private String bucketName;

    private String endpoint;

    private String baseDir;

    private String stsArn;

    private String stsEndpoint;

    /**
     * 资源过期分钟
     */
    private Long expiredMin;

    /**
     * 环境信息key
     */
    private static String ENV_KEY = "env";


    /**
     * 规则：/{baseDir}/{env}/
     *
     * @return 基础目录
     */
    public String getBaseDir() {
        String currentEnv = getEvn();
        String buffer = File.separator +
                baseDir +
                File.separator + (StringUtils.isBlank(currentEnv) ? "fat" : currentEnv) + File.separator;
        return buffer;
    }

    /**
     * 获取环境信息
     *
     * @return 环境信息
     */
    public String getEvn() {
        Environment env = ApplicationContextHandle.getBean(Environment.class);
        return env.getProperty(ENV_KEY);
    }
}
