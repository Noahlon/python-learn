package com.hellobike.aicc.domain.roster.service.impl;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.text.csv.CsvData;
import cn.hutool.core.text.csv.CsvReader;
import cn.hutool.core.text.csv.CsvRow;
import cn.hutool.core.text.csv.CsvUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelReader;
import com.alibaba.excel.read.metadata.ReadSheet;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.hellobike.aicc.common.component.ApolloConfigs;
import com.hellobike.aicc.common.enums.DistributeStatusEnum;
import com.hellobike.aicc.common.enums.FileTypeEnum;
import com.hellobike.aicc.common.enums.NameListStatusEnum;
import com.hellobike.aicc.common.enums.RosterTypeEnum;
import com.hellobike.aicc.common.enums.UploadStatusEnum;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.exception.BusinessException;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.common.service.DownloadFileService;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributeUploadFileEntity;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.distribute.repo.DistUploadFileRepo;
import com.hellobike.aicc.domain.roster.dto.NameListDupCheckResultDTO;
import com.hellobike.aicc.domain.roster.dto.NameListParseResultDTO;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;
import com.hellobike.aicc.domain.roster.repo.UploadRecordRepository;
import com.hellobike.aicc.domain.roster.service.NameListDomainService;
import com.hellobike.aicc.domain.roster.service.RosterDomainService;
import com.hellobike.aicc.domain.roster.service.excel.RosterImportReadListener;
import com.hellobike.aicc.domain.roster.service.excel.RosterImportVO;
import com.hellobike.aicc.domain.utils.RosterCheckUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import javax.annotation.Resource;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Slf4j
public class NameListDomainServiceImpl implements NameListDomainService {
    static final String SYMBOL_SPOT = ".";

    /**
     * 第四行开始存放变量信息
     */
    private static final int SKIP_ROW = 3;

    @Resource
    private DistPlanRepo distPlanRepo;

    @Resource
    private DownloadFileService downloadFileService;

    @Resource
    private DistUploadFileRepo distUploadFileRepo;

    @Resource
    private IdGeneratorService idGeneratorService;

    @Resource
    private RosterDomainService rosterDomainService;

    @Resource
    private UploadRecordRepository uploadRecordRepository;

    @Resource
    private ApolloConfigs apolloConfigs;

    @Override
    public void handlerImportNameList(DistributeUploadFileEntity uploadFileEntity, UploadRecordEntity uploadRecordEntity) {
        try {
            log.info("处理名单文件上传,名单上传任务id为：{}", uploadFileEntity.getId());
            DistributePlanEntity distributePlanEntity = distPlanRepo.queryDistributePlanById(uploadFileEntity.getDistributePlanId());

            AssertUtils.notNull(distributePlanEntity, "分流计划不存在");
            AssertUtils.notNull(uploadRecordEntity, "上传记录不存在");

            // 开始处理文件解析
            doImportNameList(distributePlanEntity, uploadFileEntity, uploadRecordEntity);

            // 更新状态为处理完成
            uploadFileEntity.setStatus(NameListStatusEnum.FINISHED.getCode());
            uploadFileEntity.setStatusDesc(NameListStatusEnum.FINISHED.getDesc());
            log.info("处理名单文件上传结束,名单上传任务id为：{}", uploadFileEntity.getId());
        } catch (BusinessException e) {
            log.error("处理名单文件上传出现业务异常,名单上传任务id为：{}", uploadFileEntity.getId(), e);
            uploadFileEntity.setStatus(NameListStatusEnum.FAILED.getCode());
            uploadFileEntity.setStatusDesc(NameListStatusEnum.FAILED.getDesc());
            uploadFileEntity.setFailedDesc(e.getBusinessErrorCode().getDesc());
        } catch (Exception e) {
            log.error("处理名单文件上传出现系统异常,名单上传任务id为：{}", uploadFileEntity.getId(), e);
            uploadFileEntity.setStatus(NameListStatusEnum.FAILED.getCode());
            uploadFileEntity.setStatusDesc(NameListStatusEnum.FAILED.getDesc());
            uploadFileEntity.setFailedDesc("系统异常");
        }
        distUploadFileRepo.saveOrUpdateUpLoadFile(uploadFileEntity);
    }

    private void doImportNameList(DistributePlanEntity distributePlan, DistributeUploadFileEntity uploadFileEntity, UploadRecordEntity uploadRecordEntity) {
        // 下载名单文件到本地
        NameListParseResultDTO parseResult;
        String filePath = null;
        try {
            filePath = downloadFileService.downloadFileToLocal(uploadFileEntity.getFileUrl(), FileUtil.getName(uploadFileEntity.getFileUrl()));
            if (StringUtils.isBlank(filePath)) {
                updateImportFileErrorRecord(uploadRecordEntity, "下载文件失败");
                throw new BusinessException(BusinessErrorCode.DOWNLOAD_FILE_ERROR);
            }

            // 解析文件且校验数据，剔除文件内重复的数据，获取校验失败的数量（failCount）和校验成功的数据列表（rosterEntityList）
            parseResult = parseFileData(uploadRecordEntity, uploadFileEntity, filePath);
        } finally {
            if (StringUtils.isNotBlank(filePath)) {
                FileUtils.deleteQuietly(new File(filePath));
            }
        }
        uploadFileEntity.setFailedCount(parseResult.getFailCount());
        if (CollectionUtils.isEmpty(parseResult.getRosterEntityList())) {
            log.warn("文件解析合法数据为0");
            uploadRecordEntity.setUploadStatus(UploadStatusEnum.UPLOAD_SUCCESS.getCode());
            uploadRecordEntity.setDistributeStatus(DistributeStatusEnum.SUCCESS.getCode());
            uploadRecordRepository.updateRecordById(uploadRecordEntity);
            return;
        }

        // 批量入库，获取与数据库中数据重复的数量（duplicationCount）和新插入数据库的数据（rosterEntityList），rosterEntityList的数量即为成功的数量（successCount）
        NameListDupCheckResultDTO dupCheckResult;
        try {
            dupCheckResult = rosterDomainService.rosterDupCheck(parseResult.getRosterEntityList(), apolloConfigs.getUseMultiTheadSaveRoster());
        } catch (Exception e) {
            log.warn("数据库重复校验异常", e);
            uploadRecordEntity.setUploadStatus(UploadStatusEnum.UPLOAD_SUCCESS.getCode());
            uploadRecordEntity.setDistributeStatus(DistributeStatusEnum.SUCCESS.getCode());
            uploadRecordRepository.updateRecordById(uploadRecordEntity);
            return;
        }
        uploadFileEntity.setDuplicateCount(dupCheckResult.getDuplicationCount());
        uploadFileEntity.setSuccessCount(dupCheckResult.getInsertEntityList().size());
        if (CollectionUtils.isEmpty(dupCheckResult.getInsertEntityList())) {
            log.warn("文件数据与数据库重复");
            uploadRecordEntity.setUploadStatus(UploadStatusEnum.UPLOAD_SUCCESS.getCode());
            uploadRecordEntity.setDistributeStatus(DistributeStatusEnum.SUCCESS.getCode());
            uploadRecordRepository.updateRecordById(uploadRecordEntity);
            return;
        }

        // 开始处理新增名单
        List<PlanRosterEntity> insertEntityList = dupCheckResult.getInsertEntityList();
        rosterDomainService.fileImportRoster(insertEntityList, distributePlan, uploadFileEntity.getCreator(), uploadRecordEntity);
    }

    private NameListParseResultDTO parseFileData(UploadRecordEntity uploadRecordEntity, DistributeUploadFileEntity uploadFileEntity, String filePath) {
        try {
            String suffix = uploadFileEntity.getFileName().substring(uploadFileEntity.getFileName().lastIndexOf(SYMBOL_SPOT) + 1);
            if (FileTypeEnum.CSV.getDesc().equalsIgnoreCase(suffix)) {
                List<CsvRow> csvRows = getCsvFileData(filePath);
                // 构造子任务
                return parseCsvRosterList(uploadFileEntity, csvRows, uploadRecordEntity.getRosterType());
            } else if (FileTypeEnum.XLSX.getDesc().equalsIgnoreCase(suffix)) {
                return parseXlsxFileData(uploadFileEntity, filePath, uploadRecordEntity.getRosterType());
            } else {
                throw new RuntimeException("文件类型不支持");
            }
        } catch (Exception e) {
            log.error("文件解析失败", e);
            updateImportFileErrorRecord(uploadRecordEntity, "文件格式有误");
            throw new BusinessException(BusinessErrorCode.IMPORT_FILE_ERROR);
        }
    }

    /**
     * 文件解析异常
     */
    private void updateImportFileErrorRecord(UploadRecordEntity uploadRecordEntity, String msg) {
        uploadRecordEntity.setUploadStatus(UploadStatusEnum.FAIL.getCode());
        uploadRecordEntity.setUploadFailReason(msg);
        uploadRecordEntity.setDistributeStatus(DistributeStatusEnum.NOT_DISTRIBUTE.getCode());
        uploadRecordRepository.updateRecordById(uploadRecordEntity);
    }

    private boolean checkCsvHeaders(List<String> headers) {
        return new HashSet<>(headers).containsAll(Arrays.asList("手机号", "数据标识", "姓名"));
    }

    private boolean dataCheck(String phone, String externalId, String name, List<String> rawList, Integer rosterType) {
        if (!RosterCheckUtil.isRosterValid(phone, externalId, name, rosterType)) {
            return false;
        }
        if (rawList.size() > 3) {
            // 检查变量长度
            for (int i = SKIP_ROW; i < rawList.size(); i++) {
                if (rawList.get(i).length() > 2048) {
                    return false;
                }
            }
        }
        return true;
    }

    private String parseVariableInfoTemp(List<String> headers, List<String> rawList) {
        if (CollectionUtils.isEmpty(headers) || CollectionUtils.isEmpty(rawList)) {
            return null;
        }
        Map<String, String> result = new HashMap<>();
        // 变量从第四列开始
        for (int i = SKIP_ROW, len = headers.size(); i < len; i++) {
            result.put(headers.get(i), rawList.get(i));
        }
        if (MapUtils.isEmpty(result)){
            return null;
        }
        return BaseJsonUtils.writeValue(result);
    }

    public NameListParseResultDTO parseCsvRosterList(DistributeUploadFileEntity uploadFileEntity, List<CsvRow> csvRows, Integer rosterType) {
        if (csvRows.size() <= 1) {
            return new NameListParseResultDTO(0, new ArrayList<>());
        }
        Set<String> set = Sets.newHashSet();
        List<String> headers = csvRows.get(0).getRawList().stream().map(t -> {
            String[] temps = t.split("\n");
            if (temps.length == 2) {
                return temps[1];
            }
            return temps[0];
        }).collect(Collectors.toList());
        AssertUtils.isTrue(checkCsvHeaders(headers), "csv表头不合法");

        // 遍历csv数据行
        int failedNum = 0;
        List<PlanRosterEntity> rosterEntityList = Lists.newArrayListWithCapacity(csvRows.size());
        for (int i = 1, len = csvRows.size(); i < len; i++) {
            List<String> rawList = csvRows.get(i).getRawList();
            if (CollectionUtils.isEmpty(rawList)) {
                continue;
            }
            String phone = rawList.get(0);
            String externalId = rawList.get(1);
            String name = rawList.get(2);
            if (!dataCheck(phone, externalId, name, rawList, rosterType)) {
                failedNum++;
                continue;
            }

            String variableInfo = parseVariableInfoTemp(headers, rawList);
            if (StringUtils.isNotBlank(variableInfo) && variableInfo.length() > 2048) {
                failedNum++;
                continue;
            }
            // 数据重复校验，不计入失败
            if (set.contains(phone + "-" + externalId)) {
                continue;
            } else {
                set.add(phone + "-" + externalId);
            }
            PlanRosterEntity roster = new PlanRosterEntity();
            roster.setId(idGeneratorService.getLongId())
                    .setRosterType(rosterType)
                    .setExternalId(externalId)
                    .setCustomerName(name)
                    .setDistributePlanId(uploadFileEntity.getDistributePlanId())
                    .setVariableInfo(variableInfo);
            if (RosterTypeEnum.TELEPHONE.getCode().equals(rosterType)) {
                roster.setPhoneNum(phone);
                roster.setMd5(DigestUtils.md5DigestAsHex(phone.getBytes()));
            } else if (RosterTypeEnum.MD5.getCode().equals(rosterType)) {
                roster.setPhoneNum(phone.toLowerCase());
                roster.setMd5(phone.toLowerCase());
            }
            rosterEntityList.add(roster);
        }
        return new NameListParseResultDTO(failedNum, rosterEntityList);
    }

    private NameListParseResultDTO parseXlsxFileData(DistributeUploadFileEntity entity, String filePath, Integer rosterType) {
        ExcelReader excelReader = EasyExcel.read(filePath).build();
        // 读取名单内容
        RosterImportReadListener listener = new RosterImportReadListener(rosterType);
        ReadSheet dataSheet = EasyExcel.readSheet(0).head(RosterImportVO.class).registerReadListener(listener).build();
        excelReader.read(dataSheet);
        List<RosterImportVO> rosterImportList = listener.getDataList();
        log.info("从名单中读去到原始内容共{}行", rosterImportList.size());

        List<PlanRosterEntity> rosterEntityList = rosterImportList.stream().map(it -> {
            PlanRosterEntity roster = new PlanRosterEntity();
            roster.setId(idGeneratorService.getLongId())
                    .setRosterType(rosterType)
                    .setExternalId(it.getExternalId())
                    .setCustomerName(it.getCustomerName())
                    .setDistributePlanId(entity.getDistributePlanId());
            if (MapUtil.isEmpty(it.getVariableMap())) {
                roster.setVariableInfo(null);
            } else {
                roster.setVariableInfo(BaseJsonUtils.writeValue(it.getVariableMap()));
            }
            if (RosterTypeEnum.TELEPHONE.getCode().equals(rosterType)) {
                roster.setPhoneNum(it.getPhoneNum());
                roster.setMd5(DigestUtils.md5DigestAsHex(it.getPhoneNum().getBytes()));
            } else if (RosterTypeEnum.MD5.getCode().equals(rosterType)) {
                roster.setPhoneNum(it.getPhoneNum().toLowerCase());
                roster.setMd5(it.getPhoneNum().toLowerCase());
            }
            return roster;
        }).collect(Collectors.toList());

        return new NameListParseResultDTO(listener.getFailedCount(), rosterEntityList);
    }

    private List<CsvRow> getCsvFileData(String filePath) {
        CsvReader reader = CsvUtil.getReader();
        CsvData data = reader.read(FileUtil.file(filePath));
        return data.getRows();
    }
}
