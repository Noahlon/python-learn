package com.hellobike.aicc.domain.roster.dto;

import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import lombok.Data;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-18  13:43:18
 */
@Data
public class ChannelImportRosterDTO {

    /**
     * 租户id
     */
    private String tenantCode;

    /**
     * 三方任务id
     */
    private String supplierTaskId;

    /**
     * 分流计划id
     */
    private Long distributePlanId;

    /**
     * 名单集合
     */
    private List<PlanRosterEntity> rosterEntityList;

    /**
     * 名单类型
     * @see com.hellobike.aicc.common.enums.RosterTypeEnum
     */
    private Integer rosterType;

    /**
     * 渠道商appKey，供外部渠道商使用
     */
    private String appKey;

}
