package com.hellobike.aicc.domain.distribute.service.impl;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DistributeStatusEnum;
import com.hellobike.aicc.common.enums.NameListStatusEnum;
import com.hellobike.aicc.common.enums.UploadStatusEnum;
import com.hellobike.aicc.common.enums.UploadTypeEnum;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributeUploadFileEntity;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.distribute.repo.DistUploadFileRepo;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributeUploadFileCondition;
import com.hellobike.aicc.domain.distribute.service.DistUploadFileDomainService;
import com.hellobike.aicc.domain.roster.dto.RosterUploadDTO;
import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;
import com.hellobike.aicc.domain.roster.repo.UploadRecordRepository;
import com.hellobike.aicc.domain.roster.service.NameListDomainService;
import com.hellobike.aicc.domain.utils.HammerThreadPoolUtil;
import com.hellobike.base.redis.core.client.IRedisHelper;
import com.hellobike.base.redis.core.lock.RedisLock;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
@Slf4j
public class DistUploadFileDomainServiceImpl implements DistUploadFileDomainService {
    private static final Integer TASK_NAME_LIST_UPLOAD_REDIS_LOCK_TIMEOUT = 10 * 1000;

    private static final Integer TASK_UPLOAD_REDIS_TIME_OUT = -1;

    /**
     * 分流计划名单上传状态锁
     */
    private static final String DISTRIBUTE_NAME_LIST_UPDATE_STATUS_KEY = "distribute:name:list:update:status:%s";
    @Resource
    private IdGeneratorService idGeneratorService;
    @Resource
    private DistUploadFileRepo distUploadFileRepo;

    @Resource
    private IRedisHelper redisHelper;

    @Resource
    private NameListDomainService nameListDomainService;

    @Resource
    private DistPlanRepo distPlanRepo;

    @Resource
    private UploadRecordRepository uploadRecordRepository;

    @Override
    public PageResult<DistributeUploadFileEntity> queryUploadFileList(DistributeUploadFileCondition condition) {
        return distUploadFileRepo.pageQueryUploadFile(condition);
    }

    @Override
    public void uploadRoster(RosterUploadDTO uploadDTO) {
        DistributePlanEntity distributePlanEntity = distPlanRepo.queryDistributePlanById(Long.valueOf(uploadDTO.getDistributeId()));
        AssertUtils.notNull(distributePlanEntity, "分流计划不存在");

        // 创建上传记录，状态为待解析;
        UploadRecordEntity uploadRecordEntity = addImportUploadRecord(distributePlanEntity, uploadDTO.getOperator(), uploadDTO.getRosterType());
        DistributeUploadFileEntity distributeUploadFileEntity = buildDistributeUploadFileEntity(uploadDTO, uploadRecordEntity.getId());
        // 如果此分流计划有待处理或者处理中的任务，则直接入库，等待定时任务调度依次执行
        DistributeUploadFileCondition condition = new DistributeUploadFileCondition();
        condition.setDistributePlanId(distributePlanEntity.getId());
        condition.setStatusList(Arrays.asList(NameListStatusEnum.PROCESSING.getCode(), NameListStatusEnum.WAIT_PROCESS.getCode()));
        List<DistributeUploadFileEntity> taskList = distUploadFileRepo.queryByCondition(condition);
        if (CollectionUtils.isNotEmpty(taskList)) {
            distributeUploadFileEntity.setStatus(NameListStatusEnum.WAIT_PROCESS.getCode());
            distributeUploadFileEntity.setStatusDesc(NameListStatusEnum.WAIT_PROCESS.getDesc());
            distUploadFileRepo.saveOrUpdateUpLoadFile(distributeUploadFileEntity);
            return;
        }

        doUpload(distributeUploadFileEntity, uploadRecordEntity);
    }

    public static void main(String[] args) {

        System.out.println(DigestUtils.md5DigestAsHex("13544011302".getBytes()));
        System.out.println(DigestUtils.md5DigestAsHex("13264677020".getBytes()));
        System.out.println(DigestUtils.md5DigestAsHex("17720499162".getBytes()));
        System.out.println(DigestUtils.md5DigestAsHex("17858919875".getBytes()));
    }

    @Override
    public void doUpload(DistributeUploadFileEntity distributeUploadFileEntity, UploadRecordEntity uploadRecordEntity) {
        if (!updateNameListToProcessing(distributeUploadFileEntity)) {
            // 此分流计划有其他上传名单任务在执行中，将状态设置为待处理，后续定时任务会继续处理
            log.info("分流计划id为：{}，有其他处理中的名单文件上传任务，直接返回", distributeUploadFileEntity.getDistributePlanId());
            distributeUploadFileEntity.setStatus(NameListStatusEnum.WAIT_PROCESS.getCode());
            distributeUploadFileEntity.setStatusDesc(NameListStatusEnum.WAIT_PROCESS.getDesc());
            distUploadFileRepo.saveOrUpdateUpLoadFile(distributeUploadFileEntity);
        } else {
            // 将文件上传状态设置为处理中成功, 开始异步处理文件导入
            boolean submitSuccess = HammerThreadPoolUtil.submitNameListHandlerTask(() -> nameListDomainService.handlerImportNameList(distributeUploadFileEntity, uploadRecordEntity));
            if (!submitSuccess) {
                // 任务提交失败（应该不会出现），更新状态为待处理，等待定时任务下次处理
                log.error("提交处理任务失败，更新状态为待处理，等待定时任务下次处理，上传名单任务id为：{}", distributeUploadFileEntity.getId());
                distributeUploadFileEntity.setStatus(NameListStatusEnum.WAIT_PROCESS.getCode());
                distributeUploadFileEntity.setStatusDesc(NameListStatusEnum.WAIT_PROCESS.getDesc());
                distUploadFileRepo.saveOrUpdateUpLoadFile(distributeUploadFileEntity);
            }
        }
    }

    /**
     * 新增上传记录
     */
    private UploadRecordEntity addImportUploadRecord(DistributePlanEntity distributePlan, String operator, Integer rosterType) {
        UploadRecordEntity uploadRecordEntity = new UploadRecordEntity();
        uploadRecordEntity.setId(idGeneratorService.getLongId());
        uploadRecordEntity.setUploadType(UploadTypeEnum.MANUAL.getCode());
        uploadRecordEntity.setUploadStatus(UploadStatusEnum.PENDING_ANALYSIS.getCode());
        uploadRecordEntity.setDistributeStatus(DistributeStatusEnum.PENDING.getCode());
        uploadRecordEntity.setUploadTime(LocalDateTime.now());
        uploadRecordEntity.setOperator(operator);
        uploadRecordEntity.setDistributeType(distributePlan.getDistributeType());
        uploadRecordEntity.setDistributePlanId(distributePlan.getId());
        uploadRecordEntity.setRosterType(rosterType);
        uploadRecordRepository.addRecord(uploadRecordEntity);
        return uploadRecordEntity;
    }

    private DistributeUploadFileEntity buildDistributeUploadFileEntity(RosterUploadDTO uploadDTO, Long uploadRecordId) {
        DistributeUploadFileEntity distributeUploadFileEntity = new DistributeUploadFileEntity();
        distributeUploadFileEntity.setId(idGeneratorService.getLongId());
        distributeUploadFileEntity.setFileUrl(uploadDTO.getFileUrl());
        distributeUploadFileEntity.setFileName(uploadDTO.getFileName());
        distributeUploadFileEntity.setDistributePlanId(Long.valueOf(uploadDTO.getDistributeId()));
        distributeUploadFileEntity.setCreator(uploadDTO.getOperator());
        distributeUploadFileEntity.setUploadRecordId(uploadRecordId);
        return distributeUploadFileEntity;
    }

    private boolean updateNameListToProcessing(DistributeUploadFileEntity entity) {
        RedisLock redisLock = redisHelper.createLock(String.format(DISTRIBUTE_NAME_LIST_UPDATE_STATUS_KEY, entity.getDistributePlanId()));
        try {
            boolean lock = redisLock.blockAcquireRenewalLock(TASK_NAME_LIST_UPLOAD_REDIS_LOCK_TIMEOUT, TASK_UPLOAD_REDIS_TIME_OUT);
            if (lock) {
                if (existProcessingTask(entity.getDistributePlanId())) {
                    log.warn("存在处理中的名单,分流计划id为：{}", entity.getDistributePlanId());
                    return false;
                }
                entity.setStatus(NameListStatusEnum.PROCESSING.getCode());
                entity.setStatusDesc(NameListStatusEnum.PROCESSING.getDesc());
                distUploadFileRepo.saveOrUpdateUpLoadFile(entity);
                return true;
            }
            return false;
        } catch (Exception e) {
            log.error("更新名单状态为执行中异常，分流计划id为：{}", entity.getDistributePlanId(), e);
            return false;
        } finally {
            redisLock.releaseLock();
        }
    }

    private boolean existProcessingTask(Long distributePlanId) {
        DistributeUploadFileCondition condition = new DistributeUploadFileCondition();
        condition.setDistributePlanId(distributePlanId);
        condition.setStatusList(Collections.singletonList(NameListStatusEnum.PROCESSING.getCode()));
        List<DistributeUploadFileEntity> entityList = distUploadFileRepo.queryByCondition(condition);
        return CollectionUtils.isNotEmpty(entityList);
    }
}
