package com.hellobike.aicc.domain.roster.dto;

import com.hellobike.aicc.common.enums.RosterDistributeStatusEnum;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-03-19  16:37:44
 */
@Data
public class BatchUpdRosterFieldDTO {

    /**
     * 名单下发状态
     */
    private RosterDistributeStatusEnum rosterDistStatusEnum;

    /**
     * 下发时间
     */
    private LocalDateTime distributeTime;

}
