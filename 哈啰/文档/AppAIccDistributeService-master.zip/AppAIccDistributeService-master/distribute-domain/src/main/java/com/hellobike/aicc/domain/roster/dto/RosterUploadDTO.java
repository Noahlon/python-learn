package com.hellobike.aicc.domain.roster.dto;

import lombok.Data;

/**
 * @author zhangzhuoqi
 * @since 2025-03-07  16:42:42
 */
@Data
public class RosterUploadDTO {

    /**
     * 上传名单文件地址
     */
    private String fileUrl;

    /**
     * 分流渠道id
     */
    private String distributeId;

    /**
     * 上传名单文件名称
     */
    private String fileName;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 上传名单类型
     */
    private Integer rosterType;
}
