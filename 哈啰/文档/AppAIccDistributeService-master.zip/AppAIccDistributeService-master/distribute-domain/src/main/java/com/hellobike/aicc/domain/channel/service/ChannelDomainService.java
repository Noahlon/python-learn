package com.hellobike.aicc.domain.channel.service;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.channel.dto.ChannelTaskRetryDTO;
import com.hellobike.aicc.domain.channel.entity.ChannelEntity;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueStatisticEntity;
import com.hellobike.aicc.domain.dialogue.entity.TenantStatEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;

import java.util.List;

/**
 * 渠道商service
 *
 * @author panlongqian
 * @since 2025-03-11
 */
public interface ChannelDomainService {
    /**
     * 查询渠道商信息
     */
    List<ChannelEntity> queryChannelList();

    /**
     * 根据渠道商id查询渠道商完整信息，包括渠道商模板信息
     */
    List<ChannelEntity> queryChannelDetail(List<Integer> channelIdList, String tenantCode);

    /**
     * 创建渠道商任务
     */
    void createDistributeChannelTask(DistributeChannelTaskEntity distributeChannelTaskEntity);

    /**
     * 重试创建渠道商任务
     */
    void retryCreateChannelTask(ChannelTaskRetryDTO channelTaskRetryDTO);

    /**
     * 查询渠道商任务列表
     */
    List<DistributeChannelTaskEntity> queryDistributeChannelTaskList(Long distributePlanId);


    /**
     * 查询分流计划统计信息
     * @param request
     * @return
     */
    PageResult<DistributePlanEntity> queryDistPlanStat(DistPlanQryParam request);

    /**
     * 查询租户下分流计划总统计信息
     * @param request
     * @return
     */
    TenantStatEntity queryDistPlanTotalStat(DistPlanQryParam request);
}
