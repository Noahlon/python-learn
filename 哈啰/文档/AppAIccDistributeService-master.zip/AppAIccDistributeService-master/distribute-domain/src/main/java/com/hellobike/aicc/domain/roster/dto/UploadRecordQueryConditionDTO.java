package com.hellobike.aicc.domain.roster.dto;

import com.hellobike.aicc.common.enums.DistributeTypeEnum;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-03-10  11:15:07
 */
@Data
public class UploadRecordQueryConditionDTO {

    /**
     * 上传记录id
     */
    private Long id;

    /**
     * 上传方式类型
     * @see com.hellobike.aicc.common.enums.UploadTypeEnum
     */
    private Integer uploadType;

    /**
     * 上传状态
     * @see com.hellobike.aicc.common.enums.UploadStatusEnum
     */
    private Integer uploadStatus;

    /**
     * 下发状态
     * @see com.hellobike.aicc.common.enums.DistributeStatusEnum
     */
    private Integer distributeStatus;

    /**
     * 上传时间-开始
     */
    private LocalDateTime startUploadTime;

    /**
     * 上传时间-结束
     */
    private LocalDateTime endUploadTime;

    /**
     * 分流类型
     * @see DistributeTypeEnum
     */
    private Integer distributeType;

    /**
     * 分流计划id
     */
    private Long distributePlanId;

    /**
     * 创建时间-开始
     */
    private LocalDateTime startCreateTime;

    /**
     * 创建时间-解说
     */
    private LocalDateTime endCreateTime;

    /**
     * 逻辑删除
     */
    private Integer isDelete;

}
