package com.hellobike.aicc.domain.dialogue.service;

import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;

/**
 *
 * 话单对外消息接口
 * @author zhangzhuoqi
 * @since 2025-03-17  17:52:50
 */
public interface CallDialogueMsgService {

    /**
     * 发送话单消息
     *
     * @author zhangzhuoqi
     * @since 2025/3/17 17:36
     * @param callDialogueEntity 话单
     * @return void
     **/
    void sendMsg(CallDialogueEntity callDialogueEntity);
}
