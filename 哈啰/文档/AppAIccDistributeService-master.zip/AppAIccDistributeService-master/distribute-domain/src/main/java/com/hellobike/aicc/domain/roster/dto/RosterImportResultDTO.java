package com.hellobike.aicc.domain.roster.dto;

import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import lombok.Data;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-20  14:11:27
 */
@Data
public class RosterImportResultDTO {

    /**
     * 重复数量
     */
    private Integer duplicationCount = 0;

    /**
     * 成功数量
     */
    private Integer successCount = 0;

    /**
     * 失败数量
     */
    private Integer failCount = 0;

    /**
     * 最终需要落库的名单
     */
    private List<PlanRosterEntity> finalRosterList;
}
