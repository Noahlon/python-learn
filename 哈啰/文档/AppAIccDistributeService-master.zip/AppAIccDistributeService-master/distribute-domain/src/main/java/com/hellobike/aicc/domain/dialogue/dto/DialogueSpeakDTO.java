package com.hellobike.aicc.domain.dialogue.dto;

import lombok.Data;


/**
 * @author fanxiaodongwb230
 * @date 2025/04/22
 */
@Data
public class DialogueSpeakDTO {
    /**
     * 说话Id
     */
    private String speakId;

    /**
     * 说话方
     * 1-呼叫方 2-被叫方
     */
    private Integer speaker;

    /**
     * 说话内容
     */
    private String speakContent;

    /**
     * 说话时间
     */
    private String speakTime;
}
