package com.hellobike.aicc.domain.utils.oss;

import cn.hutool.core.date.DateUtil;
import com.aliyun.oss.ClientException;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.DownloadFileRequest;
import com.aliyun.oss.model.GeneratePresignedUrlRequest;
import com.aliyun.oss.model.ObjectMetadata;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.auth.sts.AssumeRoleRequest;
import com.aliyuncs.auth.sts.AssumeRoleResponse;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.hellobike.aicc.common.enums.BusinessTypeEnum;
import com.hellobike.aicc.domain.common.dto.STSTicketDTO;
import com.hellobike.aicc.domain.utils.UrlUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Map;

@Slf4j
@Component
public class OSSUtils implements OSSHelper {
    private OSS ossClient;

    @Autowired
    private OSSConfiguration config;

    @PostConstruct
    private void init() {
        this.ossClient = new OSSClientBuilder().build(config.getEndpoint(), config.getAccessKeyId(), config.getAccessKeySecret());
    }


    @Override
    public String uploadFileWithExpire(String filename, BusinessTypeEnum businessTypeEnum, InputStream inputStream, String contentType, Long expiredMin) {
        String timeDir = DateUtil.format(new Date(), "yyyyMMdd");
        String filepath = config.getBaseDir().substring(1) + businessTypeEnum.getType() + File.separator + timeDir + File.separator + filename;
        if (StringUtils.isEmpty(contentType)) {
            this.ossClient.putObject(config.getBucketName(), filepath, inputStream);
        } else {
            ObjectMetadata meta = new ObjectMetadata();
            meta.setContentType(contentType);
            this.ossClient.putObject(config.getBucketName(), filepath, inputStream, meta);
        }

        return generateSTSUrl(filepath, expiredMin);
    }

    @Override
    public String uploadFileToFileName(File file, BusinessTypeEnum businessTypeEnum, Long expiredMin) {
        String filepath = config.getBaseDir().substring(1) + businessTypeEnum.getType() + File.separator + file.getName();
        try (FileInputStream inputStream = new FileInputStream(file)) {
            this.ossClient.putObject(config.getBucketName(), filepath, inputStream);
            return generateSTSUrl(filepath, expiredMin);
        } catch (Exception e) {
            log.error("上传文件异常", e);
        }
        return null;
    }

    @Override
    public void downloadByOssKey(String ossKey, String localFilePath) {
        try {
            DownloadFileRequest downloadFileRequest = new DownloadFileRequest(config.getBucketName(), ossKey);
            downloadFileRequest.setDownloadFile(localFilePath);
            this.ossClient.downloadFile(downloadFileRequest);
        } catch (Throwable e) {
            log.error("下载文件失败", e);
        }
    }

    @Override
    public String getTxtFromFileName(String fileName, BusinessTypeEnum businessTypeEnum) {
        String ossKey = config.getBaseDir().substring(1) + businessTypeEnum.getType() + File.separator + fileName;
        downloadByOssKey(ossKey, fileName);
        StringBuilder builder = new StringBuilder();
        File file = new File(fileName);
        if (!file.exists()) {
            return builder.toString();
        }
        try (FileReader fr = new FileReader(file); BufferedReader br = new BufferedReader(fr)) {
            String line;
            while ((line = br.readLine()) != null) {
                builder.append(line);
            }
        } catch (IOException e) {
            log.error("上传文件异常", e);
        }
        file.deleteOnExit();
        return builder.toString();
    }

    /**
     * 获取临时访问地址
     *
     * @param originUrl 原始文件
     * @return 授权访问的地址
     */
    @Override
    public String generateSTSUrl(String originUrl, Long expiredMin) {
        return generateSTSUrl(originUrl, null, null, expiredMin, null, null);
    }

    @Override
    public String generateSTSUrl(String originUrl) {
        return generateSTSUrl(originUrl, null, null, null, null, null);
    }

    /**
     * 资源访问授权
     *
     * @param originUrl      原始资源地址，必传
     * @param endPoint       指定内网地址，可空
     * @param publicEndPoint 指定公网地址，可空
     * @param expiredMin     过期时间，单位分钟，可空
     * @param queryParam     oss的拼接参数
     * @param renameFilename 下载后的文件名
     * @return 授权后的链接
     */
    @Override
    public String generateSTSUrl(String originUrl, String endPoint, String publicEndPoint, Long expiredMin, Map<String, String> queryParam, String renameFilename) {

        // 1. 判断资源过期时间超过10分钟，并且不带拼接参数，不重新生成，
        if (getResourceExpirationTime(originUrl) > 10 * 60 && (queryParam == null || queryParam.isEmpty())) {
            return originUrl;
        }

        // 2.已过期或者即将过期的资源，准备做授权
        GeneratePresignedUrlRequest request = new GeneratePresignedUrlRequest(config.getBucketName(), UrlUtils.getObjectRelativePath(originUrl));
        Long minutes = (expiredMin == null || expiredMin <= 0) ? config.getExpiredMin() : expiredMin;
        request.setExpiration(new Date(Timestamp.valueOf(LocalDateTime.now().plusMinutes(minutes)).getTime()));
        if (queryParam != null && !queryParam.isEmpty()) {
            request.setQueryParameter(queryParam);
        }

        // 3. 授权链接

        URL url = ossClient.generatePresignedUrl(request);
        if (!StringUtils.isEmpty(endPoint) && !StringUtils.isEmpty(publicEndPoint)) {
            return url.toString().replaceFirst(endPoint, publicEndPoint);
        }

        return UrlUtils.convertHttp2Https(url.toString());
    }


    /**
     * 计算资源过期时间
     *
     * @param url oss链接
     * @return 过期时长，单位秒
     */
    @Override
    public long getResourceExpirationTime(String url) {
        try {
            Map<String, String> queryParams = UrlUtils.parseQueryParams(url);
            if (!queryParams.containsKey("Expires")) {
                return -1;
            }

            long expires = Long.parseLong(queryParams.get("Expires"));
            return expires - (System.currentTimeMillis() / 1000);
        } catch (Exception e) {
            log.warn("解析oss url过期时间失败, url = {}", url);
            return -1;
        }
    }

    @Override
    public STSTicketDTO generateStsTicket(int expireSeconds) {
        try {
            String regionId = "oss-cn-hangzhou";
            DefaultProfile.addEndpoint(regionId, "Sts", config.getStsEndpoint());
            IClientProfile profile = DefaultProfile.getProfile(regionId, config.getAccessKeyId(), config.getAccessKeySecret());
            DefaultAcsClient client = new DefaultAcsClient(profile);

            final AssumeRoleRequest request = new AssumeRoleRequest();
            request.setSysMethod((MethodType.POST));
            request.setRoleArn(config.getStsArn());
            request.setRoleSessionName("fileUploadSession");
            request.setDurationSeconds((long) expireSeconds);

            // 3. 请求oss，获取临时授权
            final AssumeRoleResponse response = client.getAcsResponse(request);
            if (response == null) {
                log.error("获取STS接口响应为null");
                return null;
            }

            return STSTicketDTO.builder()
                    .accessKeyId(response.getCredentials().getAccessKeyId())
                    .accessKeySecret(response.getCredentials().getAccessKeySecret())
                    .securityToken(response.getCredentials().getSecurityToken())
                    .region(regionId)
                    .bucket(config.getBucketName())
                    .requestId(response.getRequestId())
                    .baseDir(getBaseDir())
                    .build();

        } catch (ClientException e) {
            log.error("构建临时授权，请求阿里云异常", e);
            return null;
        } catch (Exception ex) {
            log.error("构建临时授权失败", ex);
            return null;
        }
    }

    private String getBaseDir() {
        String currentEnv = System.getProperty("env");
        return File.separator + "distribute_file" + File.separator + (StringUtils.isBlank(currentEnv) ? "fat" : currentEnv) + File.separator;
    }
}
