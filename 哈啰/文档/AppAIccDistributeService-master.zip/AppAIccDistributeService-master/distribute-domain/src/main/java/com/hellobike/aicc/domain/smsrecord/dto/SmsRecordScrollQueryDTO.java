package com.hellobike.aicc.domain.smsrecord.dto;

import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;
import lombok.Data;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  13:56:35
 */
@Data
public class SmsRecordScrollQueryDTO {

    private String scrollId;

    private List<SmsRecordEntity> smsRecordList;
}
