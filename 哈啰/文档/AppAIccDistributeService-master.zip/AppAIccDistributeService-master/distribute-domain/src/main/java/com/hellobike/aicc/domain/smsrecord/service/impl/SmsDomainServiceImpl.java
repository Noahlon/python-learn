package com.hellobike.aicc.domain.smsrecord.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.component.ApolloConfigs;
import com.hellobike.aicc.common.constants.CommonConstants;
import com.hellobike.aicc.common.enums.BusinessTypeEnum;
import com.hellobike.aicc.common.enums.CarrierTypeEnum;
import com.hellobike.aicc.common.enums.FileExportBizTypeEnum;
import com.hellobike.aicc.common.enums.FileExportStatusEnum;
import com.hellobike.aicc.common.enums.SmsSendResultEnum;
import com.hellobike.aicc.common.enums.YesOrNoEnum;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.common.util.FileUtils;
import com.hellobike.aicc.common.util.export.ExcelExporter;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import com.hellobike.aicc.domain.file.entity.FileExportRecordEntity;
import com.hellobike.aicc.domain.file.service.FileExportRecordDomainService;
import com.hellobike.aicc.domain.smsrecord.dto.SmsCheckStatusQryConditionDTO;
import com.hellobike.aicc.domain.smsrecord.dto.SmsRecordExportDTO;
import com.hellobike.aicc.domain.smsrecord.dto.SmsRecordScrollQueryDTO;
import com.hellobike.aicc.domain.smsrecord.entity.SmsCheckEntity;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordCondition;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;
import com.hellobike.aicc.domain.smsrecord.repo.SmsCheckRepository;
import com.hellobike.aicc.domain.smsrecord.repo.SmsRecordRepository;
import com.hellobike.aicc.domain.smsrecord.service.SmsDomainService;
import com.hellobike.aicc.domain.smsrecord.service.SmsRecordMsgService;
import com.hellobike.aicc.domain.utils.HammerThreadPoolUtil;
import com.hellobike.aicc.domain.utils.oss.OSSHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
@Slf4j
public class SmsDomainServiceImpl implements SmsDomainService {

    @Resource
    private SmsRecordRepository smsRecordRepository;

    @Resource
    private IdGeneratorService idGeneratorService;

    @Resource
    private FileExportRecordDomainService exportRecordDomainService;

    @Resource
    private OSSHelper ossHelper;

    @Resource
    private ApolloConfigs apolloConfigs;

    @Resource
    private SmsCheckRepository smsCheckRepository;

    @Resource
    private SmsRecordMsgService smsRecordMsgService;

    @Override
    public PageResult<SmsRecordEntity> pageQuerySmsRecord(SmsRecordCondition condition) {
        return smsRecordRepository.pageQuerySmsRecord(condition);
    }

    @Override
    public void export(SmsRecordCondition condition, String operator) {
        long sum = smsRecordRepository.countSmsRecord(condition);
        AssertUtils.isTrue(sum > 0, BusinessErrorCode.SMS_RECORD_EXPORT_IS_EMPTY);
        String fileName = "sms_record_" + System.currentTimeMillis() + ".xlsx";
        //创建文件导出记录
        FileExportRecordEntity fileExportRecord = new FileExportRecordEntity();
        fileExportRecord.setId(idGeneratorService.getLongId());
        fileExportRecord.setBizType(FileExportBizTypeEnum.SMS.getCode());
        fileExportRecord.setStatus(FileExportStatusEnum.PROCESS.getCode());
        fileExportRecord.setFileName(fileName);
        fileExportRecord.setOperator(operator);
        exportRecordDomainService.saveOrUpdate(fileExportRecord);

        //异步导出
        CompletableFuture.runAsync(() -> {
            String scrollId = null;
            String filePathName = FileUtils.getTmpDirPath() + fileName;
            long exportNum = 0;
            try (FileOutputStream fos = new FileOutputStream(filePathName);
                 ExcelExporter exporter = ExcelExporter.getInstance(fos, SmsRecordExportDTO.class)) {
                while (exportNum < Math.min(apolloConfigs.getFileExportDataMaxLimit(), sum)) {
                    log.info("短信记录，当前导出的条数 {}", exportNum);
                    SmsRecordScrollQueryDTO scrollQueryDTO = smsRecordRepository.listSmsForExport(condition, scrollId);
                    scrollId = scrollQueryDTO.getScrollId();
                    List<SmsRecordEntity> smsRecordList = scrollQueryDTO.getSmsRecordList();
                    if (smsRecordList.isEmpty()) {
                        log.info("数据为空， scrollId {}", scrollId);
                        break;
                    }
                    List<SmsRecordExportDTO> exportList = convertSmsExports(smsRecordList);
                    exporter.write(exportList);
                    exportNum += exportList.size();
                    // 导出的数据量等于查询的数据量时或者数据等于最大数量限制时 导出完成
                    if (exportNum == sum || exportNum >= apolloConfigs.getFileExportDataMaxLimit()) {
                        log.info("短信记录，数据导出完成，导出数据条数 {}", exportNum);
                        // 文件写入完成，显式调用 finish
                        exporter.finish();
                        break;
                    }
                }
                fileExportRecord.setExportCount((int) exportNum);
                String fileUrl = ossHelper.uploadFileToFileName(new File(filePathName), BusinessTypeEnum.SMS, 60L * 24L * apolloConfigs.getFileExportOssFileExpireDay());
                if (StrUtil.isBlank(fileUrl)) {
                    fileExportRecord.setStatus(FileExportStatusEnum.FAIL.getCode());
                    fileExportRecord.setFailReason(BusinessErrorCode.CALL_DIALOGUE_UPLOAD_OSS_ERROR.getDesc());
                } else {
                    fileExportRecord.setStatus(FileExportStatusEnum.SUCCESS.getCode());
                    fileExportRecord.setFileUrl(fileUrl);
                }
                exportRecordDomainService.saveOrUpdate(fileExportRecord);
            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                org.apache.commons.io.FileUtils.deleteQuietly(new File(filePathName));
            }
        }, HammerThreadPoolUtil.getExportExecutor()).exceptionally(ex -> {
            log.info("短信导出失败,e:", ex);
            fileExportRecord.setFailReason(CommonConstants.EXPORT_ERROR);
            fileExportRecord.setStatus(FileExportStatusEnum.FAIL.getCode());
            exportRecordDomainService.saveOrUpdate(fileExportRecord);
            return null;
        });
    }

    @Override
    public void checkSmsStatus() {
        //查询出超过72小时且未处理的未知状态的短信记录
        SmsCheckStatusQryConditionDTO condition = new SmsCheckStatusQryConditionDTO();
        LocalDateTime now = LocalDateTime.now();
        int checkMinutes = apolloConfigs.getSmsCheckStatusMinutes();
        int checkStatusMinutesEnd = apolloConfigs.getSmsCheckStatusMinutesEnd();
        LocalDateTime endTime = now.minusMinutes(checkMinutes);
        LocalDateTime startTime = endTime.minusMinutes(checkStatusMinutesEnd);
        condition.setReceiveResultTimeStart(startTime);
        condition.setReceiveResultTimeEnd(endTime);
        condition.setHandleStatus(YesOrNoEnum.NO.getCode());
        condition.setHandleSendResult(SmsSendResultEnum.UNKNOWN.getCode());

        log.info("处理短信记录,startTime:{},endTime:{},checkMinutes:{},checkStatusMinutesEnd:{}", startTime, endTime, checkMinutes, checkStatusMinutesEnd);
        List<SmsCheckEntity> smsCheckList = smsCheckRepository.queryByCondition(condition);
        if (CollectionUtil.isEmpty(smsCheckList)) {
            log.info("当前没有待处理的短信记录,time:{},checkTime:{}", now, checkMinutes);
            return;
        }

        log.info("处理短信记录,list:{}", BaseJsonUtils.writeValue(smsCheckList));
        for (SmsCheckEntity smsCheckEntity : smsCheckList) {
            try {
                //将未知状态的短信记录与数据库做比对
                SmsRecordEntity smsRecord = smsRecordRepository.getById(smsCheckEntity.getSmsId(), smsCheckEntity.getPhoneNumberMd5());
                String handleResultDesc;
                //当前短信记录发送状态是未知就置为失败，并且回调客户
                if (Objects.equals(smsRecord.getSendResult(), SmsSendResultEnum.UNKNOWN.getCode())) {
                    Integer beforeSendResult = SmsSendResultEnum.UNKNOWN.getCode();
                    Integer afterSendResult = SmsSendResultEnum.FAILED.getCode();
                    smsRecord.setSendResult(afterSendResult);
                    boolean updSuccess = smsRecordRepository.updateWhenCheckStatus(smsRecord, beforeSendResult, afterSendResult);
                    if (!updSuccess) {
                        log.info("修改未知状态短信更新DB不成功,smsId:{}", smsRecord.getGuid());
                        handleResultDesc = CommonConstants.SMS_UNKNOWN_UPD_ERROR;
                    } else {
                        smsRecordMsgService.sendMsg(smsRecord);
                        handleResultDesc = String.format(CommonConstants.SMS_UNKNOWN_OVERTIME, checkMinutes);
                    }
                } else {
                    log.info("短信状态已经变更,currStatus:{}，smsId:{}", smsRecord.getSendResult(), smsRecord.getGuid());
                    handleResultDesc = String.format(CommonConstants.SMS_UNKNOWN_DONE, SmsSendResultEnum.getMsg(smsRecord.getSendResult()));
                }
                smsCheckEntity.setHandleStatus(YesOrNoEnum.YES.getCode());
                smsCheckEntity.setHandleResultDesc(handleResultDesc);
                smsCheckRepository.updateById(smsCheckEntity);
            } catch (Exception e) {
                log.error("短信状态处理失败，smsId:{},e:", smsCheckEntity.getSmsId(), e);
            }
        }
    }

    private List<SmsRecordExportDTO> convertSmsExports(List<SmsRecordEntity> smsRecordList) {
        return smsRecordList.stream().map(entity -> {
            SmsRecordExportDTO exportDTO = new SmsRecordExportDTO();
            exportDTO.setChannelName(entity.getChannelName());
            exportDTO.setExternalId(entity.getExternalId());
            exportDTO.setPlatformId(entity.getPlatformId());
            exportDTO.setPhoneNumber(entity.getPhoneNumber());
            exportDTO.setPhoneNumberMd5(entity.getPhoneNumberMd5());
            exportDTO.setDistributePlanName(entity.getDistributePlanName());
            exportDTO.setDistributePlanId(String.valueOf(entity.getDistributePlanId()));
            exportDTO.setSupplierTaskId(entity.getSupplierTaskId());
            exportDTO.setSupplierTaskName(entity.getSupplierTaskName());
            exportDTO.setSpeechName(entity.getSpeechName());
            exportDTO.setEnterpriseId(entity.getEnterpriseId());
            exportDTO.setTenantCode(entity.getTenantCode());
            exportDTO.setSendResultDesc(SmsSendResultEnum.getMsg(entity.getSendResult()));
            exportDTO.setSignature(entity.getSignature());
            exportDTO.setContent(entity.getContent());
            exportDTO.setSendTime(DateUtils.format(entity.getSendTime()));
            exportDTO.setReceiveResultTime(DateUtils.format(entity.getReceiveResultTime()));
            exportDTO.setSeatsName(entity.getSeatsName());
            exportDTO.setBillingNum(entity.getBillingNum());
            exportDTO.setCustomName(entity.getCustomName());
            exportDTO.setCallGuid(entity.getSupplierCallGuid());
            exportDTO.setProvinceCity(CallDialogueEntity.getProvinceAndCity(entity.getProvince(), entity.getCity()));
            exportDTO.setCarrier(CarrierTypeEnum.getEnumByCode(entity.getCarrier()).getDesc());
            exportDTO.setCreateTime(DateUtils.format(entity.getCreateTime()));
            return exportDTO;
        }).collect(Collectors.toList());
    }
}
