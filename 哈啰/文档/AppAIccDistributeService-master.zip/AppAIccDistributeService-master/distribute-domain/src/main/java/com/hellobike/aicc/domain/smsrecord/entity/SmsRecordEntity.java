package com.hellobike.aicc.domain.smsrecord.entity;

import com.hellobike.aicc.common.enums.SmsSendResultEnum;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * 分流平台短信记录
 *
 * @author panlongqian
 * @since 2025-04-22
 */
@Data
public class SmsRecordEntity {
    /**
     * 唯一id
     */
    private Long guid;

    /**
     * 名单id
     */
    private Long rosterId;

    /**
     * 平台数据唯一标识
     */
    private String platformId;

    /**
     * 渠道商id
     */
    private Integer channelId;

    /**
     * 渠道商名称
     */
    private String channelName;

    /**
     * 客户数据标识
     */
    private String externalId;

    /**
     * 手机号码
     */
    private String phoneNumber;

    /**
     * 手机号码的32位小写md5加密
     */
    private String phoneNumberMd5;

    /**
     * 分流计划id
     */
    private Long distributePlanId;

    /**
     * 渠道任务id
     */
    private Long channelTaskId;

    /**
     * 分流计划名称
     */
    private String distributePlanName;

    /**
     * 分流计划平台对应话单id
     */
    private Long distributePlanCallId;

    /**
     * 渠道商任务id
     */
    private String supplierTaskId;

    /**
     * 渠道商任务名称
     */
    private String supplierTaskName;

    /**
     * 企业id
     */
    private String enterpriseId;

    /**
     * 话术名称
     */
    private String speechName;

    /**
     * 租户code
     */
    private String tenantCode;

    /**
     * 短信签名
     */
    private String signature;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 短信提交时间
     */
    private LocalDateTime submitTime;

    /**
     * 短信提交结果
     */
    private Integer submitResult;

    /**
     * 短信发送时间
     */
    private LocalDateTime sendTime;

    /**
     * 短信发送结果
     *
     * @see com.hellobike.aicc.common.enums.SmsSendResultEnum
     */
    private Integer sendResult;

    /**
     * 收到短信结果时间
     */
    private LocalDateTime receiveResultTime;

    /**
     * 计费条数
     */
    private Integer billingNum;

    /**
     * 坐席id
     */
    private String seatsGuid;

    /**
     * 坐席名称
     */
    private String seatsName;

    /**
     * 客户名称
     */
    private String customName;

    /**
     * 渠道商通话记录id
     */
    private String supplierCallGuid;

    /**
     * 渠道商短信记录id
     */
    private String supplierSmsGuid;

    /**
     * 运营商
     */
    private Integer carrier;

    /**
     * 省份
     */
    private String province;

    /**
     * 城市
     */
    private String city;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 最近更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 逻辑删除
     */
    private Integer isDelete;

    /**
     * 名单唯一标识
     */
    private String rosterKey;

    /**
     * 渠道商短信记录json
     */
    private String supplierSmsJson;

    /**
     * 名单类型
     */
    private Integer rosterType;

    public void paddingBillingNum() {
        //未成功的短信，计费数为0
        if (!Objects.equals(sendResult, SmsSendResultEnum.SUCCESS.getCode())) {
            setBillingNum(0);
            return;
        }
        //发送成功的短信但没有计费数，则计算计费数
        if (Objects.isNull(billingNum)) {
            // 渠道商没有返回计费数且短信发送成功，需要计算计费数
            int length = StringUtils.length(signature) + StringUtils.length(content);
            setBillingNum(length <= 70 ? 1 : (length + 66) / 67);
        }
    }
}
