package com.hellobike.aicc.domain.smsrecord.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  14:01:42
 */
@Data
public class SmsRecordExportDTO {

    /**
     * 渠道商名称
     */
    @ExcelProperty(index = 0, value = "渠道商名称")
    private String channelName;

    /**
     * 客户数据标识
     */
    @ExcelProperty(index = 1, value = "客户数据标识")
    private String externalId;

    /**
     * 平台数据唯一标识
     */
    @ExcelProperty(index = 2, value = "平台数据标识")
    private String platformId;

    /**
     * 被叫号码
     */
    @ExcelProperty(index = 3, value = "被叫号码")
    private String phoneNumber;

    /**
     * 手机号码的32位小写md5加密
     */
    @ExcelProperty(index = 4, value = "MD5")
    private String phoneNumberMd5;

    /**
     * 分流计划名称
     */
    @ExcelProperty(index = 5, value = "分流计划名称")
    private String distributePlanName;

    /**
     * 分流计划id
     */
    @ExcelProperty(index = 6, value = "分流计划ID")
    private String distributePlanId;

    /**
     * 渠道商任务id
     */
    @ExcelProperty(index = 7, value = "任务ID")
    private String supplierTaskId;

    /**
     * 渠道商任务名称
     */
    @ExcelProperty(index = 8, value = "任务名称")
    private String supplierTaskName;

    /**
     * 话术名称
     */
    @ExcelProperty(index = 9, value = "话术名称")
    private String speechName;

    /**
     * 企业id
     */
    @ExcelProperty(index = 10, value = "企业ID")
    private String enterpriseId;

    /**
     * 租户code
     */
    @ExcelProperty(index = 11, value = "租户code")
    private String tenantCode;

    /**
     * 短信发送结果描述
     */
    @ExcelProperty(index = 12, value = "发送结果")
    private String sendResultDesc;

    /**
     * 短信签名
     */
    @ExcelProperty(index = 13, value = "短信签名")
    private String signature;

    /**
     * 短信内容
     */
    @ExcelProperty(index = 14, value = "短信内容")
    private String content;


    /**
     * 短信发送时间
     */
    @ExcelProperty(index = 15, value = "短信发送时间")
    private String sendTime;

    /**
     * 收到短信结果时间
     */
    @ExcelProperty(index = 16, value = "回执返回时间")
    private String receiveResultTime;

    /**
     * 坐席名称
     */
    @ExcelProperty(index = 17, value = "座席姓名")
    private String seatsName;

    /**
     * 计费条数
     */
    @ExcelProperty(index = 18, value = "计费条数")
    private Integer billingNum;

    /**
     * 客户名称
     */
    @ExcelProperty(index = 19, value = "客户姓名")
    private String customName;

    /**
     * 渠道商通话记录id
     */
    @ExcelProperty(index = 20, value = "通话唯一ID")
    private String callGuid;

    /**
     * 号码归属地
     */
    @ExcelProperty(index = 21, value = "号码归属地")
    private String provinceCity;

    /**
     * 运营商
     */
    @ExcelProperty(index = 22, value = "运营商")
    private String carrier;

    /**
     * 创建时间
     */
    @ExcelProperty(index = 23, value = "创建时间")
    private String createTime;
}
