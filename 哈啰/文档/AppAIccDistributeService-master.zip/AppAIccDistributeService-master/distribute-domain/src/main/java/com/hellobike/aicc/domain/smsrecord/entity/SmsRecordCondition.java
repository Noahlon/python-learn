package com.hellobike.aicc.domain.smsrecord.entity;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class SmsRecordCondition implements Serializable {
    /**
     * es索引后缀（日期格式：yyyyMMdd）
     */
    private List<String> indexes;

    /**
     * 页大小
     */
    private Integer pageSize;

    /**
     * 页码
     */
    private Integer pageNum;

    /**
     * 排序规则
     */
    private String sortRule;

    /**
     * 短信记录id
     */
    private String guid;

    /**
     * 平台数据唯一标识
     */
    private String platformId;

    /**
     * 渠道id
     */
    private Integer channelId;

    /**
     * 手机号码
     */
    private String phoneNumber;

    /**
     * 手机号码的32位小写md5加密
     */
    private String phoneNumberMd5;

    /**
     * 分流计划id
     */
    private String distributePlanId;

    /**
     * 分流计划id
     */
    private List<String> distributePlanIdList;

    /**
     * 分流计划名称
     */
    private String distributePlanName;

    /**
     * 渠道商任务id
     */
    private String supplierTaskId;

    /**
     * 渠道商任务名称
     */
    private String supplierTaskName;

    /**
     * 短信签名
     */
    private String signature;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 短信发送时间
     */
    private String sendBeginTime;

    /**
     * 短信发送时间
     */
    private String sendEndTime;

    /**
     * 短信发送结果
     */
    private List<Integer> sendResultList;

    /**
     * 收到短信结果时间
     */
    private String receiveResultBeginTime;

    /**
     * 收到短信结果时间
     */
    private String receiveResultEndTime;

    /**
     * 坐席名称
     */
    private String seatsName;

    /**
     * 渠道商通话记录id
     */
    private String supplierCallGuid;

    /**
     * 运营商
     */
    private List<Integer> carrierList;

    /**
     * 城市
     */
    private List<String> cityList;

    /**
     * 创建时间
     */
    private LocalDateTime createBeginTime;

    /**
     * 创建时间
     */
    private LocalDateTime createEndTime;
}
