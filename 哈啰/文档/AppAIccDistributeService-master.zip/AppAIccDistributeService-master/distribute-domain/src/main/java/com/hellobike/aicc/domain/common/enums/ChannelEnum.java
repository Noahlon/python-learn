package com.hellobike.aicc.domain.common.enums;

import com.hellobike.aicc.common.util.ApplicationContextHandle;
import com.hellobike.aicc.domain.channel.processor.ChannelProcessor;
import com.hellobike.aicc.domain.dialogue.handler.CallDialogueCallBackHandler;
import com.hellobike.aicc.domain.dialogue.handler.CssDialogueCallBackHandler;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * 渠道商枚举
 *
 * @author panlongqian
 * @since 2025-03-10
 */
@AllArgsConstructor
@Getter
public enum ChannelEnum {
    /**
     * 哈啰AI外呼
     */
    HELLO_AI_CALL(1, "哈啰AI外呼", "aiCallCenterProcessor");

    private final Integer channelId;

    private final String channelName;

    /**
     * 对应渠道商处理器的beanName，通过spring的getBean获取处理器
     */
    private final String channelProcessorName;

    public static ChannelProcessor getChannelProcessor(Integer channelId) {
        return Arrays.stream(values())
                .filter(channelEnum -> channelEnum.getChannelId().equals(channelId))
                .map(channelEnum -> ApplicationContextHandle.getBean(channelEnum.getChannelProcessorName(), ChannelProcessor.class))
                .findFirst()
                .orElse(null);
    }

    public static List<ChannelEnum> getAllChannel() {
        return Arrays.asList(values());
    }

    public static String getNameByCode(Integer code) {
        for (ChannelEnum channelEnum : ChannelEnum.values()) {
            if (channelEnum.getChannelId().equals(code)) {
                return channelEnum.getChannelName();
            }
        }
        return null;
    }

    /**
     * 获取对应渠道商的话单处理器
     *
     * @author zhangzhuoqi
     * @since 2025/3/14 14:10
     * @param channelEnum
     * @return CallDialogueCallbackHandler
     **/
    public static <C> CallDialogueCallBackHandler<C> getDialogueCallbackHandler(ChannelEnum channelEnum) {
        if (Objects.equals(channelEnum, ChannelEnum.HELLO_AI_CALL)){
            CssDialogueCallBackHandler bean = ApplicationContextHandle.getBean(CssDialogueCallBackHandler.class);
            return (CallDialogueCallBackHandler<C>) bean;
        }
        return null;
    }
}
