package com.hellobike.aicc.domain.roster.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.lang.Pair;
import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import com.google.common.collect.Lists;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.component.ApolloConfigs;
import com.hellobike.aicc.common.dto.DistPlanImpactRule;
import com.hellobike.aicc.common.enums.DistributeRecordTypeEnum;
import com.hellobike.aicc.common.enums.DistributeStatusEnum;
import com.hellobike.aicc.common.enums.DistributeTypeEnum;
import com.hellobike.aicc.common.enums.PlanChannelTaskStatusEnum;
import com.hellobike.aicc.common.enums.RosterDistributeStatusEnum;
import com.hellobike.aicc.common.enums.RosterTypeEnum;
import com.hellobike.aicc.common.enums.UploadStatusEnum;
import com.hellobike.aicc.common.enums.UploadTypeEnum;
import com.hellobike.aicc.common.enums.YesOrNoEnum;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.exception.BusinessException;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.common.util.ListUtils;
import com.hellobike.aicc.common.util.RedisKeyUtils;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.channel.factory.ChannelInfo;
import com.hellobike.aicc.domain.channel.processor.ChannelProcessor;
import com.hellobike.aicc.domain.common.service.DingTalkService;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanTemplateEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributeRuleEntity;
import com.hellobike.aicc.domain.distribute.repo.DistChannelTaskRepo;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.distribute.repo.DistPlanTemplateRepo;
import com.hellobike.aicc.domain.distribute.service.DistCalService;
import com.hellobike.aicc.domain.roster.dto.BatchUpdRosterFieldDTO;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterDTO;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterResultDTO;
import com.hellobike.aicc.domain.roster.dto.DistributeRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.dto.NameListDupCheckResultDTO;
import com.hellobike.aicc.domain.roster.dto.RosterAPIImportDTO;
import com.hellobike.aicc.domain.roster.dto.RosterImportResultDTO;
import com.hellobike.aicc.domain.roster.dto.RosterQueryConditionDTO;
import com.hellobike.aicc.domain.roster.dto.RosterRetryDistributeDTO;
import com.hellobike.aicc.domain.roster.dto.RosterUpdDTO;
import com.hellobike.aicc.domain.roster.dto.UploadRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.DistributeRecordEntity;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;
import com.hellobike.aicc.domain.roster.facade.RosterPortraitFacade;
import com.hellobike.aicc.domain.roster.repo.DistributeRecordRepository;
import com.hellobike.aicc.domain.roster.repo.PlanRosterRepository;
import com.hellobike.aicc.domain.roster.repo.UploadRecordRepository;
import com.hellobike.aicc.domain.roster.service.RosterDomainService;
import com.hellobike.aicc.domain.roster.service.RosterMsgService;
import com.hellobike.aicc.domain.utils.HammerThreadPoolUtil;
import com.hellobike.base.redis.core.client.IRedisHelper;
import com.hellobike.base.redis.core.lock.RedisLock;
import com.hellobike.base.redis.core.model.key.RouteKey;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;
import redis.clients.jedis.Response;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author zhangzhuoqi
 * @since 2025-03-07  16:43:57
 */
@Slf4j
@Service
public class RosterDomainServiceImpl implements RosterDomainService {
    @Resource
    private PlanRosterRepository planRosterRepository;

    @Resource
    private UploadRecordRepository uploadRecordRepository;

    @Resource
    private DistributeRecordRepository distributeRecordRepository;

    @Resource
    private DistPlanRepo distPlanRepo;

    @Resource
    private DistChannelTaskRepo distChannelTaskRepo;

    @Resource
    private IdGeneratorService idGeneratorService;

    @Resource
    private DistCalService distCalService;

    @Resource
    private IRedisHelper redisHelper;

    @Resource
    private ApolloConfigs apolloConfigs;

    private static final Integer asyncDistRecordExpireTime = 60 * 30;

    private final static String SPLIT = ".";

    @Resource
    private DingTalkService dingTalkService;

    @Resource
    private RosterPortraitFacade rosterPortraitFacade;

    @Resource
    private RosterMsgService rosterMsgService;

    @Resource
    private DistPlanTemplateRepo distPlanTemplateRepo;

    @Value("${channel.task.recheck:500}")
    private Long recheckTime;

    /**
     * 下发名单
     *
     * @param tenantCode       租户code（主要是给外呼使用）
     * @param rosterEntityList 所有待下发的名单集合
     **/
    private void doDistributeRoster(String tenantCode, List<PlanRosterEntity> rosterEntityList) {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();

        Long uploadRecordId = rosterEntityList.get(0).getUploadRecordId();
        Long distributePlanId = rosterEntityList.get(0).getDistributePlanId();
        UploadRecordEntity updUploadRecordEntity = new UploadRecordEntity();
        updUploadRecordEntity.setDistributePlanId(distributePlanId);
        updUploadRecordEntity.setId(uploadRecordId);
        log.info("开始下发名单，tenantCode:{},uploadRecordId:{},distributePlanId:{},size:{}", tenantCode, uploadRecordId, distributePlanId, rosterEntityList.size());

        rosterEntityList = rosterEntityList.stream().filter(roster -> Objects.equals(roster.getDistributeStatus(), RosterDistributeStatusEnum.PENDING.getCode())).collect(Collectors.toList());
        log.info("过滤出待下发名单,tenantCode:{},uploadRecordId:{},distributePlanId:{},size:{}", tenantCode, uploadRecordId, distributePlanId, rosterEntityList.size());
        if (CollectionUtil.isEmpty(rosterEntityList)) {
            log.info("待下发名单为空,uploadRecordId:{},distributePlanId:{}", uploadRecordId, distributePlanId);
            //修改上传记录（下发状态：无需下发）
            updUploadRecordEntity.setDistributeStatus(DistributeStatusEnum.NOT_DISTRIBUTE.getCode());
            uploadRecordRepository.updateRecordById(updUploadRecordEntity);
            return;
        }

        //更新上传记录（下发状态：下发中）
        updUploadRecordEntity.setDistributeStatus(DistributeStatusEnum.ING.getCode());
        uploadRecordRepository.updateRecordById(updUploadRecordEntity);
        //按照渠道id将名单分组，分组后的名单上传到对应渠道商
        Map<Integer, List<PlanRosterEntity>> channelMap = rosterEntityList.stream().collect(Collectors.groupingBy(PlanRosterEntity::getChannelId));
        List<CompletableFuture<Void>> futuresList = new ArrayList<>();
        channelMap.forEach((channelId, channelRosterList) -> {
            CompletableFuture<Void> future = CompletableFuture.runAsync(() -> distributeRosterByChannel(tenantCode, channelId, channelRosterList), HammerThreadPoolUtil.getRosterDistributeChannelExecutor());
            futuresList.add(future);
        });
        //等待所有渠道商下发完成
        CompletableFuture.allOf(futuresList.toArray(new CompletableFuture[0])).join();
        //更新上传记录（下发状态：下发完成）
        UploadRecordEntity uploadRecordEntity = new UploadRecordEntity();
        uploadRecordEntity.setId(uploadRecordId);
        uploadRecordEntity.setDistributePlanId(distributePlanId);
        uploadRecordEntity.setDistributeStatus(UploadStatusEnum.UPLOAD_SUCCESS.getCode());
        uploadRecordRepository.updateRecordById(uploadRecordEntity);
        stopWatch.stop();
        log.info("结束下发名单，tenantCode:{},size:{}，耗时:{}", tenantCode, rosterEntityList.size(), stopWatch.getTotalTimeMillis());
    }

    private void distributeRosterByChannel(String tenantCode, Integer channelId, List<PlanRosterEntity> channelRosterList) {
        log.info("开始下发渠道商，渠道id：{}，size：{}", channelId, channelRosterList.size());
        //在每个渠道商下按照下发记录分组（一条下发记录中的名单只会绑定在同一个渠道任务中）
        Map<Long, List<PlanRosterEntity>> distributeRecordMap = channelRosterList.stream().collect(Collectors.groupingBy(PlanRosterEntity::getDistributeRecordId));

        List<CompletableFuture<Void>> futuresList = new ArrayList<>();
        distributeRecordMap.forEach((distributeRecordId, distributeRecordRosterList) -> {
            //一条下发记录创建一个线程
            CompletableFuture<Void> future = CompletableFuture.runAsync(() -> distributeRosterByDistributeRecord(tenantCode, channelId, distributeRecordId, distributeRecordRosterList), HammerThreadPoolUtil.getRosterDistributeExecutor());
            futuresList.add(future);
        });
        CompletableFuture.allOf(futuresList.toArray(new CompletableFuture[0])).join();
    }

    private void distributeRosterByDistributeRecord(String tenantCode, Integer channelId, Long distributeRecordId, List<PlanRosterEntity> distributeRecordRosterList) {
        try {
            log.info("开始下发下发记录，下发记录id：{}，size：{}", distributeRecordId, distributeRecordRosterList.size());
            if (CollectionUtil.isEmpty(distributeRecordRosterList)) {
                return;
            }

            String supplierTaskId = distributeRecordRosterList.get(0).getSupplierTaskId();
            Long uploadRecordId = distributeRecordRosterList.get(0).getUploadRecordId();
            Long channelTaskId = distributeRecordRosterList.get(0).getChannelTaskId();
            Long distributePlanId = distributeRecordRosterList.get(0).getDistributePlanId();
            Integer rosterType = distributeRecordRosterList.get(0).getRosterType();

            //更新下发记录（下发状态：下发中，下发时间）
            LocalDateTime distTime = LocalDateTime.now();
            DistributeRecordEntity distributeRecordEntity = new DistributeRecordEntity();
            distributeRecordEntity.setId(distributeRecordId);
            distributeRecordEntity.setDistributeTime(distTime);
            distributeRecordEntity.setDistributeStatus(DistributeStatusEnum.ING.getCode());
            distributeRecordEntity.setDistributePlanId(distributePlanId);
            distributeRecordRepository.updateRecordById(distributeRecordEntity);

            // 查询渠道商详情
            ChannelInfo channelInfo = ChannelFactory.getChannel(channelId);
            if (channelInfo == null) {
                throw new BusinessException(BusinessErrorCode.NO_CHANNEL_ERROR);
            }

            ChannelProcessor channelProcessor = ChannelFactory.getChannelProcessor(channelId);

            Integer importRosterLimit = channelInfo.getImportRosterLimit();
            if (Objects.isNull(importRosterLimit) || importRosterLimit <= 0) {
                importRosterLimit = apolloConfigs.getImportRosterLimit();
            }
            //分批处理
            List<List<PlanRosterEntity>> partition = Lists.partition(distributeRecordRosterList, importRosterLimit);
            for (List<PlanRosterEntity> rosterList : partition) {
                ChannelImportRosterDTO channelImportRosterDTO = new ChannelImportRosterDTO();
                channelImportRosterDTO.setTenantCode(tenantCode);
                channelImportRosterDTO.setSupplierTaskId(supplierTaskId);
                channelImportRosterDTO.setDistributePlanId(distributePlanId);
                channelImportRosterDTO.setRosterEntityList(rosterList);

                //对接外部渠道商增加appKey参数
                channelImportRosterDTO.setAppKey(channelInfo.getAppKey());
                channelImportRosterDTO.setRosterType(rosterType);

                ChannelImportRosterResultDTO resultDTO = channelProcessor.importRoster(channelImportRosterDTO);
                int totalNum = rosterList.size();
                Integer successCount = resultDTO.getSuccessCount();
                Integer failCount = resultDTO.getFailCount();
                log.info("当前批次上传结果,channelId:{},distributeRecordId:{},successCount:{},failCount:{}", channelId, distributeRecordId, successCount, failCount);
                if (successCount <= 0 && failCount <= 0) {
                    continue;
                }
                LocalDateTime nowTime = LocalDateTime.now();
                //更新渠道任务（下发数量、下发成功数量、最近下发时间）
                DistributeChannelTaskEntity channelTaskEntity = new DistributeChannelTaskEntity();
                channelTaskEntity.setId(channelTaskId);
                channelTaskEntity.setSentTotalNum((long) totalNum);
                channelTaskEntity.setSentSuccessNum((long) successCount);
                channelTaskEntity.setLatestSentTime(nowTime);
                log.info("更新渠道任务，channelId:{},distributeRecordId:{},sentTotalNum:{},sentSuccessNum:{}", channelId, distributeRecordId, totalNum, successCount);
                distChannelTaskRepo.updateWhenDistribute(channelTaskEntity);
                //更新上传记录（下发数量）
                UploadRecordEntity uploadRecordEntity = new UploadRecordEntity();
                uploadRecordEntity.setId(uploadRecordId);
                uploadRecordEntity.setDistributeCount(totalNum);
                uploadRecordEntity.setDistributePlanId(distributePlanId);
                log.info("更新上传记录，uploadRecordId:{},distributeCount:{}", uploadRecordId, totalNum);
                uploadRecordRepository.updateWhenDistribute(uploadRecordEntity);
                //更新下发记录（下发数量，成功数量）
                DistributeRecordEntity distributeRecord = new DistributeRecordEntity();
                distributeRecord.setDistributeCount(totalNum);
                distributeRecord.setSuccessCount(successCount);
                distributeRecord.setDistributePlanId(distributePlanId);
                distributeRecord.setId(distributeRecordId);
                distributeRecordRepository.updateRecordById(distributeRecord);

                //更新当前一批名单状态（下发完成/下发失败）
                RosterDistributeStatusEnum rosterDistributeStatusEnum;
                if (resultDTO.isAllFail()) {
                    rosterDistributeStatusEnum = RosterDistributeStatusEnum.FAILED;
                } else {
                    rosterDistributeStatusEnum = RosterDistributeStatusEnum.FINISHED;
                }
                log.info("更新当前一批名单状态，size:{},rosterDistributeStatusEnum:{}", rosterList.size(), rosterDistributeStatusEnum.getDesc());
                BatchUpdRosterFieldDTO batchUpdRosterFieldDTO = new BatchUpdRosterFieldDTO();
                batchUpdRosterFieldDTO.setRosterDistStatusEnum(rosterDistributeStatusEnum);
                batchUpdRosterFieldDTO.setDistributeTime(nowTime);
                planRosterRepository.batchUpdWhenDistById(rosterList, batchUpdRosterFieldDTO);

                //发送名单更新消息
                this.batchSendRosterUpdMsg(rosterList);

            }
            //更新下发记录（下发状态：下发完成）
            distributeRecordEntity.setDistributeStatus(DistributeStatusEnum.SUCCESS.getCode());
            distributeRecordEntity.setDistributePlanId(distributePlanId);
            distributeRecordRepository.updateRecordById(distributeRecordEntity);
        } catch (Exception e) {
            log.error("下发下发记录异常，下发记录id：{},e:", distributeRecordId, e);

        }

    }

    @Override
    public PageResult<UploadRecordEntity> pageUploadRecord(UploadRecordQueryConditionDTO conditionDTO, Integer pageNum, Integer pageSize) {

        return uploadRecordRepository.pageByCondition(conditionDTO, pageNum, pageSize);
    }

    @Override
    public PageResult<DistributeRecordEntity> pageDistributeRecord(DistributeRecordQueryConditionDTO conditionDTO, Integer pageNum, Integer pageSize) {

        return distributeRecordRepository.pageByCondition(conditionDTO, pageNum, pageSize);
    }

    @Override
    public void retryDistribute(RosterRetryDistributeDTO retryDistributeDTO) {
        log.info("开始重试下发,req:{}", BaseJsonUtils.writeValue(retryDistributeDTO));
        DistributePlanEntity distributePlanEntity = distPlanRepo.queryDistributePlanById(Long.valueOf(retryDistributeDTO.getDistributePlanId()));

        //查询分流计划下所有渠道任务是否全部创建成功
        Long distributePlanId = distributePlanEntity.getId();
        List<DistributeChannelTaskEntity> distTaskList = distChannelTaskRepo.queryDistributePlanTaskList(distributePlanId);
        boolean taskOk = checkChannelTaskStatus(distributePlanEntity, distTaskList);
        AssertUtils.isTrue(taskOk, BusinessErrorCode.TASK_NOT_SUCCESS);

        //查询上传记录
        Long uploadRecordId = Long.valueOf(retryDistributeDTO.getUploadRecordId());
        UploadRecordEntity uploadRecordEntity = uploadRecordRepository.getRecordById(uploadRecordId, distributePlanId);
        AssertUtils.notNull(uploadRecordEntity, BusinessErrorCode.UPLOAD_RECORD_NOT_NULL);
        AssertUtils.isTrue(Objects.equals(uploadRecordEntity.getDistributeStatus(), DistributeStatusEnum.FAIL.getCode()), BusinessErrorCode.UPLOAD_STATUS_NOT_FAIL);
        AssertUtils.isTrue(Objects.equals(uploadRecordEntity.getUploadStatus(), DistributeStatusEnum.SUCCESS.getCode()), BusinessErrorCode.UPLOAD_STATUS_NOT_SUCCESS);

        //查询下发记录，如果有下发记录了不允许重试下发
        DistributeRecordQueryConditionDTO distRecordCon = new DistributeRecordQueryConditionDTO();
        distRecordCon.setDistributePlanId(distributePlanId);
        distRecordCon.setUploadRecordId(uploadRecordId);
        List<DistributeRecordEntity> distRecordList = distributeRecordRepository.queryByCondition(distRecordCon);
        AssertUtils.isEmpty(distRecordList, BusinessErrorCode.RETRY_DIST_RECORD_EXIST);

        //修改上传记录下发状态为未下发
        UploadRecordEntity updUploadRecordEntity = new UploadRecordEntity();
        updUploadRecordEntity.setDistributePlanId(distributePlanId);
        updUploadRecordEntity.setId(uploadRecordId);
        updUploadRecordEntity.setDistributeStatus(DistributeStatusEnum.PENDING.getCode());
        uploadRecordRepository.updateRecordById(updUploadRecordEntity);

        //异步执行
        CompletableFuture.runAsync(() -> {
            //查询出当前上传记录中的所有名单
            RosterQueryConditionDTO rosterQryConditionD = new RosterQueryConditionDTO();
            rosterQryConditionD.setDistributePlanId(distributePlanId);
            rosterQryConditionD.setUploadRecordId(Long.valueOf(retryDistributeDTO.getUploadRecordId()));
            rosterQryConditionD.setDistributeStatus(RosterDistributeStatusEnum.PENDING);
            //只查询待下发名单
            List<PlanRosterEntity> entityList = planRosterRepository.queryByCondition(distributePlanId, rosterQryConditionD);
            if (CollectionUtils.isEmpty(entityList)) {
                log.error("重试下发，名单量为空,distributePlanId:{}", distributePlanId);
                return;
            }

            //分流计算
            distCalService.decide(distributePlanEntity, distTaskList, entityList);
            //名单分流绑定任务后绑定下发记录
            this.rosterCreateAndBindDistRecord(distributePlanEntity, distTaskList, uploadRecordId, DistributeRecordTypeEnum.PREPARE, DistributeStatusEnum.PENDING, entityList);
            //分批更新名单（下发记录id，名单状态，渠道任务id）
            this.batchUpdRosterWhenRetry(entityList);
            //名单保存完后更新下发记录为正式下发
            distributeRecordRepository.updateRecordType(uploadRecordId, distributePlanId, DistributeRecordTypeEnum.FORMAL);
            //下发名单
            doDistributeRoster(distributePlanEntity.getTenantCode(), entityList);
        });
    }

    private void batchUpdRosterWhenRetry(List<PlanRosterEntity> entityList) {
        planRosterRepository.batchUpdateById(entityList);
        //发送名单更新消息
        batchSendRosterUpdMsg(entityList);
    }

    /**
     * 创建下发记录并且名单绑定下发记录
     *
     * @param distributePlanEntity 下发计划
     * @param distTaskList         渠道任务列表
     * @param uploadRecordId       上传记录id
     * @param recordTypeEnum       下发记录类型
     * @param distStatusEnum       下发状态
     * @param entityList           名单列表
     * @return void
     * @author zhangzhuoqi
     * @since 2025/3/19 19:59
     **/
    private void rosterCreateAndBindDistRecord(DistributePlanEntity distributePlanEntity,
                                               List<DistributeChannelTaskEntity> distTaskList,
                                               Long uploadRecordId,
                                               DistributeRecordTypeEnum recordTypeEnum,
                                               DistributeStatusEnum distStatusEnum,
                                               List<PlanRosterEntity> entityList) {

        List<DistributeRecordEntity> distRecordList = this.createDistRecord(distributePlanEntity, distTaskList, uploadRecordId, recordTypeEnum, distStatusEnum, entityList);

        //名单绑定任务
        this.rosterBindDistRecord(distRecordList, entityList);

    }

    private void rosterBindDistRecord(List<DistributeRecordEntity> distRecordList, List<PlanRosterEntity> entityList) {
        if (CollectionUtils.isEmpty(distRecordList)) {
            log.info("名单绑定下发记录，下发记录为空");
            return;
        }
        //下发记录按照渠道任务分组,此时一个渠道任务对应一条下发记录
        Map<Long, DistributeRecordEntity> distRecordMap = distRecordList.stream().collect(Collectors.toMap(DistributeRecordEntity::getChannelTaskId, Function.identity(), (k1, k2) -> k1));
        for (PlanRosterEntity planRosterEntity : entityList) {
            if (Objects.isNull(planRosterEntity.getChannelTaskId())) {
                log.info("当前名单渠道任务id为空，跳过id:{}", planRosterEntity.getId());
                continue;
            }
            if (!distRecordMap.containsKey(planRosterEntity.getChannelTaskId())) {
                //正常情况名单中绑定的渠道任务id一定会在下发记录中找到
                throw new BusinessException(BusinessErrorCode.ROSTER_TASK_ERROR);
            }
            planRosterEntity.setDistributeRecordId(distRecordMap.get(planRosterEntity.getChannelTaskId()).getId());
        }
    }

    /**
     * 创建下发记录
     *
     * @param distributePlanEntity 分流计划
     * @param distTaskList         渠道任务列表
     * @param uploadRecordId       上传记录id
     * @param recordTypeEnum       下发记录类型
     * @param distStatusEnum       下发状态
     * @return List<DistributeRecordEntity>
     * @author zhangzhuoqi
     * @since 2025/3/19 20:09
     **/
    private List<DistributeRecordEntity> createDistRecord(DistributePlanEntity distributePlanEntity,
                                                          List<DistributeChannelTaskEntity> distTaskList,
                                                          Long uploadRecordId,
                                                          DistributeRecordTypeEnum recordTypeEnum,
                                                          DistributeStatusEnum distStatusEnum,
                                                          List<PlanRosterEntity> rosterList) {
        Map<String, DistributeRuleEntity> ruleMap = distributePlanEntity.getDistributeRuleList().stream().collect(Collectors.toMap(DistributeRuleEntity::getPlanChannelTaskId, Function.identity(), (k1, k2) -> k1));
        //名单已经分配了的任务，当名单数量很少时，如果有多个任务，只有一个任务被分配了名单，这个时候只创建一条下发记录
        Set<Long> distRosterTaskSet = rosterList.stream().map(PlanRosterEntity::getChannelTaskId).collect(Collectors.toSet());
        //一个渠道任务创建一条下发记录
        List<DistributeRecordEntity> distRecordList = distTaskList.stream().map(task -> {
            DistributeRecordEntity distributeRecordEntity = new DistributeRecordEntity();
            DistributeRuleEntity distributeRuleEntity = ruleMap.get(String.valueOf(task.getId()));
            //比例为0的不创建下发记录
            if (BigDecimal.ZERO.compareTo(distributeRuleEntity.getPercentage()) >= 0) {
                log.info("任务分流比例为0，不创建下发记录,channelTaskId:{}", task.getId());
                return null;
            }
            if (!distRosterTaskSet.contains(task.getId())) {
                log.info("名单中不包含该任务，不创建下发记录,channelTaskId:{}", task.getId());
                return null;
            }
            distributeRecordEntity.setId(idGeneratorService.getLongId());
            distributeRecordEntity.setDistributePlanId(distributePlanEntity.getId());
            distributeRecordEntity.setDistributeStatus(distStatusEnum.getCode());
            distributeRecordEntity.setDistributeType(recordTypeEnum.getCode());
            distributeRecordEntity.setChannelTaskId(task.getId());
            distributeRecordEntity.setSupplierTaskId(task.getSupplierTaskId());
            distributeRecordEntity.setSupplierTaskName(task.getSupplierTaskName());
            distributeRecordEntity.setChannelId(Integer.parseInt(task.getChannelId()));
            distributeRecordEntity.setUploadRecordId(uploadRecordId);
            return distributeRecordEntity;
        }).filter(Objects::nonNull).collect(Collectors.toList());

        log.info("创建下发记录,list:{}", distRecordList);
        distributeRecordRepository.batchAddRecord(distRecordList);
        return distRecordList;
    }

    private boolean checkChannelTaskStatus(DistributePlanEntity distributePlanEntity, List<DistributeChannelTaskEntity> distTaskList) {
        Map<String, DistributeChannelTaskEntity> identifyMap = distTaskList.stream().collect(Collectors.toMap(it -> it.getChannelId() + "-" + it.getSupplierTaskTemplateId(), it -> it));
        for (DistributeRuleEntity ruleEntity : distributePlanEntity.getDistributeRuleList()) {
            String identify = ruleEntity.getChannelId() + "-" + ruleEntity.getTaskTemplateId();
            DistributeChannelTaskEntity taskEntity = identifyMap.get(identify);
            //如果分流规则中查不到渠道任务则标识任务尚未创建
            if (Objects.isNull(taskEntity)) {
                return false;
            }
            // 将计划渠道任务表id填充到规则中
            ruleEntity.setPlanChannelTaskId(String.valueOf(taskEntity.getId()));
            //若果渠道任务创建失败，并且比例不为0，则不允许下发
            if (!Objects.equals(taskEntity.getTaskStatus(), PlanChannelTaskStatusEnum.SUCCESS.getCode()) && BigDecimal.ZERO.compareTo(ruleEntity.getPercentage()) < 0) {
                return false;
            }
        }
        return true;
    }

    @Override
    public NameListDupCheckResultDTO rosterDupCheck(List<PlanRosterEntity> rosterEntityList, boolean isUseMultiThead) {
        if (CollectionUtils.isEmpty(rosterEntityList)) {
            return new NameListDupCheckResultDTO(0, new ArrayList<>());
        }
        // 填充分表字段并根据分表字段进行分组
        rosterEntityList.forEach(PlanRosterEntity::fillRosterPartitionCode);
        Map<String, List<PlanRosterEntity>> groupMap = rosterEntityList.stream().collect(Collectors.groupingBy(PlanRosterEntity::getPartitionCode));
        //是否需要多线程来查询数据库去重，在文件导入的时候用多线程查询提高效率
        if (!isUseMultiThead) {
            int duplicationCount = 0;
            List<PlanRosterEntity> insertList = new ArrayList<>();
            for (Map.Entry<String, List<PlanRosterEntity>> entry : groupMap.entrySet()) {
                List<PlanRosterEntity> rosterList = entry.getValue();
                List<List<PlanRosterEntity>> partition = Lists.partition(rosterList, apolloConfigs.getBatchSaveNameListSize());
                for (List<PlanRosterEntity> part : partition) {
                    NameListDupCheckResultDTO checkResult = checkDupRoster(part);
                    duplicationCount += checkResult.getDuplicationCount();
                    insertList.addAll(checkResult.getInsertEntityList());
                }
                rosterList.clear();
            }
            return new NameListDupCheckResultDTO(duplicationCount, insertList);
        }
        AtomicInteger duplicationCount = new AtomicInteger(0);
        List<PlanRosterEntity> insertList = new ArrayList<>();
        Long distributePlanId = rosterEntityList.get(0).getDistributePlanId();
        log.info("开始名单去重,planId:{}", distributePlanId);
        List<CompletableFuture<List<PlanRosterEntity>>> futureList = new ArrayList<>();
        for (Map.Entry<String, List<PlanRosterEntity>> entry : groupMap.entrySet()) {
            CompletableFuture<List<PlanRosterEntity>> future = CompletableFuture.supplyAsync(() -> {
                log.info("当前分组名单开始去重,planId:{},key:{}", distributePlanId, entry.getKey());
                long startTime = System.currentTimeMillis();
                List<PlanRosterEntity> rosterList = entry.getValue();
                List<List<PlanRosterEntity>> partition = Lists.partition(rosterList, apolloConfigs.getBatchSaveNameListSize());
                List<PlanRosterEntity> rosters = new ArrayList<>();
                for (List<PlanRosterEntity> part : partition) {
                    NameListDupCheckResultDTO checkResult = checkDupRoster(part);
                    duplicationCount.getAndAdd(checkResult.getDuplicationCount());
                    if (CollectionUtils.isNotEmpty(checkResult.getInsertEntityList())) {
                        rosters.addAll(checkResult.getInsertEntityList());
                    }
                }
                log.info("当前分组名单结束去重,planId:{},key:{},耗时:{}", distributePlanId, entry.getKey(), System.currentTimeMillis() - startTime);
                rosterList.clear();
                return rosters;
            }, HammerThreadPoolUtil.getRosterSaveExecutor());
            futureList.add(future);
        }
        CompletableFuture.allOf(futureList.toArray(new CompletableFuture[0])).join();
        for (CompletableFuture<List<PlanRosterEntity>> future : futureList) {
            try {
                insertList.addAll(future.get());
            } catch (Exception e) {
                log.error("线程异常，e:", e);
            }
        }
        log.info("结束名单去重,planId:{}", distributePlanId);
        return new NameListDupCheckResultDTO(duplicationCount.get(), insertList);
    }

    private void bindUploadRecord(List<PlanRosterEntity> entityList, Long uploadRecordId) {
        LocalDateTime now = LocalDateTime.now();
        entityList.forEach(it -> {
            it.setUploadRecordId(uploadRecordId);
            it.setUploadTime(now);
            it.setPlatformId(IdUtil.fastSimpleUUID());
        });
    }

    private UploadRecordEntity buildUploadRecord(DistributePlanEntity distributePlan, UploadStatusEnum uploadStatus, String operator, RosterTypeEnum rosterType) {
        UploadRecordEntity uploadRecordEntity = new UploadRecordEntity();
        uploadRecordEntity.setId(idGeneratorService.getLongId());
        uploadRecordEntity.setUploadStatus(uploadStatus.getCode());
        uploadRecordEntity.setUploadTime(LocalDateTime.now());
        uploadRecordEntity.setOperator(operator);
        uploadRecordEntity.setDistributeType(distributePlan.getDistributeType());
        uploadRecordEntity.setDistributePlanId(distributePlan.getId());
        if (Objects.nonNull(rosterType)) {
            uploadRecordEntity.setRosterType(rosterType.getCode());
        } else {
            uploadRecordEntity.setRosterType(RosterTypeEnum.TELEPHONE.getCode());
        }
        return uploadRecordEntity;
    }

    /**
     * 创建上传记录，填充导入名单的数据
     */
    private UploadRecordEntity paddingUploadRecord(DistributeStatusEnum distributeStatus,
                                                   UploadStatusEnum uploadStatus,
                                                   UploadTypeEnum uploadType,
                                                   List<PlanRosterEntity> entityList,
                                                   DistributePlanEntity distributePlan,
                                                   String operator,
                                                   RosterTypeEnum rosterType) {
        UploadRecordEntity uploadRecordEntity = buildUploadRecord(distributePlan, uploadStatus, operator, rosterType);
        uploadRecordEntity.setUploadType(uploadType.getCode());
        uploadRecordEntity.setDistributeStatus(distributeStatus.getCode());
        uploadRecordRepository.addRecord(uploadRecordEntity);

        // 关联上传记录，名单状态为未下发
        bindUploadRecord(entityList, uploadRecordEntity.getId());
        return uploadRecordEntity;
    }

    @Override
    public void fileImportRoster(List<PlanRosterEntity> rosters, DistributePlanEntity distributePlan, String operator, UploadRecordEntity uploadRecordEntity) {
        List<DistributeChannelTaskEntity> distTaskList = distChannelTaskRepo.queryDistributePlanTaskList(distributePlan.getId());
        //名单撞库
        this.impactRoster(distributePlan, rosters);
        boolean taskCreated = checkChannelTaskStatus(distributePlan, distTaskList);
        if (!taskCreated) {
            // 有未创建成功的渠道任务，不允许下发
            this.sendRosterDistFailedAlert(distributePlan);
            log.warn("有未创建成功的渠道任务，不允许下发,分流计划id为：{}", distributePlan.getId());
            // 更新上传记录，上传状态为上传中
            uploadRecordEntity.setUploadStatus(UploadStatusEnum.UPLOAD_ING.getCode());
            uploadRecordRepository.updateRecordById(uploadRecordEntity);
            // 关联上传记录，名单状态为未下发
            bindUploadRecord(rosters, uploadRecordEntity.getId());
            batchSaveRoster(rosters, distributePlan);
            // 名单保存完成，更新上传记录状态为上传完成，下发状态为下发失败
            uploadRecordEntity.setUploadStatus(UploadStatusEnum.UPLOAD_SUCCESS.getCode());
            uploadRecordEntity.setDistributeStatus(DistributeStatusEnum.FAIL.getCode());
            uploadRecordRepository.updateRecordById(uploadRecordEntity);
            return;
        }

        // 更新上传状态为上传中，下发状态为待下发；同时创建绑定下发记录
        uploadRecordEntity.setUploadStatus(UploadStatusEnum.UPLOAD_ING.getCode());
        uploadRecordEntity.setDistributeStatus(DistributeStatusEnum.PENDING.getCode());
        uploadRecordRepository.updateRecordById(uploadRecordEntity);
        bindUploadRecord(rosters, uploadRecordEntity.getId());

        // 2.分流计算，将名单填充渠道任务信息
        distCalService.decide(distributePlan, distTaskList, rosters);
        // 绑定下发记录
        rosterCreateAndBindDistRecord(distributePlan, distTaskList, uploadRecordEntity.getId(), DistributeRecordTypeEnum.PREPARE, DistributeStatusEnum.PENDING, rosters);

        //批量保存名单
        batchSaveRoster(rosters, distributePlan);

        //名单保存完后，更新下发记录为正式下发
        distributeRecordRepository.updateRecordType(uploadRecordEntity.getId(), distributePlan.getId(), DistributeRecordTypeEnum.FORMAL);
        // 3.名单保存完成，更新上传记录状态为上传完成
        uploadRecordEntity.setUploadStatus(UploadStatusEnum.UPLOAD_SUCCESS.getCode());
        uploadRecordRepository.updateRecordById(uploadRecordEntity);
        // 4.异步下发名单
        doDistributeRoster(distributePlan.getTenantCode(), rosters);
    }

    @Override
    public RosterImportResultDTO apiImportRoster(RosterAPIImportDTO apiImportDTO) {
        Long distributePlanId = Long.valueOf(apiImportDTO.getDistributePlanId());
        DistributePlanEntity planEntity = distPlanRepo.queryDistributePlanById(distributePlanId);
        AssertUtils.notNull(planEntity, BusinessErrorCode.DIST_NOT_EXIST_ERROR);
        AssertUtils.isTrue(Objects.equals(planEntity.getTenantCode(), apiImportDTO.getTenantId()), BusinessErrorCode.API_ROSTER_TENANT_ERROR);

        final int totalCount = apiImportDTO.getRosterEntityList().size();
        //校验名单数据并且去重
        RosterImportResultDTO resultDTO = this.checkApiImport(apiImportDTO, planEntity);
        if (resultDTO.getFailCount() + resultDTO.getDuplicationCount() >= totalCount) {
            //如果错误数量和重复数量大于等于总数量，则直接返回
            return resultDTO;
        }
        List<PlanRosterEntity> finalRosterList = resultDTO.getFinalRosterList();

        finalRosterList.forEach(it -> it.setId(idGeneratorService.getLongId()));
        resultDTO.setSuccessCount(finalRosterList.size());
        //名单撞库
        //todo 移到下发的步骤中进行处理
        this.impactRoster(planEntity, finalRosterList);
        //校验渠道任务是否都创建成功
        List<DistributeChannelTaskEntity> channelTaskList = distChannelTaskRepo.queryDistributePlanTaskList(distributePlanId);
        boolean taskSuccess = this.checkChannelTaskStatus(planEntity, channelTaskList);
        if (!taskSuccess) {
            //等待500ms后再检查一次
            try {
                log.warn("分流计划渠道任务未创建，需等待重试，id为：{}，任务:{}", distributePlanId, BaseJsonUtils.writeValue(channelTaskList));
                ThreadUtil.sleep(recheckTime);
                channelTaskList = distChannelTaskRepo.queryDistributePlanTaskList(distributePlanId);
                taskSuccess = this.checkChannelTaskStatus(planEntity, channelTaskList);
            } catch (Exception e) {
                log.error("recheckChannelTaskError：{}", distributePlanId, e);
            }
            if (!taskSuccess) {
                log.warn("分流计划渠道任务重试后依然未成功，id为：{}，任务:{}", distributePlanId, BaseJsonUtils.writeValue(channelTaskList));
                this.sendRosterDistFailedAlert(planEntity);
                // 有未创建成功的渠道任务，不允许下发
                log.warn("接口上传名单，有未创建成功的渠道任务，不允许下发,分流计划id为：{}", distributePlanId);
                // 创建一条上传记录，上传状态为上传中，下发状态为未下发
                RosterTypeEnum rosterType = RosterTypeEnum.getByCode(apiImportDTO.getRosterType());
                UploadRecordEntity uploadRecordEntity = paddingUploadRecord(DistributeStatusEnum.PENDING, UploadStatusEnum.UPLOAD_ING, UploadTypeEnum.INTERFACE, finalRosterList, planEntity, apiImportDTO.getTenantId(), rosterType);
                //分批保存名单并且更新上传数量
                batchSaveRoster(finalRosterList, planEntity);
                //更新上传记录(上传状态：上传完成；下发状态：下发失败)
                UploadRecordEntity updRecord = new UploadRecordEntity();
                updRecord.setId(uploadRecordEntity.getId());
                updRecord.setDistributePlanId(planEntity.getId());
                updRecord.setUploadStatus(UploadStatusEnum.UPLOAD_SUCCESS.getCode());
                updRecord.setDistributeStatus(DistributeStatusEnum.FAIL.getCode());
                uploadRecordRepository.updateRecordById(updRecord);
                return resultDTO;
            }
        }

        try {
            boolean isSyncDist = Objects.equals(planEntity.getDistributeType(), DistributeTypeEnum.SYNC.getCode());
            if (isSyncDist) {
                //实时分流
                doSyncDist(planEntity, finalRosterList, channelTaskList);
            } else {
                //离线分流
                doAsyncDist(planEntity, finalRosterList, channelTaskList);
            }
        } catch (Exception e) {
            log.error("接口分流错误,e:", e);
            resultDTO.setFailCount(resultDTO.getFailCount() + finalRosterList.size());
            resultDTO.setSuccessCount(0);
        }

        return resultDTO;
    }

    private void sendRosterDistFailedAlert(DistributePlanEntity planEntity) {
        DistributePlanTemplateEntity templateEntity = distPlanTemplateRepo.queryById(planEntity.getTemplateId());
        String templateName = null;
        if (Objects.nonNull(templateEntity)) {
            templateName = templateEntity.getTemplateName();
        }
        dingTalkService.sendRosterDistributeFailedAlert(planEntity.getId(), templateEntity.getTenantName(), templateName, "有未创建成功的渠道任务，不允许下发");
    }

    @Override
    public void aggDistribute() {
        //查询所有离线的分流计划
        List<Long> planIdList = distPlanRepo.queryByDistType(DistributeTypeEnum.ASYNC);
        if (CollectionUtils.isEmpty(planIdList)) {
            return;
        }

        List<UploadRecordEntity> needDistUpdRecordList = new ArrayList<>();
        //计划id分表键，只能循环查询
        for (Long planId : planIdList) {
            //查询上传中&未下发&离线分流&接口上传&超过{uploadRecordAggSeconds} + 10秒的上传记录
            UploadRecordQueryConditionDTO updQryCon = new UploadRecordQueryConditionDTO();
            updQryCon.setDistributePlanId(planId);
            updQryCon.setUploadStatus(UploadStatusEnum.UPLOAD_ING.getCode());
            updQryCon.setDistributeStatus(DistributeStatusEnum.PENDING.getCode());
            updQryCon.setDistributeType(DistributeTypeEnum.ASYNC.getCode());
            updQryCon.setUploadType(UploadTypeEnum.INTERFACE.getCode());
            LocalDateTime now = LocalDateTime.now();
            updQryCon.setStartCreateTime(now.minusSeconds(asyncDistRecordExpireTime));
            updQryCon.setEndCreateTime(now.minusSeconds(apolloConfigs.getUploadRecordAggSeconds() + 10));
            List<UploadRecordEntity> updRecordList = uploadRecordRepository.queryByCondition(updQryCon);
            if (CollectionUtils.isEmpty(updRecordList)) {
                continue;
            }
            for (UploadRecordEntity uploadRecordEntity : updRecordList) {
                //redis查询聚合记录，看是否还有正在聚合的请求
                Long updRecordId = uploadRecordEntity.getId();
                String value = redisHelper.get(RedisKeyUtils.asyncDistRecorcKey(String.valueOf(updRecordId)));
                if (StrUtil.isBlank(value)) {
                    log.error("redis查询聚合记录,未查询到聚合记录，updRecordId:{}", updRecordId);
                    continue;
                }
                if (Integer.parseInt(value) > 0) {
                    log.error("redis查询聚合记录,当前上传记录正在被聚合，不允许下发，updRecordId:{},value:{}", updRecordId, value);
                    continue;
                }
                needDistUpdRecordList.add(uploadRecordEntity);
            }
        }

        log.info("聚合下发名单，需要下发的上传记录:{}", needDistUpdRecordList);
        //一批一批的下发
        for (UploadRecordEntity recordEntity : needDistUpdRecordList) {
            //修改上传记录（上传状态：上传完成；下发状态：下发中）
            UploadRecordEntity updateRecord = new UploadRecordEntity();
            updateRecord.setId(recordEntity.getId());
            updateRecord.setUploadStatus(UploadStatusEnum.UPLOAD_SUCCESS.getCode());
            updateRecord.setDistributePlanId(recordEntity.getDistributePlanId());
            uploadRecordRepository.updateRecordById(updateRecord);
            //更新下发记录（下发类型：正式下发）
            distributeRecordRepository.updateRecordType(recordEntity.getId(), recordEntity.getDistributePlanId(), DistributeRecordTypeEnum.FORMAL);
            DistributePlanEntity planEntity = distPlanRepo.queryDistributePlanById(recordEntity.getDistributePlanId());
            RosterQueryConditionDTO rosterQryCon = new RosterQueryConditionDTO();
            rosterQryCon.setUploadRecordId(recordEntity.getId());
            rosterQryCon.setDistributeStatus(RosterDistributeStatusEnum.PENDING);
            //只查询待下发名单
            List<PlanRosterEntity> rosterEntityList = planRosterRepository.queryByCondition(planEntity.getId(), rosterQryCon);
            if (CollectionUtils.isEmpty(rosterEntityList)) {
                log.info("聚合下发名单为空,uploadId:{}", recordEntity.getId());
                continue;
            }
            log.info("聚合下发名单，需要下发的记录数:{}", rosterEntityList.size());
            //异步下发
            CompletableFuture.runAsync(() -> doDistributeRoster(planEntity.getTenantCode(), rosterEntityList), HammerThreadPoolUtil.getRosterUploadExecutor());
        }
    }

    @Override
    public void retryDistCompensate(Long distributePlanId, Long channelTaskId) {
        DistributePlanEntity distributePlanEntity = distPlanRepo.queryDistributePlanById(distributePlanId);
        DistributeRecordQueryConditionDTO distRecordCondition = new DistributeRecordQueryConditionDTO();
        distRecordCondition.setChannelTaskId(channelTaskId);
        distRecordCondition.setDistributePlanId(distributePlanEntity.getId());
        List<DistributeRecordEntity> distRecordList = distributeRecordRepository.queryByCondition(distRecordCondition);
        if (CollectionUtil.isEmpty(distRecordList)) {
            log.info("下发记录为空,channelTaskId:{}", channelTaskId);
            return;
        }

        for (DistributeRecordEntity distributeRecord : distRecordList) {
            Long distributeRecordId = distributeRecord.getId();
            try {
                RosterQueryConditionDTO rosterCondition = new RosterQueryConditionDTO();
                rosterCondition.setDistributeRecordId(distributeRecordId);
                rosterCondition.setUploadRecordId(distributeRecord.getUploadRecordId());
                List<PlanRosterEntity> distributeRecordRosterList = planRosterRepository.queryByCondition(distributePlanId, rosterCondition);
                log.info("开始下发下发记录，下发记录id：{}，size：{}", distributeRecordId, distributeRecordRosterList.size());
                if (CollectionUtil.isEmpty(distributeRecordRosterList)) {
                    return;
                }

                String supplierTaskId = distributeRecordRosterList.get(0).getSupplierTaskId();
                Long uploadRecordId = distributeRecordRosterList.get(0).getUploadRecordId();
                Integer rosterType = distributeRecordRosterList.get(0).getRosterType();
                Integer channelId = distributeRecordRosterList.get(0).getChannelId();
                String tenantCode = distributePlanEntity.getTenantCode();

                //更新下发记录（下发状态：下发中，下发时间）
                LocalDateTime distTime = LocalDateTime.now();
                DistributeRecordEntity distributeRecordEntity = new DistributeRecordEntity();
                distributeRecordEntity.setId(distributeRecordId);
                distributeRecordEntity.setDistributeTime(distTime);
                distributeRecordEntity.setDistributeStatus(DistributeStatusEnum.ING.getCode());
                distributeRecordEntity.setDistributePlanId(distributePlanId);
                distributeRecordRepository.updateRecordById(distributeRecordEntity);

                ChannelProcessor channelProcessor = ChannelFactory.getChannelProcessor(channelId);

                // 查询渠道商详情
                ChannelInfo channelInfo = ChannelFactory.getChannel(channelId);
                if (channelInfo == null) {
                    throw new BusinessException(BusinessErrorCode.NO_CHANNEL_ERROR);
                }

                //分批处理
                List<List<PlanRosterEntity>> partition = Lists.partition(distributeRecordRosterList, channelInfo.getImportRosterLimit());
                for (List<PlanRosterEntity> rosterList : partition) {
                    ChannelImportRosterDTO channelImportRosterDTO = new ChannelImportRosterDTO();
                    channelImportRosterDTO.setTenantCode(tenantCode);
                    channelImportRosterDTO.setSupplierTaskId(supplierTaskId);
                    channelImportRosterDTO.setDistributePlanId(distributePlanId);
                    channelImportRosterDTO.setRosterEntityList(rosterList);

                    //对接外部渠道商增加appKey参数
                    channelImportRosterDTO.setAppKey(channelInfo.getAppKey());
                    channelImportRosterDTO.setRosterType(rosterType);

                    ChannelImportRosterResultDTO resultDTO = channelProcessor.importRoster(channelImportRosterDTO);
                    int totalNum = rosterList.size();
                    Integer successCount = resultDTO.getSuccessCount();
                    Integer failCount = resultDTO.getFailCount();
                    log.info("当前批次上传结果,channelId:{},distributeRecordId:{},successCount:{},failCount:{}", channelId, distributeRecordId, successCount, failCount);
                    if (successCount <= 0 && failCount <= 0) {
                        continue;
                    }
                    LocalDateTime nowTime = LocalDateTime.now();
                    //更新渠道任务（下发数量、下发成功数量、最近下发时间）
                    DistributeChannelTaskEntity channelTaskEntity = new DistributeChannelTaskEntity();
                    channelTaskEntity.setId(channelTaskId);
                    channelTaskEntity.setSentTotalNum(0L);
                    channelTaskEntity.setSentSuccessNum((long) successCount);
                    channelTaskEntity.setLatestSentTime(nowTime);
                    log.info("更新渠道任务，channelId:{},distributeRecordId:{},sentTotalNum:{},sentSuccessNum:{}", channelId, distributeRecordId, totalNum, successCount);
                    distChannelTaskRepo.updateWhenDistribute(channelTaskEntity);
                    //更新下发记录（下发数量，成功数量）
                    DistributeRecordEntity distributeRecordUpdate = new DistributeRecordEntity();
                    distributeRecordUpdate.setDistributeCount(0);
                    distributeRecordUpdate.setSuccessCount(successCount);
                    distributeRecordUpdate.setDistributePlanId(distributePlanId);
                    distributeRecordUpdate.setId(distributeRecordId);
                    distributeRecordRepository.updateRecordById(distributeRecordUpdate);
                }
                //更新下发记录（下发状态：下发完成）
                distributeRecordEntity.setDistributeStatus(DistributeStatusEnum.SUCCESS.getCode());
                distributeRecordEntity.setDistributePlanId(distributePlanId);
                distributeRecordRepository.updateRecordById(distributeRecordEntity);
            } catch (Exception e) {
                log.error("下发下发记录异常，下发记录id：{},e:", distributeRecordId, e);
            }

        }
    }

    private void doSyncDist(DistributePlanEntity planEntity, List<PlanRosterEntity> finalRosterList, List<DistributeChannelTaskEntity> channelTaskList) {
        //分流计算
        distCalService.decide(planEntity, channelTaskList, finalRosterList);
        // 创建上传记录和下发记录
        Integer rosterType = finalRosterList.get(0).getRosterType();
        RosterTypeEnum rosterTypeEnum = RosterTypeEnum.getByCode(rosterType);
        UploadRecordEntity uploadRecordEntity = paddingUploadRecord(DistributeStatusEnum.PENDING, UploadStatusEnum.UPLOAD_ING, UploadTypeEnum.INTERFACE, finalRosterList, planEntity, planEntity.getTenantCode(), rosterTypeEnum);
        rosterCreateAndBindDistRecord(planEntity, channelTaskList, uploadRecordEntity.getId(), DistributeRecordTypeEnum.PREPARE, DistributeStatusEnum.PENDING, finalRosterList);

        // 分批保存时，同时更新上传记录的上传数量
        batchSaveRoster(finalRosterList, planEntity);

        //名单保存完后更新下发记录为正式下发
        distributeRecordRepository.updateRecordType(uploadRecordEntity.getId(), planEntity.getId(), DistributeRecordTypeEnum.FORMAL);
        // 4.名单保存完成，更新上传记录状态为上传完成
        uploadRecordEntity.setUploadStatus(UploadStatusEnum.UPLOAD_SUCCESS.getCode());
        uploadRecordRepository.updateRecordById(uploadRecordEntity);
        log.info("接口上传名单，实时分流保存名单完成,planEntity:{}", planEntity);
        // 5.异步下发名单
        CompletableFuture.runAsync(() -> {
            doDistributeRoster(planEntity.getTenantCode(), finalRosterList);
        }, HammerThreadPoolUtil.getRosterUploadExecutor());

    }

    /**
     * 名单撞库
     *
     * @param distributePlan 分流计划
     * @param rosters        名单集合
     */
    private void impactRoster(DistributePlanEntity distributePlan, List<PlanRosterEntity> rosters) {
        //判断分流计划是否配置撞库规则
        DistPlanImpactRule impactRule = apolloConfigs.getImpactRuleByTenant(distributePlan.getTenantCode());
        if (Objects.isNull(impactRule)) {
            log.info("获取计划撞库规则为空,planId:{}", distributePlan.getId());
            rosters.forEach(roster -> {
                roster.setDistributeStatus(RosterDistributeStatusEnum.PENDING.getCode());
                roster.setIsImpact(YesOrNoEnum.NO.getCode());
            });
            return;
        }
        //按批次撞库
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        List<CompletableFuture<Void>> futureList = new ArrayList<>();
        boolean useThead = rosters.size() > apolloConfigs.getImpactLimit();
        for (List<PlanRosterEntity> rosterEntityList : Lists.partition(rosters, apolloConfigs.getImpactLimit())) {
            if (useThead) {
                CompletableFuture<Void> future = CompletableFuture.runAsync(() -> rosterPortraitFacade.impact(impactRule, rosterEntityList), HammerThreadPoolUtil.getRosterImpactExecutor());
                futureList.add(future);
            } else {
                rosterPortraitFacade.impact(impactRule, rosterEntityList);
            }
        }
        if (CollectionUtil.isNotEmpty(futureList)) {
            CompletableFuture.allOf(futureList.toArray(new CompletableFuture[0])).join();
        }
        stopWatch.stop();
        log.info("名单撞库耗时:{},plan:{},size:{}", stopWatch.getTotalTimeMillis(), distributePlan.getId(), rosters.size());

    }

    private void doAsyncDist(DistributePlanEntity planEntity, List<PlanRosterEntity> finalRosterList, List<DistributeChannelTaskEntity> channelTaskList) {
        log.info("离线上传名单,plan:{},size:{}", BaseJsonUtils.writeValue(planEntity), finalRosterList.size());
        Long distributePlanId = planEntity.getId();
        UploadRecordEntity uploadRecordEntity = null;
        List<DistributeRecordEntity> distRecordList;
        RedisLock lock = redisHelper.createLock(RedisKeyUtils.asyncDistLockKey(distributePlanId));
        try {
            //离线分流时，先查询是否有可以聚合的上传记录
            //这里的锁是一个粗粒度锁，防止重复创建可聚合的上传记录
            //todo 减小锁的粒度，没有记录再加锁，并做double check
            boolean isLock = lock.blockAcquireLock(5000, 10000);
            if (!isLock) {
                //正常情况是不会走到这里的
                log.error("当前接口离线分流未获取到分流计划锁,planId:{}", distributePlanId);
                throw new BusinessException(BusinessErrorCode.NOT_GET_PLAN_LOCK);
            }
            UploadRecordQueryConditionDTO uQryCondition = new UploadRecordQueryConditionDTO();
            uQryCondition.setDistributePlanId(distributePlanId);
            uQryCondition.setUploadType(UploadTypeEnum.INTERFACE.getCode());
            uQryCondition.setUploadStatus(UploadStatusEnum.UPLOAD_ING.getCode());
            uQryCondition.setDistributeStatus(DistributeStatusEnum.PENDING.getCode());
            LocalDateTime nowTime = LocalDateTime.now();
            uQryCondition.setStartCreateTime(nowTime.minusSeconds(apolloConfigs.getUploadRecordAggSeconds()));
            uQryCondition.setEndCreateTime(nowTime);
            //查询可以聚合的上传记录
            List<UploadRecordEntity> canAggUploadRecordList = uploadRecordRepository.queryByCondition(uQryCondition);
            boolean isAgg = false;
            if (CollectionUtils.isNotEmpty(canAggUploadRecordList)) {
                isAgg = true;
                //理论上是只会有一条可以聚合的上传记录的
                uploadRecordEntity = canAggUploadRecordList.get(0);
                log.info("聚合上传记录,recordId:{}", uploadRecordEntity.getId());

            }
            if (Objects.isNull(uploadRecordEntity)) {
                Integer rosterType = finalRosterList.get(0).getRosterType();
                uploadRecordEntity = buildUploadRecord(planEntity, UploadStatusEnum.UPLOAD_ING, planEntity.getTenantCode(), RosterTypeEnum.getByCode(rosterType));
                uploadRecordEntity.setUploadType(UploadTypeEnum.INTERFACE.getCode());
                uploadRecordEntity.setDistributeStatus(DistributeStatusEnum.PENDING.getCode());
                uploadRecordEntity.setUploadTime(LocalDateTime.now());
                uploadRecordRepository.addRecord(uploadRecordEntity);
                log.info("创建新的聚合上传记录,recordId:{}", uploadRecordEntity.getId());
            }
            //先进行分流计算
            distCalService.decide(planEntity, channelTaskList, finalRosterList);

            distRecordList = this.addDistRecordWhenAsyncDist(planEntity, channelTaskList, uploadRecordEntity, finalRosterList, isAgg);

        } finally {
            lock.releaseLock();
        }

        //redis中查询是否有当前上传记录id
        Long incr = redisHelper.incr(RedisKeyUtils.asyncDistRecorcKey(String.valueOf(uploadRecordEntity.getId())), asyncDistRecordExpireTime, false);
        log.info("当前上传记录关联请求数量:{},updRecord:{}", incr, uploadRecordEntity.getId());

        //名单绑定上传记录
        bindUploadRecord(finalRosterList, uploadRecordEntity.getId());
        //名单绑定下发记录
        rosterBindDistRecord(distRecordList, finalRosterList);
        //分批保存
        batchSaveRoster(finalRosterList, planEntity);
        log.info("接口上传名单，离线分流保存名单完成,planEntity:{}", planEntity);
        redisHelper.decr(RedisKeyUtils.asyncDistRecorcKey(String.valueOf(uploadRecordEntity.getId())));
    }

    private List<DistributeRecordEntity> addDistRecordWhenAsyncDist(DistributePlanEntity planEntity,
                                                                    List<DistributeChannelTaskEntity> channelTaskList,
                                                                    UploadRecordEntity uploadRecordEntity,
                                                                    List<PlanRosterEntity> rosterList,
                                                                    boolean isAgg) {
        if (isAgg) {
            //名单已经分配了的任务
            Set<Long> distRosterTaskSet = rosterList.stream().map(PlanRosterEntity::getChannelTaskId).collect(Collectors.toSet());
            //查询上传记录对应的预下发记录
            DistributeRecordQueryConditionDTO distRecordQryCon = new DistributeRecordQueryConditionDTO();
            distRecordQryCon.setDistributePlanId(planEntity.getId());
            distRecordQryCon.setDistributeType(DistributeRecordTypeEnum.PREPARE.getCode());
            distRecordQryCon.setUploadRecordId(uploadRecordEntity.getId());
            List<DistributeRecordEntity> distRecordList = distributeRecordRepository.queryByCondition(distRecordQryCon);
            if (CollectionUtils.isEmpty(distRecordList)) {
                //在撞库场景下，名单如果都没命中，上传记录是不会关联下发记录的，此时创建预下发记录
                return createDistRecord(planEntity, channelTaskList, uploadRecordEntity.getId(), DistributeRecordTypeEnum.PREPARE, DistributeStatusEnum.PENDING, rosterList);
            }
            //这个时候查询出来的预下发记录要去和当前分流规则中的任务去比对，有可能会有新增的渠道任务，这个时候就要去新增预下发的记录
            Map<String, DistributeRuleEntity> ruleMap = planEntity.getDistributeRuleList().stream().collect(Collectors.toMap(DistributeRuleEntity::getPlanChannelTaskId, Function.identity(), (k1, k2) -> k1));
            Map<Long, DistributeChannelTaskEntity> taskMap = channelTaskList.stream().collect(Collectors.toMap(DistributeChannelTaskEntity::getId, Function.identity(), (k1, k2) -> k1));
            Set<Long> existTaskSet = distRecordList.stream().map(DistributeRecordEntity::getChannelTaskId).collect(Collectors.toSet());
            log.info("聚合下发记录,已经存在的下发记录，set:{}", existTaskSet);
            for (DistributeRuleEntity rule : planEntity.getDistributeRuleList()) {
                //不存在则新增预下发记录
                Long channelTaskId = Long.valueOf(rule.getPlanChannelTaskId());
                if (!existTaskSet.contains(channelTaskId)) {
                    log.info("当前分流计划有新增的任务，新增一条预下发记录，plan:{},taskId:{}", planEntity.getId(), rule.getPlanChannelTaskId());
                    DistributeRecordEntity distributeRecordEntity = new DistributeRecordEntity();
                    DistributeRuleEntity distributeRuleEntity = ruleMap.get(rule.getPlanChannelTaskId());
                    //比例为0的不创建下发记录
                    if (BigDecimal.ZERO.compareTo(distributeRuleEntity.getPercentage()) >= 0) {
                        log.info("当前分流规则比例为0，不创建下发记录,distributeRuleEntity:{}", distributeRuleEntity);
                        continue;
                    }
                    if (!distRosterTaskSet.contains(channelTaskId)) {
                        log.info("当前名单分配的任务，不包含当前任务,channelTaskId:{}", channelTaskList);
                        continue;
                    }
                    DistributeChannelTaskEntity taskEntity = taskMap.get(channelTaskId);
                    distributeRecordEntity.setId(idGeneratorService.getLongId());
                    distributeRecordEntity.setDistributePlanId(planEntity.getId());
                    distributeRecordEntity.setDistributeStatus(DistributeStatusEnum.PENDING.getCode());
                    distributeRecordEntity.setDistributeType(DistributeRecordTypeEnum.PREPARE.getCode());
                    distributeRecordEntity.setChannelTaskId(channelTaskId);
                    distributeRecordEntity.setSupplierTaskId(taskEntity.getSupplierTaskId());
                    distributeRecordEntity.setSupplierTaskName(taskEntity.getSupplierTaskName());
                    distributeRecordEntity.setChannelId(Integer.parseInt(taskEntity.getChannelId()));
                    distributeRecordEntity.setUploadRecordId(uploadRecordEntity.getId());
                    log.info("创建预下发记录,record:{}", distributeRecordEntity);
                    distributeRecordRepository.addRecord(distributeRecordEntity);
                    distRecordList.add(distributeRecordEntity);
                }
            }
            return distRecordList;
        } else {
            //创建上传记录对应的预下发记录
            return createDistRecord(planEntity, channelTaskList, uploadRecordEntity.getId(), DistributeRecordTypeEnum.PREPARE, DistributeStatusEnum.PENDING, rosterList);
        }
    }

    private RosterImportResultDTO checkApiImport(RosterAPIImportDTO ifaceDTO, DistributePlanEntity planEntity) {
        RosterImportResultDTO resultDTO = new RosterImportResultDTO();
        Long distributePlanId = planEntity.getId();
        final int totalCount = ifaceDTO.getRosterEntityList().size();
        Pair<Integer, Integer> pair = ifaceDTO.rmDupAndFail();
        Integer failCount = pair.getKey();
        Integer dupCount = pair.getValue();
        log.info("接口上传名单,totalCount:{}, failCount:{}, dupCount:{}", totalCount, failCount, dupCount);
        //校验数据格式是否正确
        resultDTO.setFailCount(failCount);
        resultDTO.setDuplicationCount(dupCount);
        //全部失败
        if (failCount + dupCount >= totalCount) {
            log.info("接口上传名单,数据格式全部错误");
            this.saveUploadRecordWhenImport(ifaceDTO.getTenantId(), planEntity.getDistributeType(), distributePlanId, ifaceDTO.getRosterType());
            return resultDTO;
        }

        //redis时间窗口数据去重
        List<PlanRosterEntity> rosterEntityList = ifaceDTO.getRosterEntityList();
        List<PlanRosterEntity> rmDupRosterList = this.redisRmDuplicate(distributePlanId, rosterEntityList);
        log.info("接口上传名单，redis去重后数量:{}", rmDupRosterList.size());
        dupCount += rosterEntityList.size() - rmDupRosterList.size();
        if (CollectionUtils.isEmpty(rmDupRosterList)) {
            log.info("接口上传名单,redis数据全部重复");
            //数据全部重复
            this.saveUploadRecordWhenImport(ifaceDTO.getTenantId(), planEntity.getDistributeType(), distributePlanId, ifaceDTO.getRosterType());
            resultDTO.setDuplicationCount(dupCount);
            return resultDTO;
        }
        //数据库去重
        NameListDupCheckResultDTO dbDupResult = this.rosterDupCheck(rmDupRosterList, false);
        List<PlanRosterEntity> finalRosterList = dbDupResult.getInsertEntityList();
        dupCount += dbDupResult.getDuplicationCount();
        if (CollectionUtils.isEmpty(finalRosterList)) {
            //数据全部重复
            log.info("接口上传名单,数据库中数据全部重复");
            this.saveUploadRecordWhenImport(ifaceDTO.getTenantId(), planEntity.getDistributeType(), distributePlanId, ifaceDTO.getRosterType());
            resultDTO.setDuplicationCount(dupCount);
            return resultDTO;
        }
        resultDTO.setFinalRosterList(finalRosterList);
        resultDTO.setDuplicationCount(dupCount);
        return resultDTO;
    }

    private void saveUploadRecordWhenImport(String operator, Integer distributeType, Long distributePlanId, Integer rosterType) {
        //创建一条上传记录，上传状态为上传完成，下发状态为无需下发
        UploadRecordEntity uploadRecordEntity = new UploadRecordEntity();
        uploadRecordEntity.setId(idGeneratorService.getLongId());
        uploadRecordEntity.setUploadType(UploadTypeEnum.INTERFACE.getCode());
        uploadRecordEntity.setUploadStatus(UploadStatusEnum.UPLOAD_SUCCESS.getCode());
        uploadRecordEntity.setUploadTime(LocalDateTime.now());
        uploadRecordEntity.setDistributeStatus(DistributeStatusEnum.NOT_DISTRIBUTE.getCode());
        uploadRecordEntity.setOperator(operator);
        uploadRecordEntity.setDistributeType(distributeType);
        uploadRecordEntity.setDistributePlanId(distributePlanId);
        RosterTypeEnum rosterTypeEnum = RosterTypeEnum.getByCode(rosterType);
        uploadRecordEntity.setRosterType(Objects.nonNull(rosterTypeEnum) ? rosterTypeEnum.getCode() : RosterTypeEnum.TELEPHONE.getCode());
        uploadRecordRepository.addRecord(uploadRecordEntity);
    }

    /**
     * redis去重
     *
     * @param distributePlanId 分流计划id
     * @param rosterEntityList 待去重待名单数据
     * @return List<PlanRosterEntity>
     * @author zhangzhuoqi
     * @since 2025/3/20 14:01
     **/
    private List<PlanRosterEntity> redisRmDuplicate(Long distributePlanId, List<PlanRosterEntity> rosterEntityList) {
        if (!apolloConfigs.getUseRedisRosterDup()) {
            return rosterEntityList;
        }
        int beforeSize = rosterEntityList.size();
        log.info("redis去重名单，before:{}", beforeSize);
        try {
            List<String> keyList = rosterEntityList.stream()
                    .map(r -> r.getPhoneNum() + r.getExternalId())
                    .map(it -> RedisKeyUtils.redisDuplicate(distributePlanId + SPLIT + it).getRawKey())
                    .collect(Collectors.toList());

            Map<String, Long> pipelineResult = redisHelper.pipelineResult(new RouteKey(RedisKeyUtils.ROSTER_DUPLICATE_KEY), keyList, (pipeline, keys) -> {
                Map<String, Response<Long>> responseMap = new HashMap<>();
                keys.forEach(key -> {
                    Response<Long> setnx = pipeline.setnx(key, "1");
                    responseMap.put(key, setnx);
                    pipeline.expire(key, apolloConfigs.getUseRedisDupExpireSecond());
                });
                pipeline.sync();
                return responseMap;
            }, false, 2);

            List<String> phoneLists = pipelineResult.entrySet().stream()
                    .filter(it -> Objects.equals(it.getValue(), 1L))
                    .map(Map.Entry::getKey)
                    .map(it -> it.split("\\" + SPLIT)[1])
                    .collect(Collectors.toList());

            log.info("checkDuplicationByRedis size={}", pipelineResult.size());


            return rosterEntityList.stream()
                    .filter(it -> phoneLists.contains(it.getPhoneNum() + it.getExternalId()))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            log.error("checkDuplicationByRedis异常={},e:", distributePlanId, e);
            return rosterEntityList;
        }
    }

    /**
     * 校验是否存在重复的子任务
     */
    private NameListDupCheckResultDTO checkDupRoster(List<PlanRosterEntity> rosterEntityList) {
        String partitionCode = rosterEntityList.get(0).getPartitionCode();
        Long distributePlanId = rosterEntityList.get(0).getDistributePlanId();
        Set<String> phoneList = rosterEntityList.stream().map(PlanRosterEntity::getPhoneNum).collect(Collectors.toSet());

        // 根据手机号查询对应名单，根据phoneNum + externalId为唯一标识进行去重
        RosterQueryConditionDTO condition = new RosterQueryConditionDTO();
        condition.setPhoneNumList(new ArrayList<>(phoneList));
        condition.setDistributePlanId(distributePlanId);
        List<PlanRosterEntity> dbRosterList = planRosterRepository.queryByPartitionCode(partitionCode, condition);
        if (CollectionUtils.isEmpty(dbRosterList)) {
            return new NameListDupCheckResultDTO(0, rosterEntityList);
        }
        Set<String> idSet = dbRosterList.stream().map(it -> it.getPhoneNum() + "-" + it.getExternalId()).collect(Collectors.toSet());
        List<PlanRosterEntity> insertRosterList = rosterEntityList.stream().filter(it -> !idSet.contains(it.getPhoneNum() + "-" + it.getExternalId())).collect(Collectors.toList());
        return new NameListDupCheckResultDTO(rosterEntityList.size() - insertRosterList.size(), insertRosterList);
    }

    private void batchSaveRoster(List<PlanRosterEntity> rosterList, DistributePlanEntity distributePlan) {
        log.info("批量保存名单");
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        rosterList.forEach(it -> {
            it.setPlanCreateTime(distributePlan.getCreateTime());
            it.setTenantId(distributePlan.getTenantCode());
        });
        List<List<PlanRosterEntity>> partition;
        if (rosterList.size() > apolloConfigs.getImportRosterLimit()) {
            partition = ListUtils.splitCollection(rosterList, HammerThreadPoolUtil.CORE_SIZE);
        } else {
            partition = Lists.partition(rosterList, apolloConfigs.getBatchSaveNameListSize());
        }

        //分批保存名单
        //只有在文件上传名单时采用多线程保存
        if (apolloConfigs.getUseMultiTheadSaveRoster() && rosterList.size() > apolloConfigs.getImportRosterLimit()) {
            List<CompletableFuture<Void>> futureList = new ArrayList<>();
            for (List<PlanRosterEntity> rosterEntityList : partition) {
                CompletableFuture<Void> future = CompletableFuture.runAsync(() -> saveRoster(rosterEntityList), HammerThreadPoolUtil.getRosterSaveExecutor());
                futureList.add(future);
            }
            CompletableFuture.allOf(futureList.toArray(new CompletableFuture[0])).join();
        } else {
            for (List<PlanRosterEntity> rosterEntityList : partition) {
                saveRoster(rosterEntityList);
            }
        }
        Long uploadRecordId = rosterList.get(0).getUploadRecordId();
        Long distributePlanId = rosterList.get(0).getDistributePlanId();
        // 2.更新上传记录的上传数量
        uploadRecordRepository.updateUploadCount(uploadRecordId, distributePlanId, rosterList.size());
        // 3.更新分流计划的上传数量
        distPlanRepo.updateUploadDataNum(distributePlanId, rosterList.size());

        //发送名单更新消息
        this.batchSendRosterUpdMsg(rosterList);

        stopWatch.stop();
        log.info("批量保存名单结束,耗时:{}", stopWatch.getTotalTimeMillis());
    }

    private void saveRoster(List<PlanRosterEntity> entityList) {
        // 1.保存名单
//        StopWatch stopWatch = new StopWatch();
//        stopWatch.start();
        planRosterRepository.batchSave(entityList);
//        stopWatch.stop();
    }

    private void batchSendRosterUpdMsg(List<PlanRosterEntity> rosterList) {
        //发送名单更新消息
        CompletableFuture.runAsync(() -> {
            Map<Long, List<PlanRosterEntity>> rosterMap = rosterList.stream().collect(Collectors.groupingBy(PlanRosterEntity::getDistributePlanId));
            rosterMap.forEach((planId, rosterEntityList) -> {
                LocalDateTime planCreateTime = rosterEntityList.get(0).getPlanCreateTime();
                if (Objects.isNull(planCreateTime)) {
                    DistributePlanEntity planEntity = distPlanRepo.queryDistributePlanById(planId);
                    planCreateTime = planEntity.getCreateTime();
                }
                String createTime = DateUtils.format(planCreateTime);
                for (PlanRosterEntity entity : rosterEntityList) {
                    RosterUpdDTO rosterUpdDTO = new RosterUpdDTO();
                    rosterUpdDTO.setId(String.valueOf(entity.getId()));
                    rosterUpdDTO.setPlanId(String.valueOf(entity.getDistributePlanId()));
                    rosterUpdDTO.setPhoneNum(entity.getPhoneNum());
                    rosterUpdDTO.setPlanCreateTime(createTime);
                    rosterMsgService.sendUpdMsg(rosterUpdDTO);
                }
            });
        }, HammerThreadPoolUtil.getRosterUpdExecutor());
    }
}

