package com.hellobike.aicc.domain.file.entity;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  10:15:09
 */
@Data
public class FileExportRecordEntity {

    private Long id;

    /**
     * 数据密级S2,文件类型
     * @see com.hellobike.aicc.common.enums.FileExportBizTypeEnum
     */
    private Integer bizType;

    /**
     * 数据密级S2,执行状态
     * @see com.hellobike.aicc.common.enums.FileExportStatusEnum
     */
    private Integer status;

    /**
     * 数据密级S2,文件名称
     */
    private String fileName;

    /**
     * 数据密级S2,文件地址
     */
    private String fileUrl;

    /**
     * 数据密级S2,导出失败原因
     */
    private String failReason;

    /**
     * 数据密级S2,操作人姓名
     */
    private String operator;

    /**
     * 数据密级S2,导出数据量
     */
    private Integer exportCount;

    /**
     * 数据密级S2,创建时间
     */
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,是否删除
     */
    private Integer isDelete;
}
