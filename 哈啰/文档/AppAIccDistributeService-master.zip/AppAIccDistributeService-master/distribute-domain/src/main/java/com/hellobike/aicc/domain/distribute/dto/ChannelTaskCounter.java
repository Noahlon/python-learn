package com.hellobike.aicc.domain.distribute.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author zhengchenyang
 * @date 2025/3/21
 * @desc 通道任务计数器
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChannelTaskCounter {

    public ChannelTaskCounter(String channelId, String taskTemplateId) {
        this.channelId = channelId;
        this.taskTemplateId = taskTemplateId;
    }

    /**
     * 渠道商id
     */
    private String channelId;

    /**
     * 渠道任务id
     */
    private String channelTaskId;

    /**
     * 渠道任务模板id
     */
    private String taskTemplateId;

    /**
     * 名单数量
     */
    private Long count = 0L;

    public String generateKey() {
        return channelId + "_" + taskTemplateId;
    }
}
