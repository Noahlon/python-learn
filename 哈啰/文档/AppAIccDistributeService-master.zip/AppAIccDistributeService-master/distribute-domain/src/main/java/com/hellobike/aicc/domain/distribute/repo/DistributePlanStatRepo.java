package com.hellobike.aicc.domain.distribute.repo;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.distribute.dto.DistributePlanStatQryConditionDTO;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanStatEntity;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-05-27  14:57:26
 */
public interface DistributePlanStatRepo {

    /**
     * 保存统计数据,同一个分流计划做更新操作
     * @param statEntity
     * @return
     */
    boolean saveOrUpdate(DistributePlanStatEntity statEntity);

    /**
     * 分页查询统计数据
     * @param condition condition
     * @return
     */
    PageResult<DistributePlanStatEntity> pageQry(DistributePlanStatQryConditionDTO condition);

    List<DistributePlanStatEntity> queryByCondition(DistributePlanStatQryConditionDTO DistributePlanStatQryConditionDTO);
}
