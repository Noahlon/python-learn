package com.hellobike.aicc.domain.roster.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author zhangzhuoqi
 * @since 2025-05-24  10:15:04
 */
@Data
public class RosterUpdDTO {

    /**
     * 名单id
     */
    private String id;

    /**
     * 分流计划id
     */
    private String planId;

    /**
     * 手机号
     */
    private String phoneNum;

    /**
     * 分流计划创建时间
     */
    private String planCreateTime;
}
