package com.hellobike.aicc.domain.smsrecord.handler;

import com.hellobike.aicc.common.enums.CarrierTypeEnum;
import com.hellobike.aicc.common.enums.RosterTypeEnum;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.channel.factory.ChannelInfo;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import com.hellobike.aicc.domain.dialogue.repo.CallDialogueRepository;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.repo.PlanRosterRepository;
import com.hellobike.aicc.domain.smsrecord.convert.SmsRecordConvert;
import com.hellobike.aicc.domain.smsrecord.dto.CssSmsRecordMsgDTO;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-04-19  10:01:35
 */
@Service
@Slf4j
public class CssSmsCallBackHandler extends AbstractSmsRecordCallBackHandler<CssSmsRecordMsgDTO> {
    @Resource
    private CallDialogueRepository callDialogueRepository;

    @Resource
    private PlanRosterRepository planRosterRepository;

    @Resource
    private IdGeneratorService idGeneratorService;

    @Resource
    private DistPlanRepo distPlanRepo;

    @Resource
    private SmsRecordConvert smsRecordConvert;

    @Override
    public void handlerSmsCallBack(CssSmsRecordMsgDTO callBackData, ChannelInfo channelInfo) {
        SmsRecordEntity smsRecordEntity = smsRecordConvert.convert(callBackData);
        PlanRosterEntity roster = queryRoster(smsRecordEntity);
        if (roster == null) {
            log.error("名单不存在，名单id为：{}，手机号码为：{}", smsRecordEntity.getRosterKey(), smsRecordEntity.getPhoneNumber());
            throw new RuntimeException("名单不存在");
        }

        smsRecordEntity.setGuid(idGeneratorService.getLongId());
        smsRecordEntity.setChannelId(ChannelFactory.getHelloAiCall().getChannelId());
        smsRecordEntity.setChannelName(ChannelFactory.getHelloAiCall().getChannelName());
        smsRecordEntity.setReceiveResultTime(LocalDateTime.now());
        smsRecordEntity.setSupplierSmsJson(BaseJsonUtils.writeValue(callBackData));
        smsRecordEntity.setRosterId(roster.getId());
        smsRecordEntity.setPlatformId(roster.getPlatformId());
        smsRecordEntity.setExternalId(roster.getExternalId());
        smsRecordEntity.setCustomName(roster.getCustomerName());
        smsRecordEntity.setPhoneNumberMd5(roster.getMd5());
        smsRecordEntity.setChannelTaskId(roster.getChannelTaskId());
        if (RosterTypeEnum.MD5.getCode().equals(roster.getRosterType())) {
            smsRecordEntity.setPhoneNumber(null);
            smsRecordEntity.setRosterType(RosterTypeEnum.MD5.getCode());
        }else if (RosterTypeEnum.TELEPHONE.getCode().equals(roster.getRosterType())){
            smsRecordEntity.setRosterType(RosterTypeEnum.TELEPHONE.getCode());
        }

        CallDialogueEntity callDialogue = queryCallDialogue(smsRecordEntity);
        if (callDialogue != null) {
            smsRecordEntity.setDistributePlanCallId(callDialogue.getId());
        }

        DistributePlanEntity distributePlan = distPlanRepo.queryDistributePlanById(roster.getDistributePlanId());
        smsRecordEntity.setDistributePlanId(distributePlan.getId());
        smsRecordEntity.setDistributePlanName(distributePlan.getDistributePlanName());
        smsRecordEntity.setCarrier(CarrierTypeEnum.getEnumByCode(callBackData.getCarrier()).getCode());

        doHandlerSmsCallBack(smsRecordEntity, ChannelFactory.getHelloAiCall().getChannelId());
    }
}
