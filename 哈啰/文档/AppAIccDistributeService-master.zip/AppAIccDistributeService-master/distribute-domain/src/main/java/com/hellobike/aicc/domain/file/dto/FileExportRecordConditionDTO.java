package com.hellobike.aicc.domain.file.dto;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  15:13:59
 */
@Data
public class FileExportRecordConditionDTO {

    private Long id;

    /**
     * 数据密级S2,文件类型
     * @see com.hellobike.aicc.common.enums.FileExportBizTypeEnum
     */
    private Integer bizType;

    /**
     * 数据密级S2,执行状态
     * @see com.hellobike.aicc.common.enums.FileExportStatusEnum
     */
    private Integer status;

    /**
     * 创建时间-开始
     */
    private LocalDateTime createTimeStart;

    /**
     * 创建时间-结束
     */
    private LocalDateTime createTimeEnd;
}
