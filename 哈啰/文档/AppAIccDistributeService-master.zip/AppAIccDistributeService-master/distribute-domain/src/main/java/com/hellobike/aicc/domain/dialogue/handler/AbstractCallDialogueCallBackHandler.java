package com.hellobike.aicc.domain.dialogue.handler;

import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.repo.DistChannelTaskRepo;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.repo.PlanRosterRepository;

import javax.annotation.Resource;
import java.util.Objects;

/**
 * 话单回调处理-抽象类
 * 不同渠道商相同处理逻辑放到此类处理
 *
 * @author zhangzhuoqi
 * @since 2025-03-14  15:57:22
 */
public abstract class AbstractCallDialogueCallBackHandler<C> implements CallDialogueCallBackHandler<C>{

    @Resource
    private PlanRosterRepository planRosterRepository;

    @Resource
    private DistChannelTaskRepo distChannelTaskRepo;

    @Resource
    private DistPlanRepo distPlanRepo;


    /**
     * 通过id获取名单
     *
     * @author zhangzhuoqi
     * @since 2025/3/17 15:53
     * @param rosterId 名单id
     * @param distPlanId 分流计划id
     * @param phoneNum 手机号
     * @return PlanRosterEntity
     **/
    protected PlanRosterEntity getRoster(Long rosterId, Long distPlanId, String phoneNum){
        return planRosterRepository.getRosterById(rosterId, distPlanId, phoneNum);
    }

    /**
     * 获取渠道任务信息
     *
     * @author zhangzhuoqi
     * @since 2025/3/17 16:16
     * @param channelTaskId 渠道任务id
     * @return ChannelTaskEntity
     **/
    protected DistributeChannelTaskEntity getChannelTask(Long channelTaskId) {
        if (Objects.isNull(channelTaskId)){
            return null;
        }
        return distChannelTaskRepo.queryById(channelTaskId);
    }

    /**
     * 获取分流计划
     *
     * @author zhangzhuoqi
     * @since 2025/3/17 16:21
     * @param distributePlanId 分流计划id
     * @return DistributePlanEntity
     **/
    protected DistributePlanEntity getDistributePlan(Long distributePlanId) {
        if (Objects.isNull(distributePlanId)){
            return null;
        }
        return distPlanRepo.queryDistributePlanById(distributePlanId);
    }
}
