package com.hellobike.aicc.domain.smsrecord.dto;

import lombok.Data;

/**
 * 外部渠道商短信回调对象
 */
@Data
public class SmsRecordCallBackDTO {
    /**
     * 短信id
     */
    private String smsId;

    /**
     * 任务id
     */
    private String taskId;

    /**
     * 任务名称
     */
    private String taskName;

    /**
     * 通话记录id
     */
    private String dialogueGuid;

    /**
     * 名单唯一标识
     */
    private String rosterKey;

    /**
     * 手机号码
     */
    private String phoneNumber;

    /**
     * 手机号码md5
     */
    private String md5;

    /**
     * 省份
     */
    private String province;

    /**
     * 城市
     */
    private String city;

    /**
     * 运营商
     */
    private Integer carrier;

    /**
     * 短信签名
     */
    private String signature;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 短信发送结果
     */
    private Integer sendResult;

    /**
     * 短信发送时间
     */
    private String sendTime;

    /**
     * 短信提交结果
     */
    private Integer submitResult;

    /**
     * 短信提交时间
     */
    private String submitTime;

    /**
     * 短信计费数
     */
    private Integer billingNum;

    /**
     * 企业id
     */
    private String enterpriseId;
}
