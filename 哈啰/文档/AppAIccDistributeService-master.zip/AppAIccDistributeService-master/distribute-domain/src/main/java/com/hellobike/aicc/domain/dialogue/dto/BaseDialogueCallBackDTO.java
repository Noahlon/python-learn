package com.hellobike.aicc.domain.dialogue.dto;

import lombok.Data;

/**
 * @author zhangzhuoqi
 * @since 2025-05-28  11:11:50
 */
@Data
public class BaseDialogueCallBackDTO {

    /**
     * 三方话单id
     */
    private String dialogueGuid;
}
