package com.hellobike.aicc.domain.channelcallback.service;

import com.hellobike.aicc.domain.dialogue.dto.DialogueCallBackDTO;
import com.hellobike.aicc.domain.smsrecord.dto.SmsRecordCallBackDTO;

/**
 * 渠道商回调服务
 *
 * @author panlongqian
 * @since 2025-04-22
 */
public interface CallbackService {
    /**
     * 渠道商短信记录回调
     */
    void smsRecordCallBack(SmsRecordCallBackDTO dto, Integer channelId);

    void callDialogueCallBack(DialogueCallBackDTO dialogueCallBackDTO, Integer channelId);
}
