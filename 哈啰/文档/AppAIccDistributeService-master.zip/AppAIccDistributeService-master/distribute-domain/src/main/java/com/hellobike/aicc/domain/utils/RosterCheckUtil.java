package com.hellobike.aicc.domain.utils;

import com.hellobike.aicc.common.enums.RosterTypeEnum;
import org.apache.commons.lang3.StringUtils;

/**
 * 名单校验
 *
 * @author panlongqian
 * @since 2025-03-27
 */
public class RosterCheckUtil {
    private static final Integer EXTERNAL_ID_MAX_LENGTH = 128;

    private static final Integer NAME_ID_MAX_LENGTH = 128;

    public static boolean isRosterValid(String phone, String externalId, String name, Integer rosterType) {
        RosterTypeEnum rosterTypeEnum = RosterTypeEnum.getByCode(rosterType);
        if (rosterTypeEnum == null) {
            return false;
        }

        if (StringUtils.isBlank(phone) || !rosterTypeEnum.check(phone)) {
            return false;
        }

        if (StringUtils.isBlank(externalId) || externalId.length() > EXTERNAL_ID_MAX_LENGTH) {
            return false;
        }
        return StringUtils.isBlank(name) || name.length() <= NAME_ID_MAX_LENGTH;
    }
}
