package com.hellobike.aicc.domain.smsrecord.handler;

import com.hellobike.aicc.common.enums.CarrierTypeEnum;
import com.hellobike.aicc.common.enums.RosterTypeEnum;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.factory.ChannelInfo;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.smsrecord.convert.SmsRecordConvert;
import com.hellobike.aicc.domain.smsrecord.dto.SmsRecordCallBackDTO;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;

/**
 * 标准短信回调处理
 */
@Service
@Slf4j
public class DefaultSmsCallBackHandler extends AbstractSmsRecordCallBackHandler<SmsRecordCallBackDTO> {
    @Resource
    private SmsRecordConvert smsRecordConvert;

    @Resource
    private IdGeneratorService idGeneratorService;

    @Resource
    private DistPlanRepo distPlanRepo;

    @Override
    public void handlerSmsCallBack(SmsRecordCallBackDTO callBackData, ChannelInfo channel) {
        SmsRecordEntity smsRecordEntity = smsRecordConvert.convert(callBackData);
        PlanRosterEntity roster = queryRoster(smsRecordEntity);
        AssertUtils.notNull(roster, "短信回调查询名单为空");

        smsRecordEntity.setGuid(idGeneratorService.getLongId());
        smsRecordEntity.setChannelId(channel.getChannelId());
        smsRecordEntity.setChannelName(channel.getChannelName());
        smsRecordEntity.setReceiveResultTime(LocalDateTime.now());
        smsRecordEntity.setSupplierSmsJson(BaseJsonUtils.writeValue(callBackData));
        smsRecordEntity.setRosterId(roster.getId());
        smsRecordEntity.setPlatformId(roster.getPlatformId());
        smsRecordEntity.setExternalId(roster.getExternalId());
        smsRecordEntity.setCustomName(roster.getCustomerName());
        smsRecordEntity.setPhoneNumberMd5(roster.getMd5());
        smsRecordEntity.setChannelTaskId(roster.getChannelTaskId());
        if (RosterTypeEnum.MD5.getCode().equals(roster.getRosterType())) {
            smsRecordEntity.setPhoneNumber(null);
            smsRecordEntity.setRosterType(RosterTypeEnum.MD5.getCode());
        }else if (RosterTypeEnum.TELEPHONE.getCode().equals(roster.getRosterType())){
            smsRecordEntity.setRosterType(RosterTypeEnum.TELEPHONE.getCode());
        }

        // 查询话单
        CallDialogueEntity callDialogue = queryCallDialogue(smsRecordEntity);
        if (callDialogue != null) {
            smsRecordEntity.setDistributePlanCallId(callDialogue.getId());
        }

        DistributePlanEntity distributePlan = distPlanRepo.queryDistributePlanById(roster.getDistributePlanId());
        smsRecordEntity.setDistributePlanId(distributePlan.getId());
        smsRecordEntity.setDistributePlanName(distributePlan.getDistributePlanName());
        smsRecordEntity.setTenantCode(distributePlan.getTenantCode());
        smsRecordEntity.setCarrier(CarrierTypeEnum.getEnumByCode(callBackData.getCarrier()).getCode());

        doHandlerSmsCallBack(smsRecordEntity, channel.getChannelId());
    }
}
