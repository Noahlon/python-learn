package com.hellobike.aicc.domain.smsrecord.handler;

import com.hellobike.aicc.domain.channel.factory.ChannelInfo;

public interface SmsCallBackHandler<T> {
    void handlerSmsCallBack(T callBackData, ChannelInfo channelInfo);
}
