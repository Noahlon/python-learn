package com.hellobike.aicc.domain.roster.dto;

import lombok.Data;

/**
 * @author zhangzhuoqi
 * @since 2025-03-18  11:38:37
 */
@Data
public class RosterRetryDistributeDTO {

    /**
     * 分流计划id
     */
    private String distributePlanId;

    /**
     * 上传记录id
     */
    private String uploadRecordId;
}
