package com.hellobike.aicc.domain.utils;


import com.hellobike.base.hammer.log.hlog.HLogger;
import com.hellobike.base.hammer.log.hlog.HLoggerFactory;

public class LogUtils {
//    public static final HLogger ERROR = HLoggerFactory.getLogger("error");
//
//    public static final HLogger WARN = HLoggerFactory.getLogger("warn");
//
//    public static final HLogger INFO = HLoggerFactory.getLogger("info");
//
//    public static final HLogger DEBUG = HLoggerFactory.getLogger("debug");
//
//    public static final HLogger COMMON = HLoggerFactory.getLogger("common");
}
