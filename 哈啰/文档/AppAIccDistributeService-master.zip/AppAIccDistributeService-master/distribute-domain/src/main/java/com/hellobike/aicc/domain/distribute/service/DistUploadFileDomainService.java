package com.hellobike.aicc.domain.distribute.service;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.distribute.entity.DistributeUploadFileEntity;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributeUploadFileCondition;
import com.hellobike.aicc.domain.roster.dto.RosterUploadDTO;
import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;

/**
 * 分流文件服务Service
 */
public interface DistUploadFileDomainService {
    /**
     * 查询文件列表
     */
    PageResult<DistributeUploadFileEntity> queryUploadFileList(DistributeUploadFileCondition condition);

    /**
     * 上传名单
     *
     * @param uploadDTO uploadDTO
     * @author zhangzhuoqi
     * @since 2025/3/7 16:45
     **/
    void uploadRoster(RosterUploadDTO uploadDTO);

    void doUpload(DistributeUploadFileEntity distributeUploadFileEntity, UploadRecordEntity uploadRecordEntity);
}
