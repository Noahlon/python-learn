package com.hellobike.aicc.domain.distribute.entity;

import lombok.Data;

import java.math.BigDecimal;

/**
 * 分流规则
 */
@Data
public class DistributeRuleEntity {
    /**
     * 渠道商id
     */
    private Integer channelId;

    /**
     * 渠道商名称
     */
    private String channelName;

    /**
     * 分配比例
     */
    private BigDecimal percentage;

    /**
     * 任务模板id
     */
    private String taskTemplateId;

    /**
     * 任务模板名称
     */
    private String taskTemplateName;

    /**
     * 三方任务名称
     */
    private String supplierTaskName;

    /**
     * 数据量，下发到渠道商成功的数据量(关联渠道任务表获取)
     */
    private Long quantity;

    /**
     * 计划渠道任务表id
     */
    private String planChannelTaskId;

    /**
     * 计划渠道任务表状态,0-任务创建失败，1-任务创建成功
     */
    private Integer planChannelTaskStatus;

    /**
     * 计划渠道任务表状态描述,0-失败，1-成功
     */
    private String planChannelTaskStatusDesc;

    public String generateKey() {
        return channelId + "_" + taskTemplateId;
    }
}
