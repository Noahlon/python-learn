package com.hellobike.aicc.domain.distribute.repo;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.distribute.entity.DistributeUploadFileEntity;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributeUploadFileCondition;

import java.util.List;

/**
 * @author fanxiaodongwb230
 * @since 2025-03-14  14:40:59
 */
public interface DistUploadFileRepo {
    void saveOrUpdateUpLoadFile(DistributeUploadFileEntity distributeUploadFileEntity);

    PageResult<DistributeUploadFileEntity> pageQueryUploadFile(DistributeUploadFileCondition condition);

    List<DistributeUploadFileEntity> queryByCondition(DistributeUploadFileCondition condition);
}
