package com.hellobike.aicc.domain.file.service;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.file.dto.FileExportRecordConditionDTO;
import com.hellobike.aicc.domain.file.entity.FileExportRecordEntity;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  10:16:41
 */
public interface FileExportRecordDomainService {

    void saveOrUpdate(FileExportRecordEntity entity);

    PageResult<FileExportRecordEntity> pageRecord(FileExportRecordConditionDTO condition, Integer pageNum, Integer pageSize);
}
