package com.hellobike.aicc.domain.channel.facade;

import com.hellobike.aicc.domain.channel.dto.ChannelTaskCreateDTO;
import com.hellobike.aicc.domain.channel.entity.ChannelEntity;
import com.hellobike.aicc.domain.channel.entity.ChannelTaskEntity;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterDTO;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterResultDTO;

import java.util.List;

public interface AICallCenterChannelFacade {
    /*
     * 创建渠道商任务
     */
    ChannelTaskEntity createChannelTask(ChannelTaskCreateDTO channelTaskCreateDTO);

    /**
     * 查询渠道商任务模板列表
     */
    List<ChannelEntity.ChannelTemplateEntity> queryChannelTemplateList(String tenantCode);

    /**
     * 上传名单
     */
    ChannelImportRosterResultDTO importRoster(ChannelImportRosterDTO channelImportRosterDTO);
}
