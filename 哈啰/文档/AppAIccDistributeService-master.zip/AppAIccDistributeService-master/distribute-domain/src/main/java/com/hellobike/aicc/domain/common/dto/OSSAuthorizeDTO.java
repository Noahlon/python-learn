package com.hellobike.aicc.domain.common.dto;

import lombok.Data;

/**
 * 类说明
 *
 * @author panlongqian
 * @since 2025-03-21
 */
@Data
public class OSSAuthorizeDTO {
    /**
     * 授权后的访问地址
     */
    private String authorizedUrl;
    /**
     * 过期时间，时间戳
     */
    private Long expired;
}
