package com.hellobike.aicc.domain.smsrecord.entity;

import com.hellobike.aicc.common.enums.SmsSendResultEnum;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-06-10  14:15:14
 */
@Data
public class SmsCheckEntity {

    /**
     * id
     */
    private Long id;

    /**
     * 数据密级L2,短信id
     */
    private Long smsId;

    /**
     * 数据密级L2,手机号md5
     */
    private String phoneNumberMd5;

    /**
     * 数据密级L2,分流计划id
     */
    private Long distributePlanId;

    /**
     * 数据密级L2,收到短信结果时间
     */
    private LocalDateTime receiveResultTime;

    /**
     * 数据密级L2,处理状态 0-未处理 1-已处理
     */
    private Integer handleStatus;

    /**
     * 数据密级L2,处理结果描述
     */
    private String handleResultDesc;

    /**
     * 数据密级L2,待处理的短信发送结果
     * @see SmsSendResultEnum
     */
    private Integer handleSendResult;

    /**
     * 数据密级L2,创建时间
     */
    private LocalDateTime createTime;

    /**
     * 数据密级L2,最近更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 数据密级L2,是否删除
     */
    private Integer isDelete;
}
