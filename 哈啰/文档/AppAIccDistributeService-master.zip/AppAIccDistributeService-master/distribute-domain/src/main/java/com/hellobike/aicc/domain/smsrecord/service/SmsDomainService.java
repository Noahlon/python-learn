package com.hellobike.aicc.domain.smsrecord.service;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordCondition;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;

public interface SmsDomainService {
    PageResult<SmsRecordEntity> pageQuerySmsRecord(SmsRecordCondition condition);

    void export(SmsRecordCondition condition, String operator);

    void checkSmsStatus();
}
