package com.hellobike.aicc.domain.distribute.repo;

import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributeChannelTaskQryCondition;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-07  14:38:58
 */
public interface DistChannelTaskRepo {
    void createDistributeChannelTask(DistributeChannelTaskEntity distributeChannelTaskEntity);

    DistributeChannelTaskEntity queryById(Long distributeChannelTaskId);

    void updateDistributeChannelTask(DistributeChannelTaskEntity distributeChannelTaskEntity);

    /**
     * 修改下发时任务信息
     *
     * @param distributeChannelTaskEntity
     */
    void updateWhenDistribute(DistributeChannelTaskEntity distributeChannelTaskEntity);

    /**
     * 查询分流计划的渠道任务列表
     *
     * @param distributePlanId 分流计划id
     * @return 分流计划的渠道任务列表
     */
    List<DistributeChannelTaskEntity> queryDistributePlanTaskList(Long distributePlanId);

    /**
     * 查询分流计划的渠道任务列表
     */
    List<DistributeChannelTaskEntity> queryTaskListByPlanIdList(List<Long> distributePlanIdList);


    /**
     * 查询分流计划的渠道任务列表同时查es
     *
     * @param distributePlanId 分流计划id
     * @param planCreateTime   分流计划创建时间（es索引）
     * @return 分流计划的渠道任务列表
     */
    List<DistributeChannelTaskEntity> queryEsPlanTaskList(Long distributePlanId, LocalDateTime planCreateTime);

    /**
     * 通过条件查询
     *
     * @param condition
     * @return List<DistributeChannelTaskEntity>
     * @author zhangzhuoqi
     * @since 2025/6/9 17:23
     **/
    List<DistributeChannelTaskEntity> queryByCondition(DistributeChannelTaskQryCondition condition);
}
