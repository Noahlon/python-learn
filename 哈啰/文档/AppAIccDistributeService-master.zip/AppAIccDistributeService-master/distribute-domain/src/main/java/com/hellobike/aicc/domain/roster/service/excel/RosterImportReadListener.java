package com.hellobike.aicc.domain.roster.service.excel;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.enums.CellDataTypeEnum;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.metadata.Cell;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * 名单文件解析监听器
 *
 * @author panlongqian
 * @since 2025-03-18
 */
@Getter
@Slf4j
public class RosterImportReadListener extends AnalysisEventListener<RosterImportVO> {
    /**
     * 第四行开始存放变量信息
     */
    private static final int SKIP_ROW = 3;

    private int failedCount = 0;

    private final Set<String> idSet = new HashSet<>();

    private final List<RosterImportVO> dataList = new ArrayList<>();

    private Map<Integer, String> headMap = new HashMap<>();

    private Integer rosterType;

    public RosterImportReadListener() {
    }

    public RosterImportReadListener(Integer rosterType) {
        this.rosterType = rosterType;
    }

    @Override
    public void invoke(RosterImportVO data, AnalysisContext context) {
        if (data == null) {
            return;
        }

        if (!data.isValid(rosterType)) {
            failedCount++;
            return;
        }

        Map<Integer, Cell> cellMap = context.readRowHolder().getCellMap();
        Map<String, String> varibaleMap = new HashMap<>();
        if (!variableCheck(cellMap, varibaleMap)) {
            failedCount++;
            return;
        }

        data.setVariableMap(varibaleMap);

        if (idSet.contains(data.getPhoneNum() + "-" + data.getExternalId())) {
            return;
        }
        idSet.add(data.getPhoneNum() + "-" + data.getExternalId());
        dataList.add(data);
    }

    private boolean variableCheck(Map<Integer, Cell> cellMap, Map<String, String> varibaleMap) {
        for (int i = SKIP_ROW; i < headMap.size(); i++) {
            Cell cell = cellMap.get(i);
            if (Objects.isNull(cell) || !(cell instanceof ReadCellData)) {
                continue;
            }
            ReadCellData<String> cellData = (ReadCellData<String>) cell;
            CellDataTypeEnum type = cellData.getType();
            String variableValue = null;
            switch (type) {
                case STRING:
                    variableValue = cellData.getStringValue();
                    break;
                case BOOLEAN:
                    variableValue = String.valueOf(cellData.getBooleanValue());
                    break;
                case NUMBER:
                    variableValue = cellData.getNumberValue().stripTrailingZeros().toPlainString();
                    break;
                default:
                    break;
            }
            if (StringUtils.isNotBlank(variableValue) && variableValue.length() > 2048) {
                return false;
            }
            varibaleMap.put(headMap.get(i), variableValue);
        }
        return BaseJsonUtils.writeValue(varibaleMap).length() <= 2048;
    }

    @Override
    public void invokeHeadMap(Map<Integer, String> headMap, AnalysisContext context) {
        log.info("解析到表头数据为 : {}", headMap);
        this.headMap = headMap;
        boolean flag = MapUtils.isNotEmpty(headMap) && headMap.values().containsAll(Arrays.asList("手机号", "数据标识", "姓名"));
        AssertUtils.isTrue(flag, "xlsx表头不合法");
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {

    }
}
