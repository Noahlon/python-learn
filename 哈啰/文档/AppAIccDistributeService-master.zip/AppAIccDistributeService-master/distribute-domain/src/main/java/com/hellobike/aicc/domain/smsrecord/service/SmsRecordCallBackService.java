package com.hellobike.aicc.domain.smsrecord.service;

import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;

public interface SmsRecordCallBackService {
    /**
     * 处理渠道商短信消息回调
     *
     * @param smsRecord 回调消息内容
     * @param channelId 渠道商信息
     */
    void handleSmsRecordCallBack(SmsRecordEntity smsRecord, Integer channelId);
}
