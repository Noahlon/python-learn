package com.hellobike.aicc.domain.roster.entity;

import lombok.Data;

/**
 * @author zhangzhuoqi
 * @since 2025-05-26  16:11:07
 */
@Data
public class RosterStat {
    /**
     * 分流计划id
     */
    private String distributePlanId;

    /**
     * 渠道任务id
     */
    private String channelTaskId;

    /**
     * 已呼叫名单数
     */
    private Long callRosterNum;

    /**
     * 接通名单数
     */
    private Long throughRosterNum;

    /**
     * 发送短信名单数
     */
    private Long sendSmsRosterNum;

    /**
     * 发送短信成功名单数
     */
    private Long sendSmsSuccRosterNum;
}
