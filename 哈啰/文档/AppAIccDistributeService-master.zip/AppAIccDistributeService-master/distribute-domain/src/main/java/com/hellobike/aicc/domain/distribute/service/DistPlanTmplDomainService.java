package com.hellobike.aicc.domain.distribute.service;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanTemplateCondition;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanTemplateEntity;

import java.util.List;

/**
 * @author fanxiaodongwb230
 */
public interface DistPlanTmplDomainService {
    /**
     * 创建分发计划模版
     * @param distributePlanTemplateEntity
     * @return
     */
    Long createPlanTemplate(DistributePlanTemplateEntity distributePlanTemplateEntity);

    /**
     * 更新分发计划模版
     * @param distributePlanTemplateEntity
     * @return
     */
    Long updatePlanTemplate(DistributePlanTemplateEntity distributePlanTemplateEntity);

    /**
     * 删除分发计划模版
     * @param templateId
     */
    void deletePlanTemplate(Long templateId);

    /**
     * 分发计划模版分页查询
     * @param condition
     * @return
     */
    PageResult<DistributePlanTemplateEntity> queryPlanTemplate(DistributePlanTemplateCondition condition);

    /**
     * 分发计划模版分页查询
     * @param condition
     * @return
     */
    List<DistributePlanTemplateEntity> queryPlanTemplateList(String tenantCode);

    /**
     * 根据id查询分发计划模版
     * @param templateId
     * @return
     */
    DistributePlanTemplateEntity getPlanTemplateById(String templateId);


}
