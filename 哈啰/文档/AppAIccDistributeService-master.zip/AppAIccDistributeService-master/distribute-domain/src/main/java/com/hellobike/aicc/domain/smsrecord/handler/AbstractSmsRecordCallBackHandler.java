package com.hellobike.aicc.domain.smsrecord.handler;

import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import com.hellobike.aicc.domain.dialogue.repo.CallDialogueRepository;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.repo.PlanRosterRepository;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;
import com.hellobike.aicc.domain.smsrecord.service.SmsRecordCallBackService;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Resource;
import java.util.Objects;

/**
 * 短信回调处理-抽象类
 * 不同渠道商相同处理逻辑放到此类处理
 */
public abstract class AbstractSmsRecordCallBackHandler<C> implements SmsCallBackHandler<C> {
    @Resource
    private SmsRecordCallBackService smsRecordDomainService;

    @Resource
    private CallDialogueRepository callDialogueRepository;

    @Resource
    private PlanRosterRepository planRosterRepository;

    protected void doHandlerSmsCallBack(SmsRecordEntity smsRecord, Integer channelId) {
        smsRecordDomainService.handleSmsRecordCallBack(smsRecord, channelId);
    }

    protected CallDialogueEntity queryCallDialogue(SmsRecordEntity smsRecordEntity) {
        // 如果手机号不为空则根据手机号查询，如果手机号为空则根据小写MD5查询
        if (StringUtils.isNotBlank(smsRecordEntity.getPhoneNumber())) {
            CallDialogueEntity dialogue = callDialogueRepository.getCallDialogueBySupplier(smsRecordEntity.getSupplierCallGuid(), smsRecordEntity.getPhoneNumber(), smsRecordEntity.getChannelId());
            if (dialogue == null && StringUtils.isNotBlank(smsRecordEntity.getPhoneNumberMd5())) {
                dialogue = callDialogueRepository.getCallDialogueBySupplier(smsRecordEntity.getSupplierCallGuid(), smsRecordEntity.getPhoneNumberMd5().toLowerCase(), smsRecordEntity.getChannelId());
            }
            return dialogue;
        } else {
            return callDialogueRepository.getCallDialogueBySupplier(smsRecordEntity.getSupplierCallGuid(), smsRecordEntity.getPhoneNumberMd5().toLowerCase(), smsRecordEntity.getChannelId());
        }
    }

    protected PlanRosterEntity queryRoster(SmsRecordEntity smsRecordEntity) {
        // 根据rosterKey查询名单
        String rosterIdStr = smsRecordEntity.getRosterKey().split("-")[0];
        String distPlanIdStr = smsRecordEntity.getRosterKey().split("-")[1];
        if (!NumberUtil.isLong(rosterIdStr) || !NumberUtil.isLong(distPlanIdStr)) {
            return null;
        }
        Long rosterId = Long.valueOf(rosterIdStr);
        Long distPlanId = Long.valueOf(distPlanIdStr);

        PlanRosterEntity roster = planRosterRepository.getRosterById(rosterId, distPlanId, smsRecordEntity.getPhoneNumber());
        if (Objects.isNull(roster)) {
            if (StrUtil.isNotBlank(smsRecordEntity.getPhoneNumberMd5())) {
                roster = planRosterRepository.getRosterById(rosterId, distPlanId, smsRecordEntity.getPhoneNumberMd5().toLowerCase());
            }
        }
        return roster;
    }
}
