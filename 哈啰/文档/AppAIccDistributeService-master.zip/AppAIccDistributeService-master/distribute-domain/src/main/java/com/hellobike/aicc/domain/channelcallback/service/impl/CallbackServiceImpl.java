package com.hellobike.aicc.domain.channelcallback.service.impl;

import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.channel.factory.ChannelInfo;
import com.hellobike.aicc.domain.channelcallback.service.CallbackService;
import com.hellobike.aicc.domain.dialogue.dto.DialogueCallBackDTO;
import com.hellobike.aicc.domain.dialogue.service.DialogueDomainService;
import com.hellobike.aicc.domain.smsrecord.dto.SmsRecordCallBackDTO;
import com.hellobike.aicc.domain.smsrecord.handler.SmsCallBackHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
@Slf4j
public class CallbackServiceImpl implements CallbackService {
    @Resource
    private DialogueDomainService dialogueDomainService;


    @Override
    public void smsRecordCallBack(SmsRecordCallBackDTO dto, Integer channelId) {
        SmsCallBackHandler smsHandler = ChannelFactory.getSmsHandler(channelId);
        ChannelInfo channel = ChannelFactory.getChannel(channelId);
        smsHandler.handlerSmsCallBack(dto, channel);
    }


    @Override
    public void callDialogueCallBack(DialogueCallBackDTO dialogueCallBackDTO, Integer channelId) {
        dialogueDomainService.handleCallDialogueCallBack(dialogueCallBackDTO, channelId);
    }
}
