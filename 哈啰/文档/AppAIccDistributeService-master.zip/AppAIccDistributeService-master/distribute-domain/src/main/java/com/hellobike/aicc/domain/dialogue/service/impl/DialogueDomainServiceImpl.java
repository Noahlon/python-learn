package com.hellobike.aicc.domain.dialogue.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.component.ApolloConfigs;
import com.hellobike.aicc.common.constants.CommonConstants;
import com.hellobike.aicc.common.enums.BusinessTypeEnum;
import com.hellobike.aicc.common.enums.CallResultEnum;
import com.hellobike.aicc.common.enums.CallTypeEnum;
import com.hellobike.aicc.common.enums.CarrierTypeEnum;
import com.hellobike.aicc.common.enums.FileExportBizTypeEnum;
import com.hellobike.aicc.common.enums.FileExportStatusEnum;
import com.hellobike.aicc.common.enums.ReleaseInitiatorEnum;
import com.hellobike.aicc.common.enums.RosterTypeEnum;
import com.hellobike.aicc.common.enums.SexEnum;
import com.hellobike.aicc.common.enums.YesOrNoEnum;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.exception.BusinessException;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.common.util.FileUtils;
import com.hellobike.aicc.common.util.RedisKeyUtils;
import com.hellobike.aicc.common.util.export.ExcelExporter;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.channel.factory.ChannelInfo;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.dialogue.dto.BaseDialogueCallBackDTO;
import com.hellobike.aicc.domain.dialogue.dto.CallDialogueExportDTO;
import com.hellobike.aicc.domain.dialogue.dto.CallDialogueQueryConditionDTO;
import com.hellobike.aicc.domain.dialogue.dto.CallDialogueScrollQueryDTO;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import com.hellobike.aicc.domain.dialogue.entity.DialogueSpeakEntity;
import com.hellobike.aicc.domain.dialogue.entity.SupplierCallDialogueEntity;
import com.hellobike.aicc.domain.dialogue.handler.CallDialogueCallBackHandler;
import com.hellobike.aicc.domain.dialogue.repo.CallDialogueRepository;
import com.hellobike.aicc.domain.dialogue.repo.SupplierCallDialogueRepository;
import com.hellobike.aicc.domain.dialogue.service.CallDialogueMsgService;
import com.hellobike.aicc.domain.dialogue.service.DialogueDomainService;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanQueryCondition;
import com.hellobike.aicc.domain.file.entity.FileExportRecordEntity;
import com.hellobike.aicc.domain.file.service.FileExportRecordDomainService;
import com.hellobike.aicc.domain.roster.dto.RosterUpdDTO;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.repo.PlanRosterRepository;
import com.hellobike.aicc.domain.utils.HammerThreadPoolUtil;
import com.hellobike.aicc.domain.roster.service.RosterMsgService;
import com.hellobike.aicc.domain.utils.oss.OSSHelper;
import com.hellobike.base.redis.core.client.IRedisHelper;
import com.hellobike.base.redis.core.lock.RedisLock;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * @author zhangzhuoqi
 * @since 2025-03-13  14:43:40
 */
@Slf4j
@Service
public class DialogueDomainServiceImpl implements DialogueDomainService {

    @Resource
    private CallDialogueRepository dialogueRepository;

    @Resource
    private PlanRosterRepository planRosterRepository;

    @Resource
    private DistPlanRepo distPlanRepo;

    @Resource
    private CallDialogueMsgService callDialogueMsgService;

    @Resource
    private SupplierCallDialogueRepository supplierCallDialogueRepository;

    @Resource
    private IdGeneratorService idGeneratorService;

    @Resource
    private OSSHelper ossHelper;

    @Resource
    private RosterMsgService rosterMsgService;

    @Resource
    private IRedisHelper redisHelper;

    @Resource
    private FileExportRecordDomainService exportRecordDomainService;

    @Resource
    private ApolloConfigs apolloConfigs;

    @Override
    public PageResult<CallDialogueEntity> pageDialogueRecords(CallDialogueQueryConditionDTO condition, Integer pageNum, Integer pageSize) {

        PageResult<CallDialogueEntity> pageResult = dialogueRepository.pageCallDialogue(condition, pageNum, pageSize);
        if (!pageResult.isEmpty()){
            List<CallDialogueEntity> callList = pageResult.getList();
            this.setCallTenantName(callList);
        }
        return pageResult;
    }

    private void setCallTenantName(List<CallDialogueEntity> callList) {
        List<Long> planIdList = callList.stream().map(CallDialogueEntity::getDistributePlanId).filter(Objects::nonNull).distinct().collect(Collectors.toList());
        if (CollectionUtil.isEmpty(planIdList)){
            return;
        }
        DistributePlanQueryCondition queryCondition = new DistributePlanQueryCondition();
        queryCondition.setPlanIdList(planIdList);
        List<DistributePlanEntity> planEntityList = distPlanRepo.queryByCondition(queryCondition);
        if (CollectionUtil.isEmpty(planEntityList)){
            return;
        }
        Map<String, String> tenantMap = planEntityList.stream().collect(Collectors.toMap(DistributePlanEntity::getTenantCode, DistributePlanEntity::getTenantName, (v1, v2) -> v1));
        for (CallDialogueEntity callDialogueEntity : callList) {
            if (tenantMap.containsKey(callDialogueEntity.getTenantId())){
                callDialogueEntity.setTenantName(tenantMap.get(callDialogueEntity.getTenantId()));
            }
        }
    }

    @Override
    public <C extends BaseDialogueCallBackDTO> void handleCallDialogueCallBack(C callBackDTO, Integer channelId) {
        RedisLock dialogueLock = redisHelper.createLock(RedisKeyUtils.cssDialogueLockKey(channelId + "-" + callBackDTO.getDialogueGuid()));
        try {
            boolean isLock = dialogueLock.blockAcquireLock(5000, 5000);
            if (!isLock) {
                log.error("渠道话单未获取到锁，guid:{}", callBackDTO.getDialogueGuid());
                return;
            }
            this.doCallBack(callBackDTO, channelId);
        } finally {
            dialogueLock.releaseLock();
        }
    }

    private <C extends BaseDialogueCallBackDTO> void doCallBack(C callBackDTO, Integer channelId) {
        ChannelInfo channel = ChannelFactory.getChannel(channelId);
        log.info("处理渠道商话单回调,callBackDTO:{},channel:{}", BaseJsonUtils.writeValue(callBackDTO), channel.getChannelName());
        if (Objects.isNull(callBackDTO)) {
            log.error("渠道商话单回调，消息题为空");
            return;
        }
        CallDialogueCallBackHandler dialogueCallbackHandler = ChannelFactory.getDialogueHandler(channelId);
        AssertUtils.notNull(dialogueCallbackHandler, BusinessErrorCode.DIALOGUE_CALL_BACK_NOT_EXIST);

        //构建话单实体
        CallDialogueEntity callDialogueEntity = dialogueCallbackHandler.buildCallDialogueEntity(callBackDTO);

        if (Objects.isNull(callDialogueEntity)) {
            log.error("构建话单数据失败");
            throw new BusinessException(BusinessErrorCode.BUILD_CALL_BACK_ERROR);
        }

        callDialogueEntity.setChannelId(channel.getChannelId());
        callDialogueEntity.setChannelName(channel.getChannelName());
        //保存话单
        CallDialogueEntity callDialogue = dialogueRepository.getCallDialogueBySupplier(callDialogueEntity.getDialogueGuid(), callDialogueEntity.getCalledNumber(), callDialogueEntity.getChannelId());
        boolean isSaveDialogue;
        boolean isSave = false;
        if (Objects.isNull(callDialogue)) {
            isSaveDialogue = dialogueRepository.save(callDialogueEntity);
            isSave = true;
        } else {
            log.info("渠道话单重复回调,dialogueGuid:{}", callDialogueEntity.getDialogueGuid());
            callDialogueEntity.setId(callDialogue.getId());
            callDialogueEntity.setCreateTime(callDialogue.getCreateTime());
            isSaveDialogue = dialogueRepository.updateById(callDialogueEntity);
        }

        //保存渠道商话单
        if (isSaveDialogue) {
            SupplierCallDialogueEntity supplierCallDialogueEntity = new SupplierCallDialogueEntity();
            supplierCallDialogueEntity.setId(idGeneratorService.getLongId());
            supplierCallDialogueEntity.setCallId(callDialogueEntity.getId());
            supplierCallDialogueEntity.setDistributePlanId(callDialogueEntity.getDistributePlanId());
            supplierCallDialogueEntity.setSupplierCallJson(BaseJsonUtils.writeValue(callBackDTO));
            supplierCallDialogueRepository.save(supplierCallDialogueEntity);
        }

        if (!isSaveDialogue) {
            log.error("话单回调，保存数据库失败,渠道商话单id:{}", callDialogueEntity.getDialogueGuid());
            throw new BusinessException(BusinessErrorCode.BUILD_CALL_BACK_ERROR);
        } else {
            //更新名单（话单数、接通话单数、最近呼叫时间、最近接通时间）
            if (isSave) {
                log.info("新增话单，更新名单数据,dialogueGuid:{}", callDialogueEntity.getDialogueGuid());
                PlanRosterEntity planRosterEntity = new PlanRosterEntity();
                planRosterEntity.setId(callDialogueEntity.getRosterId());
                planRosterEntity.setLastCallTime(callDialogueEntity.getDialTime());
                planRosterEntity.setLastThroughTime(callDialogueEntity.getAnswerTime());
                planRosterEntity.setLastCallResult(callDialogueEntity.getCallResult());
                planRosterEntity.setDistributePlanId(callDialogueEntity.getDistributePlanId());
                if (Objects.equals(callDialogueEntity.getRosterType(), RosterTypeEnum.MD5.getCode())) {
                    planRosterEntity.setPhoneNum(callDialogueEntity.getMd5());
                } else {
                    planRosterEntity.setPhoneNum(callDialogueEntity.getCalledNumber());
                }
                if (Objects.equals(callDialogueEntity.getCallResult(), CallResultEnum.THROUGH.getCode())) {
                    planRosterEntity.setThroughCallDialogueNum(1);
                }
                planRosterEntity.setCallDialogueNum(1);
                planRosterRepository.updateRosterByCallBack(planRosterEntity);
                //发送名单更新消息
                RosterUpdDTO rosterUpdDTO = new RosterUpdDTO();
                rosterUpdDTO.setId(String.valueOf(planRosterEntity.getId()));
                rosterUpdDTO.setPlanId(String.valueOf(callDialogueEntity.getDistributePlanId()));
                rosterUpdDTO.setPhoneNum(planRosterEntity.getPhoneNum());
                DistributePlanEntity distributePlanEntity = distPlanRepo.queryDistributePlanById(planRosterEntity.getDistributePlanId());
                rosterUpdDTO.setPlanCreateTime(DateUtils.format(distributePlanEntity.getCreateTime()));
                rosterMsgService.sendUpdMsg(rosterUpdDTO);
            }
        }
        //发送话单消息
        callDialogueMsgService.sendMsg(callDialogueEntity);
    }

    @Override
    public CallDialogueEntity queryDetail(String id, String calledNumber) {
        CallDialogueEntity detail = dialogueRepository.getDetail(Long.valueOf(id), calledNumber);
        if (Objects.isNull(detail)) {
            return null;
        }
        List<DialogueSpeakEntity> speakList = detail.getSpeakList();
        if (CollectionUtil.isNotEmpty(speakList)) {
            speakList.sort(Comparator.comparing(DialogueSpeakEntity::getSpeakTime));
        }
        return detail;
    }

    @Override
    public void export(CallDialogueQueryConditionDTO condition, List<String> exportFieldList, String operator) {
        long sum = dialogueRepository.countCallDialogue(condition);
        AssertUtils.isTrue(sum > 0, BusinessErrorCode.CALL_RECORD_EXPORT_IS_EMPTY);
        String fileName = "call_record_" + System.currentTimeMillis() + ".xlsx";
        //创建文件导出记录
        FileExportRecordEntity fileExportRecord = new FileExportRecordEntity();
        fileExportRecord.setId(idGeneratorService.getLongId());
        fileExportRecord.setBizType(FileExportBizTypeEnum.DIALOGUE.getCode());
        fileExportRecord.setStatus(FileExportStatusEnum.PROCESS.getCode());
        fileExportRecord.setFileName(fileName);
        fileExportRecord.setOperator(operator);
        exportRecordDomainService.saveOrUpdate(fileExportRecord);

        //异步导出
        CompletableFuture.runAsync(() -> {
            String scrollId = null;
            String filePathName = FileUtils.getTmpDirPath() + fileName;
            long exportNum = 0;
            try (FileOutputStream fos = new FileOutputStream(filePathName);
                 ExcelExporter exporter = ExcelExporter.getInstance(fos, CallDialogueExportDTO.class, exportFieldList)) {
                while (exportNum < Math.min(apolloConfigs.getFileExportDataMaxLimit(), sum)) {
                    log.info("通话记录，当前导出的条数 {}", exportNum);
                    CallDialogueScrollQueryDTO scrollQueryDTO = dialogueRepository.listDialogueForExport(condition, scrollId);
                    scrollId = scrollQueryDTO.getScrollId();
                    List<CallDialogueEntity> callDialogueList = scrollQueryDTO.getDialogueList();
                    if (callDialogueList.isEmpty()) {
                        log.info("数据为空， scrollId {}", scrollId);
                        break;
                    }
                    List<CallDialogueExportDTO> exportList = convertCallDialogueExports(callDialogueList);
                    exporter.write(exportList);
                    exportNum += exportList.size();
                    // 导出的数据量等于查询的数据量时或者数据等于最大数量限制时 导出完成
                    if (exportNum == sum || exportNum >= apolloConfigs.getFileExportDataMaxLimit()) {
                        log.info("通话记录，数据导出完成，导出数据条数 {}", exportNum);
                        // 文件写入完成，显式调用 finish
                        exporter.finish();
                        break;
                    }
                }
                fileExportRecord.setExportCount((int) exportNum);
                String fileUrl = ossHelper.uploadFileToFileName(new File(filePathName), BusinessTypeEnum.DIALOGUE, 60L * 24L * apolloConfigs.getFileExportOssFileExpireDay());
                if (StrUtil.isBlank(fileUrl)) {
                    fileExportRecord.setStatus(FileExportStatusEnum.FAIL.getCode());
                    fileExportRecord.setFailReason(BusinessErrorCode.CALL_DIALOGUE_UPLOAD_OSS_ERROR.getDesc());
                } else {
                    fileExportRecord.setStatus(FileExportStatusEnum.SUCCESS.getCode());
                    fileExportRecord.setFileUrl(fileUrl);
                }
                exportRecordDomainService.saveOrUpdate(fileExportRecord);
            } catch (Exception  e){
                throw new RuntimeException(e);
            } finally {
                org.apache.commons.io.FileUtils.deleteQuietly(new File(filePathName));
            }
        }, HammerThreadPoolUtil.getExportExecutor()).exceptionally(ex -> {
            log.info("话单导出失败,e:", ex);
            fileExportRecord.setFailReason(CommonConstants.EXPORT_ERROR);
            fileExportRecord.setStatus(FileExportStatusEnum.FAIL.getCode());
            exportRecordDomainService.saveOrUpdate(fileExportRecord);
            return null;
        });
    }


    private List<CallDialogueExportDTO> convertCallDialogueExports(List<CallDialogueEntity> callDialogueList) {
        return callDialogueList.stream().map(entity -> {
            CallDialogueExportDTO exportDTO = new CallDialogueExportDTO();
            exportDTO.setChannelName(entity.getChannelName());
            exportDTO.setPlatformId(entity.getPlatformId());
            exportDTO.setExternalId(entity.getExternalId());
            exportDTO.setMd5(entity.getMd5());
            exportDTO.setCalledNumber(entity.getCalledNumber());
            exportDTO.setDistributePlanId(String.valueOf(entity.getDistributePlanId()));
            exportDTO.setDistributePlanName(entity.getDistributePlanName());
            exportDTO.setSupplierTaskId(entity.getSupplierTaskId());
            exportDTO.setSupplierTaskName(entity.getSupplierTaskName());
            if (Objects.nonNull(entity.getTemplateId())) {
                exportDTO.setSpeechTemplateId(String.valueOf(entity.getTemplateId()));
            }
            exportDTO.setEnterpriseId(entity.getEnterpriseId());
            exportDTO.setTenantId(entity.getTenantId());
            exportDTO.setCallResultDesc(CallResultEnum.getDescByCode(entity.getCallResult()));
            exportDTO.setIntentClassify(entity.getIntentClassify());
            exportDTO.setIntentClassifyName(entity.getIntentClassifyName());
            if (CollectionUtil.isNotEmpty(entity.getHitIntentions())) {
                exportDTO.setHitIntentions(BaseJsonUtils.writeValue(entity.getHitIntentions()));
            }
            exportDTO.setIsHitSms(YesOrNoEnum.getDescByCode(entity.getIsHitSms()));
            exportDTO.setSeatName(entity.getSeatName());
            exportDTO.setDurationCallAi(entity.getDurationCallAi());
            exportDTO.setDurationCallManual(entity.getDurationCallManual());
            exportDTO.setRealCallingNumber(entity.getRealCallingNumber());
            exportDTO.setTotalTime(entity.getTotalTime());
            exportDTO.setRingTime(entity.getRingTime());
            exportDTO.setDialTime(DateUtils.format2MilliSecond(entity.getDialTime()));
            exportDTO.setHangupTime(DateUtils.format2MilliSecond(entity.getHangupTime()));
            exportDTO.setCallType(CallTypeEnum.getDescByCode(entity.getCallType()));
            exportDTO.setCallingNumber(entity.getCallingNumber());
            exportDTO.setCostUnit(entity.getCostUnit());
            exportDTO.setCustomName(entity.getCustomName());
            exportDTO.setDialogueGuid(entity.getDialogueGuid());
            exportDTO.setRecordUrl(entity.getRecordUrl());
            exportDTO.setLineId(entity.getLineId());
            exportDTO.setProvinceCity(CallDialogueEntity.getProvinceAndCity(entity.getProvince(), entity.getCity()));
            exportDTO.setCarrier(CarrierTypeEnum.getEnumByCode(entity.getCarrier()).getDesc());
            exportDTO.setSpeechCount(entity.getSpeechCount());
            exportDTO.setSex(SexEnum.getEnumByCode(entity.getSex()).getDesc());
            exportDTO.setReleaseInitiator(ReleaseInitiatorEnum.getEnumByCode(entity.getReleaseInitiator()).getDesc());
            exportDTO.setCreateTime(DateUtils.format2MilliSecond(entity.getCreateTime()));
            return exportDTO;
        }).collect(Collectors.toList());
    }
}
