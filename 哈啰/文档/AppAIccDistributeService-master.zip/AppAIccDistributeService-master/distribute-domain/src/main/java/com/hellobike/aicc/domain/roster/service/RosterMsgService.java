package com.hellobike.aicc.domain.roster.service;

import com.hellobike.aicc.domain.roster.dto.RosterUpdDTO;

/**
 * 名单消息服务
 *
 * @author zhangzhuoqi
 * @since 2025-05-24  10:54:08
 */
public interface RosterMsgService {


    /**
     * 发送名单更新消息
     *
     * @param msg msg
     * @return boolean
     * @author zhangzhuoqi
     * @since 2025/5/24 10:55
     **/
    boolean sendUpdMsg(RosterUpdDTO msg);
}
