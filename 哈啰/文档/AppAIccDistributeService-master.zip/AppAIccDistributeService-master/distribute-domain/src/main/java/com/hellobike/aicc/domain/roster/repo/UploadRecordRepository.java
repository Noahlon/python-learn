package com.hellobike.aicc.domain.roster.repo;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.roster.dto.UploadRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;

import java.util.List;

/**
 * 分表键：distributePlanId
 * 操作repo时请确保distributePlanId不为空
 *
 * @author zhangzhuoqi
 * @since 2025-03-07  14:35:52
 */
public interface UploadRecordRepository {

    /**
     * 创建一条上传记录
     * 分表键：distributePlanId
     *
     * @param uploadRecordEntity
     * @return void
     * @author zhangzhuoqi
     * @since 2025/3/7 17:42
     **/
    void addRecord(UploadRecordEntity uploadRecordEntity);

    /**
     * 通过id修改上传记录
     *
     * @param uploadRecordEntity
     * @return void
     * @author zhangzhuoqi
     * @since 2025/3/10 11:07
     **/
    void updateRecordById(UploadRecordEntity uploadRecordEntity);

    /**
     * 通过id查询上传记录
     *
     * @param id               上传记录id
     * @param distributePlanId 分流计划id（分表键）
     * @return com.hellobike.aicc.domain.roster.entity.UploadRecordEntity
     * @author zhangzhuoqi
     * @since 2025/3/10 11:07
     **/
    UploadRecordEntity getRecordById(Long id, Long distributePlanId);

    /**
     * 通过条件查询上传记录
     *
     * @param uploadRecordQueryConditionDTO 查询条件
     * @return java.util.List<com.hellobike.aicc.domain.roster.entity.UploadRecordEntity>
     * @author zhangzhuoqi
     * @since 2025/3/10 11:07
     **/
    List<UploadRecordEntity> queryByCondition(UploadRecordQueryConditionDTO uploadRecordQueryConditionDTO);

    /**
     * 分页查询
     *
     * @param uploadRecordQueryConditionDTO 查询条件
     * @param pageNum                       页码
     * @param pageSize                      页大小
     * @return
     */
    PageResult<UploadRecordEntity> pageByCondition(UploadRecordQueryConditionDTO uploadRecordQueryConditionDTO, Integer pageNum, Integer pageSize);

    /**
     * 下发名单时修改上传记录相关字段
     *
     * @author zhangzhuoqi
     * @since 2025/3/18 16:26
     * @param uploadRecordEntity
     * @return void
     **/
    void updateWhenDistribute(UploadRecordEntity uploadRecordEntity);

    /**
     * 更新上传记录的上传数量
     */
    void updateUploadCount(Long id, Long distributePlanId, Integer uploadCount);
}
