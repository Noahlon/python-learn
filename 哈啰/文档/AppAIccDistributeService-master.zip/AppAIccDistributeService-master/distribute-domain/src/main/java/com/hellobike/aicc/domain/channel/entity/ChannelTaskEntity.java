package com.hellobike.aicc.domain.channel.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 渠道商任务entity
 */
@Data
@NoArgsConstructor
public class ChannelTaskEntity {
    /**
     * 渠道商任务id
     */
    private String channelTaskId;

    /**
     * 渠道商任务名称
     */
    private String channelTaskName;

    public ChannelTaskEntity(String channelTaskId, String channelTaskName) {
        this.channelTaskId = channelTaskId;
        this.channelTaskName = channelTaskName;
    }
}
