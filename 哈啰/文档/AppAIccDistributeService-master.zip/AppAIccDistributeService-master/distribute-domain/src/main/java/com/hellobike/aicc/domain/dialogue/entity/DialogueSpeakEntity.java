package com.hellobike.aicc.domain.dialogue.entity;

import com.hellobike.aicc.common.enums.SpeakerEnum;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-04-18  10:36:10
 */
@Data
public class DialogueSpeakEntity {

    /**
     * 说话id
     */
    private String speakId;

    /**
     * 说话方 1-呼叫方 2-被叫方
     * @see SpeakerEnum
     */
    private Integer speaker;

    /**
     * 说话内容
     */
    private String speakContent;

    /**
     * 说话时间
     */
    private LocalDateTime speakTime;
}
