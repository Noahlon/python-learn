package com.hellobike.aicc.domain.channel.facade;

import com.hellobike.aicc.domain.channel.dto.ChannelTaskCreateDTO;
import com.hellobike.aicc.domain.channel.entity.ChannelEntity;
import com.hellobike.aicc.domain.channel.entity.ChannelTaskEntity;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterDTO;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterResultDTO;

import java.util.List;

/**
 * 开放平台相关接口
 *
 * @author zhangzhuoqi
 * @since 2025-05-12  15:17:58
 */
public interface OpenApiFacade {

    /**
     * openApi平台的业务线
     */
    String BIZ_TYPE = "openProtal";


    /**
     * 查询渠道任务模版
     *
     * @author zhangzhuoqi
     * @since 2025/5/12 15:43
     * @param appKey appKey
     * @return ChannelEntity
     **/
    List<ChannelEntity.ChannelTemplateEntity> queryTemplateList(String appKey);

    /**
     *
     * 创建渠道任务
     * @author zhangzhuoqi
     * @since 2025/5/12 15:44
     * @param channelTaskCreateDTO req
     * @return ChannelTaskEntity
     **/
    ChannelTaskEntity createTask(ChannelTaskCreateDTO channelTaskCreateDTO);

    ChannelImportRosterResultDTO importRoster(ChannelImportRosterDTO channelImportRosterDTO);

}
