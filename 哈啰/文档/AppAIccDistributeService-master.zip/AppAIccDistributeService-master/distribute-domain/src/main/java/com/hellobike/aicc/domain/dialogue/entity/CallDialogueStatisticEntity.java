package com.hellobike.aicc.domain.dialogue.entity;

import lombok.Data;

import java.util.Map;

/**
 * @author fanxiaodongwb230
 */
@Data
public class CallDialogueStatisticEntity {
    /**
     * 渠道商任务id
     */
    private String channelTaskId;

    /**
     * 计划id
     */
    private String planId;

    /**
     * 话单量
     */
    private Long callDialogueNum;

    /**
     * 已呼名单数
     */
    private Long callRosterNum;

    /**
     * 接通话单量
     */
    private Long throughCallDialogueNum;

    /**
     * 计费数
     */
    private Long costUnit;

    /**
     * 接通名单数
     */
    private Long throughRosterNum;

    /**
     * 意向分类统计
     */
    private Map<String, Long> intentionStat;
}
