package com.hellobike.aicc.domain.common.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 类说明
 *
 * @author panlongqian
 * @since 2025-03-21
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class STSTicketDTO {
    private String accessKeyId;

    private String accessKeySecret;

    private String securityToken;

    private String region;

    private String bucket;

    private String baseDir;

    private String requestId;
}
