package com.hellobike.aicc.domain.distribute.service.impl;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanTemplateCondition;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanTemplateEntity;
import com.hellobike.aicc.domain.distribute.repo.DistPlanTemplateRepo;
import com.hellobike.aicc.domain.distribute.service.DistPlanTmplDomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

/**
 * @author fanxiaodongwb230
 */
@Slf4j
@Service
public class DistPlanTmplDomainServiceImpl implements DistPlanTmplDomainService {
    @Resource
    private IdGeneratorService idGeneratorService;
    @Resource
    private DistPlanTemplateRepo distPlanTemplateRepo;

    @Override
    public Long createPlanTemplate(DistributePlanTemplateEntity distributePlanTemplateEntity) {
        Long id = idGeneratorService.getLongId();
        distributePlanTemplateEntity.setId(id);
        distPlanTemplateRepo.save(distributePlanTemplateEntity);
        return id;
    }
    @Override
    public Long updatePlanTemplate(DistributePlanTemplateEntity distributePlanTemplateEntity) {
       distPlanTemplateRepo.updateById(distributePlanTemplateEntity);
       return distributePlanTemplateEntity.getId();
    }

    @Override
    public void deletePlanTemplate(Long templateId) {
        distPlanTemplateRepo.deleteById(templateId);
    }

    @Override
    public PageResult<DistributePlanTemplateEntity> queryPlanTemplate(DistributePlanTemplateCondition condition) {
        return distPlanTemplateRepo.queryPlanTemplate(condition);
    }

    @Override
    public List<DistributePlanTemplateEntity> queryPlanTemplateList(String tenantCode) {
        return distPlanTemplateRepo.queryPlanTemplateList(tenantCode);
    }

    @Override
    public DistributePlanTemplateEntity getPlanTemplateById(String templateId) {
        return distPlanTemplateRepo.queryById(Long.valueOf(templateId));
    }


}
