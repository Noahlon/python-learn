package com.hellobike.aicc.domain.channel.factory;

import cn.hutool.core.collection.CollectionUtil;
import com.ctrip.framework.apollo.ConfigService;
import com.hellobike.aicc.common.util.ApplicationContextHandle;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.processor.ChannelProcessor;
import com.hellobike.aicc.domain.channel.processor.impl.DefaultChannelProcessor;
import com.hellobike.aicc.domain.dialogue.handler.CallDialogueCallBackHandler;
import com.hellobike.aicc.domain.dialogue.handler.DefaultDialogueCallBackHandler;
import com.hellobike.aicc.domain.smsrecord.handler.DefaultSmsCallBackHandler;
import com.hellobike.aicc.domain.smsrecord.handler.SmsCallBackHandler;
import com.hellobike.soa.starter.spring.event.SoaStartedEvent;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author zhangzhuoqi
 * @since 2025-04-19  09:00:16
 */
@Slf4j
@Component
public class ChannelFactory implements ApplicationListener<SoaStartedEvent> {

    @Value("${channel.config:}")
    private String channelConfig;

    private static final String HELLO_AI_CALL = "hello_ai_call";

    private static final Integer YUN_DONG_CHANNEL_ID = 2;

    private static final Map<Integer, ChannelInfo> CHANNEL_MAP = new HashMap<>();
    private static final Map<String, ChannelInfo> CHANNEL_APPKEY_MAP = new HashMap<>();
    private static List<ChannelInfo> CHANNEL_LIST;

    public void initConfig() {
        CHANNEL_LIST = BaseJsonUtils.readValues(channelConfig, ChannelInfo.class);
        log.info("初始化渠道配置,channelList:{}", channelConfig);
        if (CollectionUtil.isEmpty(CHANNEL_LIST)) {
            log.error("初始化渠道配置为空");
            return;
        }
        for (ChannelInfo channelInfo : CHANNEL_LIST) {
            CHANNEL_MAP.put(channelInfo.getChannelId(), channelInfo);
            CHANNEL_APPKEY_MAP.put(channelInfo.getAppKey(), channelInfo);
        }
    }

    /**
     * 获取所有渠道
     */
    public static List<ChannelInfo> getAllChannel() {
        return CHANNEL_LIST.stream().filter(ChannelInfo::getIsEnable).collect(Collectors.toList());
    }

    /**
     * 获取渠道名称
     *
     * @param channelId 渠道id
     */
    public static String getNameById(Integer channelId) {
        ChannelInfo channelInfo = CHANNEL_MAP.get(channelId);
        if (Objects.isNull(channelInfo)) {
            return null;
        }
        return channelInfo.getChannelName();
    }

    /**
     * 通过渠道id获取渠道信息
     *
     * @param channelId 渠道id
     */
    public static ChannelInfo getChannel(Integer channelId) {
        ChannelInfo channelInfo = CHANNEL_MAP.get(channelId);
        if (Objects.isNull(channelInfo) || !channelInfo.getIsEnable()) {
            log.error("渠道不存在或已禁用,id:{}", channelId);
            return null;
        }
        return channelInfo;
    }

    /**
     * 通过渠道appKey获取渠道信息
     *
     * @param appKey 渠道appKey
     */
    public static ChannelInfo getChannel(String appKey) {
        ChannelInfo channelInfo = CHANNEL_APPKEY_MAP.get(appKey);
        if (Objects.isNull(channelInfo) || !channelInfo.getIsEnable()) {
            log.error("渠道不存在或已禁用,appKey:{}", appKey);
            return null;
        }
        return channelInfo;
    }

    /**
     * 获取云动外呼渠道
     */
    public static ChannelInfo getYunDongChannel() {
        return getChannel(YUN_DONG_CHANNEL_ID);
    }

    /**
     * 获取哈啰ai外呼渠道
     */
    public static ChannelInfo getHelloAiCall() {
        return getChannel(HELLO_AI_CALL);
    }


    /**
     * 获取渠道调用接口处理器
     *
     * @param channelId 渠道id
     */
    public static ChannelProcessor getChannelProcessor(Integer channelId) {
        ChannelInfo channel = getChannel(channelId);
        if (Objects.isNull(channel) || !channel.getIsEnable()) {
            return null;
        }
        //如果是标准对接，返回默认处理器
        if (channel.getIsStandard()) {
            return ApplicationContextHandle.getBean(DefaultChannelProcessor.class);
        }
        try {
            return ApplicationContextHandle.getBean(channel.getProcessorClassName(), ChannelProcessor.class);
        } catch (Exception e) {
            log.error("找不到渠道处理器,渠道商id为：{}, 渠道商名称为：{}", channel.getChannelId(), channel.getChannelName());
            return null;
        }
    }

    /**
     * 获取渠道话单回调处理器
     *
     * @param channelId 渠道id
     */
    public static CallDialogueCallBackHandler<?> getDialogueHandler(Integer channelId) {
        ChannelInfo channel = getChannel(channelId);
        if (Objects.isNull(channel) || !channel.getIsEnable()) {
            return null;
        }
        //如果是标准对接，返回默认处理器
        if (channel.getIsStandard()) {
            return ApplicationContextHandle.getBean(DefaultDialogueCallBackHandler.class);
        }
        try {
            return ApplicationContextHandle.getBean(channel.getDialogueClassName(), CallDialogueCallBackHandler.class);
        } catch (Exception e) {
            log.error("找不到话单渠道处理器,渠道商id为：{}, 渠道商名称为：{}", channel.getChannelId(), channel.getChannelName());
            return null;
        }
    }

    /**
     * 获取渠道短信回调处理器
     *
     * @param channelId 渠道id
     */
    public static SmsCallBackHandler getSmsHandler(Integer channelId) {
        ChannelInfo channel = getChannel(channelId);
        if (Objects.isNull(channel) || !channel.getIsEnable()) {
            return null;
        }
        //如果是标准对接，返回默认处理器
        if (channel.getIsStandard()) {
            return ApplicationContextHandle.getBean(DefaultSmsCallBackHandler.class);
        }
        try {
            return ApplicationContextHandle.getBean(channel.getSmsClassName(), SmsCallBackHandler.class);
        } catch (Exception e) {
            log.error("找不到短信渠道处理器,渠道商id为：{}, 渠道商名称为：{}", channel.getChannelId(), channel.getChannelName());
            return null;
        }
    }

    @Override
    public void onApplicationEvent(@NotNull SoaStartedEvent soaStartedEvent) {
        //初始化渠道配置
        initConfig();
        //监听渠道配置变动
        ConfigService.getAppConfig().addChangeListener(changeEvent -> {
            try {
                //初始化监听事件
                String key = "channel.config";
                if (changeEvent.isChanged(key)) {
                    channelConfig = changeEvent.getChange(key).getNewValue();
                    initConfig();
                }
            } catch (Exception e) {
                log.error("apollo change error", e);
            }
        });
    }
}
