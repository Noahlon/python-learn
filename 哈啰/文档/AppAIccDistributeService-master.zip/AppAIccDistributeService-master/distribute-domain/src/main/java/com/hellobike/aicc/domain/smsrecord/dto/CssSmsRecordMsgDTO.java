package com.hellobike.aicc.domain.smsrecord.dto;

import lombok.Data;

/**
 * 外呼短信推送消息
 *
 * @author panlongqian
 * @since 2025-04-10
 */
@Data
public class CssSmsRecordMsgDTO {
    /**
     * 短信记录id
     */
    private String id;

    /**
     * 用户接受号码
     */
    private String phoneNumber;

    /**
     * 手机号码的32位小写md5加密
     */
    private String md5;

    /**
     * 短信签名
     */
    private String signature;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 短信发送状态code
     */
    private String sendResult;

    /**
     * 计费条数
     */
    private Integer billingNum;

    /**
     * 租户id
     */
    private String tenantId;

    /**
     * 话单guid
     */
    private String callGuid;

    /**
     * 任务id
     */
    private String taskGuid;

    /**
     * 任务名称
     */
    private String taskName;

    /**
     * 话术名称
     */
    private String speechName;

    /**
     * 归属省
     */
    private String province;

    /**
     * 归属市
     */
    private String city;

    /**
     * 运营商
     */
    private Integer carrier;

    /**
     * 短信发送时间
     */
    private String sendTime;

    /**
     * 名单对应的外部id
     */
    private String externalId;
}
