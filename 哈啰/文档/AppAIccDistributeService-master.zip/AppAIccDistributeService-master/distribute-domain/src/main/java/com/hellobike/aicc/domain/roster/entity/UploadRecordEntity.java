package com.hellobike.aicc.domain.roster.entity;


import com.hellobike.aicc.common.enums.DistributeTypeEnum;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-03-07  17:40:49
 */
@Data
public class UploadRecordEntity {

    private Long id;

    /**
     * 上传方式类型
     *
     * @see com.hellobike.aicc.common.enums.UploadTypeEnum
     */
    private Integer uploadType;

    /**
     * 上传状态
     *
     * @see com.hellobike.aicc.common.enums.UploadStatusEnum
     */
    private Integer uploadStatus;

    /**
     * 上传失败原因
     */
    private String uploadFailReason;

    /**
     * 上传数量
     */
    private Integer uploadCount;

    /**
     * 上传时间
     */
    private LocalDateTime uploadTime;

    /**
     * 下发状态
     */
    private Integer distributeStatus;

    /**
     * 下发数量
     */
    private Integer distributeCount;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 分流类型
     *
     * @see DistributeTypeEnum
     */
    private Integer distributeType;

    /**
     * 分流计划id
     */
    private Long distributePlanId;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 名单类型，1-明文，2-md5
     */
    private Integer rosterType;
}
