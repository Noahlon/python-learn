package com.hellobike.aicc.domain.distribute.repo.condition;

import lombok.Data;

/**
 * @author zhangzhuoqi
 * @since 2025-06-09  17:23:23
 */
@Data
public class DistributeChannelTaskQryCondition {

    /**
     * 三方任务模版id
     */
    private String supplierTaskTemplateId;

    /**
     * 三方任务模版名称
     */
    private String supplierTaskTemplateName;

}
