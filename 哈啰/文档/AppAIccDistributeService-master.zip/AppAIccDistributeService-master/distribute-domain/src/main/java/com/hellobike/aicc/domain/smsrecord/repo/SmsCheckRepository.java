package com.hellobike.aicc.domain.smsrecord.repo;

import com.hellobike.aicc.domain.smsrecord.dto.SmsCheckStatusQryConditionDTO;
import com.hellobike.aicc.domain.smsrecord.entity.SmsCheckEntity;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-06-10  14:14:23
 */
public interface SmsCheckRepository {

    boolean save(SmsCheckEntity entity);

    List<SmsCheckEntity> queryByCondition(SmsCheckStatusQryConditionDTO condition);

    void updateById(SmsCheckEntity smsCheckEntity);
}
