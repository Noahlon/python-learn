package com.hellobike.aicc.domain.distribute.entity;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 数据密级S2,分流模板表
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Data
public class DistributePlanTemplateEntity{

    private Long id;

    /**
     * 数据密级S2,模板名称
     */
    private String templateName;

    /**
     * 数据密级S2,租户code
     */
    private String tenantCode;

    /**
     * 数据密级S2,租户名称
     */
    private String tenantName;

    /**
     * 数据密级S2,分流类型，1-实时分流，2-离线分流
     */
    private Integer distributeType;

    /**
     * 数据密级S2,分流类型描述
     */
    private String distributeTypeDesc;

    /**
     * 数据密级S2,分流规则
     */
    private List<DistributeRuleEntity> distributeRuleList;

    /**
     * 数据密级S2,创建人
     */
    private String creator;

    /**
     * 数据密级S2,创建时间
     */
    private LocalDateTime latestUsingTime;

    /**
     * 数据密级S2,创建时间
     */
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,逻辑删除
     */
    private Integer isDelete =0 ;


}
