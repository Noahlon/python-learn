package com.hellobike.aicc.domain.dialogue.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;


/**
 * @author fanxiaodongwb230
 * @date 2025/04/24 10:04
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class DialogueCallBackDTO extends BaseDialogueCallBackDTO {

    /**
     * 名单数据标识
     */
    private String rosterKey;

    /**
     * 对话信息List
     */
    private List<DialogueSpeakDTO> speakList;

    /**
     * 企业id
     */
    private String enterpriseId;

    /**
     * 被叫号码
     */
    private String calledNumber;

    /**
     * 呼叫结果
     */
    private Integer callResult;

    /**
     * 渠道商呼叫结果code
     */
    private String supplierCallResult;

    /**
     * 渠道商呼叫结果描述
     */
    private String supplierCallResultDesc;

    /**
     * 意向分类code
     * A,B,C,D,E,F,G,H,I,J之一
     */
    private String intentClassify;

    /**
     * 意向分类名称
     */
    private String intentClassifyName;

    /**
     * 命中意图集合
     */
    private List<String> hitIntentions;

    /**
     * 意向标签集合
     */
    private List<String> tags;

    /**
     * 是否触发短信 0-否 1-是
     */
    private Integer isHitSms;

    /**
     * AI通话时长（秒）
     */
    private Integer durationCallAi;

    /**
     * 人工通话时长（秒）
     */
    private Integer durationCallManual;

    /**
     * 中继外显号
     */
    private String realCallingNumber;

    /**
     * 座席名称
     */
    private String seatName;

    /**
     * 通话时长（秒）
     */
    private Integer totalTime;

    /**
     * 振铃时长（秒）
     * 2024-07-30 17:07:59.510
     */
    private Integer ringTime;

    /**
     * 拨打时间
     */
    private String dialTime;

    /**
     * 挂机时间
     */
    private String hangupTime;

    /**
     * 计费数
     */
    private Integer costUnit;

    /**
     * 通话类型 1: AI外呼，2：人工坐席
     */
    private Integer callType;

    /**
     * 主叫号码
     */
    private String callingNumber;

    /**
     * 线路id
     */
    private String lineId;

    /**
     * 号码归属城市
     */
    private String city;

    /**
     * 号码归属省份
     */
    private String province;

    /**
     * 运营商 枚举(1:移动，2：联通，3：电信，4：虚拟，5：未知)
     */
    private Integer carrier;

    /**
     * 客户姓名
     */
    private String customName;

    /**
     * 挂断方 1：呼叫方；2：被叫方；0：未知；
     */
    private Integer releaseInitiator;

    /**
     * 录音文件地址
     */
    private String recordUrl;

    /**
     * 对话轮次
     */
    private Integer speechCount;

    /**
     * 说话次数
     */
    private Integer speakCount;

    /**
     * 性别 1:男，2：女，3：未知
     */
    private Integer sex;

    /**
     * 三方任务id
     */
    private String supplierTaskId;

    /**
     * 三方任务名称
     */
    private String supplierTaskName;

    /**
     * 手机号md5
     */
    private String md5;

    /**
     * 应答时间
     */
    private String answerTime;
}
