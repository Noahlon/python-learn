package com.hellobike.aicc.domain.distribute.repo;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributeRuleEntity;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author zhengchenyang
 * @date 2025/3/20
 * @desc 分流规则缓存
 */
@Service
public class DistRuleManage {
    @Resource
    private DistPlanRepo distPlanRepo;

    private Cache<Long, List<DistributeRuleEntity>> distRuleCache;

    public List<DistributeRuleEntity> getDistRule(Long planId) {
        if (distRuleCache == null || distRuleCache.estimatedSize() <= 0) {
            initDistRule();
        }
        List<DistributeRuleEntity> rules = distRuleCache.getIfPresent(planId);
        return CollectionUtils.isNotEmpty(rules) ? rules : null;
    }

    @PostConstruct
    public void init() {
        initDistRule();
    }

    private void initDistRule() {
        distRuleCache = Caffeine.newBuilder()
                .initialCapacity(DistRuleConstant.RatioCaCheConfig.INITIAL_CAPACITY)
                .maximumSize(DistRuleConstant.RatioCaCheConfig.MAXIMUM_SIZE)
                .expireAfterWrite(DistRuleConstant.RatioCaCheConfig.EXPIRE_AFTER_WRITE_MINUTES, TimeUnit.MINUTES)
                .expireAfterAccess(DistRuleConstant.RatioCaCheConfig.EXPIRE_AFTER_ACCESS_MINUTES, TimeUnit.MINUTES)
                .build();
        List<DistributePlanEntity> plans = distPlanRepo.queryAllEffectiveDistPlans();
        if (CollectionUtils.isNotEmpty(plans)) {
            Map<Long, List<DistributeRuleEntity>> map = plans.stream()
                    .collect(Collectors.toMap(DistributePlanEntity::getId, DistributePlanEntity::getDistributeRuleList, (a, b) -> b));
            distRuleCache.putAll(map);
        }
    }
}
