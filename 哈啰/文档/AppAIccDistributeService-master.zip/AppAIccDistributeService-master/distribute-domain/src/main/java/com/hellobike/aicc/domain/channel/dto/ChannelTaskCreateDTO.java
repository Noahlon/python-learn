package com.hellobike.aicc.domain.channel.dto;

import com.hellobike.aicc.common.basic.LoginParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 类说明
 *
 * @author panlongqian
 * @since 2025-03-20
 */

@EqualsAndHashCode(callSuper = true)
@Data
public class ChannelTaskCreateDTO extends LoginParam {
    /**
     * 渠道任务模板id
     */
    private String taskTemplateId;

    /**
     * 分流计划id
     */
    private Long distributePlanId;

    /**
     * 渠道商appKey，供外部渠道商使用
     */
    private String appKey;


}
