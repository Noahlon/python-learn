package com.hellobike.aicc.domain.channel.dto;

import com.hellobike.aicc.domain.smsrecord.dto.SmsRecordCallBackDTO;
import lombok.Data;


/**
 * @author ymh
 */
@Data
public class ChannelSmsPushDTO {

    /**
     * 短信回调内容
     */
    private SmsRecordCallBackDTO smsRecordCallBackDTO;

    /**
     * 渠道id
     */
    private Integer channelId;


}
