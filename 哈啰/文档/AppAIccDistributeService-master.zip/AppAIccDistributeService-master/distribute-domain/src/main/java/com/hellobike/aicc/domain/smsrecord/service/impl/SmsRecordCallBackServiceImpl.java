package com.hellobike.aicc.domain.smsrecord.service.impl;

import com.hellobike.aicc.common.enums.RosterTypeEnum;
import com.hellobike.aicc.common.enums.SmsSendResultEnum;
import com.hellobike.aicc.common.enums.YesOrNoEnum;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.exception.BusinessException;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.common.util.RedisKeyUtils;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.roster.dto.RosterUpdDTO;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.repo.PlanRosterRepository;
import com.hellobike.aicc.domain.roster.service.RosterMsgService;
import com.hellobike.aicc.domain.smsrecord.entity.SmsCheckEntity;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;
import com.hellobike.aicc.domain.smsrecord.entity.SupplierSmsRecordEntity;
import com.hellobike.aicc.domain.smsrecord.repo.SmsCheckRepository;
import com.hellobike.aicc.domain.smsrecord.repo.SmsRecordRepository;
import com.hellobike.aicc.domain.smsrecord.repo.SupplierSmsRecordRepository;
import com.hellobike.aicc.domain.smsrecord.service.SmsRecordCallBackService;
import com.hellobike.aicc.domain.smsrecord.service.SmsRecordMsgService;
import com.hellobike.base.redis.core.client.IRedisHelper;
import com.hellobike.base.redis.core.lock.RedisLock;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Objects;

@Service
@Slf4j
public class SmsRecordCallBackServiceImpl implements SmsRecordCallBackService {
    @Resource
    private SmsRecordMsgService smsRecordMsgService;

    @Resource
    private SmsRecordRepository smsRecordRepository;

    @Resource
    private SupplierSmsRecordRepository supplierSmsRecordRepository;

    @Resource
    private IRedisHelper redisHelper;

    @Resource
    private IdGeneratorService idGeneratorService;

    @Resource
    private PlanRosterRepository planRosterRepository;

    @Resource
    private RosterMsgService rosterMsgService;

    @Resource
    private DistPlanRepo distPlanRepo;

    @Resource
    private SmsCheckRepository smsCheckRepository;

    @Override
    public void handleSmsRecordCallBack(SmsRecordEntity smsRecord, Integer channelId) {
        RedisLock smsLock = redisHelper.createLock(RedisKeyUtils.cssSmsRecordLockKey(smsRecord.getChannelId() + "-" + smsRecord.getSupplierSmsGuid()));
        try {
            boolean isLock = smsLock.blockAcquireLock(5000, 5000);
            if (!isLock) {
                log.error("外呼短信未获取到锁，短信记录id:{}", smsRecord.getChannelId() + "-" + smsRecord.getSupplierSmsGuid());
                return;
            }

            //计算短信计费数
            smsRecord.paddingBillingNum();

            // 保存短信记录表和ES
            SmsRecordEntity dbSmsRecord = smsRecordRepository.getSmsRecordBySupplier(smsRecord.getSupplierSmsGuid(), smsRecord.getPhoneNumberMd5(), smsRecord.getChannelId());
            boolean saveSuccess;
            boolean isSave = false;
            if (dbSmsRecord == null) {
                saveSuccess = smsRecordRepository.save(smsRecord);
                isSave = true;
            } else {
                log.info("渠道记录重复回调,supplierSmsGuid:{}", smsRecord.getSupplierSmsGuid());
                smsRecord.setGuid(dbSmsRecord.getGuid());
                smsRecord.setCreateTime(dbSmsRecord.getCreateTime());
                smsRecord.setUpdateTime(LocalDateTime.now());
                smsRecord.setIsDelete(dbSmsRecord.getIsDelete());
                saveSuccess = smsRecordRepository.updateById(smsRecord);
            }

            if (saveSuccess) {
                // 保存原始短信记录
                SupplierSmsRecordEntity supplierSmsRecord = new SupplierSmsRecordEntity();
                supplierSmsRecord.setGuid(idGeneratorService.getLongId());
                supplierSmsRecord.setSmsId(smsRecord.getGuid());
                supplierSmsRecord.setDistributePlanId(smsRecord.getDistributePlanId());
                supplierSmsRecord.setSupplierSmsJson(smsRecord.getSupplierSmsJson());
                supplierSmsRecordRepository.save(supplierSmsRecord);
            } else {
                log.error("短信回调保存数据库失败,渠道商id为：{}, 短信id为:{}", channelId, smsRecord.getSupplierSmsGuid());
                throw new BusinessException(BusinessErrorCode.SAVE_SMS_RECORD_ERROR);
            }

            //更新名单
            if (isSave) {
                //记录发送状态未知的短信
                if (Objects.equals(smsRecord.getSendResult(), SmsSendResultEnum.UNKNOWN.getCode())) {
                    log.info("新增短信，记录发送状态未知的短信,supplierSmsGuid:{}", smsRecord.getSupplierSmsGuid());
                    SmsCheckEntity smsCheckEntity = new SmsCheckEntity();
                    smsCheckEntity.setId(idGeneratorService.getLongId());
                    smsCheckEntity.setSmsId(smsRecord.getGuid());
                    smsCheckEntity.setPhoneNumberMd5(smsRecord.getPhoneNumberMd5());
                    smsCheckEntity.setDistributePlanId(smsRecord.getDistributePlanId());
                    smsCheckEntity.setReceiveResultTime(smsRecord.getReceiveResultTime());
                    smsCheckEntity.setHandleStatus(YesOrNoEnum.NO.getCode());
                    smsCheckEntity.setHandleSendResult(SmsSendResultEnum.UNKNOWN.getCode());
                    smsCheckRepository.save(smsCheckEntity);
                }
                log.info("新增短信，更新名单数据,supplierSmsGuid:{}", smsRecord.getSupplierSmsGuid());
                PlanRosterEntity planRosterEntity = new PlanRosterEntity();
                planRosterEntity.setId(smsRecord.getRosterId());
                planRosterEntity.setDistributePlanId(smsRecord.getDistributePlanId());
                if (Objects.equals(smsRecord.getRosterType(), RosterTypeEnum.MD5.getCode())) {
                    planRosterEntity.setPhoneNum(smsRecord.getPhoneNumberMd5());
                } else {
                    planRosterEntity.setPhoneNum(smsRecord.getPhoneNumber());
                }
                if (Objects.equals(smsRecord.getSendResult(), SmsSendResultEnum.SUCCESS.getCode())) {
                    planRosterEntity.setSmsSendSuccessCount(1);
                }
                planRosterEntity.setSmsSendCount(1);
                planRosterRepository.updateRosterByCallBack(planRosterEntity);
                //发送名单更新消息
                RosterUpdDTO rosterUpdDTO = new RosterUpdDTO();
                rosterUpdDTO.setId(String.valueOf(planRosterEntity.getId()));
                rosterUpdDTO.setPlanId(String.valueOf(smsRecord.getDistributePlanId()));
                rosterUpdDTO.setPhoneNum(planRosterEntity.getPhoneNum());
                DistributePlanEntity distributePlanEntity = distPlanRepo.queryDistributePlanById(planRosterEntity.getDistributePlanId());
                rosterUpdDTO.setPlanCreateTime(DateUtils.format(distributePlanEntity.getCreateTime()));
                rosterMsgService.sendUpdMsg(rosterUpdDTO);
            }

            // 推送短信记录
            smsRecordMsgService.sendMsg(smsRecord);
        } finally {
            smsLock.releaseLock();
        }
    }
}
