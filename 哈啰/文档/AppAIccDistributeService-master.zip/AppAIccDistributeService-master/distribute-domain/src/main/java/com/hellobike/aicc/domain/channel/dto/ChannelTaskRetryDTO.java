package com.hellobike.aicc.domain.channel.dto;

import com.hellobike.aicc.common.basic.LoginParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 类说明
 *
 * @author panlongqian
 * @since 2025-03-20
 */

@EqualsAndHashCode(callSuper = true)
@Data
public class ChannelTaskRetryDTO extends LoginParam {
    /**
     * 计划渠道任务表id
     */
    private String planChannelTaskId;
}
