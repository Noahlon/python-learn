package com.hellobike.aicc.domain.channel.processor.impl;

import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.domain.channel.dto.ChannelTaskCreateDTO;
import com.hellobike.aicc.domain.channel.entity.ChannelEntity;
import com.hellobike.aicc.domain.channel.entity.ChannelTaskEntity;
import com.hellobike.aicc.domain.channel.facade.AICallCenterChannelFacade;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.channel.processor.ChannelProcessor;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterDTO;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterResultDTO;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 外呼渠道处理器
 *
 * @author panlongqian
 * @since 2025-03-11
 */
@Service
public class AiCallCenterProcessor implements ChannelProcessor {

    @Resource
    private AICallCenterChannelFacade aiCallCenterChannelFacade;

    @Override
    public ChannelEntity queryChannelDetail(String tenantCode) {
        AssertUtils.notBlank(tenantCode, "查询模板列表租户code不能为空");

        ChannelEntity channelEntity = new ChannelEntity();
        channelEntity.setChannelId(ChannelFactory.getHelloAiCall().getChannelId());
        channelEntity.setChannelName(ChannelFactory.getHelloAiCall().getChannelName());

        List<ChannelEntity.ChannelTemplateEntity> channelTemplateEntityList = aiCallCenterChannelFacade.queryChannelTemplateList(tenantCode);
        AssertUtils.notNull(channelTemplateEntityList, "查询模板列表异常");
        channelEntity.setTemplateList(channelTemplateEntityList);
        return channelEntity;
    }

    @Override
    public ChannelTaskEntity createChannelTask(ChannelTaskCreateDTO channelTaskCreateDTO) {
        return aiCallCenterChannelFacade.createChannelTask(channelTaskCreateDTO);
    }

    @Override
    public ChannelImportRosterResultDTO importRoster(ChannelImportRosterDTO channelImportRosterDTO) {
        ChannelImportRosterResultDTO resultDTO = new ChannelImportRosterResultDTO(0,0,false);
        //按照名单类型分组上传
        Map<Integer, List<PlanRosterEntity>> rosterMap = channelImportRosterDTO.getRosterEntityList().stream().collect(Collectors.groupingBy(PlanRosterEntity::getRosterType));
        ChannelImportRosterDTO req = new ChannelImportRosterDTO();
        req.setDistributePlanId(channelImportRosterDTO.getDistributePlanId());
        req.setTenantCode(channelImportRosterDTO.getTenantCode());
        req.setSupplierTaskId(channelImportRosterDTO.getSupplierTaskId());
        int allFailFlag = 0;
        for (Map.Entry<Integer, List<PlanRosterEntity>> entry : rosterMap.entrySet()) {
            Integer rosterType = entry.getKey();
            List<PlanRosterEntity> value = entry.getValue();
            req.setRosterEntityList(value);
            req.setRosterType(rosterType);
            ChannelImportRosterResultDTO res = aiCallCenterChannelFacade.importRoster(req);
            resultDTO.setSuccessCount(resultDTO.getSuccessCount() + res.getSuccessCount());
            resultDTO.setFailCount(resultDTO.getFailCount() + res.getFailCount());
            if (res.isAllFail()){
                allFailFlag += 1;
            }
        }
        if (allFailFlag == rosterMap.size()){
            resultDTO.setAllFail(true);
        }
        return resultDTO;
    }
}
