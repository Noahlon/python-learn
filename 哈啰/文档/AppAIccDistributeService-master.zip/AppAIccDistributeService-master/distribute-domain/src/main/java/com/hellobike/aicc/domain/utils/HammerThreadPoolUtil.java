package com.hellobike.aicc.domain.utils;

import com.hellobike.base.hammer.concurrent.HamExecutorService;
import com.hellobike.base.hammer.concurrent.HamExecutors;
import com.hellobike.base.hammer.concurrent.HamThreadFactory;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 线程池
 */
@Slf4j
public class HammerThreadPoolUtil {
    public static final Integer CORE_SIZE = Runtime.getRuntime().availableProcessors();

    public static final Integer MAX_SIZE = 4 * CORE_SIZE;

     static class HammerThreadPool {
        private static final int KEEP_ALIVE_TIME = 120;

        /**
         * 渠道任务创建线程池
         */
        private final HamExecutorService channelTaskCreatePool;

        /**
         * 名单文件导入处理线程池
         */
        private final HamExecutorService nameListHandlerPool;

        /**
         * 名单下发处理线程池
         */
        private final HamExecutorService rosterDistributePool;

         /**
          * 名单下发渠道处理线程池
          */
         private final HamExecutorService rosterDistributeChannelPool;

         /**
          * 名单上传处理线程池
          */
         private final HamExecutorService rosterUploadPool;

         /**
          * 名单批量保存线程池
          */
         private final HamExecutorService rosterSavePool;

         /**
          * 名单撞库线程池
          */
         private final HamExecutorService rosterImpactPool;

         /**
          * 导出文件线程池
          */
         private final HamExecutorService exportPool;

         /**
          * 名单更新mq消息线程池
          */
         private final HamExecutorService rosterUpdPool;

        private HammerThreadPool() {
            channelTaskCreatePool = HamExecutors.newThreadPool(4, 8
                    , KEEP_ALIVE_TIME, TimeUnit.SECONDS, new LinkedBlockingQueue<>(1024),
                    new HamThreadFactory("channelTaskCreatePool"), new ThreadPoolExecutor.CallerRunsPolicy());

            nameListHandlerPool = HamExecutors.newThreadPool(8, 8
                    , KEEP_ALIVE_TIME, TimeUnit.SECONDS, new LinkedBlockingQueue<>(1024),
                    new HamThreadFactory("nameListHandlerPool"), new ThreadPoolExecutor.AbortPolicy());

            rosterDistributePool = HamExecutors.newThreadPool(8, 16
                    , KEEP_ALIVE_TIME, TimeUnit.SECONDS, new LinkedBlockingQueue<>(1024),
                    new HamThreadFactory("rosterDistributePool"), new ThreadPoolExecutor.CallerRunsPolicy());

            rosterSavePool = HamExecutors.newThreadPool(2 * HammerThreadPoolUtil.CORE_SIZE, 4 * HammerThreadPoolUtil.CORE_SIZE
                    , KEEP_ALIVE_TIME, TimeUnit.SECONDS, new LinkedBlockingQueue<>(1024),
                    new HamThreadFactory("rosterSavePool"), new ThreadPoolExecutor.CallerRunsPolicy());

            rosterUploadPool = HamExecutors.newThreadPool(8, 16
                    , KEEP_ALIVE_TIME, TimeUnit.SECONDS, new LinkedBlockingQueue<>(1024),
                    new HamThreadFactory("rosterUploadPool"), new ThreadPoolExecutor.CallerRunsPolicy());

            rosterDistributeChannelPool = HamExecutors.newThreadPool(8, 8
                    , KEEP_ALIVE_TIME, TimeUnit.SECONDS, new LinkedBlockingQueue<>(1024),
                    new HamThreadFactory("rosterDistributeChannelPool"), new ThreadPoolExecutor.CallerRunsPolicy());

            rosterImpactPool = HamExecutors.newThreadPool(2 * HammerThreadPoolUtil.CORE_SIZE, 4 * HammerThreadPoolUtil.CORE_SIZE
                    , KEEP_ALIVE_TIME, TimeUnit.SECONDS, new LinkedBlockingQueue<>(1024),
                    new HamThreadFactory("rosterImpactPool"), new ThreadPoolExecutor.CallerRunsPolicy());
            exportPool = HamExecutors.newThreadPool(4, 8
                    , KEEP_ALIVE_TIME, TimeUnit.SECONDS, new LinkedBlockingQueue<>(1024),
                    new HamThreadFactory("exportPool"), new ThreadPoolExecutor.CallerRunsPolicy());
            rosterUpdPool = HamExecutors.newThreadPool(4, 8
                    , KEEP_ALIVE_TIME, TimeUnit.SECONDS, new LinkedBlockingQueue<>(1024),
                    new HamThreadFactory("rosterUpdPool"), new ThreadPoolExecutor.CallerRunsPolicy());
        }

        public static HammerThreadPool getInstance() {
            return ThreadPoolManagerHolder.instance;
        }

        private static class ThreadPoolManagerHolder {
            public static HammerThreadPool instance = new HammerThreadPool();
        }

        public void submitChannelTaskCreateTask(Runnable task) {
            try {
                channelTaskCreatePool.submit(task);
            } catch (Exception e) {
                log.error("提交渠道任务创建失败", e);
            }
        }

        public boolean submitNameListHandlerTask(Runnable task) {
            try {
                nameListHandlerPool.submit(task);
                return true;
            } catch (Exception e) {
                log.error("提交名单处理任务失败", e);
                return false;
            }
        }

        public boolean submitRosterDistributeTask(Runnable task) {
            try {
                rosterDistributePool.submit(task);
                return true;
            } catch (Exception e) {
                log.error("提交名单下发任务失败", e);
                return false;
            }
        }
    }

    public static void submitChannelTaskCreateTask(Runnable task) {
        HammerThreadPool.getInstance().submitChannelTaskCreateTask(task);
    }

    public static boolean submitNameListHandlerTask(Runnable task) {
        return HammerThreadPool.getInstance().submitNameListHandlerTask(task);
    }

    public static boolean submitRosterDistributeTask(Runnable task) {
        return HammerThreadPool.getInstance().submitRosterDistributeTask(task);
    }

    public static HamExecutorService getRosterDistributeExecutor() {
        return HammerThreadPool.getInstance().rosterDistributePool;
    }

    public static HamExecutorService getRosterDistributeChannelExecutor() {
        return HammerThreadPool.getInstance().rosterDistributeChannelPool;
    }

    public static HamExecutorService getRosterUploadExecutor() {
        return HammerThreadPool.getInstance().rosterUploadPool;
    }

    public static HamExecutorService getRosterSaveExecutor() {
        return HammerThreadPool.getInstance().rosterSavePool;
    }

    public static HamExecutorService getRosterImpactExecutor() {
        return HammerThreadPool.getInstance().rosterImpactPool;
    }

    public static HamExecutorService getExportExecutor() {
        return HammerThreadPool.getInstance().exportPool;
    }

    public static HamExecutorService getRosterUpdExecutor() {
        return HammerThreadPool.getInstance().rosterUpdPool;
    }
}
