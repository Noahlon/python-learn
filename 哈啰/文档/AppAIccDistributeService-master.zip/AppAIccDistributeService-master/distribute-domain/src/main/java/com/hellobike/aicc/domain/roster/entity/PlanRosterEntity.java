package com.hellobike.aicc.domain.roster.entity;

import com.hellobike.aicc.common.enums.RosterDistributeStatusEnum;
import com.hellobike.aicc.common.util.DBPartitionUtils;
import lombok.Data;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-03-07  16:53:34
 */
@Data
@Accessors(chain = true)
@Slf4j
public class PlanRosterEntity {

    private Long id;

    /**
     * 手机号
     */
    private String phoneNum;

    /**
     * 客户数据唯一标识
     */
    private String externalId;

    /**
     * 平台数据唯一标识
     */
    private String platformId;

    /**
     * 客户姓名
     */
    private String customerName;

    /**
     * 变量信息
     */
    private String variableInfo;

    /**
     * 分流计划id
     */
    private Long distributePlanId;

    /**
     * 上传记录id
     */
    private Long uploadRecordId;

    /**
     * 下发记录id
     */
    private Long distributeRecordId;

    /**
     * 下发状态
     * @see RosterDistributeStatusEnum
     */
    private Integer distributeStatus;

    /**
     * 渠道id
     */
    private Integer channelId;

    /**
     * 渠道名称
     */
    private String channelName;

    /**
     * 手机号md5
     */
    private String md5;

    /**
     * 渠道任务id
     */
    private Long channelTaskId;

    /**
     * 三方任务id
     */
    private String supplierTaskId;

    /**
     * 三方任务名称
     */
    private String supplierTaskName;

    /**
     * 话单数量
     */
    private Integer callDialogueNum;

    /**
     * 接通话单数
     */
    private Integer throughCallDialogueNum;

    /**
     * 上传时间
     */
    private LocalDateTime uploadTime;

    /**
     * 下发时间
     */
    private LocalDateTime distributeTime;

    /**
     * 最近呼叫时间
     */
    private LocalDateTime lastCallTime;

    /**
     * 最近接通时间
     */
    private LocalDateTime lastThroughTime;

    /**
     * 扩展字段
     */
    private String extInfo;

    /**
     * 分表键（分流计划id+手机号最后一位）
     */
    private String partitionCode;

    /**
     * 名单类型 默认为1，明文导入
     * @see com.hellobike.aicc.common.enums.RosterTypeEnum
     */
    private Integer rosterType = 1;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 最近更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 逻辑删除
     */
    private Integer isDelete;

    /**
     * 命中规则
     */
    private String hitRule;

    /**
     * 是否命中规则 0-否 1-是
     */
    private Integer isHitRule;

    /**
     * 是否撞库 0-否 1-是
     */
    private Integer isImpact;

    /**
     * 不下发原因
     */
    private String notDistReason;

    /**
     * 最近外呼状态
     * @see com.hellobike.aicc.common.enums.CallResultEnum
     */
    private Integer lastCallResult;

    /**
     * 短信发送次数
     */
    private Integer smsSendCount;

    /**
     * 短信发送成功次数
     */
    private Integer smsSendSuccessCount;

    /**
     * 分流计划创建时间
     */
    private LocalDateTime planCreateTime;

    /**
     * 租户id
     */
    private String tenantId;

    public void fillRosterPartitionCode() {
        setPartitionCode(DBPartitionUtils.getRosterPartitionCode(distributePlanId, phoneNum));
    }

    public String getRosterKey() {
        return id+"-"+distributePlanId;
    }
}
