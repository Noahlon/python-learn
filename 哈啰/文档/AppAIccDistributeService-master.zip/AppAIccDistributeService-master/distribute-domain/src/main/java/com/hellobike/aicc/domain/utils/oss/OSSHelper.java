package com.hellobike.aicc.domain.utils.oss;


import com.hellobike.aicc.common.enums.BusinessTypeEnum;
import com.hellobike.aicc.domain.common.dto.STSTicketDTO;

import java.io.File;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.util.Map;


public interface OSSHelper {


    /**
     * 上传文件到业务目录，并返回上传后的地址
     *
     * @param fileName     文件名
     * @param businessTypeEnum     业务模块
     * @param is           输入流
     * @param contentType  请求类型
     * @param expiredMin   过期时间
     * @return             oss地址
     */
    String uploadFileWithExpire(String fileName, BusinessTypeEnum businessTypeEnum , InputStream is, String contentType, Long expiredMin);

    /**
     * 上传文件到业务目录，并返回上传后的地址
     *
     * @param file             文件
     * @param businessTypeEnum 业务模块
     * @param expiredMin       过期时间
     * @return oss地址
     */
    String uploadFileToFileName(File file, BusinessTypeEnum businessTypeEnum, Long expiredMin);

    /**
     * 根据oss key下载
     *
     * @param ossKey        oss key 例子：knowledgeFlowImage/sqlCount/sqlStatisticsList.json
     * @param localFilePath 本地文件路径，将对应文件下载到本地
     */
    void downloadByOssKey(String ossKey, String localFilePath);


    /**
     * 根据oss key 直接获取文本内容，对应文件会直接删除
     *
     * @param fileName oss key 例子：sqlStatisticsList.json
     * @return oss url
     */
    String getTxtFromFileName(String fileName, BusinessTypeEnum businessTypeEnum);


    /**
     * 获取临时访问地址，设置下载文件名
     *
     * @param originUrl  原始文件路径
     * @param expiredMin 过期时间
     * @return 临时访问地址
     */
    String generateSTSUrl(String originUrl, Long expiredMin);

    /**
     * 获取临时访问地址，设置下载文件名
     *
     * @param originUrl    原始文件路径
     * @return             临时访问地址
     */
    String generateSTSUrl(String originUrl);

    /**
     * 资源访问授权
     *
     * @param originUrl        原始资源地址，必传
     * @param endPoint         指定内网地址，可空
     * @param publicEndPoint   指定公网地址，可空
     * @param expiredMin       过期时间，单位分钟，可空
     * @param queryParam       oss的拼接参数
     * @param filename         下载后的文件名
     * @return                 授权后的链接
     */
    String generateSTSUrl(String originUrl, String endPoint, String publicEndPoint, Long expiredMin, Map<String, String> queryParam, String filename);

    /**
     * 计算资源过期时间
     *
     * @param url oss链接
     * @return    过期时长，单位秒
     */
    long getResourceExpirationTime(String url) throws URISyntaxException;

    /**
     * 生成临时访问凭证
     *
     * @param expireSeconds 过期时间，单位秒
     * @return 临时访问凭证
     */
    STSTicketDTO generateStsTicket(int expireSeconds);
}
