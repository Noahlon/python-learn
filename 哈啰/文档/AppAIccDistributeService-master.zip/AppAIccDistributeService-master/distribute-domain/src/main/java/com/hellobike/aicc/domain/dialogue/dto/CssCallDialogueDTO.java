package com.hellobike.aicc.domain.dialogue.dto;

import com.hellobike.aicc.common.enums.CssCallDetailResEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-14  13:47:02
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CssCallDialogueDTO extends BaseDialogueCallBackDTO{

    /**
     * 话单guid
     */
    private String guid;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 主叫号
     */
    private String callingNumber;
    /**
     * 真实主叫号
     */
    private String realCallingNumber;
    /**
     * 被叫号
     */
    private String calledNumber;
    /**
     * 租户
     */
    private String tenant;
    /**
     * 租户描述
     */
    private String tenantDesc;
    /**
     * 业务场景
     */
    private String bizScene;
    /**
     * 业务场景
     */
    private String bizReqId;
    /**
     * 录音文件地址
     */
    private String recordFile;

    /**
     * 线路guid
     */
    private String lineGuid;

    /**
     * 挂断方，0：未知；1：机器人；2：客户
     */
    private Integer releaseInitiator;
    /**
     * 呼叫类型，2：呼出
     */
    private Integer contactType;

    /**
     * 项目任务类型
     * @see com.hellobike.aicc.common.enums.HumanTaskTypeEnum
     */
    private Integer projectTaskType;

    /**
     * 运营商
     */
    private String carrier;

    /**
     * 对话轮数
     */
    private Integer speechCount;

    /**
     * 挂断时间
     */
    private LocalDateTime hangupTime;
    /**
     * 接听时间
     */
    private LocalDateTime answerTime;
    /**
     * 拨号时间
     */
    private LocalDateTime dialTime;
    /**
     * 响铃时长（秒）
     */
    private Long durationRing;
    /**
     * 通话时长（秒）
     */
    private Long durationCall;
    /**
     * 外呼结果
     * {@link CssCallDetailResEnum}
     */
    private Integer calloutResult;
    /**
     * 外呼结果描述
     */
    private String calloutResultDesc;
    /**
     * 任务guid
     */
    private String taskGuid;
    /**
     * 意向分类
     */
    private String intentClassify;

    /**
     * 命中意图
     */
    private String recognizedIntent;

    /**
     * 意向分类名称
     */
    private String intentClassifyName;

    /**
     * 意向标签集合
     */
    private List<String> intentionLabels;

    /**
     * 当前手机号当日呼叫次数
     */
    private Integer callCount;

    /**
     * 是否为通话结束第一次产生的话单
     */
    private Boolean isFirstCreated;

    /**
     * 被叫号归属城市
     */
    private String city;

    /**
     * 被叫号归属省
     */
    private String province;

    /**
     * 给外部的外呼结果
     * {@link com.hellobike.css.ai.common.enums.CallResultExternalEnum}
     */
    private Integer externalCallResult;

    /**
     * 给外部的外呼结果描述
     */
    private String externalCallResultDesc;

    /**
     * 是否触发短信
     */
    private Boolean isHitSms;

    /**
     * 是否座席转接成功
     */
    private Boolean transferSuccess;

    /**
     * 坐席guid
     */
    private String seatGuid;

    /**
     * 坐席名称
     */
    private String seatName;

    /**
     * 是否是坐席触发的电话
     */
    private Boolean seatTrigger;

    /**
     * AI段通时
     */
    private Long durationCallAi;

    /**
     * 人工段通时
     */
    private Long durationCallManual;

    /**
     * 等待时长
     */
    private Integer waitDuration;

    /**
     * 名单对应的外部id
     */
    private String externalId;

    /**
     * 名单对应的newId
     */
    private String userNewId;

    /**
     * 名单对应的guid
     */
    private String userGuid;

    /**
     * 是否呼损
     */
    private Boolean callLoss;

    /**
     * 呼损分类
     */
    private String callLossClass;

    /**
     * 项目guid
     */
    private String projectGuid;

    /**
     * md5加密手机号
     */
    private String md5Phone;

    /**
     * 说话次数
     */
    private Integer speakCount;
}
