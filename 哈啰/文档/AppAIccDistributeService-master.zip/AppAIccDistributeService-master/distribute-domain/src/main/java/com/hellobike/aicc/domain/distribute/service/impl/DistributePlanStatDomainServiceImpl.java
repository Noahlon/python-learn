package com.hellobike.aicc.domain.distribute.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.map.MapUtil;
import com.google.common.collect.Lists;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.component.ApolloConfigs;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.distribute.dto.DistributePlanStatQryConditionDTO;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanStatEntity;
import com.hellobike.aicc.domain.distribute.repo.DistChannelTaskRepo;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.distribute.repo.DistributePlanStatRepo;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanQueryCondition;
import com.hellobike.aicc.domain.distribute.service.DistributePlanStatDomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author zhangzhuoqi
 * @since 2025-05-27  15:04:22
 */
@Slf4j
@Service
public class DistributePlanStatDomainServiceImpl implements DistributePlanStatDomainService {

    @Resource
    private ApolloConfigs apolloConfigs;

    @Resource
    private DistPlanRepo distPlanRepo;

    @Resource
    private DistributePlanStatRepo distributePlanStatRepo;

    @Resource
    private IdGeneratorService idGeneratorService;

    @Resource
    private DistChannelTaskRepo distChannelTaskRepo;

    @Override
    public void stat() {
        //查询出{statDayRange}天内的分流计划
        LocalDateTime endTime = DateUtils.getCurrentDayEnd();
        LocalDateTime startTime = endTime.minusDays(apolloConfigs.getStatDayRange());
        DistributePlanQueryCondition planCondition = new DistributePlanQueryCondition();
        planCondition.setCreateStartTime(DateUtils.format(startTime));
        planCondition.setCreateEndTime(DateUtils.format(endTime));
        List<DistributePlanEntity> planList = distPlanRepo.queryByCondition(planCondition);
        if (CollectionUtil.isEmpty(planList)){
            return;
        }

        for (List<DistributePlanEntity> planEntityList : Lists.partition(planList, 500)) {
            distPlanRepo.statPlan(planEntityList);
        }


        List<Long> planIdList = planList.stream().map(DistributePlanEntity::getId).collect(Collectors.toList());

        log.info("开始统计计划,list:{}", planIdList);

        List<DistributeChannelTaskEntity> taskList = distChannelTaskRepo.queryTaskListByPlanIdList(planIdList);
        Map<Long, List<DistributeChannelTaskEntity>> taskMap = new HashMap<>();
        if (CollectionUtil.isNotEmpty(taskList)){
            taskMap = taskList.stream().collect(Collectors.groupingBy(DistributeChannelTaskEntity::getDistributePlanId));
        }
        Map<Long, List<DistributeChannelTaskEntity>> finalTaskMap = taskMap;

        //统计数据入库
        planList.forEach(it -> {
            DistributePlanStatEntity entity = new DistributePlanStatEntity();
            entity.setId(idGeneratorService.getLongId());
            entity.setDistributePlanId(it.getId());
            entity.setDistributePlanName(it.getDistributePlanName());
            entity.setTenantId(it.getTenantCode());
            entity.setTenantName(it.getTenantName());
            entity.setUploadDataNum(Objects.nonNull(it.getUploadDataNum()) ? it.getUploadDataNum().intValue() : 0);
            entity.setCallRosterNum(Objects.nonNull(it.getCallRosterNum()) ? it.getCallRosterNum().intValue() : 0);
            entity.setThroughCallDialogueNum(Objects.nonNull(it.getThroughCallDialogueNum()) ? it.getThroughCallDialogueNum().intValue() : 0);
            entity.setCostUnit(Objects.nonNull(it.getCostUnit()) ? it.getCostUnit().intValue() : 0);
            entity.setThroughRosterNum(Objects.nonNull(it.getThroughRosterNum()) ? it.getThroughRosterNum().intValue() : 0);
            entity.setSendSmsRosterNum(Objects.nonNull(it.getSendSmsSum()) ? it.getSendSmsSum().intValue() : 0);
            entity.setSmsSuccRosterNum(Objects.nonNull(it.getSmsSuccSum()) ? it.getSmsSuccSum().intValue() : 0);
            entity.setSmsUnit(Objects.nonNull(it.getSmsUnit()) ? it.getSmsUnit().intValue() : 0);
            entity.setIntentionStat(MapUtil.isNotEmpty(it.getIntentionStat()) ? BaseJsonUtils.writeValue(it.getIntentionStat()) : null);
            entity.setPlanCreateTime(it.getCreateTime());
            entity.setLastStatTime(LocalDateTime.now());
            entity.setCallDialogueNum(Objects.nonNull(it.getCallDialogueNum()) ? it.getCallDialogueNum().intValue() : 0);
            if (finalTaskMap.containsKey(it.getId())) {
                List<DistributeChannelTaskEntity> planTaskList = finalTaskMap.get(it.getId());
                //发送总数
                entity.setSentTotalNum(planTaskList.stream().map(DistributeChannelTaskEntity::getSentTotalNum).filter(Objects::nonNull).reduce(Long::sum).orElse(0L).intValue());
                // 发送成功数
                entity.setSentSuccessNum(planTaskList.stream().map(DistributeChannelTaskEntity::getSentSuccessNum).filter(Objects::nonNull).reduce(Long::sum).orElse(0L).intValue());
            } else {
                entity.setSentTotalNum(0);
                entity.setSentSuccessNum(0);
            }
            boolean success = distributePlanStatRepo.saveOrUpdate(entity);
            if (!success){
                log.error("统计入库失败,plan:{}", it.getId());
            }
        });

    }

    @Override
    public PageResult<DistributePlanStatEntity> pageStat(DistributePlanStatQryConditionDTO condition) {
        return distributePlanStatRepo.pageQry(condition);
    }

    @Override
    public List<DistributePlanStatEntity> queryByCondition(DistributePlanStatQryConditionDTO conditionDTO) {
        return distributePlanStatRepo.queryByCondition(conditionDTO);
    }
}
