package com.hellobike.aicc.domain.common.service;

public interface DownloadFileService {
    /**
     * 将文件下载到本地
     *
     * @param fileUrl  文件url
     * @param fileName 文件名称
     * @return 下载到本地到文件路径
     */
    String downloadFileToLocal(String fileUrl, String fileName);
}
