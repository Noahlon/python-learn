package com.hellobike.aicc.domain.smsrecord.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author zhengchenyang
 * @date 2025/4/23
 * @desc
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class DistPlanSmsStat extends SmsStatEntity{
    /**
     * 计划id
     */
    private String planId;
}
