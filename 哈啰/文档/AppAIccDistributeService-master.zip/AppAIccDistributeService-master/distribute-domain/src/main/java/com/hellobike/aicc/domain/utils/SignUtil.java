package com.hellobike.aicc.domain.utils;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.roster.dto.ExtPlanRosterDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author fanxiaodongwb230
 */
@Slf4j
public class SignUtil {

    private static final String MD5 = "MD5";

    public static void main(String[] args) {
        JSONObject map = new JSONObject();
        map.put("supplierTaskId", "169014");
        map.put("rosterType", 1);
        //map.put("rosterListJson","");
        map.put("rosterListJson","[{\"phone\":\"16000000001\",\"name\":\"2921\",\"rosterKey\":\"7315491229117120544-7315487584837369866\",\"variableInfos\":{\"姓名\":\"李四\",\"性别\":\"女\"}},{\"phone\":\"16000000000\",\"name\":\"30ki\",\"rosterKey\":\"7315491229117120545-7315487584837369866\",\"variableInfos\":{\"姓名\":\"张三\",\"性别\":\"男\"}},{\"phone\":\"16000000002\",\"name\":\"te3d\",\"rosterKey\":\"7315491229117120546-7315487584837369866\",\"variableInfos\":{\"姓名\":\"李四\",\"性别\":\"女\"}}]");
        String appKey = "caoweicode-GRwpOHxC";
        map.put("appKey", appKey);
        map.put("timestamp", 1747225991);
        map.put("channelCode", appKey);

        /*map.put("appKey","caoweicode-GRwpOHxC");
        map.put("timestamp",1747051153);
        map.put("channelCode","caoweicode-GRwpOHxC");*/



        //驰必准
        //System.out.println(signTopRequest(map, "f922e497b8e04971afc85de510cd8462"));
        System.out.println(signTopRequest1(map, "f922e497b8e04971afc85de510cd8462"));
        //System.out.println(signTopRequest(map, "801afd8e48764d6f9336cc8a7e277db3"));
    }

    public static String signTopRequest1(JSONObject params, String secret) {

        return getMd5Str(getStringToSign(params, secret));

    }

    public static String signTopRequest(Map<String, Object> params, String secret) {
        // 第一步：检查参数是否已经排序
        String[] keys = params.keySet().toArray(new String[0]);
        Arrays.sort(keys);
        // 第二步：把所有参数名和参数值串在一起
        StringBuilder query = new StringBuilder();
        query.append(secret);
        for (String key : keys) {
            if (StrUtil.isNotBlank(key)) {
                Object value = params.get(key);
                if (null != value) {
                    query.append(key.trim());
                    if (value instanceof List || value instanceof Map) {
                        query.append(JSON.toJSONString(value).trim());
                    } else {
                        query.append(value);
                    }
                }
            }
        }
        query.append(secret);
        String s1 = "f922e497b8e04971afc85de510cd8462appKeycaoweicode-GRwpOHxCchannelCodecaoweicode-GRwpOHxCrosterList[{\"phone\":\"15000000000\",\"name\":\"zwno\",\"rosterKey\":\"7315106848870236163-7315106805920563201\"}]rosterType1supplierTaskId168935timestamp1747049823f922e497b8e04971afc85de510cd8462";
        System.out.println(s1);
        System.out.println(query.toString());
        System.out.println(Objects.equals(s1,query.toString()));
        return getMd5Str(query.toString());
    }

    public static String getStringToSign(JSONObject params, String secret) {
        // 第一步：检查参数是否已经排序
        String[] keys = params.keySet().toArray(new String[0]);
        Arrays.sort(keys);
        // 第二步：把所有参数名和参数值串在一起
        StringBuilder query = new StringBuilder();
        query.append(secret);
        for (String key : keys) {
            if (StrUtil.isNotBlank(key)) {
                Object value = params.get(key);
                if (null != value) {
                    query.append(key.trim());
                    if (value instanceof List || value instanceof Map) {
                        query.append(BaseJsonUtils.writeValue(value));
                    } else {
                        query.append(String.valueOf(value).trim());
                    }
                }
            }
        }
        query.append(secret);
        System.out.println(query.toString());
        String s = "f922e497b8e04971afc85de510cd8462appKeycaoweicode-GRwpOHxCchannelCodecaoweicode-GRwpOHxCrosterList[{\"phone\":\"15000000000\",\"name\":\"zwno\",\"rosterKey\":\"7315106848870236163-7315106805920563201\"}]rosterType1supplierTaskId168935timestamp1747049823f922e497b8e04971afc85de510cd8462";
        System.out.println(s);
        System.out.println(query.toString().equals(s));
        return query.toString();
    }

    public static String signTopRequest(JSONObject params, String secret) {
        return getMd5Str(getStringToSign(params, secret));
    }

    /**
     * 获取md5 byte数组
     */
    private static byte[] getMd5(String str) {
        MessageDigest messageDigest;
        try {
            messageDigest = MessageDigest.getInstance(MD5);
            messageDigest.reset();
            messageDigest.update(str.getBytes(StandardCharsets.UTF_8));
        } catch (NoSuchAlgorithmException e) {
            log.error("NoSuchAlgorithmException caught!");
            return ArrayUtils.EMPTY_BYTE_ARRAY;
        }
        return messageDigest.digest();
    }

    /**
     * MD5 加密
     */
    public static String getMd5Str(String str) {
        return toHex(getMd5(str));
    }

    /**
     * 转小写16进制字符串
     * @param byteArray
     * @return
     */
    private static String toHex(byte[] byteArray) {
        if (null == byteArray) {
            return null;
        }
        StringBuilder md5Str = new StringBuilder();
        for (byte b: byteArray) {
            md5Str.append(String.format("%02x", b));
        }
        return md5Str.toString();
    }
}
