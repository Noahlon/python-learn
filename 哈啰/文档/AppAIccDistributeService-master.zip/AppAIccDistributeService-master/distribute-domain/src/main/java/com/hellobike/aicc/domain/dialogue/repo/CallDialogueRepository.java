package com.hellobike.aicc.domain.dialogue.repo;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.dialogue.dto.CallDialogueQueryConditionDTO;
import com.hellobike.aicc.domain.dialogue.dto.CallDialogueScrollQueryDTO;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-07  14:38:29
 */
public interface CallDialogueRepository {

    /**
     * 保存话单
     * calledNumber(被叫号)、dialogueGuid(三方通话唯一id)必传
     *
     * @param callDialogueEntity
     * @return true 保存成功，false 保存失败
     * @author zhangzhuoqi
     * @since 2025/3/12 11:09
     **/
    boolean save(CallDialogueEntity callDialogueEntity);

    /**
     * 通过id更新话单（需要传入分表键：手机号）
     *
     * @param callDialogueEntity
     * @return boolean
     * @author zhangzhuoqi
     * @since 2025/3/18 10:59
     **/
    boolean updateById(CallDialogueEntity callDialogueEntity);

    /**
     * 分页查询话单
     *
     * @param condition 查询条件
     * @param pageNum   页码
     * @param pageSize  页大小
     * @return PageResult<CallDialogueEntity>
     * @author zhangzhuoqi
     * @since 2025/3/12 13:26
     **/
    PageResult<CallDialogueEntity> pageCallDialogue(CallDialogueQueryConditionDTO condition, Integer pageNum, Integer pageSize);

    /**
     * 通过渠道商话单id查询唯一话单
     *
     * @param dialogueGuid 渠道商话单guid
     * @param calledNumber 被叫号
     * @param channelId 渠道id
     * @return CallDialogueEntity
     * @author zhangzhuoqi
     * @since 2025/3/18 11:06
     **/
    CallDialogueEntity getCallDialogueBySupplier(String dialogueGuid, String calledNumber, Integer channelId);

    /**
     * 查询话单详情
     *
     * @param id           话单id
     * @param calledNumber 被叫号
     * @return CallDialogueEntity
     * @author zhangzhuoqi
     * @since 2025/4/18 16:29
     **/
    CallDialogueEntity getDetail(Long id, String calledNumber);

    /**
     * 查询话单列表进行导出
     *
     * @author zhangzhuoqi
     * @since 2025/4/21 15:36
     * @param condition 查询条件
     * @return CallDialogueScrollQueryDTO
     **/
    CallDialogueScrollQueryDTO listDialogueForExport(CallDialogueQueryConditionDTO condition, String scrollId);

    /**
     * 查询话单数量
     *
     * @author zhangzhuoqi
     * @since 2025/4/21 18:46
     * @param condition
     * @return int
     **/
    long countCallDialogue(CallDialogueQueryConditionDTO condition);
}
