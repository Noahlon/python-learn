package com.hellobike.aicc.domain.smsrecord.service;

import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;

public interface SmsRecordMsgService {
    /**
     * 发送短信记录消息
     */
    void sendMsg(SmsRecordEntity smsRecordDTO);
}
