package com.hellobike.aicc.domain.dialogue.dto;

import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import lombok.Data;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-04-21  17:36:46
 */
@Data
public class CallDialogueScrollQueryDTO {

    private String scrollId;

    private List<CallDialogueEntity> dialogueList;
}
