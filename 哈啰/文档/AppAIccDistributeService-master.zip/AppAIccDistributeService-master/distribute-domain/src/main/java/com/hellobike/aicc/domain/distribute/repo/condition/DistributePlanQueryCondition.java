package com.hellobike.aicc.domain.distribute.repo.condition;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * 分流模板查询condition
 */
@Data
@Accessors(chain = true)
public class DistributePlanQueryCondition {
    /**
     * 分流计划id
     */
    private String planId;

    /**
     * 分流计划id集合
     */
    private List<Long> planIdList;

    /**
     * 分流计划名称
     */
    private String planName;

    /**
     * 租户code
     */
    private List<String> tenantCodeList;


    /**
     * 分配类型
     * DistributeTypeNum
     */
    private Integer distributeType;

    /**
     * 渠道商id
     */
    private Integer channelId;

    /**
     * 创建开始时间
     */
    private String createStartTime;

    /**
     * 创建结束时间
     */
    private String createEndTime;

    /**
     * pageSize 每页查询数
     */
    private Integer pageSize;

    /**
     * 页码 查询的页码，从1开始
     */
    private Integer pageNum;

    /**
     * 三方任务模版id
     */
    private String supplierTemplateId;

    /**
     * 三方任务模版名称
     */
    private String supplierTemplateName;

    /**
     * 计划模版id
     */
    private String planTemplateId;

    /**
     * 计划模版名称
     */
    private String planTemplateName;

    /**
     * 计划模版id集合
     */
    private List<Long> planTemplateIdList;
}
