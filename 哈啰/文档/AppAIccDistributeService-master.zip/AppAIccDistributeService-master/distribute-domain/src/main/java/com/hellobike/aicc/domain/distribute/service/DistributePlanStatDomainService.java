package com.hellobike.aicc.domain.distribute.service;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.distribute.dto.DistributePlanStatQryConditionDTO;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanStatEntity;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-05-27  15:04:09
 */
public interface DistributePlanStatDomainService {

    /**
     * 分流计划统计
     */
    void stat();

    PageResult<DistributePlanStatEntity> pageStat(DistributePlanStatQryConditionDTO condition);

    /**
     * 条件查询
     * @param conditionDTO
     * @return
     */
    List<DistributePlanStatEntity> queryByCondition(DistributePlanStatQryConditionDTO conditionDTO);
}
