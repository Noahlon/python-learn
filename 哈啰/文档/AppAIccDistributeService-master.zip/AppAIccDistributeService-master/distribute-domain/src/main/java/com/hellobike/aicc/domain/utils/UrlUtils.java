package com.hellobike.aicc.domain.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class UrlUtils {

    /**
     * 获取url中的资源相对路径
     * </p>
     * <a href="https://aiplatform-aigcvideo.oss-cn-hangzhou.aliyuncs.com/fat/biz/1706696638691.png?OSSAccessKeyId=LTAI5tSg79Y4x3uaafvft7wA&Expires=1709797272&Signature=LF7F%2FIr2cEwCeJDxsh8zmsmuFlY%3D"/> --> fat/biz/1706696638691.png
     * <a href="https://aiplatform-aigcvideo.oss-cn-hangzhou.aliyuncs.com/fat/biz/1706696638691.png"/> --> fat/biz/1706696638691.png
     * fat/biz/1706696638691.png --> fat/biz/1706696638691.png
     * null --> null
     *
     * @param url oss链接
     * @return    资源相对路径
     */
    public static String getObjectRelativePath(String url) {
        if (StringUtils.isBlank(url)) {
            return null;
        }

        try {
            URI uri = new URI(url);
            String path = uri.getPath();
            return StringUtils.startsWith(path, "/") ? StringUtils.substring(path, 1) : path;
        } catch (URISyntaxException e) {
            log.warn("解析url失败，url = {}", url, e);
            return null;
        }
    }

    /**
     * 判断链接是否有效
     *
     * @param url 链接
     * @return    true=有效
     */
    public static boolean isValidUrl(String url) {
        try {
            new URL(url);
            return true;
        } catch (MalformedURLException e) {
            return false;
        }
    }

    /**
     * 获取url中的查询参数，只查url中的参数
     *
     * @param url 链接
     * @return    参数
     */
    public static Map<String, String> parseQueryParams(String url)  {
        if (!isValidUrl(url)) {
            throw new RuntimeException("invalid url");
        }

        try {

            URI uri = new URI(url);
            String query = uri.getQuery();
            if (StringUtils.isBlank(query)) {
                return Collections.emptyMap();
            }

            Map<String, String> params = new HashMap<>();
            String[] pairs = StringUtils.split(query, "&");
            for (String pair : pairs) {
                String[] kv = StringUtils.split(pair, "=");
                params.put(kv[0], kv[1]);
            }
            return params;

        } catch (URISyntaxException e) {
            log.warn("获取url中查询参数失败, url = {}", url, e);
            return Collections.emptyMap();
        }
    }

    public static String convertHttp2Https(String link) {
        if (StringUtils.isBlank(link)) {
            throw new RuntimeException("invalid url");
        }
        try {
            URL url = new URL(link);
            if (StringUtils.equalsIgnoreCase(url.getProtocol(), "https")) {
                return url.toString();
            }
            return "https" + url.toString().substring(4);
        } catch (Exception e) {
            log.warn("解析url失败, url = {}", link, e);
            return null;
        }
    }
}
