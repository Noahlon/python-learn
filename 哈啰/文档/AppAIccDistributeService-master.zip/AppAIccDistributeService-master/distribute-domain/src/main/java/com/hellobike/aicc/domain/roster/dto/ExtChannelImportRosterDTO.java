package com.hellobike.aicc.domain.roster.dto;

import lombok.Data;

import java.util.List;

/**
 * @author fanxiaodongwb230
 * @since 2025-04-25  10:43:18
 */
@Data
public class ExtChannelImportRosterDTO {
    /**
     * 渠道商appKey，供外部渠道商使用
     */
    private String appKey;

    /**
     * 三方任务id
     */
    private String supplierTaskId;

    /**
     * 名单类型
     * @see com.hellobike.aicc.common.enums.RosterTypeEnum
     */
    private Integer rosterType;

    /**
     * 名单集合
     */
    private List<ExtPlanRosterDTO> rosterList;

    /**
     * 名单集合-json字符串（将名单集合转为json字符串，避免开放平台生序列号字段时生成签名有顺序问题）
     */
    private String rosterListJson;

}
