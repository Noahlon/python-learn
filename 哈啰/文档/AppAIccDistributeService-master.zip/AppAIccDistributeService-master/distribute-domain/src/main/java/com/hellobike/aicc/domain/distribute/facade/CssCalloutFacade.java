package com.hellobike.aicc.domain.distribute.facade;

import com.hellobike.aicc.domain.dialogue.entity.DialogueSpeakEntity;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-04-22  15:44:38
 */
public interface CssCalloutFacade {

    /**
     * 获取话单对话内容
     *
     * @author zhangzhuoqi
     * @since 2025/4/22 15:44
     * @param bizReqId 外呼业务请求id
     * @return List<DialogueSpeakEntity>
     **/
    List<DialogueSpeakEntity> querySpeakList(String bizReqId);
}
