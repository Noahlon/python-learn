package com.hellobike.aicc.domain.file.service.impl;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.file.dto.FileExportRecordConditionDTO;
import com.hellobike.aicc.domain.file.entity.FileExportRecordEntity;
import com.hellobike.aicc.domain.file.repo.FileExportRecordRepository;
import com.hellobike.aicc.domain.file.service.FileExportRecordDomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  10:17:06
 */
@Slf4j
@Service
public class FileExportRecordDomainServiceImpl implements FileExportRecordDomainService {

    @Resource
    private FileExportRecordRepository fileExportRecordRepository;

    @Override
    public void saveOrUpdate(FileExportRecordEntity entity) {
        fileExportRecordRepository.saveOrUpdate(entity);
    }

    @Override
    public PageResult<FileExportRecordEntity> pageRecord(FileExportRecordConditionDTO condition, Integer pageNum, Integer pageSize) {
        return fileExportRecordRepository.pageRecord(condition, pageNum, pageSize);
    }
}
