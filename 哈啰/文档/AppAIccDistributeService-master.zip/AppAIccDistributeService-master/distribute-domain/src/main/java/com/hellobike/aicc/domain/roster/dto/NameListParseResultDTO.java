package com.hellobike.aicc.domain.roster.dto;

import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import lombok.Data;

import java.util.List;

/**
 * 解析名单文件结果对象
 */
@Data
public class NameListParseResultDTO {
    /**
     * 失败条数(校验失败的数量)
     */
    private Integer failCount;
    /**
     * 名单集合
     */
    private List<PlanRosterEntity> rosterEntityList;

    public NameListParseResultDTO(Integer failCount, List<PlanRosterEntity> rosterEntityList) {
        this.failCount = failCount;
        this.rosterEntityList = rosterEntityList;
    }
}
