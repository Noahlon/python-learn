package com.hellobike.aicc.domain.smsrecord.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * @author zhengchenyang
 * @date 2025/4/23
 * @desc
 */
@Data
public class SmsStatEntity implements Serializable {
    /**
     * 名单发送总数
     */
    private Long sendSum;

    /**
     * 名单发送成功数
     */
    private Long succSum;

    /**
     * 计费数
     */
    private Long smsUnit;
}
