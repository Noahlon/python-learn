package com.hellobike.aicc.domain.common.service.impl;

import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.exception.BusinessException;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.common.dto.OSSAuthorizeDTO;
import com.hellobike.aicc.domain.common.dto.STSTicketDTO;
import com.hellobike.aicc.domain.common.service.OssTokenDomainService;
import com.hellobike.aicc.domain.utils.oss.OSSUtils;
import com.hellobike.base.redis.core.client.IRedisHelper;
import com.hellobike.base.redis.core.model.key.Key;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * 类说明
 *
 * @author panlongqian
 * @since 2025-03-21
 */
@Service
public class OssTokenDomainServiceImpl implements OssTokenDomainService {
    private static final String OSS_STS_TOKEN_YEY = "distribute.oss.sts.token";

    @Resource
    private IRedisHelper redisHelper;

    @Resource
    private OSSUtils ossUtils;

    @Override
    public STSTicketDTO getOssTempToken() {
        STSTicketDTO ticket;

        // 1. 先取redis
        Key key = Key.convertByFormat(OSS_STS_TOKEN_YEY);
        Boolean exist = redisHelper.exists(key);
        if (exist != null && exist) {
            String value = redisHelper.get(key);
            ticket = BaseJsonUtils.readValue(value, STSTicketDTO.class);
            if (ticket != null) {
                return ticket;
            }
        }

        // 2. 没数据，去申请
        int expireSeconds = 3600;
        ticket = ossUtils.generateStsTicket(expireSeconds);
        if (ticket == null) {
            throw new BusinessException(BusinessErrorCode.OSS_STS_TOKEN_ERROR);
        }

        redisHelper.set(key, BaseJsonUtils.writeValue(ticket), expireSeconds - 5);
        return ticket;
    }

    @Override
    public OSSAuthorizeDTO resourceAuthorize(String ossUrl) {
        OSSAuthorizeDTO authorize = new OSSAuthorizeDTO();
        // 120分钟过期的授权地址
        String url = ossUtils.generateSTSUrl(ossUrl, 120L);
        authorize.setAuthorizedUrl(url);
        authorize.setExpired(System.currentTimeMillis() + 120 * 60 * 1000);
        return authorize;
    }
}
