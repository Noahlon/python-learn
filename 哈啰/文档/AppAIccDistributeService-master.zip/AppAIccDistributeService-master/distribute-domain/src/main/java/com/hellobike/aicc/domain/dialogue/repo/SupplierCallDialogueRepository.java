package com.hellobike.aicc.domain.dialogue.repo;

import com.hellobike.aicc.domain.dialogue.entity.SupplierCallDialogueEntity;

/**
 * @author zhangzhuoqi
 * @since 2025-04-22  13:38:55
 */
public interface SupplierCallDialogueRepository {

    void save(SupplierCallDialogueEntity supplierCallDialogueEntity);
}
