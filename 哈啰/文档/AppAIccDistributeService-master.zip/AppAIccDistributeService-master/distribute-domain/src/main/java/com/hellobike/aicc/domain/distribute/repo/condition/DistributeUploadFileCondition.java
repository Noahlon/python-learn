package com.hellobike.aicc.domain.distribute.repo.condition;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * <p>
 * 数据密级S2,分流上传文件查询条件
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-14
 */
@Data
@Accessors(chain = true)
public class DistributeUploadFileCondition {

    private String id;

    /**
     * 数据密级S2,文件名称
     */
    private String fileName;

    /**
     * 数据密级S2,分流计划id
     */
    private Long distributePlanId;

    private List<Integer> statusList;

    /**
     * pageSize 每页查询数
     */
    private Integer pageSize;

    /**
     * 页码 查询的页码，从1开始
     */
    private Integer pageNum;

}
