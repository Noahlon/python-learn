package com.hellobike.aicc.domain.distribute.service.impl;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.hellobike.aicc.common.component.ApolloConfigs;
import com.hellobike.aicc.common.enums.RosterDistributeStatusEnum;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributeRuleEntity;
import com.hellobike.aicc.domain.distribute.repo.DistChannelRepo;
import com.hellobike.aicc.domain.distribute.service.DistCalService;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import lombok.Data;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author zhengchenyang
 * @date 2025/3/18
 * @desc
 */
@Service
public class DistCalServiceImpl implements DistCalService {

    @Value("${roster.minimum.size:5}")
    private Integer minimum;

    @Resource
    private DistChannelRepo distChannelRepo;

    @Resource
    private ApolloConfigs apolloConfigs;

    @Override
    public void decide(DistributePlanEntity plan, List<DistributeChannelTaskEntity> tasks, List<PlanRosterEntity> rosters) {
        if (plan == null || CollectionUtils.isEmpty(rosters) || CollectionUtils.isEmpty(tasks)) {
            return;
        }
        //只对待下发待名单进行分流分配任务
        rosters = rosters.stream().filter(r -> Objects.equals(r.getDistributeStatus(), RosterDistributeStatusEnum.PENDING.getCode())).collect(Collectors.toList());
        List<DistributeRuleEntity> rules = plan.getDistributeRuleList();
        if (CollectionUtils.isEmpty(rules)) {
            rules = getDefaultRule();
        }
        Map<String, BigDecimal> ratioMap = rules.stream().filter(o -> !o.getPercentage().equals(BigDecimal.ZERO)).collect(Collectors.toMap(DistributeRuleEntity::generateKey, DistributeRuleEntity::getPercentage));
        Map<String, DistributeRuleEntity> ruleMap = rules.stream().filter(o -> !o.getPercentage().equals(BigDecimal.ZERO)).collect(Collectors.toMap(DistributeRuleEntity::generateKey, Function.identity(), (o1, o2) -> o1));
        Map<String, DistributeChannelTaskEntity> taskMap = tasks.stream().collect(Collectors.toMap(DistributeChannelTaskEntity::generateKey, Function.identity(), (o1, o2) -> o1));
        if (rosters.size() >= minimum) {
            localCal(ratioMap, ruleMap, taskMap, rosters);
        } else {
            distributeCal(plan.getId(), ratioMap, ruleMap, taskMap, rosters);
        }
    }

    /**
     * 分流决策
     */
    public void distributeCal(Long planId, Map<String, BigDecimal> ratioMap, Map<String, DistributeRuleEntity> ruleMap, Map<String, DistributeChannelTaskEntity> taskMap, List<PlanRosterEntity> rosters) {
        //统计总数
        Map<String, Long> countMap = distChannelRepo.queryTaskCounter(planId);
        long totalSize = countMap.values().stream().mapToLong(l -> l).sum();
        //计算当前各渠道任务比例
        Map<String, BigDecimal> currentRatioMap = calculateCurrentRatioMap(countMap, totalSize);

        // 动态调整权重并归一化
        Map<String, BigDecimal> weights = calculateNormalizedWeights(ratioMap, currentRatioMap);

        // 随机选择目标规则并分配
        assignRostersToTasks(planId, rosters, weights, ruleMap, taskMap);
    }

    /**
     * 异步分流决策
     */
    public void localCal(Map<String, BigDecimal> ratioMap, Map<String, DistributeRuleEntity> ruleMap, Map<String, DistributeChannelTaskEntity> taskMap, List<PlanRosterEntity> rosters) {
        // 打乱顺序
        Collections.shuffle(rosters);

        // 计算分割点
        int totalSize = rosters.size();
        List<SplitRule> splitRules = Lists.newArrayList();
        int cumulativeIndex = 0;
        for (Map.Entry<String, BigDecimal> entry : ratioMap.entrySet()) {
            BigDecimal splitPointDecimal = entry.getValue().multiply(BigDecimal.valueOf(totalSize))
                    .divide(BigDecimal.valueOf(100), RoundingMode.HALF_UP);
            int splitPoint = splitPointDecimal.intValue();

            cumulativeIndex += splitPoint;
            if (cumulativeIndex >= totalSize) {
                addSplitRule(splitRules, totalSize, entry.getKey());
                break;
            }
            addSplitRule(splitRules, cumulativeIndex, entry.getKey());
        }
        // 确保最后一个分割点等于总长度
        if (cumulativeIndex < totalSize) {
            String lastRuleKey = splitRules.get(splitRules.size() - 1).getRuleKey();
            addSplitRule(splitRules, totalSize, lastRuleKey);
        }

        // 分割列表
        int startIndex = 0;
        for (SplitRule splitPoint : splitRules) {
            int endIndex = splitPoint.getIndex();
            DistributeRuleEntity rule = ruleMap.get(splitPoint.getRuleKey());
            DistributeChannelTaskEntity task = taskMap.get(splitPoint.getRuleKey());
            rosters.subList(startIndex, endIndex).forEach(roster -> {
                roster.setChannelId(rule.getChannelId());
                roster.setChannelName(ChannelFactory.getNameById(rule.getChannelId()));
                roster.setChannelTaskId(Long.valueOf(rule.getPlanChannelTaskId()));
                roster.setSupplierTaskId(task.getSupplierTaskId());
                roster.setSupplierTaskName(task.getSupplierTaskName());
            });
            startIndex = endIndex;
        }
    }

    /**
     * 计算当前各渠道任务比例
     *
     * @param countMap
     * @param totalSize
     * @return
     */
    private Map<String, BigDecimal> calculateCurrentRatioMap(Map<String, Long> countMap, long totalSize) {
        return countMap.entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        entry -> {
                            if (totalSize == 0) {
                                return BigDecimal.ZERO; // 如果总数为零，比例为 0
                            }
                            BigDecimal value = BigDecimal.valueOf(entry.getValue());
                            return value.multiply(BigDecimal.valueOf(100))
                                    .divide(BigDecimal.valueOf(totalSize), 10, RoundingMode.HALF_UP);
                        }
                ));
    }

    /**
     * 计算并归一化权重
     */
    private Map<String, BigDecimal> calculateNormalizedWeights(Map<String, BigDecimal> ratioMap, Map<String, BigDecimal> currentRatioMap) {
        Map<String, BigDecimal> weights = new HashMap<>();
        BigDecimal totalWeight = BigDecimal.ZERO;

        // 动态调整权重
        for (String key : ratioMap.keySet()) {
            BigDecimal targetRatio = ratioMap.get(key);
            BigDecimal currentRatio = currentRatioMap.getOrDefault(key, BigDecimal.ZERO);
            // 确保权重非负
            BigDecimal weight = targetRatio.subtract(currentRatio).max(BigDecimal.ZERO);
            weights.put(key, weight);
            totalWeight = totalWeight.add(weight);
        }

        // 归一化权重
        if (totalWeight.compareTo(BigDecimal.ZERO) == 0) {
            // 如果所有权重都为零，均匀分配
            BigDecimal uniformWeight = BigDecimal.ONE.divide(BigDecimal.valueOf(weights.size()), 10, RoundingMode.HALF_UP);
            weights.replaceAll((k, v) -> uniformWeight);
        } else {
            BigDecimal finalTotalWeight = totalWeight;
            weights.replaceAll((k, v) -> v.divide(finalTotalWeight, 10, RoundingMode.HALF_UP));
        }

        return weights;
    }


    /**
     * 随机选择目标规则并分配
     */
    private void assignRostersToTasks(Long planId, List<PlanRosterEntity> rosters, Map<String, BigDecimal> weights,
                                      Map<String, DistributeRuleEntity> ruleMap, Map<String, DistributeChannelTaskEntity> taskMap) {
        // 生成随机数 [0, 1)
        BigDecimal rand = BigDecimal.valueOf(Math.random()).setScale(10, RoundingMode.HALF_UP);
        BigDecimal cumulativeProbability = BigDecimal.ZERO;

        // 随机选择目标规则
        String selectedRuleKey = null;
        for (String ruleKey : weights.keySet()) {
            cumulativeProbability = cumulativeProbability.add(weights.get(ruleKey));
            // 比较随机数与累积概率
            if (rand.compareTo(cumulativeProbability) < 0) {
                selectedRuleKey = ruleKey;
                break;
            }
        }

        // 如果未选中任何规则（理论上不会发生），可以选择第一个规则作为默认值
        if (selectedRuleKey == null) {
            selectedRuleKey = weights.keySet().iterator().next();
        }

        // 获取选中的规则和任务
        DistributeRuleEntity selectedRule = ruleMap.get(selectedRuleKey);
        DistributeChannelTaskEntity selectedTask = taskMap.get(selectedRuleKey);

        // 分配到对应的渠道任务
        rosters.forEach(roster -> {
            roster.setChannelId(selectedRule.getChannelId());
            roster.setChannelName(ChannelFactory.getNameById(selectedRule.getChannelId()));
            roster.setChannelTaskId(Long.valueOf(selectedRule.getPlanChannelTaskId()));
            roster.setSupplierTaskId(selectedTask.getSupplierTaskId());
            roster.setSupplierTaskName(selectedTask.getSupplierTaskName());
        });

        // 更新任务计数器
        distChannelRepo.incrTaskCounter(planId, selectedRule.generateKey(), rosters.size());
    }

    private void addSplitRule(List<SplitRule> splitRules, int index, String ruleKey) {
        splitRules.add(new SplitRule(index, ruleKey));
    }

    private List<DistributeRuleEntity> getDefaultRule() {
        String ruleStr = apolloConfigs.getDefaultDistRule();
        if (StringUtils.isBlank(ruleStr)) {
            return new ArrayList<>();
        }
        return JSON.parseArray(ruleStr, DistributeRuleEntity.class);
    }

    @Data
    public static class SplitRule {
        private int index;
        private String ruleKey;

        public SplitRule() {
        }

        public SplitRule(int index, String ruleKey) {
            this.index = index;
            this.ruleKey = ruleKey;
        }
    }
}
