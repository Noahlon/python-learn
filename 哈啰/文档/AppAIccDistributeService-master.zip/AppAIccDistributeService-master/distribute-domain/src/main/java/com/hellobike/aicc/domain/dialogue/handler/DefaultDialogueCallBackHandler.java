package com.hellobike.aicc.domain.dialogue.handler;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.csp.sentinel.util.StringUtil;
import com.hellobike.aicc.common.enums.*;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.dialogue.dto.DialogueCallBackDTO;
import com.hellobike.aicc.domain.dialogue.dto.DialogueSpeakDTO;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import com.hellobike.aicc.domain.dialogue.entity.DialogueSpeakEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-04-19  09:56:59
 */
@Slf4j
@Service
public class DefaultDialogueCallBackHandler extends AbstractCallDialogueCallBackHandler<DialogueCallBackDTO> {

    @Resource
    private IdGeneratorService idGeneratorService;
    @Override
    public CallDialogueEntity buildCallDialogueEntity(DialogueCallBackDTO callBackDTO) {
        //获取名单
        String rosterKey = callBackDTO.getRosterKey();
        if (StrUtil.isBlank(rosterKey)) {
            log.error("外呼话单中rosterKey为空");
            return null;
        }
        String rosterIdStr = rosterKey.split("-")[0];
        String distPlanIdStr = rosterKey.split("-")[1];
        if (!NumberUtil.isLong(rosterIdStr) || !NumberUtil.isLong(distPlanIdStr)) {
            log.error("外呼话单中id格式错误,rosterId:{},uploadIdStr:{}", rosterIdStr, distPlanIdStr);
            return null;
        }
        Long rosterId = Long.valueOf(rosterIdStr);
        Long distPlanId = Long.valueOf(distPlanIdStr);

        PlanRosterEntity rosterEntity = super.getRoster(rosterId, distPlanId, callBackDTO.getCalledNumber());
        if (Objects.isNull(rosterEntity)) {
            //如果向外呼上传名单是md5字段，话单回调中被叫号是明文字段
            if (StrUtil.isNotBlank(callBackDTO.getMd5())) {
                rosterEntity = super.getRoster(rosterId, distPlanId, callBackDTO.getMd5().toLowerCase());
            }
            if (Objects.isNull(rosterEntity)){
                log.error("外呼话单中名单为空,rosterId:{},distPlanId:{}", rosterId, distPlanId);
                return null;
            }
        }
        CallDialogueEntity entity = new CallDialogueEntity();
        entity.setId(idGeneratorService.getLongId());
        entity.setSpeakList(buildSpeakList(callBackDTO.getSpeakList()));
        entity.setEnterpriseId(callBackDTO.getEnterpriseId());
        entity.setCalledNumber(callBackDTO.getCalledNumber());
        entity.setRosterId(rosterId);
        entity.setRosterType(rosterEntity.getRosterType());

        entity.setCallResult(CallResultEnum.getEnumByCode(callBackDTO.getCallResult()).getCode());
        entity.setSupplierCallResult(callBackDTO.getSupplierCallResult());
        entity.setIntentClassify(callBackDTO.getIntentClassify());
        entity.setTags(callBackDTO.getTags());
        entity.setHitIntentions(callBackDTO.getHitIntentions());

        if(Objects.nonNull(callBackDTO.getIsHitSms())) {
            YesOrNoEnum yesOrNoEnum = YesOrNoEnum.getEnumByCode(callBackDTO.getIsHitSms());
            entity.setIsHitSms(Objects.nonNull(yesOrNoEnum) ? yesOrNoEnum.getCode() : null);
        }

        entity.setDurationCallAi(callBackDTO.getDurationCallAi());
        entity.setDurationCallManual(callBackDTO.getDurationCallManual());
        entity.setRealCallingNumber(callBackDTO.getRealCallingNumber());
        entity.setIntentClassifyName(callBackDTO.getIntentClassifyName());
        entity.setSeatName(callBackDTO.getSeatName());
        entity.setTotalTime(callBackDTO.getTotalTime());
        entity.setRingTime(callBackDTO.getRingTime());
        if(StringUtil.isNotEmpty(callBackDTO.getDialTime())) {
            entity.setDialTime(DateUtils.toMilliSecondLocalDateTime(callBackDTO.getDialTime()));
        }
        if(StringUtil.isNotEmpty(callBackDTO.getHangupTime())) {
            entity.setHangupTime(DateUtils.toMilliSecondLocalDateTime(callBackDTO.getHangupTime()));
        }
        entity.setCostUnit(callBackDTO.getCostUnit());

        if(Objects.nonNull(callBackDTO.getCallType())) {
            CallTypeEnum callTypeEnum = CallTypeEnum.getEnumByCode(callBackDTO.getCallType());
            entity.setCallType(Objects.nonNull(callTypeEnum) ? callTypeEnum.getCode() : null);
        }

        entity.setCallingNumber(callBackDTO.getCallingNumber());
        entity.setLineId(callBackDTO.getLineId());
        entity.setCity(callBackDTO.getCity());
        entity.setProvince(callBackDTO.getProvince());
        entity.setCarrier(CarrierTypeEnum.getEnumByCode(callBackDTO.getCarrier()).getCode());
        entity.setCustomName(rosterEntity.getCustomerName());
        entity.setDialogueGuid(callBackDTO.getDialogueGuid());
        entity.setReleaseInitiator(ReleaseInitiatorEnum.getEnumByCode(callBackDTO.getReleaseInitiator()).getCode());
        entity.setRecordUrl(callBackDTO.getRecordUrl());
        entity.setSpeechCount(callBackDTO.getSpeechCount());
        entity.setSpeakCount(callBackDTO.getSpeakCount());
        entity.setSex(SexEnum.getEnumByCode(callBackDTO.getSex()).getCode());
        entity.setSupplierTaskId(callBackDTO.getSupplierTaskId());
        entity.setSupplierTaskName(callBackDTO.getSupplierTaskName());
        if(StringUtil.isNotEmpty(callBackDTO.getAnswerTime())){
            entity.setAnswerTime(DateUtils.toMilliSecondLocalDateTime(callBackDTO.getAnswerTime()));
        }
        if (StringUtil.isNotEmpty(callBackDTO.getMd5())) {
            entity.setMd5(callBackDTO.getMd5().toLowerCase());
        }else {
            entity.setMd5(DigestUtils.md5DigestAsHex(callBackDTO.getCalledNumber().getBytes()));
        }
        entity.setExternalId(rosterEntity.getExternalId());
        entity.setPlatformId(rosterEntity.getPlatformId());
        entity.setChannelTaskId(rosterEntity.getChannelTaskId());

        DistributeChannelTaskEntity channelTask = super.getChannelTask(rosterEntity.getChannelTaskId());

        if (Objects.isNull(channelTask)) {
            log.error("外呼名单获取渠道任务为空,taskId:{}", rosterEntity.getChannelTaskId());
        } else {
            entity.setSupplierTaskTemplateId(channelTask.getSupplierTaskTemplateId());
            entity.setDistributePlanId(channelTask.getDistributePlanId());
            DistributePlanEntity planEntity = super.getDistributePlan(channelTask.getDistributePlanId());
            if (Objects.nonNull(planEntity)) {
                entity.setDistributePlanName(planEntity.getDistributePlanName());
                //租户id
                entity.setTenantId(planEntity.getTenantCode());
                entity.setTemplateId(planEntity.getTemplateId());
            }
        }
        return entity;
    }

    private List<DialogueSpeakEntity> buildSpeakList(List<DialogueSpeakDTO> speakList) {
        if (CollectionUtils.isEmpty(speakList)) {
            return null;
        }
        List<DialogueSpeakEntity> speakEntityList = new ArrayList<>();
        speakList.forEach(speakDTO -> {
            DialogueSpeakEntity dialogueSpeakEntity = new DialogueSpeakEntity();
            dialogueSpeakEntity.setSpeakId(speakDTO.getSpeakId());
            dialogueSpeakEntity.setSpeakContent(speakDTO.getSpeakContent());
            if(!StringUtils.isEmpty(speakDTO.getSpeakTime())) {
                dialogueSpeakEntity.setSpeakTime(DateUtils.toMilliSecondLocalDateTime(speakDTO.getSpeakTime()));
            }
            if(Objects.nonNull(speakDTO.getSpeaker())) {
                SpeakerEnum speakerEnum = SpeakerEnum.getByCode(speakDTO.getSpeaker());
                dialogueSpeakEntity.setSpeaker(Objects.nonNull(speakerEnum) ? speakerEnum.getCode() : null);
            }
            speakEntityList.add(dialogueSpeakEntity);
        });
        return speakEntityList;

    }
}
