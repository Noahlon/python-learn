package com.hellobike.aicc.domain.dialogue.handler;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.common.component.ApolloConfigs;
import com.hellobike.aicc.common.enums.CallResultEnum;
import com.hellobike.aicc.common.enums.CallTypeEnum;
import com.hellobike.aicc.common.enums.CarrierTypeEnum;
import com.hellobike.aicc.common.enums.HumanTaskTypeEnum;
import com.hellobike.aicc.common.enums.ReleaseInitiatorEnum;
import com.hellobike.aicc.common.enums.SexEnum;
import com.hellobike.aicc.common.enums.YesOrNoEnum;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.dialogue.dto.CallResultExternalDTO;
import com.hellobike.aicc.domain.dialogue.dto.CssCallDialogueDTO;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import com.hellobike.aicc.domain.dialogue.entity.DialogueSpeakEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.facade.CssCalloutFacade;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-03-14  14:08:11
 */
@Slf4j
@Service
public class CssDialogueCallBackHandler extends AbstractCallDialogueCallBackHandler<CssCallDialogueDTO> {

    @Resource
    private IdGeneratorService idGeneratorService;

    @Resource
    private ApolloConfigs apolloConfigs;

    @Resource
    private CssCalloutFacade cssCalloutFacade;

    @Override
    public CallDialogueEntity buildCallDialogueEntity(CssCallDialogueDTO cssCallDialogueDTO) {
        //获取名单
        String externalId = cssCallDialogueDTO.getExternalId();
        if (StrUtil.isBlank(externalId)) {
            log.error("外呼话单中externalId为空");
            return null;
        }
        String rosterIdStr = externalId.split("-")[0];
        String distPlanIdStr = externalId.split("-")[1];
        if (!NumberUtil.isLong(rosterIdStr) || !NumberUtil.isLong(distPlanIdStr)) {
            log.error("外呼话单中id格式错误,rosterId:{},uploadIdStr:{}", rosterIdStr, distPlanIdStr);
            return null;
        }
        Long rosterId = Long.valueOf(rosterIdStr);
        Long distPlanId = Long.valueOf(distPlanIdStr);

        PlanRosterEntity rosterEntity = super.getRoster(rosterId, distPlanId, cssCallDialogueDTO.getCalledNumber());
        if (Objects.isNull(rosterEntity)) {
            //如果向外呼上传名单是md5字段，话单回调中被叫号是明文字段
            if (StrUtil.isNotBlank(cssCallDialogueDTO.getMd5Phone())) {
                rosterEntity = super.getRoster(rosterId, distPlanId, cssCallDialogueDTO.getMd5Phone().toLowerCase());
            }
            if (Objects.isNull(rosterEntity)){
                log.error("外呼话单中名单为空,rosterId:{},distPlanId:{}", rosterId, distPlanId);
                return null;
            }
        }
        CallDialogueEntity entity = new CallDialogueEntity();
        entity.setId(idGeneratorService.getLongId());
        entity.setEnterpriseId(null);
        entity.setRosterId(rosterId);
        entity.setRosterType(rosterEntity.getRosterType());
        if (Objects.nonNull(cssCallDialogueDTO.getCalloutResult())) {
            entity.setSupplierCallResult(String.valueOf(cssCallDialogueDTO.getCalloutResult()));
            //映射本地的话单结果
            List<CallResultExternalDTO> callResultExternalList = BaseJsonUtils.readValues(apolloConfigs.getCssCallResultMapping(), CallResultExternalDTO.class);
            Integer externalStatus = callResultExternalList.stream().filter(e -> CollectionUtil.isNotEmpty(e.getCallResultStatusList())
                            && e.getCallResultStatusList().contains(cssCallDialogueDTO.getCalloutResult()))
                    .map(CallResultExternalDTO::getCallResultExternalStatus)
                    .findFirst().orElse(null);
            entity.setCallResult(externalStatus);
        }

        entity.setIntentClassify(cssCallDialogueDTO.getIntentClassify());
        if (CollectionUtil.isNotEmpty(cssCallDialogueDTO.getIntentionLabels())) {
            entity.setTags(cssCallDialogueDTO.getIntentionLabels());
        }
        entity.setSpeakCount(cssCallDialogueDTO.getSpeakCount());
        String recognizedIntent = cssCallDialogueDTO.getRecognizedIntent();
        if (StrUtil.isNotBlank(recognizedIntent)) {
            entity.setHitIntentions(BaseJsonUtils.readValues(recognizedIntent, String.class));
        }
        entity.setIsHitSms(Boolean.TRUE.equals(cssCallDialogueDTO.getIsHitSms()) ? YesOrNoEnum.YES.getCode() : YesOrNoEnum.NO.getCode());
        if (Objects.nonNull(cssCallDialogueDTO.getDurationCallAi())) {
            entity.setDurationCallAi(cssCallDialogueDTO.getDurationCallAi().intValue());
        }
        if (Objects.nonNull(cssCallDialogueDTO.getDurationCallManual())) {
            entity.setDurationCallManual(cssCallDialogueDTO.getDurationCallManual().intValue());
        }
        entity.setRealCallingNumber(cssCallDialogueDTO.getRealCallingNumber());
        entity.setIntentClassifyName(cssCallDialogueDTO.getIntentClassifyName());
        entity.setSeatName(cssCallDialogueDTO.getSeatName());
        if (Objects.nonNull(cssCallDialogueDTO.getDurationCall())) {
            entity.setTotalTime(cssCallDialogueDTO.getDurationCall().intValue());
            //计费单元数 = 通话时长 / 60，向上取整
            entity.setCostUnit((entity.getTotalTime() + 60 - 1) / 60);
        }
        if (Objects.nonNull(cssCallDialogueDTO.getDurationRing())) {
            entity.setRingTime(cssCallDialogueDTO.getDurationRing().intValue());
        }
        if (Objects.nonNull(cssCallDialogueDTO.getDialTime())) {
            entity.setDialTime(cssCallDialogueDTO.getDialTime());
        }
        if (Objects.nonNull(cssCallDialogueDTO.getHangupTime())) {
            entity.setHangupTime(cssCallDialogueDTO.getHangupTime());
        }
        if (HumanTaskTypeEnum.isHumanCall(cssCallDialogueDTO.getProjectTaskType())) {
            entity.setCallType(CallTypeEnum.HUMAN.getCode());
        } else {
            entity.setCallType(CallTypeEnum.AI.getCode());
        }
        entity.setCallingNumber(cssCallDialogueDTO.getCallingNumber());
        entity.setCustomName(rosterEntity.getCustomerName());
        entity.setDialogueGuid(cssCallDialogueDTO.getGuid());
        entity.setRecordUrl(cssCallDialogueDTO.getRecordFile());
        entity.setLineId(cssCallDialogueDTO.getLineGuid());
        entity.setCity(cssCallDialogueDTO.getCity());
        entity.setProvince(cssCallDialogueDTO.getProvince());
        if (StrUtil.isNotBlank(cssCallDialogueDTO.getCarrier())) {
            CarrierTypeEnum carrierEnum = CarrierTypeEnum.getEnumByDesc(cssCallDialogueDTO.getCarrier());
            entity.setCarrier(Objects.nonNull(carrierEnum) ? carrierEnum.getCode() : null);
        }
        entity.setSpeechCount(cssCallDialogueDTO.getSpeechCount());
        entity.setSex(SexEnum.UNKNOWN.getCode());
        entity.setReleaseInitiator(ReleaseInitiatorEnum.getEnumByCode(cssCallDialogueDTO.getReleaseInitiator()).getCode());
        entity.setExternalId(rosterEntity.getExternalId());
        entity.setPlatformId(rosterEntity.getPlatformId());
        entity.setCalledNumber(cssCallDialogueDTO.getCalledNumber());
        entity.setChannelTaskId(rosterEntity.getChannelTaskId());
        entity.setExtInfo(null);
        DistributeChannelTaskEntity channelTask = super.getChannelTask(rosterEntity.getChannelTaskId());
        if (Objects.isNull(channelTask)) {
            log.error("外呼名单获取渠道任务为空,taskId:{}", rosterEntity.getChannelTaskId());
        } else {
            entity.setSupplierTaskId(channelTask.getSupplierTaskId());
            entity.setSupplierTaskName(channelTask.getSupplierTaskName());
            entity.setSupplierTaskTemplateId(channelTask.getSupplierTaskTemplateId());
            entity.setDistributePlanId(channelTask.getDistributePlanId());
            DistributePlanEntity planEntity = super.getDistributePlan(channelTask.getDistributePlanId());
            if (Objects.nonNull(planEntity)) {
                entity.setDistributePlanName(planEntity.getDistributePlanName());
                //租户id
                entity.setTenantId(planEntity.getTenantCode());
                entity.setTemplateId(planEntity.getTemplateId());
            }
        }
        entity.setAnswerTime(cssCallDialogueDTO.getAnswerTime());
        if (StrUtil.isNotBlank(cssCallDialogueDTO.getMd5Phone())) {
            entity.setMd5(cssCallDialogueDTO.getMd5Phone().toLowerCase());
        }else {
            entity.setMd5(DigestUtils.md5DigestAsHex(cssCallDialogueDTO.getCalledNumber().getBytes()));
        }

        //企业id
        entity.setEnterpriseId(cssCallDialogueDTO.getTenant());
        //接通时查询对话信息
        if (Objects.equals(entity.getCallResult(), CallResultEnum.THROUGH.getCode())){
            List<DialogueSpeakEntity> speakList = cssCalloutFacade.querySpeakList(cssCallDialogueDTO.getBizReqId());
            if (CollectionUtil.isNotEmpty(speakList)){
                entity.setSpeakList(speakList);
            }
        }
        return entity;
    }

}
