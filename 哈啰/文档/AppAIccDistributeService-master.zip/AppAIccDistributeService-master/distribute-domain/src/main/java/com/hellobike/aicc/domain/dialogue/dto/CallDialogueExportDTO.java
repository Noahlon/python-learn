package com.hellobike.aicc.domain.dialogue.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.hellobike.aicc.common.enums.CallResultEnum;
import lombok.Data;

/**
 * @author zhangzhuoqi
 * @since 2025-04-21  15:49:11
 */
@Data
public class CallDialogueExportDTO {

    /**
     * 渠道商名称
     */
    @ExcelProperty("渠道商名称")
    private String channelName;

    /**
     * 客户数据标识
     */
    @ExcelProperty("客户数据标识")
    private String externalId;

    /**
     * 平台数据标识
     */
    @ExcelProperty("平台数据标识")
    private String platformId;

    /**
     * 小写md5
     */
    @ExcelProperty("MD5")
    private String md5;

    /**
     * 被叫号码
     */
    @ExcelProperty("被叫号码")
    private String calledNumber;

    /**
     * 分流计划名称
     */
    @ExcelProperty("分流计划名称")
    private String distributePlanName;

    /**
     * 分流计划ID
     */
    @ExcelProperty("分流计划ID")
    private String distributePlanId;

    /**
     * 任务ID
     */
    @ExcelProperty("任务ID")
    private String supplierTaskId;

    /**
     * 任务名称
     */
    @ExcelProperty("任务名称")
    private String supplierTaskName;

    /**
     * 话术模板ID
     */
    @ExcelProperty("话术模板ID")
    private String speechTemplateId;

    /**
     * 企业ID
     */
    @ExcelProperty("企业ID")
    private String enterpriseId;

    /**
     * 租户code
     */
    @ExcelProperty("租户code")
    private String tenantId;

    /**
     * 呼叫结果
     * @see CallResultEnum
     */
    @ExcelProperty("呼叫结果")
    private String callResultDesc;

    /**
     * 意向分类Code
     */
    @ExcelProperty("意向分类Code")
    private String intentClassify;

    /**
     * 意向分类名称
     */
    @ExcelProperty("意向分类名称")
    private String intentClassifyName;

    /**
     * 命中意图
     */
    @ExcelProperty("命中意图")
    private String hitIntentions;

    /**
     * 触发短信
     */
    @ExcelProperty("是否触发短信")
    private String isHitSms;

    /**
     * 坐席姓名
     */
    @ExcelProperty("坐席姓名")
    private String seatName;

    /**
     * AI通话时长
     */
    @ExcelProperty("AI通话时长")
    private Integer durationCallAi;

    /**
     * 人工通话时长
     */
    @ExcelProperty("人工通话时长")
    private Integer durationCallManual;

    /**
     * 中继外显号
     */
    @ExcelProperty("中继外显号")
    private String realCallingNumber;

    /**
     * 通话时长
     */
    @ExcelProperty("通话时长")
    private Integer totalTime;

    /**
     * 振铃时长
     */
    @ExcelProperty("振铃时长")
    private Integer ringTime;

    /**
     * 拨打时间
     */
    @ExcelProperty("拨打时间")
    private String dialTime;

    /**
     * 挂机时间
     */
    @ExcelProperty("挂机时间")
    private String hangupTime;

    /**
     * 通话类型
     * @see com.hellobike.aicc.common.enums.CallTypeEnum
     */
    @ExcelProperty("通话类型")
    private String callType;

    /**
     * 主叫号码
     */
    @ExcelProperty("主叫号码")
    private String callingNumber;

    /**
     * 计费单元数
     */
    @ExcelProperty("计费单元数")
    private Integer costUnit;

    /**
     * 客户姓名
     */
    @ExcelProperty("客户姓名")
    private String customName;

    /**
     * 渠道商通话唯一ID
     */
    @ExcelProperty("通话唯一ID")
    private String dialogueGuid;

    /**
     * 通话完整录音地址
     */
    @ExcelProperty("录音地址")
    private String recordUrl;

    /**
     * 线路ID
     */
    @ExcelProperty("线路ID")
    private String lineId;

    /**
     * 号码归属省份
     */
    @ExcelProperty("号码归属地")
    private String provinceCity;

    /**
     * 运营商
     * @see com.hellobike.aicc.common.enums.CarrierTypeEnum
     */
    @ExcelProperty("运营商")
    private String carrier;

    /**
     * 对话轮次
     */
    @ExcelProperty("对话轮次")
    private Integer speechCount;

    /**
     * 性别 (1男 2女 3未知)
     * @see com.hellobike.aicc.common.enums.SexEnum
     */
    @ExcelProperty("性别")
    private String sex;

    /**
     * 挂断方
     * @see com.hellobike.aicc.common.enums.ReleaseInitiatorEnum
     */
    @ExcelProperty("挂断方")
    private String releaseInitiator;

    @ExcelProperty("创建时间")
    private String createTime;


}
