package com.hellobike.aicc.domain.roster.entity;

import com.hellobike.aicc.common.enums.DistributeRecordTypeEnum;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-03-10  16:23:26
 */
@Data
public class DistributeRecordEntity {

    /**
     * 下发记录id
     */
    private Long id;

    /**
     * 下发状态 1未下发 2下发中 3下发完成
     * @see com.hellobike.aicc.common.enums.DistributeStatusEnum
     */
    private Integer distributeStatus;

    /**
     * 下发类型
     * @see DistributeRecordTypeEnum
     */
    private Integer distributeType;

    /**
     * 下发数量
     */
    private Integer distributeCount;

    /**
     * 成功数量
     */
    private Integer successCount;

    /**
     * 下发时间
     */
    private LocalDateTime distributeTime;

    /**
     * 渠道任务id
     */
    private Long channelTaskId;

    /**
     * 三方任务id
     */
    private String supplierTaskId;

    /**
     * 三方任务名称
     */
    private String supplierTaskName;

    /**
     * 分流计划id
     */
    private Long distributePlanId;

    /**
     * 渠道id
     */
    private Integer channelId;

    /**
     * 上传记录id
     */
    private Long uploadRecordId;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 最近更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 逻辑删除
     */
    private Integer isDelete;

}
