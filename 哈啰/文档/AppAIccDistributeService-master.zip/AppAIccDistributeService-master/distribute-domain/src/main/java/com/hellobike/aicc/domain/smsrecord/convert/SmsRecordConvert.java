package com.hellobike.aicc.domain.smsrecord.convert;

import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.smsrecord.dto.CssSmsRecordMsgDTO;
import com.hellobike.aicc.domain.smsrecord.dto.SmsRecordCallBackDTO;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(componentModel = "spring", imports = DateUtils.class)
public interface SmsRecordConvert {
    @Mappings({
            @Mapping(source = "id", target = "supplierSmsGuid"),
            @Mapping(source = "md5", target = "phoneNumberMd5"),
            @Mapping(source = "tenantId", target = "tenantCode"),
            @Mapping(source = "callGuid", target = "supplierCallGuid"),
            @Mapping(source = "taskGuid", target = "supplierTaskId"),
            @Mapping(source = "taskName", target = "supplierTaskName"),
            @Mapping(source = "externalId", target = "rosterKey"),
            @Mapping(target = "sendTime", expression = "java(DateUtils.toLocalDateTime(dto.getSendTime()))")
    })
    SmsRecordEntity convert(CssSmsRecordMsgDTO dto);

    @Mappings({
            @Mapping(target = "supplierSmsGuid", source = "smsId"),
            @Mapping(target = "supplierTaskId", source = "taskId"),
            @Mapping(target = "supplierTaskName", source = "taskName"),
            @Mapping(target = "supplierCallGuid", source = "dialogueGuid"),
            @Mapping(target = "phoneNumberMd5", source = "md5"),
            @Mapping(target = "sendTime", expression = "java(DateUtils.toLocalDateTime(dto.getSendTime()))"),
            @Mapping(target = "submitTime", expression = "java(DateUtils.toLocalDateTime(dto.getSubmitTime()))")
    })
    SmsRecordEntity convert(SmsRecordCallBackDTO dto);
}
