package com.hellobike.aicc.domain.channel.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * 分流渠道任务表
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class DistributeChannelTaskEntity {
    private Long id;

    /**
     * 分流计划id
     */
    private Long distributePlanId;

    /**
     * 渠道id
     */
    private String channelId;

    /**
     * 渠道名称
     */
    private String channelName;

    /**
     * 三方任务id
     */
    private String supplierTaskId;

    /**
     * 三方任务名称
     */
    private String supplierTaskName;

    /**
     * 三方任务模板id
     */
    private String supplierTaskTemplateId;

    /**
     * 三方任务模板名称
     */
    private String supplierTaskTemplateName;

    /**
     * 下发总数据量
     */
    private Long sentTotalNum;

    /**
     * 下发成功数据量
     */
    private Long sentSuccessNum;

    /**
     * 最近下发时间,下发任务时更新最近下发时间
     */
    private LocalDateTime latestSentTime;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 任务状态
     * PlanChannelTaskStatusEnum
     */
    private Integer taskStatus;

    /**
     * 话单量
     */
    private Long callDialogueNum;

    /**
     * 接通话单量
     */
    private Long throughCallDialogueNum;

    /**
     * 计费数
     */
    private Long costUnit;

    /**
     * 接通名单数
     */
    private Long throughRosterNum;

    /**
     * 发送短信名单数
     */
    private Long sendSmsSum;

    /**
     * 短信成功名单数
     */
    private Long smsSuccSum;

    /**
     * 短信计费数
     */
    private Long smsUnit;

    /**
     * 意向统计
     */
    private Map<String,Long> intentionStat;

    public String generateKey() {
        return channelId + "_" + supplierTaskTemplateId;
    }
}
