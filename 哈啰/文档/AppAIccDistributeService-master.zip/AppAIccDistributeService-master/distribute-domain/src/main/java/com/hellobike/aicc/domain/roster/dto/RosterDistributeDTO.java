package com.hellobike.aicc.domain.roster.dto;

import lombok.Data;

/**
 * @author zhangzhuoqi
 * @since 2025-03-18  15:37:13
 */
@Data
public class RosterDistributeDTO {
}
