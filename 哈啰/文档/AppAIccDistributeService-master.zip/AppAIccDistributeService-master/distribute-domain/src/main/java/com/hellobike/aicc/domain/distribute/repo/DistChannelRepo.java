package com.hellobike.aicc.domain.distribute.repo;

import java.util.Map;

/**
 * @author zhengchenyang
 * @since 2025-03-07  14:38:58
 */
public interface DistChannelRepo {
    /**
     * 查询分流计划的渠道任务计数信息
     *
     * @param distributePlanId
     * @return
     */
    Map<String, Long> queryTaskCounter(Long distributePlanId);

    /**
     * 更新分流计划的渠道任务计数信息
     *
     * @param distributePlanId
     * @param channelTaskKey
     * @param count
     */
    void incrTaskCounter(Long distributePlanId, String channelTaskKey, int count);

    void delTaskCounter(Long distributePlanId);
}
