package com.hellobike.aicc.domain.roster.service;

import com.hellobike.aicc.domain.distribute.entity.DistributeUploadFileEntity;
import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;

/**
 * 导入名单解析处理Service
 */
public interface NameListDomainService {

    /**
     * 处理导入名单
     **/
    void handlerImportNameList(DistributeUploadFileEntity entity, UploadRecordEntity uploadRecordEntity);
}
