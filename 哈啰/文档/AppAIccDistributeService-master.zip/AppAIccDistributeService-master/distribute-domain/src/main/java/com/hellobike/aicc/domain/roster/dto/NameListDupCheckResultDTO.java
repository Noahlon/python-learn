package com.hellobike.aicc.domain.roster.dto;

import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import lombok.Data;

import java.util.List;

/**
 * 名单数据库重复数据校验结果对象
 */
@Data
public class NameListDupCheckResultDTO {
    /**
     * 重复数量（与数据库有重复的数量，号码 + 数据标识 作为唯一表述）
     */
    private Integer duplicationCount;

    /**
     * 与数据库没有重复，需要入库的数据，号码 + 数据标识 作为唯一标识
     * insertEntityList的size即为导入成功的数量
     */
    private List<PlanRosterEntity> insertEntityList;

    public NameListDupCheckResultDTO(Integer duplicationCount, List<PlanRosterEntity> rosterEntityList) {
        this.duplicationCount = duplicationCount;
        this.insertEntityList = rosterEntityList;
    }
}
