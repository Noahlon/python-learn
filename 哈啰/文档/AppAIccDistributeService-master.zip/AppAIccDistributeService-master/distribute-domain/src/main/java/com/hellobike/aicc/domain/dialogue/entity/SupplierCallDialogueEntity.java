package com.hellobike.aicc.domain.dialogue.entity;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-04-22  13:39:27
 */
@Data
public class SupplierCallDialogueEntity {

    private Long id;

    /**
     * 数据密级S2,分流平台话单id
     */
    private Long callId;

    /**
     * 数据密级S2,分流计划id
     */
    private Long distributePlanId;

    /**
     * 数据密级S2,供应商话单数据
     */
    private String supplierCallJson;

    /**
     * 数据密级S2,创建时间
     */
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,是否删除
     */
    private Integer isDelete;
}
