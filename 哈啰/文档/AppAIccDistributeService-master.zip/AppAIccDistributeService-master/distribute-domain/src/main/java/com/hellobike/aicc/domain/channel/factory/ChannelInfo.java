package com.hellobike.aicc.domain.channel.factory;

import lombok.Data;

/**
 * @author zhangzhuoqi
 * @since 2025-04-19  09:13:31
 */
@Data
public class ChannelInfo {

    /**
     * 渠道id
     */
    private Integer channelId;

    /**
     * 渠道对应开发平台的appKey（如果是内部渠道，如外呼，则给定一个固定值，该字段不能为空）
     */
    private String appKey;

    /**
     * appKey对应的密钥
     */
    private String secret;

    /**
     * 渠道名称
     */
    private String channelName;

    /**
     * 渠道接口处理器类名
     */
    private String processorClassName;

    /**
     * 渠道话单回调处理类名
     */
    private String dialogueClassName;

    /**
     * 短信回调处理类名
     */
    private String smsClassName;

    /**
     * 是否标准对接渠道 false-定制化对接渠道 true-标准对接渠道
     */
    private Boolean isStandard;

    /**
     * 是否启用
     */
    private Boolean isEnable;

    /**
     * 上传名单数量限制
     */
    private Integer importRosterLimit;

    /**
     * 接口失败重试次数
     */
    private Integer retryCount;

}
