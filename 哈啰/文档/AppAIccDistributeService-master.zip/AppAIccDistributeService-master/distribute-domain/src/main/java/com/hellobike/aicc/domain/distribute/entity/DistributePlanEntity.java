package com.hellobike.aicc.domain.distribute.entity;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 数据密级S2,分流模板表
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Data
public class DistributePlanEntity {
    private Long id;

    /**
     * 分流计划名称
     */
    private String distributePlanName;

    /**
     * 分流计划模板id
     */
    private Long templateId;

    /**
     * 分流计划模板名称
     */
    private String templateName;

    /**
     * 租户id
     */
    private String tenantCode;

    /**
     * 租户名称
     */
    private String tenantName;

    /**
     * 分流类型，1-实时分流，2-离线分流
     */
    private Integer distributeType;

    /**
     * 分流类型描述
     */
    private String distributeTypeDesc;

    /**
     * 上传数据量
     */
    private Long uploadDataNum;

    /**
     * 分流规则
     */
    private List<DistributeRuleEntity> distributeRuleList;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 已呼名单数
     */
    private Long callRosterNum;

    /**
     * 接通话单量
     */
    private Long throughCallDialogueNum;

    /**
     * 话单量
     */
    private Long callDialogueNum;

    /**
     * 计费数
     */
    private Long costUnit;

    /**
     * 接通名单数
     */
    private Long throughRosterNum;

    /**
     * 短信发送数量
     */
    private Long sendSmsSum;

    /**
     * 短信成功数量
     */
    private Long smsSuccSum;

    /**
     * 短信计费数
     */
    private Long smsUnit;

    /**
     * 意向统计
     */
    private Map<String,Long> intentionStat;

}
