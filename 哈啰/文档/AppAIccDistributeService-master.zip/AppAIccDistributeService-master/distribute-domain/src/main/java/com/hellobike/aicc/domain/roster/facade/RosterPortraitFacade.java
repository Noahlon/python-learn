package com.hellobike.aicc.domain.roster.facade;

import com.hellobike.aicc.common.dto.DistPlanImpactRule;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;

import java.util.List;

/**
 *
 * 名单画像接口
 * @author zhangzhuoqi
 * @since 2025-04-11  10:33:22
 */
public interface RosterPortraitFacade {

    /**
     * 名单撞库，设置名单标签等信息
     *
     * @author zhangzhuoqi
     * @since 2025/4/11 10:34
     * @param ruleDTO 分流计划撞库规则
     * @param rosterList 名单集合
     * @return void
     **/
    void impact(DistPlanImpactRule ruleDTO, List<PlanRosterEntity> rosterList);
}
