package com.hellobike.aicc.domain.distribute.entity;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-05-27  15:00:59
 */
@Data
public class DistributePlanStatEntity {

    private Long id;

    /**
     * 数据密级S2,分流计划id
     */
    private Long distributePlanId;

    /**
     * 数据密级S2,分流计划名称
     */
    private String distributePlanName;

    /**
     * 数据密级S2,租户id
     */
    private String tenantId;

    /**
     * 数据密级S2,租户名称
     */
    private String tenantName;

    /**
     * 数据密级S2,上传数据量
     */
    private Integer uploadDataNum;

    /**
     * 数据密级S2,已呼名单数
     */
    private Integer callRosterNum;

    /**
     * 数据密级S2,接通话单量
     */
    private Integer throughCallDialogueNum;

    /**
     * 数据密级S2,话单计费数
     */
    private Integer costUnit;

    /**
     * 数据密级S2,接通名单数
     */
    private Integer throughRosterNum;

    /**
     * 数据密级S2,发送短信名单数
     */
    private Integer sendSmsRosterNum;

    /**
     * 数据密级S2,发送短信成功名单数
     */
    private Integer smsSuccRosterNum;

    /**
     * 数据密级S2,短信计费数
     */
    private Integer smsUnit;

    /**
     * 数据密级S2,意向统计
     */
    private String intentionStat;

    /**
     * 数据密级S2,分流计划创建时间
     */
    private LocalDateTime planCreateTime;

    /**
     * 数据密级S2,最近一次统计时间
     */
    private LocalDateTime lastStatTime;

    /**
     * 数据密级S2,话单量
     */
    private Integer callDialogueNum;

    /**
     * 数据密级S2,下发总数据量
     */
    private Integer sentTotalNum;

    /**
     * 数据密级S2,下发成功数据量
     */
    private Integer sentSuccessNum;

    /**
     * 数据密级S2,创建时间
     */
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,是否删除
     */
    private Integer isDelete;
}
