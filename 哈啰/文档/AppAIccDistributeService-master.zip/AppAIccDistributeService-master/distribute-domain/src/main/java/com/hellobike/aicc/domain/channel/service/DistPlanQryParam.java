package com.hellobike.aicc.domain.channel.service;


import lombok.Data;

/**
 * @author zhengchenyang
 * @date 2025/4/23
 * @desc
 */

@Data
public class DistPlanQryParam {
    /**
     * 租户id
     */
    private String tenantId;

    /**
     * 分流计划id
     */
    private String planId;

    /**
     * 分流计划名称
     */
    private String planName;

    /**
     * 页大小
     */
    private Integer pageSize;

    /**
     * 页码
     */
    private Integer pageNum;
}
