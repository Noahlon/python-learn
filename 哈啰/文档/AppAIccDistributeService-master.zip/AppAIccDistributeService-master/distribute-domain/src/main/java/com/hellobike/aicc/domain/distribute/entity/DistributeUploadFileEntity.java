package com.hellobike.aicc.domain.distribute.entity;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 分流上传文件实体
 */
@Data
public class DistributeUploadFileEntity {
    private Long id;

    /**
     * 数据密级S2,文件名称
     */
    private String fileName;

    /**
     * 数据密级S2,文件连接
     */
    private String fileUrl;

    /**
     * 数据密级S2,分流计划id
     */
    private Long distributePlanId;

    /**
     * 数据密级S2,成功条数
     */
    private Integer successCount;

    /**
     * 数据密级S2,失败条数
     */
    private Integer failedCount;

    /**
     * 数据密级S2,重复条数
     */
    private Integer duplicateCount;

    /**
     * 数据密级S2,操作类型
     */
    private Integer operationType;

    /**
     * 状态
     */
    private Integer status;

    /**
     * 数据密级S2,状态描述
     */
    private String statusDesc;

    /**
     * 失败原因
     */
    private String failedDesc;

    /**
     * 数据密级S2,创建人
     */
    private String creator;

    /**
     * 数据密级S1,创建时间
     */
    private LocalDateTime createTime;

    /**
     * 数据密级S2,失败信息url
     */
    private String failedUrl;

    /**
     * 上传记录id
     */
    private Long uploadRecordId;
}
