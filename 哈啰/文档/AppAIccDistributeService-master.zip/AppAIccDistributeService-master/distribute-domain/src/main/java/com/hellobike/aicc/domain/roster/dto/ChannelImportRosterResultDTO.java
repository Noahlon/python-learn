package com.hellobike.aicc.domain.roster.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author zhangzhuoqi
 * @since 2025-03-18  13:24:33
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChannelImportRosterResultDTO {

    /**
     * 上传名单成功数量
     */
    private Integer successCount;

    /**
     * 上传名单失败数量
     */
    private Integer failCount;

    /**
     * 是否全部失败
     */
    private boolean allFail;
}
