package com.hellobike.aicc.domain.channel.processor.impl;

import com.hellobike.aicc.domain.channel.dto.ChannelTaskCreateDTO;
import com.hellobike.aicc.domain.channel.entity.ChannelEntity;
import com.hellobike.aicc.domain.channel.entity.ChannelTaskEntity;
import com.hellobike.aicc.domain.channel.facade.OpenApiFacade;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.channel.factory.ChannelInfo;
import com.hellobike.aicc.domain.channel.processor.ChannelProcessor;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterDTO;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterResultDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-04-19  09:58:37
 */
@Slf4j
@Service
public class DefaultChannelProcessor implements ChannelProcessor {

    @Resource
    private OpenApiFacade openApiFacade;

    @Override
    public ChannelEntity queryChannelDetail(String appKey) {
        ChannelInfo channel = ChannelFactory.getChannel(appKey);
        if (Objects.isNull(channel)){
            return null;
        }
        ChannelEntity channelEntity = new ChannelEntity();
        channelEntity.setChannelId(channel.getChannelId());
        channelEntity.setChannelName(channel.getChannelName());

        List<ChannelEntity.ChannelTemplateEntity> templateList = openApiFacade.queryTemplateList(appKey);
        channelEntity.setTemplateList(templateList);
        return channelEntity;
    }

    @Override
    public ChannelTaskEntity createChannelTask(ChannelTaskCreateDTO channelTaskCreateDTO) {

        return openApiFacade.createTask(channelTaskCreateDTO);
    }

    @Override
    public ChannelImportRosterResultDTO importRoster(ChannelImportRosterDTO channelImportRosterDTO) {

        return openApiFacade.importRoster(channelImportRosterDTO);

    }
}
