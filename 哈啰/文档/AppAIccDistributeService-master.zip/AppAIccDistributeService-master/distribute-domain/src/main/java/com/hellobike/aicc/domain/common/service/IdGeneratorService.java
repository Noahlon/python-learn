package com.hellobike.aicc.domain.common.service;

public interface IdGeneratorService {
    Long getLongId();

    String getStringId();
}
