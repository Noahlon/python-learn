package com.hellobike.aicc.domain.roster.repo;

import com.hellobike.aicc.domain.roster.dto.BatchUpdRosterFieldDTO;
import com.hellobike.aicc.domain.roster.dto.RosterQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-07  14:36:58
 */
public interface PlanRosterRepository {


    /**
     * 话单/短信回调更新名单数据
     *
     * @param planRosterEntity entity
     * @return void
     * @author zhangzhuoqi
     * @since 2025/3/14 15:03
     **/
    void updateRosterByCallBack(PlanRosterEntity planRosterEntity);

    /**
     * 批量保存名单
     *
     * @param entityList
     * @return void
     * @author zhangzhuoqi
     * @since 2025/3/14 15:03
     **/
    void batchSave(List<PlanRosterEntity> entityList);

    /**
     * 通过id获取名单
     *
     * @param rosterId   名单id
     * @param distPlanId 分流计划id
     * @param phoneNum   手机号
     * @return PlanRosterEntity
     * @author zhangzhuoqi
     * @since 2025/3/17 15:53
     **/
    PlanRosterEntity getRosterById(Long rosterId, Long distPlanId, String phoneNum);

    /**
     * 对一批名单更新相同的字段且相同的值(更新字段和条件字段按需添加)
     * 名单集合实体中必须要传入分流计划ID和手机号（用来做分表键）和主键id
     *
     * @param rosterEntityList           名单集合
     * @param field 更新字段
     * @return void
     * @author zhangzhuoqi
     * @since 2025/3/18 16:41
     **/
    void batchUpdWhenDistById(List<PlanRosterEntity> rosterEntityList, BatchUpdRosterFieldDTO field);

    /**
     * 通过条件查询名单信息（查询条件按需补充）
     *
     * @param distPlanId 分流计划id
     * @param condition  查询条件
     * @return List<PlanRosterEntity>
     * @author zhangzhuoqi
     * @since 2025/3/19 09:59
     **/
    List<PlanRosterEntity> queryByCondition(Long distPlanId, RosterQueryConditionDTO condition);

    /**
     * 通过条件查询名单信息（查询条件按需补充）
     *
     * @param condition  查询条件
     * @return List<PlanRosterEntity>
     * @author zhangzhuoqi
     * @since 2025/3/19 09:59
     **/
    List<PlanRosterEntity> queryByPartitionCode(String partitionCode, RosterQueryConditionDTO condition);

    /**
     * 批量更新名单（分流计划id、手机号、id必传）
     *
     * @author zhangzhuoqi
     * @since 2025/3/19 17:16
     * @param entityList 名单集合
     * @return void
     **/
    void batchUpdateById(List<PlanRosterEntity> entityList);
}
