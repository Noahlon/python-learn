package com.hellobike.aicc.domain.distribute.repo;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanTemplateCondition;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanTemplateEntity;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-07  14:40:59
 */
public interface DistPlanTemplateRepo {
    void save(DistributePlanTemplateEntity distributePlanTemplateEntity);

    DistributePlanTemplateEntity queryById(Long id);

    void updateById(DistributePlanTemplateEntity distributePlanTemplateEntity);

    boolean deleteById(Long id);

    PageResult<DistributePlanTemplateEntity> queryPlanTemplate(DistributePlanTemplateCondition condition);

    List<DistributePlanTemplateEntity> queryByIdList(List<Long> idList);

    List<DistributePlanTemplateEntity> queryPlanTemplateList(String tenantCode);


    List<DistributePlanTemplateEntity> queryByCondition(DistributePlanTemplateCondition condition);
}
