package com.hellobike.aicc.domain.common.service;

import com.hellobike.aicc.domain.common.dto.OSSAuthorizeDTO;
import com.hellobike.aicc.domain.common.dto.STSTicketDTO;

public interface OssTokenDomainService {
    /**
     * 获取oss临时token
     */
    STSTicketDTO getOssTempToken();

    OSSAuthorizeDTO resourceAuthorize(String ossUrl);
}
