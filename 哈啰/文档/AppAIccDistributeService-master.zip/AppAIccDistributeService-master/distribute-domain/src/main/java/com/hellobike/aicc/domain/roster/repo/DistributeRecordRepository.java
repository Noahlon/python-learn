package com.hellobike.aicc.domain.roster.repo;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DistributeRecordTypeEnum;
import com.hellobike.aicc.domain.roster.dto.DistributeRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.DistributeRecordEntity;

import java.util.List;

/**
 * 分表键：distributePlanId
 * 操作repo时请确保distributePlanId不为空
 * @author zhangzhuoqi
 * @since 2025-03-07  14:37:53
 */
public interface DistributeRecordRepository {

    /**
     * 创建一条下发记录
     * 分表键：distributePlanId
     *
     * @param distributeRecordEntity
     * @return void
     * @author zhangzhuoqi
     * @since 2025/3/7 17:42
     **/
    void addRecord(DistributeRecordEntity distributeRecordEntity);

    /**
     * 批量创建下发记录
     *
     * @param distributeRecordEntityList
     * @return void
     * @author zhangzhuoqi
     * @since 2025/3/10 11:07
     **/
    void batchAddRecord(List<DistributeRecordEntity> distributeRecordEntityList);

    /**
     * 通过id修改下发记录 （按需修改字段）
     *
     * @param distributeRecordEntity
     * @return void
     * @author zhangzhuoqi
     * @since 2025/3/10 11:07
     **/
    void updateRecordById(DistributeRecordEntity distributeRecordEntity);

    /**
     * 通过上传记录id批量更新下发记录类型
     *
     * @author zhangzhuoqi
     * @since 2025/3/21 14:56
     * @param uploadRecordId
     * @param distributePlanId
     * @param recordType
     * @return void
     **/
    void updateRecordType(Long uploadRecordId,Long distributePlanId, DistributeRecordTypeEnum recordType);

    /**
     * 通过id查询上传记录
     *
     * @param id               下发记录id
     * @param distributePlanId 分流计划id（分表键）
     * @return com.hellobike.aicc.domain.roster.entity.UploadRecordEntity
     * @author zhangzhuoqi
     * @since 2025/3/10 11:07
     **/
    DistributeRecordEntity getRecordById(Long id, Long distributePlanId);

    /**
     * 通过条件查询下发记录
     *
     * @param conditionDTO 查询条件
     * @return java.util.List<com.hellobike.aicc.domain.roster.entity.UploadRecordEntity>
     * @author zhangzhuoqi
     * @since 2025/3/10 11:07
     **/
    List<DistributeRecordEntity> queryByCondition(DistributeRecordQueryConditionDTO conditionDTO);

    /**
     * 分页查询
     *
     * @param conditionDTO 查询条件
     * @param pageNum                       页码
     * @param pageSize                      页大小
     * @return
     */
    PageResult<DistributeRecordEntity> pageByCondition(DistributeRecordQueryConditionDTO conditionDTO, Integer pageNum, Integer pageSize);
}
