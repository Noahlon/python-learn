package com.hellobike.aicc.domain.distribute.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.hellobike.aicc.common.basic.BffLogin;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.PlanChannelTaskStatusEnum;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.domain.channel.dto.ChannelTaskCreateDTO;
import com.hellobike.aicc.domain.channel.entity.ChannelTaskEntity;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.channel.factory.ChannelInfo;
import com.hellobike.aicc.domain.channel.processor.ChannelProcessor;
import com.hellobike.aicc.domain.channel.service.ChannelDomainService;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanTemplateEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributeRuleEntity;
import com.hellobike.aicc.domain.distribute.repo.DistChannelRepo;
import com.hellobike.aicc.domain.distribute.repo.DistChannelTaskRepo;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.distribute.repo.DistPlanTemplateRepo;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributeChannelTaskQryCondition;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanQueryCondition;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanTemplateCondition;
import com.hellobike.aicc.domain.distribute.service.DistPlanDomainService;
import com.hellobike.aicc.domain.utils.HammerThreadPoolUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 类说明
 *
 * @author panlongqian
 * @since 2025-03-10
 */
@Service
@Slf4j
public class DistPlanDomainServiceImpl implements DistPlanDomainService {
    @Resource
    private IdGeneratorService idGeneratorService;

    @Resource
    private DistPlanRepo distPlanRepo;

    @Resource
    private DistChannelRepo distChannelRepo;

    @Resource
    private ChannelDomainService channelDomainService;

    @Resource
    private DistChannelTaskRepo distChannelTaskRepo;

    @Resource
    private DistPlanTemplateRepo distPlanTemplateRepo;

    @Override
    public Long createDistributePlan(DistributePlanEntity distributePlan, BffLogin user) {
        if (distributePlan.getTemplateId() != null) {
            // 校验模板是否存在，同时更新模板最近使用时间distPlanTemplateRepo
            DistributePlanTemplateEntity template = distPlanTemplateRepo.queryById(distributePlan.getTemplateId());
            AssertUtils.notNull(template, "模板不存在");
            template.setLatestUsingTime(LocalDateTime.now());
            distPlanTemplateRepo.updateById(template);
        }
        Long distributePlanId = idGeneratorService.getLongId();
        distributePlan.setId(distributePlanId);
        distPlanRepo.createDistributePlan(distributePlan);

        // 创建渠道任务，存入渠道任务表
        distributePlan.getDistributeRuleList().forEach(ruleEntity ->
                HammerThreadPoolUtil.submitChannelTaskCreateTask(() -> addChannelTask(ruleEntity, distributePlan, user)));
        return distributePlanId;
    }

    @Override
    public DistributePlanEntity queryDistributePlanDetail(Long id) {
        DistributePlanEntity distributePlan = distPlanRepo.queryDistributePlanById(id);
        AssertUtils.notNull(distributePlan, "分流计划不存在");

        // 根据分流计划id查询填充渠道任务状态和渠道任务id（用于失败重试）
        List<DistributeChannelTaskEntity> channelTaskList = distChannelTaskRepo.queryDistributePlanTaskList(distributePlan.getId());
        // 渠道商id + 渠道商任务模板id 做唯一标识
        Map<String, DistributeChannelTaskEntity> identifyMap = channelTaskList.stream().collect(Collectors.toMap(it -> it.getChannelId() + "-" + it.getSupplierTaskTemplateId(), it -> it));

        for (DistributeRuleEntity ruleEntity : distributePlan.getDistributeRuleList()) {
            String identify = ruleEntity.getChannelId() + "-" + ruleEntity.getTaskTemplateId();
            DistributeChannelTaskEntity taskEntity = identifyMap.get(identify);
            if (taskEntity == null) {
                // 渠道任务不存在
                ruleEntity.setPlanChannelTaskStatus(PlanChannelTaskStatusEnum.NOT_CREATE.getCode());
                ruleEntity.setPlanChannelTaskStatusDesc(PlanChannelTaskStatusEnum.NOT_CREATE.getDesc());
            } else {
                // 渠道任务存在,填充渠道任务状态和渠道任务id（用于失败重试）
                ruleEntity.setPlanChannelTaskId(String.valueOf(taskEntity.getId()));
                ruleEntity.setPlanChannelTaskStatus(taskEntity.getTaskStatus());
                ruleEntity.setPlanChannelTaskStatusDesc(PlanChannelTaskStatusEnum.getDescByCode(taskEntity.getTaskStatus()));
            }
        }

        return distributePlan;
    }

    /**
     * 创建渠道任务
     */
    private void addChannelTask(DistributeRuleEntity ruleEntity, DistributePlanEntity distributePlan, BffLogin user) {
        try {
            ChannelProcessor channelProcessor = ChannelFactory.getChannelProcessor(ruleEntity.getChannelId());
            if (channelProcessor == null) {
                log.error("找不到渠道处理器,渠道商id为：{}, 渠道商名称为：{}", ruleEntity.getChannelId(), ruleEntity.getChannelName());
                return;
            }

            // 创建渠道任务，新增计划渠道任务记录，状态为成功或者失败
            DistributeChannelTaskEntity distributeChannelTaskEntity = new DistributeChannelTaskEntity();
            distributeChannelTaskEntity.setId(idGeneratorService.getLongId());
            distributeChannelTaskEntity.setDistributePlanId(distributePlan.getId());
            distributeChannelTaskEntity.setChannelId(String.valueOf(ruleEntity.getChannelId()));
            distributeChannelTaskEntity.setChannelName(ruleEntity.getChannelName());
            distributeChannelTaskEntity.setSupplierTaskTemplateId(ruleEntity.getTaskTemplateId());
            distributeChannelTaskEntity.setSupplierTaskTemplateName(ruleEntity.getTaskTemplateName());
            distributeChannelTaskEntity.setCreator(user.getUserName());

            ChannelTaskCreateDTO channelTaskCreateDTO = new ChannelTaskCreateDTO();
            channelTaskCreateDTO.setTaskTemplateId(ruleEntity.getTaskTemplateId());
            channelTaskCreateDTO.set_user(user);
            channelTaskCreateDTO.setDistributePlanId(distributePlan.getId());

            // 查询渠道商详情,为外部渠道商设置appKey
            ChannelInfo channelInfo = ChannelFactory.getChannel(ruleEntity.getChannelId());
            channelTaskCreateDTO.setAppKey(channelInfo.getAppKey());

            //动态路由外呼系统或外部渠道商
            ChannelTaskEntity channelTask = tryCreateChannelTask(channelProcessor, channelTaskCreateDTO);
            if (channelTask == null || StringUtils.isBlank(channelTask.getChannelTaskId())) {
                log.error("渠道商创建任务失败,渠道商id为：{}, 渠道商名称为：{}", ruleEntity.getChannelId(), ruleEntity.getChannelName());
                distributeChannelTaskEntity.setTaskStatus(PlanChannelTaskStatusEnum.FAILED.getCode());
            } else {
                distributeChannelTaskEntity.setSupplierTaskId(channelTask.getChannelTaskId());
                distributeChannelTaskEntity.setSupplierTaskName(channelTask.getChannelTaskName());
                distributeChannelTaskEntity.setTaskStatus(PlanChannelTaskStatusEnum.SUCCESS.getCode());
            }
            channelDomainService.createDistributeChannelTask(distributeChannelTaskEntity);
        } catch (Exception e) {
            log.error("创建渠道商任务出现异常,渠道商id为：{}, 渠道商名称为：{}", ruleEntity.getChannelId(), ruleEntity.getChannelName());
        }
    }

    private ChannelTaskEntity tryCreateChannelTask(ChannelProcessor channelProcessor, ChannelTaskCreateDTO channelTaskCreateDTO) {
        ChannelTaskEntity channelTask = channelProcessor.createChannelTask(channelTaskCreateDTO);
        if (channelTask == null || StringUtils.isBlank(channelTask.getChannelTaskId())) {
            // 重试一次
            channelTask = channelProcessor.createChannelTask(channelTaskCreateDTO);
        }
        return channelTask;
    }

    @Override
    public void updateDistributePlan(DistributePlanEntity distributePlan, BffLogin user) {
        DistributePlanEntity dbEntity = distPlanRepo.queryDistributePlanById(distributePlan.getId());
        AssertUtils.notNull(dbEntity, "分流计划不存在");

        Map<String, DistributeRuleEntity> existIdentifyMap = dbEntity.getDistributeRuleList().stream().collect(Collectors.toMap(it -> it.getChannelId() + "-" + it.getTaskTemplateId(), it -> it));
        Map<String, DistributeRuleEntity> updateIdentifyMap = distributePlan.getDistributeRuleList().stream().collect(Collectors.toMap(it -> it.getChannelId() + "-" + it.getTaskTemplateId(), it -> it));

        // 只能新增分流规则，不能删除分流规则
        AssertUtils.isTrue(updateIdentifyMap.keySet().containsAll(existIdentifyMap.keySet()), "不能删除规则");

        for (Map.Entry<String, DistributeRuleEntity> entry : updateIdentifyMap.entrySet()) {
            String key = entry.getKey();
            DistributeRuleEntity updateEntity = entry.getValue();
            if (!existIdentifyMap.containsKey(key)) {
                // 新增的规则,只需要这几个字段，防止多传字段影响数据
                DistributeRuleEntity newRule = new DistributeRuleEntity();
                newRule.setChannelId(updateEntity.getChannelId());
                newRule.setChannelName(updateEntity.getChannelName());
                newRule.setTaskTemplateId(updateEntity.getTaskTemplateId());
                newRule.setTaskTemplateName(updateEntity.getTaskTemplateName());
                newRule.setPercentage(updateEntity.getPercentage());
                dbEntity.getDistributeRuleList().add(newRule);
                // 创建渠道任务
                HammerThreadPoolUtil.submitChannelTaskCreateTask(() -> addChannelTask(newRule, distributePlan, user));
            } else {
                // 修改规则,只修改比例
                existIdentifyMap.get(key).setPercentage(updateEntity.getPercentage());
            }
        }
        distPlanRepo.updateDistributePlan(dbEntity);
        distChannelRepo.delTaskCounter(distributePlan.getId());
    }

    @Override
    public PageResult<DistributePlanEntity> pageQueryDistributePlan(DistributePlanQueryCondition condition) {
        boolean isEmpty = this.setPlanQryCondition(condition);
        if (isEmpty){
            return PageResult.getEmptyPage(condition.getPageNum(), condition.getPageSize());
        }
        PageResult<DistributePlanEntity> distributePlanList = distPlanRepo.pageQueryDistributePlan(condition);
        if (CollectionUtil.isEmpty(distributePlanList.getList())){
            return distributePlanList;
        }
        Map<Long, DistributePlanEntity> planMap = distributePlanList.getList().stream().collect(Collectors.toMap(DistributePlanEntity::getId, it -> it));
        List<Long> templateIdList = distributePlanList.getList().stream().map(DistributePlanEntity::getTemplateId).distinct().collect(Collectors.toList());
        Map<Long, DistributePlanTemplateEntity> templateMap = this.mapTemplate(templateIdList);


        List<DistributeChannelTaskEntity> taskList = distChannelTaskRepo.queryTaskListByPlanIdList(new ArrayList<>(planMap.keySet()));
        // 根据分流计划id分组
        Map<Long, List<DistributeChannelTaskEntity>> taskMap = taskList.stream().collect(Collectors.groupingBy(DistributeChannelTaskEntity::getDistributePlanId));
        for (Map.Entry<Long, List<DistributeChannelTaskEntity>> entry : taskMap.entrySet()) {
            List<DistributeRuleEntity> finalRuleList = new ArrayList<>();
            DistributePlanEntity plan = planMap.get(entry.getKey());
            if (Objects.nonNull(plan.getTemplateId())){
                DistributePlanTemplateEntity templateEntity = templateMap.get(plan.getTemplateId());
                if (Objects.nonNull(templateEntity)){
                    plan.setTemplateName(templateEntity.getTemplateName());
                    plan.setTemplateId(templateEntity.getId());
                }
            }
            List<DistributeChannelTaskEntity> task = entry.getValue();
            Map<String, DistributeChannelTaskEntity> collect = task.stream().collect(Collectors.toMap(it -> it.getChannelId() + "-" + it.getSupplierTaskTemplateId(), it -> it));
            for (DistributeRuleEntity rule : plan.getDistributeRuleList()) {
                DistributeChannelTaskEntity channelTask = collect.get(rule.getChannelId() + "-" + rule.getTaskTemplateId());
                if (channelTask != null && Objects.equals(PlanChannelTaskStatusEnum.SUCCESS.getCode(), channelTask.getTaskStatus())) {
                    rule.setQuantity(channelTask.getSentSuccessNum() == null ? 0 : channelTask.getSentSuccessNum());
                    rule.setSupplierTaskName(channelTask.getSupplierTaskName());
                    finalRuleList.add(rule);
                }
            }
            plan.setDistributeRuleList(finalRuleList);
        }
        return distributePlanList;
    }

    private boolean setPlanQryCondition(DistributePlanQueryCondition condition) {
        if (StringUtils.isNotBlank(condition.getSupplierTemplateId()) || StringUtils.isNotBlank(condition.getSupplierTemplateName())){
            DistributeChannelTaskQryCondition taskQryCondition = new DistributeChannelTaskQryCondition();
            taskQryCondition.setSupplierTaskTemplateId(condition.getSupplierTemplateId());
            taskQryCondition.setSupplierTaskTemplateName(condition.getSupplierTemplateName());
            List<DistributeChannelTaskEntity> taskEntityList = distChannelTaskRepo.queryByCondition(taskQryCondition);
            if (CollectionUtil.isNotEmpty(taskEntityList)){
                List<Long> planIdList = taskEntityList.stream().map(DistributeChannelTaskEntity::getDistributePlanId).distinct().collect(Collectors.toList());
                condition.setPlanIdList(planIdList);
            }else {
                //如果通过名称查询为空则直接返回
                return true;
            }
        }
        if (StringUtils.isNotBlank(condition.getPlanTemplateName())){
            //通过模版名称查询模版id
            DistributePlanTemplateCondition templateCondition = new DistributePlanTemplateCondition();
            templateCondition.setTemplateName(condition.getPlanTemplateName());
            List<DistributePlanTemplateEntity> templateList = distPlanTemplateRepo.queryByCondition(templateCondition);
            if (CollectionUtil.isNotEmpty(templateList)){
                condition.setPlanTemplateIdList(templateList.stream().map(DistributePlanTemplateEntity::getId).collect(Collectors.toList()));
            } else {
                //如果通过名称查询为空则直接返回
                return true;
            }
        }
        return false;
    }

    private Map<Long, DistributePlanTemplateEntity> mapTemplate(List<Long> templateIdList) {
        Map<Long, DistributePlanTemplateEntity> templateMap = new HashMap<>();
        if (CollectionUtil.isEmpty(templateIdList)){
            return templateMap;
        }
        List<DistributePlanTemplateEntity> templateList = distPlanTemplateRepo.queryByIdList(templateIdList);
        if (CollectionUtil.isEmpty(templateList)){
            return templateMap;
        }
        templateList.forEach(it -> templateMap.put(it.getId(), it));
        return templateMap;
    }
}
