package com.hellobike.aicc.domain.smsrecord.repo;

import com.hellobike.aicc.domain.smsrecord.entity.SupplierSmsRecordEntity;

public interface SupplierSmsRecordRepository {
    void save(SupplierSmsRecordEntity entity);
}
