package com.hellobike.aicc.domain.smsrecord.dto;

import com.hellobike.aicc.common.enums.SmsSendResultEnum;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-06-10  19:15:38
 */
@Data
public class SmsCheckStatusQryConditionDTO {

    /**
     * 收到短信结果时间-开始
     */
    private LocalDateTime receiveResultTimeStart;

    /**
     * 收到短信结果时间-结束
     */
    private LocalDateTime receiveResultTimeEnd;

    /**
     * 处理状态 0-未处理 1-已处理
     */
    private Integer handleStatus;

    /**
     * 待处理的短信发送结果
     * @see SmsSendResultEnum
     */
    private Integer handleSendResult;
}
