package com.hellobike.aicc.domain.common.service;

public interface DingTalkService {
    /**
     * 通知渠道任务创建失败
     *
     * @param planId 分流计划id
     * @param channelName 渠道商名称
     */
    void sendChannelTaskCreateFailedAlert(Long planId, String channelName);

    /**
     * 通知名单下发失败
     *
     * @param planId 分流计划id
     * @param failReason 失败原因
     */
    void sendRosterDistributeFailedAlert(Long planId, String tenantName, String templateName, String failReason);

    /**
     * 通知外呼话单消费失败
     * @param dialogueId 外呼话单id
     */
    void sendDialogueFailedAlert(String dialogueId);

    /**
     * 通知外呼短信记录消费失败
     * @param msgId MQ消息id
     */
    void sendSmsRecordFailedAlert(String msgId);

    /**
     * 通知名单更新消费失败
     * @param messageId 消息id
     */
    void sendRosterFailedAlert(String messageId);

    /**
     * 通知渠道商接口调用失败
     */
    void sendChannelApiFail(String channelName, String apiName, String failReason);
}
