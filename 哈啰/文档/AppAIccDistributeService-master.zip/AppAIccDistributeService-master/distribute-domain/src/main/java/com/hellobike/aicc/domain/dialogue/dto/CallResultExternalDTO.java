package com.hellobike.aicc.domain.dialogue.dto;

import lombok.Data;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-04-01  15:31:27
 */
@Data
public class CallResultExternalDTO {

    /**
     * 对内呼叫状态码
     */
    private List<Integer> callResultStatusList;

    /**
     * 对外呼叫状态码
     */
    private Integer callResultExternalStatus;
}
