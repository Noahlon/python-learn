package com.hellobike.aicc.domain.dialogue.service;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.dialogue.dto.BaseDialogueCallBackDTO;
import com.hellobike.aicc.domain.dialogue.dto.CallDialogueQueryConditionDTO;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-13  14:43:23
 */
public interface DialogueDomainService {

    /**
     * 分页查询话单
     *
     * @param condition 查询条件
     * @param pageNum   页码
     * @param pageSize  页大小
     * @return PageResult<CallDialogueEntity>
     * @author zhangzhuoqi
     * @since 2025/3/13 14:49
     **/
    PageResult<CallDialogueEntity> pageDialogueRecords(CallDialogueQueryConditionDTO condition, Integer pageNum, Integer pageSize);

    /**
     * 处理渠道商话单回调
     *
     * @param callBackDTO 回调话单消息体
     * @param channelId   渠道商id
     * @return void
     * @author zhangzhuoqi
     * @since 2025/3/14 13:59
     **/
    <C extends BaseDialogueCallBackDTO> void handleCallDialogueCallBack(C callBackDTO, Integer channelId);

    /**
     * 查询话单详情
     *
     * @param id           话单id
     * @param calledNumber 被叫号
     * @return CallDialogueEntity
     * @author zhangzhuoqi
     * @since 2025/4/18 16:28
     **/
    CallDialogueEntity queryDetail(String id, String calledNumber);

    /**
     * 导出通话记录
     *
     * @param condition 查询条件
     * @param exportFieldList 导出字段集合
     * @param operator 操作人
     * @return String
     * @author zhangzhuoqi
     * @since 2025/4/21 15:35
     **/
    void export(CallDialogueQueryConditionDTO condition, List<String> exportFieldList,String operator);
}
