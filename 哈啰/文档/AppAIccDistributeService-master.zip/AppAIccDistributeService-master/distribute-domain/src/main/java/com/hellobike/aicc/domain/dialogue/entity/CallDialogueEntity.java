package com.hellobike.aicc.domain.dialogue.entity;

import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.common.enums.CallResultEnum;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-12  11:01:48
 */
@Data
public class CallDialogueEntity {

    /**
     * 话单id
     */
    private Long id;

    /**
     * 渠道id
     */
    private Integer channelId;

    /**
     * 渠道名称
     */
    private String channelName;

    /**
     * 对话信息
     */
    private List<DialogueSpeakEntity> speakList;

    /**
     * 数据密级S2,企业id
     */
    private String enterpriseId;

    /**
     * 数据密级S2,租户id（外呼中的租户id）
     */
    private String tenantId;

    /**
     * 租户名称
     */
    private String tenantName;

    /**
     * 数据密级S2,呼叫结果
     * @see CallResultEnum
     */
    private Integer callResult;

    /**
     * 数据密级S2,供应商呼叫结果code
     */
    private String supplierCallResult;

    /**
     * 数据密级S2,意向分类code
     */
    private String intentClassify;

    /**
     * 数据密级S2,命中意图
     */
    private List<String> hitIntentions;

    /**
     * 数据密级S2,知识标签
     */
    private List<String> tags;

    /**
     * 数据密级S2,分流计划模版id
     */
    private Long templateId;

    /**
     * 数据密级S2,说话次数
     */
    private Integer speakCount;

    /**
     * 数据密级S2,是否触发短信
     */
    private Integer isHitSms;

    /**
     * 数据密级S2,ai段时长
     */
    private Integer durationCallAi;

    /**
     * 数据密级S2,人工段时长
     */
    private Integer durationCallManual;

    /**
     * 数据密级S2,中继外显号
     */
    private String realCallingNumber;

    /**
     * 数据密级S2,意向分类名称
     */
    private String intentClassifyName;

    /**
     * 数据密级S2,座席名称
     */
    private String seatName;

    /**
     * 数据密级S2,通话时长
     */
    private Integer totalTime;

    /**
     * 数据密级S2,振铃时长
     */
    private Integer ringTime;

    /**
     * 数据密级S2,拨打时间
     */
    private LocalDateTime dialTime;

    /**
     * 数据密级S2,挂机时间
     */
    private LocalDateTime hangupTime;

    /**
     * 数据密级S2,通话类型
     * @see com.hellobike.aicc.common.enums.CallTypeEnum
     */
    private Integer callType;

    /**
     * 数据密级S2,主叫号码
     */
    private String callingNumber;

    /**
     * 数据密级S2,计费单元数
     */
    private Integer costUnit;

    /**
     * 数据密级S2,客户姓名
     */
    private String customName;

    /**
     * 数据密级S2,三方通话唯一id
     */
    private String dialogueGuid;

    /**
     * 数据密级S2,通话录音地址
     */
    private String recordUrl;

    /**
     * 数据密级S2,线路id
     */
    private String lineId;

    /**
     * 数据密级S2,号码归属城市
     */
    private String city;

    /**
     * 数据密级S2,号码归属省份
     */
    private String province;

    /**
     * 数据密级S2,运营商
     * @see com.hellobike.aicc.common.enums.CarrierTypeEnum
     */
    private Integer carrier;

    /**
     * 数据密级S2,对话轮次
     */
    private Integer speechCount;

    /**
     * 数据密级S2,性别
     * @see com.hellobike.aicc.common.enums.SexEnum
     */
    private Integer sex;

    /**
     * 数据密级S2,挂断方
     * @see com.hellobike.aicc.common.enums.ReleaseInitiatorEnum
     */
    private Integer releaseInitiator;

    /**
     * 数据密级S2,外部数据唯一标识
     */
    private String externalId;

    /**
     * 数据密级S2,平台数据唯一标识
     */
    private String platformId;

    /**
     * 数据密级S2,被叫号
     */
    private String calledNumber;

    /**
     * 数据密级S2,渠道任务id
     */
    private Long channelTaskId;

    /**
     * 数据密级S2,扩展信息
     */
    private String extInfo;

    /**
     * 数据密级S2,三方任务id
     */
    private String supplierTaskId;

    /**
     * 数据密级S2,三方任务名称
     */
    private String supplierTaskName;

    /**
     * 数据密级S2,三方任务模版id
     */
    private String supplierTaskTemplateId;

    /**
     * 数据密级S2,名单id
     */
    private Long rosterId;

    /**
     * 数据密级S2,分流计划id
     */
    private Long distributePlanId;

    /**
     * 数据密级S2,分流计划名称
     */
    private String distributePlanName;

    /**
     * 数据密级S2,接通时间
     */
    private LocalDateTime answerTime;

    /**
     * 数据密级S2,手机号md5
     */
    private String md5;

    /**
     * 数据密级S2,创建时间
     */
    private LocalDateTime createTime;

    /**
     * 数据密级S2,最近更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 数据密级S2,逻辑删除
     */
    private Integer isDelete;

    /**
     * 名单类型
     */
    private Integer rosterType;

    public static String getProvinceAndCity(String province, String city) {
        if (!StrUtil.isEmpty(province) && !StrUtil.isEmpty(city)) {
            return province + "/" + city;
        } else if (!StrUtil.isEmpty(province)) {
            return province;
        } else if (!StrUtil.isEmpty(city)) {
            return city;
        } else {
            return "";
        }
    }
}
