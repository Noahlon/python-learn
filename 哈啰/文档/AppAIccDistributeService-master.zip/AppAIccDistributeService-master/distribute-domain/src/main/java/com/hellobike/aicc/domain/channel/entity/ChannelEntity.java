package com.hellobike.aicc.domain.channel.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 渠道商entity
 */
@Data
@NoArgsConstructor
public class ChannelEntity {
    /**
     * 渠道商id
     */
    private Integer channelId;

    /**
     * 渠道商名称
     */
    private String channelName;

    public ChannelEntity(Integer channelId, String channelName) {
        this.channelId = channelId;
        this.channelName = channelName;
    }

    /**
     * 渠道商模板列表
     */
    private List<ChannelTemplateEntity> templateList;

    /**
     * 渠道商模板entity
     */
    @Data
    @NoArgsConstructor
    public static class ChannelTemplateEntity {
        /**
         * 模板id
         */
        private String templateId;

        /**
         * 模板名称
         */
        private String templateName;

        public ChannelTemplateEntity(String templateId, String templateName) {
            this.templateId = templateId;
            this.templateName = templateName;
        }

    }
}
