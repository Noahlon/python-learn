package com.hellobike.aicc.domain.smsrecord.entity;

import lombok.Data;

@Data
public class SupplierSmsRecordEntity {
    private Long guid;

    /**
     * 分流平台短信记录id
     */
    private Long smsId;

    /**
     * 数据密级S2,分流计划id
     */
    private Long distributePlanId;

    /**
     * 数据密级S2,供应商话单数据
     */
    private String supplierSmsJson;
}
