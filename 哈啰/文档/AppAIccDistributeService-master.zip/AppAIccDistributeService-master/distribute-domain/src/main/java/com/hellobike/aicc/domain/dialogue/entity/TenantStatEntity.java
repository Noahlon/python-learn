package com.hellobike.aicc.domain.dialogue.entity;


import lombok.Data;

import java.util.Map;

/**
 * @author zhengchenyang
 * @date 2025/4/27 17:21
 */
@Data
public class TenantStatEntity {
    /**
     * 渠道商任务id
     */
    private String tenantId;

    /**
     * 上传名单数
     */
    private Long uploadDataNum;

    /**
     * 话单量
     */
    private Long callDialogueNum;

    /**
     * 已呼名单数
     */
    private Long callRosterNum;

    /**
     * 接通话单量
     */
    private Long throughCallDialogueNum;

    /**
     * 计费数
     */
    private Long costUnit;

    /**
     * 接通名单数
     */
    private Long throughRosterNum;

    /**
     * 意向分类统计
     */
    private Map<String, Long> intentionStat;

    /**
     * 发送总数
     */
    private Long sendSmsSum;

    /**
     * 发送成功数
     */
    private Long smsSuccSum;

    /**
     * 计费数
     */
    private Long smsUnit;
}
