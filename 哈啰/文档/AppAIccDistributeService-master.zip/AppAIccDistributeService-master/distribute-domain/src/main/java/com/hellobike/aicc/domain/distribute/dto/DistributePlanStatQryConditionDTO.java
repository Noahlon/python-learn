package com.hellobike.aicc.domain.distribute.dto;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhangzhuoqi
 * @since 2025-05-27  16:57:55
 */
@Data
public class DistributePlanStatQryConditionDTO {

    /**
     * 租户id
     */
    private String tenantId;

    /**
     * 分流计划id
     */
    private String distributePlanId;

    /**
     * 分流计划名称
     */
    private String distributePlanName;

    /**
     * 分流计划创建时间-开始
     */
    private LocalDateTime planCreateTimeStart;

    /**
     * 分流计划创建时间-结束
     */
    private LocalDateTime planCreateTimeEnd;

    private Integer pageNum;

    private Integer pageSize;
}
