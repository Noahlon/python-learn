package com.hellobike.aicc.domain.channel.processor;

import com.hellobike.aicc.domain.channel.dto.ChannelTaskCreateDTO;
import com.hellobike.aicc.domain.channel.entity.ChannelEntity;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterDTO;
import com.hellobike.aicc.domain.roster.dto.ChannelImportRosterResultDTO;
import com.hellobike.aicc.domain.channel.entity.ChannelTaskEntity;
/**
 * 渠道商Processor
 */
public interface ChannelProcessor {
    /**
     * 查询渠道商详细信息，包含渠道商模板信息
     * 我们自己的外呼系统传tenantCode，其他渠道商传appKey
     */
    ChannelEntity queryChannelDetail(String tenantCode);

    /**
     * 创建渠道商任务
     */
    ChannelTaskEntity createChannelTask(ChannelTaskCreateDTO channelTaskCreateDTO);

    /**
     * 向渠道商上传名单
     *
     * @author zhangzhuoqi
     * @since 2025/3/18 13:26
     * @param channelImportRosterDTO
     * @return ChannelImportRosterResultEntity
     **/
    ChannelImportRosterResultDTO importRoster(ChannelImportRosterDTO channelImportRosterDTO);
}
