package com.hellobike.aicc.domain.distribute.service;

import com.hellobike.aicc.common.basic.BffLogin;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanQueryCondition;

/**
 * 分流计划service
 *
 * @author panlongqian
 * @since 2025-03-07
 */
public interface DistPlanDomainService {
    /**
     * 创建分流计划
     *
     * @param distributePlan 分流计划
     * @return 分流计划id
     */
    Long createDistributePlan(DistributePlanEntity distributePlan, BffLogin user);

    /**
     * 查询分流计划详情
     */
    DistributePlanEntity queryDistributePlanDetail(Long id);

    /**
     * 更新分流计划
     *
     * @param distributePlan 分流计划
     */
    void updateDistributePlan(DistributePlanEntity distributePlan, BffLogin user);

    /**
     * 分页查询分流计划
     */
    PageResult<DistributePlanEntity> pageQueryDistributePlan(DistributePlanQueryCondition condition);
}
