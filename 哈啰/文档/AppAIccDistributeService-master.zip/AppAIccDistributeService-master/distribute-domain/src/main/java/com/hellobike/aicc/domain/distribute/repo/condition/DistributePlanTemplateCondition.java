package com.hellobike.aicc.domain.distribute.repo.condition;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * <p>
 * 数据密级S2,分流模板表
 * </p>
 *
 * @author mybatisplus generator
 * @since 2025-03-07
 */
@Data
@NoArgsConstructor
@Accessors(chain = true)
public class DistributePlanTemplateCondition {

    /**
     * 模板id
     */
    private String templateId;

    /**
     * 数据密级S2,模板名称
     */
    private String templateName;

    /**
     * 数据密级S2,租户id
     */
    private List<String> tenantCodeList;

    /**
     * 数据密级S2,分流类型，1-实时分流，2-离线分流
     */
    private Integer distributeType;


    /**
     * 数据密级S2,渠道编码
     */
    private Integer channelId;

    /**
     * 页码
     */
    private Integer pageNum;

    /**
     * 每页数量
     */
    private Integer pageSize;

    /**
     * 排序字段，“createTime”，“latestUsingTime”
     */
    private String sortColumn;

    /**
     * 排序方式 （asc 或 desc）
     */
    private String sortType;

}
