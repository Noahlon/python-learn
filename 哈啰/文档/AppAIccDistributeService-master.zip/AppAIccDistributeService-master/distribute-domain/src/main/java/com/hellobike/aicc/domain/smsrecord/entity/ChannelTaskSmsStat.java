package com.hellobike.aicc.domain.smsrecord.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author zhengchenyang
 * @date 2025/4/23
 * @desc
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ChannelTaskSmsStat extends SmsStatEntity{
    /**
     * 渠道任务id
     */
    private String channelTaskId;
}
