package com.hellobike.aicc.domain.smsrecord.repo;

import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.smsrecord.dto.SmsRecordScrollQueryDTO;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordCondition;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;

public interface SmsRecordRepository {

    /**
     * 根据id查询短信记录
     *
     * @param id          id
     * @param phoneNumMd5 手机号md5（分表键）
     * @return SmsRecordEntity
     */
    SmsRecordEntity getById(Long id, String phoneNumMd5);

    /**
     * 保存短信记录
     */
    boolean save(SmsRecordEntity entity);

    /**
     * 查询短信记录
     */
    SmsRecordEntity getSmsRecordBySupplier(String supplierSmsGuid, String phoneNumberMd5, Integer channelId);

    /**
     * 更新短信记录
     */
    boolean updateById(SmsRecordEntity entity);

    /**
     * 分页查询短信记录
     */
    PageResult<SmsRecordEntity> pageQuerySmsRecord(SmsRecordCondition condition);

    /**
     * 按条件查询短信数量
     */
    long countSmsRecord(SmsRecordCondition condition);

    /**
     * 滚动查询短信记录去导出
     */
    SmsRecordScrollQueryDTO listSmsForExport(SmsRecordCondition condition, String scrollId);

    /**
     * 修改短信发送状态
     *
     * @param smsRecord    smsRecord
     * @param beforeStatus 修改之前状态
     * @param afterStatus  修改之后状态
     */
    boolean updateWhenCheckStatus(SmsRecordEntity smsRecord, Integer beforeStatus, Integer afterStatus);
}
