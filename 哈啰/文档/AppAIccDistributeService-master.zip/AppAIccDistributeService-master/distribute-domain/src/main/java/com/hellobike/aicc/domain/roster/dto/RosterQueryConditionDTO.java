package com.hellobike.aicc.domain.roster.dto;

import com.hellobike.aicc.common.enums.RosterDistributeStatusEnum;
import lombok.Data;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-19  09:57:17
 */
@Data
public class RosterQueryConditionDTO {

    /**
     * 名单id
     */
    private Long id;

    /**
     * 名单id集合
     */
    private List<Long> idList;

    /**
     * 手机号集合
     */
    private List<String> phoneNumList;

    /**
     * 分流计划id
     */
    private Long distributePlanId;

    /**
     * 上传记录id
     */
    private Long uploadRecordId;

    /**
     * 下发记录id
     */
    private Long distributeRecordId;

    /**
     * 名单下发状态
     */
    private RosterDistributeStatusEnum distributeStatus;

    /**
     * 是否查询所有字段
     */
    private Boolean queryAllField;

    /**
     * 名单下发状态集合
     */
    private List<RosterDistributeStatusEnum> distributeStatusList;
}
