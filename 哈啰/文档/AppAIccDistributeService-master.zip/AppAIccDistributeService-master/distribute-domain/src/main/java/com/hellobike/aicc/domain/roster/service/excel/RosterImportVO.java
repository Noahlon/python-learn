package com.hellobike.aicc.domain.roster.service.excel;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.hellobike.aicc.domain.utils.RosterCheckUtil;
import lombok.Data;

import java.util.Map;

@Data
public class RosterImportVO {
    /**
     * 手机号
     */
    @ExcelProperty(index = 0, value = "手机号")
    private String phoneNum;

    /**
     * 数据标识
     */
    @ExcelProperty(index = 1, value = "数据标识")
    private String externalId;

    /**
     * 姓名
     */
    @ExcelProperty(index = 2, value = "姓名")
    private String customerName;

    /**
     * 变量信息
     */
    @ExcelIgnore
    private Map<String, String> variableMap;

    public boolean isValid(Integer rosterType) {
        return RosterCheckUtil.isRosterValid(phoneNum, externalId, customerName, rosterType);
    }
}
