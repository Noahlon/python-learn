package com.hellobike.aicc.domain.dialogue.handler;

import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;

/**
 * 渠道商话单回调处理接口
 *
 * @author zhangzhuoqi
 * @since 2025-03-14  14:05:58
 */
public interface CallDialogueCallBackHandler<C> {

    /**
     * 构建本地话单entity
     *
     * @author zhangzhuoqi
     * @since 2025/3/14 14:07
     * @param callBackDTO 回调数据
     * @return CallDialogueEntity
     **/
    CallDialogueEntity buildCallDialogueEntity(C callBackDTO);
}
