package com.hellobike.aicc.domain.channel.dto;

import com.hellobike.aicc.domain.dialogue.dto.DialogueCallBackDTO;
import lombok.Data;


/**
 * @author ymh
 */
@Data
public class ChannelDialoguePushDTO {
    /**
     * 渠道话单
     */
    private DialogueCallBackDTO dialogueCallBackDTO;

    /**
     * 渠道id
     */
    private Integer channelId;

}
