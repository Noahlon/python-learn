package com.hellobike.aicc.web.util;


import cn.hutool.core.collection.CollectionUtil;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.util.Objects;
import java.util.Set;

/**
 * 参数校验工具类
 *
 **/
@Slf4j
public class ParamValidUtils {

    private static final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();


    /**
     * 校验带有NotNull等这类注解等参数
     * @param param 入惨实体类
     */
    public static void validParam(Object param) {
        if (Objects.isNull(param)){
            return;
        }
        Set<ConstraintViolation<Object>> validateResults = validator.validate(param);
        if (CollectionUtil.isEmpty(validateResults)) {
            return;
        }
        String validateErrMsg = validateResults.stream().findFirst().get().getMessage();
        throw new BusinessException(BusinessErrorCode.PARAMETER_ERROR, validateErrMsg);
    }

}

