package com.hellobike.aicc.web.service.distribute;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.distribute.plan.dto.DistributePlan;
import com.hellobike.aicc.api.distribute.plan.dto.DistributeRule;
import com.hellobike.aicc.api.distribute.plan.dto.ExternalDistributePlan;
import com.hellobike.aicc.api.distribute.plan.iface.DistributePlanService;
import com.hellobike.aicc.api.distribute.plan.request.DistributePlanQueryRequest;
import com.hellobike.aicc.api.distribute.plan.request.DistributePlanRequest;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DistributeTypeEnum;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanTemplateEntity;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanQueryCondition;
import com.hellobike.aicc.domain.distribute.service.DistPlanDomainService;
import com.hellobike.aicc.domain.distribute.service.DistPlanTmplDomainService;
import com.hellobike.aicc.web.convert.DistributePlanApiConvert;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@SoaService
public class DistributePlanServiceImpl implements DistributePlanService {
    @Resource
    private DistPlanDomainService distPlanDomainService;

    @Resource
    private DistributePlanApiConvert distributePlanApiConvert;

    @Resource
    private DistPlanTmplDomainService distPlanTmplDomainService;

    private static final BigDecimal HUNDRED = new BigDecimal("100");

    @Override
    public Result<String> createDistributePlan(DistributePlan distributePlan) {
        // 校验分流类型和分流规则
        DistributeTypeEnum distributeTypeEnum = DistributeTypeEnum.getByCode(distributePlan.getDistributeType());
        AssertUtils.notNull(distributeTypeEnum, "分流类型不存在");
        distributePlan.setDistributeTypeDesc(distributeTypeEnum.getDesc());

        // 校验分流规则数量
        AssertUtils.isFalse(distributePlan.validate(), "分流规则数量异常");

        // 校验分流规则渠道 + 模板是否唯一
        validateUniqueness(distributePlan);

        // 校验分流比例是否为100
        validatePercentage(distributePlan);

        distributePlan.setCreator(distributePlan.get_user().getUserName());
        Long id = distPlanDomainService.createDistributePlan(distributePlanApiConvert.convert(distributePlan), distributePlan.get_user());
        return Result.frontOk(String.valueOf(id));
    }

    @Override
    public Result<Void> updateDistributePlan(DistributePlan distributePlan) {
        // 校验分流规则数量
        AssertUtils.isFalse(distributePlan.validate(), "分流规则数量异常");

        // 校验分流规则渠道 + 模板是否唯一
        validateUniqueness(distributePlan);

        // 校验分流比例是否为100
        validatePercentage(distributePlan);
        distPlanDomainService.updateDistributePlan(distributePlanApiConvert.convert(distributePlan), distributePlan.get_user());
        return Result.frontOk();
    }

    @Override
    public Result<PageResult<DistributePlan>> pageQueryDistributePlan(DistributePlanQueryRequest request) {
        DistributePlanQueryCondition condition = distributePlanApiConvert.convert(request);
        PageResult<DistributePlanEntity> distributePlanEntityPageResult = distPlanDomainService.pageQueryDistributePlan(condition);
        PageResult<DistributePlan> result = distributePlanApiConvert.convert(distributePlanEntityPageResult);
        if (CollectionUtils.isNotEmpty(result.getList())) {
            // 计算下发比例（下发到三方渠道任务成功的数据量 / 分流计划中上传成功的总量）
            result.getList().forEach(this::calSendPercentage);
        }
        return Result.frontOk(result);
    }

    @Override
    public Result<DistributePlan> queryDistributePlanDetail(DistributePlanRequest request) {
        AssertUtils.notBlank(request.getPlanId(), "分流计划id不能为空");
        return Result.frontOk(distributePlanApiConvert.convert(distPlanDomainService.queryDistributePlanDetail(Long.valueOf(request.getPlanId()))));
    }

    @Override
    public Result<String> createExternalDistributePlan(ExternalDistributePlan distributePlan) {
        if (StringUtils.isBlank(distributePlan.getDistributePlanTemplateId())) {
            return Result.fail(BusinessErrorCode.PARAMETER_ERROR, "模板id不能为空");
        }
        DistributePlanTemplateEntity planTemplateEntity = distPlanTmplDomainService.getPlanTemplateById(distributePlan.getDistributePlanTemplateId());
        AssertUtils.notNull(planTemplateEntity, "分流模板不存在");
        // 比较distributePlan.getTenantCode()和planTemplateEntity.getTenantCode()是否相同
        if (!StringUtils.equals(distributePlan.getTenantCode(), planTemplateEntity.getTenantCode())) {
            return Result.fail(BusinessErrorCode.PARAMETER_ERROR, "租户代码不匹配");
        }
        // 如果没有设置计划名称，则使用模板id + 时间戳
        if (StringUtils.isBlank(distributePlan.getDistributePlanName())) {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            distributePlan.setDistributePlanName(planTemplateEntity.getTemplateName() + "-" + timestamp);
        }
        distributePlan.setDistributePlanTemplateId(String.valueOf(planTemplateEntity.getId()));
        distributePlan.setDistributeType(planTemplateEntity.getDistributeType());
        distributePlan.setDistributeTypeDesc(planTemplateEntity.getDistributeTypeDesc());
        distributePlan.setDistributeRuleList(distributePlanApiConvert.convert(planTemplateEntity.getDistributeRuleList()));
        distributePlan.setTenantCode(planTemplateEntity.getTenantCode());
        distributePlan.setTenantName(planTemplateEntity.getTenantName());
        distributePlan.setCreator(distributePlan.get_user().getUserName());
        Long id = distPlanDomainService.createDistributePlan(distributePlanApiConvert.convert(distributePlan), distributePlan.get_user());
        return Result.frontOk(String.valueOf(id));
    }

    private void validatePercentage(DistributePlan distributePlan) {
        BigDecimal percentageTotal = distributePlan.getDistributeRuleList().stream().map(it -> {
            BigDecimal num = new BigDecimal(it.getPercentage());
            return num.scale() > 2 ? num.setScale(2, RoundingMode.DOWN) : num;
        }).reduce(BigDecimal.ZERO, BigDecimal::add);

        AssertUtils.isTrue(percentageTotal.compareTo(HUNDRED) == 0, "分流比例总和必须为100");
    }

    private void validateUniqueness(DistributePlan distributePlan) {
        // 校验 channelId,channelName,taskTemplateId,taskTemplateName 是否为空
        distributePlan.getDistributeRuleList().stream()
                .forEach(rule -> {
                    AssertUtils.notNull(rule.getChannelId(), "渠道id不能为空");
                    AssertUtils.notBlank(rule.getChannelName(), "渠道名称不能为空");
                    AssertUtils.notBlank(rule.getTaskTemplateId(), "任务模版Id不能为空");
                    AssertUtils.notBlank(rule.getTaskTemplateName(), "任务模版名称不能为空");
                });

        Map<String, List<DistributeRule>> channelGroup = distributePlan.getDistributeRuleList().stream()
                .collect(Collectors.groupingBy(it -> it.getChannelId() + "-" + it.getTaskTemplateId()));
        List<DistributeRule> distributeRules = channelGroup.values().stream().filter(it -> it.size() > 1).findFirst().orElse(null);
        AssertUtils.isEmpty(distributeRules, "存在相同的任务模版，请重新选择");
    }

    private void calSendPercentage(DistributePlan distributePlan) {
        for (DistributeRule distributeRule : distributePlan.getDistributeRuleList()) {
            if (distributePlan.getUploadDataNum() != null && distributePlan.getUploadDataNum() != 0 && distributeRule.getQuantity() != null) {
                distributeRule.setSendPercentage(String.valueOf(new BigDecimal(distributeRule.getQuantity()).multiply(HUNDRED).divide(new BigDecimal(distributePlan.getUploadDataNum()), 2, RoundingMode.HALF_UP)));
            }
        }
    }
}
