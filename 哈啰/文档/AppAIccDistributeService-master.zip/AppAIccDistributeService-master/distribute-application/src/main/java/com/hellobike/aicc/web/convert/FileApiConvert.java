package com.hellobike.aicc.web.convert;

import com.hellobike.aicc.api.file.response.FileExportRecordResponse;
import com.hellobike.aicc.domain.file.entity.FileExportRecordEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  15:18:57
 */
@Mapper(componentModel = "spring")
public interface FileApiConvert {

    @Mapping(target = "createTime",dateFormat = "yyyy-MM-dd HH:mm:ss")
    FileExportRecordResponse convert(FileExportRecordEntity entityPage);

    List<FileExportRecordResponse> convertList(List<FileExportRecordEntity> entityList);
}
