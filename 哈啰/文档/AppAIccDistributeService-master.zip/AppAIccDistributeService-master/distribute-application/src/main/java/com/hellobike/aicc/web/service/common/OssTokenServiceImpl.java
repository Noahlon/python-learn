package com.hellobike.aicc.web.service.common;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.common.iface.OssTokenService;
import com.hellobike.aicc.api.common.request.OSSAuthorizeRequest;
import com.hellobike.aicc.api.common.response.OSSAuthorizeResponse;
import com.hellobike.aicc.api.common.response.OssTokenResponse;
import com.hellobike.aicc.common.basic.LoginParam;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.domain.common.service.OssTokenDomainService;
import com.hellobike.aicc.web.convert.OssTokenApiConvert;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Resource;

@SoaService
public class OssTokenServiceImpl implements OssTokenService {
    private static final String QUESTION_MARK = "?";

    @Resource
    private OssTokenDomainService ossTokenDomainService;

    @Resource
    private OssTokenApiConvert ossTokenApiConvert;

    @Override
    public Result<OssTokenResponse> getOssTempToken(LoginParam request) {
        return Result.frontOk(ossTokenApiConvert.convert(ossTokenDomainService.getOssTempToken()));
    }

    @Override
    public Result<OSSAuthorizeResponse> resourceAuthorize(OSSAuthorizeRequest request) {
        AssertUtils.notBlank(request.getOssUrl(), BusinessErrorCode.PARAMETER_ERROR, "请求url为空");
        AssertUtils.isFalse(StringUtils.contains(request.getOssUrl(), QUESTION_MARK), BusinessErrorCode.PARAMETER_ERROR, "请求url格式不正确");
        return Result.frontOk(ossTokenApiConvert.convert(ossTokenDomainService.resourceAuthorize(request.getOssUrl())));
    }
}
