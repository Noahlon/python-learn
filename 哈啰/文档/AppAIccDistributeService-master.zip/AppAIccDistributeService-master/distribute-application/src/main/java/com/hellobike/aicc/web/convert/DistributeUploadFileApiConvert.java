package com.hellobike.aicc.web.convert;

import com.hellobike.aicc.api.distribute.upload.request.DistributeUploadFileQueryRequest;
import com.hellobike.aicc.api.distribute.upload.response.DistributeUploadFileResponse;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.distribute.entity.DistributeUploadFileEntity;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributeUploadFileCondition;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface DistributeUploadFileApiConvert {
    PageResult<DistributeUploadFileResponse> convert(PageResult<DistributeUploadFileEntity> entityPage);

    DistributeUploadFileCondition convert(DistributeUploadFileQueryRequest request);


}