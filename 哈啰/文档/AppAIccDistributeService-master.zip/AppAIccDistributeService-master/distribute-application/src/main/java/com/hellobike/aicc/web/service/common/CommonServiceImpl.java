package com.hellobike.aicc.web.service.common;

import cn.hutool.core.collection.CollectionUtil;
import com.google.api.client.util.Lists;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.common.iface.CommonService;
import com.hellobike.aicc.api.common.request.EnumRequest;
import com.hellobike.aicc.api.common.response.EnumResponse;
import com.hellobike.aicc.common.dto.CommonEnumDTO;
import com.hellobike.aicc.common.enums.CommonEnum;
import com.hellobike.aicc.common.enums.ValueLableEnum;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-04-22  16:44:17
 */
@Slf4j
@SoaService
public class CommonServiceImpl implements CommonService {

    @Override
    public Result<EnumResponse> queryEnumList(EnumRequest request) {
        EnumResponse enumResponse = new EnumResponse();
        enumResponse.setType(request.getType());
        CommonEnum commonEnum = ValueLableEnum.ENUM_MAP.get(request.getType());
        AssertUtils.notNull(commonEnum, "枚举类型不存在");
        List<CommonEnumDTO> list = commonEnum.allEnum();
        if (CollectionUtil.isEmpty(list)) {
            enumResponse.setEnumConstantDTOList(Lists.newArrayList());
        } else {
            enumResponse.setEnumConstantDTOList(list);
        }
        return Result.frontOk(enumResponse);
    }
}
