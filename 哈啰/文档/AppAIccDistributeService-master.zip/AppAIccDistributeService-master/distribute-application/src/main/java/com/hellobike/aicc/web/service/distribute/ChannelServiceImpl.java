package com.hellobike.aicc.web.service.distribute;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.distribute.plan.dto.BusinessTaskStat;
import com.hellobike.aicc.api.distribute.plan.dto.ChannelTaskStat;
import com.hellobike.aicc.api.distribute.plan.dto.ConversionFunnel;
import com.hellobike.aicc.api.distribute.plan.dto.IntentionClassify;
import com.hellobike.aicc.api.distribute.plan.iface.ChannelService;
import com.hellobike.aicc.api.distribute.plan.request.BusinessTaskStatReq;
import com.hellobike.aicc.api.distribute.plan.request.ChannelQueryRequest;
import com.hellobike.aicc.api.distribute.plan.request.ChannelTaskRequest;
import com.hellobike.aicc.api.distribute.plan.request.RetryCreateChannelTaskRequest;
import com.hellobike.aicc.api.distribute.plan.response.BusinessTaskStatResponse;
import com.hellobike.aicc.api.distribute.plan.response.ChannelResponse;
import com.hellobike.aicc.api.distribute.plan.response.ChannelTaskStatResponse;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.component.ApolloConfigs;
import com.hellobike.aicc.common.enums.ChannelFunnelOrderEnum;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.channel.entity.ChannelEntity;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.channel.service.ChannelDomainService;
import com.hellobike.aicc.domain.channel.service.DistPlanQryParam;
import com.hellobike.aicc.domain.dialogue.entity.TenantStatEntity;
import com.hellobike.aicc.domain.distribute.dto.DistributePlanStatQryConditionDTO;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanStatEntity;
import com.hellobike.aicc.domain.distribute.service.DistributePlanStatDomainService;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.web.convert.ChannelApiConvert;
import com.hellobike.aicc.web.convert.ChannelTaskApiConvert;
import com.hellobike.aicc.web.convert.DistPlanQryConvert;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 类说明
 *
 * @author panlongqian
 * @since 2025-03-11
 */
@SoaService
public class ChannelServiceImpl implements ChannelService {
    @Resource
    private ChannelDomainService channelDomainService;

    @Resource
    private ChannelApiConvert channelApiConvert;

    @Resource
    private ChannelTaskApiConvert channelTaskApiConvert;

    @Resource
    private DistPlanQryConvert distPlanQryConvert;

    @Resource
    private ApolloConfigs apolloConfigs;

    @Resource
    private DistributePlanStatDomainService statDomainService;

    @Resource
    private DistPlanRepo distPlanRepo;

    private static final BigDecimal HUNDRED = new BigDecimal("100");

    @Override
    public Result<List<ChannelResponse>> queryChannelList(ChannelQueryRequest request) {
        List<ChannelEntity> channelEntityList = channelDomainService.queryChannelList();
        return Result.frontOk(channelApiConvert.convert(channelEntityList));
    }

    @Override
    public Result<List<ChannelResponse>> queryChannelDetail(ChannelQueryRequest request) {
        AssertUtils.notEmpty(request.getChannelIdList(), "渠道id列表为空");
        List<ChannelEntity> channelEntityList = channelDomainService.queryChannelDetail(request.getChannelIdList(), request.getTenantCode());
        return Result.frontOk(channelApiConvert.convert(channelEntityList));
    }

    @Override
    public Result<Void> retryCreateChannelTask(RetryCreateChannelTaskRequest request) {
        channelDomainService.retryCreateChannelTask(channelApiConvert.convert(request));
        return Result.frontOk();
    }

    @Override
    public Result<ChannelTaskStatResponse> channelTaskStat(ChannelTaskRequest request) {
        if (StringUtils.isBlank(request.getPlanId())) {
            return Result.fail(BusinessErrorCode.PARAMETER_ERROR, "分流计划id为空");
        }

        ChannelTaskStatResponse response = new ChannelTaskStatResponse();
        Long planId = Long.valueOf(request.getPlanId());
        DistributePlanEntity planEntity = distPlanRepo.queryDistributePlanById(planId);
        List<DistributeChannelTaskEntity> taskEntityList = channelDomainService.queryDistributeChannelTaskList(planId);
        List<ChannelTaskStat> taskStatList = channelTaskApiConvert.convert(taskEntityList);
        if (CollectionUtils.isNotEmpty(taskStatList)) {
            // 发送总数
            response.setSentTotalSum(taskStatList.stream().map(ChannelTaskStat::getSentTotalNum).filter(Objects::nonNull).reduce(Long::sum).orElse(0L));
            // 发送成功数
            response.setSentSuccessSum(taskStatList.stream().map(ChannelTaskStat::getSentSuccessNum).filter(Objects::nonNull).reduce(Long::sum).orElse(0L));
            // 通话数
            response.setCallDialogueNumSum(taskStatList.stream().map(ChannelTaskStat::getCallDialogueNum).filter(Objects::nonNull).reduce(Long::sum).orElse(0L));
            // 通话成功数
            response.setThroughCallDialogueNumSum(taskStatList.stream().map(ChannelTaskStat::getThroughCallDialogueNum).filter(Objects::nonNull).reduce(Long::sum).orElse(0L));
            // 计费数
            response.setCostUnitSum(taskStatList.stream().map(ChannelTaskStat::getCostUnit).filter(Objects::nonNull).reduce(Long::sum).orElse(0L));
            // 接通名单数
            response.setThroughRosterNumSum(taskStatList.stream().map(ChannelTaskStat::getThroughRosterNum).filter(Objects::nonNull).reduce(Long::sum).orElse(0L));

            // 短信发送数
            response.setTotalSendSmsSum(taskStatList.stream().map(ChannelTaskStat::getSendSmsSum).filter(Objects::nonNull).reduce(Long::sum).orElse(0L));
            // 短信成功数
            response.setTotalSmsSuccSum(taskStatList.stream().map(ChannelTaskStat::getSmsSuccSum).filter(Objects::nonNull).reduce(Long::sum).orElse(0L));
            // 短信计费数
            response.setTotalSmsUnit(taskStatList.stream().map(ChannelTaskStat::getSmsUnit).filter(Objects::nonNull).reduce(Long::sum).orElse(0L));

            taskStatList
                    .forEach(it -> {
                        if (it.getThroughRosterNum() != null && it.getSentSuccessNum() != null && it.getSentSuccessNum() != 0) {
                            //名单接通率
                            it.setThroughRosterPercentage(new BigDecimal(it.getThroughRosterNum()).multiply(HUNDRED).divide(new BigDecimal(it.getSentSuccessNum()), 2, RoundingMode.HALF_UP) + "%");
                        }

                        if (it.getSmsSuccSum() != null && it.getSendSmsSum() != null && it.getSendSmsSum() != 0) {
                            //短信成功率
                            it.setSmsSuccRate(new BigDecimal(it.getSmsSuccSum()).multiply(HUNDRED).divide(new BigDecimal(it.getSendSmsSum()), 2, RoundingMode.HALF_UP) + "%");
                        }
                        // 发送总数占比
                        if (it.getSentTotalNum() != null && response.getSentTotalSum() != null && response.getSentTotalSum() != 0) {
                            it.setSentTotalNumPercentage(new BigDecimal(it.getSentTotalNum()).multiply(HUNDRED).divide(new BigDecimal(response.getSentTotalSum()), 2, RoundingMode.HALF_UP) + "%");
                        }
                    });
            //意图分类统计
            response.setTotalIntentClassifyList(calIntention(response.getThroughCallDialogueNumSum(), taskStatList, ChannelTaskStat::getIntentClassifyList));
            // 总计行转化漏斗统计
            response.setTotalConversionFunnel(calConversionFunnel(taskStatList, ChannelTaskStat::getConversionFunnel));
            //总计行漏斗中加入上传数量
            ConversionFunnel conversionFunnel = new ConversionFunnel();
            ChannelFunnelOrderEnum uploadNum = ChannelFunnelOrderEnum.UPLOAD_NUM;
            conversionFunnel.setName(uploadNum.getName());
            conversionFunnel.setCode(uploadNum.getCode());
            conversionFunnel.setId(uploadNum.getId());
            conversionFunnel.setValue(planEntity.getUploadDataNum());
            response.getTotalConversionFunnel().add(conversionFunnel);

            response.getTotalConversionFunnel().sort(Comparator.comparing(ConversionFunnel::getId));
        }
        //总的名单接通率
        if (response.getThroughRosterNumSum() != null && response.getSentSuccessSum() != null && response.getSentSuccessSum() != 0) {
            response.setThroughRosterPercentage(new BigDecimal(response.getThroughRosterNumSum()).multiply(HUNDRED).divide(new BigDecimal(response.getSentSuccessSum()), 2, RoundingMode.HALF_UP) + "%");
        }
        // 总的短信成功率率
        if (response.getTotalSmsSuccSum() != null && response.getTotalSendSmsSum() != null && response.getTotalSendSmsSum() != 0) {
            response.setTotalSmsSuccRate(new BigDecimal(response.getTotalSmsSuccSum()).multiply(HUNDRED).divide(new BigDecimal(response.getTotalSendSmsSum()), 2, RoundingMode.HALF_UP) + "%");
        }
        response.setChannelTaskStatList(taskStatList);
        return Result.frontOk(response);
    }

    @Override
    public Result<BusinessTaskStatResponse> businessTaskStat(BusinessTaskStatReq request) {
        if (StringUtils.isBlank(request.getTenantId())) {
            return Result.fail(BusinessErrorCode.PARAMETER_ERROR, "租户id为空");
        }
        if (Boolean.TRUE.equals(apolloConfigs.getBusinessStatV2())) {
            return businessTaskStatV2(request);
        }
        DistPlanQryParam requestParam = distPlanQryConvert.convert(request);

        BusinessTaskStatResponse response = new BusinessTaskStatResponse();
        PageResult<DistributePlanEntity> planPageResult = channelDomainService.queryDistPlanStat(requestParam);
        TenantStatEntity tenantStat = channelDomainService.queryDistPlanTotalStat(requestParam);
        if (tenantStat != null) {
            response.setTotalUploadNum(tenantStat.getUploadDataNum());
            response.setTotalCallRosterNum(tenantStat.getCallRosterNum());
            response.setTotalThroughCallDialogueNum(tenantStat.getThroughCallDialogueNum());
            response.setCostUnitSum(tenantStat.getCostUnit());
            response.setThroughRosterNumSum(tenantStat.getThroughRosterNum());
            response.setTotalSmsUnit(tenantStat.getSmsUnit());
            response.setTotalSmsSuccNum(tenantStat.getSmsSuccSum());
            response.setTotalSendSmsNum(tenantStat.getSendSmsSum());
            response.setTotalIntentClassifyList(channelTaskApiConvert.convertIntentionStat(tenantStat.getThroughCallDialogueNum(), tenantStat.getIntentionStat()));
            response.setTotalConversionFunnel(channelTaskApiConvert.buildTenantFunnelList(tenantStat));
        }
        List<BusinessTaskStat> taskStatList = channelTaskApiConvert.convertPlan(planPageResult.getList());
        if (CollectionUtils.isNotEmpty(taskStatList)) {
            taskStatList
                    .forEach(it -> {
                        if (it.getThroughRosterNum() != null && it.getCallRosterNum() != null && it.getCallRosterNum() != 0) {
                            //名单接通率
                            it.setThroughRosterPercentage(new BigDecimal(it.getThroughRosterNum()).multiply(HUNDRED).divide(new BigDecimal(it.getCallRosterNum()), 2, RoundingMode.HALF_UP) + "%");
                        }

                        if (it.getSmsSuccSum() != null && it.getSendSmsSum() != null && it.getSendSmsSum() != 0) {
                            //短信成功率
                            it.setSmsSuccRate(new BigDecimal(it.getSmsSuccSum()).multiply(HUNDRED).divide(new BigDecimal(it.getSendSmsSum()), 2, RoundingMode.HALF_UP) + "%");
                        }
                    });
        }
        //总的名单接通率
        if (response.getThroughRosterNumSum() != null && response.getTotalCallRosterNum() != null && response.getTotalCallRosterNum() != 0) {
            response.setThroughRosterPercentage(new BigDecimal(response.getThroughRosterNumSum()).multiply(HUNDRED).divide(new BigDecimal(response.getTotalCallRosterNum()), 2, RoundingMode.HALF_UP) + "%");
        }
        // 总的短信成功率率
        if (response.getTotalSmsSuccNum() != null && response.getTotalSendSmsNum() != null && response.getTotalSendSmsNum() != 0) {
            response.setTotalSmsSuccRate(new BigDecimal(response.getTotalSmsSuccNum()).multiply(HUNDRED).divide(new BigDecimal(response.getTotalSendSmsNum()), 2, RoundingMode.HALF_UP) + "%");
        }
        PageResult<BusinessTaskStat> pageResult = new PageResult<>();
        pageResult.setPageNum(planPageResult.getPageNum());
        pageResult.setPageSize(planPageResult.getPageSize());
        pageResult.setTotalPages(planPageResult.getTotalPages());
        pageResult.setTotalRecord(planPageResult.getTotalRecord());
        pageResult.setList(taskStatList);
        response.setBusinessTaskStatList(pageResult);
        return Result.frontOk(response);
    }

    private Result<BusinessTaskStatResponse> businessTaskStatV2(BusinessTaskStatReq request) {
        DistributePlanStatQryConditionDTO conditionDTO = new DistributePlanStatQryConditionDTO();
        conditionDTO.setTenantId(request.getTenantId());
        conditionDTO.setDistributePlanId(request.getTaskId());
        conditionDTO.setDistributePlanName(request.getTaskName());
        conditionDTO.setPageNum(request.getPageNum());
        conditionDTO.setPageSize(request.getPageSize());
        //查询出{statDayRange}天内的分流计划
        LocalDateTime endTime = DateUtils.getCurrentDayEnd();
        LocalDateTime startTime = endTime.minusDays(apolloConfigs.getStatQueryDayRange());
        conditionDTO.setPlanCreateTimeEnd(endTime);
        conditionDTO.setPlanCreateTimeStart(startTime);

        PageResult<DistributePlanStatEntity> pageResult = statDomainService.pageStat(conditionDTO);
        BusinessTaskStatResponse response = new BusinessTaskStatResponse();
        if (pageResult.isEmpty()) {
            return Result.frontOk(response);
        }
        //总计行统计
        this.statTenantTotal(response, conditionDTO);
        //分流计划列表统计
        List<BusinessTaskStat> businessTaskStatList = pageResult.getList().stream().map(it -> {
            BusinessTaskStat businessTaskStat = new BusinessTaskStat();
            businessTaskStat.setTaskName(it.getDistributePlanName());
            businessTaskStat.setTaskId(String.valueOf(it.getDistributePlanId()));
            businessTaskStat.setUploadNum(it.getUploadDataNum().longValue());
            businessTaskStat.setCallRosterNum(it.getCallRosterNum().longValue());
            businessTaskStat.setThroughRosterNum(it.getThroughRosterNum().longValue());
            businessTaskStat.setThroughCallDialogueNum(it.getThroughCallDialogueNum().longValue());
            businessTaskStat.setCostUnit(it.getCostUnit().longValue());
            businessTaskStat.setCreateTime(DateUtils.format(it.getPlanCreateTime()));
            businessTaskStat.setSendSmsSum(it.getSendSmsRosterNum().longValue());
            businessTaskStat.setSmsSuccSum(it.getSmsSuccRosterNum().longValue());
            if (it.getThroughRosterNum() != null && it.getCallRosterNum() != null && it.getCallRosterNum() != 0) {
                //名单接通率
                businessTaskStat.setThroughRosterPercentage(new BigDecimal(it.getThroughRosterNum()).multiply(HUNDRED).divide(new BigDecimal(it.getCallRosterNum()), 2, RoundingMode.HALF_UP) + "%");
            }

            if (it.getSmsSuccRosterNum() != null && it.getSendSmsRosterNum() != null && it.getSendSmsRosterNum() != 0) {
                //短信成功率
                businessTaskStat.setSmsSuccRate(new BigDecimal(it.getSmsSuccRosterNum()).multiply(HUNDRED).divide(new BigDecimal(it.getSendSmsRosterNum()), 2, RoundingMode.HALF_UP) + "%");
            }
            businessTaskStat.setSmsUnit(it.getSmsUnit().longValue());
            Map<String, Integer> map = BaseJsonUtils.readValue(it.getIntentionStat(), Map.class);
            //意图分类统计
            Map<String, Long> intentionStatMap = new HashMap<>();
            if (MapUtil.isNotEmpty(map)) {
                map.forEach((k, v) -> {
                    intentionStatMap.put(k, v.longValue());
                });
            }
            businessTaskStat.setIntentClassifyList(channelTaskApiConvert.convertIntentionStat(it.getThroughCallDialogueNum().longValue(), intentionStatMap));
            //转换漏斗
            DistributePlanEntity planEntity = new DistributePlanEntity();
            planEntity.setUploadDataNum(it.getUploadDataNum().longValue());
            planEntity.setCallRosterNum(it.getCallRosterNum().longValue());
            planEntity.setThroughRosterNum(it.getThroughRosterNum().longValue());
            planEntity.setSendSmsSum(it.getSendSmsRosterNum().longValue());
            planEntity.setSmsSuccSum(it.getSmsSuccRosterNum().longValue());
            businessTaskStat.setConversionFunnel(channelTaskApiConvert.buildPlanFunnelList(planEntity));
            return businessTaskStat;
        }).collect(Collectors.toList());
        response.setBusinessTaskStatList(pageResult.clonePageResult(businessTaskStatList));

        LocalDateTime lastStatTime = pageResult.getList().get(0).getLastStatTime();
        response.setLastStatTime(DateUtils.format(lastStatTime));
        response.setStatDayRange(apolloConfigs.getStatQueryDayRange());

        return Result.frontOk(response);
    }

    private void statTenantTotal(BusinessTaskStatResponse response, DistributePlanStatQryConditionDTO conditionDTO) {
        List<DistributePlanStatEntity> statList = statDomainService.queryByCondition(conditionDTO);
        if (CollectionUtil.isEmpty(statList)) {
            return;
        }
        Map<String, Long> totalIntentMap = new HashMap<>();
        for (DistributePlanStatEntity statEntity : statList) {
            response.setTotalUploadNum(response.getTotalUploadNum() + statEntity.getUploadDataNum());
            response.setTotalCallRosterNum(response.getTotalCallRosterNum() + statEntity.getCallRosterNum());
            response.setTotalThroughCallDialogueNum(response.getTotalThroughCallDialogueNum() + statEntity.getThroughCallDialogueNum());
            response.setCostUnitSum(response.getCostUnitSum() + statEntity.getCostUnit());
            response.setThroughRosterNumSum(response.getThroughRosterNumSum() + statEntity.getThroughRosterNum());
            response.setTotalSmsUnit(response.getTotalSmsUnit() + statEntity.getSmsUnit());
            response.setTotalSmsSuccNum(response.getTotalSmsSuccNum() + statEntity.getSmsSuccRosterNum());
            response.setTotalSendSmsNum(response.getTotalSendSmsNum() + statEntity.getSendSmsRosterNum());
            response.setTotalSmsUnit(response.getTotalSmsUnit() + statEntity.getSmsUnit());
            if (StrUtil.isNotBlank(statEntity.getIntentionStat())) {
                Map<String, Integer> map = BaseJsonUtils.readValue(statEntity.getIntentionStat(), Map.class);
                map.forEach((k, v) -> {
                    if (totalIntentMap.containsKey(k)) {
                        totalIntentMap.put(k, totalIntentMap.get(k) + v);
                    } else {
                        totalIntentMap.put(k, v.longValue());
                    }
                });
            }
        }
        //意图分类总计
        response.setTotalIntentClassifyList(channelTaskApiConvert.convertIntentionStat(response.getTotalThroughCallDialogueNum(), totalIntentMap));
        //转换漏斗
        TenantStatEntity tenantStat = new TenantStatEntity();
        tenantStat.setUploadDataNum(response.getTotalUploadNum());
        tenantStat.setCallRosterNum(response.getTotalCallRosterNum());
        tenantStat.setThroughRosterNum(response.getThroughRosterNumSum());
        tenantStat.setSendSmsSum(response.getTotalSendSmsNum());
        tenantStat.setSmsSuccSum(response.getTotalSmsSuccNum());
        response.setTotalConversionFunnel(channelTaskApiConvert.buildTenantFunnelList(tenantStat));
        //总的名单接通率
        if (response.getThroughRosterNumSum() != null && response.getTotalCallRosterNum() != null && response.getTotalCallRosterNum() != 0) {
            response.setThroughRosterPercentage(new BigDecimal(response.getThroughRosterNumSum()).multiply(HUNDRED).divide(new BigDecimal(response.getTotalCallRosterNum()), 2, RoundingMode.HALF_UP) + "%");
        }
        // 总的短信成功率率
        if (response.getTotalSmsSuccNum() != null && response.getTotalSendSmsNum() != null && response.getTotalSendSmsNum() != 0) {
            response.setTotalSmsSuccRate(new BigDecimal(response.getTotalSmsSuccNum()).multiply(HUNDRED).divide(new BigDecimal(response.getTotalSendSmsNum()), 2, RoundingMode.HALF_UP) + "%");
        }
    }

    /**
     * 列表全部意图合并
     *
     * @param taskStatList
     * @param getIntentClassifyListFunc
     * @param <T>
     * @return
     */
    private <T> List<IntentionClassify> calIntention(Long throughCallDlgNum, List<T> taskStatList, Function<T, List<IntentionClassify>> getIntentClassifyListFunc) {
        if (throughCallDlgNum == null || throughCallDlgNum <= 0) {
            return new ArrayList<>();
        }
        List<IntentionClassify> intentionClassifyList = new ArrayList<>();
        if (CollectionUtils.isEmpty(taskStatList)) {
            IntentionClassify intentionClassify = new IntentionClassify();
            intentionClassify.setCode("OTHER");
            intentionClassify.setValue(throughCallDlgNum);
            intentionClassify.setName("其他");
            intentionClassify.setPercentage("100.00%");
            intentionClassifyList.add(intentionClassify);
            return intentionClassifyList;
        }

        // 提取所有 IntentionClassify 并按 code 分组，累加 value
        Map<String, Long> groupedByCode = taskStatList.stream()
                .filter(o -> CollectionUtils.isNotEmpty(getIntentClassifyListFunc.apply(o)))
                .flatMap(taskStat -> getIntentClassifyListFunc.apply(taskStat).stream())
                .collect(Collectors.groupingBy(
                        IntentionClassify::getCode,
                        Collectors.summingLong(IntentionClassify::getValue)
                ));

        // 计算总值
        long totalValue = groupedByCode.entrySet().stream()
                .filter(entry -> !"OTHER".equals(entry.getKey()))
                .mapToLong(Map.Entry::getValue)
                .sum();

        for (Map.Entry<String, Long> entry : groupedByCode.entrySet()) {
            if ("OTHER".equals(entry.getKey())) {
                continue;
            }
            String code = entry.getKey();
            Long value = entry.getValue();

            IntentionClassify intentionClassify = new IntentionClassify();
            intentionClassify.setCode(code);
            intentionClassify.setValue(value);
            intentionClassify.setName(code + "类");

            // 重新计算 percentage
            BigDecimal percentage = new BigDecimal(value)
                    .multiply(HUNDRED)
                    .divide(new BigDecimal(throughCallDlgNum), 2, RoundingMode.HALF_UP);
            intentionClassify.setPercentage(percentage + "%");
            intentionClassifyList.add(intentionClassify);
        }
        long otherNum = throughCallDlgNum - totalValue;
        IntentionClassify other = new IntentionClassify();
        other.setCode("OTHER");
        other.setValue(otherNum);
        other.setName("其他");
        other.setPercentage(new BigDecimal(otherNum).multiply(HUNDRED).divide(new BigDecimal(throughCallDlgNum), 2, RoundingMode.HALF_UP) + "%");
        intentionClassifyList.add(other);
        return intentionClassifyList;
    }

    /**
     * 列表全部漏斗合并
     *
     * @param taskStatList
     * @param getConversionFunnelFunc
     * @param <T>
     * @return
     */
    private <T> List<ConversionFunnel> calConversionFunnel(List<T> taskStatList, Function<T, List<ConversionFunnel>> getConversionFunnelFunc) {
        if (CollectionUtils.isEmpty(taskStatList)) {
            return new ArrayList<>();
        }

        // 提取所有 ConversionFunnel 并按 code 分组
        Map<String, ConversionFunnel> groupedByCode = taskStatList.stream()
                .filter(o -> CollectionUtils.isNotEmpty(getConversionFunnelFunc.apply(o)))
                .flatMap(taskStat -> getConversionFunnelFunc.apply(taskStat).stream())
                .collect(Collectors.toMap(
                        ConversionFunnel::getCode,
                        funnel -> new ConversionFunnel(funnel.getName(), funnel.getCode(), funnel.getId(), funnel.getValue()),
                        (existing, replacement) -> {
                            existing.setValue(existing.getValue() + replacement.getValue());
                            return existing;
                        }
                ));

        // 返回排序后的结果
        List<ConversionFunnel> res = new ArrayList<>(groupedByCode.values());
        res.sort(Comparator.comparing(ConversionFunnel::getId));
        return res;
    }

}
