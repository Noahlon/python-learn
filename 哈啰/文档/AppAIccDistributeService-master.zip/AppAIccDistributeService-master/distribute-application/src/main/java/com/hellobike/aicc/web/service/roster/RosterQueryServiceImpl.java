package com.hellobike.aicc.web.service.roster;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.roster.iface.RosterQueryFacadeService;
import com.hellobike.aicc.api.roster.request.RosterDistributeQueryRequest;
import com.hellobike.aicc.api.roster.request.RosterTemplateRequest;
import com.hellobike.aicc.api.roster.request.RosterUploadQueryRequest;
import com.hellobike.aicc.api.roster.response.RosterDistributeRecordResponse;
import com.hellobike.aicc.api.roster.response.RosterUploadRecordResponse;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DistributeRecordTypeEnum;
import com.hellobike.aicc.common.enums.FileTypeEnum;
import com.hellobike.aicc.domain.roster.dto.DistributeRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.dto.UploadRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.DistributeRecordEntity;
import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;
import com.hellobike.aicc.domain.roster.service.RosterDomainService;
import com.hellobike.aicc.web.convert.RosterApiConvert;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * @author zhangzhuoqi
 * @since 2025-03-10  13:49:29
 */
@SoaService
@Slf4j
public class RosterQueryServiceImpl implements RosterQueryFacadeService {

    @Resource
    private RosterDomainService rosterDomainService;

    @Resource
    private RosterApiConvert rosterApiConvert;

    @Value("${roster.template.csv:https://aiot-businessprotal.oss-cn-hangzhou.aliyuncs.com/aicc_distribute/roster_template/%E4%B8%8A%E4%BC%A0%E6%A8%A1%E7%89%88.csv?OSSAccessKeyId=LTAI5tDmYeLQaUPFxjqrZHGV&Expires=1837060984&Signature=NEe%2F11r7ZsYnx6LtrCvN0KbK8Oc%3D}")
    private String csvTemplateUrl;

    @Value("${roster.template.xlsx:https://aiot-businessprotal.oss-cn-hangzhou.aliyuncs.com/aicc_distribute/roster_template/%E4%B8%8A%E4%BC%A0%E6%A8%A1%E7%89%88.xlsx?OSSAccessKeyId=LTAI5tDmYeLQaUPFxjqrZHGV&Expires=1837405442&Signature=cJl7ytgv2AvW086W7FS0qE0z1OQ%3D}")
    private String xlsxTemplateUrl;

    @Override
    public Result<PageResult<RosterUploadRecordResponse>> queryUploadRecords(RosterUploadQueryRequest rosterUploadQueryRequest) {
        UploadRecordQueryConditionDTO conditionDTO = rosterApiConvert.uploadRecordQueryReqToDTO(rosterUploadQueryRequest);
        PageResult<UploadRecordEntity> pageResult = rosterDomainService.pageUploadRecord(conditionDTO, rosterUploadQueryRequest.getPageNum(), rosterUploadQueryRequest.getPageSize());
        if (pageResult.isEmpty()) {
            return Result.frontOk(PageResult.getEmptyPage(rosterUploadQueryRequest.getPageNum(), rosterUploadQueryRequest.getPageSize()));
        }
        List<RosterUploadRecordResponse> recordList = rosterApiConvert.uploadRecordEntityToResList(pageResult.getList());
        return Result.frontOk(pageResult.clonePageResult(recordList));
    }

    @Override
    public Result<PageResult<RosterDistributeRecordResponse>> queryDistributeRecords(RosterDistributeQueryRequest request) {
        DistributeRecordQueryConditionDTO conditionDTO = rosterApiConvert.distributeRecordQueryReqToDTO(request);
        //查询正式下发的记录，不查询预下发记录
        conditionDTO.setDistributeType(DistributeRecordTypeEnum.FORMAL.getCode());
        PageResult<DistributeRecordEntity> pageResult = rosterDomainService.pageDistributeRecord(conditionDTO, request.getPageNum(), request.getPageSize());
        if (pageResult.isEmpty()) {
            return Result.frontOk(PageResult.getEmptyPage(request.getPageNum(), request.getPageSize()));
        }
        List<RosterDistributeRecordResponse> recordList = rosterApiConvert.distributeRecordEntityToResList(pageResult.getList());

        return Result.frontOk(pageResult.clonePageResult(recordList));
    }

    @Override
    public Result<String> downloadRosterTemplate(RosterTemplateRequest request) {
        if (Objects.equals(FileTypeEnum.CSV.getCode(), request.getType())){
            return Result.frontOk(csvTemplateUrl);
        } else if (Objects.equals(FileTypeEnum.XLSX.getCode(), request.getType())) {
            return Result.frontOk(xlsxTemplateUrl);
        }
        return Result.frontOk();
    }
}
