package com.hellobike.aicc.web;

import com.ctrip.framework.apollo.spring.annotation.EnableApolloConfig;
import com.hellobike.aicc.common.util.ApplicationContextHandle;
import com.hellobike.otter.healthcheck.springboot.EnableHealthCheckManagement;
import com.hellobike.base.basicconf.client.BasicConfClientBuilder;
import com.hellobike.es.sdk.common.EsApplication;
import com.hellobike.soa.starter.spring.annotation.SoaComponentScan;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.io.IOException;

/**
 * @author helloboot
 *
 */
@Slf4j
@SpringBootApplication(
        scanBasePackages = {
                "com.hellobike.aicc",
                "com.hellobike.unkonw.common"
        },
        exclude = {DataSourceAutoConfiguration.class}
)
@EnableHealthCheckManagement
@Import(ApplicationContextHandle.class)
@SoaComponentScan(value = {"com.hellobike.aicc"})
@RestController
@EnableApolloConfig
public class AppAIccDistributeServiceApplication implements ApplicationRunner {
    public static void main(String[] args) {
        // 这里推荐使用-D参数指定
        System.setProperty("APPID","AppAIccDistributeService");
        SpringApplication.run(AppAIccDistributeServiceApplication.class, args);

        try {
            BasicConfClientBuilder builder = new BasicConfClientBuilder();
            //7初始化
            EsApplication.start(builder.build());
        } catch (IOException e) {
            log.error("EsApplication start exception!", e);
        }
    }


    @Override
    public void run(ApplicationArguments args) throws Exception {

    }


    /**
    * 默认服务端支持跨域
    */
    @Bean
    public CorsFilter corsFilter() {
        final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        final CorsConfiguration corsConfiguration = new CorsConfiguration();
        //24小时
        Long maxAge=new Long(86400);
        corsConfiguration.setMaxAge(maxAge);
        corsConfiguration.addAllowedHeader("*");
        corsConfiguration.addAllowedOrigin("*");
        corsConfiguration.addAllowedMethod("*");
        source.registerCorsConfiguration("/**", corsConfiguration);
        return new CorsFilter(source);
    }

    // 为了SLB检查可以正常返回，WEB项目默认访问/
    @RequestMapping("/")
    public String index(){
        return "SUCCESS";
    }

}
