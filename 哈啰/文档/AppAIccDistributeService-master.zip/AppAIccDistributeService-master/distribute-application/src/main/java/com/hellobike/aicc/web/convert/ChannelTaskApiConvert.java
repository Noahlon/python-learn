package com.hellobike.aicc.web.convert;

import com.hellobike.aicc.api.distribute.plan.dto.BusinessTaskStat;
import com.hellobike.aicc.api.distribute.plan.dto.ChannelTaskStat;
import com.hellobike.aicc.api.distribute.plan.dto.ConversionFunnel;
import com.hellobike.aicc.api.distribute.plan.dto.IntentionClassify;
import com.hellobike.aicc.common.enums.ChannelFunnelOrderEnum;
import com.hellobike.aicc.common.enums.CommonFunnelEnum;
import com.hellobike.aicc.common.enums.PlanFunnelOrderEnum;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.dialogue.entity.TenantStatEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import org.apache.commons.collections4.MapUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Mapper(componentModel = "spring")
public interface ChannelTaskApiConvert {
    BigDecimal HUNDRED = new BigDecimal("100");

    List<ChannelTaskStat> convert(List<DistributeChannelTaskEntity> entityList);

    @Mappings({
            @Mapping(target = "latestSentTime", source = "latestSentTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(target = "createTime", source = "createTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(target = "intentClassifyList", source = "entity", qualifiedByName = "convertChannelIntentionStat"),
            @Mapping(target = "conversionFunnel", source = "entity", qualifiedByName = "buildChannelFunnelList")
    })
    ChannelTaskStat convert(DistributeChannelTaskEntity entity);

    @Mappings({
            @Mapping(target = "createTime", source = "createTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(target = "intentClassifyList", source = "entity", qualifiedByName = "convertPlanIntentionStat"),
            @Mapping(target = "conversionFunnel", source = "entity", qualifiedByName = "buildPlanFunnelList"),
            @Mapping(target = "uploadNum", source = "uploadDataNum"),
            @Mapping(target = "taskId", source = "id"),
            @Mapping(target = "taskName", source = "distributePlanName")
    })
    BusinessTaskStat convertPlan(DistributePlanEntity entity);

    List<BusinessTaskStat> convertPlan(List<DistributePlanEntity> entityList);

    @Named("convertChannelIntentionStat")
    default List<IntentionClassify> convertChannelIntentionStat(DistributeChannelTaskEntity entity) {
        return convertIntentionStat(entity.getThroughCallDialogueNum(), entity.getIntentionStat());
    }

    @Named("convertPlanIntentionStat")
    default List<IntentionClassify> convertPlanIntentionStat(DistributePlanEntity entity) {
        return convertIntentionStat(entity.getThroughCallDialogueNum(), entity.getIntentionStat());
    }


    /**
     * 组装意向分类
     *
     * @param intentionStat
     * @return
     */
    default List<IntentionClassify> convertIntentionStat(Long throughCallDlgNum, Map<String, Long> intentionStat) {
        if (throughCallDlgNum == null || throughCallDlgNum <= 0) {
            return new ArrayList<>();
        }
        List<IntentionClassify> intentionClassifyList = new ArrayList<>();
        if (MapUtils.isEmpty(intentionStat)) {
            IntentionClassify intentionClassify = new IntentionClassify();
            intentionClassify.setCode("OTHER");
            intentionClassify.setValue(throughCallDlgNum);
            intentionClassify.setName("其他");
            intentionClassify.setPercentage("100.00%");
            intentionClassifyList.add(intentionClassify);
            return intentionClassifyList;
        }
        long total = intentionStat.values().stream().reduce(Long::sum).orElse(0L);
        for (Map.Entry<String, Long> entry : intentionStat.entrySet()) {
            IntentionClassify intentionClassify = new IntentionClassify();
            intentionClassify.setCode(entry.getKey());
            intentionClassify.setValue(entry.getValue());
            intentionClassify.setName(entry.getKey() + "类");
            intentionClassify.setPercentage(new BigDecimal(entry.getValue()).multiply(HUNDRED).divide(new BigDecimal(throughCallDlgNum), 2, RoundingMode.HALF_UP) + "%");
            intentionClassifyList.add(intentionClassify);
        }
        long otherNum = throughCallDlgNum - total;
        IntentionClassify other = new IntentionClassify();
        other.setCode("OTHER");
        other.setValue(otherNum);
        other.setName("其他");
        other.setPercentage(new BigDecimal(otherNum).multiply(HUNDRED).divide(new BigDecimal(throughCallDlgNum), 2, RoundingMode.HALF_UP) + "%");
        intentionClassifyList.add(other);
        return intentionClassifyList;
    }

    /**
     * 构建漏斗
     *
     * @param entity
     * @return
     */
    @Named("buildTenantFunnelList")
    default List<ConversionFunnel> buildTenantFunnelList(TenantStatEntity entity) {
        return buildFunnelList(entity, PlanFunnelOrderEnum.values());
    }

    /**
     * 构建漏斗
     *
     * @param entity
     * @return
     */
    @Named("buildPlanFunnelList")
    default List<ConversionFunnel> buildPlanFunnelList(DistributePlanEntity entity) {
        return buildFunnelList(entity, PlanFunnelOrderEnum.values());
    }

    /**
     * 构建漏斗
     *
     * @param entity
     * @return
     */
    @Named("buildChannelFunnelList")
    default List<ConversionFunnel> buildChannelFunnelList(DistributeChannelTaskEntity entity) {
        return buildFunnelList(entity, ChannelFunnelOrderEnum.values());
    }

    /**
     * 通用的漏斗构建方法
     *
     * @param entity 实体对象
     * @param enums  枚举数组
     * @return 漏斗列表
     */
    default <T, E extends CommonFunnelEnum> List<ConversionFunnel> buildFunnelList(T entity, E[] enums) {
        List<ConversionFunnel> conversionFunnelList = new ArrayList<>();
        for (E enumValue : enums) {
            if (enumValue.getShowFlag()){
                continue;
            }
            ConversionFunnel conversionFunnel = new ConversionFunnel();
            try {
                conversionFunnel.setId(enumValue.getId());
                conversionFunnel.setName(enumValue.getName());
                conversionFunnel.setCode(enumValue.getCode());

                Object fieldValue = getFieldValueByReflection(entity, enumValue.getCode());
                conversionFunnel.setValue(fieldValue != null ? Long.parseLong(fieldValue.toString()) : 0L);
                conversionFunnelList.add(conversionFunnel);
            } catch (Exception e) {
                // 如果反射调用失败，跳过当前枚举值
                continue;
            }
        }
        return conversionFunnelList;
    }

    default <T> Object getFieldValueByReflection(T entity, String code) {
        if (entity == null || code == null || code.isEmpty()) {
            return null;
        }
        try {
            // 拼接 getter 方法名（假设字段名为 code，getter 方法为 getCode）
            String getterMethodName = "get" + code.substring(0, 1).toUpperCase() + code.substring(1);
            Method method = entity.getClass().getMethod(getterMethodName);
            return method.invoke(entity);
        } catch (Exception e) {
            return null;
        }
    }

    default Object getFieldValueByReflection(DistributeChannelTaskEntity entity, String code) {
        return getFieldValueByReflection((Object) entity, code);
    }

    default Object getFieldValueByReflection(DistributePlanEntity entity, String code) {
        return getFieldValueByReflection((Object) entity, code);
    }
}
