package com.hellobike.aicc.web.convert;


import com.hellobike.aicc.api.distribute.template.request.DistributePlanTemplateQueryRequest;
import com.hellobike.aicc.api.distribute.template.request.DistributePlanTemplateRequest;
import com.hellobike.aicc.api.distribute.template.response.DistributePlanTemplateResponse;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanTemplateCondition;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanTemplateEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

/**
 * @author fanxiaodongwb230
 */
@Mapper(componentModel = "spring")
public interface DistributePlanTemplateApiConvert {
    @Mappings({
        @Mapping(target = "id", source = "templateId")
    })
    DistributePlanTemplateEntity convert(DistributePlanTemplateRequest request);

    PageResult<DistributePlanTemplateResponse> convert(PageResult<DistributePlanTemplateEntity> entityPage);

    DistributePlanTemplateCondition convert(DistributePlanTemplateQueryRequest request);

    @Mappings({
            @Mapping(target = "latestUseTime", source = "latestUsingTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(target = "createTime", source = "createTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(target = "templateId", source = "id")
    })
    DistributePlanTemplateResponse convert(DistributePlanTemplateEntity entity);

    List<DistributePlanTemplateResponse> convert(List<DistributePlanTemplateEntity> entityList);

}