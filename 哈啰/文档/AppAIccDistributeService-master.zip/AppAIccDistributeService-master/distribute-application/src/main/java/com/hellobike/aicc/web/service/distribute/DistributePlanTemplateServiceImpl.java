package com.hellobike.aicc.web.service.distribute;


import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.distribute.plan.dto.DistributeRule;
import com.hellobike.aicc.api.distribute.template.iface.DistributePlanTemplateService;
import com.hellobike.aicc.api.distribute.template.request.CommonPlanTemplateRequest;
import com.hellobike.aicc.api.distribute.template.request.CopyTemplateResponse;
import com.hellobike.aicc.api.distribute.template.request.DistributePlanTemplateQueryRequest;
import com.hellobike.aicc.api.distribute.template.request.DistributePlanTemplateRequest;
import com.hellobike.aicc.api.distribute.template.response.DistributePlanTemplateResponse;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DistributeTypeEnum;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.domain.channel.entity.ChannelEntity;
import com.hellobike.aicc.domain.channel.service.ChannelDomainService;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanTemplateEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributeRuleEntity;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanTemplateCondition;
import com.hellobike.aicc.domain.distribute.service.DistPlanTmplDomainService;
import com.hellobike.aicc.web.convert.DistributePlanTemplateApiConvert;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @Author: fanxiaodongwb230
 * @CreateTime: 2025-03-18
 * @Description:
 * @Version: 1.0
 */
@Slf4j
@SoaService
public class DistributePlanTemplateServiceImpl implements DistributePlanTemplateService {

    @Resource
    private DistPlanTmplDomainService distPlanTmplDomainService;

    @Resource
    private ChannelDomainService channelDomainService;

    @Resource
    private DistributePlanTemplateApiConvert distributePlanTemplateApiConvert;

    private static final BigDecimal HUNDRED = new BigDecimal("100");

    private static final Integer MAX_SIZE = 20;

    /**
     * 创建模板
     * @param request
     * @return
     */
    @Override
    public Result<String> createPlanTemplate(DistributePlanTemplateRequest request) {
        if (StringUtils.isAnyBlank(request.getTemplateName(), request.getTenantCode())) {
            return Result.fail(BusinessErrorCode.PARAMETER_ERROR);
        }
        // 校验分流类型和分流规则
        DistributeTypeEnum distributeTypeNum = DistributeTypeEnum.getByCode(request.getDistributeType());
        AssertUtils.notNull(distributeTypeNum, "分流类型不存在");
        request.setDistributeTypeDesc(distributeTypeNum.getDesc());

        // 校验 distributeRuleList
        validateDistributeRuleList(request.getDistributeRuleList());
        request.setCreator(request.get_user().getUserName());

        Long templateId = distPlanTmplDomainService.createPlanTemplate(distributePlanTemplateApiConvert.convert(request));
        return Result.frontOk(String.valueOf(templateId));

    }

    /**
     * 修改模板
     * @param request
     * @return
     */
    @Override
    public Result<String> editPlanTemplate(DistributePlanTemplateRequest request) {
        // 校验 templateId 是否为空或无效数字
        if (StringUtils.isBlank(request.getTemplateId()) || !isNumeric(request.getTemplateId())) {
            return Result.fail(BusinessErrorCode.PARAMETER_ERROR, "模板ID不能为空且必须为有效数字");
        }
        // 校验分流类型和分流规则
        DistributeTypeEnum distributeTypeNum = DistributeTypeEnum.getByCode(request.getDistributeType());
        AssertUtils.notNull(distributeTypeNum, "分流类型不存在");
        // 校验 distributeRule
        validateDistributeRuleList(request.getDistributeRuleList());
        // 更新模板并验证返回值
        Long templateId = distPlanTmplDomainService.updatePlanTemplate(distributePlanTemplateApiConvert.convert(request));
        return Result.frontOk(String.valueOf(templateId));

    }

    /**
     * 删除模板
     * @param request
     * @return
     */
    @Override
    public Result<String> deletePlanTemplate(CommonPlanTemplateRequest request) {
        String templateId = request.getTemplateId();
        if (StringUtils.isBlank(templateId)) {
            return Result.fail(BusinessErrorCode.PARAMETER_ERROR);
        }
        Long id = Long.valueOf(templateId);
        distPlanTmplDomainService.deletePlanTemplate(id);
        return Result.frontOk(templateId);
    }

    /**
     * 查询分配计划模板
     *
     * @param request 分配计划模板查询请求
     * @return 分配计划模板响应的Result对象
     */
    @Override
    public Result<PageResult<DistributePlanTemplateResponse>> queryPlanTemplate(DistributePlanTemplateQueryRequest request) {
        DistributePlanTemplateCondition condition = distributePlanTemplateApiConvert.convert(request);
        // 调用服务查询分配计划模板
        PageResult<DistributePlanTemplateEntity> pageList = distPlanTmplDomainService.queryPlanTemplate(condition);
        return Result.frontOk(distributePlanTemplateApiConvert.convert(pageList));

    }

    /**
     * 查询所有分配计划模板
     *
     * @param request 分配计划模板查询请求
     * @return 分配计划模板响应的Result对象
     */
    @Override
    public Result<List<DistributePlanTemplateResponse>> queryPlanTemplateList(CommonPlanTemplateRequest request) {
        String tenantCode = request.getTenantCode();
        AssertUtils.notNull(tenantCode, "租户code不能为空");
        List<DistributePlanTemplateEntity> entityList = distPlanTmplDomainService.queryPlanTemplateList(tenantCode);
        return Result.frontOk(distributePlanTemplateApiConvert.convert(entityList));
    }

    @Override
    public Result<CopyTemplateResponse> copyTemplate(CommonPlanTemplateRequest request) {
        String templateId = request.getTemplateId();
        DistributePlanTemplateEntity templateEntity = distPlanTmplDomainService.getPlanTemplateById(templateId);
        AssertUtils.notNull(templateEntity, BusinessErrorCode.TEMPLATE_NOT_EXIST);
        CopyTemplateResponse copyRes = new CopyTemplateResponse();
        copyRes.setTenantCode(templateEntity.getTenantCode());
        copyRes.setTenantName(templateEntity.getTenantName());
        if (templateEntity.getTemplateName().length() >= 200){
            copyRes.setTemplateName(templateEntity.getTemplateName());
        }else {
            copyRes.setTemplateName(templateEntity.getTemplateName() + "副本");
        }

        copyRes.setDistributeType(templateEntity.getDistributeType());
        //查询渠道商模版信息
        List<DistributeRuleEntity> distributeRuleList = templateEntity.getDistributeRuleList();
        List<Integer> channelIdList = distributeRuleList.stream().map(DistributeRuleEntity::getChannelId).collect(Collectors.toList());
        List<ChannelEntity> channelEntityList = channelDomainService.queryChannelDetail(channelIdList, templateEntity.getTenantCode());
        if (CollectionUtils.isEmpty(channelEntityList)){
            copyRes.setDistributeRuleList(Collections.emptyList());
            return Result.frontOk(copyRes);
        }
        Map<Integer, ChannelEntity> channelMap = channelEntityList.stream().collect(Collectors.toMap(ChannelEntity::getChannelId, Function.identity(), (v1, v2) -> v1));
        List<DistributeRule> ruleList = new ArrayList<>();
        for (DistributeRuleEntity distributeRuleEntity : distributeRuleList) {
            ChannelEntity channelEntity = channelMap.get(distributeRuleEntity.getChannelId());
            if (Objects.isNull(channelEntity)){
                continue;
            }
            DistributeRule rule = new DistributeRule();
            ruleList.add(rule);
            rule.setChannelId(distributeRuleEntity.getChannelId());
            rule.setChannelName(distributeRuleEntity.getChannelName());
            rule.setPercentage(distributeRuleEntity.getPercentage().toString());
            if (CollectionUtils.isEmpty(channelEntity.getTemplateList())){
                continue;
            }
            List<ChannelEntity.ChannelTemplateEntity> templateList = channelEntity.getTemplateList();
            Map<String, ChannelEntity.ChannelTemplateEntity> templateMap = templateList.stream().collect(Collectors.toMap(ChannelEntity.ChannelTemplateEntity::getTemplateId, Function.identity(), (v1, v2) -> v1));
            if (!templateMap.containsKey(distributeRuleEntity.getTaskTemplateId())){
                log.info("渠道商模版不存在,templateId:{}", distributeRuleEntity.getTaskTemplateId());
                continue;
            }
            rule.setTaskTemplateId(distributeRuleEntity.getTaskTemplateId());
            rule.setTaskTemplateName(distributeRuleEntity.getTaskTemplateName());
        }
        copyRes.setDistributeRuleList(ruleList);
        return Result.frontOk(copyRes);
    }

    /**
     * 验证分配规则是否有效
     * 规则被视为有效的条件是：
     * 1. 所有规则的百分比之和等于100%
     * 2. 每个渠道和任务模板的组合在规则列表中必须是唯一的
     * 3. 规则列表的大小不能超过20条
     */
    private void validateDistributeRuleList(List<DistributeRule> rules) {
        // 校验分流规则数量
        boolean flag = CollectionUtils.isEmpty(rules) || rules.size() > MAX_SIZE;
        AssertUtils.isFalse(flag, "分流规则数量异常");

        // 校验 channelId,channelName,taskTemplateId,taskTemplateName 是否为空
        rules.stream()
            .forEach(rule -> {
                AssertUtils.notNull(rule.getChannelId(), "渠道id不能为空");
                AssertUtils.notBlank(rule.getChannelName(), "渠道名称不能为空");
                AssertUtils.notBlank(rule.getTaskTemplateId(), "任务模版Id不能为空");
                AssertUtils.notBlank(rule.getTaskTemplateName(), "任务模版名称不能为空");
            });

        // 校验分流规则渠道 + 模板是否唯一
        Map<String, List<DistributeRule>> channelGroup = rules.stream()
                .collect(Collectors.groupingBy(it -> it.getChannelId() + "-" + it.getTaskTemplateId()));
        List<DistributeRule> distributeRules = channelGroup.values().stream().filter(it -> it.size() > 1).findFirst().orElse(null);
        AssertUtils.isEmpty(distributeRules, "该任务模版已经存在，请重新选择");

        // 校验分流比例是否为100
        BigDecimal percentageTotal = rules.stream().map(it -> {
            BigDecimal num = new BigDecimal(it.getPercentage());
            return num.scale() > 2 ? num.setScale(2, RoundingMode.DOWN) : num;
        }).reduce(BigDecimal.ZERO, BigDecimal::add);
        AssertUtils.isTrue(percentageTotal.compareTo(HUNDRED) == 0, "分流比加和不等于100，请重新编辑提交");
    }

    // 辅助方法：判断字符串是否为有效数字
    private boolean isNumeric(String str) {
        // 处理 null 和空字符串的情况
        if (str == null || str.trim().isEmpty()) {
            return false;
        }
        // 使用正则表达式判断是否为有效数字
        return str.matches("-?\\d+");
    }
}
