package com.hellobike.aicc.web.service.dialogue;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.dialogue.iface.DialogueQueryService;
import com.hellobike.aicc.api.dialogue.request.DialogueDetailRequest;
import com.hellobike.aicc.api.dialogue.request.DialogueListQueryRequest;
import com.hellobike.aicc.api.dialogue.request.DialogueQueryRequest;
import com.hellobike.aicc.api.dialogue.response.DialogueDetailResponse;
import com.hellobike.aicc.api.dialogue.response.DialogueInfoResponse;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.dialogue.dto.CallDialogueQueryConditionDTO;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import com.hellobike.aicc.domain.dialogue.service.DialogueDomainService;
import com.hellobike.aicc.web.convert.CallDialogueApiConvert;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author zhangzhuoqi
 * @since 2025-03-13  14:39:50
 */
@Slf4j
@SoaService
public class DialogueQueryServiceImpl implements DialogueQueryService {

    @Resource
    private DialogueDomainService dialogueDomainService;

    @Resource
    private CallDialogueApiConvert callDialogueApiConvert;

    @Override
    public Result<PageResult<DialogueInfoResponse>> queryDialogueRecords(DialogueListQueryRequest request) {
        CallDialogueQueryConditionDTO condition = callDialogueApiConvert.pageReqToDTO(request);
        PageResult<CallDialogueEntity> pageResult = dialogueDomainService.pageDialogueRecords(condition, request.getPageNum(), request.getPageSize());
        if (pageResult.isEmpty()) {
            return Result.frontOk(PageResult.getEmptyPage(request.getPageNum(), request.getPageSize()));
        }
        PageResult<DialogueInfoResponse> dialoguePageResult = pageResult.clonePageResult(callDialogueApiConvert.entityToRespList(pageResult.getList()));
        return Result.frontOk(dialoguePageResult);
    }

    @Override
    public Result<DialogueDetailResponse> queryDetail(DialogueDetailRequest req) {
        CallDialogueEntity callDialogueEntity = dialogueDomainService.queryDetail(req.getId(), req.getCalledNumber());
        if (Objects.isNull(callDialogueEntity)) {
            return Result.frontOk();
        }
        return Result.frontOk(callDialogueApiConvert.entityToDetailResp(callDialogueEntity));
    }

    @Override
    public Result<Void> export(DialogueListQueryRequest req) {
        CallDialogueQueryConditionDTO condition = callDialogueApiConvert.pageReqToDTO(req);
        try {
            List<String> exportFieldList = null;
            if (StrUtil.isNotBlank(req.getExportFieldList())){
                exportFieldList = BaseJsonUtils.readValues(req.getExportFieldList(), String.class);
            }
            String realName = req.get_user().getRealName();
            dialogueDomainService.export(condition, exportFieldList,realName);
            return Result.frontOk();
        }catch (Exception e){
            log.error("话单导出异常,e:",e);
            return Result.fail(BusinessErrorCode.CALL_RECORD_EXPORT_ERROR);
        }
    }

    @Override
    public Result<List<Object>> queryFromDB(DialogueQueryRequest req) {
        if (req.getPhoneList().size() > 200){
            return Result.fail(BusinessErrorCode.COMMON_ERROR,"查询数量不能超过200");
        }
        CallDialogueQueryConditionDTO conditionDTO = new CallDialogueQueryConditionDTO();
        conditionDTO.setCalledNumberList(req.getPhoneList());
        conditionDTO.setDistributePlanId(req.getDistributePlanId());
        PageResult<CallDialogueEntity> pageResult = dialogueDomainService.pageDialogueRecords(conditionDTO, 1, 200);
        if (pageResult.isEmpty()){
            log.info("queryFromDB es为空,req:{}", BaseJsonUtils.writeValue(req));
            return Result.frontOk(CollectionUtil.newArrayList());
        }
        Map<Long, String> map = pageResult.getList().stream().collect(Collectors.toMap(CallDialogueEntity::getId, CallDialogueEntity::getCalledNumber));
        List<Object> list = new ArrayList<>();
        for (Long id : map.keySet()) {
            String calledNumber = map.get(id);
            CallDialogueEntity callDialogueEntity = dialogueDomainService.queryDetail(String.valueOf(id), calledNumber);
            if (Objects.nonNull(callDialogueEntity)){
                list.add(callDialogueEntity);
            }
        }
        return Result.frontOk(list);
    }
}
