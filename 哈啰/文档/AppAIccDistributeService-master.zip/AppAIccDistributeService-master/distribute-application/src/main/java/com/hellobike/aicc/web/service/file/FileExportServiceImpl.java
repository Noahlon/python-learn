package com.hellobike.aicc.web.service.file;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.file.iface.FileExportService;
import com.hellobike.aicc.api.file.request.FileExportRecordRequest;
import com.hellobike.aicc.api.file.response.FileExportRecordResponse;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.file.dto.FileExportRecordConditionDTO;
import com.hellobike.aicc.domain.file.entity.FileExportRecordEntity;
import com.hellobike.aicc.domain.file.service.FileExportRecordDomainService;
import com.hellobike.aicc.web.convert.FileApiConvert;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Resource;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  15:11:51
 */
@Slf4j
@SoaService
public class FileExportServiceImpl implements FileExportService {

    @Resource
    private FileExportRecordDomainService exportRecordDomainService;

    @Resource
    private FileApiConvert fileApiConvert;

    @Override
    public Result<PageResult<FileExportRecordResponse>> pageRecord(FileExportRecordRequest request) {
        FileExportRecordConditionDTO conditionDTO = new FileExportRecordConditionDTO();
        conditionDTO.setBizType(request.getBizType());
        conditionDTO.setStatus(request.getStatus());
        conditionDTO.setCreateTimeStart(DateUtils.toLocalDateTime(request.getCreateTimeStart()));
        conditionDTO.setCreateTimeEnd(DateUtils.toLocalDateTime(request.getCreateTimeEnd()));

        PageResult<FileExportRecordEntity> result = exportRecordDomainService.pageRecord(conditionDTO, request.getPageNum(), request.getPageSize());
        if (result.isEmpty()){
            return Result.frontOk(PageResult.getEmptyPage(request.getPageNum(), request.getPageSize()));
        }
        PageResult<FileExportRecordResponse> pageResult = result.clonePageResult(fileApiConvert.convertList(result.getList()));
        return Result.frontOk(pageResult);
    }
}
