package com.hellobike.aicc.web.aop;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.exception.BusinessException;
import com.hellobike.aicc.web.util.ParamValidUtils;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;

@Slf4j
@Aspect
@Component
@Order(0)
public class SoaAspect {

    /**
     * SOA切面拦截异常处理ddd
     *
     * @param point 切点对象
     * @return SOA执行结果
     * @throws Throwable
     */
    @Around("within(@com.hellobike.soa.starter.spring.annotation.SoaService *)")
    public Object around(ProceedingJoinPoint point) throws Throwable {
        MethodSignature signature = (MethodSignature) point.getSignature();
        //请求的参数
        Method invokeMethod = point.getTarget().getClass().getDeclaredMethod(signature.getName(), signature.getMethod().getParameterTypes());
        Object result = null;
        try {
            validParam(point.getArgs());
            result = point.proceed();
            return result;
        } catch (BusinessException e) {
            log.error("SOA调用业务异常,method:{},errorCode:{}", invokeMethod.getName(), e.getBusinessErrorCode());
            result = Result.fail(e.getBusinessErrorCode(), e.getArgs());
            return result;
        } catch (Exception e) {
            log.error("SOA调用系统异常,method:{},e:", invokeMethod.getName(), e);
            result = Result.fail(BusinessErrorCode.COMMON_ERROR.getCode(), "系统异常，请稍后重试");
            return result;
        }
    }

    private void validParam(Object[] args) throws Exception {
        for (Object arg : args) {
            ParamValidUtils.validParam(arg);
        }
    }
}

