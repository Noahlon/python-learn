package com.hellobike.aicc.web.convert;

import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.api.sms.request.SmsRecordQueryRequest;
import com.hellobike.aicc.api.sms.response.SmsRecordResponse;
import com.hellobike.aicc.common.enums.SmsSendResultEnum;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordCondition;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-13  14:47:23
 */
@Mapper(componentModel = "spring", imports = {DateUtils.class, StrUtil.class, Long.class, SmsSendResultEnum.class})
public interface SmsRecordApiConvert {
    @Mappings({
            @Mapping(source = "supplierCallGuid", target = "callGuid"),
            @Mapping(target = "sendResultDesc", expression = "java(SmsSendResultEnum.getMsg(entity.getSendResult()))"),
            @Mapping(target = "sendTime", expression = "java(DateUtils.format(entity.getSendTime()) != null ? DateUtils.format(entity.getSendTime()) : \"\")"),
            @Mapping(target = "receiveResultTime", expression = "java(DateUtils.format(entity.getReceiveResultTime()))"),
            @Mapping(target = "createTime", expression = "java(DateUtils.format(entity.getCreateTime()))")
    })
    SmsRecordResponse entityToResp(SmsRecordEntity entity);

    List<SmsRecordResponse> entityToResp(List<SmsRecordEntity> entityList);

    @Mappings({
            @Mapping(target = "supplierCallGuid", source = "callGuid"),
            @Mapping(target = "createBeginTime",expression = "java(DateUtils.toLocalDateTime(request.getCreateBeginTime()))"),
            @Mapping(target = "createEndTime",expression = "java(DateUtils.toLocalDateTime(request.getCreateEndTime()))")
    })
    SmsRecordCondition convert(SmsRecordQueryRequest request);

    default String mapString(String value) {
        if (value == null) {
            return "";
        }
        return value;
    }
}
