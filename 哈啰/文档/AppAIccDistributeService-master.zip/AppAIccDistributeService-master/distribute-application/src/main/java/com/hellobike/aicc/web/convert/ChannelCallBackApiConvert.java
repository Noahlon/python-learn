package com.hellobike.aicc.web.convert;

import com.hellobike.aicc.api.callback.request.CallDialogueCallBackRequest;
import com.hellobike.aicc.api.callback.request.SmsRecordCallBackRequest;
import com.hellobike.aicc.domain.dialogue.dto.DialogueCallBackDTO;
import com.hellobike.aicc.domain.smsrecord.dto.SmsRecordCallBackDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ChannelCallBackApiConvert {
    SmsRecordCallBackDTO convertDto(SmsRecordCallBackRequest request);


    DialogueCallBackDTO convert(CallDialogueCallBackRequest request);
}
