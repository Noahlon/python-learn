package com.hellobike.aicc.web.convert;

import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.api.dialogue.request.DialogueListQueryRequest;
import com.hellobike.aicc.api.dialogue.response.DialogueDetailResponse;
import com.hellobike.aicc.api.dialogue.response.DialogueInfoResponse;
import com.hellobike.aicc.api.dialogue.response.DialogueSpeakResponse;
import com.hellobike.aicc.common.enums.CallResultEnum;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.dialogue.dto.CallDialogueQueryConditionDTO;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import com.hellobike.aicc.domain.dialogue.entity.DialogueSpeakEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-13  14:47:23
 */
@Mapper(componentModel = "spring", imports = {DateUtils.class, StrUtil.class, Long.class, CallResultEnum.class})
public interface CallDialogueApiConvert {

    @Mapping(target = "createTimeStart",expression = "java(DateUtils.toLocalDateTime(request.getCreateTimeStart()))")
    @Mapping(target = "createTimeEnd",expression = "java(DateUtils.toLocalDateTime(request.getCreateTimeEnd()))")
    @Mapping(target = "dialTimeStart",expression = "java(DateUtils.toLocalDateTime(request.getDialTimeStart()))")
    @Mapping(target = "dialTimeEnd",expression = "java(DateUtils.toLocalDateTime(request.getDialTimeEnd()))")
    @Mapping(target = "hangupTimeStart",expression = "java(DateUtils.toLocalDateTime(request.getHangupTimeStart()))")
    @Mapping(target = "hangupTimeEnd",expression = "java(DateUtils.toLocalDateTime(request.getHangupTimeEnd()))")
    CallDialogueQueryConditionDTO pageReqToDTO(DialogueListQueryRequest request);

    List<DialogueInfoResponse> entityToRespList(List<CallDialogueEntity> list);

    @Mapping(source = "supplierTaskTemplateId" ,target = "speechTemplateId")
    @Mapping(target = "createTime" ,expression = "java(DateUtils.format(entity.getCreateTime()))")
    @Mapping(target = "dialTime" ,expression = "java(DateUtils.format(entity.getDialTime()))")
    @Mapping(target = "hangupTime" ,expression = "java(DateUtils.format(entity.getHangupTime()))")
    @Mapping(target = "callResultDesc" ,expression = "java(CallResultEnum.getDescByCode(entity.getCallResult()))")
    DialogueInfoResponse entityToResp(CallDialogueEntity entity);

    @Mapping(target = "hangupTime" ,expression = "java(DateUtils.format(entity.getHangupTime()))")
    @Mapping(target = "answerTime" ,expression = "java(DateUtils.format(entity.getAnswerTime()))")
    DialogueDetailResponse entityToDetailResp(CallDialogueEntity entity);

    @Mapping(target = "speakTime" ,expression = "java(DateUtils.format(entity.getSpeakTime()))")
    DialogueSpeakResponse entityToSpeakResp(DialogueSpeakEntity entity);

    default String mapString(String value) {
        if (value == null) {
            return "";
        }
        return value;
    }
}
