package com.hellobike.aicc.web.convert;

import com.hellobike.aicc.api.distribute.plan.request.RetryCreateChannelTaskRequest;
import com.hellobike.aicc.api.distribute.plan.response.ChannelResponse;
import com.hellobike.aicc.domain.channel.dto.ChannelTaskRetryDTO;
import com.hellobike.aicc.domain.channel.entity.ChannelEntity;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ChannelApiConvert {
    List<ChannelResponse> convert(List<ChannelEntity> entityList);

    ChannelResponse convert(ChannelEntity entity);

    ChannelTaskRetryDTO convert(RetryCreateChannelTaskRequest request);
}
