package com.hellobike.aicc.web.service.callback;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.callback.iface.ChannelCallBackService;
import com.hellobike.aicc.api.callback.request.CallDialogueCallBackRequest;
import com.hellobike.aicc.api.callback.request.ChannelCallBackBaseRequest;
import com.hellobike.aicc.api.callback.request.SmsRecordCallBackRequest;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.dto.ChannelDialoguePushDTO;
import com.hellobike.aicc.domain.channel.dto.ChannelSmsPushDTO;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.channel.factory.ChannelInfo;
import com.hellobike.aicc.domain.channelcallback.service.CallbackService;
import com.hellobike.aicc.domain.common.service.DingTalkService;
import com.hellobike.aicc.domain.dialogue.dto.DialogueCallBackDTO;
import com.hellobike.aicc.domain.smsrecord.dto.SmsRecordCallBackDTO;
import com.hellobike.aicc.infrastructure.hms.producer.ChannelDialogueMsgProducer;
import com.hellobike.aicc.infrastructure.hms.producer.ChannelSmsRecordMsgProducer;
import com.hellobike.aicc.web.convert.ChannelCallBackApiConvert;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.Resource;

@SoaService
@Slf4j
public class ChannelCallBackServiceImpl implements ChannelCallBackService {

    @Resource
    private CallbackService callbackService;

    @Resource
    private ChannelCallBackApiConvert channelCallBackApiConvert;

    @Resource
    private DingTalkService dingTalkService;

    @Resource
    private ChannelDialogueMsgProducer channelDialogueMsgProducer;

    @Resource
    private ChannelSmsRecordMsgProducer channelSmsRecordMsgProducer;

    @Value("${channel.callback.async:true}")
    private boolean channelCallBackAsync;

    @Override
    public Result<Void> callDialogueCallBack(ChannelCallBackBaseRequest<CallDialogueCallBackRequest> request) {
        try {
            log.info("渠道商话单回调,req:{}", BaseJsonUtils.writeValue(request));
            AssertUtils.isTrue(request.getData() != null && request.getData().isValid(), "回调数据校验失败");
            ChannelInfo channel = ChannelFactory.getChannel(request.getAppKey());
            AssertUtils.isTrue(channel != null && channel.getIsEnable(), "渠道商不可用");
            DialogueCallBackDTO dialogueDTO = channelCallBackApiConvert.convert(request.getData());
            if (channelCallBackAsync) {
                ChannelDialoguePushDTO pushDTO = new ChannelDialoguePushDTO();
                pushDTO.setChannelId(channel.getChannelId());
                pushDTO.setDialogueCallBackDTO(dialogueDTO);
                channelDialogueMsgProducer.sendMsg(pushDTO);
            } else {
                callbackService.callDialogueCallBack(dialogueDTO, channel.getChannelId());
            }

        } catch (Exception e) {
            log.error("渠道商话单回调异常,e:", e);
            dingTalkService.sendDialogueFailedAlert(request.getAppKey());
            throw e;
        }

        return Result.frontOk();

    }

    @Override
    public Result<Void> smsRecordCallBack(ChannelCallBackBaseRequest<SmsRecordCallBackRequest> request) {
        try {
            log.info("渠道商短信记录回调,req:{}", BaseJsonUtils.writeValue(request));
            AssertUtils.isTrue(request.getData() != null && request.getData().isValid(), "回调数据校验失败");
            ChannelInfo channel = ChannelFactory.getChannel(request.getAppKey());
            AssertUtils.isTrue(channel != null && channel.getIsEnable(), "渠道商不可用");
            SmsRecordCallBackDTO dto = channelCallBackApiConvert.convertDto(request.getData());
            if (channelCallBackAsync) {
                ChannelSmsPushDTO pushDTO = new ChannelSmsPushDTO();
                pushDTO.setChannelId(channel.getChannelId());
                pushDTO.setSmsRecordCallBackDTO(dto);
                channelSmsRecordMsgProducer.sendMsg(pushDTO);
            } else {
                callbackService.smsRecordCallBack(dto, channel.getChannelId());
            }
        } catch (Exception e) {
            log.error("渠道商短信回调异常,e:", e);
            dingTalkService.sendSmsRecordFailedAlert(request.getAppKey());
            throw e;
        }
        return Result.frontOk();
    }
}
