package com.hellobike.aicc.web.service.distribute;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.distribute.upload.iface.DistributeUploadFileService;
import com.hellobike.aicc.api.distribute.upload.request.DistributeUploadFileQueryRequest;
import com.hellobike.aicc.api.distribute.upload.request.RosterUploadRequest;
import com.hellobike.aicc.api.distribute.upload.response.DistributeUploadFileResponse;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.RosterTypeEnum;
import com.hellobike.aicc.common.util.AssertUtils;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.distribute.entity.DistributeUploadFileEntity;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributeUploadFileCondition;
import com.hellobike.aicc.domain.distribute.service.DistUploadFileDomainService;
import com.hellobike.aicc.domain.roster.dto.RosterUploadDTO;
import com.hellobike.aicc.web.convert.DistributeUploadFileApiConvert;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Resource;

/**
 * 分发文件具体实现类
 *
 * @author zhushenghua
 */
@SoaService
@Slf4j
public class DistributeUploadFileServiceImpl implements DistributeUploadFileService {
    @Resource
    private DistUploadFileDomainService distUploadFileDomainService;
    @Resource
    private DistributeUploadFileApiConvert distributeUploadFileApiConvert;

    @Override
    public Result<Boolean> uploadRoster(RosterUploadRequest request) {
        RosterTypeEnum rosterTypeEnum = RosterTypeEnum.getByCode(request.getRosterType());
        AssertUtils.notNull(rosterTypeEnum, "名单类型错误");
        RosterUploadDTO rosterUploadDTO = new RosterUploadDTO();
        rosterUploadDTO.setDistributeId(request.getDistributePlanId());
        rosterUploadDTO.setFileUrl(request.getFileUrl());
        rosterUploadDTO.setFileName(request.getFileName());
        rosterUploadDTO.setOperator(request.get_user().getUserName());
        rosterUploadDTO.setRosterType(request.getRosterType());
        log.info("开始上传名单，参数信息：{}", BaseJsonUtils.writeValue(rosterUploadDTO));
        distUploadFileDomainService.uploadRoster(rosterUploadDTO);
        return Result.frontOk();
    }

    @Override
    public Result<PageResult<DistributeUploadFileResponse>> queryUploadFileList(DistributeUploadFileQueryRequest request) {
        DistributeUploadFileCondition condition = distributeUploadFileApiConvert.convert(request);
        PageResult<DistributeUploadFileEntity> entityPageResult = distUploadFileDomainService.queryUploadFileList(condition);
        return Result.frontOk(distributeUploadFileApiConvert.convert(entityPageResult));
    }
}
