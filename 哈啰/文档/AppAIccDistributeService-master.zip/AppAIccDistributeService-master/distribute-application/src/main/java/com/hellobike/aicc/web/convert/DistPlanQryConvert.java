package com.hellobike.aicc.web.convert;


import com.hellobike.aicc.api.distribute.plan.request.BusinessTaskStatReq;
import com.hellobike.aicc.domain.channel.service.DistPlanQryParam;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;


@Mapper(componentModel = "spring")
public interface DistPlanQryConvert {

    @Mappings({
            @Mapping(target = "planId", source = "taskId"),
            @Mapping(target = "planName", source = "taskName")
    })
    DistPlanQryParam convert(BusinessTaskStatReq param);
}
