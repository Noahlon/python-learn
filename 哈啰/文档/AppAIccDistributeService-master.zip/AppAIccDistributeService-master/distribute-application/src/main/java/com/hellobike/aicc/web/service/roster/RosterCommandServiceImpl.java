package com.hellobike.aicc.web.service.roster;

import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.roster.iface.RosterCommandFacadeService;
import com.hellobike.aicc.api.roster.request.RosterImportRequest;
import com.hellobike.aicc.api.roster.request.RosterRetryDistributeRequest;
import com.hellobike.aicc.api.roster.response.RosterImportResponse;
import com.hellobike.aicc.common.component.ApolloConfigs;
import com.hellobike.aicc.common.enums.RosterTypeEnum;
import com.hellobike.aicc.common.exception.BusinessErrorCode;
import com.hellobike.aicc.common.exception.BusinessException;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.roster.dto.RosterAPIImportDTO;
import com.hellobike.aicc.domain.roster.dto.RosterImportResultDTO;
import com.hellobike.aicc.domain.roster.dto.RosterRetryDistributeDTO;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.service.RosterDomainService;
import com.hellobike.aicc.web.convert.RosterApiConvert;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.DigestUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author zhangzhuoqi
 * @since 2025-03-07  16:27:34
 */
@SoaService
@Slf4j
public class RosterCommandServiceImpl implements RosterCommandFacadeService {

    @Resource
    private RosterApiConvert rosterApiConvert;

    @Resource
    private RosterDomainService rosterDomainService;

    @Resource
    private ApolloConfigs apolloConfigs;

    @Override
    public Result<Void> retryDistribute(RosterRetryDistributeRequest request) {
        RosterRetryDistributeDTO retryDistributeDTO = rosterApiConvert.retry2DTO(request);
        rosterDomainService.retryDistribute(retryDistributeDTO);
        return Result.frontOk();
    }

    @Override
    public Result<RosterImportResponse> importRoster(RosterImportRequest request) {
        if (request.getDataList().size() > apolloConfigs.getImportRosterLimit()){
            return Result.fail(BusinessErrorCode.IMPORT_SIZE_LIMIT_ERROR.getCode(),"导入名单数量不能超过" + apolloConfigs.getImportRosterLimit() + "条");
        }
        RosterImportResultDTO resultDTO = new RosterImportResultDTO();
        try {
            RosterAPIImportDTO reqDTO = new RosterAPIImportDTO();
            reqDTO.setTenantId(request.getTenantId());
            reqDTO.setDistributePlanId(request.getDistributePlanId());
            reqDTO.setRosterType(request.getRosterType());
            List<PlanRosterEntity> rosterList = request.getDataList().stream().map(it -> {
                PlanRosterEntity planRosterEntity = new PlanRosterEntity();
                planRosterEntity.setCustomerName(it.getName());
                planRosterEntity.setExternalId(it.getDataIdentifier());
                planRosterEntity.setVariableInfo(BaseJsonUtils.writeValue(it.getVariableInfos()));
                planRosterEntity.setRosterType(request.getRosterType());
                if (RosterTypeEnum.TELEPHONE.getCode().equals(request.getRosterType())) {
                    planRosterEntity.setPhoneNum(it.getPhone());
                    planRosterEntity.setMd5(StrUtil.isNotBlank(it.getPhone()) ? DigestUtils.md5DigestAsHex(it.getPhone().getBytes()) : null);
                } else if (RosterTypeEnum.MD5.getCode().equals(request.getRosterType())) {
                    planRosterEntity.setPhoneNum(StrUtil.isNotBlank(it.getPhone()) ? it.getPhone().toLowerCase() : null);
                    planRosterEntity.setMd5(StrUtil.isNotBlank(it.getPhone()) ? it.getPhone().toLowerCase() : null);
                }
                planRosterEntity.setDistributePlanId(Long.valueOf(request.getDistributePlanId()));
                return planRosterEntity;
            }).collect(Collectors.toList());
            reqDTO.setRosterEntityList(rosterList);

            resultDTO = rosterDomainService.apiImportRoster(reqDTO);
        }catch (BusinessException e){
            log.error("接口上传名单业务异常，e:",e);
            return Result.fail(e.getBusinessErrorCode());
        }catch (Exception e){
            log.error("接口上传名单异常，e:",e);
            resultDTO.setFailCount(request.getDataList().size());
            resultDTO.setSuccessCount(0);
            resultDTO.setDuplicationCount(0);
        }


        return Result.ok(rosterApiConvert.importIface2Res(resultDTO));
    }
}
