package com.hellobike.aicc.web.convert;

import com.hellobike.aicc.api.distribute.plan.dto.DistributeRule;
import com.hellobike.aicc.domain.distribute.entity.DistributeRuleEntity;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface DistributeRuleConvert {
    List<DistributeRuleEntity> convert(List<DistributeRule> ruleResponse);
}