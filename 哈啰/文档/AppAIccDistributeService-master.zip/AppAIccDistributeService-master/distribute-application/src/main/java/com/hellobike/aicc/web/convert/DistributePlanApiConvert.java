package com.hellobike.aicc.web.convert;

import com.hellobike.aicc.api.distribute.plan.dto.DistributePlan;
import com.hellobike.aicc.api.distribute.plan.dto.DistributeRule;
import com.hellobike.aicc.api.distribute.plan.dto.ExternalDistributePlan;
import com.hellobike.aicc.api.distribute.plan.request.DistributePlanQueryRequest;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributeRuleEntity;
import com.hellobike.aicc.domain.distribute.repo.condition.DistributePlanQueryCondition;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring")
public interface DistributePlanApiConvert {
    @Mappings({
            @Mapping(target = "templateId", source = "distributePlanTemplateId")
    })
    DistributePlanEntity convert(DistributePlan request);

    @Mappings({
            @Mapping(target = "templateId", source = "distributePlanTemplateId")
    })
    DistributePlanEntity convert(ExternalDistributePlan request);

    DistributeRuleEntity convert(DistributeRule request);


    DistributePlanQueryCondition convert(DistributePlanQueryRequest request);

    PageResult<DistributePlan> convert(PageResult<DistributePlanEntity> page);

    @Mappings({
            @Mapping(target = "createTime", source = "createTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(target = "distributePlanTemplateId", source = "templateId"),
            @Mapping(target = "distributePlanTemplateName", source = "templateName")
    })
    DistributePlan convert(DistributePlanEntity entity);

    List<DistributeRule> convert(List<DistributeRuleEntity> entityList);
}
