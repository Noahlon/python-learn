package com.hellobike.aicc.web.convert;

import com.hellobike.aicc.api.common.response.OSSAuthorizeResponse;
import com.hellobike.aicc.api.common.response.OssTokenResponse;
import com.hellobike.aicc.domain.common.dto.OSSAuthorizeDTO;
import com.hellobike.aicc.domain.common.dto.STSTicketDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface OssTokenApiConvert {
    OssTokenResponse convert(STSTicketDTO ticket);

    OSSAuthorizeResponse convert(OSSAuthorizeDTO authorize);
}
