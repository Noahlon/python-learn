package com.hellobike.aicc.web.convert;

import cn.hutool.core.util.StrUtil;
import com.hellobike.aicc.api.roster.request.RosterDistributeQueryRequest;
import com.hellobike.aicc.api.roster.request.RosterRetryDistributeRequest;
import com.hellobike.aicc.api.roster.request.RosterUploadQueryRequest;
import com.hellobike.aicc.api.roster.response.RosterDistributeRecordResponse;
import com.hellobike.aicc.api.roster.response.RosterImportResponse;
import com.hellobike.aicc.api.roster.response.RosterUploadRecordResponse;
import com.hellobike.aicc.common.enums.RosterTypeEnum;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.roster.dto.DistributeRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.dto.RosterImportResultDTO;
import com.hellobike.aicc.domain.roster.dto.RosterRetryDistributeDTO;
import com.hellobike.aicc.domain.roster.dto.UploadRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.DistributeRecordEntity;
import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.util.DigestUtils;

import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-07  16:38:44
 */
@Mapper(componentModel = "spring",imports = {ChannelFactory.class, BaseJsonUtils.class, DigestUtils.class, StrUtil.class, RosterTypeEnum.class})
public interface RosterApiConvert {
    UploadRecordQueryConditionDTO uploadRecordQueryReqToDTO(RosterUploadQueryRequest request);

    @Mapping(target = "uploadTime", source = "uploadTime", dateFormat = "yyyy-MM-dd HH:mm:ss")
    @Mapping(target = "rosterTypeDesc", expression = "java(RosterTypeEnum.getMsgByCode(entity.getRosterType()))")
    RosterUploadRecordResponse uploadRecordEntityToRes(UploadRecordEntity entity);

    @Mapping(target = "uploadTime", source = "uploadTime", dateFormat = "yyyy-MM-dd HH:mm:ss")
    List<RosterUploadRecordResponse> uploadRecordEntityToResList(List<UploadRecordEntity> entityList);


    @Mapping(source = "taskName", target = "supplierTaskName")
    DistributeRecordQueryConditionDTO distributeRecordQueryReqToDTO(RosterDistributeQueryRequest request);

    @Mapping(source = "supplierTaskName", target = "taskName")
    @Mapping(source = "supplierTaskId", target = "taskId")
    @Mapping(target = "channelName", expression = "java(entity.getChannelId() == null ? null : ChannelFactory.getNameById(entity.getChannelId()))")
    @Mapping(target = "distributeTime", source = "distributeTime", dateFormat = "yyyy-MM-dd HH:mm:ss")
    RosterDistributeRecordResponse distributeRecordEntityToRes(DistributeRecordEntity entity);

    List<RosterDistributeRecordResponse> distributeRecordEntityToResList(List<DistributeRecordEntity> entityList);

    RosterRetryDistributeDTO retry2DTO(RosterRetryDistributeRequest request);


    RosterImportResponse importIface2Res(RosterImportResultDTO resultDTO);
}
