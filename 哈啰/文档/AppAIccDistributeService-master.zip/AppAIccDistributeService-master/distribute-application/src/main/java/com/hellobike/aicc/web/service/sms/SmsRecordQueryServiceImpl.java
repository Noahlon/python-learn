package com.hellobike.aicc.web.service.sms;

import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.sms.iface.SmsRecordQueryService;
import com.hellobike.aicc.api.sms.request.SmsRecordQueryRequest;
import com.hellobike.aicc.api.sms.response.SmsRecordResponse;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordCondition;
import com.hellobike.aicc.domain.smsrecord.entity.SmsRecordEntity;
import com.hellobike.aicc.domain.smsrecord.service.SmsDomainService;
import com.hellobike.aicc.web.convert.SmsRecordApiConvert;
import com.hellobike.soa.starter.spring.annotation.SoaService;

import javax.annotation.Resource;

@SoaService
public class SmsRecordQueryServiceImpl implements SmsRecordQueryService {
    @Resource
    private SmsRecordApiConvert smsRecordApiConvert;

    @Resource
    private SmsDomainService smsDomainService;

    @Override
    public Result<PageResult<SmsRecordResponse>> querySmsRecords(SmsRecordQueryRequest request) {
        SmsRecordCondition condition = smsRecordApiConvert.convert(request);
        PageResult<SmsRecordEntity> pageResult = smsDomainService.pageQuerySmsRecord(condition);
        if (pageResult.isEmpty()) {
            return Result.frontOk(PageResult.getEmptyPage(request.getPageNum(), request.getPageSize()));
        }
        PageResult<SmsRecordResponse> result = pageResult.clonePageResult(smsRecordApiConvert.entityToResp(pageResult.getList()));
        return Result.frontOk(result);
    }

    @Override
    public Result<Void> export(SmsRecordQueryRequest request) {
        SmsRecordCondition condition = smsRecordApiConvert.convert(request);
        String operator = request.get_user().getRealName();
        smsDomainService.export(condition, operator);
        return Result.frontOk();
    }
}
