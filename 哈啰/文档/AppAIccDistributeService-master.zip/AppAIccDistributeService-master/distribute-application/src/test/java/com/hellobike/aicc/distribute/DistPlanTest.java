package com.hellobike.aicc.distribute;

import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import com.hellobike.aicc.BaseTest;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.distribute.plan.dto.DistributePlan;
import com.hellobike.aicc.api.distribute.plan.dto.DistributeRule;
import com.hellobike.aicc.api.distribute.plan.dto.ExternalDistributePlan;
import com.hellobike.aicc.api.distribute.plan.iface.DistributePlanService;
import com.hellobike.aicc.api.distribute.plan.request.DistributePlanQueryRequest;
import com.hellobike.aicc.api.roster.iface.RosterCommandFacadeService;
import com.hellobike.aicc.api.roster.request.RosterImportDataRequest;
import com.hellobike.aicc.api.roster.request.RosterImportRequest;
import com.hellobike.aicc.api.roster.response.RosterImportResponse;
import com.hellobike.aicc.common.basic.BffLogin;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.infrastructure.job.ChannelTaskDataFixJob;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author fanxiaodongwb230
 */
@Slf4j
public class DistPlanTest extends BaseTest {
    @Resource
    private RosterCommandFacadeService rosterCommandFacadeService;
    @Resource
    private DistributePlanService service;

    @Resource
    private ChannelTaskDataFixJob channelTaskDataFixJob;

    @Test
    public void testCreateChannelTask() {
        ExternalDistributePlan request = new ExternalDistributePlan();
        BffLogin user = new BffLogin();
        user.setUserName("fanxiaodongwb230@hellobike.com");
        user.setRealName("樊晓东");
        user.setEmail("fanxiaodongwb230@hellobike.com");
        request.set_user(user);
        request.setDistributePlanTemplateId("7312332512586956801");
        request.setDistributePlanName("测试计划分流到渠道商");
        request.setTenantCode("11625");
        request.setTenantName("VK-11625-分流平台租户");
        request.setDistributeType(1);
        List<DistributeRule> ruleList = new ArrayList<>();
        DistributeRule rule = new DistributeRule();
        rule.setChannelId(2);
        rule.setChannelName("驰必准AI外呼");
        rule.setPercentage("100");
        rule.setTaskTemplateId("20250426000001");
        rule.setTaskTemplateName("MockTemplate_1");
        ruleList.add(rule);
        request.setDistributeRuleList(ruleList);

        Result<String> result = service.createExternalDistributePlan(request);
        log.info("res:{}", result);
    }


    @Test
    public void testImport() throws InterruptedException {

        for (int i = 0; i < 1; i++) {
            List<RosterImportDataRequest> dataRequestList = new ArrayList<>();
            RosterImportRequest request = new RosterImportRequest();
            request.setTenantId("11625");
            request.setDistributePlanId("7312332761695125505");
            request.setRosterType(1);

            int count = 5;
            for (int j = 0; j < 10; j++) {
                count++;
                String phoneStr;
                long phone;
                if (count < 3){
                    phone = 13500010050L;
                }else {
                    phone = 13600010050L;
                }
                phoneStr = (phone+j)+"";
                RosterImportDataRequest dataRequest = new RosterImportDataRequest();
                //dataRequest.setPhone(DigestUtils.md5DigestAsHex(phoneStr.getBytes()));
                dataRequest.setPhone(phoneStr);
                dataRequest.setName(RandomUtil.randomString(4));
                dataRequest.setDataIdentifier(IdUtil.fastSimpleUUID());
                Map<String, String> map = new HashMap<>();
                map.put("k1", "v1");
                map.put("k2", "v2");
                dataRequest.setVariableInfos(map);
                dataRequestList.add(dataRequest);
                System.out.println(BaseJsonUtils.writeValue(dataRequestList));
            }
            request.setDataList(dataRequestList);

            Result<RosterImportResponse> res = rosterCommandFacadeService.importRoster(request);
            log.info("res:{}", res);
        }
        while (true) {
            Thread.sleep(50);
        }
    }

    @Test
    public void pageTest(){
        for (int i = 0; i < 5; i++) {
            DistributePlanQueryRequest request = new DistributePlanQueryRequest();
            request.setPageNum(1);
            request.setPageSize(100);
            //request.setPlanTemplateName("0426_s1");
            //request.setPlanTemplateId("7312311864530239489");
            request.setSupplierTemplateName("分流平台");
            request.setSupplierTemplateId("6206765614338933850");
            Result<PageResult<DistributePlan>> pageResultResult = service.pageQueryDistributePlan(request);
            log.info("pageResultResult:{}", pageResultResult);
        }

    }

    @Test
    public void taskFix(){
        channelTaskDataFixJob.trigger(null);
    }
}
