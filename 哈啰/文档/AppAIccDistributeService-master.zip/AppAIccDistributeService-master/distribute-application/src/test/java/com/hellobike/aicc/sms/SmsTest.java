package com.hellobike.aicc.sms;

import cn.hutool.core.util.IdUtil;
import com.google.common.collect.Lists;
import cn.hutool.core.thread.ThreadUtil;
import com.hellobike.aicc.BaseTest;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.callback.iface.ChannelCallBackService;
import com.hellobike.aicc.api.callback.request.ChannelCallBackBaseRequest;
import com.hellobike.aicc.api.callback.request.SmsRecordCallBackRequest;
import com.hellobike.aicc.api.sms.iface.SmsRecordQueryService;
import com.hellobike.aicc.api.sms.request.SmsRecordQueryRequest;
import com.hellobike.aicc.api.sms.response.SmsRecordResponse;
import com.hellobike.aicc.common.basic.BffLogin;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.SmsSendResultEnum;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.roster.dto.RosterQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.repo.PlanRosterRepository;
import com.hellobike.aicc.domain.smsrecord.service.SmsDomainService;
import com.hellobike.aicc.infrastructure.es.smsrecord.po.SmsRecordESPO;
import com.hellobike.aicc.infrastructure.es.smsrecord.repository.SmsRecordESRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-11  10:11:48
 */
@Slf4j
public class SmsTest extends BaseTest {
    @Resource
    private SmsRecordQueryService smsRecordQueryService;

    @Resource
    PlanRosterRepository planRosterRepository;

    @Resource
    ChannelCallBackService channelCallBackService;

    @Resource
    IdGeneratorService idGeneratorService;

    @Resource
    SmsRecordESRepository smsRecordESRepository;

    @Resource
    private SmsDomainService smsDomainService;

    @Test
    public void testQuery() {
        SmsRecordQueryRequest request = new SmsRecordQueryRequest();
        Result<PageResult<SmsRecordResponse>> pageResultResult = smsRecordQueryService.querySmsRecords(request);
        System.out.println(pageResultResult);
    }

    @Test
    public void testQuery2() {
        List<PlanRosterEntity> entityList = planRosterRepository.queryByCondition(7320820922772226049L, new RosterQueryConditionDTO());
        for (int i = 1; i < 2; i++) {
            PlanRosterEntity roster = entityList.get(i);
            ChannelCallBackBaseRequest<SmsRecordCallBackRequest> request = new ChannelCallBackBaseRequest<>();
            request.setAppKey("caoweicode-WWmJQ8Tb");
            SmsRecordCallBackRequest data = new SmsRecordCallBackRequest();
            data.setSmsId(idGeneratorService.getStringId());
            data.setTaskId("7320820922772226049");
            data.setTaskName("测试流程-20250612135655");
            data.setDialogueGuid(idGeneratorService.getStringId());
            data.setRosterKey(roster.getId() + "-" + "7320820922772226049");
            data.setPhoneNumber(roster.getPhoneNum());
            data.setMd5(roster.getMd5());
            data.setProvince("湖北");
            data.setCity("武汉");
            data.setCarrier(3);
            data.setSignature("[韵达]");
            data.setContent("快递领取呀");
            data.setSubmitResult(1);
            data.setSubmitTime(DateUtils.getDateTimeString(LocalDateTime.now()));
            data.setSendResult(SmsSendResultEnum.UNKNOWN.getCode());
            data.setSendTime(DateUtils.getDateTimeString(LocalDateTime.now()));
            data.setBillingNum(2);
            data.setEnterpriseId(String.valueOf(i));
            request.setData(data);
            Result<Void> voidResult = channelCallBackService.smsRecordCallBack(request);
            log.info("res:{}",voidResult);
        }
    }

    @Test
    public void save2Es(){
        List<SmsRecordESPO> list = new ArrayList<>();
        for (int i = 0; i < 510000; i++) {
            SmsRecordESPO smsRecordESPO = new SmsRecordESPO();
            smsRecordESPO.setGuid((long) i);
            smsRecordESPO.setRosterId(123L);
            smsRecordESPO.setPlatformId(IdUtil.fastSimpleUUID());
            smsRecordESPO.setChannelId(1);
            smsRecordESPO.setChannelName("哈啰AI外呼");
            smsRecordESPO.setExternalId(IdUtil.fastSimpleUUID());
            long phone = 1500000000 + i;
            smsRecordESPO.setPhoneNumber(phone+"");
            smsRecordESPO.setPhoneNumberMd5(IdUtil.fastSimpleUUID());
            smsRecordESPO.setDistributePlanId(123555L);
            smsRecordESPO.setChannelTaskId(123999L);
            smsRecordESPO.setDistributePlanName("测试计划");
            smsRecordESPO.setDistributePlanCallId(1234L);
            smsRecordESPO.setSupplierTaskId("1");
            smsRecordESPO.setSupplierTaskName("test");
            smsRecordESPO.setEnterpriseId("1");
            smsRecordESPO.setSpeechName("test");
            smsRecordESPO.setTenantCode("123490");
            smsRecordESPO.setSignature("签名");
            smsRecordESPO.setContent("哈哈哈测试");
            smsRecordESPO.setSubmitTime("2025-05-27 00:00:00");
            smsRecordESPO.setSubmitResult(1);
            smsRecordESPO.setSendTime("2025-05-27 00:00:00");
            smsRecordESPO.setSendResult(1);
            smsRecordESPO.setReceiveResultTime("2025-05-27 00:00:00");
            smsRecordESPO.setBillingNum(1);
            smsRecordESPO.setSeatsGuid(null);
            smsRecordESPO.setSeatsName(null);
            smsRecordESPO.setCustomName("zzq");
            smsRecordESPO.setSupplierCallGuid("1");
            smsRecordESPO.setSupplierSmsGuid(i+"");
            smsRecordESPO.setCarrier(1);
            smsRecordESPO.setProvince("湖北");
            smsRecordESPO.setCity("武汉");
            smsRecordESPO.setCreateTime("2025-05-27 14:00:00");
            smsRecordESPO.setUpdateTime("2025-05-27 14:00:00");
            smsRecordESPO.setIsDelete(0);
            list.add(smsRecordESPO);
        }
        for (List<SmsRecordESPO> smsRecordESPOS : Lists.partition(list, 1000)) {
            boolean save = smsRecordESRepository.save(smsRecordESPOS, LocalDateTime.now());
            log.info("res:{}",save);
        }

    }

    @Test
    public void testExort() {
        SmsRecordQueryRequest request = new SmsRecordQueryRequest();
        request.setCreateBeginTime("2025-05-14 00:00:00");
        request.setCreateEndTime("2025-05-20 23:59:59");
        BffLogin bffLogin = new BffLogin();
        bffLogin.setRealName("zzq");
        request.set_user(bffLogin);
        Result<Void> export = smsRecordQueryService.export(request);
        log.info("res:{}",export);
        while (true){
            ThreadUtil.sleep(500);
        }
    }

    @Test
    public void checkSmsStatus(){
        smsDomainService.checkSmsStatus();
    }
}
