package com.hellobike.aicc.callback;

import com.hellobike.aicc.BaseTest;
import com.hellobike.aicc.api.callback.dto.DialogueSpeak;
import com.hellobike.aicc.api.callback.iface.ChannelCallBackService;
import com.hellobike.aicc.api.callback.request.CallDialogueCallBackRequest;
import com.hellobike.aicc.api.callback.request.ChannelCallBackBaseRequest;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.util.DigestUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-06  17:22:11
 */
@Slf4j
public class ChannelCallBackTest extends BaseTest {
    @Resource
    private ChannelCallBackService channelService;

    @Test
    public void callbackDialogue() {
        /**
         * appKey:hello_ai_call
         * channelId:1
         * appKey:qwer-hhhhhkkk
         * channelId:2
         */

        ChannelCallBackBaseRequest<CallDialogueCallBackRequest> request = new ChannelCallBackBaseRequest<CallDialogueCallBackRequest>();
        String calledNumber = "13600010050";
        request.setAppKey("qwer-hhhhhkkk");
        CallDialogueCallBackRequest data = new CallDialogueCallBackRequest();
        List<DialogueSpeak> speakList = new ArrayList<>();
        DialogueSpeak dialogueSpeak = new DialogueSpeak();
        dialogueSpeak.setSpeakId("1");
        dialogueSpeak.setSpeakContent("你好");
        dialogueSpeak.setSpeaker(1);
        dialogueSpeak.setSpeakTime("2025-03-06 17:22:11.222");
        speakList.add(dialogueSpeak);
        data.setRosterKey("7312333468217311240-7312332761695125505");
        data.setSpeakList(speakList);
        data.setEnterpriseId("1");
        data.setCalledNumber(calledNumber);
        data.setCallResult(18);
        data.setDialogueGuid("202504271909002");
        data.setAnswerTime("2025-03-06 17:22:11.222");
        data.setMd5(DigestUtils.md5DigestAsHex(calledNumber.getBytes()));
        request.setData(data);
        channelService.callDialogueCallBack(request);
        log.info("话单回调参数：", BaseJsonUtils.writeValue(request));


    }
}
