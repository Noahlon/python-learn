package com.hellobike.aicc.distribute;

import com.hellobike.aicc.BaseTest;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.file.iface.FileExportService;
import com.hellobike.aicc.api.file.request.FileExportRecordRequest;
import com.hellobike.aicc.api.file.response.FileExportRecordResponse;
import com.hellobike.aicc.common.basic.PageResult;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import javax.annotation.Resource;

/**
 * @author zhangzhuoqi
 * @since 2025-05-22  15:23:43
 */
@Slf4j
public class FileTest extends BaseTest {

    @Resource
    private FileExportService fileExportService;

    @Test
    public void page(){
        for (int i = 0; i < 10; i++) {
            FileExportRecordRequest request = new FileExportRecordRequest();
            request.setBizType(null);
            request.setStatus(null);
            request.setCreateTimeStart(null);
            request.setCreateTimeEnd(null);
            request.setPageSize(50);
            request.setPageNum(1);

            Result<PageResult<FileExportRecordResponse>> pageResultResult = fileExportService.pageRecord(request);
            log.info("res:{}", pageResultResult);
        }

    }
}
