package com.hellobike.aicc.distribute;

import com.hellobike.aicc.BaseTest;
import com.hellobike.aicc.api.distribute.plan.iface.DistributePlanService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import javax.annotation.Resource;

/**
 * @author zhangzhuoqi
 * @since 2025-03-06  17:22:11
 */
@Slf4j
public class DistributeCommandTest extends BaseTest {

    @Resource
    private DistributePlanService distributeCommandFacadeService;

    @Test
    public void test(){
    }
}
