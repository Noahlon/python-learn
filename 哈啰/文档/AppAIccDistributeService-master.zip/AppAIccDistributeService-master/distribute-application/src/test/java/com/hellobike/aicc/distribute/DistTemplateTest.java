package com.hellobike.aicc.distribute;

import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import com.hellobike.aicc.BaseTest;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.distribute.plan.dto.DistributeRule;
import com.hellobike.aicc.api.distribute.plan.dto.ExternalDistributePlan;
import com.hellobike.aicc.api.distribute.plan.iface.DistributePlanService;
import com.hellobike.aicc.api.distribute.template.iface.DistributePlanTemplateService;
import com.hellobike.aicc.api.distribute.template.request.CommonPlanTemplateRequest;
import com.hellobike.aicc.api.distribute.template.request.CopyTemplateResponse;
import com.hellobike.aicc.api.distribute.template.request.DistributePlanTemplateRequest;
import com.hellobike.aicc.api.roster.iface.RosterCommandFacadeService;
import com.hellobike.aicc.api.roster.request.RosterImportDataRequest;
import com.hellobike.aicc.api.roster.request.RosterImportRequest;
import com.hellobike.aicc.api.roster.response.RosterImportResponse;
import com.hellobike.aicc.common.basic.BffLogin;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author fanxiaodongwb230
 */
@Slf4j
public class DistTemplateTest extends BaseTest {

    @Resource
    private DistributePlanTemplateService service;

  /*  {"templateId":"1000001","templateName":"分流计划模版6","tenantCode":"00005","tenantName":"租户1","distributeType":1,distributeRuleList:[
        {"channelId":10001,"channelName":"渠道1","percentage":"50","taskTemplateId":"10001","taskTemplateName":"任务模版1"},
        {"channelId":1002,"channelName":"渠道2","percentage":"50","taskTemplateId":"10002","taskTemplateName":"任务模版2"}],"_user":{"userName":"test","realName":" 张三","email":"test@163.com","jobnumber":"5"}}*/

    @Test
    public void testCreateTemplate() {
        DistributePlanTemplateRequest request = new DistributePlanTemplateRequest();
        BffLogin user = new BffLogin();
        user.setUserName("fanxiaodongwb230@hellobike.com");
        user.setRealName("樊晓东");
        user.setEmail("fanxiaodongwb230@hellobike.com");
        request.set_user(user);
        request.setTenantCode("11625");
        request.setTenantName("VK-11625-分流平台租户");
        request.setTemplateName("测试模板-用于测试渠道-0426_2");
        request.setDistributeType(1);
        List<DistributeRule> ruleList = new ArrayList<>();
        DistributeRule rule = new DistributeRule();
        rule.setChannelId(2);
        rule.setChannelName("驰必准AI外呼");
        rule.setPercentage("100");
        rule.setTaskTemplateId("20250426000001");
        rule.setTaskTemplateName("MockTemplate_1");
        ruleList.add(rule);
        request.setDistributeRuleList(ruleList);
        Result<String> result = service.createPlanTemplate(request);
        log.info("res:{}", result);
    }

    @Test
    public void testCopyTemplate() {
        CommonPlanTemplateRequest req = new CommonPlanTemplateRequest();
        req.setTemplateId("7316720854633545752");
        for (int i = 0; i < 5; i++) {
            Result<CopyTemplateResponse> copyTemplateResponseResult = service.copyTemplate(req);
            log.info("res:{}", copyTemplateResponseResult);
        }

    }


}
