package com.hellobike.aicc.distribute;

import com.hellobike.aicc.BaseTest;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.distribute.plan.iface.ChannelService;
import com.hellobike.aicc.api.distribute.plan.request.ChannelQueryRequest;
import com.hellobike.aicc.api.distribute.plan.request.RetryCreateChannelTaskRequest;
import com.hellobike.aicc.api.distribute.plan.response.ChannelResponse;
import com.hellobike.aicc.common.basic.BffLogin;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-06  17:22:11
 */
@Slf4j
public class ChannelTest extends BaseTest {
    @Resource
    private ChannelService channelService;

    @Test
    public void test() {
        RetryCreateChannelTaskRequest request = new RetryCreateChannelTaskRequest();
        request.setPlanChannelTaskId("7305023663600041985");
        BffLogin user = new BffLogin();
        user.setUserName("panlongqian044@hellobike.com");
        user.setRealName("潘龙骞");
        user.setEmail("panlongqian044@hellobike.com");
        request.set_user(user);
        Result<Void> voidResult = channelService.retryCreateChannelTask(request);
        System.out.println(voidResult);
    }

    @Test
    public void testChannelDetail() {
        ChannelQueryRequest request = new ChannelQueryRequest();
        BffLogin user = new BffLogin();
        user.setUserName("fanxiaodongwb230@hellobike.com");
        user.setRealName("樊晓东");
        user.setEmail("fanxiaodongwb230@hellobike.com");
        request.set_user(user);
        List<Integer> channelIdList = new ArrayList<>();
        channelIdList.add(2);
        request.setChannelIdList(channelIdList);
        Result<List<ChannelResponse>> result = channelService.queryChannelDetail(request);
        log.info("res:{}", result);
    }
}
