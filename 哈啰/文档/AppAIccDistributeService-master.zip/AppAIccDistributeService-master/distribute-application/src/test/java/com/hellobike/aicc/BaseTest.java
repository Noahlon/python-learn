package com.hellobike.aicc;

import com.hellobike.aicc.web.AppAIccDistributeServiceApplication;
import com.hellobike.base.basicconf.client.BasicConfClientBuilder;
import com.hellobike.css.ai.api.base.BffLogin;
import com.hellobike.es.sdk.common.EsApplication;
import lombok.extern.slf4j.Slf4j;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;


@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {AppAIccDistributeServiceApplication.class})
public class BaseTest {
    static {
        System.setProperty("env", "fat");
        System.setProperty("APPID", "AppAIccDistributeService");
        System.setProperty("apollo.meta", "http://fat-apollometa.hellobike.cn:10080");
        System.setProperty("basicConf.host", "https://fat-basicconf.hellobike.cn");
        System.setProperty("kms.host", "https://fat-kms-service.hellobike.cn");
        System.setProperty("dbManagerUrl", "http://uat-dbmanageservice-inner.hellobike.cn");
        //HMS消息摘除
        System.setProperty("hms-consumer-suspend", "true");

        try{
            BasicConfClientBuilder builder = new BasicConfClientBuilder();
            //7初始化
            EsApplication.start(builder.build());
        }catch (IOException e){
            log.error("EsApplication start exception!", e);
        }

//        System.setProperty("kms.host", "https://fat-kms-service.hellobike.cn");
//        System.setProperty("dbManagerUrl", "http://uat-dbmanageservice-inner.hellobike.cn");
        // -Denv=fat -DAPPID=AppAIccDistributeService -Dapollo.meta=http://fat-apollometa.hellobike.cn:10080 -DbasicConf.host=https://fat-basicconf.hellobike.cn  -Dkms.host=https://fat-kms-service.hellobike.cn -DdbManagerUrl=http://uat-dbmanageservice-inner.hellobike.cn
    }

    public BffLogin mockBffLogin(){
        BffLogin bffLogin = new BffLogin();
        bffLogin.setUserName("test");
        bffLogin.setRealName("test");
        bffLogin.setEmail(null);
        return bffLogin;
    }



}
