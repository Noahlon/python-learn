package com.hellobike.aicc.roster;

import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.http.HttpUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.write.style.column.LongestMatchColumnWidthStyleStrategy;
import com.alibaba.fastjson.JSONObject;
import com.hellobike.aicc.BaseTest;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.roster.iface.RosterCommandFacadeService;
import com.hellobike.aicc.api.roster.iface.RosterQueryFacadeService;
import com.hellobike.aicc.api.roster.request.RosterDistributeQueryRequest;
import com.hellobike.aicc.api.roster.request.RosterImportDataRequest;
import com.hellobike.aicc.api.roster.request.RosterImportRequest;
import com.hellobike.aicc.api.roster.request.RosterTemplateRequest;
import com.hellobike.aicc.api.roster.request.RosterUploadQueryRequest;
import com.hellobike.aicc.api.roster.response.RosterDistributeRecordResponse;
import com.hellobike.aicc.api.roster.response.RosterImportResponse;
import com.hellobike.aicc.api.roster.response.RosterUploadRecordResponse;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.DistributeRecordTypeEnum;
import com.hellobike.aicc.common.enums.DistributeStatusEnum;
import com.hellobike.aicc.common.enums.UploadStatusEnum;
import com.hellobike.aicc.common.enums.UploadTypeEnum;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.channel.entity.DistributeChannelTaskEntity;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.distribute.entity.DistributePlanEntity;
import com.hellobike.aicc.domain.distribute.entity.DistributeRuleEntity;
import com.hellobike.aicc.domain.distribute.repo.DistChannelTaskRepo;
import com.hellobike.aicc.domain.distribute.repo.DistPlanRepo;
import com.hellobike.aicc.domain.distribute.service.DistCalService;
import com.hellobike.aicc.domain.roster.dto.DistributeRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.dto.RosterRetryDistributeDTO;
import com.hellobike.aicc.domain.roster.dto.UploadRecordQueryConditionDTO;
import com.hellobike.aicc.domain.roster.entity.DistributeRecordEntity;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.entity.UploadRecordEntity;
import com.hellobike.aicc.domain.roster.repo.DistributeRecordRepository;
import com.hellobike.aicc.domain.roster.repo.PlanRosterRepository;
import com.hellobike.aicc.domain.roster.repo.UploadRecordRepository;
import com.hellobike.aicc.domain.roster.service.RosterDomainService;
import com.hellobike.aicc.domain.roster.service.excel.RosterImportVO;
import com.hellobike.aicc.domain.utils.oss.OSSUtils;
import com.hellobike.aicc.infrastructure.es.roster.po.PlanRosterESPO;
import com.hellobike.aicc.infrastructure.es.roster.repository.RosterEsContainer;
import com.hellobike.aicc.infrastructure.job.RosterAggDistributeJob;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import javax.annotation.Resource;
import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author zhangzhuoqi
 * @since 2025-03-11  10:11:48
 */
@Slf4j
public class RosterTest extends BaseTest {

    @Resource
    private UploadRecordRepository uploadRecordRepository;

    @Resource
    private DistributeRecordRepository distributeRecordRepository;

    @Resource
    private IdGeneratorService idGeneratorService;

    @Resource
    private RosterDomainService rosterDomainService;

    @Resource
    private RosterQueryFacadeService rosterQueryFacadeService;

    @Resource
    private RosterCommandFacadeService rosterCommandFacadeService;

    @Resource
    private OSSUtils ossUtils;

    @Resource
    private PlanRosterRepository planRosterRepository;

    @Resource
    private DistCalService distCalService;

    @Resource
    private DistPlanRepo distPlanRepo;

    @Resource
    private DistChannelTaskRepo distChannelTaskRepo;

    @Resource
    RosterAggDistributeJob rosterAggDistributeJob;

    @Resource
    RosterEsContainer rosterEsContainer;

    @Test
    public void testAddUploadRecord() {
        Long distributePlanId = idGeneratorService.getLongId();
        log.info("id:{}", distributePlanId);
        /*for (int i = 0; i < 15; i++) {
            UploadRecordEntity entity = new UploadRecordEntity();
            entity.setId(idGeneratorService.getLongId());
            entity.setUploadType(UploadTypeEnum.MANUAL.getCode());
            entity.setUploadStatus(UploadStatusEnum.UPLOAD_SUCCESS.getCode());
            entity.setUploadCount(1000);
            entity.setDistributeCount(50);
            entity.setUploadTime(LocalDateTime.now());
            entity.setOperator("zzq");
            entity.setDistributeType(DistributeTypeEnum.SYNC.getCode());
            entity.setDistributePlanId(distributePlanId);
            if(i == 0 || i == 1 || i == 2){
                entity.setDistributeStatus(DistributeStatusEnum.PENDING.getCode());
            }else {
                entity.setDistributeStatus(DistributeStatusEnum.SUCCESS.getCode());
            }


            uploadRecordRepository.addRecord(entity);
        }*/

        for (int i = 0; i < 15; i++) {
            Long id = idGeneratorService.getLongId();
            DistributeRecordEntity entity = new DistributeRecordEntity();
            entity.setId(id);
            entity.setDistributeStatus(DistributeStatusEnum.PENDING.getCode());
            entity.setDistributeCount(2000);
            entity.setSuccessCount(1000);
            entity.setDistributeTime(LocalDateTime.now());
            entity.setChannelTaskId(123L);
            entity.setSupplierTaskId(IdUtil.fastSimpleUUID());
            entity.setSupplierTaskName("测试任务");
            entity.setDistributePlanId(7305215350138339329L);
            entity.setChannelId(1);
            entity.setUploadRecordId(7303538659319742466L);
            entity.setDistributeType(DistributeRecordTypeEnum.FORMAL.getCode());

            distributeRecordRepository.addRecord(entity);
        }
    }

    @Test
    public void testUpdateUploadRecord() {
        UploadRecordEntity entity = new UploadRecordEntity();
        entity.setId(7303538659319742466L);
        entity.setUploadType(UploadTypeEnum.MANUAL.getCode());
        entity.setUploadStatus(UploadStatusEnum.UPLOAD_SUCCESS.getCode());
        entity.setUploadCount(2000);
        entity.setUploadTime(LocalDateTime.now());
        entity.setOperator("zzq");
        entity.setDistributePlanId(7303538659319742465L);
        entity.setDistributeStatus(DistributeStatusEnum.PENDING.getCode());
        entity.setDistributeCount(1000);
        uploadRecordRepository.updateRecordById(entity);
    }

    @Test
    public void testGetUploadRecord() {

        UploadRecordEntity recordById = uploadRecordRepository.getRecordById(7303538659319742466L, 7303538659319742465L);

        log.info("res:{}", recordById);
    }

    @Test
    public void testListUploadRecord() {

        for (int i = 0; i < 5; i++) {
            UploadRecordQueryConditionDTO conditionDTO = new UploadRecordQueryConditionDTO();
            conditionDTO.setId(null);
            conditionDTO.setUploadType(UploadTypeEnum.INTERFACE.getCode());
            conditionDTO.setUploadStatus(UploadStatusEnum.UPLOAD_SUCCESS.getCode());
            conditionDTO.setDistributeStatus(null);
            conditionDTO.setStartUploadTime(null);
            conditionDTO.setEndUploadTime(null);
            conditionDTO.setDistributeType(null);
            conditionDTO.setDistributePlanId(7303538659319742465L);


            List<UploadRecordEntity> uploadRecordEntities = uploadRecordRepository.queryByCondition(conditionDTO);

            log.info("res:{}", uploadRecordEntities);
        }

    }

    @Test
    public void testPageUploadRecord() {

        for (int i = 0; i < 5; i++) {
            UploadRecordQueryConditionDTO conditionDTO = new UploadRecordQueryConditionDTO();
            conditionDTO.setId(null);
            conditionDTO.setUploadType(null);
            conditionDTO.setUploadStatus(null);
            conditionDTO.setDistributeStatus(null);
            conditionDTO.setStartUploadTime(null);
            conditionDTO.setEndUploadTime(null);
            conditionDTO.setDistributeType(null);
            conditionDTO.setDistributePlanId(7305215350138339329L);


            PageResult<UploadRecordEntity> pageResult = uploadRecordRepository.pageByCondition(conditionDTO, 1, 10);

            log.info("res:{}", pageResult);
        }

    }

    @Test
    public void testAddDistributeRecord() {
        Long id = idGeneratorService.getLongId();
        DistributeRecordEntity entity = new DistributeRecordEntity();
        entity.setId(id);
        entity.setDistributeStatus(DistributeStatusEnum.PENDING.getCode());
        entity.setDistributeCount(2000);
        entity.setSuccessCount(1000);
        entity.setDistributeTime(LocalDateTime.now());
        entity.setChannelTaskId(123L);
        entity.setSupplierTaskId(IdUtil.fastSimpleUUID());
        entity.setSupplierTaskName("测试任务");
        entity.setDistributePlanId(7303538659319742465L);
        entity.setChannelId(1234);
        entity.setUploadRecordId(7303538659319742466L);

        distributeRecordRepository.addRecord(entity);
    }

    @Test
    public void testUpdateDistributeRecord() {
        DistributeRecordEntity entity = new DistributeRecordEntity();
        entity.setId(7303542657934884865L);
        entity.setDistributeStatus(DistributeStatusEnum.PENDING.getCode());
        entity.setDistributeCount(1000);
        entity.setSuccessCount(1000);
        entity.setDistributeTime(LocalDateTime.now());
        entity.setChannelTaskId(66666L);
        entity.setSupplierTaskName("测试任务");
        entity.setSupplierTaskId(IdUtil.fastSimpleUUID());
        entity.setDistributePlanId(7303538659319742465L);
        entity.setChannelId(1);
        entity.setUploadRecordId(null);
        distributeRecordRepository.updateRecordById(entity);
    }

    @Test
    public void testGetDistributeRecord() {

        DistributeRecordEntity recordById = distributeRecordRepository.getRecordById(7303542657934884865L, 7303538659319742465L);

        log.info("res:{}", recordById);
    }

    @Test
    public void testListDistributeRecord() {

        for (int i = 0; i < 5; i++) {
            DistributeRecordQueryConditionDTO conditionDTO = new DistributeRecordQueryConditionDTO();
            conditionDTO.setId(null);
            conditionDTO.setDistributeStatus(null);
            conditionDTO.setStartDistributeTime(null);
            conditionDTO.setEndDistributeTime(null);
            conditionDTO.setChannelTaskId(null);
            conditionDTO.setSupplierTaskName(null);
            conditionDTO.setChannelId(null);
            conditionDTO.setUploadRecordId(null);
            conditionDTO.setStartCreateTime(null);
            conditionDTO.setEndCreateTime(null);

            conditionDTO.setDistributePlanId(7303538659319742465L);


            List<DistributeRecordEntity> entityList = distributeRecordRepository.queryByCondition(conditionDTO);

            log.info("res:{}", entityList);
        }

    }

    @Test
    public void testPageDistributeRecord() {

        for (int i = 0; i < 5; i++) {
            DistributeRecordQueryConditionDTO conditionDTO = new DistributeRecordQueryConditionDTO();
            conditionDTO.setId(null);
            conditionDTO.setDistributeStatus(null);
            conditionDTO.setStartDistributeTime(null);
            conditionDTO.setEndDistributeTime(null);
            conditionDTO.setChannelTaskId(null);
            conditionDTO.setSupplierTaskName(null);
            conditionDTO.setChannelId(null);
            conditionDTO.setUploadRecordId(null);
            conditionDTO.setStartCreateTime(null);
            conditionDTO.setEndCreateTime(null);

            conditionDTO.setDistributePlanId(7305215350138339329L);


            PageResult<DistributeRecordEntity> pageResult = distributeRecordRepository.pageByCondition(conditionDTO, 1, 10);

            log.info("res:{}", pageResult);
        }

    }

    @Test
    public void testRecordPage() {
        for (int i = 0; i < 10; i++) {
            RosterUploadQueryRequest request = new RosterUploadQueryRequest();
            request.setUploadType(null);
            request.setDistributePlanId("7305215350138339329");
            request.setDistributeStatus(1);
            request.setPageSize(10);
            request.setPageNum(1);

            Result<PageResult<RosterUploadRecordResponse>> pageResultResult = rosterQueryFacadeService.queryUploadRecords(request);
            log.info("res:{}", pageResultResult);

            RosterDistributeQueryRequest request1 = new RosterDistributeQueryRequest();
            request1.setChannelId(null);
            request1.setTaskName(null);
            request1.setDistributePlanId("7305215350138339329");
            request1.setPageSize(10);
            request1.setPageNum(1);

            Result<PageResult<RosterDistributeRecordResponse>> pageResultResult1 = rosterQueryFacadeService.queryDistributeRecords(request1);
            log.info("res:{}", pageResultResult1);
        }

    }

    @Test
    public void getTemplate() {
        RosterTemplateRequest request = new RosterTemplateRequest();
        request.setType(null);

        Result<String> result = rosterQueryFacadeService.downloadRosterTemplate(request);
        log.info("res:{}", result);

        /*File file = new File("/Users/zhangzhuoqi/IdeaProjects/AppAIccDistributeService/distribute-application/src/main/resources/上传模版.csv");
        ossUtils.uploadFileToFileName(file, BusinessTypeEnum.ROSTER, 1L);*/
    }

    @Test
    public void testUpdateRoster() {
        List<PlanRosterEntity> entityList = new ArrayList<>();
        /*for (int i = 0; i < 50; i++) {
            PlanRosterEntity entity = new PlanRosterEntity();
            entity.setId(idGeneratorService.getLongId());
            entity.setPhoneNum("150000000" + RandomUtil.randomInt(10,20));
            entity.setExternalId(IdUtil.fastSimpleUUID());
            entity.setPlatformId(IdUtil.fastSimpleUUID());
            entity.setCustomerName(RandomUtil.randomString(5));
            entity.setVariableInfo("{\"name\":\"zzq\"}");
            entity.setDistributePlanId(7303538659319742465L);
            entity.setUploadRecordId(7303538659319742466L);
            entity.setDistributeRecordId(7303542657934884865L);
            entity.setDistributeStatus(DistributeStatusEnum.PENDING.getCode());
            entity.setChannelId(1);
            entity.setChannelTaskId(66666L);
            entity.setChannelTaskName("测试-任务");
            entity.setCallDialogueNum(0);
            entity.setThroughCallDialogueNum(0);
            entity.setUploadTime(LocalDateTime.now());
            entity.setDistributeTime(LocalDateTime.now());
            entity.setLastCallTime(LocalDateTime.now());
            entity.setLastThroughTime(LocalDateTime.now());
            entity.setExtInfo("{\"name\":\"zzq\"}");
            entityList.add(entity);
        }

        planRosterRepository.batchSave(entityList);*/

        //更新名单（话单数、接通话单数、最近呼叫时间、最近接通时间）
        PlanRosterEntity planRosterEntity = new PlanRosterEntity();
        planRosterEntity.setId(7317666355181322264L);
        planRosterEntity.setDistributePlanId(7317666222037336085L);
        planRosterEntity.setPhoneNum("13544011302");
        planRosterEntity.setLastCallTime(LocalDateTime.now().plusDays(1));
        planRosterEntity.setLastThroughTime(LocalDateTime.now().plusDays(1));
        planRosterEntity.setDistributePlanId(7303538659319742465L);
        planRosterEntity.setSmsSendCount(1);
        planRosterEntity.setSmsSendSuccessCount(1);
        planRosterEntity.setCallDialogueNum(1);
        planRosterEntity.setThroughCallDialogueNum(1);
        planRosterEntity.setLastCallResult(8);
        planRosterRepository.updateRosterByCallBack(planRosterEntity);
    }


    @Test
    public void testImport() throws InterruptedException {


        for (int i = 0; i < 1; i++) {
            List<RosterImportDataRequest> dataRequestList = new ArrayList<>();
            RosterImportRequest request = new RosterImportRequest();
            request.setTenantId("11626");
            request.setDistributePlanId("7315098718496882721");
            request.setRosterType(1);

            int count = 0;
            for (int j = 0; j < 1; j++) {
                count++;
                String phoneStr;
                long phone;
                if (count < 3){
                    phone = 13500010050L;
                }else {
                    phone = 15000000000L;
                }
                phoneStr = (phone+j)+"";
                RosterImportDataRequest dataRequest = new RosterImportDataRequest();
                //dataRequest.setPhone(DigestUtils.md5DigestAsHex(phoneStr.getBytes()));
                dataRequest.setPhone(phoneStr);
                dataRequest.setName(RandomUtil.randomString(4));
                dataRequest.setDataIdentifier(IdUtil.fastSimpleUUID());
                /*Map<String, String> map = new HashMap<>();
                map.put("k1", "v1");
                map.put("k2", "v2");
                dataRequest.setVariableInfos(map);*/
                dataRequestList.add(dataRequest);
                System.out.println(BaseJsonUtils.writeValue(dataRequestList));
            }
            request.setDataList(dataRequestList);

            Result<RosterImportResponse> res = rosterCommandFacadeService.importRoster(request);
            log.info("res:{}", res);
        }
        while (true) {
            Thread.sleep(50);
        }
    }

    @Test
    public void testImportThread() throws InterruptedException {
        for (int i = 0; i < 50; i++) {
            new Thread(() -> {
                List<RosterImportDataRequest> dataRequestList = new ArrayList<>();
                RosterImportRequest request = new RosterImportRequest();
                request.setTenantId("11624");
                request.setDistributePlanId("7307297436490531975");
                for (int j = 0; j < 10; j++) {
                    RosterImportDataRequest dataRequest = new RosterImportDataRequest();
                    dataRequest.setPhone(RandomUtil.randomNumbers(11));
                    dataRequest.setName(RandomUtil.randomString(4));
                    dataRequest.setDataIdentifier(IdUtil.fastSimpleUUID());
                    Map<String, String> map = new HashMap<>();
                    map.put("k1", "v1");
                    map.put("k2", "v2");
                    dataRequest.setVariableInfos(map);
                    dataRequestList.add(dataRequest);
                    System.out.println(BaseJsonUtils.writeValue(dataRequestList));
                }
                request.setDataList(dataRequestList);

                Result<RosterImportResponse> res = rosterCommandFacadeService.importRoster(request);
                log.info("res:{}", res);
            }).start();
        }
        while (true) {
            Thread.sleep(50);
        }
    }

    @Test
    public void testDist() {
        DistributePlanEntity distributePlanEntity = distPlanRepo.queryDistributePlanById(7305468008037679105L);
        List<DistributeChannelTaskEntity> taskList = distChannelTaskRepo.queryDistributePlanTaskList(distributePlanEntity.getId());
        Map<String, DistributeChannelTaskEntity> identifyMap = taskList.stream().collect(Collectors.toMap(it -> it.getChannelId() + "-" + it.getSupplierTaskTemplateId(), it -> it));
        for (DistributeRuleEntity ruleEntity : distributePlanEntity.getDistributeRuleList()) {
            String identify = ruleEntity.getChannelId() + "-" + ruleEntity.getTaskTemplateId();
            DistributeChannelTaskEntity taskEntity = identifyMap.get(identify);
            // 将计划渠道任务表id填充到规则中
            ruleEntity.setPlanChannelTaskId(String.valueOf(taskEntity.getId()));
        }
        List<PlanRosterEntity> finalRosters = new ArrayList<>();
        for (int i = 0; i < 120392; i++) {
            PlanRosterEntity roster = new PlanRosterEntity();
            roster.setId(idGeneratorService.getLongId());
            roster.setPhoneNum(RandomUtil.randomNumbers(11));
            roster.setExternalId(IdUtil.fastSimpleUUID());
            roster.setPlatformId(IdUtil.fastSimpleUUID());
            roster.setCustomerName("zzq");
            roster.setVariableInfo(null);
            roster.setDistributePlanId(distributePlanEntity.getId());
            List<PlanRosterEntity> rosters = new ArrayList<>();
            rosters.add(roster);
            distCalService.decide(distributePlanEntity, taskList, rosters);
            finalRosters.addAll(rosters);
        }
        //按照任务分组
        Map<Long, List<PlanRosterEntity>> map = finalRosters.stream().collect(Collectors.groupingBy(PlanRosterEntity::getChannelTaskId));
        map.forEach((taskId, rosterList) -> {
            log.info("taskId:{},size:{}", taskId, rosterList.size());
        });
    }

    @Test
    public void testJob() {
        rosterAggDistributeJob.trigger(null);
        ThreadUtil.sleep(20, TimeUnit.MINUTES);
    }

    @Test
    public void testRetry() {
        RosterRetryDistributeDTO dto = new RosterRetryDistributeDTO();
        dto.setDistributePlanId("7306203712320997035");
        dto.setUploadRecordId("7306204079540731905");

        rosterDomainService.retryDistribute(dto);

        ThreadUtil.sleep(10, TimeUnit.MINUTES);
    }


    @Test
    public void testBatchAdd() {
        Long longId = idGeneratorService.getLongId();
        System.out.println("longID:" + longId);
        PlanRosterEntity entity = new PlanRosterEntity();
        entity.setId(longId);
        entity.setPhoneNum("15000000000");
        entity.setExternalId("slejrnngsssssswwwweee");
        entity.setPlatformId(IdUtil.fastSimpleUUID());
        entity.setCustomerName("sss");
        entity.setVariableInfo(null);
        entity.setDistributePlanId(7306188203192845989L);
        entity.setUploadRecordId(7306188323452354561L);
        entity.setDistributeRecordId(7306188370697029282L);
        entity.setDistributeStatus(1);
        entity.setChannelId(1);
        entity.setChannelName("哈啰");
        entity.setMd5("aaaaa");
        entity.setChannelTaskId(0L);
        entity.setSupplierTaskId("sssfff");
        entity.setSupplierTaskName("fffff");
        entity.setCallDialogueNum(0);
        entity.setThroughCallDialogueNum(0);
        entity.setUploadTime(LocalDateTime.now());
        entity.setDistributeTime(LocalDateTime.now());
        entity.setLastCallTime(LocalDateTime.now());
        entity.setLastThroughTime(LocalDateTime.now());

        planRosterRepository.batchSave(Collections.singletonList(entity));
    }

    @Test
    public void getRosterFile() {
        List<RosterImportVO> list = new ArrayList<>();
        for (int i = 0; i < 1000000; i++) {
            String phone;
            if (i <= 400000) {
                phone = (13100010000L + i) + "";
            } else {
                phone = (13200010000L + i) + "";
            }
            RosterImportVO rosterImportVO = new RosterImportVO();
            rosterImportVO.setPhoneNum(phone);
            rosterImportVO.setExternalId(IdUtil.fastSimpleUUID());
            rosterImportVO.setCustomerName(RandomUtil.randomString(6));
            rosterImportVO.setVariableMap(null);
            list.add(rosterImportVO);
        }
        EasyExcel.write(new File("/Users/zhangzhuoqi/Downloads/撞库名单100w.xlsx"), RosterImportVO.class).sheet()
                .registerWriteHandler
                        (new LongestMatchColumnWidthStyleStrategy())
                .doWrite(list);
    }

    @Test
    public void testEs(){
        List<PlanRosterESPO> rosterList = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            Long id = null;
            String phone = null;
            if (i ==0){
                id = 7317122234362953734L;
                phone = "15000000001";
            } else if (i == 1 ) {
                id = 7317122234362953733L;
                phone = "15000000000";
            }else if (i == 2){
                id = 7317122234362953735L;
                phone = "15000000002";
            } else {
                id = 7317128086255894542L;
                phone = "15000000003";
            }
            PlanRosterESPO po = new PlanRosterESPO();
            po.setId(id);
            po.setDistPlanCreateTime(DateUtils.toLocalDateTime("2025-05-23 15:31:14"));
            po.setDistributePlanId(7317122206445666305L);
            po.setPhoneNum(phone);
            rosterList.add(po);
        }
        rosterEsContainer.addRoster(rosterList,false);

        while (true){
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Test
    public void retryDistCompensate() {
        Long planId = 7315973306984169494L;
        Long channelTaskId = 7315973306984169495L;
        rosterDomainService.retryDistCompensate(planId,channelTaskId);
    }


    @Test
    public void zhongTouSmsCallBack() {
        //status == 0 表示成功
        String json = "{\"merId\":449,\"serialNum\":\"0D4Fbra6A2nsd/yhpf/bzg==\",\"phone\":\"15316787937\",\"submitDate\":\"2025-06-15 17:39:49\",\"recvDate\":\"2025-06-15 17:39:54\",\"chargeNum\":0,\"reqId\":\"0D4Fbra6A2nsd/yhpf/bzg==\",\"status\":\"UT:0013\"}";
        JSONObject jsonObject = JSONObject.parseObject(json);
        String res = HttpUtil.post("https://fat-msgcallback.hellobike.com/zhongtou/sms", jsonObject.toJSONString());
        log.info("zhongTongSmsCallBack response:" + res);
    }

}
