package com.hellobike.aicc.distribute;

import com.hellobike.aicc.BaseTest;
import com.hellobike.aicc.infrastructure.job.DistributePlanStatJob;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import javax.annotation.Resource;

/**
 * @author zhangzhuoqi
 * @since 2025-05-27  15:45:12
 */
@Slf4j
public class StatTest extends BaseTest {

    @Resource
    private DistributePlanStatJob distributePlanStatJob;

    @Test
    public void statPlan() {
        distributePlanStatJob.trigger(null);
    }
}
