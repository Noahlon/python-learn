package com.hellobike.aicc.calldialogue;

import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import com.google.common.collect.Lists;
import com.hellobike.aicc.BaseTest;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.common.iface.CommonService;
import com.hellobike.aicc.api.common.request.EnumRequest;
import com.hellobike.aicc.api.common.response.EnumResponse;
import com.hellobike.aicc.api.dialogue.iface.DialogueQueryService;
import com.hellobike.aicc.api.dialogue.request.DialogueDetailRequest;
import com.hellobike.aicc.api.dialogue.request.DialogueListQueryRequest;
import com.hellobike.aicc.api.dialogue.request.DialogueQueryRequest;
import com.hellobike.aicc.api.dialogue.response.DialogueDetailResponse;
import com.hellobike.aicc.api.dialogue.response.DialogueInfoResponse;
import com.hellobike.aicc.api.distribute.plan.iface.ChannelService;
import com.hellobike.aicc.api.distribute.plan.request.BusinessTaskStatReq;
import com.hellobike.aicc.api.distribute.plan.request.ChannelTaskRequest;
import com.hellobike.aicc.api.distribute.plan.response.BusinessTaskStatResponse;
import com.hellobike.aicc.api.distribute.plan.response.ChannelTaskStatResponse;
import com.hellobike.aicc.common.basic.BffLogin;
import com.hellobike.aicc.common.basic.PageResult;
import com.hellobike.aicc.common.enums.OpenApiCallBackTagEnum;
import com.hellobike.aicc.common.enums.SpeakerEnum;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.common.util.DateUtils;
import com.hellobike.aicc.domain.channel.factory.ChannelFactory;
import com.hellobike.aicc.domain.channel.factory.ChannelInfo;
import com.hellobike.aicc.domain.common.service.DingTalkService;
import com.hellobike.aicc.domain.common.service.IdGeneratorService;
import com.hellobike.aicc.domain.dialogue.dto.CssCallDialogueDTO;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueEntity;
import com.hellobike.aicc.domain.dialogue.entity.CallDialogueStatisticEntity;
import com.hellobike.aicc.domain.dialogue.entity.DialogueSpeakEntity;
import com.hellobike.aicc.domain.dialogue.repo.CallDialogueRepository;
import com.hellobike.aicc.domain.dialogue.service.DialogueDomainService;
import com.hellobike.aicc.infrastructure.es.EsPage;
import com.hellobike.aicc.infrastructure.es.calldialogue.condition.CallDialogueESCondition;
import com.hellobike.aicc.infrastructure.es.calldialogue.po.CallDialogueESPO;
import com.hellobike.aicc.infrastructure.es.calldialogue.repository.CallDialogueESRepository;
import com.hellobike.aicc.infrastructure.hms.consumer.dialogue.CssCallDialogueConsumer;
import com.hellobike.base.model.Proto;
import com.hellobike.openapi.iface.dto.CallbackExecuteResDTO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author zhangzhuoqi
 * @since 2025-03-11  16:09:38
 */

@Slf4j
public class CallTest extends BaseTest {

    @Resource
    private IdGeneratorService idGeneratorService;

    @Resource
    private CallDialogueESRepository callDialogueESRepository;

    @Resource
    private CallDialogueRepository callDialogueRepository;

    @Resource
    private DialogueQueryService dialogueQueryService;

    @Resource
    private DialogueDomainService dialogueDomainService;

    @Resource
    private CssCallDialogueConsumer cssCallDialogueConsumer;

    @Resource
    private CommonService commonService;

    @Resource
    private ChannelService channelService;

    @Resource
    private DingTalkService dingTalkService;
    @Test
    public void save2Es() {
        List<CallDialogueESPO> list = new ArrayList<>();
        for (int i = 0; i < 550000; i++) {
            Long longId = idGeneratorService.getLongId();
            System.out.println("longId:" + longId);
            CallDialogueESPO callDialogueESPO = new CallDialogueESPO();
            callDialogueESPO.setId(longId);
            callDialogueESPO.setChannelId(1);
            callDialogueESPO.setChannelName("哈啰AI外呼");
            callDialogueESPO.setEnterpriseId("abc");
            callDialogueESPO.setCallResult(4);
            callDialogueESPO.setIntentClassify("A");
            callDialogueESPO.setHitIntentions(null);
            callDialogueESPO.setIsHitSms(0);
            callDialogueESPO.setDurationCallAi(0);
            callDialogueESPO.setDurationCallManual(0);
            callDialogueESPO.setRealCallingNumber("");
            callDialogueESPO.setTotalTime(0);
            callDialogueESPO.setRingTime(0);
            callDialogueESPO.setDialTime(DateUtils.format(LocalDateTime.now()));
            callDialogueESPO.setHangupTime(DateUtils.format(LocalDateTime.now()));
            callDialogueESPO.setCallType(1);
            callDialogueESPO.setCallingNumber("666");
            callDialogueESPO.setCostUnit(0);
            callDialogueESPO.setCustomName("zzq");
            callDialogueESPO.setDialogueGuid(IdUtil.fastSimpleUUID());
            callDialogueESPO.setRecordUrl("http://baidu.com");
            callDialogueESPO.setLineId("666666");
            callDialogueESPO.setCarrier(0);
            callDialogueESPO.setSpeechCount(0);
            callDialogueESPO.setSex(0);
            callDialogueESPO.setReleaseInitiator(0);
            callDialogueESPO.setExternalId(IdUtil.fastSimpleUUID());
            callDialogueESPO.setPlatformId("12345");
            long phone = 1500000000 + i;
            callDialogueESPO.setCalledNumber("" + phone);
            callDialogueESPO.setChannelTaskId(123L);
            callDialogueESPO.setExtInfo("");
            callDialogueESPO.setSupplierTaskId("123");
            callDialogueESPO.setSupplierTaskName("123");
            callDialogueESPO.setSupplierTaskTemplateId("333");
            callDialogueESPO.setRosterId(1L);
            callDialogueESPO.setDistributePlanId(1234555L);
            callDialogueESPO.setDistributePlanName("测试计划");
            callDialogueESPO.setMd5(IdUtil.fastSimpleUUID());
            callDialogueESPO.setCreateTime(DateUtils.format(LocalDateTime.now()));
            callDialogueESPO.setUpdateTime(DateUtils.format(LocalDateTime.now()));
            callDialogueESPO.setIndexDate(LocalDateTime.now());
            callDialogueESPO.setIsDelete(0);
            list.add(callDialogueESPO);

        }
        for (List<CallDialogueESPO> callDialogueESPOS : Lists.partition(list, 1000)) {
            boolean save = callDialogueESRepository.save(callDialogueESPOS);
            log.info("res:{}", save);
        }


    }

    @Test
    public void pageEs() {
        CallDialogueESCondition condition = new CallDialogueESCondition();
        EsPage<CallDialogueESPO> callDialogueESPOEsPage = callDialogueESRepository.pageCallDialogue(condition);
        log.info("res:{}", callDialogueESPOEsPage);
    }

    @Test
    public void saveCall() {


        for (int i = 0; i < 100; i++) {
            CallDialogueEntity entity = new CallDialogueEntity();
            Long longId = idGeneratorService.getLongId();
            entity.setId(longId);
            entity.setEnterpriseId(i + "");
            entity.setCallResult(RandomUtil.randomInt(1, 9));
            String intentClassify = RandomUtil.randomString("ABCDEFGHIJ", 1);
            entity.setIntentClassify(intentClassify);
            entity.setIntentClassifyName(intentClassify+"类");
            entity.setHitIntentions(Arrays.asList("意图" + i, "意图" + i));
            entity.setIsHitSms(RandomUtil.randomInt(0, 2));
            entity.setDurationCallAi(i);
            entity.setDurationCallManual(i);
            entity.setRealCallingNumber("123456");
            entity.setTotalTime(1);
            entity.setRingTime(1);
            entity.setDialTime(LocalDateTime.now());
            entity.setHangupTime(LocalDateTime.now());
            entity.setCallType(RandomUtil.randomInt(1, 3));
            entity.setCallingNumber("88888888");
            entity.setCostUnit(1);
            entity.setDialogueGuid(IdUtil.fastSimpleUUID());
            entity.setRecordUrl("http://www.baidu.com");
            entity.setLineId("ggggggg");
            if (i == 0 || i==10){
                entity.setCity("长沙");
                entity.setProvince("湖南");
            }else {
                entity.setCity("武汉");
                entity.setProvince("湖北");
            }


            entity.setCarrier(RandomUtil.randomInt(1, 6));
            entity.setSpeechCount(2);
            entity.setSex(RandomUtil.randomInt(1, 4));
            entity.setReleaseInitiator(RandomUtil.randomInt(0, 3));
            entity.setExternalId(IdUtil.fastSimpleUUID());
            entity.setPlatformId(IdUtil.fastSimpleUUID());
            entity.setCalledNumber((Long.parseLong("1390000001") + i) + "");
            entity.setChannelTaskId(9999999988888L);
            entity.setExtInfo("{\"name\":\"zzq\"}");
            entity.setSeatName("zzq");
            entity.setSupplierTaskId("hhhhhhh");
            entity.setSupplierTaskName("渠道任务-test");
            entity.setSupplierTaskTemplateId(IdUtil.fastSimpleUUID());
            entity.setRosterId(idGeneratorService.getLongId());
            entity.setDistributePlanId(7311927546557104131L);
            entity.setDistributePlanName("统计-计划");
            entity.setMd5(IdUtil.fastSimpleUUID());
            entity.setCreateTime(LocalDateTime.now());
            entity.setUpdateTime(LocalDateTime.now());
            entity.setIsDelete(0);
            entity.setCustomName("张三");
            entity.setChannelId(ChannelFactory.getHelloAiCall().getChannelId());
            entity.setChannelName(ChannelFactory.getHelloAiCall().getChannelName());
            List<DialogueSpeakEntity> speakList = new ArrayList<>();
            boolean flag = true;
            for (int j = 0; j < 5; j++) {
                DialogueSpeakEntity speakEntity = new DialogueSpeakEntity();
                speakEntity.setSpeakId(IdUtil.fastSimpleUUID());
                speakEntity.setSpeaker(flag ? SpeakerEnum.CALLER.getCode() : SpeakerEnum.CALLED_PARTY.getCode());
                speakEntity.setSpeakContent(flag ? "我是机器人" + RandomUtil.randomString(10) : "我是用户" + RandomUtil.randomString(10));
                flag = !flag;
                speakEntity.setSpeakTime(LocalDateTime.now().plusSeconds(j));
                speakList.add(speakEntity);
            }
            entity.setSpeakList(speakList);
            entity.setTags(Arrays.asList("标签1", "标签2"));
            entity.setSupplierCallResult("1");
            entity.setSpeakCount(3);
            entity.setTemplateId(123L);
            entity.setTenantId("11626");
            entity.setAnswerTime(LocalDateTime.now());
            callDialogueRepository.save(entity);

        }

    }

    @Test
    public void page() {
        for (int i = 0; i < 20; i++) {
            DialogueListQueryRequest request = new DialogueListQueryRequest();
            request.setCreateTimeStart("2025-06-06 00:00:00");
            request.setCreateTimeEnd("2025-06-11 00:00:00");
            request.setPageNum(1);
            request.setPageSize(100);
            request.setDistributePlanId("");
            request.setMd5("");
            request.setDistributePlanName("");
            request.setSupplierTaskName("");
            request.setCostUnitStart(null);
            request.setCostUnitEnd(null);
            request.setIsHitSms(null);
            //request.setIntentClassifyList(Arrays.asList("A", "B"));
            //request.setIntentClassifyName("A类");
            //request.setHitIntentions(Arrays.asList("意图38","意图2"));
            //request.setExcludeIntentions(Arrays.asList("意图1gg22", "意图2"));
            Result<PageResult<DialogueInfoResponse>> pageResultResult = dialogueQueryService.queryDialogueRecords(request);
            log.error("res:{}", pageResultResult);
        }

    }

    @Test
    public void queryDetail() {
        DialogueDetailRequest req = new DialogueDetailRequest();
        req.setId("7310636704858767379");
        req.setCalledNumber("1390000001");

        Result<DialogueDetailResponse> res = dialogueQueryService.queryDetail(req);
        log.info("res:{}", res);
    }

    @Test
    public void export() {
        for (int i = 0; i < 1; i++) {
            DialogueListQueryRequest req = new DialogueListQueryRequest();
            req.setCallResultList(null);
            req.setCreateTimeStart("2025-05-29 00:00:00");
            req.setCreateTimeEnd("2025-05-29 23:59:59");
            //req.setDistributePlanId("6987567822908988");
            req.setExportFieldList("[\"externalId\",\"platformId\",\"md5\",\"calledNumber\",\"distributePlanName\",\"distributePlanId\",\"supplierTaskId\",\"supplierTaskName\",\"speechTemplateId\",\"enterpriseId\",\"tenantId\",\"callResultDesc\",\"intentClassify\",\"intentClassifyName\",\"hitIntentions\",\"isHitSms\",\"seatName\",\"durationCallAi\",\"durationCallManual\",\"realCallingNumber\",\"totalTime\",\"ringTime\",\"dialTime\",\"hangupTime\",\"callType\",\"callingNumber\",\"costUnit\",\"customName\",\"dialogueGuid\",\"recordUrl\",\"lineId\",\"provinceCity\",\"carrier\",\"speechCount\",\"sex\",\"releaseInitiator\",\"createTime\",\"channelName\"]");

            BffLogin bffLogin = new BffLogin();
            bffLogin.setRealName("zzq");
            req.set_user(bffLogin);
            Result<Void> export = dialogueQueryService.export(req);
            log.info("res:{}", export);
            while (true){
                ThreadUtil.sleep(500);
            }
        }
    }

    @Test
    public void queryFromDB() {
        DialogueQueryRequest req = new DialogueQueryRequest();
        req.setPhoneList(Arrays.asList("1390000018", "1390000019", "1390000020"));
        req.setDistributePlanId("6987567822908988");

        Result<List<Object>> queryFromDB = dialogueQueryService.queryFromDB(req);
        log.info("res:{}", queryFromDB);
    }

    @Test
    public void testCallBack() {
        String s = "{\"bizReqId\":\"0a4da8acl1l2qu23gmhbrwbrbt57xeqt\",\"bizScene\":\"4012469739890671623\",\"callCount\":1,\"calledNumber\":\"19116396129\",\"callingNumber\":\"20250109\",\"calloutResult\":20,\"calloutResultDesc\":\"用户未接\",\"carrier\":\"未知\",\"contactType\":2,\"createTime\":\"2025-04-16T17:18:32\",\"dialTime\":\"2025-04-16T17:18:31.985\",\"durationCall\":0,\"durationRing\":0,\"externalCallResult\":8,\"externalCallResultDesc\":\"未接通\",\"externalId\":\"7310270840213667848-7310270430044356619\",\"guid\":\"2aa298316e3f4188803384b919ee42af\",\"hangupTime\":\"2025-04-16T17:18:37.025\",\"intentClassify\":\"D\",\"intentClassifyName\":\"D类\",\"intentionLabels\":[],\"isFirstCreated\":true,\"isHitSms\":false,\"lineGuid\":\"5997907092044259581\",\"realCallingNumber\":\"20250109001\",\"recordFile\":\"https://easybike-image.oss-cn-hangzhou.aliyuncs.com/cppcc-pro/recordwav/fake.wav\",\"releaseInitiator\":2,\"speakCount\":0,\"speechCount\":0,\"taskGuid\":\"628386244221157113\",\"tenant\":\"11625\",\"tenantDesc\":\"11625\"}";
        CssCallDialogueDTO cssCallDialogueDTO = BaseJsonUtils.readValue(s, CssCallDialogueDTO.class);
        cssCallDialogueDTO.setIntentionLabels(Arrays.asList("你好", "哈哈"));
        cssCallDialogueDTO.setSpeakCount(3);
        dialogueDomainService.handleCallDialogueCallBack(cssCallDialogueDTO, ChannelFactory.getHelloAiCall().getChannelId());
        /*ConsumeMessage consumeMessage = new ConsumeMessage();
        consumeMessage.setMsgId("test");
        cssCallDialogueConsumer.msgProcess(consumeMessage);*/
    }


    @Test
    public void testS() {
        CallDialogueESCondition condition = new CallDialogueESCondition();
        condition.setDistributePlanId(String.valueOf(6287567822998988L));
        List<CallDialogueStatisticEntity> callDialogueStatisticEntities = callDialogueESRepository.statDlgByChannelTask(condition);
        log.info("res:{}", callDialogueStatisticEntities);
    }

    @Test
    public void testStat() {
        for (int i = 0; i < 10; i++) {
            ChannelTaskRequest request = new ChannelTaskRequest();
            request.setPlanId("7320638279286798835");
            Result<ChannelTaskStatResponse> res = channelService.channelTaskStat(request);
            System.out.println(res);
        }

    }

    @Test
    public void testBusinessStat() {
        for (int i = 0; i < 10; i++) {
            BusinessTaskStatReq request = new BusinessTaskStatReq();
            request.setTenantId("11626");
            request.setPageNum(1);
            request.setPageSize(100);
            Result<BusinessTaskStatResponse> res = channelService.businessTaskStat(request);
            System.out.println(res);
        }

    }

    @Test
    public void testEnum() {
        for (int i = 0; i < 10; i++) {
            EnumRequest req = new EnumRequest();
            req.setType(1);
            Result<EnumResponse> enumResponseResult = commonService.queryEnumList(req);
            System.out.println(enumResponseResult);
        }

    }

    @Test
    public void send() {
        dingTalkService.sendRosterFailedAlert("test");
        ChannelInfo yunDongChannel = ChannelFactory.getYunDongChannel();
        Proto<CallbackExecuteResDTO> proto = new Proto<>();
        proto.setCode(0);
        proto.setMsg("测试");
        CallbackExecuteResDTO resDTO = new CallbackExecuteResDTO();
        resDTO.setSuccess(false);
        resDTO.setData(null);
        resDTO.setErrMsg("测试错误");

        proto.setData(resDTO);

        dingTalkService.sendChannelApiFail(yunDongChannel.getChannelName(), OpenApiCallBackTagEnum.IMPORT_ROSTER.getDesc(), BaseJsonUtils.writeValue(proto));
    }
}
