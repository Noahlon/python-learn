package com.hellobike.aicc.name.list;

import com.hellobike.aicc.BaseTest;
import com.hellobike.aicc.api.basic.Result;
import com.hellobike.aicc.api.distribute.plan.iface.ChannelService;
import com.hellobike.aicc.api.distribute.plan.request.RetryCreateChannelTaskRequest;
import com.hellobike.aicc.api.distribute.upload.iface.DistributeUploadFileService;
import com.hellobike.aicc.api.distribute.upload.request.RosterUploadRequest;
import com.hellobike.aicc.common.basic.BffLogin;
import com.hellobike.aicc.common.util.BaseJsonUtils;
import com.hellobike.aicc.domain.roster.dto.NameListDupCheckResultDTO;
import com.hellobike.aicc.domain.roster.entity.PlanRosterEntity;
import com.hellobike.aicc.domain.roster.service.RosterDomainService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author zhangzhuoqi
 * @since 2025-03-06  17:22:11
 */
@Slf4j
public class NameListTest extends BaseTest {
    @Resource
    private DistributeUploadFileService distributeUploadFileService;

    @Resource
    private RosterDomainService rosterDomainService;

    @Test
    public void testUploadRoster() throws InterruptedException {
        RosterUploadRequest request = new RosterUploadRequest();
        request.setFileUrl("https://aiot-businessprotal.oss-cn-hangzhou.aliyuncs.com/distribute_file/fat/%E4%B8%8A%E4%BC%A0%E6%A8%A1%E7%89%88%20(1).xlsx?OSSAccessKeyId=LTAI5tDmYeLQaUPFxjqrZHGV&Expires=1749016682&Signature=vj3happOPnluA2H%2FMxKCAKXPuLI%3D");
        request.setFileName("分流计划XLSX模板.xlsx");
        request.setDistributePlanId("7319329044401430347");
        request.setRosterType(1);
        BffLogin user = new BffLogin();
        user.setUserName("panlongqian044@hellobike.com");
        user.setRealName("潘龙骞");
        user.setEmail("panlongqian044@hellobike.com");
        request.set_user(user);
        Result<Boolean> booleanResult = distributeUploadFileService.uploadRoster(request);
        System.out.println(booleanResult);
        TimeUnit.MINUTES.sleep(10);
    }

    @Test
    public void test() {
        String str = "[{\"id\":7306233594557956099,\"phoneNum\":\"923123123\",\"externalId\":\"8025\",\"customerName\":\"潘\",\"variableInfo\":\"{}\",\"distributePlanId\":7306218141264238823,\"md5\":\"1ec18d1c9496b7269c2644aafbe31336\",\"partitionCode\":\"73062181412642388233\"}]";
        List<PlanRosterEntity> rosterEntities = BaseJsonUtils.readValues(str, PlanRosterEntity.class);
        NameListDupCheckResultDTO nameListDupCheckResultDTO = rosterDomainService.rosterDupCheck(rosterEntities,false);
        System.out.println(nameListDupCheckResultDTO);
    }
}
