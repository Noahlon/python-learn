package com.dxh.api.fsApi.utils;

import java.util.Arrays;
import java.util.UUID;

public class SnowFlakeUtil {

    public static String getNextId() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }
}
