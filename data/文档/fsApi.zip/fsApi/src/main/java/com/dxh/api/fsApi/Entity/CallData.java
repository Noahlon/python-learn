package com.dxh.api.fsApi.Entity;


import com.alibaba.excel.annotation.ExcelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// 定义 Excel 数据对应的实体类
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CallData {
    // Getter 和 Setter 方法
    // 定义 Excel 表头与实体类属性的映射
    @ExcelProperty("手机号")
    private String phone;
    @ExcelProperty("数据标识")
    private String dataLogo;
    @ExcelProperty("姓名")
    private String name;
}