package com.dxh.api.fsApi.utils;

import lombok.extern.slf4j.Slf4j;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.Security;
import java.util.Base64;

@Slf4j
public class AESUtil {

    //偏移量,AES 为16bytes. DES 为8bytes
    private static final String IV = "0987654321012345";

    //私钥,AES固定格式为128/192/256 bits.即：16/24/32bytes。DES固定格式为64bits，即8bytes。
    private static final String AES_KEY="35609875678789654398765432108765";

    //填充类型，DES加密把前面的AES改成DES即可
    public static final String AES_TYPE = "AES/CBC/PKCS5Padding";

    public static final String AES_TYPE_7 = "AES/CBC/PKCS7";


    public static String encode(String password){
        try {
            Security.addProvider(new com.sun.crypto.provider.SunJCE());
            IvParameterSpec ivParameterSpec = new IvParameterSpec(IV.getBytes());
            //两个参数，第一个为私钥字节数组， 第二个为加密方式 AES或者DES
            SecretKeySpec secretKeySpec = new SecretKeySpec(AES_KEY.getBytes(), "AES");

            Cipher cipher = Cipher.getInstance(AES_TYPE);
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);
            //PKCS5Padding比PKCS7Padding效率高，PKCS7Padding可支持IOS加解密
            //初始化，此方法可以采用三种方式，按加密算法要求来添加。
            // （1）无第三个参数
            // （2）第三个参数为SecureRandom random = new SecureRandom();中random对象，随机数。(AES不可采用这种方法)
            // （3）采用此代码中的IVParameterSpec(ECB不能使用偏移量)
            //加密时使用:ENCRYPT_MODE;  解密时使用:DECRYPT_MODE;

            byte[] encryptedData = cipher.doFinal(password.getBytes());

            return Base64.getEncoder().encodeToString(encryptedData);
        } catch (Exception e) {
            log.error("Exception:{}", e.getMessage());
            return null;
        }
    }


    public static String decode(String encodePassword){
        try {
            byte[] decodeByte = Base64.getDecoder().decode(encodePassword);

            IvParameterSpec ivParameterSpec = new IvParameterSpec(IV.getBytes());
            SecretKeySpec secretKeySpec = new SecretKeySpec(AES_KEY.getBytes(), "AES");

            Cipher cipher = Cipher.getInstance(AES_TYPE);

            //解密模式
            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivParameterSpec);

            byte[] bytes = cipher.doFinal(decodeByte);
            return new String(bytes);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception{}", e.getMessage());
            return null;
        }
    }

}

