package com.dxh.api.fsApi.Handler;

import com.dxh.api.fsApi.EnumMessage;
import com.dxh.api.fsApi.WSMessageDTO;
import com.dxh.api.fsApi.utils.JacksonInstance;
import com.dxh.api.fsApi.utils.SnowFlakeUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Objects;


@Slf4j
@Component
@ChannelHandler.Sharable
public class MessageHandler extends SimpleChannelInboundHandler<TextWebSocketFrame> {

    @Override
    public void channelRead0(ChannelHandlerContext ctx, TextWebSocketFrame msg) throws Exception{
        // 获取客户端发送的数据
        WSMessageDTO wsMessageDTO = JacksonInstance.toObject(msg.text(), new TypeReference<WSMessageDTO>(){});
        if(Objects.isNull(wsMessageDTO)){
            TextWebSocketFrame result = WSMessageDTO.error("参数不能为空");
            ctx.channel().writeAndFlush(result);
            ctx.fireChannelRead(result);
        }else {
            log.info("server receive msg：{}", wsMessageDTO);
            //verifyParams(ctx, wsMessageDTO);
            wsMessageDTO.setReceiveTime(LocalDateTime.now().toString());
            wsMessageDTO.setMessageId(SnowFlakeUtil.getNextId());
            wsMessageDTO.setSendTime(LocalDateTime.now().toString());
            log.info("server send msg：{}", wsMessageDTO.toString());
            TextWebSocketFrame result = WSMessageDTO.ok(wsMessageDTO);
            // 根据消息类型获取对应的处理器 核心处理方法
            ctx.channel().writeAndFlush(result);
            ctx.fireChannelRead(result);
        }
    }

    private void verifyParams(ChannelHandlerContext ctx, WSMessageDTO wsMessageDTO) {
        StringBuilder sb = new StringBuilder();
        if (wsMessageDTO.getToken() == null) {
            sb.append("senderId不能为空");
        }
        if (!EnumMessage.containsMessage(wsMessageDTO.getMessageType())) {
            sb.append("messageType不能为空");
        }
        if (wsMessageDTO.getData() == null) {
            sb.append("message不能为空");
        }
        if (sb.length() > 0) {
            log.error("参数校验失败:{}", sb.toString());
            ctx.close();
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        log.error("MessageHandler server exceptionCaught:{}", cause.getMessage());
        super.exceptionCaught(ctx,cause);
    }
}
