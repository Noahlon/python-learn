package com.dxh.api.fsApi;


import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
@Component
@Slf4j
public class NettyWebSocketServer {
    private final EventLoopGroup parentGroup = new NioEventLoopGroup();
    private final EventLoopGroup childGroup = new NioEventLoopGroup(Runtime.getRuntime().availableProcessors() * 2);
    /**
     * -- GETTER --
     *  获取通道
     *
     * @return
     */
    @Getter
    private Channel channel;

    @Resource
    private WebsocketServerChannelInitializer websocketServerChannelInitializer;

    /**
     * 初始化服务端
     * sync()：等待Future直到其完成，如果这个Future失败，则抛出失败原因；
     * syncUninterruptibly()：不会被中断的sync()；
     */
    public ChannelFuture bind(String host, Integer port) {
        ChannelFuture channelFuture = null;
        try {
            channelFuture = new ServerBootstrap()
                    .group(parentGroup, childGroup) // 指定线程模型 一个用于接收客户端连接，一个用于处理客户端读写操作
                    .channel(NioServerSocketChannel.class) // 指定服务端的IO模型
                    .option(ChannelOption.SO_BACKLOG, 4096) // 设置TCP缓冲区
                    .childOption(ChannelOption.SO_KEEPALIVE, true) // 保持连接 tcp底层心跳机制
                    .childHandler(websocketServerChannelInitializer) // 指定处理新连接数据的读写处理逻辑
                    .bind(host, port)
                    .addListener(new GenericFutureListener<Future<? super Void>>() {
                        @Override
                        public void operationComplete(Future<? super Void> future) throws Exception {
                            if (future.isSuccess()) {
                                log.info("Netty服务端启动成功，监听端口：{}", port);
                            } else {
                                log.error("Netty服务端启动失败，监听端口：{}", port);
                                bind(host, port + 1);
                            }
                        }
                    })
                    .syncUninterruptibly();// 绑定端口
            channel = channelFuture.channel(); // 获取channel
        }catch (Exception e){
            log.error("Netty服务端启动失败，err msg：{}", e.getMessage());
            e.printStackTrace();
        } finally {
            if (null == channelFuture) {
                channel.close();
                parentGroup.shutdownGracefully();
                childGroup.shutdownGracefully();
            }
        }
        return channelFuture;
    }


    /**
     * 销毁
     */
    public void destroy() {
        if (null == channel) return;
        channel.close();
        parentGroup.shutdownGracefully();
        childGroup.shutdownGracefully();
    }

}
