package com.dxh.api.fsApi;

import io.netty.channel.ChannelFuture;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.socket.config.annotation.EnableWebSocket;

import javax.annotation.Resource;

//@EnableWebSocket
@SpringBootApplication
public class FsApiApplication implements CommandLineRunner {

	@Value("${netty.host}")
	private String host;
	@Value("${netty.port}")
	private Integer port;
	@Resource
	private NettyWebSocketServer nettyWebSocketServer;

	public static void main(String[] args) {
		SpringApplication.run(FsApiApplication.class, args);
	}

	// springboot启动后执行netty服务端启动
	@Override
	public void run(String... args) throws Exception {
		ChannelFuture channelFuture = nettyWebSocketServer.bind(host, port);
		// 优雅关闭, jvm关闭时将netty服务端关闭
		Runtime.getRuntime().addShutdownHook(new Thread(() -> nettyWebSocketServer.destroy()));
		// 阻塞 直到channel关闭
		channelFuture.channel().closeFuture().syncUninterruptibly();
	}

}
