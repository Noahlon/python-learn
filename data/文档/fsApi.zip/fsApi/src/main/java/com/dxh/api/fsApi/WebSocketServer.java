package com.dxh.api.fsApi;

import com.dxh.api.fsApi.config.WebSocketConfigurator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * websocket的处理类。
 * 作用相当于HTTP请求
 * 中的controller
 */
@Component
@Slf4j
@CrossOrigin("*")
@ServerEndpoint(value = "/ws/{token}",configurator = WebSocketConfigurator.class)
public class WebSocketServer {

    /**静态变量，用来记录当前在线连接数。应该把它设计成线程安全的。*/
    private static int onlineCount = 0;
    /**concurrent包的线程安全Set，用来存放每个客户端对应的WebSocket对象。*/
    //TODO 正式应该使用redis或者直接调用后端，本身不维护登录client；
    private static ConcurrentHashMap<String,WebSocketServer> webSocketMap = new ConcurrentHashMap<>();
    //private static ConcurrentHashMap<String, List<WebSocketServer>> devWebSocketMap = new ConcurrentHashMap<>();
    /**与某个客户端的连接会话，需要通过它来给客户端发送数据*/
    private Session session;
    /**接收userId*/
    private String userId = "";

    /**
     * 连接建立成
     * 功调用的方法
     */
    @OnOpen
    public void onOpen(Session session,@PathParam("token") String token) {
        this.session = session;

        if(StringUtils.isBlank(token)){
            log.error("ws onOpen fail, token is null");
            return;
        }
        log.info("ws client connect session:{}", session);
        //userId = session.getId()+"_"+userId; //拼接
        this.userId=token;
        if(webSocketMap.containsKey(token)){
            webSocketMap.remove(token);
            //加入set中
            webSocketMap.put(token,this);
        }else{
            //加入set中
            webSocketMap.put(token,this);
            //在线数加1
            addOnlineCount();
        }
        log.info("用户连接:"+userId+",当前在线用户为:" + getOnlineCount());
        this.sendMessage("{\"status\":0,\"msg\":\"连接成功\"}");
    }

    /**
     * 连接关闭
     * 调用的方法
     */
    @OnClose
    public void onClose() throws IOException {
        if(webSocketMap.containsKey(userId)){
            webSocketMap.remove(userId);
            //从set中删除
            subOnlineCount();
        }
        log.info("用户退出:"+userId+",当前在线用户为:" + getOnlineCount());
        this.session.close();
    }

    /**
     * 收到客户端消
     * 息后调用的方法
     * @param message
     * 客户端发送过来的消息
     **/
    @OnMessage
    public void onMessage(Session session, String message) {
        log.info("用户消息:"+userId+",报文:"+message);
        if(StringUtils.isBlank(message)) {
            return;
        }
        if (message.equals("ping")){
            this.sendMessage("{\"code\":0,\"msg\":\"pong\"}");
        }
        //可以群发消息
        //消息保存到数据库、redis
        if(StringUtils.isNotBlank(message)){
            try {
                //可以群发消息
                //消息保存到数据库、redis
                log.info("收到来自"+userId+"的信息:"+message);
//                //群发消息
//                for(WebSocketServer item: webSocketMap.values()){
//                    item.sendMessage(message);
//                }
                this.sendMessage(message);

            }catch (Exception e){
                log.error("ws onMessage sendMessage fail:{}", e.getMessage());
            }
        }
    }


    /**
     * @param session
     * @param error
     */
    @OnError
    public void onError(Session session, Throwable error) {

        log.error("用户错误:"+this.userId+",原因:"+error.getMessage());
    }

    /**
     * 实现服务
     * 器主动推送
     */
    public void sendMessage(String message) {
        log.info("发送消息到:"+userId+"，报文:"+message);
        try {
            if(!this.session.isOpen()){
                log.error("ws sendMessage fail, session is closed");
                return;
            }
            if(StringUtils.isBlank(message)){
                log.error("ws sendMessage fail, message is null");
                return;
            }
            WsProto<Object> result = WsProto.builder().code(0).msg("success").data(message).build();
            this.session.getBasicRemote().sendText(String.valueOf(result));
        } catch (IOException e) {
            log.error("ws sendMessage fail reason:{}", e.getMessage());
        }
    }

    /**
     *发送自定
     *义消息
     **/
    public static void sendInfo(String message, String userId) {
        log.info("发送消息到:"+userId+"，报文:"+message);
        if(StringUtils.isNotBlank(userId) && webSocketMap.containsKey(userId)){
            webSocketMap.get(userId).sendMessage(message);
        }else{
            log.error("ws send info error, user:{} not online",userId);
        }
    }

    /**
     * 获得此时的
     * 在线用户数
     * @return
     */
    public static synchronized int getOnlineCount() {
        return onlineCount;
    }

    /**
     * 在线人
     * 数加1
     */
    public static synchronized void addOnlineCount() {
        WebSocketServer.onlineCount++;
    }

    /**
     * 在线人
     * 数减1
     */
    public static synchronized void subOnlineCount() {
        WebSocketServer.onlineCount--;
    }

}



