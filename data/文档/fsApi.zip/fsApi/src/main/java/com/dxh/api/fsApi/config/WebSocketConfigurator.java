package com.dxh.api.fsApi.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;

import javax.servlet.http.HttpSession;
import javax.websocket.HandshakeResponse;
import javax.websocket.server.HandshakeRequest;
import javax.websocket.server.ServerEndpointConfig;
import java.util.List;
import java.util.Map;

@Configuration
@Slf4j
public class WebSocketConfigurator extends ServerEndpointConfig.Configurator {
    private static ApplicationContext applicationContext;

    /**、
     * 这段代码的作用是将Spring的ApplicationContext注入到WebSocketConfigurator类中，以便在WebSocket端点中实现依赖注入。
     * 具体来说，这段代码通过Spring的@Autowired注解将Spring上下文（ApplicationContext）注入到WebSocketConfigurator类的静态字段中。
     * @param applicationContext
     */
    @Autowired
    public void setApplicationContext(ApplicationContext applicationContext) {
        WebSocketConfigurator.applicationContext = applicationContext;
    }

    /**
     * 注意:没有一个客户端发起握手,端点就有一个新的实列 那么引用的这个配置也是新的实列 所以内存地址不一样 这里sec的用胡属性也不同就不会产生冲突
     * 修改握手机制  就是第一次http发送过来的握手
     * @param sec   服务器websocket端点的配置
     * @param request
     * @param response
     */
    @Override
    public void modifyHandshake(ServerEndpointConfig sec, HandshakeRequest request, HandshakeResponse response) {
        super.modifyHandshake(sec, request, response);
        HttpSession httpSession =(HttpSession) request.getHttpSession();
        //将从握手的请求中获取httpsession
        Map<String, List<String>> pramas = request.getParameterMap();
        /**
         * 一般会在请求头中添加token 解析出来id作为键值对
         */
        Map<String, Object> properties = sec.getUserProperties();
        /**
         * 一个客户端和和服务器发起一次请求交互 就有一个唯一session
         *存储session 是为了能够从其中用户用户info 到时候作为wssession的key 但是session 不共享 为此redis改进 或者token也是可以的
         * 这里使用UUID作为标识
         */
        // properties.put(HttpSession.class.getName(),httpSession);
        //String sessionKey = UUID.randomUUID().toString().replaceAll("-", "");
        properties.put("token",pramas.get("token").get(0));
    }

    @Override
    public <T> T getEndpointInstance(Class<T> endpointClass) throws InstantiationException {
        return super.getEndpointInstance(endpointClass);
    }

}


