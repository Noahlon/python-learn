package com.dxh.api.fsApi;


import com.dxh.api.fsApi.Handler.BinHandler;
import com.dxh.api.fsApi.Handler.HeartBeatServerHandler;
import com.dxh.api.fsApi.Handler.InitParamHandler;
import com.dxh.api.fsApi.Handler.MessageHandler;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;
import io.netty.handler.stream.ChunkedWriteHandler;
import io.netty.handler.timeout.IdleStateHandler;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

@Component
public class WebsocketServerChannelInitializer extends ChannelInitializer<SocketChannel> {
//    @Sharable
    //private final LoggingHandler loggingHandler = new LoggingHandler(LogLevel.WARN);
    public final static String WEBSOCKET_PATH = "/wsNetty";
    @Resource
    private InitParamHandler initParamHandler;
    @Resource
    private MessageHandler messageHandler;
    @Resource
    private BinHandler.OutBoundHandler outBoundHandler;
    @Resource
    private HeartBeatServerHandler heartBeatServerHandler;

    @Resource
    private BinHandler binHandler;


    @Override
    protected void initChannel(SocketChannel socketChannel) throws Exception {
        ChannelPipeline pipeline = socketChannel.pipeline();
        // 日志打印
        //pipeline.addLast(loggingHandler);
        // http报文解析器 线程不安全不能被共享
        pipeline.addLast(new HttpServerCodec());
//        // 添加对大数据流的支持
        pipeline.addLast(new ChunkedWriteHandler());
//        // 消息聚合器 8192 8M
        pipeline.addLast(new HttpObjectAggregator(1 << 13));
        pipeline.addLast(initParamHandler);
        pipeline.addLast(new IdleStateHandler(600, 600, 600 * 3, TimeUnit.SECONDS));
        // 进行设置心跳检测//websocket 服务器处理的协议，用于给指定的客户端进行连接访问的路由地址
       // ================= 上述是用于支持http协议的 ==============
        // 处理uri参数 WebSocketServerProtocolHandler不允许带参数 顺序不可调换
        pipeline.addLast(new WebSocketServerProtocolHandler(WEBSOCKET_PATH,null, true, 1<<16,true,true,5000));
        pipeline.addLast(heartBeatServerHandler);
        pipeline.addLast(binHandler);
        pipeline.addLast(messageHandler);
        // 自定义出栈处理器
        pipeline.addLast(outBoundHandler);
    }
}
