package com.dxh.api.fsApi.Handler;

import com.dxh.api.fsApi.WSMessageDTO;
import io.netty.channel.*;
import io.netty.handler.codec.http.FullHttpMessage;
import io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame;
import io.netty.handler.codec.http.websocketx.PingWebSocketFrame;
import io.netty.handler.codec.http.websocketx.PongWebSocketFrame;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@ChannelHandler.Sharable
public class BinHandler extends SimpleChannelInboundHandler<BinaryWebSocketFrame> {

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, BinaryWebSocketFrame msg) throws Exception {
        log.info("收到二进制消息：" + msg.content().toString(io.netty.util.CharsetUtil.UTF_8));
        ctx.channel().writeAndFlush(new BinaryWebSocketFrame(msg.content()));
    }

    @Slf4j
    @Component
    @Sharable
    public static class OutBoundHandler extends ChannelOutboundHandlerAdapter {
        /**
         * 若调用WSMessageDTO方法，必须注意内存泄露
         * 即调用方必须是SimpleChannelInboundHandler<>
         * 严禁使用ChannelInboundHandlerAdapter, 否则将造成严重内存泄露
         * 相应地，必须使用此处的写出@param msg ，释放@param msg 引用
         * @param ctx               the {@link ChannelHandlerContext} for which the write operation is made
         * @param msg               the message to write
         * @param promise           the {@link ChannelPromise} to notify once the operation completes
         * @throws Exception
         */
        @Override
        public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
            if (msg instanceof FullHttpMessage){
                log.info("OutBoundHandler,webSocket协议升级成功");
                // 出栈必须得这样写，不能自定义通信消息，可能把websocket反馈的消息覆盖了。  也不能在最后处理器调ctx.fireChannelRead()
                ctx.writeAndFlush(msg,promise);
            } else if (msg instanceof TextWebSocketFrame) {
                log.info("OutBoundHandler return msg type of TextWebSocketFrame:{}", ((TextWebSocketFrame) msg).text());
                ctx.writeAndFlush(msg, promise);
            } else if (msg instanceof PingWebSocketFrame) {
                log.info("OutBoundHandler return msg type of PingWebSocketFrame:{}", msg.toString());
                ctx.writeAndFlush(msg, promise);
            } else if (msg instanceof PongWebSocketFrame){
                log.info("OutBoundHandler return msg type of PongWebSocketFrame:{}", msg.toString());
                ctx.writeAndFlush(msg, promise);
            }else {
                log.error("OutBoundHandler.write: 消息类型错误");
                ctx.writeAndFlush(WSMessageDTO.error("服务器内部错误: OutBoundHandler.write()"), promise);
            }
        }
    }
}
