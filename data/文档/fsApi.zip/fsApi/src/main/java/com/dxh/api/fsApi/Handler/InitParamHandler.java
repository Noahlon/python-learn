package com.dxh.api.fsApi.Handler;

import cn.hutool.core.net.url.UrlBuilder;
import com.dxh.api.fsApi.WSMessageDTO;
import com.dxh.api.fsApi.WebsocketServerChannelInitializer;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelId;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.util.concurrent.GlobalEventExecutor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * URL参数处理程序，这时候连接还是个http请求，没有升级成webSocket协议，此处SimpleChannelInboundHandler泛型使用FullHttpRequest
 *
 * @author YuanJie
 * @date 2023/5/7 15:07
 */
@Slf4j
@ChannelHandler.Sharable
@Component
public class InitParamHandler extends SimpleChannelInboundHandler<FullHttpRequest> {

    /**
     * 存储已经登录用户的channel对象
     */
    public static ChannelGroup channelGroup = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

    /**
     * 存储用户id和用户的channelId绑定
     */
    public static final Map<String, ChannelId> userMap = new ConcurrentHashMap<>();
    public static final Map<ChannelId,String> clientMap = new ConcurrentHashMap<>();



    /**
     * 此处进行url参数提取，重定向URL，访问webSocket的url不支持带参数的，带参数会抛异常，这里先提取参数，将参数放入通道中传递下去，重新设置一个不带参数的url
     *
     * @param ctx     the {@link ChannelHandlerContext} which this {@link SimpleChannelInboundHandler}
     *                belongs to
     * @param request the message to handle
     * @throws Exception
     */
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, FullHttpRequest request) throws Exception {
        if (!this.acceptInboundMessage(request)) {
            ctx.fireChannelRead(request.retain());
        }
        String uri = request.uri();
        log.info("NettyWebSocketParamHandler channelRead0 formate URL:{}", uri);
        Map<CharSequence, CharSequence> queryMap = UrlBuilder.ofHttp(uri).getQuery().getQueryMap();
        //将参数放入通道中传递下去
        String token = (String) queryMap.get("token");
        if (StringUtils.isBlank(token)) {
            log.info("NettyWebSocketParamHandler channelRead0: 参数缺失 token");
            ctx.writeAndFlush(WSMessageDTO.error("InitParamHandler ex return param token loss"));
            ctx.close();
        }
        //验证token
        verifyToken(ctx,token);
        // 初始化数据
        initData(ctx, token);
        // 获取？之前的路径
        request.setUri(WebsocketServerChannelInitializer.WEBSOCKET_PATH);
        ctx.fireChannelRead(request.retain());
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) {
        //添加到channelGroup通道组
        channelGroup.add(ctx.channel());
        ctx.channel().writeAndFlush(WSMessageDTO.ok());
        log.info("InitParamHandler channelActive，ID:{},",ctx.channel().id());
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) {
        // 移除channelGroup 通道组
        userMap.remove(clientMap.get(ctx.channel().id()));
        clientMap.remove(ctx.channel().id());
        channelGroup.remove(ctx.channel());
        log.info("InitParamHandler channelInactive，ID:{},",ctx.channel().id());
        ctx.close();
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        log.error("NettyWebSocketParamHandler InitParamHandler exceptionCaught --> cause: ", cause);
        ctx.close();
    }

    private void verifyToken(ChannelHandlerContext ctx, String token) {
        if(token == null) {
            log.info("NettyWebSocketParamHandler.channelRead0 --> : 用户未登录... {}", token);
            channelGroup.remove(ctx.channel());
            ctx.close();
        }
        // token续期
        //redissonCache.expire(userKey, SystemConstants.TOKEN_EXPIRE_TIME, TimeUnit.MILLISECONDS);
    }

    private void initData(ChannelHandlerContext ctx, String token){
        userMap.put(token, ctx.channel().id());
        clientMap.put(ctx.channel().id(),token);
    }
}

