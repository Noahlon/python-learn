package com.dxh.api.fsApi;

import com.dxh.api.fsApi.utils.JacksonInstance;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author YuanJie
 * @projectName vector-server
 * @package com.vector.netty.entity
 * @className com.vector.netty.entity.SocketMessage
 * @copyright Copyright 2020 vector, Inc All rights reserved.
 * @date 2023/6/14 19:35
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WSMessageDTO<T> implements Serializable {
    /**
     * 消息发送者
     */
    private String token;
    /**
     * 消息类型 0文本 1图片 2文件 3视频 4语音 5位置 6名片 7链接 8系统消息
     */
    private byte messageType;

    /**
     * 记录每条消息的id
     */
    private String messageId;
    /**
     * 消息内容
     */
    private T data;

    /**
     * 消息发送时间
     */
    private String sendTime;
    /**
     * 消息接收时间
     */

    private String receiveTime;

    /**
     * 最后一条消息内容
     */
    private String lastMessage;

    /**
     * 消息状态 0失败 1成功
     */
    private int code;

//    /**
//     * 消息状态 0普通消息 1心跳检测
//     */
//    private int dataType;


    /**
     * 封装统一返回格式
     * @return
     */
    public static TextWebSocketFrame ok(){
        WSMessageDTO data = new WSMessageDTO();
        data.setCode(1);
        return new TextWebSocketFrame(JacksonInstance.toJson(data)).retain();
    }

    public static TextWebSocketFrame ok(WSMessageDTO data){
        data.setCode(1);
        return new TextWebSocketFrame(JacksonInstance.toJson(data)).retain();
    }

    public static TextWebSocketFrame error(String message){
        WSMessageDTO data = new WSMessageDTO();
        data.setCode(0);
        data.setData(message);
        return new TextWebSocketFrame(JacksonInstance.toJson(data)).retain();
    }
}

