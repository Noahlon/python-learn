package com.dxh.api.fsApi.utils;

import cn.hutool.crypto.digest.MD5;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.read.listener.PageReadListener;
import com.dxh.api.fsApi.Entity.CallData;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;


public class PhoneToMd5 {
    public static void main(String[] args) {
//        // 写入 Excel 文件
//        writeExcel();
//        // 读取 Excel 文件
//        readExcel();
        readAndWriteExcel();
    }

    public static void writeExcel() {
        // 准备数据
        List<CallData> data = new ArrayList<>();
        data.add(new CallData("张三", "20", "北京"));
        data.add(new CallData("李四", "25", "上海"));
        data.add(new CallData("王五", "30", "广州"));

        // 写入 Excel 文件
        String fileName = "easyexcel_demo.xlsx";
        EasyExcel.write(fileName, CallData.class).sheet("Sheet1").doWrite(data);
        System.out.println("Excel 文件写入成功！");
    }

    public static void readExcel() {
        String fileName = "/Users/dxh/Downloads/131百万名单.xlsx";
        // 读取 Excel 文件
        EasyExcel.read(fileName, CallData.class, new PageReadListener<CallData>(dataList -> {
            for (CallData data : dataList) {
                System.out.println(data);
            }
        })).sheet().doRead();
    }

    public static void readAndWriteExcel() {
        String fileName = "/Users/dxh/Downloads/131百万名单.xlsx";
        String fileNameOut = "/Users/dxh/Downloads/10百万名单.xlsx";
        List<CallData> dataMD5List = new ArrayList<>();
        AtomicInteger n = new AtomicInteger();
        // 读取 Excel 文件
        EasyExcel.read(fileName, CallData.class, new PageReadListener<CallData>(dataList -> {
            for (CallData data : dataList){
                CallData dataMD5 = new CallData();
                System.out.println(data);
                dataMD5.setPhone(MD5.create().digestHex(data.getPhone()));
                dataMD5.setDataLogo(UUID.randomUUID().toString());
                dataMD5.setName(data.getName());
                dataMD5List.add(dataMD5);
                n.getAndIncrement();
                if(n.get() > 100000){
                    break;
                }
            }
        })).sheet().doRead();
        EasyExcel.write(fileNameOut, CallData.class).sheet("Sheet1").doWrite(dataMD5List);

    }
}