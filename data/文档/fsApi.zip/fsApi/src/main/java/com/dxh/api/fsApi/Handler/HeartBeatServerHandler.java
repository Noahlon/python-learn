package com.dxh.api.fsApi.Handler;

import com.dxh.api.fsApi.WSMessageDTO;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.websocketx.PingWebSocketFrame;
import io.netty.handler.codec.http.websocketx.PongWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketFrame;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.util.CharsetUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@ChannelHandler.Sharable
public class HeartBeatServerHandler extends SimpleChannelInboundHandler<WebSocketFrame> {

    // 记录读超时几次了，用来判断是否断开该连接
    private int readIdleTimes = 0;

    private int writeIdleTimes = 0;

    private int readAndWriteIdleTimes = 0;

    /*
     * Channel 收到消息后触发
     *
     * 注：心跳包说白了就是一个某些地方特殊的数据包
     * 	  所以这里我们规定，如果消息内容是 "Heartbeat Packet"，那么它就是一个心跳包
     */
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, WebSocketFrame webSocketFrame) throws Exception {
        if(webSocketFrame instanceof PingWebSocketFrame) {
            log.info("[server] ping received,channelId:{} msg:{} ", ctx.channel().id(),
                    webSocketFrame.content().toString(CharsetUtil.UTF_8));
            readIdleTimes = 0;
            writeIdleTimes = 0;
            readAndWriteIdleTimes = 0;
        } else if(webSocketFrame instanceof PongWebSocketFrame){
            log.info("[server] pong received,channelId:{} msg:{} ",ctx.channel().id(),
                    webSocketFrame.content().toString(CharsetUtil.UTF_8));
            readIdleTimes = 0 ;
            writeIdleTimes = 0;
            readAndWriteIdleTimes=0;
        }
        if(webSocketFrame == null){
            ctx.writeAndFlush(WSMessageDTO.error("webSocketFrame is null"));
        }
        log.info("[server] channelRead0: channelId:{} msg:{} ",ctx.channel().id(),
                webSocketFrame.content().toString(CharsetUtil.UTF_8));
        ctx.fireChannelRead(webSocketFrame.retain());
    }

    /**
     * 用户事件触发
     *
     * 当 IdleStateHandler 发现读超时后，会调用 fireUserEventTriggered() 去执行后一个 Handler 的 userEventTriggered 方法。
     * 所以，根据心跳检测状态去关闭连接的就写在这里！
     */
    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if( evt instanceof IdleStateEvent) {
            // 入站的消息就是 IdleStateEvent 具体的事件
            IdleStateEvent event = (IdleStateEvent) evt;
            String eventType = null;
            // 我们在 IdleStateHandler 中也看到了，它有读超时，写超时，读写超时等
            // 所以，这里我们需要判断事件类型
            switch (event.state()) {
                case READER_IDLE:
                    eventType = "readLeisure";
                    readIdleTimes++; // 读空闲的计数加 1
                    break;
                case WRITER_IDLE:
                    eventType = "writeLeisure";
                    writeIdleTimes++;
                    break; // 不处理
                case ALL_IDLE:
                    eventType = "readAndWriteLeisure";
                    readAndWriteIdleTimes++;
                    break; // 不处理
            }

            // 打印触发了一次超时警告
            log.warn("ip:" + ctx.channel().remoteAddress() + ",id:" + ctx.channel().id() + "超时事件：" + eventType);

            // 当读超时超过 3 次，我们就端口该客户端的连接
            // 注：读超时超过 3 次，代表起码有 4 次 3s 内客户端没有发送心跳包或普通数据包
            if (readIdleTimes > 3 || writeIdleTimes > 3 || readAndWriteIdleTimes > 3) {
                log.warn(" [server]读空闲超过3次，关闭连接，释放更多资源ip:{},channelId:{}", ctx.channel().remoteAddress(), ctx.channel().id());
                ctx.channel().writeAndFlush(WSMessageDTO.error("time out"));
                ctx.close(); // 手动断开连接
            }
        }else {
            ctx.fireUserEventTriggered(evt);
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        log.error("[server] HeartBeatServerHandler exceptionCaught: {}",cause.getMessage());
        super.exceptionCaught(ctx,cause);
    }
}
