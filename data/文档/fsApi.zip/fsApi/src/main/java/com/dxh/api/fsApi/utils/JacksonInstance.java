package com.dxh.api.fsApi.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JacksonInstance {

    private static final ObjectMapper objectMapper = new ObjectMapper();
//    static {
//        objectMapper.registerModule(new JavaTimeModule());
//    }

    public static ObjectMapper getInstance() {
        return objectMapper;
    }

    public static <T> T toObject(String json, TypeReference<T> clazz) {
        try {
            return objectMapper.readValue(json, clazz);
        } catch (Exception e) {
            log.error("Jackson toObject fail:{}", e.toString());
            return null;
        }
    }

    public static String toJson(Object object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Jackson toJson fail:{}", e.getMessage());
        }
        return null;
    }
}
