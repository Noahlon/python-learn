package com.dxh.api.fsApi;

import lombok.Data;
import lombok.Getter;

@Getter
public enum EnumMessage {

    //消息类型 0文本 1图片 2文件 3视频 4语音 5位置 6名片 7链接 8系统消息
    TEXT("text", 0),
    IMAGE("image", 1),
    FILE("file", 2),
    VIDEO("video", 3),
    VOICE("voice", 4),
    LOCATION("location", 5),
    CARD("card", 6),
    LINK("link", 7),
    SYSTEM("system", 8);

    private String messageType;
    private int code;

    EnumMessage(String messageType, int code) {
        this.messageType = messageType;
       this.code = code;
    }

    public static boolean containsMessage(byte messageType) {
        for (EnumMessage message : EnumMessage.values()) {
            if (message.getCode() == messageType) {
                return true;
            }
        }
        return false;
    }


    public boolean containsMessageType(String messageType) {
        for (EnumMessage message : EnumMessage.values()) {
            if (message.getMessageType().equals(messageType)) {
                return true;
            }
        }
        return false;
    }

    private EnumMessage getMessageType(String messageType) {
        for (EnumMessage message : EnumMessage.values()) {
            if (message.getMessageType().equals(messageType)) {
                return message;
            }
        }
        return null;
    }
}
