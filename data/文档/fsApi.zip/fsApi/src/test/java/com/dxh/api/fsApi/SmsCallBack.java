package com.dxh.api.fsApi;

import com.alibaba.fastjson.JSONObject;
import com.dxh.api.fsApi.utils.OkHttpUtil;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

@Slf4j
public class SmsCallBack {

    private final Headers headers = new Headers.Builder()
            .add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
            .build();
    OkHttpClient okHttpClient = OkHttpUtil.getOkHttpClient();

    //众投测试短信回调
    @Test
    public void zhongTouSmsCallBack() {
        //status == 0 表示成功
        String json = "{\"merId\":449,\"serialNum\":\"MHiEluPCrNpbVOylYxI+ZA==\",\"phone\":\"18758068694\"," +
                "\"submitDate\":\"2025-06-16 11:33:38\",\"recvDate\":\"2025-06-16 11:33:44\",\"chargeNum\":0," +
                "\"reqId\":\"qLSOZVu2AjY2xrfhoZ4VNA==\",\"status\":\"\"}";
        JSONObject jsonObject = JSONObject.parseObject(json);
        String res = OkHttpUtil.post(okHttpClient,"https://fat-msgcallback.hellobike.com/zhongtou/sms", jsonObject,
                headers);
        log.info("zhongTongSmsCallBack response:" + res);
    }

    /**
    * 联鹭测试短信回调
    */
    @Test
    public void lianLuSmsCallBack() {
        //status == 0 表示成功
        String json = "'[ { \"messageId\": \"619f9099-f72e-40ad-bbbe-7ad43619feed\", \"mobile\": \"17613737592\", " +
                "\"msg_count\": 100, \"recvTime\": 1703751941045, \"sendTime\": 1703751941045, \"statusCode\": \"1\" } ]'";
        JSONObject jsonObject = JSONObject.parseObject(json);
        String res = OkHttpUtil.post(okHttpClient,"https://fat-msgcallback.hellobike.com/sms/volcengine", jsonObject,
                headers);
        log.info("zhongTongSmsCallBack response:" + res);
    }

/**/
    @Test
    public void testDiv() {
        System.out.println((71+66)/67);
    }

}
