package com.dxh.api.fsApi;

import cn.hutool.crypto.digest.MD5;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dxh.api.fsApi.utils.OkHttpUtil;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Headers;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tomcat.util.http.FastHttpDateFormat;
import org.jetbrains.annotations.TestOnly;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.ArrayList;
import java.util.List;

import static cn.hutool.crypto.digest.DigestAlgorithm.MD5;
//import static com.sun.javafx.application.ParametersImpl.params;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Slf4j
public class TaskDistribute {


    private final Headers headers = new Headers.Builder()
            .add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
            .build();

    // fat驰必准v2，详见AppAIccDistributeService服务apollo动态配置channel.config
    private static final String OPENAPI_APPKEY_CHIBIZHUN_V2 = "caoweicode-zDQ6xMrc";
    private static final String OPENAPI_SECRET_CHIBIZHUN_V2 = "17d51cf92f3041c2a0e71feaac05448c";

//            "appKey": "caoweicode-WWmJQ8Tb",
//                    "secret":"test-secret",


    //查询分流计划模版
    @Test
    public void testChiBiZhunSmsCallBack() {
        System.out.println("-------testChiBiZhunSmsCallBack调用-----------");
        String url = "https://fat-hello-openapi.hellobike.com/openapi";
        String method = "channel.call.smsCallBack";
        String appKey = OPENAPI_APPKEY_CHIBIZHUN_V2;
        String timestamp = String.valueOf(new Timestamp(System.currentTimeMillis()));
        String token = getOpenApiToken(OPENAPI_APPKEY_CHIBIZHUN_V2, OPENAPI_SECRET_CHIBIZHUN_V2);
        HashMap<String, Object> params;
        params = new HashMap<>();
        params.put("method", method);
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("partnerId", "11621");
        params.put("token", token);
        String chiBiZhunSmsCallBack = "{\n" +
                "      \"dialogueGuid\": \"684a7a88e4b0624b83423148\",\n" +
                "      \"submitResult\": 0,\n" +
                "      \"signature\": \"【众安金融】\",\n" +
                "      \"sendResult\": 2,\n" +
                "      \"city\": \"邢台\",\n" +
                "      \"rosterKey\": \"7321571569239724509-7321571382408581168\",\n" +
                "      \"content\": \"【众安金融】请您核对：您已成功获取可授款168000元，免费30天，请及时确认 xdw1.cn/q7OmY5At 实申为准，拒收请回复R\",\n" +
                "      \"sendTime\": \"2025-06-12 14:59:04.000\",\n" +
                "      \"carrier\": 3,\n" +
                "      \"smsId\": \"522663339\",\n" +
                "      \"phoneNumber\": \"18758068694\",\n" +
                "      \"submitTime\": \"2025-06-12 14:58:59.000\",\n" +
                "      \"province\": \"河北\",\n" +
                "      \"taskName\": \"光大银行_测试短链-20250616150123389\",\n" +
                "      \"enterpriseId\": \"chibizhun001\",\n" +
                "      \"taskId\": \"1084469\",\n" +
                "      \"md5\": \"0e7c40ba43345049d3a7401efee7e1f9\"\n" +
                "}";

        // 这里设置要回调的状态、金额、手机号、对应的分流计划id
        JSONObject data = JSONObject.parseObject(chiBiZhunSmsCallBack);
        data.put("sendResult", 0);
        //data.put("billingNum", 2);
        String phoneNumber = "18758068694";
        String planID="7321571382408581168";
        String rosterId= "7321571569239724509";
        String rosterKey = rosterId + "-" + planID;
        data.put("rosterKey", rosterKey);
        data.put("phoneNumber", phoneNumber);
        data.put("md5", cn.hutool.crypto.digest.MD5.create().digestHex(phoneNumber));
        params.put("data", data);
        params.put("partnerId", "11621");
        String sign = signTopRequest(params, OPENAPI_SECRET_CHIBIZHUN_V2);
        params.put("sign", sign);
        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(), url, params, headers);
        log.info("----------testListTaskTemplate response:" + response);
    }

    //查询分流计划模版
    @Test
    public void testListTaskTemplate() {
        System.out.println("-------testListTaskTemplate调用-----------");
        String url = "https://fat-hello-openapi.hellobike.com/openapi";
        String method = "ds.call.listTaskTemplate";
        String appKey = "caoweicode-JuqQ18Oj";
        String timestamp = String.valueOf(new Timestamp(System.currentTimeMillis()));
        String token = getOpenApiToken();

        HashMap<String, Object> params;
        params = new HashMap<>();
        params.put("method", method);
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("partnerId", "11621");
        params.put("token", token);
        String sign = signTopRequest(params, "dfb738c0692c4480a0ad19ce4d36ce61");
        params.put("sign", sign);
        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(), url, params, headers);
        log.info("----------testListTaskTemplate response:" + response);
    }

    //使用模版ID创建分流计划
    @Test
    public void testCreateTaskByTemplate() {
        System.out.println("--------testCreateTaskByTemplate调用-----------");
        String url = "https://fat-hello-openapi.hellobike.com/openapi";
        String method = "ds.call.createTaskByTemplate";
        String appKey = "caoweicode-JuqQ18Oj";
        String timestamp = String.valueOf(new Timestamp(System.currentTimeMillis()));
        String token = getOpenApiToken();
        String templateId = "6195210537373008432";
        String taskName = "分流二期"+ LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));

        HashMap<String, Object> params;
        params = new HashMap<>();
        params.put("method", method);
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("partnerId", "11621");
        params.put("token", token);
        params.put("templateId", templateId);
        params.put("taskName", taskName);
        String sign = signTopRequest(params, "dfb738c0692c4480a0ad19ce4d36ce61");
        params.put("sign", sign);

        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(), url, params, headers);
        log.info("------------testCreateTaskByTemplate response:" + response);
    }

    //  生成带变量的手机号
    public String generateVariableRosterList(int phoneNum) {
        String CHAR_SET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();

        // 生成 100 个对象
        List<Map<String, Object>> variableRosterList = new ArrayList<>();
        for (int i = 0; i < phoneNum; i++) {

            // 生成 10 位以 1 开头的电话号码
            StringBuilder phone = new StringBuilder("1");
            for (int a = 0; a < 9; a++) {
                phone.append(random.nextInt(10));
            }

            // 生成 20 位数字的 dataIdentifier
            StringBuilder identifier = new StringBuilder();
            for (int b = 0; b < 10; b++) {
                identifier.append(random.nextInt(10));
            }

            // 生成 8 位字母和数字组合的 name
            StringBuilder name = new StringBuilder();
            for (int c = 0; c < 8; c++) {
                name.append(CHAR_SET.charAt(random.nextInt(CHAR_SET.length())));
            }

            // 创建 SimpleDateFormat 对象，指定日期和时间格式
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            // 获取当前日期和时间
            Date now = new Date();
            // 格式化日期和时间
            String formattedDate = sdf.format(now);


            // 生成变量
            Random random1 = new Random();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            JSONObject variableInfos = new JSONObject();
            variableInfos.put("variable_1", Integer.valueOf(phone.toString()) % 10000);
            variableInfos.put("variable_2", name);
            variableInfos.put("variable_3", "～这里是操作引导变量值" + Integer.valueOf(phone.toString()) % 10000 + "～");
            variableInfos.put("variable_4", String.valueOf(random1.nextInt(900000) + 100000));
            variableInfos.put("variable_5", "0571" + (random1.nextInt(9000000) + 1000000));
            variableInfos.put("variable_6", formattedDate);

            Map<String, Object> item = new HashMap<>();
            item.put("phone", phone);
            item.put("dataIdentifier", identifier);
            item.put("name", name.toString());
            item.put("variableInfos", variableInfos);

            variableRosterList.add(item);
        }

        // 使用 FastJSON 将 Map 转换为 JSON 字符串
        String rosterJson = JSONObject.toJSONString(variableRosterList);
        return rosterJson;

    }


    //  生成不带变量的手机号
    public String generateRosterList(int phoneNum) {
        String CHAR_SET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();

        // 生成 100 个对象
        List<Map<String, Object>> rosterList = new ArrayList<>();
        for (int i = 0; i < phoneNum; i++) {

            // 生成 10 位以 1 开头的电话号码
            StringBuilder phone = new StringBuilder("1");
            for (int a = 0; a < 9; a++) {
                phone.append(random.nextInt(10));
            }

            // 生成 20 位数字的 dataIdentifier
            StringBuilder identifier = new StringBuilder();
            for (int b = 0; b < 10; b++) {
                identifier.append(random.nextInt(10));
            }

            // 生成 8 位字母和数字组合的 name
            StringBuilder name = new StringBuilder();
            for (int c = 0; c < 8; c++) {
                name.append(CHAR_SET.charAt(random.nextInt(CHAR_SET.length())));
            }

            Map<String, Object> item = new HashMap<>();
            item.put("phone", phone.toString());
            item.put("dataIdentifier", identifier.toString());
            item.put("name", name.toString());

            rosterList.add(item);
        }

//        // 构建完整的 JSON 数据结构
//        Map<String, List<Map<String, String>>> data = new HashMap<>();
//        data.put("rosterList", rosterList);

        // 使用 FastJSON 将 Map 转换为 JSON 字符串
        String rosterJson = JSONObject.toJSONString(rosterList);

        return rosterJson;

    }


    //传固定的名单
    public JSONArray dataListPhone() {

        // 构建 dataList
        JSONArray dataList = new JSONArray();

        JSONObject variableInfos1 = new JSONObject();
        variableInfos1.put("variable_1", "6673");
        variableInfos1.put("variable_2", "fivenamevk3");
        variableInfos1.put("variable_3", "～这里是操作引导变量值3～");
        variableInfos1.put("variable_4", "123000");
        variableInfos1.put("variable_5", "057100001");
        variableInfos1.put("variable_6", "2025/04/09 15:21:58");

        JSONObject item1 = new JSONObject();
//        item1.put("phone", "13588386673");
        item1.put("phone", "C8B593E1390BD5472831F1B632EF2E64");
        item1.put("dataIdentifier", "13588386673");
        item1.put("name", "fivenamevk3");
        item1.put("variableInfos", variableInfos1);
        dataList.add(item1);


        JSONObject variableInfos2 = new JSONObject();
        variableInfos2.put("variable_1", "6129");
        variableInfos2.put("variable_2", "namevk1");
        variableInfos2.put("variable_3", "～操作引导变量值1～");
        variableInfos2.put("variable_4", "123000");
        variableInfos2.put("variable_5", "057100001");
        variableInfos2.put("variable_6", "2025/04/09 15:21:58");

        JSONObject item2 = new JSONObject();
//        item2.put("phone", "19116396129");
        item2.put("phone", "0C0730BE0750D926171895EA8A8249BE");
        item2.put("dataIdentifier", "19116396129");
        item2.put("name", "测试机namevk1");
        item2.put("variableInfos", variableInfos2);
        dataList.add(item2);


        JSONObject variableInfos3 = new JSONObject();
        variableInfos3.put("variable_1", "9790");
        variableInfos3.put("variable_2", "namevk2");
        variableInfos3.put("variable_3", "～这里是操作引导变量值2～");
        variableInfos3.put("variable_4", "123000");
        variableInfos3.put("variable_5", "057100001");
        variableInfos3.put("variable_6", "2025/04/09 15:21:58");

        JSONObject item3 = new JSONObject();
//        item3.put("phone", "15669059790");
        item3.put("phone", "461F3411DD1114F611865B98BABAD53C");
        item3.put("dataIdentifier", "15669059790");
        item3.put("name", "Vickynamevk2");
        item3.put("variableInfos", variableInfos3);
        dataList.add(item3);


        JSONObject variableInfos4 = new JSONObject();
        variableInfos4.put("variable_1", "1320");
        variableInfos4.put("variable_2", "fivenamevk3");
        variableInfos4.put("variable_3", "～这里是操作引导变量值3～");
        variableInfos4.put("variable_4", "123000");
        variableInfos4.put("variable_5", "057100001");
        variableInfos4.put("variable_6", "2025/04/09 15:21:58");

        JSONObject item4 = new JSONObject();
//        item4.put("phone", "13200010001");
        item4.put("phone", "A5C9A326B1002430F656F43F141907B1");
        item4.put("dataIdentifier", "13200010001");
        item4.put("name", "fivenamevk3");
        item4.put("variableInfos", variableInfos4);
        dataList.add(item4);


        JSONObject variableInfos5 = new JSONObject();
        variableInfos5.put("variable_1", "1310");
        variableInfos5.put("variable_2", "fivenamevk3");
        variableInfos5.put("variable_3", "～这里是操作引导变量值3～");
        variableInfos5.put("variable_4", "123000");
        variableInfos5.put("variable_5", "057100001");
        variableInfos5.put("variable_6", "2025/04/09 15:21:58");

        JSONObject item5 = new JSONObject();
//        item5.put("phone", "15669059790");
        item5.put("phone", "461F3411DD1114F611865B98BABAD53C");
        item5.put("dataIdentifier", "1566905");
        item5.put("name", "fivenamevk3");
        item5.put("variableInfos", variableInfos5);
        dataList.add(item5);

        return dataList;
    }


    //导入名单
    @Test
    public void testImportRoster() {
        System.out.println("\n\n--------testImportRoster调用-----------");

        String url = "https://fat-hello-openapi.hellobike.com/openapi";
        String method = "ds.call.importRoster";
        String appKey = "caoweicode-JuqQ18Oj";
        String partnerId = "11621";
        String taskId = "7312839677363224577";
//        Integer rosterType = 1;

        String timestamp = String.valueOf(new Timestamp(System.currentTimeMillis()));
        String token = getOpenApiToken();

        HashMap<String, Object> params = new HashMap<>();
        params = new HashMap<>();
        params.put("method", method);
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("partnerId", partnerId);
        params.put("token", token);
        params.put("taskId", taskId);
        params.put("rosterType", 2);    // 名单类型；1-明文 2-md5（不传默认明文）

        JSONObject phoneMap = new JSONObject();
        phoneMap.put("phone", cn.hutool.crypto.digest.MD5.create().digestHex("18758068694"));
        phoneMap.put("dataIdentifier", UUID.randomUUID().toString());
        phoneMap.put("name", "邓小辉");

        JSONObject phoneMap1 = new JSONObject();
        phoneMap1.put("phone", cn.hutool.crypto.digest.MD5.create().digestHex("19116396129"));
        phoneMap1.put("dataIdentifier", UUID.randomUUID().toString());
        phoneMap1.put("name", "庞腊梅");

        JSONArray dataList = new JSONArray();
        dataList.add(phoneMap);
        dataList.add(phoneMap1);
        params.put("rosterList",dataList.toJSONString());  //生成不带变量的名单

//      生成token，需要放在最后一步
        String sign = signTopRequest(params, "dfb738c0692c4480a0ad19ce4d36ce61");
        params.put("sign", sign);

//      发起post请求
        log.info("-------------");
        log.info(url,params,headers);
        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(), url, params, headers);
        log.info("--------testImportRoster respons`e：" + response);
    }


    //   20个线程池并发调用导入名单接口
    @Test
    public void executorImportRoster() {

        // 创建一个固定大小为 20 的线程池
        ExecutorService executorService = Executors.newFixedThreadPool(20);

        for (int i = 0; i < 20; i++) {
            executorService.submit(() -> {
                testImportRoster();     //并发调用导入名单接口
//                testCreateTaskByTemplate();     //并发调用创建分流计划接口
//                testListTaskTemplate();     //并发调用查询分流计划模版接口

            });
        }
        // 关闭线程池
        executorService.shutdown();
        System.out.println("-------关闭线程池---------");
        try {
            // 等待所有任务完成，最多等待 10 秒
            executorService.awaitTermination(10, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


    }


    //获取token
    private String getOpenApiToken() {
        String url = "https://fat-hello-openapi.hellobike.com/login";
        String appKey = "caoweicode-JuqQ18Oj";
        String phoneNumber = "15669059790";
        String timestamp = String.valueOf(new Timestamp(System.currentTimeMillis()));

        HashMap<String, Object> params = new HashMap<>();
        params.put("method", "hello.open.login");
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("phoneNumber", phoneNumber);
        String sign = signTopRequest(params, "dfb738c0692c4480a0ad19ce4d36ce61");
        params.put("sign", sign);

        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(), url, params, headers);
        JSONObject tokenObject = JSON.parseObject(response);
        return tokenObject.getString("data");
    }

    //获取token
    private String getOpenApiToken(String appKey, String secret) {
        String url = "https://fat-hello-openapi.hellobike.com/login";
        String phoneNumber = "15669059790";
        String timestamp = String.valueOf(new Timestamp(System.currentTimeMillis()));

        HashMap<String, Object> params = new HashMap<>();
        params.put("method", "hello.open.login");
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("phoneNumber", phoneNumber);
        String sign = signTopRequest(params, secret);
        params.put("sign", sign);

        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(), url, params, headers);
        JSONObject tokenObject = JSON.parseObject(response);
        return tokenObject.getString("data");
    }

    /**
     * 根据参数创建sign
     *
     * @param params 参数信息
     * @param secret 秘钥
     * @return sign
     */
    public static String signTopRequest(Map<String, Object> params, String secret) {
        // 第一步：检查参数是否已经排序
        String[] keys = params.keySet().toArray(new String[0]);
        Arrays.sort(keys);
        // 第二步：把所有参数名和参数值串在一起
        StringBuilder query = new StringBuilder();
        query.append(secret);
        for (String key : keys) {
            if (StringUtils.isNotBlank(key)) {
                Object value = params.get(key);
                if (null != value) {
                    query.append(key.trim());
                    if (value instanceof List || value instanceof Map) {
                        query.append(JSONObject.toJSONString(value));
                    } else {
                        query.append(value);
                    }
                }
            }
        }
        query.append(secret);
        return getMd5Str(query.toString());
    }


    /**
     * 转小写16进制字符串
     *
     * @param byteArray
     * @return
     */
    private static String toHex(byte[] byteArray) {
        if (null == byteArray) {
            return null;
        }
        StringBuilder md5Str = new StringBuilder();
        for (byte b : byteArray) {
            md5Str.append(String.format("%02x", b));
        }
        return md5Str.toString();
    }


    /**
     * 获取md5 byte数组
     */
    private static byte[] getMd5(String str) {
        MessageDigest messageDigest;
        try {
            messageDigest = MessageDigest.getInstance(MD5.getValue());
            messageDigest.reset();
            messageDigest.update(str.getBytes(StandardCharsets.UTF_8));
        } catch (NoSuchAlgorithmException e) {
            log.error("NoSuchAlgorithmException caught!");
            return ArrayUtils.EMPTY_BYTE_ARRAY;
        }
        return messageDigest.digest();
    }


    /**
     * MD5 加密===> 最终的sign
     */
    public static String getMd5Str(String str) {
        return toHex(getMd5(str));
    }

    @Test
    public void testStringToRanDomDigit() {
        String s = "4";
        final int FNV_PRIME = 16777619;
        int hash = 0x811C9DC5;

        for (char c:s.toCharArray()){
            hash ^= c;
            hash *= FNV_PRIME;
        }
        System.out.println(Math.abs(hash)%10);
    }



}

@T

