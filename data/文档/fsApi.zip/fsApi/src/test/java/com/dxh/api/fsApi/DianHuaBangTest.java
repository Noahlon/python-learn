package com.dxh.api.fsApi;

import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dxh.api.fsApi.utils.AESUtil;
import com.dxh.api.fsApi.utils.OkHttpUtil;
import com.dxh.api.fsApi.utils.SnowFlakeUtil;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Headers;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.*;

import static cn.hutool.crypto.digest.DigestAlgorithm.MD5;

@Slf4j
@SpringBootTest
public class DianHuaBangTest {

    public DianHuaBangTest(){

    }

    private Headers headers = new Headers.Builder()
            .add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
            .build();

    @Test
    public void testAddTaskV2() throws InterruptedException {
        for (int i = 0; i < 100; i++){
            addTaskByCallCenter();
            Thread.sleep(100);
            break;
        }
    }

    @Test
    public void testAddTaskV2ByOpenApi() throws InterruptedException {
        for (int i = 0; i < 100; i++){
            addTaskByOpenApi();
            Thread.sleep(100);
            break;
        }
    }
    //调用线上，不要随意使用
//    @Test
//    public void testAddTaskV2ByOpenApiPro() throws InterruptedException {
//        for (int i = 0; i < 100; i++){
//            addTaskByOpenApiPro();
//            Thread.sleep(100);
//            break;
//        }
//    }

    private void addTaskByCallCenter() {
        String url = "https://fat-bff-admin.hellobike.cn/general/bffGeneralReqLogin";
        HashMap<String, Object> params = new HashMap<>();
        params.put("bffAction", "task.createTask");
        String key = DateUtil.format(new Date(), "yyyyMMddHHmmss");
        params.put("name", "dxh测试任务-");
        params.put("exeStartTime", "09:00");
        params.put("exeEndTime","23:00");
        params.put("expectLoadCount", "1");
        params.put("tenant", "11047");
        params.put("faqGuid", "0a4767c5l1lqmucwm4cnj2nfi6dciuws");
        params.put("autoRetry", "0");
        params.put("ext", "{\"autoRetry\":{},\"callDuration\":[{\"startTime\":\"09:00\",\"endTime\":\"23:00\"}]}");
        params.put("groupId", "0a4767c5l1lqmucwm4cnj2nfi6dciuws");
        params.put("taskType", "0");
        params.put("transfer", "0");
        params.put("phoneType", "1");
        params.put("tenantLineGroupId", "5842059117384436314");
        params.put("thirdBlacklistIntercept", "1");
        params.put("featureIntercept", "1");
        params.put("templateGuid", "4143144739837313108");
        params.put("templateName", "dxh任务模版");
        params.put("faqName", "dxh话术-勿动-new");
        params.put("multipleSmsLink", "0");
        Headers headers = new Headers.Builder()
                .add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
                .add("Token", "bearer_99e6096c-c5a1-4ef3-a58f-01e627588181")
                .build();
        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
        JSONObject responseObject = JSON.parseObject(response);
        String guid = responseObject.getString("data");
        //testImportCallListEncryptedCallList(guid,10000L, );
    }


    private void addTaskByOpenApi() {
        String url="https://fat-hello-openapi.hellobike.com/openapi";

        String method = "call.out.createTaskByTemplateGuid";
        //fat
        String appKey = "caoweicode-6UFj9Pjq";
        //pro
        //String appKey = "hnykxx-UqUXcMaO";

        String token = getOpenApiToken();

        String timestamp =  String.valueOf(new Timestamp(System.currentTimeMillis()));
        HashMap<String, Object> params = new HashMap<>();
        params.put("method", method);
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("templateGuid", "6195210537373008432");
        //params.put("templateGuid", "4143144739837313108");
        params.put("taskName", "dxh测试任务-"+ DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss"));
        params.put("token", token);
        //fat
        String sign = signTopRequest(params, "a35c530c15f5492d9c59240b7cc3f186");
        params.put("sign", sign);
        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
        JSONObject responseObject = JSON.parseObject(response);
        String guid = responseObject.getString("data");
        Long phoneNumber = 10000000000L;
        testImportCallListEncryptedCallList(guid,phoneNumber,token);
    }

    private void addTaskByOpenApiPro() {
        String url="https://open.hellobike.com/openapi";

        String method = "call.out.createTaskByTemplateGuid";
        //pro
        String appKey = "hnykxx-UqUXcMaO";

        String token = getOpenApiTokenPro();

        String timestamp =  String.valueOf(new Timestamp(System.currentTimeMillis()));
        HashMap<String, Object> params = new HashMap<>();
        params.put("method", method);
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("templateGuid", "6197618467842031617");
        //params.put("templateGuid", "6118275542747710597");
        params.put("taskName", "TEST-DXH-"+ DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss"));
        params.put("token", token);
        //pro
        String sign = signTopRequest(params, "7cf2f27e8c344fe99478baac8f9e543c");
        params.put("sign", sign);
        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
        JSONObject responseObject = JSON.parseObject(response);
        String guid = responseObject.getString("data");
        Long phoneNumber = 10000000000L;
        testImportCallListEncryptedCallListPro(guid,phoneNumber,token);
    }

    public void testImportCallListEncryptedCallList(String taskGuid, long num, String token) {
        String url="https://fat-hello-openapi.hellobike.com/openapi";

        String method = "call.out.batchImportEncryptedCallListV2";
        String appKey = "caoweicode-6UFj9Pjq";

        JSONArray callList = new JSONArray();

        JSONObject variableInfos = new JSONObject();
        variableInfos.put("variable_2", "123");
        for(int j=0;j<30;j++){
            num = num + 1;
            String phoneNumber = "18758068694";
//            String phoneNumberAes =
//                    "MCICBAEpaLkCCBZH9p+" + AESUtil.encode(String.valueOf(phoneNumber))+ SnowFlakeUtil.getNextId();
            String externalId = "33333333333333333";
            String name = "1223";
            String companyName = "456";
            HashMap<String, String> callListItems = new HashMap<>();
            callListItems.put("phone", phoneNumber);
            callListItems.put("externalId", externalId);
            callListItems.put("name", name);
            callListItems.put("companyName", companyName);
            callListItems.put("variableInfos", variableInfos.toJSONString());
            callList.add(callListItems);
            break;
        }

//        String phoneNumber1 = "18042463702";
//        String externalId1 = "33333333333333333";
//        String name1 = "1223";
//        String companyName1 = "456";
//        HashMap<String, String> callListItems1 = new HashMap<>();
//        callListItems1.put("phone", phoneNumber1);
//        callListItems1.put("externalId", externalId1);
//        callListItems1.put("name", name1);
//        callListItems1.put("companyName", companyName1);
//        callList.add(callListItems1);

        String size = String.valueOf(callList.size());
        String timestamp =  String.valueOf(new Timestamp(System.currentTimeMillis()));
        HashMap<String, Object> params = new HashMap<>();
        params.put("method", method);
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("size", size);
        params.put("taskGuid", taskGuid);
        params.put("callList", callList.toJSONString());
        params.put("token", token);
        String sign = signTopRequest(params, "a35c530c15f5492d9c59240b7cc3f186");
        params.put("sign", sign);
        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
    }

    public void testImportCallListEncryptedCallListPro(String taskGuid, long num, String token) {
        String url="https://open.hellobike.com/openapi";

        String method = "call.out.batchImportEncryptedCallListV2";
        String appKey = "hnykxx-UqUXcMaO";

        JSONArray callList = new JSONArray();

//        JSONObject variableInfos = new JSONObject();
//        variableInfos.put("variable_3", "123");
        for(int j=0;j<30;j++){
            num = num + 1;
            String phoneNumber = "MCICBAEpaLkCCBZH9p+mniABBBAOTngTGRF/RbFUoMBVjGA+";
            String phoneNumberAes =
                    "MCICBAEpaLkCCBZH9p+" + AESUtil.encode(String.valueOf(num))+ SnowFlakeUtil.getNextId();
            String externalId = "33333333333333333";
            String name = "1223";
            String companyName = "456";
            HashMap<String, String> callListItems = new HashMap<>();
            callListItems.put("phone", phoneNumber);
            callListItems.put("externalId", externalId);
            callListItems.put("name", name);
            callListItems.put("companyName", companyName);
            //        items.put("variableInfos", variableInfos.toJSONString());
            callList.add(callListItems);
            break;
        }

//        String phoneNumber1 = "18042463702";
//        String externalId1 = "33333333333333333";
//        String name1 = "1223";
//        String companyName1 = "456";
//        HashMap<String, String> callListItems1 = new HashMap<>();
//        callListItems1.put("phone", phoneNumber1);
//        callListItems1.put("externalId", externalId1);
//        callListItems1.put("name", name1);
//        callListItems1.put("companyName", companyName1);
//        callList.add(callListItems1);

        String size = String.valueOf(callList.size());
        String timestamp =  String.valueOf(new Timestamp(System.currentTimeMillis()));
        HashMap<String, Object> params = new HashMap<>();
        params.put("method", method);
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("size", size);
        params.put("taskGuid", taskGuid);
        params.put("callList", callList.toJSONString());
        params.put("token", token);
        String sign = signTopRequest(params, "7cf2f27e8c344fe99478baac8f9e543c");
        params.put("sign", sign);
        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
    }

    @Test
    public void testListTaskTemplate() {
        String url="https://fat-hello-openapi.hellobike.com/openapi";

        String method = "ds.call.listTaskTemplate";
        String appKey = "caoweicode-WWmJQ8Tb";
        String secret = "801afd8e48764d6f9336cc8a7e277db3";
        String phoneNumber = "15000000000";
        String token = getOpenApiToken(appKey, secret, phoneNumber);

        String timestamp =  String.valueOf(new Timestamp(System.currentTimeMillis()));
        HashMap<String, Object> params = new HashMap<>();
        params.put("method", method);
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("token", token);
        String sign = signTopRequest(params, secret);
        params.put("sign", sign);
        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
        System.out.println(response);
    }

    private String getOpenApiToken(){
        String url = "https://fat-hello-openapi.hellobike.com/login";
        String appKey = "caoweicode-6UFj9Pjq";
        String phoneNumber = "15706805741";
        String timestamp = String.valueOf(new Timestamp(System.currentTimeMillis()));
        HashMap<String, Object> params = new HashMap<>();
        params.put("method", "hello.open.login");
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("phoneNumber", phoneNumber);
        String sign = signTopRequest(params, "a35c530c15f5492d9c59240b7cc3f186");
        params.put("sign", sign);
        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
        JSONObject tokenObject = JSON.parseObject(response);
        return tokenObject.getString("data");
    }

    private String getOpenApiToken(String appKey, String secret, String phoneNumber){
        String url = "https://fat-hello-openapi.hellobike.com/login";
        String timestamp = String.valueOf(new Timestamp(System.currentTimeMillis()));
        HashMap<String, Object> params = new HashMap<>();
        params.put("method", "hello.open.login");
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("phoneNumber", phoneNumber);
        String sign = signTopRequest(params, secret);
        params.put("sign", sign);
        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
        JSONObject tokenObject = JSON.parseObject(response);
        return tokenObject.getString("data");
    }

    private String getOpenApiTokenPro(){
        String url = "https://open.hellobike.com/login";
        String appKey = "hnykxx-UqUXcMaO";
        String phoneNumber = "18758068694";
        String timestamp = String.valueOf(new Timestamp(System.currentTimeMillis()));
        HashMap<String, Object> params = new HashMap<>();
        params.put("method", "hello.open.login");
        params.put("appKey", appKey);
        params.put("timestamp", timestamp);
        params.put("phoneNumber", phoneNumber);
        String sign = signTopRequest(params, "7cf2f27e8c344fe99478baac8f9e543c");
        params.put("sign", sign);
        String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
        JSONObject tokenObject = JSON.parseObject(response);
        return tokenObject.getString("data");
    }

    private  String signTopRequest(Map<String, Object> params, String secret) {
        // 第一步：检查参数是否已经排序
        String[] keys = params.keySet().toArray(new String[0]);
        Arrays.sort(keys);
        // 第二步：把所有参数名和参数值串在一起
        StringBuilder query = new StringBuilder();
        query.append(secret);
        for (String key : keys) {
            if (StringUtils.isNotBlank(key)) {
                String value = (String) params.get(key);

                if (null != value) {

                    query.append(key.trim());

                    query.append(value.trim());
                }

            }

        }

        query.append(secret);

        return getMd5Str(query.toString());

    }

    public static String getStringToSign (JSONObject params, String secret) {

        // 第一步：检查参数是否已经排序

        String[] keys = params.keySet().toArray(new String[0]);

        Arrays.sort(keys);

        // 第二步：把所有参数名和参数值串在一起
        StringBuilder query = new StringBuilder();

        query.append(secret);

        for (String key : keys) {

            if (StringUtils.isNotBlank(key)) {

                Object value = params.get(key);

                if (null != value) {

                    query.append(key.trim());

                    if (value instanceof List || value instanceof Map) {

                        query.append(JSON.toJSONString(value).trim());

                    } else {
                        query.append(String.valueOf(value).trim());

                    }

                }

            }

        }

        query.append(secret);

        return query.toString();

    }

    public static String signTopRequest(JSONObject params, String secret) {

        return getMd5Str(getStringToSign(params, secret));

    }

    /**

     * 获取md5 byte数组

     */

    private static byte[] getMd5(String str) {

        MessageDigest messageDigest;

        try {

            messageDigest = MessageDigest.getInstance(MD5.getValue());

            messageDigest.reset();

            messageDigest.update(str.getBytes(StandardCharsets.UTF_8));

        } catch (NoSuchAlgorithmException e) {

            log.error("NoSuchAlgorithmException caught!");

            return ArrayUtils.EMPTY_BYTE_ARRAY;

        }

        return messageDigest.digest();

    }

    /**

     * MD5 加密

     */

    public static String getMd5Str(String str) {

        return toHex(getMd5(str));

    }

    /**

     * 转小写16进制字符串

     * @param byteArray

     * @return

     */
    private static String toHex(byte[] byteArray) {
        if (null == byteArray) {
            return null;

        }
        StringBuilder md5Str = new StringBuilder();

        for (byte b: byteArray) {

            md5Str.append(String.format("%02x", b));

        }

        return md5Str.toString();

    }
}
