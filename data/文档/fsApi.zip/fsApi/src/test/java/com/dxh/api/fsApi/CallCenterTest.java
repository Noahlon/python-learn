package com.dxh.api.fsApi;

import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dxh.api.fsApi.utils.OkHttpUtil;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Headers;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.*;

import static cn.hutool.crypto.digest.DigestAlgorithm.MD5;

@Slf4j
@SpringBootTest
public class CallCenterTest {

	public CallCenterTest(){

	}

	private Headers headers = new Headers.Builder()
			.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
			.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
			.build();
	@Test
	public void testAddTask() throws InterruptedException {
		for (int i = 0; i < 100; i++){
			addTask();
			Thread.sleep(100);
			break;
		}
	}

	@Test
	public void testAddTaskV2() throws InterruptedException {
		for (int i = 0; i < 100; i++){
			addTaskV2();
			Thread.sleep(100);
			break;
		}
	}

	@Test
	public void testAddTaskV2ByOpenApi() throws InterruptedException {
		for (int i = 0; i < 100; i++){
			addTaskByOpenApi();
			Thread.sleep(100);
			break;
		}
	}

	private void addTask() {
		String url = "https://fat-bff-admin.hellobike.cn/general/bffGeneralReqLogin";
		HashMap<String, Object> params = new HashMap<>();
		params.put("bffAction", "task.createTask");
		params.put("name", "dxh测试任务-202501211956");
		params.put("exeStartTime", "09:00");
		params.put("exeEndTime","23:00");
		params.put("expectLoadCount", "1");
		params.put("tenant", "11047");
		params.put("faqGuid", "0a4767c5l1lqmucwm4cnj2nfi6dciuws");
		params.put("autoRetry", "0");
		params.put("ext", "{\"autoRetry\":{},\"callDuration\":[{\"startTime\":\"09:00\",\"endTime\":\"23:00\"}]}");
		params.put("groupId", "0a4767c5l1lqmucwm4cnj2nfi6dciuws");
		params.put("taskType", "0");
		params.put("transfer", "0");
		params.put("tenantLineGroupId", "6097084174983757827");
		params.put("thirdBlacklistIntercept", "0");
		params.put("featureIntercept", "0");
		params.put("templateGuid", "4143144739837313108");
		params.put("templateName", "dxh任务模版");
		params.put("faqName", "dxh话术-勿动-new");
		params.put("multipleSmsLink", "0");

		Headers headers1 = headers.newBuilder().add("Content-Type", "application/json;charset=UTF-8")
				.add("Accept", "application/json, text/plain, */*")
				.add("Accept-Encoding", "gzip, deflate, br")
				.add("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
				.add("Connection", "keep-alive")
				.add("Token", "bearer_87bf5e98-a6d8-43b9-a127-ae389a287936")
				.build();

		String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers1);
		JSONObject responseObject = JSON.parseObject(response);
		String guid = responseObject.getString("data");
		log.info("create Task guid:" + response);
		testImportCallList(guid);
	}

	private void addTaskV2() {
		String url = "https://fat-bff-admin.hellobike.cn/general/bffGeneralReqLogin";
		HashMap<String, Object> params = new HashMap<>();
		params.put("bffAction", "task.createTask");
		String key = DateUtil.format(new Date(), "yyyyMMddHHmmss");
		params.put("name", "dxh测试任务-"+ key);
		params.put("exeStartTime", "09:00");
		params.put("exeEndTime","23:00");
		params.put("expectLoadCount", "1");
		params.put("tenant", "11047");
		params.put("faqGuid", "0a4767c5l1lqmucwm4cnj2nfi6dciuws");
		params.put("autoRetry", "0");
		params.put("ext", "{\"autoRetry\":{},\"callDuration\":[{\"startTime\":\"09:00\",\"endTime\":\"23:00\"}]}");
		params.put("groupId", "0a4767c5l1lqmucwm4cnj2nfi6dciuws");
		params.put("taskType", "0");
		params.put("transfer", "0");
		params.put("phoneType", "2");
		params.put("tenantLineGroupId", "6097084174983757827");
		params.put("thirdBlacklistIntercept", "1");
		params.put("featureIntercept", "1");
		params.put("templateGuid", "4143144739837313108");
		params.put("templateName", "dxh任务模版");
		params.put("faqName", "dxh话术-勿动-new");
		params.put("multipleSmsLink", "0");
		String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
		JSONObject responseObject = JSON.parseObject(response);
		String guid = responseObject.getString("data");
		log.info("create Task guid:" + response);
		testImportCallListV2(guid);
	}

	private void addTaskByOpenApi() {
		String url="https://fat-hello-openapi.hellobike.com/openapi";

		String method = "call.out.createTaskByTemplateGuid";
		String appKey = "caoweicode-6UFj9Pjq";

		String token = getOpenApiToken();

		String timestamp =  String.valueOf(new Timestamp(System.currentTimeMillis()));
		HashMap<String, Object> params = new HashMap<>();
		params.put("method", method);
		params.put("appKey", appKey);
		params.put("timestamp", timestamp);
        //dxh非bpo租户模版
		params.put("templateGuid", "6195210537373008432");
        //dxh非bpo租户模版长期
        //params.put("templateGuid", "6197618467842031617");
        params.put("taskName", "dxh测试任务-"+ DateUtil.format(new Date(), "yyyyMMddHHmmss"));
		params.put("token", token);
		String sign = signTopRequest(params, "a35c530c15f5492d9c59240b7cc3f186");
		params.put("sign", sign);
		String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
		JSONObject responseObject = JSON.parseObject(response);
		String guid = responseObject.getString("data");
		log.info("create Task guid:" + response);
		testImportCallListV2(guid);
	}



	public void testImportCallListV2(String taskGuid) {
		String url="https://fat-hello-openapi.hellobike.com/openapi";

		String method = "call.out.batchImportEncryptedCallListV2";
		String appKey = "caoweicode-6UFj9Pjq";

		String token = getOpenApiToken();
		JSONArray callList = new JSONArray();

		HashMap<String, String> callListItems = new HashMap<>();
        String phoneNumber = "18758068694";
        String externalId = "33333333333333333";
        String name = "1223";
        String companyName = "456";
		callListItems.put("phone", phoneNumber);
		callListItems.put("externalId", externalId);
		callListItems.put("name", name);
		callListItems.put("companyName", companyName);
        JSONObject variableInfos = new JSONObject();
        variableInfos.put("aaaaaaaa", "我们大A");
        variableInfos.put("variable_3", "123");
        callListItems.put("variableInfos", variableInfos.toJSONString());
		callList.add(callListItems);

        HashMap<String, String> callListItems1 = new HashMap<>();
        String phoneNumber1 = "19116396129";
        String externalId1 = "33333333333333333";
        String name1 = "1223";
        String companyName1 = "456";
        callListItems1.put("phone", phoneNumber1);
        callListItems1.put("externalId", externalId1);
        callListItems1.put("name", name1);
        callListItems1.put("companyName", companyName1);
        JSONObject variableInfos1 = new JSONObject();
        variableInfos1.put("aaaaaaaa", "我们大B");
        variableInfos1.put("variable_3", "456");
        callListItems1.put("variableInfos1", variableInfos1.toJSONString());
        callList.add(callListItems1);

		String size = String.valueOf(callList.size());
		String timestamp =  String.valueOf(new Timestamp(System.currentTimeMillis()));
		HashMap<String, Object> params = new HashMap<>();
		params.put("method", method);
		params.put("appKey", appKey);
		params.put("timestamp", timestamp);
		params.put("size", size);
		params.put("taskGuid", taskGuid);
		params.put("callList", callList.toJSONString());
		params.put("token", token);
		String sign = signTopRequest(params, "a35c530c15f5492d9c59240b7cc3f186");
		params.put("sign", sign);
		String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
		log.info("testImportCallListV2 response:" + response);
	}


	public void testImportCallList(String taskGuid) {
		String url="https://fat-hello-openapi.hellobike.com/openapi";

		String method = "call.out.batchImportEncryptedCallList";
		String appKey = "caoweicode-6UFj9Pjq";

		String token = getOpenApiToken();
		JSONArray callList = new JSONArray();

//        JSONObject variableInfos = new JSONObject();
//        variableInfos.put("variable_3", "123");

		String phoneNumberAes = "747420b5f6ad09f6635c0bc5bf6c29cc";
		String externalId = "33333333333333333";
		String name = "1223";
		String companyName = "456";
		HashMap<String, String> items = new HashMap<>();
		items.put("phoneNumberAes", phoneNumberAes);
		//items.put("externalId", externalId);
		items.put("name", name);
		items.put("companyName", companyName);
//        items.put("variableInfos", variableInfos.toJSONString());
		callList.add(items);

		String size = "1";
		String timestamp =  String.valueOf(new Timestamp(System.currentTimeMillis()));
		HashMap<String, Object> params = new HashMap<>();
		params.put("method", method);
		params.put("appKey", appKey);
		params.put("timestamp", timestamp);
		params.put("size", size);
		params.put("taskGuid", taskGuid);
		params.put("callList", callList.toJSONString());
		params.put("token", token);
		String sign = signTopRequest(params, "a35c530c15f5492d9c59240b7cc3f186");
		params.put("sign", sign);
		String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
		log.info("testImportCallList response:" + response);
	}

	private String getOpenApiToken(){
		String url = "https://fat-hello-openapi.hellobike.com/login";
		String appKey = "caoweicode-6UFj9Pjq";
		String phoneNumber = "15706805741";
		String timestamp = String.valueOf(new Timestamp(System.currentTimeMillis()));
		HashMap<String, Object> params = new HashMap<>();
		params.put("method", "hello.open.login");
		params.put("appKey", appKey);
		params.put("timestamp", timestamp);
		params.put("phoneNumber", phoneNumber);
		String sign = signTopRequest(params, "a35c530c15f5492d9c59240b7cc3f186");
		params.put("sign", sign);
		String response = OkHttpUtil.post(OkHttpUtil.getOkHttpClient(),url, params, headers);
		JSONObject tokenObject = JSON.parseObject(response);
		return tokenObject.getString("data");
	}

	private  String signTopRequest(Map<String, Object> params, String secret) {
		// 第一步：检查参数是否已经排序
		String[] keys = params.keySet().toArray(new String[0]);
		Arrays.sort(keys);
		// 第二步：把所有参数名和参数值串在一起
		StringBuilder query = new StringBuilder();
		query.append(secret);
		for (String key : keys) {
			if (StringUtils.isNotBlank(key)) {
				String value = (String) params.get(key);

				if (null != value) {

					query.append(key.trim());

					query.append(value.trim());
				}

			}

		}

		query.append(secret);

		return getMd5Str(query.toString());

	}

	public static String getStringToSign (JSONObject params, String secret) {

		// 第一步：检查参数是否已经排序

		String[] keys = params.keySet().toArray(new String[0]);

		Arrays.sort(keys);

		// 第二步：把所有参数名和参数值串在一起
		StringBuilder query = new StringBuilder();

		query.append(secret);

		for (String key : keys) {

			if (StringUtils.isNotBlank(key)) {

				Object value = params.get(key);

				if (null != value) {

					query.append(key.trim());

					if (value instanceof List || value instanceof Map) {

						query.append(JSON.toJSONString(value).trim());

					} else {
						query.append(String.valueOf(value).trim());

					}

				}

			}

		}

		query.append(secret);

		return query.toString();

	}

	public static String signTopRequest(JSONObject params, String secret) {

		return getMd5Str(getStringToSign(params, secret));

	}

	/**

	 * 获取md5 byte数组

	 */

	private static byte[] getMd5(String str) {

		MessageDigest messageDigest;

		try {

			messageDigest = MessageDigest.getInstance(MD5.getValue());

			messageDigest.reset();

			messageDigest.update(str.getBytes(StandardCharsets.UTF_8));

		} catch (NoSuchAlgorithmException e) {

			log.error("NoSuchAlgorithmException caught!");

			return ArrayUtils.EMPTY_BYTE_ARRAY;

		}

		return messageDigest.digest();

	}

	/**

	 * MD5 加密

	 */

	public static String getMd5Str(String str) {

		return toHex(getMd5(str));

	}

	/**

	 * 转小写16进制字符串

	 * @param byteArray

	 * @return

	 */
	private static String toHex(byte[] byteArray) {
		if (null == byteArray) {
			return null;

		}
		StringBuilder md5Str = new StringBuilder();

		for (byte b: byteArray) {

			md5Str.append(String.format("%02x", b));

		}

		return md5Str.toString();

	}
}
